<?php
class Second_db_model extends CI_Model {

function __construct(){
    parent::__construct();
    //load our second db and put in $db2
    $this->db2 = $this->load->database('second', TRUE);
}

      function insert_data($tabel,$data)
{
    $this->db2->insert($tabel,$data);
    return  $this->db2->insert_id();
}

function delete_data($tabel,$cond)
{
    $this->db2->where($cond);
    $this->db2->delete($tabel);
    //return $this->db2->last_query();    
    return true;
}

function get_data($table,$cond,$limit=null,$start=null,$order_by=null,$order_type=null)
{
    $this->db2->where($cond);

    if($limit!=''){
        if($start=='0')
        $this->db2->limit($limit);
        else
         $this->db2->limit($limit,$start);
    }
    if($order_by!='' && !empty($order_type))
    {
    $this->db2->order_by($order_by,$order_type);
    }
    $this->db2->from($table);
    $query=$this->db2->get();
   //return $this->db2->last_query();
    return  $query->result();
}

function update_data($table,$data,$cond)
{
    $this->db2->where($cond);
    $this->db2->update($table,$data);
    // return $this->db2->last_query();
    return true;
}

function join_qry($t1,$t2,$join_cond1,$join_cond2,$cond,$select,$limit=null,$start=null)
{
    $this->db2->select($select);
    $this->db2->from($t1);
    $this->db2->join($t2,$t2.'.'.$join_cond1.'='.$t1.'.'.$join_cond2,'left');
    $this->db2->where($cond);
    if($start!='' && $limit!=''){
       $this->db2->limit($limit, $start);
    }
    //$this->db2->group_by('cat_name');// add group_by
    $query=$this->db2->get();
    //return $this->db2->last_query();
    return  $query->result();
}

 function record_count($table_name) {
return $this->db2->count_all($table_name);
}

function record_count2($table_name,$cond=null) {
    if($cond!='')
    {
        $this->db2->where($cond);
    }
    $query=$this->db2->get($table_name);
    //return $this->db2->last_query(); 
//return $this->db2->count_all($table_name);
    return $query->num_rows();
}

function name_exist($table,$cond)
{
    $this->db2->where($cond);
    $result=$this->db2->get($table);
    if($result->num_rows() > 0) 
    {
        
      //$this->form_validation->set_message('alias_exist_check', 'Already exists.');
      return false;
    } 
    else 
    {
        //return $this->db2->last_query();
      return true;
    }
}

function get_data_wherein($table,$pids)
{
    $this->db2->select('sp_name');
    $this->db2->where('sp_status','1');
        $this->db2->where_in('sp_id',$pids);
        $this->db2->from($table);
 $query=$this->db2->get();
   // return $this->db2->last_query();
    return  $query->result();
}




function bnk_bal_rx($cond2,$main_cond='',$or_where_month=null,$like=null)
{
    $cond1=array('ae_status'=>'1','ae_cash_type'=>'Received');
    
    $cond3=array('ae_sts'=>'PDC');
    $cond4=array('ae_sts'=>'Bank Transfer');
    $current_time=date('H:i:s');
    $current_date=date('Y-m-d');
    
    $this->db2->select('SUM(ae_amount) as rx_total');
    $this->db2->from('account_entry1');
    $this->db2->where($cond1);
    $this->db2->where($cond2);

    // $this->db2->where($cond3);
    // $this->db2->or_where($cond4);


if(!empty($main_cond))
    $this->db2->where($main_cond);
if(!empty($or_where_month))
    // $this->db2->or_where($or_where_month);    
    $this->db2->where($or_where_month);  
if(!empty($like))
    $this->db2->like($like);

    $qry=$this->db2->get();
    //return $this->db2->last_query();
    return $qry->result();
}

function bnk_bal_spend($cond2,$main_cond='',$or_where_month=null,$like=null)
{
    $cond1=array('ae_status'=>'1','ae_cash_type'=>'Spend');
    $this->db2->select('SUM(ae_amount) as spend_total' );
    $this->db2->from('account_entry1');
    $this->db2->where($cond1);
    $this->db2->where($cond2);


if(!empty($main_cond))
    $this->db2->where($main_cond);

if(!empty($or_where_month))
    // $this->db2->or_where($or_where_month);    
    $this->db2->where($or_where_month);  
    if(!empty($like))
    $this->db2->like($like);

    $qry=$this->db2->get();
    //return $this->db2->last_query();
    return $qry->result();
}


function bnk_bal_rx_btw_dates($cond2,$start_date,$end_date,$bal_cond=null,$start_date_cond=null,$or_where_start='',$or_where_end='',$like='')
{
    
    $this->db2->select('SUM(ae_amount) as rx_total');
    $this->db2->from('account_entry1');
    $this->db2->where(array('ae_status'=>'1','ae_cash_type'=>'Received'));
    $this->db2->where($cond2);

$this->db2->where('ae_date >=' ,$start_date);
$this->db2->where('ae_date <=', $end_date);

if(!empty($bal_cond))
        $this->db2->where($bal_cond);
if(!empty($start_date_cond))
        $this->db2->where($start_date_cond);
    if(!empty($like))
    $this->db2->like($like);

    $qry=$this->db2->get();
    //return $this->db2->last_query();
    return $qry->result();
}

function bnk_bal_spend_btw_dates($cond2,$start_date,$end_date,$bal_cond=null,$start_date_cond=null,$or_where_start='',$or_where_end='',$like='')
{
    $this->db2->select('SUM(ae_amount) as spend_total' );
    $this->db2->from('account_entry1');
    $this->db2->where(array('ae_status'=>'1','ae_cash_type'=>'Spend'));
    $this->db2->where($cond2);
    // $this->db2->where(" ae_date BETWEEN ". $start_date ." AND ".$end_date);
    // $this->db2->or_where(" ae_date BETWEEN ".$or_where_start." AND ".$or_where_end);  
$this->db2->where('ae_date >=' ,$start_date);
$this->db2->where('ae_date <=' ,$end_date);

if(!empty($bal_cond))
        $this->db2->where($bal_cond);
if(!empty($start_date_cond))
        $this->db2->where($start_date_cond);     

    if(!empty($like))
    $this->db2->like($like);

    $qry=$this->db2->get();
    //return $this->db2->last_query();
    return $qry->result();
}


function update_data_acc()
{
    $qry=$this->get_data('account_entry1',array('ae_status_data'=>'1','ae_status'=>'1'));
    foreach ($qry as $key) {

        $date_created= $key->ae_dt_created;
        $date_from=date ("Y-m-d",strtotime($date_created));
        $date_upto=date("Y-m-d", strtotime("$date_created +7 days"));
        $Today = date("Y-m-d");
        
        if($date_upto==$Today || $date_upto <= $Today)
        {
            $cond1=array('ae_status'=>'1','ae_dt_created'=>$date_created);
                $data=array('ae_status_data'=>'2');
                $this->db2->where($cond1);
                $this->db2->update('account_entry1',$data);
                return true;
        }
        else{
            return true;
        }       
        
    }
    
}


function update_data_fund()
{
    $qry=$this->get_data('fund_transfer',array('ft_trsnf_sts'=>'2','ft_status'=>'1'));
    foreach ($qry as $key) {

        $date_created= $key->ft_date_created;
        $date_from=date ("Y-m-d",strtotime($date_created));

        $date_upto=date("Y-m-d", strtotime("$date_created +7 days"));
        $Today = date("Y-m-d");

        if($date_upto==$Today || $date_upto <= $Today)
        {
            $cond1=array('ft_status'=>'1','ft_date_created'=>$date_created);
                $data=array('ft_trsnf_sts'=>'2');
                $this->db2->where($cond1);
                $this->db2->update('fund_transfer',$data);
                return true;
        }
        else{
            return true;
        }
        
    }
}



function get_opening_bal($cond2,$main_cond='',$or_where_month=null,$like=null)
{
    $cond1=array('ae_status'=>'1','ae_cash_type'=>'Received','ae_desc'=>'Opening Balances');
    $this->db2->select('SUM(ae_amount) as opening_bal_total,ae_amount,COUNT(ae_id) as row_count');
    // $this->db2->select('ae_amount');
    $this->db2->from('account_entry1');

    $this->db2->where($cond1);
    $this->db2->where($cond2);

if(!empty($main_cond))
    $this->db2->where($main_cond);
if(!empty($or_where_month))
    $this->db2->or_where($or_where_month);   
if(!empty($like))
    $this->db2->like($like);

 $this->db2->order_by('ae_date','ASC');
    $qry=$this->db2->get();
    //return $this->db2->last_query();
    if(empty($qry))
        return 0;
    else 
    return $qry->result();
}



function sales_custmr_count($select=null,$cond=null,$group_by=null,$join=null,$join_cond=null,$join_type=null)
{
    if(!empty($select))
    $this->db2->select($select);
    $this->db2->from('sales_customer_entry');
    $this->db2->where(array('sca_status'=>'1'));
    if(!empty($cond))
    $this->db2->where($cond);

    if(!empty($join))
    {
        $this->db2->join($join,$join_cond,$join_type);
    }

if(!empty($group_by))
    $this->db2->group_by($group_by);
    
    $qry=$this->db2->get();
    //return $this->db2->last_query();
    return $qry->result();
}


function sales_cust_country()
{
    $this->db2->select('sca_id, sca_staff_id, sca_cust_id, sca_cust_name, sca_cust_email, sca_cust_landline, sca_cust_mobile, sca_cust_country, sca_cust_company, sca_cust_interest, sca_cust_sms_notf, sca_cust_wtsapp_notf, sca_status,country_val.country_id, country_val.name, country_val.dial_code, country_val.code,country_val.flag');
    $this->db2->from('sales_customer_entry');
    $this->db2->join('country_val','country_val.country_id=sales_customer_entry.sca_cust_country','left');
    $this->db2->where(array('sca_status'=>'1'));
     $this->db2->order_by('sca_id','DESC');

    $query=$this->db2->get();
    //return $this->db2->last_query();
    return  $query->result();
}















}