<?php
class Four_db_model extends CI_Model {

function __construct(){
    parent::__construct();
    //load our second db and put in $db2
    $this->db4 = $this->load->database('four', TRUE);
}

function get_data_main($table,$cond)
{
	$this->db4->where($cond);
	$this->db4->from($table);
	$qry=$this->db4->get();


return $qry->result();
}

function get_data()
{
	$qry=$this->db4->query('select * from u0001');	
	//$qry=$this->db4->query('select * from mr004 as t where t.L2 !=-1');	
//$qry=$this->db4->query('select * from mr004 as t where t.Type=144');	
//$qry=$this->db4->query('select Name,Code2 from mr001 ');	
 // $qry=$this->db4->query('select * from mr000 where L2=493');
//$qry=$this->db4->query('select * from pendingrefs');	
//$qry=$this->db4->query("select *,dbo.convertfocusdatedisplay( d.Date_) as date_convert from data d where dbo.convertfocusdatedisplay( d.Date_)='01-02-2019' ");

return $qry->result();
}

function get_data2()
{
$qry=$this->db4->query("select a.Name Customer,d.VoucherNo, dbo.convertfocusdatedisplay( d.date_),p.* from pendingrefs p
inner join data d on d.BillWiseOff=p.RefId
inner join mr000 a on p.code=a.masterid");
return $qry->result();
}

function get_data3()
{
$qry=$this->db4->query("select a.Name,a.Code,a.Code2,b.WeightYH,b.ClassYH,b.HSCODEYH,b.ExtraArDescriptYH,a.masterid from mr001 a 
	left join u0001 b on b.ExtraId=a.Eoff 

	where b.ClassYH='' or b.ClassYH='NULL'
	
	");
return $qry->result();
}

function get_data31()
{
$qry=$this->db4->query("select a.Name,a.Code,a.Code2,a.masterid,c.prod,c.vals0,c.pty from mr001 a 
	left join u0001 b on b.ExtraId=a.Eoff 
	left join srate c on c.prod=a.masterid 
	where b.ClassYH!=''
	");
return $qry->result();
}


function get_data33($cond)
{
$this->db4->select('a.Name,a.Code,a.Code2,a.masterid,c.prod,c.vals0,c.pty');
	$this->db4->from('srate c');
	$this->db4->join('mr001 a','a.masterid=c.prod','left');
	
	$this->db4->where($cond);
	$qry=$this->db4->get();
	return $qry->result();
}


















}
