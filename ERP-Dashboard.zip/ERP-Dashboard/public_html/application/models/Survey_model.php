<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Survey_model extends CI_Model {


function get_survey_prd_set($cond=null)
{
	$this->db->from('survey_table');
	if(!empty($cond))
		$this->db->where($cond);

	$this->db->where(array('st_sts'=>'1'));
	$this->db->join('product_set_data','product_set_data.psd_survey_id=survey_table.st_id','left');
	$qry=$this->db->get();
	return $qry->result();
}

function survey_installation($cond=null)
{
	$this->db->from('survey_table');
	if(!empty($cond))
		$this->db->where($cond);

	$this->db->where(array('st_sts'=>'1'));
	$this->db->join('installation_dept','installation_dept.ins_survey_id=survey_table.st_id','left');
	$this->db->order_by('ins_id','DESC');
	$this->db->group_by('st_id');
	$qry=$this->db->get();
	return $qry->result();
}


function get_login_emp_details($cond=null)
{
	$this->db->from('employee_details');
	if(!empty($cond))
		$this->db->where($cond);

	$this->db->where(array('ed_sts'=>'1'));
	$this->db->join(' login_credentials',' login_credentials.log_id=employee_details.ed_login_id','left');
	
	//$this->db->group_by('st_id');
	$qry=$this->db->get();
	return $qry->result();
}






























}