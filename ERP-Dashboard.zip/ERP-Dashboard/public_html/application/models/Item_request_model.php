<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item_request_model extends CI_Model {


function get_combined_item_generate_shipment($cond)
{
	$this->db->from('generate_shipment_details');
	if(!empty($cond))
		$this->db->where($cond);
	$this->db->where(array('gsd_sts'=>'1'));
	$this->db->join('item_request','item_request.ir_id=generate_shipment_details.gsd_item_req_id','left');
	$qry=$this->db->get();
	return $qry->result();
}












}