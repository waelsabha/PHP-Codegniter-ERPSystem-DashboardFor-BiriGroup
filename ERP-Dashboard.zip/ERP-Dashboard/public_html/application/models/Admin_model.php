<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {

function insert_data($tabel,$data)
{
	$this->db->insert($tabel,$data);
	return  $this->db->insert_id();
}

function insert_data2($tabel,$data)
{
$this->db->insert($tabel,$data);
//return $this->db->last_query();    
	return  $this->db->insert_id();
}

function insert_batch_data($tabel,$data)
{
	$this->db->insert_batch($tabel,$data);
	return  $this->db->insert_id();
}

function delete_data($tabel,$cond)
{
	$this->db->where($cond);
	$this->db->delete($tabel);
	//return $this->db->last_query();    
	return true;
}
function truncate_table($table_name)
{
	$this->db->truncate($table_name);
}
function get_data($table,$cond=null,$limit=null,$start=null,$order_by=null,$order_type=null,$grp_by=null,$like_cond=null)
{
	if(!empty($cond))
	$this->db->where($cond);

	if($limit!=''){
		if($start=='0')
		$this->db->limit($limit);
		else
		 $this->db->limit($limit,$start);
    }
    if($order_by!='' && !empty($order_type))
    {
    $this->db->order_by($order_by,$order_type);
    }
    if(!empty($grp_by))
    {
    $this->db->group_by($grp_by);
    }
    if(!empty($like_cond))
    {
    $this->db->like($like_cond);
    }
	$this->db->from($table);
    $query=$this->db->get();
   //return $this->db->last_query();
	return  $query->result();
}
function get_data_multiple($table, $conditions = array(), $limit = null, $start = null, $order_by = null, $order_type = null, $grp_by = null, $like_cond = null)
{
    if (!empty($conditions)) {
        $this->db->group_start();
        foreach ($conditions as $condition) {
            $this->db->or_group_start();
            $this->db->where($condition);
            $this->db->group_end();
        }
        $this->db->group_end();
    }

    if ($limit != '') {
        if ($start == '0') {
            $this->db->limit($limit);
        } else {
            $this->db->limit($limit, $start);
        }
    }

    if ($order_by != '' && !empty($order_type)) {
        $this->db->order_by($order_by, $order_type);
    }

    if (!empty($grp_by)) {
        $this->db->group_by($grp_by);
    }

    if (!empty($like_cond)) {
        $this->db->like($like_cond);
    }

    $query = $this->db->get($table);

    return $query->result();
}

function get_data_2($table,$cond,$limit=null,$start=null,$order_by=null,$order_type=null)
{
	//$this->db->select('SUM(ae_amount) as total_bal');
	$this->db->where($cond);

	if($limit!=''){
		if($start=='0')
		$this->db->limit($limit);
		else
		 $this->db->limit($limit,$start);
    }
    if($order_by!='' && !empty($order_type))
    {
    $this->db->order_by($order_by,$order_type);
    }
	$this->db->from($table);
    $query=$this->db->get();
   //return $this->db->last_query();
	return  $query->result();
}

function get_data_select_column($select,$table,$cond,$limit=null,$start=null,$order_by=null,$order_type=null)
{
	$this->db->select('SUM('.$select.') as total_bal');
	$this->db->where($cond);

	if($limit!=''){
		if($start=='0')
		$this->db->limit($limit);
		else
		 $this->db->limit($limit,$start);
    }
    if($order_by!='' && !empty($order_type))
    {
    $this->db->order_by($order_by,$order_type);
    }
	$this->db->from($table);
    $query=$this->db->get();
   //return $this->db->last_query();
	return  $query->result();
}


function update_data($table,$data,$cond)
{
	$this->db->where($cond);
	$this->db->update($table,$data);
	// return $this->db->last_query();
	return true;
}

function join_qry($t1,$t2,$join_cond1,$join_cond2,$cond,$select,$limit=null,$start=null)
{
	$this->db->select($select);
	$this->db->from($t1);
	$this->db->join($t2,$t2.'.'.$join_cond1.'='.$t1.'.'.$join_cond2,'left');
	$this->db->where($cond);
	if($start!='' && $limit!=''){
       $this->db->limit($limit, $start);
    }
	//$this->db->group_by('cat_name');// add group_by
	$query=$this->db->get();
	//return $this->db->last_query();
	return  $query->result();
}

 function record_count($table_name) {
return $this->db->count_all($table_name);
}

function record_count2($table_name,$cond=null) {
	if($cond!='')
	{
		$this->db->where($cond);
	}
	$query=$this->db->get($table_name);
	//return $this->db->last_query(); 
//return $this->db->count_all($table_name);
return $query->num_rows();
}


function CBM_Ready_count($table_name,$cond=null)
{
    $this->db->select('SUM(CBM_Size) as total_cbm');
    $this->db->from($table_name);
    $this->db->where('ir_sts', '1');
    $this->db->group_start(); // Start of the OR condition
    $this->db->where('ir_req_status', '3');
    $this->db->or_where('ir_req_status', '4');
    $this->db->group_end(); // End of the OR condition

    $qry = $this->db->get();
    // return $this->db->last_query();
    return $qry->result();
}






function name_exist($table,$cond)
{
	$this->db->where($cond);
	$result=$this->db->get($table);
	if($result->num_rows() > 0) 
	{
		
      //$this->form_validation->set_message('alias_exist_check', 'Already exists.');
      return false;
   	} 
   	else 
   	{
   		//return $this->db->last_query();
      return true;
   	}
}

function get_data_wherein($table,$pids)
{
	$this->db->select('sp_name');
	$this->db->where('sp_status','1');
		$this->db->where_in('sp_id',$pids);
		$this->db->from($table);
 $query=$this->db->get();
   // return $this->db->last_query();
	return  $query->result();
}


function bnk_bal_sum_amount1($cond2,$like='',$order_by=null,$order_type=null)
{
	
	$this->db->select('SUM(ae_amount) as total_amount');
	$this->db->from('account_entry1');
	$this->db->where(array('ae_status'=>'1','ae_cash_type'=>'Received'));
	$this->db->where($cond2);

	if(!empty($like))
	$this->db->like($like);
 if($order_by!='' && !empty($order_type))
    {
    $this->db->order_by($order_by,$order_type);
    }
	$qry=$this->db->get();
	//return $this->db->last_query();
	return $qry->result();
}


function bnk_bal_sum_amount2($cond2,$like='',$order_by=null,$order_type=null)
{
	
	$this->db->select('SUM(ae_amount) as total_amount');
	$this->db->from('account_entry1');
	$this->db->where(array('ae_status'=>'1','ae_cash_type'=>'Spend'));
	$this->db->where($cond2);

	if(!empty($like))
	$this->db->like($like);
 if($order_by!='' && !empty($order_type))
    {
    $this->db->order_by($order_by,$order_type);
    }
	$qry=$this->db->get();
	//return $this->db->last_query();
	return $qry->result();
}


function bnk_bal_rx($cond2,$main_cond='',$or_where_month=null,$like=null)
{
	$cond1=array('ae_status'=>'1','ae_cash_type'=>'Received');
	
	$cond3=array('ae_sts'=>'PDC');
	$cond4=array('ae_sts'=>'Bank Transfer');
	$current_time=date('H:i:s');
	$current_date=date('Y-m-d');
	
	$this->db->select('SUM(ae_amount) as rx_total');
	$this->db->from('account_entry1');
	$this->db->where($cond1);
	$this->db->where($cond2);

	// $this->db->where($cond3);
	// $this->db->or_where($cond4);


if(!empty($main_cond))
	$this->db->where($main_cond);
if(!empty($or_where_month))
	// $this->db->or_where($or_where_month);	
	$this->db->where($or_where_month);	
if(!empty($like))
	$this->db->like($like);

	$qry=$this->db->get();
	//return $this->db->last_query();
	return $qry->result();
}

function bnk_bal_spend($cond2,$main_cond='',$or_where_month=null,$like=null)
{
	$cond1=array('ae_status'=>'1','ae_cash_type'=>'Spend');
	$this->db->select('SUM(ae_amount) as spend_total' );
	$this->db->from('account_entry1');
	$this->db->where($cond1);
	$this->db->where($cond2);


if(!empty($main_cond))
	$this->db->where($main_cond);

if(!empty($or_where_month))
	// $this->db->or_where($or_where_month);	
	$this->db->where($or_where_month);	
	if(!empty($like))
	$this->db->like($like);

	$qry=$this->db->get();
	//return $this->db->last_query();
	return $qry->result();
}


function bnk_bal_rx_btw_dates($cond2,$start_date=null,$end_date=null,$bal_cond=null,$start_date_cond=null,$or_where_start='',$or_where_end='',$like='',$order_by=null,$order_type=null)
{
	
	$this->db->select('SUM(ae_amount) as rx_total');
	$this->db->from('account_entry1');
	$this->db->where(array('ae_status'=>'1','ae_cash_type'=>'Received'));
	$this->db->where($cond2);
	
if(!empty($start_date))
$this->db->where('ae_date >=' ,$start_date);
if(!empty($end_date))
$this->db->where('ae_date <=', $end_date);

if(!empty($bal_cond))
		$this->db->where($bal_cond);
if(!empty($start_date_cond))
		$this->db->where($start_date_cond);
	if(!empty($like))
	$this->db->like($like);
 if($order_by!='' && !empty($order_type))
    {
    $this->db->order_by($order_by,$order_type);
    }
	$qry=$this->db->get();
	//return $this->db->last_query();
	return $qry->result();
}

function bnk_bal_spend_btw_dates($cond2,$start_date=null,$end_date=null,$bal_cond=null,$start_date_cond=null,$or_where_start='',$or_where_end='',$like='',$order_by=null,$order_type=null)
{
	$this->db->select('SUM(ae_amount) as spend_total' );
	$this->db->from('account_entry1');
	$this->db->where(array('ae_status'=>'1','ae_cash_type'=>'Spend'));
	$this->db->where($cond2);
	// $this->db->where(" ae_date BETWEEN ". $start_date ." AND ".$end_date);
	// $this->db->or_where(" ae_date BETWEEN ".$or_where_start." AND ".$or_where_end);
		
if(!empty($start_date))
$this->db->where('ae_date >=' ,$start_date);
if(!empty($end_date))
$this->db->where('ae_date <=', $end_date);

if(!empty($bal_cond))
		$this->db->where($bal_cond);
if(!empty($start_date_cond))
		$this->db->where($start_date_cond);		

	if(!empty($like))
	$this->db->like($like);
 if($order_by!='' && !empty($order_type))
    {
    $this->db->order_by($order_by,$order_type);
    }
	$qry=$this->db->get();
	//return $this->db->last_query();
	return $qry->result();
}

function entire_bnk_bal($cond2,$like=null,$order_by=null,$order_type=null,$group_by=null)
{
	
	$this->db->select('*');
	$this->db->from('account_entry1');
	$this->db->where(array('ae_status'=>'1'));
	$this->db->where($cond2);

	if(!empty($like))
	$this->db->like($like);

 if($order_by!='' && !empty($order_type))
   $this->db->order_by($order_by,$order_type);
   
    if(!empty($group_by))
	$this->db->group_by($group_by);

	$qry=$this->db->get();
	//return $this->db->last_query();
	return $qry->result();
}

function get_max_data($table,$cond2,$like=null,$limit=null,$order_by=null,$order_type=null)
{
	//$this->db->select_max('ae_id');
	$this->db->where($cond2);

	if(!empty($like))
	$this->db->like($like);

 if($order_by!='' && !empty($order_type))
    {
    $this->db->order_by($order_by,$order_type);
    }

    if(!empty($limit)){
       $this->db->limit($limit);
    }
    
    $this->db->from($table);
	$qry=$this->db->get();
	//return $this->db->last_query();
	return $qry->result();
}

function update_data_acc()
{
	$qry=$this->get_data('account_entry1',array('ae_status_data'=>'1','ae_status'=>'1'));
	// foreach ($qry as $key) {

	// 	$date_created= $key->ae_dt_created;
	// 	$date_from=date ("Y-m-d",strtotime($date_created));
	// 	$date_upto=date("Y-m-d", strtotime("$date_created +7 days"));
	// 	$Today = date("Y-m-d");
		
	// 	if($date_upto==$Today || $date_upto <= $Today)
	// 	{
	// 		$cond1=array('ae_status'=>'1','ae_dt_created'=>$date_created);
	// 			$data=array('ae_status_data'=>'2');
	// 			$this->db->where($cond1);
	// 			$this->db->update('account_entry1',$data);
	// 			return true;
	// 	}
	// 	else{
	// 		return true;
	// 	}		
		
	// }
	
}





function get_srproduct_details($table,$cond,$limit=null,$start=null,$order_by=null,$order_type=null,$or_where=null)
{
    $this->db->where($cond);
    //$this->db2->where($cond2);
if(!empty($or_where))
 $this->db->or_where($or_where);

    if($limit!=''){
        if($start=='0')
        $this->db->limit($limit);
        else
         $this->db->limit($limit,$start);
    }
    if($order_by!='' && !empty($order_type))
    {
    $this->db->order_by($order_by,$order_type);
    }

    $this->db->from($table);
    $query=$this->db->get();
    //return $this->db2->last_query();
   return  $query->result();
}







function update_data_fund()
{
	$qry=$this->get_data('fund_transfer',array('ft_trsnf_sts'=>'2','ft_status'=>'1'));
	// foreach ($qry as $key) {

	// 	$date_created= $key->ft_date_created;
	// 	$date_from=date ("Y-m-d",strtotime($date_created));

	// 	$date_upto=date("Y-m-d", strtotime("$date_created +7 days"));
	// 	$Today = date("Y-m-d");

	// 	if($date_upto==$Today || $date_upto <= $Today)
	// 	{
	// 		$cond1=array('ft_status'=>'1','ft_date_created'=>$date_created);
	// 			$data=array('ft_trsnf_sts'=>'2');
	// 			$this->db->where($cond1);
	// 			$this->db->update('fund_transfer',$data);
	// 			return true;
	// 	}
	// 	else{
	// 		return true;
	// 	}
		
	// }
}



function get_opening_bal($cond2,$main_cond='',$or_where_month=null,$like=null)
{
	$cond1=array('ae_status'=>'1','ae_cash_type'=>'Received','ae_desc'=>'Opening Balances');
	$this->db->select('SUM(ae_amount) as opening_bal_total,ae_amount,COUNT(ae_id) as row_count');
	// $this->db->select('ae_amount');
	$this->db->from('account_entry1');

	$this->db->where($cond1);
	$this->db->where($cond2);

if(!empty($main_cond))
	$this->db->where($main_cond);
if(!empty($or_where_month))
	$this->db->or_where($or_where_month);	
if(!empty($like))
	$this->db->like($like);

 $this->db->order_by('ae_date','ASC');
	$qry=$this->db->get();
	//return $this->db->last_query();
	if(empty($qry))
		return 0;
	else 
	return $qry->result();
}



function sales_custmr_count($select=null,$cond=null,$group_by=null,$join=null,$join_cond=null,$join_type=null)
{
	if(!empty($select))
	$this->db->select($select);
	$this->db->from('sales_customer_entry');
	$this->db->where(array('sca_status'=>'1'));
	if(!empty($cond))
	$this->db->where($cond);

	if(!empty($join))
	{
		$this->db->join($join,$join_cond,$join_type);
	}

if(!empty($group_by))
	$this->db->group_by($group_by);
	
	$qry=$this->db->get();
	//return $this->db->last_query();
	return $qry->result();
}


function sales_cust_country($cond=null,$wherein_cond=null)
{
	$this->db->select('sca_id, sca_staff_id, sca_cust_id, sca_cust_name, sca_cust_email, sca_cust_landline, sca_cust_mobile, sca_cust_country, sca_cust_company, sca_cust_interest, sca_cust_sms_notf, sca_cust_wtsapp_notf,sca_cust_designation, sca_status,sca_business_cards,sca_dt_updated,country_val.country_id, country_val.name, country_val.dial_code, country_val.code,country_val.flag');
	$this->db->from('sales_customer_entry');
	$this->db->join('country_val','country_val.country_id=sales_customer_entry.sca_cust_country','left');
	if(!empty($cond))
	$this->db->where($cond);
	if(!empty($wherein_cond))
	$this->db->where_in('sca_staff_id',$wherein_cond);
	$this->db->where(array('sca_status'=>'1'));
	 $this->db->order_by('sca_id','DESC');

	$query=$this->db->get();
	//return $this->db->last_query();
	return  $query->result();
}

function emp_country($cond=null,$wherein_cond=null)
{
	$this->db->select('ed_id, ed_name, ed_pos, ed_doj, ed_nationality, ed_mob, ed_martial_sts, ed_gender, ed_branch, ed_pic, ed_jol, ed_emp_ltr, ed_visa, ed_psprt, ed_emirates_id, ed_vacation_date, ed_tkt_sts, ed_sick_leave_pay,country_val.country_id, country_val.name as country_name, country_val.dial_code, country_val.code,country_val.flag');
	$this->db->from('employee_details');
	$this->db->join('country_val','country_val.country_id=employee_details.ed_nationality','left');
	if(!empty($cond))
	$this->db->where($cond);
	if(!empty($wherein_cond))
	$this->db->where_in('ed_id',$wherein_cond);

	$this->db->where(array('ed_sts'=>'1'));
	 $this->db->order_by('ed_id','DESC');

	$query=$this->db->get();
	//return $this->db->last_query();
	return  $query->result();
}


function get_data_list_account($type=null,$bnk=null,$mnt=null,$yr=null,$strt_dt=null,$end_dt=null,$dt_crtd=null,$limit=null,$start=null,$order_by=null,$order_type=null)
{
	$this->db->where(array('ae_status'=>'1','ae_desc !='=>"Opening Balances"));
	//////conditions strats ////////

	if(!empty($type))
		$this->db->where('ae_cash_type',$type);

	if(!empty($bnk))
	$this->db->where('ae_bank',$bnk);

	if(!empty($mnt))
	$this->db->where('ae_month',$mnt);

	if(!empty($yr))
	$this->db->where('ae_year',$yr);

	if(!empty($dt_crtd))
	$this->db->where('DATE(ae_dt_updt)',$dt_crtd);
	
	if(!empty($strt_dt)&&!empty($end_dt))
		$this->db->where(array('ae_date >='=>$strt_dt,'ae_date <='=>$end_dt));

	elseif(!empty($strt_dt))
		$this->db->where(array('ae_date >='=>$strt_dt));

	elseif(!empty($end_dt))	
		$this->db->where(array('ae_date <='=>$end_dt));
	else{}
	/////////////end of cond//////////

	if($limit!=''){
		if($start=='0')
		$this->db->limit($limit);
		else
		 $this->db->limit($limit,$start);
    }
    if($order_by!='' && !empty($order_type))
    {
    $this->db->order_by($order_by,$order_type);
    }
	$this->db->from('account_entry1');
    $query=$this->db->get();
   	//return $this->db->last_query();
	return  $query->result();
}





function accounts_master_data($cond=null,$cr_yr=null,$date1=null)
{
	$names = array('Cash Dubai', 'Transfer Mo', 'POS Transac','Unbilled Pu','Unbilled Ex','Direct Cash');
	$this->db->select("acc_md_id,acc_md_date,acc_md_dr_amnt,acc_id_cat,acc_m_name,YEAR(`acc_md_date`) as year,acc_md_acc_name");
	$this->db->from('account_master_data');
	$this->db->join('account_master_category','account_master_category.acc_m_id=account_master_data.acc_id_cat','left');
	$this->db->where('acc_id_cat',$cond);
	if(!empty($cond))
	$this->db->where('acc_id_cat',$cond);
	if(!empty($cr_yr))
	$this->db->where(array('YEAR(`acc_md_date`)'=>$cr_yr));

if(!empty($date1) )
$this->db->where($date1);

	$this->db->where_not_in('acc_md_acc_name', $names);
	$this->db->order_by('YEAR(`acc_md_date`)','DESC');
	//$this->db->group_by('YEAR(`acc_md_date`)');
	$qry=$this->db->get();	
	//	return $this->db->last_query();			
	return $qry->result();
}


function get_data_leave($cond=null)
{
	$this->db->select("add_leave.*,tbl_emp_tree.et_name,tbl_emp_tree.et_id");
	$this->db->from('add_leave');
	$this->db->join('tbl_emp_tree','tbl_emp_tree.et_id=add_leave.l_user','left');
	//$this->db->where('acc_id_cat',$cond);
	if(!empty($cond))
	$this->db->where($cond);
	
	$qry=$this->db->get();	
	//	return $this->db->last_query();			
	return $qry->result();
}



function get_compare_sales_receipt($cond=null)
{
	$this->db->from('inv_complete_sales_report');
	$this->db->join('inv_recipt_reg','inv_recipt_reg.irr_voc_no_sales=inv_complete_sales_report.icsr_voc_no','left');
	//$this->db->where('acc_id_cat',$cond);
	if(!empty($cond))
	$this->db->where($cond);
	//$this->db->order_by('DATE(`icsr_date`)','ASC');
	$qry=$this->db->get();	
	//	return $this->db->last_query();			
	return $qry->result();
}


function get_request_money($cond=null)
{
	$this->db->select("emp_request_money.*,tbl_emp_tree.et_name,tbl_emp_tree.et_id");
	$this->db->from('emp_request_money');
	$this->db->join('tbl_emp_tree','tbl_emp_tree.et_id=emp_request_money.r_user','left');
	//$this->db->where('acc_id_cat',$cond);
	if(!empty($cond))
	$this->db->where($cond);
	
	$qry=$this->db->get();	
	//	return $this->db->last_query();			
	return $qry->result();
}




function generateCode($user_id)
{
	$datetimecreate=get_date_time();
	$code=rand(1000,9999);
	$item=array('user_id'=>$user_id,'code'=>$code,'datecreated'=>$datetimecreate);
	$this->db->insert('user_code',$item);		
	return $code;
}

function authenticateCode($user_id,$code)
{
	$code=$this->db->select('*')->from('user_code')->where('user_id',$user_id)->where('code',$code)->where('is_expire','0')->get()->result_array();


	if($code)
	{
		 return true;
	}

	 else
        {
            return false;
        }
}

public function expireCode($user_id)
    {
        $this->db->query("update user_code set is_expire='1' where user_id=".$user_id);
    }




  public function getAllById($table,$id)
    {
        $st= $this->db->select('*')->from($table)->WHERE('id',$id)->get()->result_array();
        return $st[0];
    }





 public function get_child_assets($id)
    {
	 		$this->db->select("item_name,item_id");
	          $this->db->from('items_assets');
	
	            $this->db->where('parent_asset',$id);

	            $qry=$this->db->get();	
		
	              return $qry->result();
      
    }







}