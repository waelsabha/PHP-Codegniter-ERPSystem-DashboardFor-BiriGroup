<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Purchase_book_model extends CI_Model {

function bar_chart_year($year,$month)
{
$this->db->select('SUM(pb_net_amount) as total_amount');
	$this->db->from('purchase_book');

	$this->db->where(array('pb_month'=>$month,'pb_sts'=>'1','pb_year'=>$year));
	
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();	
}



function cat_total_month($year,$month)
{
$this->db->select('SUM(pb_net_amount) as total_amount,pb_class');
	$this->db->from('purchase_book');

	$this->db->where(array('pb_month'=>$month,'pb_sts'=>'1','pb_year'=>$year));
	$this->db->group_by('pb_class');
			$qry=$this->db->get();
		//return $this->db->last_query();
		return $qry->result();	
}

function all_category($year=null,$cond=null,$month_cond=null)
{
	$this->db->select("COUNT(pb_class) as total_cat,SUM(pb_net_amount) as total_amount,pb_class");
	$this->db->from('purchase_book');
	
	$this->db->where(array('pb_sts'=>'1','pb_class !='=>''));
	$this->db->where_not_in('pb_class ', array('Safety Stickers','GAS & AIR HOSE','Road Tape'));

	if(!empty($year))
	$this->db->where(array('pb_year'=>$year));

	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
	
	$this->db->group_by('pb_class');
	$this->db->order_by('total_amount','DESC');

	$qry=$this->db->get();		
	//return $this->db->last_query();		
	return $qry->result();	
}


function all_prd($year=null,$cond=null,$month_cond=null,$cat)
{
	$this->db->select("pb_id,pb_class, pb_prd_code, pb_prd_name, pb_qnty, pb_rate, pb_gross, pb_rcpt_rate, pb_net_amount, pb_branch");
	$this->db->from('purchase_book');

	if(!empty($cat))
	$this->db->where(array('pb_class'=>$cat));
	
	$this->db->where(array('pb_sts'=>'1'));
	
	if(!empty($year))
	$this->db->where(array('pb_year'=>$year));

	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
		
	$this->db->order_by('pb_net_amount','DESC');
$qry=$this->db->get();		
	//return $this->db->last_query();		
	return $qry->result();	
}


function all_category_purchase($year=null,$cond=null,$month_cond=null,$city_list=null,$where_in_cond=null)
{
	$this->db->select("COUNT(sbp_ar_category) as total_cat,SUM(sbp_gross) as total_gross_amount,sbp_ar_category");
	$this->db->from('sales_book_product');
	$this->db->join('sales_book_report','sales_book_report.sbr_id=sales_book_product.sbp_vochure_no');

	$this->db->where(array('sbp_ar_sts'=>'1'));
	
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));

	if(!empty($cond))
		$this->db->where($cond);

	if(!empty($where_in_cond))
	$this->db->where_in('sbp_ar_category ', $where_in_cond);
		

	if(!empty($month_cond))
		$this->db->where($month_cond);
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}	

	$this->db->group_by('sbp_ar_category');
	$this->db->order_by('total_gross_amount','DESC');

	$qry=$this->db->get();		
	//return $this->db->last_query();		
	return $qry->result();	
}


function all_prd_purchase($cat=null,$branch=null,$salesperson=null,$year=null,$cond=null,$month_cond=null,$city_list=null)
{
	$this->db->select('sbp_prd_code,sbp_prd_name,sbp_ar_category,sbp_gross,sbp_qty,sbr_branch,sbr_salesman');
	$this->db->from('sales_book_product');
	$this->db->join('sales_book_report','sales_book_report.sbr_id=sales_book_product.sbp_vochure_no');

	if(!empty($cat))
	{
	$this->db->where(array('sbp_ar_category'=>$cat,'sbr_sts'=>'1'));
	}
	if(!empty($branch))
	{
	$this->db->where(array('sbr_branch'=>$branch,'sbr_sts'=>'1'));
	}
	if(!empty($salesperson))
	{
	$this->db->where(array('sbr_salesman'=>$salesperson,'sbr_sts'=>'1'));
	}
	
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));

	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
	if(!empty($city_list))
	{
	$this->db->where_in('sales_book_report.sbr_city',$city_list);
	}
		

	$this->db->order_by('sbp_prd_code','DESC');
$qry=$this->db->get();		
	//return $this->db->last_query();		
	return $qry->result();	
}








}


