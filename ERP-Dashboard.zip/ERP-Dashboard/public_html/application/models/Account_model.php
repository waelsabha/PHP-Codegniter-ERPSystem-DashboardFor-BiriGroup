<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account_model extends CI_Model {

function get_name_acc_tree()
{
	$this->db->select('root_id,root_name,root_memo,root_bal,root_code,root_sts,
		par_id, par_root, par_name, par_opening_bal, par_ac_code, par_memo, par_sts,
		ch_id, ch_root, ch_imd_parnt, ch_nxt_parnt, ch_name, ch_opening_bal, ch_memo, ch_code, ch_sts,
		account_tree_sibling.sib_id, account_tree_sibling.sib_root, account_tree_sibling.sib_parnt, account_tree_sibling.sib_child, account_tree_sibling.sib_1, account_tree_sibling.sib_opening_bal, account_tree_sibling.sib_memo, account_tree_sibling.sib_code, account_tree_sibling.sib_sts,

		account_tree_sibling2.sib_id as sib2_id, account_tree_sibling2.sib_root as sib2_root, account_tree_sibling2.sib_parnt as sib2_prnt, account_tree_sibling2.sib_child as sib2_child, account_tree_sibling2.sib_1 as sib2_1, account_tree_sibling2.sib_2 as sib2_2, account_tree_sibling2.sib_opening_bal as sib2_bal, account_tree_sibling2.sib_memo as sib2_memo, account_tree_sibling2.sib_code as sib2_code, account_tree_sibling2.sib_sts as sib2_sts,

		account_tree_sibling3.sib_id as sib3_id, account_tree_sibling3.sib_root as sib3_root, account_tree_sibling3.sib_parnt as sib3_prnt, account_tree_sibling3.sib_child as sib3_child, account_tree_sibling3.sib_1 as sib3_1, account_tree_sibling3.sib_2 as sib3_2, account_tree_sibling3.sib_3 as sib3_3, account_tree_sibling3.sib_opening_bal as sib3_bal, account_tree_sibling3.sib_memo as sib3_memo, account_tree_sibling3.sib_code as sib3_code, account_tree_sibling3.sib_sts as sib3_sts,

		account_tree_sibling4.sib_id as sib4_id, account_tree_sibling4.sib_root as sib4_root, account_tree_sibling4.sib_parnt as sib4_prnt, account_tree_sibling4.sib_child as sib4_child, account_tree_sibling4.sib_1 as sib4_1, account_tree_sibling4.sib_2 as sib4_2, account_tree_sibling4.sib_3 as sib4_3, account_tree_sibling4.sib_4 as sib4_4, account_tree_sibling4.sib_opening_bal as sib4_bal,
		 account_tree_sibling4.sib_memo as sib4_memo, account_tree_sibling4.sib_code as sib4_code,
		  account_tree_sibling4.sib_sts as sib4_sts,

		  account_tree_sibling5.sib_id as sib5_id, account_tree_sibling5.sib_root as sib5_root, account_tree_sibling5.sib_parnt as sib5_prnt, account_tree_sibling5.sib_child as sib5_child, account_tree_sibling5.sib_1 as sib5_1, account_tree_sibling5.sib_2 as sib5_2, account_tree_sibling5.sib_3 as sib5_3, account_tree_sibling5.sib_4 as sib5_4, account_tree_sibling5.sib_5 as sib5_5, account_tree_sibling5.sib_opening_bal as sib5_bal, account_tree_sibling5.sib_memo as sib5_memo, account_tree_sibling5.sib_code as sib5_code, account_tree_sibling5.sib_sts as sib5_sts,
	');

	$this->db->from('account_tree_root');
	$this->db->join('account_tree_parent','account_tree_parent.par_root=account_tree_root.root_id','left');

	$this->db->join('account_tree_child','account_tree_child.ch_root=account_tree_root.root_id','left');
	$this->db->join('account_tree_sibling','account_tree_sibling.sib_root=account_tree_root.root_id','left');

	$this->db->join('account_tree_sibling2','account_tree_sibling2.sib_root=account_tree_root.root_id','left');

	$this->db->join('account_tree_sibling3','account_tree_sibling3.sib_root=account_tree_root.root_id','left');

	$this->db->join('account_tree_sibling4','account_tree_sibling4.sib_root=account_tree_root.root_id','left');

	$this->db->join('account_tree_sibling5','account_tree_sibling5.sib_root=account_tree_root.root_id','left');
		
	$this->db->where(array('root_sts'=>'1'));	
	///$this->db->group_by('root_name');// add group_by
	$query=$this->db->get();
	//return $this->db->last_query();
	return  $query->result();
}


function acc_cust_country()
{
	$this->db->select('ac_id, ac_staff, ac_code, ac_name, ac_mobile, ac_email, ac_adrs, ac_notes, ac_country, ac_sts,ac_excel_id,ac_dt_updt,country_val.country_id, country_val.name, country_val.dial_code, country_val.code,country_val.flag');
	$this->db->from('acc_cusotmer');
$this->db->join('country_val','country_val.country_id=acc_cusotmer.ac_country','left');
	if(!empty($cond))
	$this->db->where($cond);
	$this->db->where(array('ac_sts'=>'1'));
	 $this->db->order_by('ac_id','DESC');

	$query=$this->db->get();
	//return $this->db->last_query();
	return  $query->result();
}















}