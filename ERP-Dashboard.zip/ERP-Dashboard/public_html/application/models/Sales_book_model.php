<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Sales_book_model extends CI_Model {



function vochr_prd($year=null,$cond=null,$month_cond=null,$city_list=null)
{
	$this->db->select('sbr_id,sbr_vochuer_no, sbr_customer, sbr_narration, sbr_branch, sbr_city, sbr_salesman, sbr_acc_to, sbr_storename, sbr_paymnt_type, sbr_due_date, sbr_vou_date, sbr_excel_id, sbr_sts,sbp_id, sbp_vochure_no, sbp_prd_name, sbp_prd_code, sbp_qty, sbp_rate, sbp_gross, sbp_vat, sbp_ar_name, sbp_ar_category, sbp_ar_sts');

	$this->db->from('sales_book_report');
	$this->db->join('sales_book_product','sales_book_product.sbp_id=sales_book_report.sbr_id','left');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
	$this->db->where(array('sbr_sts'=>'1'));
	
if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));
if(!empty($cond))
		$this->db->where($cond);

	if(!empty($month_cond))
		$this->db->where($month_cond);

	 $this->db->order_by('sbr_id','DESC');

	$query=$this->db->get();
	//return $this->db->last_query();
	return  $query->result();
}

function total_sales_all_years()
{
$this->db->select('SUM(sbp_gross) as total_amount,sbr_voc_year');
	$this->db->from('sales_book_report');
	
	$this->db->where(array('sbr_sts'=>'1'));
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
	$this->db->group_by('sbr_voc_year');
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();	
}

function total_sales_all_years_ksa()
{
$this->db->select('SUM(sbp_gross) as total_amount,sbr_voc_year');
	$this->db->from('sales_book_report');
	
	$this->db->where(array('sbr_sts'=>'1','sbr_city'=>'Riyadh'));
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
        $this->db->where_in('sbr_city',$city_list);
	}
	$this->db->group_by('sbr_voc_year');
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();	
}

function bar_chart_data_2018($year=null,$city_list=null,$new_cond=null)
{
$this->db->select('SUM(sbp_gross) as total_amount');
	$this->db->from('sales_book_report');
	
	$this->db->where(array('sbr_sts'=>'1','sbr_voc_year'=>'2018'));
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();	
}


function bar_chart_data_curnt_year($year,$month,$city_list=null,$new_cond=null)
{
$this->db->select('SUM(sbp_gross) as total_amount');
	$this->db->from('sales_book_report');
	
	$this->db->where(array('sbr_voc_month'=>$month,'sbr_sts'=>'1','sbr_voc_year'=>$year));
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();	
}

function bar_chart_data_prev_year($year,$month,$city_list=null,$new_cond=null)
{
$this->db->select('SUM(sbp_gross) as total_amount');
	$this->db->from('sales_book_report');

	$this->db->where(array('sbr_voc_month'=>$month,'sbr_sts'=>'1','sbr_voc_year'=>$year));
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
			$qry=$this->db->get();		
			//return $this->db->last_query();		
		return $qry->result();	
}

function country_branch()
{
	$this->db->select('sc_name,sbc_branch,sbc_id,sc_id');
	$this->db->from('sales_country');
	$this->db->join('sales_branch_country','sales_branch_country.sbc_country_id= sales_country.sc_id','left');
	$this->db->group_by('sc_id');
	$query=$this->db->get();
	//return $this->db->last_query();
	return  $query->result();
}


function country_city_sum($name_city,$year=null,$cond=null,$month_cond=null,$city_list=null)
{
 $this->db->select('SUM(sbp_gross) as total_amount,sbr_city');
	$this->db->from('sales_book_report');

	$this->db->where(array('sbr_city'=>$name_city,'sbr_sts'=>'1'));
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));
	
	if(!empty($cond))
		$this->db->where($cond);

	if(!empty($month_cond))
		$this->db->where($month_cond);
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
$this->db->order_by('total_amount','DESC');

			$qry=$this->db->get();	
		//return $this->db->last_query();			
	return $qry->result();	
}


function type_sales($type,$year=null,$cond=null,$month_cond=null,$city_list=null)
{
$this->db->select('SUM(sbp_gross) as total_amount,sbr_acc_to');
	$this->db->from('sales_book_report');

	$this->db->where(array('sbr_acc_to'=>$type,'sbr_sts'=>'1'));
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));

		if(!empty($cond))
		$this->db->where($cond);

	if(!empty($month_cond))
		$this->db->where($month_cond);
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}	
			$qry=$this->db->get();				
		return $qry->result();	
}

function all_category($year=null,$cond=null,$month_cond=null,$city_list=null,$new_cond=null)
{
	$this->db->select("COUNT(sbp_ar_category) as total_cat,SUM(sbp_gross) as total_gross_amount,sbp_ar_category");
	$this->db->from('sales_book_product');
	$this->db->join('sales_book_report','sales_book_report.sbr_id=sales_book_product.sbp_vochure_no');

	$this->db->where(array('sbp_ar_sts'=>'1'));
	
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));
	

	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}	
	
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	$this->db->group_by('sbp_ar_category');
	$this->db->order_by('total_gross_amount','DESC');

	$qry=$this->db->get();		
	//return $this->db->last_query();		
	return $qry->result();	
}


function all_prd($cat=null,$branch=null,$salesperson=null,$year=null,$cond=null,$month_cond=null,$city_list=null,$new_cond=null)
{
	$this->db->select('sbp_prd_code,sbp_prd_name,sbp_ar_category,sbp_gross,sbp_qty,sbr_branch,sbr_salesman');
	$this->db->from('sales_book_product');
	$this->db->join('sales_book_report','sales_book_report.sbr_id=sales_book_product.sbp_vochure_no');

	if(!empty($cat))
	{
	$this->db->where(array('sbp_ar_category'=>$cat,'sbr_sts'=>'1'));
	}
	if(!empty($branch))
	{
	$this->db->where(array('sbr_branch'=>$branch,'sbr_sts'=>'1'));
	}
	if(!empty($salesperson))
	{
	$this->db->where(array('sbr_salesman'=>$salesperson,'sbr_sts'=>'1'));
	}
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));

	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
	if(!empty($city_list))
	{
	$this->db->where_in('sales_book_report.sbr_city',$city_list);
	}
		

	$this->db->order_by('sbp_prd_code','DESC');
$qry=$this->db->get();		
	//return $this->db->last_query();		
	return $qry->result();	
}

function prd_cat($prd_code)
{
	$this->db->where(array('sbp_prd_code'=>$prd_code));
	
	$this->db->order_by('sbp_gross','DESC');
	$qry=$this->db->get('sales_book_product');
	//return $this->db->last_query();
	return $qry->result();
}


function slow_moving($cat,$year=null)
{
	$this->db->select('SUM(sbp_gross + sbp_vat) as total_prd_sum,sbp_prd_code,sbp_prd_name,MIN(sbp_prd_code) as code_min');
	$this->db->from('sales_book_product');
	$this->db->join('sales_book_report','sales_book_report.sbr_id=sales_book_product.sbp_vochure_no','inner');
	$this->db->where(array('sbp_ar_category'=>$cat,'sbr_sts'=>'1','sbr_voc_year'=>$year,'sbp_prd_code !='=>''));
	$this->db->group_by('sbp_prd_code');
	$this->db->having('MIN(total_prd_sum)');
	$qry=$this->db->get();
	return $qry->result();
}

function salesman_sales($year=null,$cond=null,$month_cond=null,$city_list=null,$new_cond=null)
{
	$this->db->select('SUM(sbp_gross) as total_gross_amount,sbr_salesman');
	$this->db->from('sales_book_report');
$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id','inner');

	$this->db->where(array('sbr_sts'=>'1'));
	$this->db->where_not_in('sbr_salesman', array('H.Murtaza','Showroom -','MOUHNAD'));
	
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));

	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
		
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}	
	

	$this->db->group_by('sbr_salesman');
	$this->db->order_by('total_gross_amount','DESC');
			$qry=$this->db->get();	
		//return $this->db->last_query();				
		return $qry->result();	
}

function branch_sales($year=null,$cond=null,$month_cond=null,$city_list=null)
{
	$this->db->select('SUM(sbp_gross) as total_gross_amount,sbr_branch');
	$this->db->from('sales_book_report');
$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id','inner');

	$this->db->where(array('sbr_sts'=>'1'));
	//$this->db->where(array('sbr_voc_month'=>'02'));
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));
	
	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}	
	

	$this->db->group_by('sbr_branch');
	$this->db->order_by('total_gross_amount','DESC');
			$qry=$this->db->get();				
		return $qry->result();	
}



function get_salesman_details($year,$name)
{
	$this->db->select("SUM(sbp_gross) as total_gross_amount");
	$this->db->from('sales_book_product');
	$this->db->join('sales_book_report','sales_book_report.sbr_id=sales_book_product.sbp_vochure_no');

	$this->db->where(array('sbr_sts'=>'1','sbr_voc_year'=>$year));
	$this->db->where_not_in('sbr_salesman', array('H.Murtaza','Showroom -','MOUHNAD'));
	$this->db->like('sbr_salesman', $name);
	$qry=$this->db->get();	
	//return $this->db->last_query();			
		return $qry->result();	
}

function date_time($user_id,$date_val)
{
	$sql=$this->db->query("SELECT * FROM sales_customer_entry WHERE sca_status='1' AND sca_staff_id='$user_id' AND  sca_dt_created LIKE '$date_val%'");
	//return $this->db->last_query();	
	//$this->output->enable_profiler(TRUE);
	return $sql->result();
}

function get_total_all($cr_yr=null,$fiv_yr_bck=null,$qurter_1=null,$qurter_2=null,$cond_date_range=null)
{
$this->db->select('SUM(sbp_gross) as total_amount,sbr_voc_year,COUNT(sbp_ar_category) as total_cat,sbp_ar_category');
	$this->db->from('sales_book_report');
	
	if(!empty($fiv_yr_bck) && !empty($cr_yr))
	$this->db->where(array('sbr_voc_year >='=>$fiv_yr_bck,'sbr_voc_year <='=>$cr_yr));
	if(!empty($qurter_1))
	$this->db->where(array('sbr_voc_month >='=>$qurter_1));
	if(!empty($qurter_2))
		$this->db->where(array('sbr_voc_month <='=>$qurter_2));
	if(!empty($cond_date_range))
		$this->db->where($cond_date_range);

	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
		$this->db->group_by('sbr_voc_year','sbp_ar_category');
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();
}


function get_seasons_total_category_max($cr_yr=null,$qurter_1=null,$qurter_2=null,$cond_date_range=null)
{
$this->db->select('COUNT(sbp_ar_category) as total_cat,sbp_ar_category');
	$this->db->from('sales_book_report');
	
	if(!empty($cr_yr))
	$this->db->where(array('sbr_voc_year'=>$cr_yr));
	if(!empty($qurter_1))
	$this->db->where(array('sbr_voc_month >='=>$qurter_1));
	if(!empty($qurter_2))
		$this->db->where(array('sbr_voc_month <='=>$qurter_2));
	if(!empty($cond_date_range))
		$this->db->where($cond_date_range);

	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
		$this->db->group_by('sbp_ar_category');
		$this->db->order_by('total_cat','DESC');
		$this->db->limit(1);
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();
}

function get_seasons_total_category_min($cr_yr=null,$qurter_1=null,$qurter_2=null,$cond_date_range=null)
{
$this->db->select('COUNT(sbp_ar_category) as total_cat,sbp_ar_category');
	$this->db->from('sales_book_report');
	
	if(!empty($cr_yr))
	$this->db->where(array('sbr_voc_year'=>$cr_yr));
	if(!empty($qurter_1))
	$this->db->where(array('sbr_voc_month >='=>$qurter_1));
	if(!empty($qurter_2))
		$this->db->where(array('sbr_voc_month <='=>$qurter_2));
	if(!empty($cond_date_range))
		$this->db->where($cond_date_range);

	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
		$this->db->group_by('sbp_ar_category');
		$this->db->order_by('total_cat','ASC');
		$this->db->limit(1);
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();
}





function sales_per_salesperson($year=null,$cond=null,$month_cond=null,$city_list=null,$new_cond=null)
{
	$this->db->select('sbp_prd_code,sbp_prd_name,sbp_ar_category,sbp_gross,sbp_qty,sbr_branch,sbr_salesman');
	$this->db->from('sales_book_report');
$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id','inner');

	$this->db->where(array('sbr_sts'=>'1'));
	$this->db->where_not_in('sbr_salesman', array('H.Murtaza','Showroom -','MOUHNAD'));
	
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));

	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
		
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}	
	

	//$this->db->group_by('sbr_salesman');
	//$this->db->order_by('total_gross_amount','DESC');
			$qry=$this->db->get();	
		//return $this->db->last_query();				
		return $qry->result();	
}


function cash_customer_top($cond=null)
{
$this->db->select('sbr_salesman,sbr_narration,sbr_voc_year,sbr_voc_month');
	$this->db->from('sales_book_report');
$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id','inner');

	$this->db->where(array('sbr_sts'=>'1'));
	$this->db->where_not_in('sbr_salesman', array('H.Murtaza','Showroom -','MOUHNAD'));	

	if(!empty($cond))
		$this->db->like($cond);				
	$this->db->group_by('sbr_narration');
	$qry=$this->db->get();	
	//return $this->db->last_query();				
	return $qry->result();	
}


function cash_customer_top_data($narration=null,$name)
{
$this->db->select("sum(sbp_qty) as total_qnty,sbr_narration");
	$this->db->from('sales_book_product');
	$this->db->join('sales_book_report','sales_book_report.sbr_id=sales_book_product.sbp_vochure_no');

	$this->db->where(array('sbr_sts'=>'1'));
	$this->db->where(array('sbr_salesman'=>$name));
	$this->db->where_not_in('sbr_salesman', array('H.Murtaza','Showroom -','MOUHNAD'));
	
	if(!empty($narration))
	$this->db->like('sbr_narration', $narration);
	
	$this->db->order_by('total_qnty','DESC');
	//$this->db->group_by('sbr_narration');
	$qry=$this->db->get();	
	//return $this->db->last_query();			
	return $qry->result();	
}


 function all_sprd($year=null,$cond=null,$month_cond=null,$city_list=null,$new_cond=null)
{
	$this->db->select("COUNT(sbp_prd_code) as total_prd,SUM(sbp_qty) as total_qty,sbp_prd_code");
	$this->db->from('sales_book_product');
	$this->db->join('sales_book_report','sales_book_report.sbr_id=sales_book_product.sbp_vochure_no');

	$this->db->where(array('sbp_ar_sts'=>'1'));
	
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));
	

	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}	
	
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	$this->db->group_by('sbp_prd_code');
	$this->db->order_by('total_qty','DESC');

	$qry=$this->db->get();		
	//return $this->db->last_query();		
	return $qry->result();	
}






 function all_customer($year=null,$cond=null,$month_cond=null,$city_list=null,$new_cond=null)
{
	$this->db->select("COUNT(sbr_customer) as total_customercount,SUM(sbr_customer) as total_customersum,sbr_customer");
	$this->db->from('sales_book_report');


	$this->db->where(array('sbr_sts'=>'1'));
	
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));
	

	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}	
	
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	$this->db->group_by('sbr_customer');
	$this->db->order_by('total_customercount','DESC');

	$qry=$this->db->get();		
	//return $this->db->last_query();		
	return $qry->result();	
}






function total_daily_target($currentdateday,$salesman_focus,$city_list=null,$new_cond=null)
{
$this->db->select('SUM(sbp_gross) as total_amount_day');
	$this->db->from('sales_book_report');

	$this->db->where(array('sbr_vou_date'=>$currentdateday,'sbr_salesman'=>$salesman_focus));
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
			$qry=$this->db->get();		
			//return $this->db->last_query();		
		return $qry->result();	
}
function total_weekly_target($condweekly,$salesman_focus,$city_list=null)
{
$this->db->select('SUM(sbp_gross) as total_amount_week');
	$this->db->from('sales_book_report');

	$this->db->where(array('sbr_salesman'=>$salesman_focus));
	
	$this->db->where($condweekly);
	
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
			$qry=$this->db->get();		
			//return $this->db->last_query();		
		return $qry->result();	
}

function total_monthely_target($condmonthely,$salesman_focus,$city_list=null)
{
	$this->db->select('SUM(sbp_gross) as total_amount_month');
	$this->db->from('sales_book_report');

	$this->db->where(array('sbr_salesman'=>$salesman_focus));
	
	$this->db->where($condmonthely);
	
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
			$qry=$this->db->get();		
			//return $this->db->last_query();		
		return $qry->result();	
}

function total_qouarter_target($condqouarter,$salesman_focus,$city_list=null)
{
   $this->db->select('SUM(sbp_gross) as total_amount_qouarter');
	$this->db->from('sales_book_report');


	$this->db->where(array('sbr_salesman'=>$salesman_focus));
	
	$this->db->where($condqouarter);
	
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
			$qry=$this->db->get();		
			//return $this->db->last_query();		
		return $qry->result();	
}


function bar_chart_data_curnt_year2($year,$month,$city_list=null,$new_cond=null,$salesman_focus)
{
$this->db->select('SUM(sbp_gross) as total_amount');
	$this->db->from('sales_book_report');
	
	$this->db->where(array('sbr_voc_month'=>$month,'sbr_sts'=>'1','sbr_voc_year'=>$year,'sbr_salesman'=>$salesman_focus));
if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();	
}

function bar_chart_data_prev_year2($year,$month,$city_list=null,$new_cond=null,$salesman_focus)
{
$this->db->select('SUM(sbp_gross) as total_amount');
	$this->db->from('sales_book_report');

	$this->db->where(array('sbr_voc_month'=>$month,'sbr_sts'=>'1','sbr_voc_year'=>$year,'sbr_salesman'=>$salesman_focus));

	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
			$qry=$this->db->get();		
			//return $this->db->last_query();		
		return $qry->result();	
}


function total_sales_all_years_ksa2($salesman_focus)
{
$this->db->select('SUM(sbp_gross) as total_amount,sbr_voc_year');
	$this->db->from('sales_book_report');
	
	$this->db->where(array('sbr_sts'=>'1','sbr_city'=>'Riyadh','sbr_salesman'=>$salesman_focus));

	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
        $this->db->where_in('sbr_city',$city_list);
	}
	$this->db->group_by('sbr_voc_year');
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();	
}


function total_sales_all_years2($salesman_focus)
{
$this->db->select('SUM(sbp_gross) as total_amount,sbr_voc_year');
	$this->db->from('sales_book_report');
	
	$this->db->where(array('sbr_sts'=>'1','sbr_salesman'=>$salesman_focus));
	
	
	$this->db->join('sales_book_product','sales_book_product.sbp_vochure_no=sales_book_report.sbr_id');
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}
	$this->db->group_by('sbr_voc_year');
			$qry=$this->db->get();
			//return $this->db->last_query();
		return $qry->result();	
}

function all_category2($year=null,$cond=null,$month_cond=null,$city_list=null,$new_cond=null,$salesman_focus=null)
{
	$this->db->select("COUNT(sbp_ar_category) as total_cat,SUM(sbp_gross) as total_gross_amount,sbp_ar_category");
	$this->db->from('sales_book_product');
	$this->db->join('sales_book_report','sales_book_report.sbr_id=sales_book_product.sbp_vochure_no');

	$this->db->where(array('sbp_ar_sts'=>'1'));
	
	if(!empty($year))
	$this->db->where(array('sbr_voc_year'=>$year));
	

	if(!empty($cond))
		$this->db->where($cond);
	if(!empty($month_cond))
		$this->db->where($month_cond);
			if(!empty($salesman_focus))
	$this->db->where(array('sbr_salesman'=>$salesman_focus));
	if(!empty($city_list))
	{
	$this->db->where_in('sbr_city',$city_list);
	}	
	
	if(!empty($new_cond))
	{
	$this->db->where($new_cond);
	}


	
	$this->db->group_by('sbp_ar_category');
	$this->db->order_by('total_gross_amount','DESC');

	$qry=$this->db->get();		
	//return $this->db->last_query();		
	return $qry->result();	
}



























}