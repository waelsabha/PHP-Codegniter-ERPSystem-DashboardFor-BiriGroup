<?php

defined('BASEPATH') or exit('No direct script access allowed');



        $lang['List'] = 'List ';
        $lang['List_Sales_invoice'] = 'List Sales Invoice ';

         $lang['Click_to_create'] = 'Click To Create';


         $lang['Sort_by_payment'] = 'Sort by payment';
         $lang['Paid'] = 'Paid';
         $lang['Partially_Paid'] = 'Partially Paid ';
         $lang['Not_paid'] = 'Not paid';

        $lang['Action'] = 'Action'; 
        $lang['Doc_No'] = 'DOC. No';
        $lang['Date'] = 'Date';
        $lang['Company'] = 'Company';
        $lang['Customer'] = 'Customer';
        $lang['Narration'] = 'Narration';
        $lang['Due_Amount'] = 'Due Amount';
        $lang['Total_Amount'] = 'Total Amount';
        $lang['Delivery_Status'] = 'Delivery Status';
        $lang['Status'] = 'Status';
         $lang['Not_Delivered'] = 'Not_Delivered';
        $lang['Delivered'] = 'Delivered';
        $lang['Partially_Delivered'] = 'Partially Delivered';
         $lang['Wrong_Delivered'] = 'Wrong Delivered';
         $lang['Returened_All'] = 'Returened All';
          $lang['partially_All'] = 'Partially All';
          $lang['View'] = 'View';
          $lang['Open_edit_modal'] = 'اOpen edit modal';
           $lang['Edit_Details'] = 'Edit Details';
           $lang['Delete'] = 'Delete';
           $lang['Generate_Pdf'] = 'Generate Pdf';
           $lang['Reference Details'] = 'Reference Details';
            $lang['Sales Invoice Data'] = 'Sales Invoice Data';
            $lang['Doc no'] = 'Doc no';
            $lang['User Created'] = 'User Created';
             $lang['Currency'] = 'Currency';
             $lang['Vat Type'] = 'Vat Type';
              $lang['Taxable'] = 'Taxable'; 
              $lang['Non-Taxable'] = 'Non-Taxable'; 
               $lang['Linked to'] = 'Linked to'; 
               $lang['Sales Account'] = 'Sales Account';
               $lang['LPO No'] = 'LPO No';
               $lang['Price Level'] = 'Price Level'; 
               $lang['Salesman'] = 'Salesman'; 
                $lang['Payment Type'] = 'Payment Type'; 
                $lang['Place of Supply'] = 'Place of Supply';
                 $lang['Jurisdiction'] = 'Jurisdiction'; 
                 $lang['Contact'] = 'Contact'; 
                 $lang['Delivery Address'] = 'Delivery Address';
                 $lang['Mark'] = 'Mark';
                 $lang['Ship Contact'] = 'Ship Contact';
                 $lang['Country'] = 'Country';
                $lang['Current Status'] = 'Current Status';
                $lang['Attachements'] = 'Attachements';
                 $lang['Warehouse'] = 'Warehouse';
                 $lang['Product'] = 'Product';
                  $lang['Quantity'] = 'Quantity';
                   $lang['Rate'] = 'Rate';
                    $lang['Gross'] = 'Gross';
                    $lang['Discount'] = 'Discount';
                    $lang['Discount Amount'] = 'Discount Amount';
                    $lang['Add.Charges'] = 'Add.Charges';
                    $lang['Fnet'] = 'Fnet';
                    $lang['Vat'] = 'Vat';
                    $lang['Delivery Date'] = 'Delivery Date';
                    $lang['Remark'] = 'Remark';
                    $lang['Tax Code'] = 'Tax Code';
                    $lang['Total Quantity'] = 'Total Quantity';
                    $lang['Total Rate'] = 'Total Rate';
                    $lang['Total Gross'] = 'Total Gross';
                    $lang['Total Discount'] = 'Total Gross';
                   $lang['Total Discount Amount'] = 'Total Discount Amount';
                   $lang['Total Additional Charges'] = 'Total Additional Charges';
                   $lang['Total Fnet'] = 'Total Fnet';
                    $lang['Total VAT Amount'] = 'Total VAT Amount';
                    $lang['Final Amount'] = 'Final Amount';
                    $lang['Are you sure, you want to delete this payment details permanently?'] = 'Are you sure, you want to delete this payment details permanently?';
                    $lang['This action cannot be undone?'] = 'This action cannot be undone';
                    $lang['Are You Sure?'] = 'Are You Sure?';
                     $lang['Are You check the Price With Focus?'] = 'Are You check the Price With Focus?';
                      $lang['this is Secondary Check For Product Price Between Focus And Dashboard'] = 'this is Secondary Check For Product Price Between Focus And Dashboard';
                    
                    $lang['Confirm'] = 'Confirm ';
                     $lang['Cancel'] = 'Cancel';

                      $lang['Generate PDF'] = 'Generate PDF';
                      $lang['Choose option to print Invoice as'] = 'Choose option to print Invoice as';
                      $lang['With Letter-head'] = 'With Letter-head';
                      $lang['Without Letter-head'] = 'Without Letter-head';
                     
                   $lang['Description'] = 'Description';
                   $lang['Assets_name'] = 'Assets_name';
                   $lang['sub_from'] = 'sub_from';
                    $lang['Assets_parent'] = 'Assets_parent';
                     $lang['Belong_To'] = 'Belong_To';
                     $lang['Serial_number'] = 'Serial_number';
                     $lang['final_custody_date'] = 'final_custody_date';
                     $lang['availiabilaty'] = 'availiabilaty';
                     $lang['condition_statue'] = 'condition_statue';        
                           $lang['Not_Avialable'] = 'Not_Avialable ';
                        
                         $lang['Avialable'] = '  Avialable';
                     $lang['Custody'] = '  Custody';
                      $lang['Employee Custody'] = 'Employee Custody';
                       $lang['add cutody to employee'] = 'add cutody to employee';
$lang['Employee'] = 'Employee';

$lang['custody name and serial'] = 'custody name and serial';
$lang['custody name'] = 'custody name';
$lang['custody type'] = 'custody type';
$lang['custody parent'] = 'custody parent';
$lang['custody condition'] = 'custody condition';
$lang['previous custody'] = 'previous custody';




   
                     
   $lang['New_assets'] = 'New assets';
     $lang['assets']='assets';
          $lang['Create Assets Item']='Create Assets Item';
    $lang['asset_name']='Asset Name';

 $lang['description']='description Name';

    $lang['serial_number'] = 'serial_number';
	   $lang['Conditional_statue'] = 'Conditional statue';

                      $lang['Transactions'] = 'Transactions';
                        $lang['Sales'] = 'Sales';
                          $lang['Issue Sales Invoice'] = 'Issue Sales Invoice ';
                            $lang['Fileds marked as'] = 'Fileds marked as ::*:: are required fields';

     $lang['Doc No'] = 'Doc No';
$lang['Customer'] = 'Customer';
$lang['Choose'] = 'Choose';
$lang['LPO Number'] = 'LPO Number';
  $lang['Project'] = 'Project';                    
$lang['Customer Contact'] = 'Customer Contact'; 
 $lang['Country/City'] = 'Country/City '; 
$lang['Shipping Mark'] = 'Shipping Mark'; 
$lang['Delivery Contact'] = 'Delivery Contact'; 
$lang['Customer Vat number'] = 'Customer Vat number'; 

  $lang['Currency Name'] = 'Currency Name ';
       
  $lang['Currenct Conv'] = 'Currenct Conv';
                   
  $lang['Taxable Invoice'] = 'Taxable Invoice';
                    
      $lang['Non-Taxable Invoice'] = 'Non-Taxable Invoice';                
                    
        $lang['Upload files here.Make sure the file size is less than 2MB'] = 'Upload files here.Make sure the file size is less than 2MB';

                   
$lang['FILES UPLOADED'] = 'FILES UPLOADED';
 $lang['Image'] = 'Image';                 
                    
$lang['Item'] = 'Item';
                
 $lang['Total Number of items'] = 'Total Number of items';         
$lang['Total Discount Percentage'] = 'Total Discount Percentage';


$lang['Total VAT Charges'] = 'Total VAT Charges';


$lang['Click to see total amount'] = 'Click to see total amount';
 
 $lang['Amount as per the currency rate selected'] = 'Amount as per the currency rate selected';
 
$lang['References'] = 'References';

$lang['Save Edit'] = 'Save Edit';

$lang['Pop-up Invoice'] = 'Pop-up Invoice';

$lang['Reset'] = 'Reset';
$lang['Save'] = 'Save';
$lang['Add More'] = 'Add More';
$lang['Amount Total'] = 'Amount Total';

$lang['Add as new reference'] = 'Add as new reference';

$lang['Reference'] = 'Reference';
$lang['Bill Amount'] = 'Bill Amount';
$lang['Amount Adjusted'] = 'Amount Adjusted';
$lang['Pick Amount'] = 'Pick Amount';

$lang['Reset Fields'] = 'Reset Fields';
$lang['Amount to adjust'] = 'Amount to adjust';
$lang['Amount adjusted'] = 'Amount adjusted';

 $lang['List_assets'] = 'List Of Assets'; 

      ?>