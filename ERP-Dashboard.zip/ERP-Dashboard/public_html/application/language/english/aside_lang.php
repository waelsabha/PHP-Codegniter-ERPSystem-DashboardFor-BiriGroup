<?php

defined('BASEPATH') or exit('No direct script access allowed');

//company master
 $lang['Navigation'] = 'Navigation';
$lang['Company'] = 'Company';
 $lang['Backup'] = 'Backup';
 $lang['Setting'] = 'Setting';
$lang['Masters'] = 'Masters';
 $lang['Security'] = 'Security';
$lang['Costing'] = 'Costing';

 $lang['Account_Tree_Master'] = 'Account_Tree_Master';

 $lang['Position_management'] = 'Position_management'; 

 $lang['Product_tree'] = 'Product_tree';
$lang['Company'] = 'Company';
 $lang['Task Scheduler'] = 'Task Scheduler';
$lang['Terms of Contract'] = 'Terms of Contract';
$lang['Shopify_test_price_uae'] = 'Shopify_test_price_uae';

$lang['Create Groups'] = 'Create Groups';

$lang['Set Group Pricing'] = 'Set Group Pricing';

$lang['Product Pricing UK'] = 'Product Pricing UK';

 $lang['Account Tree Master'] = 'Account Tree Master ';

 $lang['Position Management'] = 'Position Management';

 $lang['Positions Manager'] = 'Positions Manager';

 $lang['Salary Structure'] = 'Salary Structure';

 $lang['Job Offer Requests'] = 'Job Offer Requests';

 $lang['Product Tree'] = 'Product Tree';

  $lang['Product Tree Master'] = 'Product Tree Master';

  $lang['Add Products'] = 'Add Products';
$lang['Product List'] = 'Product List';
  $lang['Upload Product Extra Details Excel Sheet'] = 'Upload Product Extra Details Excel Sheet';
  $lang['Upload Product Excel Sheet'] = 'Upload Product Excel Sheet';
 $lang['Category'] = 'Category';
  $lang['Brands'] = 'Brands';
 $lang['Units'] = 'Units';

$lang['Variations'] = 'Variations';
$lang['HS Codes'] = 'HS Codes';
$lang['UAE & KSA Percentages'] = 'UAE & KSA Percentages';
$lang['Currency Conv.'] = 'Currency Conv.';
$lang['Warehouse'] = 'Warehouse';
$lang['Place of Supply'] = 'Place of Supply';

$lang['Pricelevel'] = 'Pricelevel';
$lang['Projects'] = 'Projects';
$lang['Salesman'] = 'Salesman';
$lang['Department'] = 'Department';
$lang['Payment Method'] = 'Payment Method';
$lang['Company Assets'] = 'Company Assets';
$lang['Vehicle Assets'] = 'Vehicle Assets';
$lang['Tools Assets'] = 'Tools Assets';


$lang['Fixed Asset Tree Master'] = 'Fixed Asset Tree Master';

$lang['Region'] = 'Region';
$lang['Port of load/dock'] = 'Port of load/dock';

$lang['Bin'] = 'Bin';
$lang['Google Calender'] = 'Google Calender';


//transaction 
 $lang['Transactions'] = 'Transactions';
 $lang['Sales'] = 'Sales';

 $lang['Cash & Bank'] = 'Cash & Bank';
 $lang['Receipt'] = 'Receipt ';
 $lang['Payments'] = 'Payments';
 $lang['Petty Cash'] = 'Petty Cash';
 $lang['Post-Dated Cheque Receipts'] = 'Post-Dated Cheque Receipts';
 $lang['Post-Dated Cheque Payments'] = 'Post-Dated Cheque Payments';
 $lang['Cheque-Follow-Up'] = 'Cheque-Follow-Up';
 $lang['Purchases'] = 'Purchases';
 $lang['Production Order'] = 'Production Order';
 $lang['Add Production Order'] = 'Add Production Order';
 $lang['List Production Order'] = 'List Production Order';
 $lang['Check production status'] = 'Check production status';
 $lang['Item Request'] = 'Item Request';
 $lang['Create Item Request'] = 'Create Item Request';

$lang['Create Item Request KSA'] = 'Create Item Request KSA';
$lang['Create Item Request UK'] = 'Create Item Request UK';
$lang['Create Item Request CA'] = 'Create Item Request CA';
$lang['List Item Request'] = 'List Item Request';
$lang['List All Item Request'] = 'List Item Request UAE';
$lang['List All Item Request ksa'] = 'List Item Request KSA';
$lang['List All Item Request uk'] = 'List Item Request UK';
$lang['List All Item Request ca'] = 'List Item Request CA';
$lang['List Completed Item Request'] = 'List Completed Item Request';
$lang['List Rejected Item Request'] = 'List Rejected Item Request';


$lang['Generate Shipment'] = 'Generate Shipment';
$lang['Request for Quotation'] = 'Request for Quotation';
$lang['List Generate Shipment'] = 'List Generate Shipment';
$lang['Purchase Order'] = 'Purchase Order';
$lang['Material Receipt Note'] = 'Material Receipt Note';
$lang['Purchase Invoice'] = 'Purchase Invoice';
$lang['Purchase Return'] = 'Purchase Return';
$lang['Product Costing&Details'] = 'Product Costing&Details';





        $lang['Sales_Invoice'] = 'Sales_Invoice'; 
        $lang['UAE_Sales_Invoice'] = 'UAE_Sales_Invoice'; 
        $lang['KSA_Sales_Invoice'] = 'KSA_Sales_Invoice'; 
        $lang['Dragon_Sales_Invoice'] = 'Dragon_Sales_Invoice'; 
        $lang['Export_Sales_Invoice'] = 'Export_Sales_Invoice'; 
        $lang['UK_Sales_Invoice'] = 'UK_Sales_Invoice';

        $lang['Sales_Invoice_online_shop'] = 'Online_Sales_Invoice';
           $lang['UAE_Sales_Invoice_Online'] = 'UAE_Invoice_Online';
       $lang['KSA_Sales_Invoice_Online'] = ' KSA_Invoice_Online';
       $lang['UK_Sales_Invoice_Online'] = 'UK_Invoice_Online';
       $lang['Amazon_Sales_Invoice'] = 'Amazon_Sales_Invoice';

	   $lang['Incoming_Orders'] = 'Online_Incoming_Orders';

	      $lang['List_Incoming_Orders-UAE'] = 'Incoming_Orders-UAE';
		  $lang['List_Incoming_Orders-KSA'] = 'Incoming_Orders-KSA';
		  $lang['List_Incoming_Orders-UK'] = 'Incoming_Orders-UK';
		  $lang['List_Incoming_Orders-Canada'] = 'Incoming_Orders-Canada';
            $lang['List_Incoming_Orders-Amazon'] = 'Incoming_Orders-Amazon-UK';
            $lang['List_Incoming_Orders-Amazon-UAE'] = 'Incoming_Orders-Amazon_UK-uae';
		     $lang['Import_Amazon_Orders_UK'] = 'Import_Amazon_Orders_UK';
       $lang['Import_Amazon_Orders_UAE'] = 'Import_Amazon_Orders_UAE';
	   $lang['Import_Amazon'] = 'Import_Amazon';
       $lang['Update_amazon_Payment'] = 'Update_amazon_Payment';
     

         $lang['UAE Amazon-Sales Invoice'] = 'UAE Amazon-Sales Invoice';

          $lang['KSA Amazon-Sales Invoice'] = 'KSA Amazon-Sales Invoice'; 

  $lang['UK Amazon-Sales Invoice'] = 'UK Amazon-Sales Invoice'; 
         


        $lang['Sales_Quotaion'] = 'Sales_Quotaion';



         $lang['Create Quotation'] = 'Create Quotation';
          $lang['Quotation - Lists'] = 'Quotation - Lists';
           $lang['List Quotation'] = 'List Quotation';
            $lang['List Quotation-RTA Sharjah'] = 'List Quotation-RTA Sharjah';
             $lang['List Quotation-PWRak'] = 'List Quotation-PWRak';
              $lang['List Porforma Invoice'] = 'List Porforma Invoice';
               $lang['Signs - Price Calculation'] = 'Signs - Price Calculation';
                $lang['Add stamp & Signature'] = 'Add stamp & Signature';
                 $lang['Update Product Stock'] = 'Update Product Stock';
                   $lang['List Stock'] = 'List Stock';
                    $lang['Item Price Check'] = 'Item Price Check';
                     $lang['UAE-Delivery Note'] = 'UAE-Delivery Note';
                      $lang['KSA-Delivery Note'] = 'KSA-Delivery Note';
                       $lang['Dragon-Delivery Note'] = 'Dragon-Delivery Note';
                 $lang['Export-Delivery Note'] = 'Export-Delivery Note';
                 $lang['Amazon-UK-Delivery Note'] = 'Amazon-UK-Delivery Note';
                   $lang['Price List Amazon (UK)'] = 'Price List Amazon (UK)';
                   $lang['Check New Price'] = 'Check New Price';
                   
                   $lang['Sales Return'] = 'Sales Return';
                    $lang['Delivery Note'] = 'Delivery Note ';
                      $lang['Stock Adjustments -'] = 'Stock Adjustments -';
                       $lang['Stock Adjustments +'] = 'Stock Adjustments +';

 $lang['Stock Transfers'] = 'Stock Transfers';
  $lang['Opening Stocks'] = 'Opening Stocks';
   $lang['Current Stock'] = 'Current Stock';
    $lang['Low Inventories'] = 'Low Inventories';
     $lang['Stock delivery report'] = 'Stock delivery report';

      $lang['UAE Stock delivery report'] = 'UAE Stock delivery report';
      $lang['KSA Stock delivery report'] = 'KSA Stock delivery report';  
        
        
        
   
        
        $lang['Item_Price_Check'] = 'Item_Price_Check';
        $lang['Delivery_Note'] = 'Delivery_Note';
        $lang['Sales_Return'] = 'Sales_Return';
         $lang['Journals'] = 'Journals';
        $lang['Stocks'] = 'Stocks';

$lang['Dragon Stock delivery report'] = 'Dragon Stock delivery report';
$lang['Export Stock delivery report'] = 'Export Stock delivery report';
$lang['Stock wharehouse yearly'] = 'Stock wharehouse yearly';
$lang['Update Product Suggestion Stock'] = 'Update Product Suggestion Stock';
         
          $lang['Sales Quotation'] = 'Sales Quotation'; 
             
               

////////////////////////////
//finacial accounting

$lang['Financial Accounting'] = 'Financial Accounting';
$lang['Sub-Ledger'] = 'Sub-Ledger';
$lang['manage-assets'] = 'Manage Assets';




//////////////////////////////
////Account Reports

 $lang['Accounts Reports'] = 'Accounts Reports';
  $lang['Dashboard'] = 'Dashboard';
   $lang['Reports'] = 'Reports';
    $lang['Accounts Operations Report'] = 'Accounts Operations Report';
     $lang['Graphical data'] = 'Graphical data';
      $lang['Fund Transfer'] = 'Fund Transfer';
       $lang['Approve Transfers Now'] = 'Approve Transfers Now';

//////////////////
/////Sales Book 


$lang['Sales Book'] = 'Sales Book';

$lang['Sales Book Excel upload'] = 'Sales Book Excel upload';

$lang['Total Sales Book'] = 'Total Sales Book';
$lang['Country Wise Sales'] = 'Country Wise Sales';
$lang['Season Sales'] = 'Season Sales';


///////////////////
/////Purchase Book 

$lang['Purchase Book'] = 'Purchase Book';
$lang['Purchase Book Excel upload'] = 'Purchase Book Excel upload';
$lang['Total Purchase Book'] = 'Total Purchase Book';




////////////////////////
////marketing Reports

 $lang['Marketing Reports'] = 'Marketing Reports';
  $lang['Dashboard'] = 'Dashboard';
   $lang['VISITORS FORM'] = 'VISITORS FORM';
    $lang['Gulf Trading Visitors Form'] = 'Gulf Trading Visitors Form';
     $lang['List Visitors'] = 'List Visitors';

//////////////////
///User management     

$lang['User Managment'] = 'User Managment';
$lang['Add Users'] = 'Add Users';
$lang['List Users'] = 'List Users';

///////////////
///Fund Transfer

 $lang['Fund Transfer'] = 'Fund Transfer';
  $lang['Transfer Funds'] = 'Transfer Funds';
   $lang['List Transfers'] = 'List Transfers';






/////////////////
//sales master  

 $lang['Sales Master'] = 'Sales Master';
  $lang['Add Customer Details'] = 'Add Customer Details';
   $lang['List Customer Details'] = 'List Customer Details';
    $lang['Excel upload Customer Details'] = 'Excel upload Customer Details';
     $lang['Add Sales Target'] = 'Add Sales Target';
      $lang['List Sales Target'] = 'List Sales Target';

////////////File Manager/////////////

      $lang['File Manager'] = 'File Manager';
      $lang['Add Files'] = 'Add Files';




/////////HR Management/////////

$lang['HR Management'] = 'HR Management';
$lang['Add Employee To Tree'] = 'Add Employee To Tree';
$lang['List Employee Tree'] = 'List Employee Tree';
$lang['List Jobs Applied'] = 'List Jobs Applied';
$lang['Hiring'] = 'Hiring';
$lang['Add Jobs'] = 'Add Jobs';
$lang['List Jobs'] = 'List Jobs';
$lang['Job Offer'] = 'Job Offer';
$lang['Add Leave'] = 'Add Leave';
$lang['List Leave'] = 'List Leave';
$lang['List employee request'] = 'List employee request';
$lang['List User Files'] = 'List User Files ';
$lang['Leave_system'] = 'Leave system ';

$lang['Employee Custody'] = 'Employee Custody';
 ///////////Email marketing customers Management///

$lang['Email marketing customers Management'] = 'Email marketing customers Management';

$lang['Customer excel upload'] = 'Customer excel upload';

$lang['List Customer'] = 'List Customer';

///Inventory Management///////////

$lang['Inventory Management'] = 'Inventory Management';
$lang['Excel upload warehouse details'] = 'Excel upload warehouse details';
$lang['List Inventory data'] = 'List Inventory data';


////////////Invoice Data


$lang['Invoice Data'] = 'Invoice Data';
$lang['Upload Receipt Register Excel'] = 'Upload Receipt Register Excel';
$lang['Upload Complete Sales Report Excel'] = 'Upload Complete Sales Report Excel';
$lang['Compare Sales Report Vs. Receipt'] = 'Compare Sales Report Vs. Receipt';








/////////////Survey Module///////////


$lang['Survey Module'] = 'Survey Module';

$lang['Create Survey'] = 'Create Survey';
$lang['List Survey'] = 'List Survey';
$lang['List Installation'] = 'List Installation';
$lang['Create Single Installation'] = 'Create Single Installation';
$lang['List Single Installation'] = 'List Single Installation';
$lang['Accounts Survey Module'] = 'Accounts Survey Module';
$lang['Survey BOM'] = 'Survey BOM';

$lang['Create Customer Pricing'] = 'Create Customer Pricing';









///////////////Manage Profile///////////////////////

$lang['Manage Profile'] = 'Manage Profile';
$lang['List all tickets'] = 'List all tickets';


//////////////

/////Check Your Tasks


$lang['Check Your Tasks'] = 'Check Your Tasks';

$lang['List of Tasks'] = 'List of Tasks';





      ?>