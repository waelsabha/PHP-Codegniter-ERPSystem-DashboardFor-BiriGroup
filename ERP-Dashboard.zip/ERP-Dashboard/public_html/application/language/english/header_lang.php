<?php

defined('BASEPATH') or exit('No direct script access allowed');


        // title
        $lang['text_title_header'] = 'Welcome ';
         $lang['text_name_Admin'] = 'Biri Group Admin';
        $lang['text_name_staff'] = 'Biri Group Staff';
 
         $lang['text_en'] = 'English';
         $lang['text_ar'] = 'Arabic ';





        // Main Menu
        $lang['text_logout'] = 'logout';
        $lang['text_menu_demo_header'] = 'Live Demo'; 
        $lang['text_menu_tutorials_header'] = 'Tutorials';
        $lang['text_menu_contact_header'] = 'Contact';
      ?>