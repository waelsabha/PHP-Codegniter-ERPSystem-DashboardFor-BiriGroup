<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
 * Language: English
 * Module: Billers
 *
 * Last edited:
 * 30th April 2015
 *
 * Package:
 * Stock Manage Advance v3.0
 *
 * You can translate this file to your language.
 * For instruction on new language setup, please visit the documentations.
 * You also can share your language files by emailing to saleem@tecdiary.com
 * Thank you
 */

$lang['PRODUCTION ORDER']                   =  'PRODUCTION ORDER';
$lang['NEW ORDERS']                  = 'NEW ORDERS';
$lang['ACCEPTED ORDERS']                = 'ACCEPTED ORDERS';
$lang['ON PRODUCTION']               = 'ON PRODUCTION';
$lang['READY FOR DELIVERY']                 = 'READY FOR DELIVERY';
$lang['DELIVERED']               = 'DELIVERED';
$lang['REJECTED ORDERS']               = 'REJECTED ORDERS';
$lang['Dashboard']              = 'dashboard';

$lang['Pending']               = 'Pending';
$lang['approve now']              = 'approve now';
$lang['Approved']			      = 'Approved';
$lang['Special Customer request:']			      = 'Special Customer request:';
$lang['Download attachments:']			      = 'Download attachments:';
$lang['Special Request']			      = 'Special Request';
$lang['Remarks']			      = 'Remarks';
$lang['Is expected delivery same as delivery date?']= 'Is expected delivery same as delivery date?';
$lang['Extended Delivery Date']	      = 'Extended Delivery Date';


$lang['Sales Person']			      = 'Sales Person';
$lang['Delivery Date']			      = 'Delivery Date';
$lang['Last date of delivery'] = 'Last date of delivery';
$lang['Delivery Location'] = 'Delivery Location';
$lang['Product Name']			      = 'Product Name';
$lang['Quantity']			      = 'Quantity';
$lang['Weight']			      = 'Weight';
$lang['Status']			      = 'Status';
$lang['Attachments']		= 'Attachments';
$lang['Action']			      = 'Action';

?>