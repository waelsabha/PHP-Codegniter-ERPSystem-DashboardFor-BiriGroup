<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
 * Language: English
 * Module: Billers
 *
 * Last edited:
 * 30th April 2015
 *
 * Package:
 * Stock Manage Advance v3.0
 *
 * You can translate this file to your language.
 * For instruction on new language setup, please visit the documentations.
 * You also can share your language files by emailing to saleem@tecdiary.com
 * Thank you
 */

$lang['PRODUCTION ORDER']                   =  'طلب تصنيع ';
$lang['NEW ORDERS']                  = 'طلب جديد';
$lang['ACCEPTED ORDERS']                = 'الطلبات المقبولة';
$lang['ON PRODUCTION']               = 'قيد التصنيع';
$lang['READY FOR DELIVERY']                 = 'الطلبات الجاهزة  للشحن';
$lang['DELIVERED']               = 'الطلبات المشحونة ';
$lang['REJECTED ORDERS']               = 'الطلبات المرفوضة';
$lang['Dashboard']              = 'لوحة التحكم';

$lang['Pending']               = 'معلق';
$lang['approve now']              = 'اضغط للموافقة';
$lang['Approved']			      = 'تمت الموافقة ';
$lang['Special Customer request:']			      = 'متطلبات خاصة';
$lang['Download attachments:']			      = 'تحميل المرفقات';
$lang['Special Request']			      = 'متطلبات خاصة';
$lang['Remarks']			      = 'ملاحظات';
$lang['Is expected delivery same as delivery date?']= 'هل سيتم الشحن بنفس التاريخ المحدد في الطلب؟';
$lang['Extended Delivery Date']	      = 'التاريخ النهائي للشحن';


$lang['Sales Person']			      = 'مسؤول المبيعات';
$lang['Delivery Date']			      = 'تاريخ الشحن';
$lang['Last date of delivery']			      = 'اخر موعد للشحن';
$lang['Delivery Location']			      = 'الشحن إلى';
$lang['Product Name']			      = 'اسم المنتج';
$lang['Quantity']			      = 'الكمية';
$lang['Weight']			      = 'الوزن';
$lang['Status']			      = 'الحالة';
$lang['Attachments']			      = 'المرفقات';
$lang['Action']			      = 'الإجراء';

?>