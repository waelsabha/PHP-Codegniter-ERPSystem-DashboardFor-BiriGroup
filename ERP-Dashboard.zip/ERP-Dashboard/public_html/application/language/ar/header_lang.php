<?php

defined('BASEPATH') or exit('No direct script access allowed');

  // title
        $lang['text_title_header'] = 'مرحبا   ';
         $lang['text_name_Admin'] = 'قسم الادمن  ';
        $lang['text_name_staff'] = 'فريق عمل بيري ';
 
        // Main Menu
        $lang['text_logout'] = 'تسجيل الخروج  ';

         $lang['text_en'] = 'الانكليزية  ';
         $lang['text_ar'] = 'العربية  ';
    ?>