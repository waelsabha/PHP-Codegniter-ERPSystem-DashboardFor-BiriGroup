<?php

defined('BASEPATH') or exit('No direct script access allowed');

//company master
 $lang['Navigation'] = 'خريطة الموقع   ';
$lang['Company'] = 'قسم ادارة الشركة  ';
 $lang['Backup'] = 'نسخة احتياطية';
 $lang['Setting'] = 'الاعدادات  ';
$lang['Masters'] = 'الرئيسية ';
 $lang['Security'] = 'الحماية ';
         $lang['Costing'] = 'تسعير المنتجات ';

 $lang['Account_Tree_Master'] = 'شجرة الحسابات ';

 $lang['Position_management'] = 'ادارة المناصب  '; 

 $lang['Product_tree'] = 'شجرة المنتجات  ';
$lang['Company'] = 'الشركة ';
 $lang['Task Scheduler'] = 'منظم المهام  ';
 $lang['Terms of Contract'] = 'الشروط والعقود ';


$lang['Create Groups'] = 'انشاء مجموعات  ';

$lang['Set Group Pricing'] = 'وضع تسعير للمجموعات  ';

$lang['Product Pricing UK'] = ' UK  تسعير المنتجات  ';

 $lang['Account Tree Master'] = 'شجرة الحسابات  الرئيسية  ';

 $lang['Position Management'] = 'ادارة المناصب الوظيفية ';

 $lang['Positions Manager'] = 'ادارة المناصب  ';

 $lang['Salary Structure'] = ' تفصيل الراتب ';

 $lang['Job Offer Requests'] = 'طلب  عرض العمل  ';

 $lang['Product Tree'] = 'شجرة المنتجات';

  $lang['Product Tree Master'] = 'شجرة المنتجات الرئيسية   ';

  $lang['Add Products'] = ' اضافة  المنتجات  ';
$lang['Product List'] = 'لائحة المنتجات  ';
  $lang['Upload Product Extra Details Excel Sheet'] = 'رفع  تفاصيل المنتجات  اكسل  ';
  $lang['Upload Product Excel Sheet'] = 'Excel  رفع جدول المنتجات  ';
 $lang['Category'] = 'الاصناف ';
  $lang['Brands'] = 'العلامات التجارية   ';
 $lang['Units'] = 'الواحدات   ';

$lang['Variations'] = 'منظم المهام  ';
$lang['HS Codes'] = 'مHS Codes ';
$lang['UAE & KSA Percentages'] = 'UAE&KSA ضبط النسب في  ';
$lang['Currency Conv.'] = 'تحويل العملة  ';
$lang['Warehouse'] = 'المستودع  ';
$lang['Place of Supply'] = 'مكان التزويد  ';

$lang['Pricelevel'] = 'مستويات السعر  ';
$lang['Projects'] = 'المشاريع';
$lang['Salesman'] = 'مندوب المبيعات';
$lang['Department'] = 'الاقسام';
$lang['Payment Method'] = 'طريقة الدفع';
$lang['Company Assets'] = 'اصول الشركة';

$lang['Vehicle Assets'] = 'اصول المركبات';
$lang['Tools Assets'] = 'اصول الادوات';

$lang['Fixed Asset Tree Master'] = 'شجرة الاصول الثابتة الرئيسية  ';

$lang['Region'] = 'المنطقة  ';
$lang['Port of load/dock'] = 'ميناء التحميل  ';

$lang['Bin'] = 'Bin';
$lang['Google Calender'] = 'جدولة غوغل  ';



//transaction 
 $lang['Transactions'] = 'المعاملات المالية  ';
 $lang['Sales'] = 'المبيعات  ';

 $lang['Cash & Bank'] = 'النقد والبنوك  ';
 $lang['Receipt'] = 'ايصال الدفع  ';
 $lang['Payments'] = 'المدفوعات  ';
 $lang['Petty Cash'] = 'المبالغ الصغيرة ';
 $lang['Post-Dated Cheque Receipts'] = 'إيصالات الشيكات المؤجلة';
 $lang['Post-Dated Cheque Payments'] = 'مدفوعات الشيكات المؤجلة';
 $lang['Cheque-Follow-Up'] = 'متابعة الشيكات   ';
 $lang['Purchases'] = 'المشتريات  ';
 $lang['Production Order'] = ' طلبات الانتاج  ';
 $lang['Add Production Order'] = 'اضافة طلبية انتاج ';
 $lang['List Production Order'] = 'لائحة طلبيات الانتاج ';
 $lang['Check production status'] = 'التأكد من حالة الانتاج ';
 $lang['Item Request'] = 'طلب  منتج معين ';
 $lang['Create Item Request'] = 'انشاء طلب منتج معين ';

$lang['Create Item Request KSA'] = 'انشاء طلب منتج للسعودية  ';
$lang['Create Item Request UK'] = 'انشاء طلب منتج مملكة متحدة  ';
$lang['Create Item Request CA'] = 'انشاء طلب منتج كندا  ';
$lang['List Item Request'] = 'لائحة طلبات المنتجات   ';
$lang['List All Item Request'] = ' لائحة طلبات الامارات  ';
$lang['List All Item Request ksa'] = 'لائحة طلبات السعودية';
$lang['List All Item Request uk'] = 'لائحة طلبات الملكة المتحدة';
$lang['List All Item Request ca'] = 'لائحة طلبات كندا';

$lang['List Completed Item Request'] = 'لائحة الطلبات المكتملة  ';
$lang['List Rejected Item Request'] = 'لائحة الطلبات المرفوضة  ';


$lang['Generate Shipment'] = 'اتوليد شحنة جديدة  ';
$lang['Request for Quotation'] = ' طلب  عرض سعر  ';
$lang['List Generate Shipment'] = 'لائحة توليد الشحنات   ';
$lang['Purchase Order'] = 'طلب شراء   ';
$lang['Material Receipt Note'] = 'مذكرة استلام المواد ';
$lang['Purchase Invoice'] = 'فاتورة الشراء  ';
$lang['Purchase Return'] = 'مرتجع الشراء ';
$lang['Product Costing&Details'] = 'تفاصيل تكلفة المنتج ';





        $lang['Sales_Invoice'] = 'فاتورة المبيعات  '; 
        $lang['UAE_Sales_Invoice'] = 'فاتورة المبيعات في الامارات '; 
        $lang['KSA_Sales_Invoice'] = 'مبيعات السعودية  '; 
        $lang['Dragon_Sales_Invoice'] = 'مبيعات دراغون '; 
        $lang['Export_Sales_Invoice'] = 'مبيعات التصدير '; 
        $lang['UK_Sales_Invoice'] = 'UK مبيعات  ';


         $lang['Sales_Invoice_online_shop'] = 'مبيعات المتاجرالالكترونية ';
          $lang['UAE_Sales_Invoice_Online'] = 'مبيعات متجر UAE ';
       $lang['KSA_Sales_Invoice_Online'] = ' مبيعات متجر KSA ';
       $lang['UK_Sales_Invoice_Online'] = 'مبيعات متجرUK';

 $lang['Amazon_Sales_Invoice'] = 'مبيعات امازون';
         $lang['UAE Amazon-Sales Invoice'] = 'فاتورة  شراء  امازون امارات  ';

          $lang['KSA Amazon-Sales Invoice'] = 'فاتورة شراء امازون السعودية  '; 

 $lang['UK Amazon-Sales Invoice'] = 'فاتورة شراء امازون المملكة المتحدة'; 
        $lang['Sales_Quotaion'] = 'عروض الاسعار  ';
$lang['Incoming_Orders'] = 'الفواتير القادمة من المواقع';
	      $lang['List_Incoming_Orders'] = 'لائحة الفواتير المستوردة ';
		     $lang['Import_Amazon_Orders'] = 'استيراد الطلبات من امازون';
$lang['Update_amazon_Payment'] = 'تحديث مبيعات امازون';
     $lang['Import_Amazon_Orders_UK'] = 'استيراد الطلبات من امازون الUK ';
       $lang['Import_Amazon_Orders_UAE'] = 'استيراد الطلبات من امازون الامارات';
 $lang['Import_Amazon'] = 'استيراد من امازون';
         $lang['Create Quotation'] = 'انشاء  عرض سعر ';
          $lang['Quotation - Lists'] = 'لائحة عروض الاسعار ';
           $lang['List Quotation'] = 'لائحة عروض الاسعار ';
            $lang['List Quotation-RTA Sharjah'] = 'لائحة عروض الاسعار الشارقة ';
             $lang['List Quotation-PWRak'] = 'عروض اسعار رأس الخيمة ';
              $lang['List Porforma Invoice'] = 'لائحة الفاتورة الاولية  ';
               $lang['Signs - Price Calculation'] = 'حساب سعر الافتات ';
                $lang['Add stamp & Signature'] = 'اضافة توقيع او ختم ';
                 $lang['Update Product Stock'] = 'تحديث مخزون  المنتجات  ';
                   $lang['List Stock'] = 'لائحة المخزون  ';
                    $lang['Item Price Check'] = 'التحقق من سعر المنتج  ';
                     $lang['UAE-Delivery Note'] = 'ايصال التسليم -الامارات  ';
                      $lang['KSA-Delivery Note'] = 'ايصال التسليم -السعودية ';
                       $lang['Dragon-Delivery Note'] = 'ايصال التسليم -السوق الصيني  ';
                 $lang['Export-Delivery Note'] = 'ايصال  الدفع -التصدير ';
                  $lang['Amazon-UK-Delivery Note'] = 'ايصال  الدفع -امازون المملكة المتحدة ';
                 
                
                   $lang['Price List Amazon (UK)'] = 'لائحة الاسعار أمازون  (UK) ';
                   $lang['Check New Price'] = 'التحقق من تحديث الاسعار';
                    $lang['Sales Return'] = 'المرتجعات ';
                  $lang['Delivery Note'] = 'فواتير التوصيل  ';  
                    
                      $lang['Stock Adjustments -'] = 'ضبط المخزون  - ';
                       $lang['Stock Adjustments +'] = 'ضبط المخزون  + ';

 $lang['Stock Transfers'] = 'نقل مخزون المنتجات   ';
  $lang['Opening Stocks'] = ' المخزون الافتتاحي  ';
   $lang['Current Stock'] = 'المخزون الحالي  ';
    $lang['Low Inventories'] = 'المخزونات المنخفضة  ';
     $lang['Stock delivery report'] = 'تقرير تسليم المنتجات   ';

      $lang['UAE Stock delivery report'] = 'تقرير تسليم المنتجات -  الامارات   ';
      $lang['KSA Stock delivery report'] = ' تقرير تسليم المنتجات  - السعودية ';  
        
        
        
   
        
        $lang['Item_Price_Check'] = 'التحقق من سعر المنتج ';
        $lang['Delivery_Note'] = 'فاتورة تسليم المنتج ';
        $lang['Sales_Return'] = 'مرتجعات المبيعات ';
         $lang['Journals'] = 'دفتر اليومية';
        $lang['Stocks'] = 'ادارة المخزونات  ';

$lang['Dragon Stock delivery report'] = 'تقرير تسليم المنتجات - دراغون ';
$lang['Export Stock delivery report'] = 'تقرير تسليم المنتجات  - الاستيراد ';
$lang['Stock wharehouse yearly'] = 'مخزون المستودعات السنوي  ';
$lang['Update Product Suggestion Stock'] = 'تحديث مقترح مخزون المنتجات ';
         
     $lang['Sales Quotation'] = 'عروض الاسعار للمبيعات  ';    
      
     
               

////////////////////////////
//finacial accounting

$lang['Financial Accounting'] = 'المحاسبة المالية ';
$lang['Sub-Ledger'] = 'دفتر الحسابات  ';



$lang['manage-assets'] = 'ادارة الاصول';

//////////////////////////////
////Account Reports

 $lang['Accounts Reports'] = 'تقارير المحاسبة ';
 
   $lang['Reports'] = 'التقارير ';
    $lang['Accounts Operations Report'] = 'تقارير العمليات المحاسبية ';
     $lang['Graphical data'] = 'البيانات التوضيحية ';
      $lang['Fund Transfer'] = 'تحويل الأموال';
       $lang['Approve Transfers Now'] = 'تأكيد  التحويل الان ';

//////////////////
/////Sales Book 


$lang['Sales Book'] = 'دفتر  المبيعات ';

$lang['Sales Book Excel upload'] = 'تحميل دفتر المبيعاات ';

$lang['Total Sales Book'] = 'مجموع دفتر الحسابات ';
$lang['Country Wise Sales'] = 'تقارير ومخططات مبيعات  المناطق ';
$lang['Season Sales'] = 'المبيعات الموسمية';


///////////////////
/////Purchase Book 

$lang['Purchase Book'] = 'دفتر المشتريات';
$lang['Purchase Book Excel upload'] = 'تحميل دفتر المشتريات ';
$lang['Total Purchase Book'] = 'دفتر المشتريات الكلي والحسابات ';



////////////////////////
////marketing Reports

 $lang['Marketing Reports'] = 'تقارير  التسويق  ';
  $lang['Dashboard'] = 'الرئيسية   ';
   $lang['VISITORS FORM'] = 'نموذج الزوار ';
    $lang['Gulf Trading Visitors Form'] = 'زوار الخليج للتجارة ';
     $lang['List Visitors'] = 'قائمة الزوار ';

//////////////////
///User management     

$lang['User Managment'] = 'ادارة المستخدمين';
$lang['Add Users'] = 'اضافة مستخدم';
$lang['List Users'] = 'لائحة المستخدمين ';

///////////////
///Fund Transfer

 $lang['Fund Transfer'] = 'تحويل الارصدة ';
  $lang['Transfer Funds'] = 'تحويل رصيد ';
   $lang['List Transfers'] = 'لائحة التحويلات ';






/////////////////
//sales master  

 $lang['Sales Master'] = 'المبيعات والادارة  ';
  $lang['Add Customer Details'] = 'اضافة  تفاصيل الزبون';
   $lang['List Customer Details'] = 'لائحة الزبائن';
    $lang['Excel upload Customer Details'] = 'تحميل  ملف بتفاصل الزبائن ';
     $lang['Add Sales Target'] = 'اضافة  هدف مبيعات جديد';
      $lang['List Sales Target'] = ' لائحة  اهداف المبيعات ';

////////////File Manager/////////////

      $lang['File Manager'] = ' مدير الملفات ';
      $lang['Add Files'] = 'اضافة الملفات ';




/////////HR Management/////////

$lang['HR Management'] = 'ادارة الموارد  ';
$lang['Add Employee To Tree'] = 'اضافة موظف  الى الشجرة   ';
$lang['List Employee Tree'] = 'شجرة الموظفين ';
$lang['List Jobs Applied'] = 'المتقدمين للوظائف';
$lang['Hiring'] = 'التوظيف';
$lang['Add Jobs'] = 'اضافة منصب  ';
$lang['List Jobs'] = 'الائحة المناصب  ';
$lang['Job Offer'] = 'عرض العمل  ';
$lang['Add Leave'] = 'اضافة اجازة  ';
$lang['List Leave'] = ' لائحة  الاجازات  ';
$lang['List employee request'] = 'لائحة طلبات الموظفين  ';
$lang['List User Files'] = 'لائحة ملفات الموظفين  ';



 ///////////Email marketing customers Management///

$lang['Email marketing customers Management'] = 'التسويق وادارة الزبائن ';

$lang['Customer excel upload'] = 'تحميل ملف الزبون';

$lang['List Customer'] = 'لائحة الزبائن   ';

///Inventory Management///////////

$lang['Inventory Management'] = 'ادارة المخزون  ';
$lang['Excel upload warehouse details'] = ' تحميل ملف  لتفاصيل المستودع ';
$lang['List Inventory data'] = 'لائحة بيانات المخزون  ';


////////////Invoice Data


$lang['Invoice Data'] = 'بيانات الفواتير  ';
$lang['Upload Receipt Register Excel'] = 'رفع  ملف الايصالات  ';
$lang['Upload Complete Sales Report Excel'] = 'رفع  ملف تقرير المبيعات الكامل  ';
$lang['Compare Sales Report Vs. Receipt'] = 'مقارنة  تقرير المبيعات مع الايصالات  ';








/////////////Survey Module///////////


$lang['Survey Module'] = 'وحدة الدراسات  ';

$lang['Create Survey'] = 'انشاء دراسة  ';
$lang['List Survey'] = 'لائحة الدراسات  ';
$lang['List Installation'] = 'لائحة التثبيت  ';
$lang['Create Single Installation'] = 'اانشاء تثبيت معين   ';
$lang['List Single Installation'] = 'لائحة التثبيتات المفردة  ';
$lang['Accounts Survey Module'] = 'نموذج حسابات الدراسات  ';
$lang['Survey BOM'] = 'دراسات  Bom   ';

$lang['Create Customer Pricing'] = 'انشاء تسعيرة للزبون  ';









///////////////Manage Profile///////////////////////

$lang['Manage Profile'] = ' ادارة الملفات  ';
$lang['List all tickets'] = 'لائحة التيكيت ';


//////////////

/////Check Your Tasks


$lang['Check Your Tasks'] = 'التحقق من  المهام  ';

$lang['List of Tasks'] = 'لائحة المهام ';





      ?>