<?php

defined('BASEPATH') or exit('No direct script access allowed');



        $lang['List'] = 'لائحة   ';
        $lang['List_Sales_invoice'] = 'لائحة فواتير المبيعات  ';

         $lang['Click_to_create'] = 'فاتورة جديدة';


         $lang['Sort_by_payment'] = 'فرز حسب المدفوعات';
         $lang['Paid'] = 'مدفوع';
         $lang['Partially_Paid'] = 'مدفوع جزئيا';
         $lang['Not_paid'] = 'غير مدفوع ';

        $lang['Action'] = 'القائمة  '; 
        $lang['Doc_No'] = 'رقم المستند ';
        $lang['Date'] = 'التاريخ ';
        $lang['Company'] = 'الشركة ';
        $lang['Customer'] = 'لحساب الزبون';
        $lang['Narration'] = 'ملاحظات  ';
        $lang['Due_Amount'] = 'المبلغ المستحق ';
        $lang['Total_Amount'] = 'المبلغ الكلي ';
        $lang['Delivery_Status'] = 'حالة التوصيل ';
        $lang['Status'] = 'الحالة  ';
         $lang['Not_Delivered'] = 'غير مستلم ';
        $lang['Delivered'] = 'تم التسليم ';
        $lang['Partially_Delivered'] = 'تسليم جزئي ';
         $lang['Wrong_Delivered'] = 'خطأ تسليم  ';
         $lang['Returened_All'] = 'مرتجع بالكامل ';
        $lang['partially_Returened'] = 'مرتجع جزئيا  ';
         $lang['View'] = 'اظهار تفاصيل ';
         $lang['Open_edit_modal'] = 'التحديث ';
         $lang['Edit_Details'] = 'تعديل ';
        $lang['Delete'] = 'حذف ';
        $lang['Generate_Pdf'] = 'طباعة PDF ';
        $lang['Reference Details'] = 'التفاصيل المرجعية  ';
        $lang['Sales Invoice Data'] = 'مبيعات فاتورة المبيعات  ';
        $lang['Doc no'] = 'رقم  المستند ';
         $lang['User Created'] = 'المستخدم المنشئ  ';
        $lang['Currency'] = 'العملة  ';
        $lang['Vat Type'] = 'نوع  الضريبة  ';
         $lang['Taxable'] = 'خاضع للضريبة'; 
        $lang['Non-Taxable'] = 'غير خاضع للضريبة '; 
        $lang['Linked to'] = 'مرتبط بالتالي  '; 
        $lang['Sales Account'] = 'حساب المبيعات  '; 
         $lang['LPO No'] = 'رقم امر الشراء '; 
           $lang['Price Level'] = 'مستوى السعر '; 
         $lang['Salesman'] = 'مندوب المبيعات  '; 
         $lang['Payment Type'] = 'نوع الدفع  '; 
         $lang['Place of Supply'] = 'مصدر التزويد  '; 
        $lang['Jurisdiction'] = 'الجهة  '; 
         $lang['Narration'] = 'المؤسسة  '; 
         $lang['Contact'] = 'جهة الاتصال  '; 
         $lang['Delivery Address'] = 'عنوان التوصيل  ';
         $lang['Mark'] = 'علامة  ';
        $lang['Ship Contact'] = 'جهة اتصال الشحن  ';
        $lang['Country'] = 'البلد  ';

        $lang['Current Status'] = 'حالة الفاتورة ';
        $lang['Attachements'] = 'ملحقات  ';
        $lang['Warehouse'] = 'المستودع ';
        $lang['Product'] = 'المنتج ';
        $lang['Quantity'] = 'الكمية  ';
        $lang['Rate'] = 'المبلغ  ';
        $lang['Gross'] = 'الاجمالي  ';
        $lang['Discount'] = 'الخصم ';
        $lang['Discount Amount'] = 'مبلغ الخصم ';
        $lang['Add.Charges'] = 'القيمة المضافة ';
        $lang['Fnet'] = 'المبلغ الصافي ';
        $lang['Vat'] = 'الضريبة ';
        $lang['Delivery Date'] = 'تاريخ التوصيل ';
        $lang['Remark'] = 'ملاحظة ';
        $lang['Tax Code'] = 'الرمز الضريبي ';
        $lang['Total Quantity'] = 'الكمية الكليّة ';
        $lang['Total Rate'] = 'المبلغ الكلي   للقطعة ';
         $lang['Total Gross'] = 'المجموع الكلي ';
         $lang['Total Discount'] = 'مجموع الخصم ';
         $lang['Total Discount Amount'] = 'مجموع مبلغ الخصم  ';
         $lang['Total Additional Charges'] = 'مجموع المدفوعات الاضافية ';

         $lang['Total Fnet'] = 'جموع صافي المبلغ  ';
           $lang['Total VAT Amount'] = 'مجموع صافي الضريبة ';
           $lang['Final Amount'] = 'المبلغ النهائي ';
		     $lang['Are you sure, you want to delete this payment details permanently?'] = 'هل انت متأكد ؟ ستقوم بحذف كافة تفاصيل الفاتورة بشكل تام ';
                    $lang['This action cannot be undone?'] = 'هذا الحذف لايمكن التراجع عنه ';

                    $lang['Are You Sure?'] = 'هل انت متأكد ؟';
					$lang['Confirm'] = 'تأكيد ';
                     $lang['Cancel'] = 'الغاء الامر ';

                 $lang['Generate PDF'] = 'PDF تصدير ملف  ';
                      $lang['Choose option to print Invoice as'] = 'اختر طريقة طباعة الفاتورة  ';
                      $lang['With Letter-head'] = 'مع الترويسة  ';
                      $lang['Without Letter-head'] = 'بدون ترويسة  ';

                      
                      $lang['Transactions'] = ' المعاملات المالية ';
                        $lang['Sales'] = 'المبيعات ';
                          $lang['Issue Sales Invoice'] = 'اصدار فاتورة المبيعات   ';
                            $lang['Fileds marked as'] = 'الحقول المميزة بالرمز ::*:: هي حقول الزامية    ';


  $lang['Description'] = 'الوصف';
                   $lang['Assets_name'] = 'اسم الاصل';
                   $lang['sub_from'] = 'فرع الاصل';
                    $lang['Assets_parent'] = 'اساس الاصل';
                     $lang['Belong_To'] = 'ضمن عهدة';
                     $lang['Serial_number'] = 'الرقم التسلسلي';
                     $lang['final_custody_date'] = 'تاريخ اخر عهدة';
                     $lang['availiabilaty'] = 'الاتاحية';
                     $lang['condition_statue'] = 'الحالة الفنية  ';
                      $lang['Not_Avialable'] = 'غير متاح  ';
                      $lang['Avialable'] = 'متاح ';
                 $lang['asset_name']='اسم الاصل';
       $lang['New_assets'] = 'تسجيل اصل جديد';               
               $lang['assets'] = 'الاصول';                    
  $lang['Create Assets Item']='انشاء اصل جديد';
     $lang['Doc No'] = 'رقم المستند ';
$lang['Customer'] = 'الزبون  ';
$lang['Choose'] = 'إختر  ';
$lang['LPO Number'] = 'رقم اخر طلب شراء ';
  $lang['Project'] = 'المشروع ';                    
$lang['Customer Contact'] = 'جهة اتصال الزبون '; 
 $lang['Country/City'] = 'الدولة /المدينة '; 
$lang['Shipping Mark'] = 'علامة الشحن '; 
$lang['Delivery Contact'] = 'جهة اتصال الموصل '; 
$lang['Customer Vat number'] = 'الرقم الضريبي للزبون  '; 

  $lang['Currency Name'] = 'اسم العملة ';
       
  $lang['Currenct Conv'] = 'تحويل العملة ';
                   
  $lang['Taxable Invoice'] = 'فاتورة خاضعة للضريبة ';
                    
      $lang['Non-Taxable Invoice'] = 'فاتورة غير خاضعة للضريبة ';                
                    
        $lang['Upload files here.Make sure the file size is less than 2MB'] = 'قم بتحميل الملفات هنا . تأكد بان حجم الملف لايتجاوز  2MB';

                   
$lang['FILES UPLOADED'] = 'تم رفع الملفات ';
 $lang['Image'] = 'صورة  ';                 
                    
$lang['Item'] = 'االمنتج ';
                
 $lang['Total Number of items'] = 'عدد المنتجات الكلي ';         
$lang['Total Discount Percentage'] = 'مجموع نسبة الخصم ';


$lang['Total VAT Charges'] = 'مجموع تكاليف الضريبة ';


$lang['Click to see total amount'] = 'اضغط لحساب المجموع الكلّي ';
 
 $lang['Amount as per the currency rate selected'] = 'المبلغ سيكون على حسب  العملة الموضوعة ';
 
$lang['References'] = 'ارتباطات  ';

$lang['Save Edit'] = 'حفظ التعديلات ';

$lang['Pop-up Invoice'] = 'اضغط لتظهر الفاتورة  ';

$lang['Reset'] = '
إعادة ضبط';
 $lang['Are You check the Price With Focus?'] = 'هل قمت بالتأكد من الاسعار مع فوكس؟';
$lang['this is Secondary Check For Product Price Between Focus And Dashboard'] = 'هذه مقارنة ثانوية للتاكيد بين سعر المنتج على فوكس وعلى الداشبورد ماشي؟';
     $lang['Save'] = 'حفظ ';       
       $lang['Add More'] = 'اضافة المزيد ';
       $lang['Amount Total'] = 'المبلغ الكلّي';

       $lang['Add as new reference'] = 'اضافة كمرجع جديد  ';

       $lang['Reference'] = 'ارتباط ';
       $lang['Bill Amount'] = 'مبلغ الفاتورة';

       $lang['Amount Adjusted'] = 'المبلغ المضبوط ';
       $lang['Pick Amount'] = 'التقاط قيمة ';

$lang['Reset Fields'] = 'اعادة ضبط الحقول ';

$lang['Amount to adjust'] = 'المبلغ  الباقي  بدون ضبط ';

$lang['Amount adjusted'] = 'الكمية المضبوطة ';

$lang['To be adjusted'] = 'المتبقي بحاجة للضبط ';

            
      $lang['List_assets'] = 'قائمة الموجودات'; 

       
        



      ?>