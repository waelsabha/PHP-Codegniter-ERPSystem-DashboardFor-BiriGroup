<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['client_id'] = '92784722830-93cdvdkanqmhfinm74v4glq7au972tt7.apps.googleusercontent.com';
$config['client_secret'] = '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';
