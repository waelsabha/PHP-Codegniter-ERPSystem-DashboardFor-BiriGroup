<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Login_controller';


// $route['dashboard-calender'] = 'GoogleCalendar/index';
// $route['gc/auth/index'] = 'GoogleCalendar/index';
// $route['gc/auth/login'] = 'GoogleCalendar/login';
// $route['gc/auth/oauth'] = 'GoogleCalendar/oauth';
// $route['gc/auth/logout'] = 'GoogleCalendar/logout';






$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['dashboard']='Dashboard_controller/dashboard';

$route['submit_date_range_dashboard']='Dashboard_controller/dashboard';

//tree
$route['list_tree']='Admin_biri/list_tree';
$route['list_positions']='Admin_biri/list_positions';
$route['list_terms']='Admin_biri/list_terms';

$route['list_salary_structure']='Admin_biri/list_salary_structure';
$route['job_offer_sts_list']='Admin_biri/job_offer_sts_list';


$route['submit_positions']='Admin_biri/submit_positions';
$route['submit_terms']='Admin_biri/submit_terms';
$route['edit_position']='Admin_biri/edit_position';
$route['edit_terms']='Admin_biri/edit_terms';
$route['delete_position/(:num)']='Admin_biri/delete_position/$1';
$route['delete_terms/(:num)']='Admin_biri/delete_terms/$1';


$route['add_tree/(:num)']='Admin_biri/add_tree/$1';

$route['submit_add_subcategory']='Admin_biri/submit_add_subcategory';
$route['submit_add_file']='Admin_biri/submit_add_file';
$route['grid_tree']='Admin_biri/check_file';
$route['getItem'] = "Admin_biri/getItem";
$route['accountsTreeView'] = "Admin_biri/accountsTreeView";
$route['editData/(:num)']='Admin_biri/editData/$1';
$route['submit_update_account_tree_data'] = 'Admin_biri/submit_update_account_tree_data';
$route['accountsMove'] = "Admin_biri/accountsMove";

$route['add_account_entry']='Admin_biri/add_acc';
$route['list_account_entry']='Admin_biri/list_account_entry';
$route['submit_account_entry']='Admin_biri/submit_account_entry';

// $route['view_account_entry/(:num)']='Admin_biri/view_account_entry/$1';
$route['edit_account_entry/(:num)']='Admin_biri/add_acc/$1';
$route['edit_account_entry/(:num)/(:any)']='Admin_biri/add_acc/$1/$2';
$route['delete_account_entry/(:num)']='Admin_biri/delete_account_entry/$1';
$route['delete_account_entry/(:num)/(:any)']='Admin_biri/delete_account_entry/$1/$1';

$route['accounts_report']='Admin_biri/accounts_report';
$route['accounts_report_graph']='Admin_biri/accounts_report_graph';

$route['login']='Login_controller/login';
$route['submit_login']='Login_controller/submit_login';

$route['acc_excel_upload']='Import_excel/excel_upload';
$route['submit_excel_sheet']='Import_excel/submit_excel_sheet';

$route['tx_funds']='Fund_tx/tx_funds';
$route['list_txs']='Fund_tx/list_txs';

$route['submit_fund_tx']='Fund_tx/submit_fund_tx';
$route['delete_fund_transfer/(:num)/(:num)']='Fund_tx/delete_fund_transfer/$1/$2';
// $route['edit_fund_transfer/(:num)']='Admin_biri/edit_fund_transfer/$1';

$route['list_pending_tx']='Accounts_controller/list_pending_tx';

$route['list_opening_bal']='Accounts_controller/list_opening_bal';
$route['delete_opening_bal/(:num)']='Accounts_controller/delete_opening_bal/$1';

$route['tx_funds_approve']='Fund_tx/tx_funds_approve';

$route['reconcile_entries']='Accounts_controller/reconcile_entries';
$route['reconcile_data_now/(:num)']='Accounts_controller/reconcile_data_now/$1';
$route['list_reconcilled']='Accounts_controller/reconcile_entries/$1';
$route['un_reconcile_data_now/(:num)']='Accounts_controller/un_reconcile_data_now/$1';


$route['this_range_date']='Dashboard_new/this_range_date';

$route['submit_lstacc_sorting']='Accounts_controller/submit_lstacc_sorting';

////////////test excel///////////////

$route['contact-us']='Login_controller/contact';

$route['display']='Login_controller/display';
$route['save']='Import/save';

/////data for cusotmer excel details upload///
 $route['customer_excel']='Customer_list_excel/customer_excel';
 $route['submit_customer_excel']='Customer_list_excel/submit_customer_excel';
 $route['list_customer_excel']='Customer_list_excel/list_customer_excel';

/////////////////for sales/////////
$route['add-customer-details']='Sales_controller/add_custmrs';
$route['list-customer-details']='Sales_controller/list_custmrs';
$route['submit_new_cusomter']='Sales_controller/submit_new_cusomter';

$route['edit_cust_details/(:num)']='Sales_controller/add_custmrs/$1';
$route['delete_cust_details/(:num)']='Sales_controller/delete_custmrs/$1';

$route['marketing-dashboard']='Sales_dashboard_controller/dashboard';
$route['hr-dashboard']='HR_dashboard_controller/dashboard';


$route['add-files']='Sales_controller/add_bus_cards';

$route['submit_bus_card']='Sales_controller/submit_bus_card';
$route['delete_bus_card/(:num)']='Sales_controller/delete_bus_card/$1';
$route['download_files/(:num)']='Sales_controller/download_files/$1';
$route['download_bus_cards/(:num)']='Sales_controller/download_bus_cards/$1';

$route['customer-excel-upload']='Sales_controller/customer_excel_upload';
$route['submit_cutomer_visitor_excel']='Sales_controller/submit_cutomer_visitor_excel';

$route['add-quotation']='Quotation_controller/add_quotation';
$route['submit_quotation_details']='Quotation_controller/submit_quotation_details';
$route['quotation-status/(:num)']='Quotation_controller/quotation_status/$1';
$route['generate_quotation/(:num)']='Quotation_controller/generate_quotation/$1';

$route['send_mail_quotation/(:num)']='Quotation_controller/send_mail_quotation/$1';
$route['list-quotation']='Quotation_controller/list_quotation';
$route['list-quotation/(:any)']='Quotation_controller/list_quotation/$1';

$route['edit_quotation/(:num)']='Quotation_controller/add_quotation/$1';
$route['add-signature']='Quotation_controller/add_signature';
$route['submit_signature']='Quotation_controller/submit_signature';
$route['copy_quotation/(:num)/(:any)']='Quotation_controller/add_quotation/$1/$2';

$route['submit_quotation_sts']='Quotation_controller/submit_quotation_sts';
$route['quotation_sts/(:num)/(:num)']='Quotation_controller/quotation_sts/$1/$2';
$route['get_price_item']='Quotation_controller/get_price_item';

$route['price-list']='Quotation_controller/price_list';

$route['quot_history/(:num)']='Quotation_controller/quot_history/$1';

$route['update-product-stock-1']='Quotation_controller/update_product_stock';
$route['list-stock']='Quotation_controller/list_stock';

$route['excel_download_sample_update_stock']='Quotation_controller/excel_download_sample_update_stock';
$route['submit_product_update_stock']='Quotation_controller/submit_product_update_stock';

$route['issue_performa_invoice/(:num)']='Quotation_controller/issue_performa_invoice/$1';

$route['list-porforma']='Quotation_controller/list_performa';
$route['generate_quotation/(:num)/(:any)']='Quotation_controller/generate_quotation/$1/$2';
$route['generate_localproforma/(:num)/(:any)']='Quotation_controller/generate_localproforma/$1/$2';
$route['send_mail_quotation/(:num)/(:any)']='Quotation_controller/send_mail_quotation/$1/$2';

$route['submit_pi_details']='Quotation_controller/submit_pi_details';

$route['raise_stock_ticket/(:num)']='Quotation_controller/raise_stock_ticket/$1';
$route['submit_ticket_stock']='Quotation_controller/submit_ticket_stock';
$route['reply_ticket/(:num)']='Quotation_controller/reply_ticket/$1';
$route['all-tickets']='Employee_controller/all_tickets';

$route['get_picture_report/(:any)']='Quotation_controller/get_picture_report/$1'; 
$route['submit_picture_report']='Quotation_controller/submit_picture_report';

///////////user managment///////
$route['add-users']='Main_admin/add_users';
$route['list-users']='Main_admin/list_users';

$route['submit_user_mng']='Main_admin/submit_user_mng';

$route['edit_user/(:num)']='Main_admin/add_users/$1';
$route['delete_user/(:num)']='Main_admin/delete_user/$1';
$route['list-user-files']='Main_admin/list_user_files';
$route['current_user_activity/(:num)']='Main_admin/current_user_activity/$1';
////////////////production///////////

$route['production-entry']='Production_entry/production_entry';
$route['prd-category']='Production_entry/prd_category';
$route['prd-brands']='Production_entry/prd_brands';
$route['prd-units']='Production_entry/prd_units';
$route['prd-variations']='Production_entry/prd_variations';
$route['prd-final-values']='Production_entry/prd_final_values';
$route['prd-hse-codes']='Production_entry/prd_hse_codes';

$route['submit_hs_codes']='Production_entry/submit_hs_codes';
$route['edit_hse_code']='Production_entry/edit_hse_code';
$route['delete_hse_code/(:num)']='Production_entry/delete_hse_code/$1';

$route['submit_cat']='Production_entry/submit_cat';
$route['edit_cat']='Production_entry/edit_cat';
$route['delete_category/(:num)']=
'Production_entry/delete_category/$1';

$route['submit_brand_data']='Production_entry/submit_brand_data';
$route['edit_brand']='Production_entry/edit_brand';
$route['delete_brand/(:num)']=
'Production_entry/delete_brand/$1';

$route['submit_unit_data']='Production_entry/submit_unit_data';
$route['edit_unit']='Production_entry/edit_unit';
$route['delete_units/(:num)']=
'Production_entry/delete_units/$1';

$route['submit_variation']='Production_entry/submit_variation';
$route['edit_variation']='Production_entry/edit_variation';
$route['delete_variation/(:num)']='Production_entry/delete_variation/$1';

$route['edit_finals']='Production_entry/edit_finals';

$route['submit_prd']='Production_entry/submit_prd';
$route['list-production']='Production_entry/list_prd';
$route['delete_prd/(:num)']='Production_entry/delete_prd/$1';
$route['edit_prd/(:num)']='Production_entry/production_entry/$1';

$route['upload-production-excel']='Excel_production/excel_upload';
$route['submit_production_excel']='Excel_production/submit_production_excel';

$route['product-order']='Product_order/prd_order';
$route['submit_prd_order']='Product_order/submit_prd_order';
$route['prd-order-next']='Product_order/prd_order_next';
$route['update_variations']='Product_order/update_variations';
$route['prd-order-list']='Product_order/prd_list';

$route['edit_prd_ordr/(:num)']='Product_order/prd_order/$1';
$route['delete_prd_ordr/(:num)']='Product_order/delete_prd_ordr/$1';
$route['product_order_status']='Product_order/po_sts';

$route['prd-order-sts']='Product_order/po_sts_sales';

$route['submit_form_check_po_sts']='Product_order/submit_check_po_sts';

$route['po_history/(:num)']='Product_order/po_history/$1';
$route['generate_po_pdf/(:num)']='Product_order/generate_prd_order/$1';

$route['approve_po_ksa/(:num)']='Product_order/approve_po_ksa/$1';


$route['make_migrate']='Product_order/make_migrate';

$route['prd_extra_details_excel']='Production_entry/excel_upload_prd_details';
$route['submit_prd_extra_details']='Production_entry/submit_prd_extra_details';


$route['send_sms/(:num)']='Gulf_trading/send_sms/$1';

////////////////////////inventory managment/////////////////////////////////
$route['add-inventory']='Inventory_mngmnt/add_inventory';
$route['submit_inventory_excel']='Inventory_mngmnt/submit_inventory_excel';
$route['list-inventory']='Inventory_mngmnt/list_inventory';
$route['view_inventory/(:num)']='Inventory_mngmnt/view_inventory/$1';

///////////main factory && adv dashboard///////////

$route['po-dashboard']='Admin_PO/dashboard_po';
$route['dept_edited_prod_order']='Admin_PO/edit_dept_po';
$route['po_attachments/(:num)']='Admin_PO/download_po_attachments/$1';

$route['submit_po_delivery_note']='Admin_PO/submit_po_delivery_note';

//////////data from focus /////////////
$route['invoice-pending']='Focus_data/pending_invoice';

////////////////cron job////////////
$route['check_delivery']='Cron_jobs/check_delivery';
$route['check_pallet_uk']='Cron_jobs/check_pallet_uk';


///////Accounts tree//////
$route['accounts-head']='Accounts_tree/accounts_head';
$route['submit_ac_head']='Accounts_tree/submit_ac_head';

$route['add-customers']='Accounts_customer/add_customers';
$route['add-suppliers']='Accounts_suppliers/add_suppliers';

$route['submit_acc_customer']='Accounts_customer/submit_acc_customer';
$route['submit_acc_supplier']='Accounts_suppliers/submit_acc_supplier';

$route['acc_upload_excel/(:any)']='Account_excel/excel_upload/$1';
$route['submit_excel_sheet2']='Account_excel/submit_excel_sheet';

$route['list-account-head']='Accounts_tree/list_acc_head';
$route['list-account-suppliers']='Accounts_suppliers/list_acc_suppliers';
$route['list-account-customers']='Accounts_customer/list_acc_customers';
$route['delete_supplier/(:num)']='Accounts_suppliers/delete_supplier/$1';
$route['delete_customer/(:num)']='Accounts_customer/delete_customer/$1';

$route['edit_head/(:any)/(:num)']='Accounts_tree/edit_head/$1/$2';

$route['incoming-payment']='Payment/incoming_payment';
$route['submit_incoming_payment']='Payment/submit_ip';

$route['outgoing-payment']='Payment/outgoing_payment';
$route['submit_outgoing_payment']='Payment/submit_outgoing_payment';
///////sales book reports////

$route['sales-book']='Sales_book/sales_book_excel_upload';
$route['submit_sales_book_excel']='Sales_book/submit_sales_book_excel';

$route['sales-book-dashboard']='Sales_book/sb_dashboard';

$route['sales-book-dashboard-country']='Sales_country_book/sb_dashboard';
$route['submit_date_range_sales_country_book']='Sales_country_book/sb_dashboard';

$route['ksa-sales-book-dashboard']='ksa_Sales_book/ksa_sb_dashboard';
$route['submit_date_range_sales_book']='Sales_book/sb_dashboard';
$route['season-sales']='Sales_book/compare_sales';
$route['submit_season_comparison']='Sales_book/submit_season_comparison';
///////purchase book reports////

$route['purchase-book-excel']='Purchase_book/purchase_book_excel_upload';
$route['submit_purchase_book_excel']='Purchase_book/submit_purchase_book_excel';

$route['purchase-book-dashboard']= 'Purchase_book/pb_dashboard';

$route['submit_date_range_purchase_book']='Purchase_book/pb_dashboard';
$route['submit_class_year_selected/(:num)']='Purchase_book/pb_dashboard/$1';
$route['submit_group_year_selected/(:num)']='Purchase_book/pb_dashboard/$1';

////////hr managment/////
$route['employee-tree']='Employee_tree/create_employee_tree';
$route['employee-upload']='Employee_tree/hr_excel_upload';
$route['submit_hr_excel']='Employee_tree/submit_hr_excel';
$route['list-employee-tree']='Employee_tree/list_emp_tree';
$route['add-employees']='HR_controller/add_emp';
$route['submit_emp_office']='HR_controller/submit_emp';
$route['list-employees']='HR_controller/list_emp';
$route['list-jobs-applied']='HR_controller/list_jobs';
$route['delete_job_details/(:num)']='HR_controller/delete_job_details/$1';
$route['edit_status_job_application']='HR_controller/edit_job_sts';

$route['edit_emp_details/(:num)']='HR_controller/add_emp/$1';
$route['delete_emp_details/(:num)']='HR_controller/delete_emp/$1';

$route['download_emp_files/(:num)']='HR_controller/download_emp_files/$1';
$route['download_emp_files_req/(:any)/(:num)']='HR_controller/download_emp_files_req/$1/$2';

$route['add-jobs']='Careers/add_jobs';
$route['submit_add_jobs']='Careers/submit_add_jobs';
$route['list-jobs']='Careers/list_jobs';
$route['edit_job_details/(:num)']='Careers/add_jobs/$1';
$route['delete_job/(:num)']='Careers/delete_job_details/$1';

$route['job-offer']='Careers/job_offer';
$route['list_job_offer']='Careers/list_job_offer';
$route['edit-job-offer_details/(:num)']='Careers/job_offer/$1';
$route['delete-job-offer/(:num)']='Careers/delete_job_offer_details/$1';
$route['submit-job-offer']='Careers/submit_job_offer';
//$route['approve_job_offer']='Admin_biri/approve_job_offer';
$route['job-offer-draft/(:num)']='Careers/job_offer_draft/$1';
$route['job-offer-final/(:num)']='Careers/job_offer_final/$1';
$route['job-offer-reject/(:num)']='Careers/job_offer_reject/$1';
$route['job-offer-approve/(:num)']='Careers/job_offer_approve/$1';

$route['edit_job_details/(:num)']='Careers/add_jobs/$1';
$route['delete_job/(:num)']='Careers/delete_job_details/$1';
$route['add-leave']='Leave_controller/add_leave';
$route['submit_leave']='Leave_controller/submit_leave';
$route['list-leave']='Leave_controller/list_leave';
$route['edit_leave_details/(:num)']='Leave_controller/add_leave/$1';
$route['delete_leave/(:num)']='Leave_controller/delete_leave/$1';
$route['submit_leave_status']='Leave_controller/submit_leave_status';

$route['list-employee-request']='Requests_controller/list_employee_request';
$route['add-emp-request']='Requests_controller/add_employee_request';
$route['edit_empreq_details/(:num)']='Requests_controller/add_employee_request/$1';
$route['delete_emp_req/(:num)']='Requests_controller/delete_emp_req/$1';

$route['submit_emp_request']='Requests_controller/submit_emp_request';

$route['submit_request_status']='Requests_controller/submit_request_status';
//////for accounts masters//////
$route['account_masters_excel']='Accounts_master_excel/account_masters_excel';
$route['submit_account_masters_excel']='Accounts_master_excel/submit_account_masters_excel';
$route['account_masters_data']='Accounts_master_excel/account_masters_data';
$route['submit_acc_master_date_range']='Accounts_master_excel/account_masters_data';
$route['emp-custody-create']='Manage_assets/emp_custody_page';

//////////////////////////////////item request////////////////////////////
$route['add_item_request']='Item_request/add_item_request';
$route['add_item_request_ksa']='Item_request/add_item_request_ksa';
$route['add_item_request_uk']='Item_request/add_item_request_uk';
$route['add_item_request_ca']='Item_request/add_item_request_ca';
$route['submit_item_req']='Item_request/submit_item_req';
$route['submit_item_req_ksa']='Item_request/submit_item_req_ksa';
$route['submit_item_req_uk']='Item_request/submit_item_req_uk';
$route['submit_item_req_ca']='Item_request/submit_item_req_ca';

$route['item-request-status/(:num)']='Item_request/item_request_status/$1';

$route['item-request-status-uk/(:num)']='Item_request/item_request_status_uk/$1';
$route['item-request-status-ksa/(:num)']='Item_request/item_request_status_ksa/$1';
$route['item-request-status-ca/(:num)']='Item_request/item_request_status_ca/$1';



$route['list-item-request']='Item_request/list_item_request';
$route['list-item-request-ksa']='Item_request/list_item_request_ksa';
$route['list-item-request-uk']='Item_request/list_item_request_uk';
$route['list-item-request-ca']='Item_request/list_item_request_ca';

$route['list-completed-item-request']='Item_request/list_completed_item_request';
$route['list-rejected-item-request']='Item_request/list_rejected_item_request';


$route['change_item_req_sts/(:num)/(:num)']='Item_request/change_item_req_sts/$1/$2';
$route['change_item_req_sts_ksa/(:num)/(:num)']='Item_request/change_item_req_sts_ksa/$1/$2';
$route['change_item_req_sts_uk/(:num)/(:num)']='Item_request/change_item_req_sts_uk/$1/$2';
$route['change_item_req_sts_ca/(:num)/(:num)']='Item_request/change_item_req_sts_ca/$1/$2';
$route['submit_item_req_sts']='Item_request/submit_item_req_sts';
$route['edit_item_request/(:num)']='Item_request/add_item_request/$1';
$route['edit_item_request_ksa/(:num)']='Item_request/add_item_request_ksa/$1';
$route['edit_item_request_uk/(:num)']='Item_request/add_item_request_uk/$1';
$route['edit_item_request_ca/(:num)']='Item_request/add_item_request_ca/$1';

$route['delete_item_request/(:num)']='Item_request/delete_item_request/$1';
$route['item_request_history/(:num)']='Item_request/item_request_history/$1';
$route['item_reply_request/(:num)']='Item_request/item_reply_request/$1';

$route['generate_req_order/(:num)']='Item_request/generate_req_order/$1';
$route['generate_req_order_ksa/(:num)']='Item_request/generate_req_order_ksa/$1';
$route['generate_req_order_uk/(:num)']='Item_request/generate_req_order_uk/$1';
$route['generate_req_order_ca/(:num)']='Item_request/generate_req_order_ca/$1';

$route['combined_db']='Dashboard_combined/combined_dashboard';
$route['sales-user-dashboard']='Sales_user_dashboard/dashboard';

$route['add-sales-target']='Sales_target/add_sales_target';
$route['list-sales-target']='Sales_target/list_sales_target';
$route['submit_sales_target']='Sales_target/submit_sales_target';
$route['edit_target_details/(:num)']='Sales_target/add_sales_target/$1';
$route['delete_target_details/(:num)']='Sales_target/delete_target_details/$1';

$route['manage_item_request/(:num)']='Item_request/manage_item_request/$1';
$route['manage_item_request_uk/(:num)']='Item_request/manage_item_request_uk/$1';
$route['manage_item_request_ca/(:num)']='Item_request/manage_item_request_ca/$1';
$route['manage_item_request_ksa/(:num)']='Item_request/manage_item_request_ksa/$1';
$route['submit_adj_qnty']='Item_request/submit_adj_qnty';
$route['generate-shipment-item-request']='Item_request/generate_shipment';

$route['submit_generate_shipment']='Item_request/submit_generate_shipment';
$route['list-generate-shipment']='Item_request/list_generate_shipment';
$route['view_shipment_details/(:num)']='Item_request/view_shipment_details/$1';
$route['view_shipment_details_uk/(:num)']='Item_request/view_shipment_details_uk/$1';
$route['view_shipment_details_ca/(:num)']='Item_request/view_shipment_details_ca/$1';
$route['view_shipment_details_ksa/(:num)']='Item_request/view_shipment_details_ksa/$1';

///////////survey controller////////
$route['create-survey-data']='Survey_controller/add_survey_data';
$route['submit_survey_details']='Survey_controller/submit_survey_details';
$route['show-prd-sets/(:num)']='Survey_controller/show_prd_sets/$1';
$route['manage_prd_set/(:num)']='Survey_controller/manage_prd_set/$1';
$route['submit_manage_prd_set']='Survey_controller/submit_manage_prd_set';
$route['status-page-prd-set/(:num)']='Survey_controller/sts_prd_set/$1';
$route['generate_po_survey/(:num)']='Survey_controller/generate_po_survey/$1';
$route['generate_po_survey/(:num)/(:any)']='Survey_controller/generate_po_survey/$1/$2';
$route['print-prd-sets-status/(:num)']='Survey_controller/print_prd_sets_status/$1';

$route['list-survey-data']='Survey_controller/list_survey_data';
$route['add_survey_prd_quantities/(:num)']='Survey_controller/add_survey_prd_quantities/$1';

$route['list-installations']='Installation_controller/list_all_installations';
$route['set_installation_date']='Installation_controller/set_installation_date';
$route['manage_installation/(:num)']='Installation_controller/manage_installation/$1';

$route['submit_manage_installation']='Installation_controller/submit_manage_installation';
$route['generate_pdf_installation/(:num)']='Installation_controller/generate_pdf_installation/$1';
$route['generate_pdf_installation/(:num)/(:any)']='Installation_controller/generate_pdf_installation/$1/$2';

$route['submit_edit_qty_survey']='Survey_controller/submit_edit_qty_survey';
$route['generate_installation/(:num)']='Installation_controller/generate_installation/$1';
$route['submit_edit_qty_installation']='Installation_controller/submit_edit_qty_installation';
$route['generate_installation_excel/(:num)']='Installation_controller/generate_installation_excel/$1';

$route['change_sts_installation/(:num)/(:any)']='Installation_controller/change_sts_installation/$1/$2';
$route['manage_assets/(:any)']='Manage_assets/manage_assets/$1';

$route['delete_survey/(:num)']='Survey_controller/delete_survey/$1';
$route['edit_survey_details/(:num)']='Survey_controller/add_survey_data/$1';
$route['submit_installation_img']='Installation_controller/submit_installation_img';

$route['send_installation_mail_customer/(:num)']='Installation_controller/send_installation_mail_customer/$1';

$route['create_bom_po_adv/(:num)']='Admin_PO/create_bom_po_adv/$1';
$route['submit_bom_adv']='Admin_PO/submit_bom_adv';
$route['show-bom-adv/(:num)']='Admin_PO/show_bom_adv/$1';

$route['survey-history/(:num)']='Survey_controller/survey_history/$1';
$route['installation-history/(:num)']='Installation_controller/installation_history/$1';

$route['manage-customer-pricing']='Survey_controller/manage_customer_pricing';
$route['add-survey-customer-pricing']='Survey_controller/add_customer_pricing';
$route['submit_cust_pricing']='Survey_controller/submit_cust_pricing';

$route['check_customer_pricing']='Survey_controller/check_customer_pricing';
$route['edit_cust_pricing/(:num)']='Survey_controller/add_customer_pricing/$1';
$route['delete_cust_pricing/(:num)']='Survey_controller/delete_cust_pricing/$1';

$route['list-survey-customer-pricing']='Survey_controller/list_customer_pricing';

$route['manage_prd_singles/(:num)/(:num)']='Survey_controller/manage_prd_singles/$1/$2';
$route['submit_manage_prd_singles']='Survey_controller/submit_manage_prd_singles';
$route['survey-bom']='Survey_controller/survey_bom';
$route['show-bom-adv/(:num)']='Survey_controller/show_bom_adv/$1';

$route['view_set_installation/(:num)']='Installation_controller/view_set_installation/$1';
$route['submit_installation_details']='Installation_controller/submit_installation_details';
$route['complete_installation_details/(:num)']='Installation_controller/complete_installation_details/$1';
$route['single_prd_img_upload']='Installation_controller/single_prd_img_upload';
$route['prd_set_img_upload']='Installation_controller/prd_set_img_upload';
$route['submit_complete_installation']='Installation_controller/submit_complete_installation';
$route['installation_report/(:num)']='Installation_controller/installation_report/$1';
$route['generate_pdf_current_installation/(:num)']='Installation_controller/generate_pdf_current_installation/$1';

$route['return-installation-items/(:num)']='Survey_controller/return_installation_items/$1';
$route['submit_return_installation']='Survey_controller/submit_return_installation';

$route['list_scheduled/(:num)']='Installation_controller/list_scheduled/$1';
$route['edit_manage_installation/(:num)']='Installation_controller/edit_manage_installation/$1';
$route['delete_manage_installation/(:num)']='Installation_controller/delete_manage_installation/$1';

$route['create_new_item_sets/(:any)/(:num)']='Survey_controller/create_new_item_sets/$1/$2';
$route['submit_create_prd_sets_details']='Survey_controller/submit_create_prd_sets_details';
$route['survey-dashboard']='Survey_dashboard/index';
$route['submit_set_installation_date']='Installation_controller/submit_set_installation_date';

$route['print-complete-installation-report/(:num)/(:any)']='Installation_controller/installation_report/$1/$2';
////////////////////////////////////////item pricing//////////////////////////////////////////////////
$route['create-prd-grps-pricing']='Item_costing/create_prd_grps_pricing';
$route['set-prd-grps-pricing']='Item_costing/set_prd_grps_pricing';
$route['check-standard-pricing']='Item_costing/prd_std_pricing';
$route['check-customized-pricing']='Item_costing/custom_pricing';

$route['std-pricing']='Item_costing/prd_std_pricing';


$route['pricing-uk']='Item_costing/pricing_show_uk';

$route['list-product-costing-details']='Item_costing/product_show_details_uk';



$route['product_extra/(:any)']='Item_costing/product_purchase_extra/$1';

$route['list-price-amazon-uk']='Item_costing/pricing_amazon_uk';
//////////sample excel/////
$route['sample_bom']='Manage_Bom/create_bom_data';

/////////////////////////////////manage po partially//////////////////////////////////////////
$route['approve_po_partially/(:num)']='Manage_PO/manage_approve_po/$1';
$route['submit_manage_approve_po']='Manage_PO/submit_manage_approve_po';

$route['upload-invoice-excel']='Inv_mngt/excel_upload';
$route['submit_complete_sales_excel']='Inv_mngt/submit_complete_sales_excel';
$route['excel_upload_complete_sales_report']='Inv_mngt/excel_upload_complete_sales_report';
$route['compare-sales-report-receipt']='Inv_mngt/compare_sales_report_receipt';

$route['test_new_cron']='Cron_jobs/sample_cron_check';

/////////////////////////////single installation//////////////////////
$route['single-installation']='Single_installation/single_installation';
$route['single-installation/(:num)']='Single_installation/single_installation/$1';
$route['list-single-installation']='Single_installation/list_single_installation';
$route['delete_single_installation/(:num)']="Single_installation/delete_single_installation/$1";

/////////////////masters/////////////////
$route['master-company']='Masters_essentials/create_company';
$route['asset-register']='Masters_essentials/asset_register';
$route['list-asset-register']='Masters_essentials/list_asset_register';
$route['master-currency-converter']='Masters_essentials/currecny_convt';

$route['master-accounts-tree']='Masters_essentials/test_tree_acc';
$route['product-master']='Masters_essentials/product_master';
$route['fixed-asset-tree']='Masters_essentials/master_fixed_asset';

$route['master-db-backup']='Masters_essentials/database_backup';
$route['master-price-level']='Masters_essentials/price_level_master';
$route['master-region']='Masters_essentials/region_master';
$route['master-payment-methods-master']='Masters_essentials/payment_method_masterss';
$route['master-warehouse']='Masters_essentials/warehouse_master';
$route['master-place-supply']='Masters_essentials/place_supply_master';
$route['master-project']='Masters_essentials/project_master';
/////////cash & bank/////////////////////
$route['create-receipt']='Receipt_Master/create_receipt';
$route['list-receipt']='Receipt_Master/list_receipt';

$route['create-pdr']='Receipt_Master/create_pdr';
$route['list-pdr']='Receipt_Master/list_pdr';

$route['create_receipt_customer_print/(:any)/(:any)/(:any)']='Receipt_Master/create_receipt_for_cutomer/$1/$2/$3';

$route['create-payment']='Payments_CB/create_payment';
$route['list-payments']='Payments_CB/list_payments';
$route['create-pdp']='Payments_CB/create_pdp_payment';
$route['list-pdp']='Payments_CB/list_pdp';
$route['list-cheque']='Payments_CB/list_cheque';
$route['create-journal']='Journals/create_journal';
$route['list-journal-entries']='Journals/list_journal_entries';
$route['create-petty-cash']='Petty_cash/create_petty_cash';
$route['list-petty-cash']='Petty_cash/list_petty_cash';
/////transactions////
$route['sales-invoice/(:any)']='Sales_invoice/sales_invoice_page/$1';
$route['list-sales-invoice/(:any)']='Sales_invoice/list_sales_invoice/$1';
//$route['list-sales-invoice-online/(:any)']='Sales_invoice/list_sales_invoice_online/$1';
$route['list-incoming-invoice-online/(:any)']='Sales_invoice/list_sales_invoice_online/$1';

$route['list-amazon-upload-uk']='Sales_invoice/upload_amazon_order_uk';
$route['list-amazon-upload-uae']='Sales_invoice/upload_amazon_order_uae';
$route['update_amazon_payment']='Sales_invoice/upload_amazon_payment';
$route['submit_amazon_order_excel']='Sales_invoice/submit_amazon_order_excel';
$route['submit_amazon_order_uae_excel']='Sales_invoice/submit_amazon_order_uae_excel';
$route['submit_amazon_payment_excel']='Sales_invoice/submit_amazon_payment_excel';
$route['delivery-note/(:any)']='Delivery_note/create_delivery_note/$1';
$route['list-delivery-note/(:any)']='Delivery_note/list_delivery_note/$1';
$route['sales-return']='Sales_return/create_sales_return';
$route['list-sales-return']='Sales_return/list_sales_return';

$route['generate_srt_pdf/(:any)']='Sales_return/generate_srt_pdf/$1';
$route['load_invoice_data/(:any)']='Sales_invoice/load_invoice_data/$1';
//$route['load_delivery_data/(:any)']='Delivery_note/load_delivery_data/$1';
////////////stock module////////////////////
$route['opening-stock']='Prd_stocks/opening_stock';
$route['list-opening-stock']='Prd_stocks/list_opening_stock';
$route['stock-excess']='Prd_stocks/stock_excess';
$route['list-excess-stock']='Prd_stocks/list_excess_stock';
$route['stock-shortage']='Prd_stocks/stock_shortage';
$route['list-shortage-stock']='Prd_stocks/list_shortage_stock';
$route['stock-transfer']='Prd_stocks/stock_transfer';
$route['list-transfer-stock']='Prd_stocks/list_transfer_stock';
$route['list-current-stock']='Prd_stocks/list_current_stock';
$route['list-Low-stock']='Prd_stocks/list_low_stock';


///this is to study particular wharehouse to save it and using with suggusted product

$route['study-stock-qnty']='Study_stock/study_stock_qnty';

$route['study-suggestion-stock']='Study_stock/new_sugussted_stock';
//this is for each product in the wharehouse 
$route['suggested-stock-qnty']='Study_stock/suggested_stock_qnty';


$route['stock-delivery-report/(:any)']='Prd_stocks/stock_delivery_report/$1';
//////////////////financial accounting//////
$route['sub-ledger']='Ledger/sub_ledger';
$route['manage-assets']='Manage_assets/manage_assets_lists';
//////////purchase controller/////////
$route['list-purchase-mrn']='Purchase_controller/list_mrn';
$route['add-purchase-mrn']='Purchase_controller/purchase_mrn_page';
$route['get_product_extras']='Purchase_controller/get_product_extras';

$route['list-purchase-invoice']='Purchase_controller/list_purchase_invoice';
$route['add-purchase-invoice']='Purchase_controller/purchase_invoice';

$route['list-purchase-return']='Purchase_controller/list_purchase_return';
$route['add-purchase-return']='Purchase_controller/purchase_return';

///gulf trade visitors //////
$route['gulf-trading-visitors']='Gulf_trading/create_form';
$route['gulf-trading-visitors-list']='Gulf_trading/list_form';

$route['logout']='Login_controller/logout';

//////this for task scheduler
$route['task-schedule']='Task_Scheduler/indextask';

//$route['Task_scheduler/submit_more_info_req']='Task_scheduler/submit_more_info_req';
$route['create-task']='Task_Scheduler/add_task_request';
$route['edit_task_request/(:num)']='Task_Scheduler/add_task_request/$1';
$route['change_task_req_sts/(:num)/(:num)']='Task_Scheduler/change_task_req_sts/$1/$2';
$route['item-task-status/(:num)']='Task_Scheduler/item_task_status/$1';
$route['submit_task_req']='Task_Scheduler/submit_task_req';
/////////designer dashboard/////
$route['Designer-dashboard']='Design_Controller/dashboard';
$route['change_img_req_sts/(:num)/(:num)']='Design_Controller/change_img_req_sts/$1/$2';
$route['auth_code']='Login_controller/authorize';


//assets managemant 


$route['add-new-assets']='Manage_assets/add_assets';
//price sync


$route['shopify-price-test/(:any)']='Prd_stocks/price_shopify/$1';

$route['list-check-new-price']='Prd_stocks/view_list_new_pricing';
