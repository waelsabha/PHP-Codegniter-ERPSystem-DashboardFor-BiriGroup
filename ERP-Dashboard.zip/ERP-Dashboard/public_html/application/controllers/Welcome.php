<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->library('numbertowordconvertsconver');			
		$this->load->model(array('Second_db_model','Sales_book_model'));
		$this->load->model('Third_db_model','tm');		
	}
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}

function all_notifications()
{
	if(logged_in())
	{
		$this->load->view('admin/all_notifications');
	}
}

	function manage_notification()
	{
		$activities_id=$this->input->post('nt_type_id');
		$activities_type=$this->input->post('nt_type');

if($this->session->userdata['user']['role'] =='1')
	{
		$this->Admin_model->update_data('activities',array('act_notification_sts_mngmnt'=>'0'),array('act_id'=>$activities_id));
	}
else
{
	$this->Admin_model->update_data('activities',array('act_notification_sts'=>'0'),array('act_id'=>$activities_id));
}
	if($activities_type=="po")
		{
			echo 'list-production';
		}
		elseif($activities_type=="quotation")
		{

			echo 'list-quotation';
		}
		elseif($activities_type=="item_req")
		{

			echo 'list-item-request';
		}
		elseif($activities_type=="survey")
		{

			echo 'list-survey-data';
		}
		elseif($activities_type=="installation")
		{

			echo 'list-installations';
		}
		else{}

	}










}
