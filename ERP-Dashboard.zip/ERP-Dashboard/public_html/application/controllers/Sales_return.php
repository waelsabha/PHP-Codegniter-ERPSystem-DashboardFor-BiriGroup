<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_return extends CI_Controller {

		public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','email_survey'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
		$this->load->library('numbertowordconvertsconver');		
		  $this->load->library('numbertowordconvertsconverksa');	
		$this->load->library('Numbertoworduk');	
		require 'vendor/autoload.php';
		require_once 'vendor/khaled.alshamaa/ar-php/src/Arabic.php';			
	}

function create_sales_return($dn=null)
{
	if(logged_in())
	{


        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='sales-return')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'sales-invoice'));
		$salesman=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales', 'log_status !='=>'0'));
		foreach($salesman as $s)
		{
			$data['salesman'][]=$this->Admin_model->get_data('employee_details',array('ed_login_id'=>$s->log_id));
		}
	
		$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent IN  (638,490)");////TO GET uae and ksa customres COMBINED
		$data['customers']=$sql_cust->result_array();
		$data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts'=>'1'));
		$data['price_level']=$this->Admin_model->get_data('master_price_level',array('mpc_sts'=>'1'));
		$data['region']=$this->Admin_model->get_data('master_region',array('mr_sts'=>'1'));
		$data['payment_method']=$this->Admin_model->get_data('master_payment_method',array('mpm_sts'=>'1'));

		$sql_sales_acc=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent IN  (616,619)");////TO GET uae and ksa customres COMBINED
		$data['sales_accont']=$sql_sales_acc->result_array();
		
		$data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));
		$data['place_supply']=$this->Admin_model->get_data('master_place_supply',array('mps_sts'=>'1'));
		$data['project']=$this->Admin_model->get_data('master_project',array('mpj_sts'=>'1'));

			if(empty($dn))
			{
			$val_recipt=$this->Admin_model->get_data('sales_return',array('srt_sts'=>'1'),'','','srt_id','DESC');
				if(empty($val_recipt))
				$data['doc_num']='SRT 1200';
					else
					{
					$bal_string1=str_replace("SRT ", "", $val_recipt[0]->srt_doc_no);
					//print_r($bal_string1);
				           $new_id_1=($bal_string1)+1;
				            $data['doc_num']="SRT ".$new_id_1;
					}
			}
	    $this->load->view('admin/transactions/sales_return',$data);

    }
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 



	}
}


function list_sales_return()
{
	
if(logged_in())
	{

        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='list-sales-return')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

					$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'list-sales-return'));
					$sql2=$this->db->query("SELECT sr.*,mat.label as cust_acc,mat2.mw_name,mc.mcomp_name
				FROM sales_return as sr  
				join master_accounts_tree as mat on mat.id=sr.srt_customer_acc_id
				join 	master_warehouse as mat2 on mat2.mw_id=sr.srt_warehouse 
					join master_company as mc on mc.mcomp_id=sr.srt_company 
				WHERE sr.srt_sts = '1' order by sr.srt_id DESC");
					$data['result']=$sql2->result_array();
						$this->load->view('admin/transactions/list_sales_return',$data);

   }
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 
	}
}


function get_cust_sales_inv()
{
	$cust_id=$this->input->post('cust_id');
	$page_type=$this->input->post('page_type');
	if($page_type=="uae")
	{
		$sql2=$this->db->query("SELECT delivery_note.*,sales_invoice.si_delivery_sts 
			FROM delivery_note  
			join sales_invoice on sales_invoice.si_id=delivery_note.dn_sales_inv_id
			WHERE sales_invoice.si_delivery_sts in('delivered','delivered_with_return','partially_delivered')  and delivery_note.dn_customer_acc_id='".$cust_id."' ");
		$dn_data=$sql2->result_array();
	}
	elseif($page_type=="ksa")
	{
		$sql2=$this->db->query("SELECT delivery_note_ksa.*,sales_invoice_ksa.si_delivery_sts 
			FROM delivery_note_ksa  
			join sales_invoice_ksa on sales_invoice_ksa.si_id=delivery_note_ksa.dn_sales_inv_id
			WHERE sales_invoice_ksa.si_delivery_sts  in('delivered','delivered_with_return','partially_delivered') and delivery_note_ksa.dn_customer_acc_id='".$cust_id."' ");
		$dn_data=$sql2->result_array();
	}
	elseif($page_type=="dragon")
	{
		$sql2=$this->db->query("SELECT delivery_note.*,sales_invoice.si_delivery_sts 
			FROM delivery_note_dragon  
			join sales_invoice on sales_invoice.si_id=delivery_note.dn_sales_inv_id
			WHERE sales_invoice.si_delivery_sts  in('delivered','delivered_with_return','partially_delivered') and delivery_note.dn_customer_acc_id='".$cust_id."' ");
		$dn_data=$sql2->result_array();
	}
	elseif($page_type=="export")
	{
		$sql2=$this->db->query("SELECT delivery_note.*,sales_invoice.si_delivery_sts 
			FROM delivery_note_export  
			join sales_invoice on sales_invoice.si_id=delivery_note.dn_sales_inv_id
			WHERE sales_invoice.si_delivery_sts in('delivered','delivered_with_return','partially_delivered') and delivery_note.dn_customer_acc_id='".$cust_id."' ");
		$dn_data=$sql2->result_array();
	}
	else{}	
		
		foreach($dn_data as $index=>$ai)
		{
			//print_r($index);
			$doc_num[]=$ai['dn_doc_no'];
			$date[]=$ai['dn_date'];
			$inv_id[]=$ai['dn_id'];
			$prds_ids[]=explode('|#|',$ai['dn_product']);
			$qnty[]=explode('|#|',$ai['dn_qnty']);
		}
	$ij=1;	
		$html="<div class='row'>
		<div class='col-md-12'>";
$html.="<table class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
			$html.="<thead>";
			$html.="<th></th>";
			$html.="<th>Document No.</th>";
			$html.="<th>Date</th>";
			$html.="<th>Particulars</th>";
			$html.="<th>Quantity</th>";
			// $html.="<th>Balance Amount</th>";
			$html.="</thead>";
			$html.="<tbody>";
		foreach($prds_ids as $ind=>$k)
		{
			foreach($k as $v1=>$v)
			{
				//print_r($rates[$ind][$v1]);
				 $prd_data=$this->tm->get_data('products',array('pid'=>$v));
				 $html.="<tr>";
		$html.="<td><input type='checkbox' name='choose_inv' value='".$inv_id[$ind].",".$v1."'></td>";
		$html.="<td><p>".$doc_num[$ind]."</p></td>";
		$html.="<td><p>".$date[$ind]."</p></td>";
		$html.="<td><p>".$prd_data[0]->pname."</p></td>";
		$html.="<td><p>".$qnty[$ind][$v1]."</p></td>";
		$html.="</tr>"; 
			$ij++;
			}
		}		
			$html.="</tbody>";
			$html.="</table>";
			$html.="</div>		
			</div>";
			echo $html;
}

function get_inv_details_checked()
	{
		$checked_vals=explode(',',$this->input->post('checked_inv'));
		$page_type=$this->input->post('page_type');
		$inv_id=$checked_vals[0];////here inv_id is from delivery_note
		$array_position=$checked_vals[1];

		if($page_type=="uae")
		{
		$get_dt_details=$this->Admin_model->get_data('delivery_note',array('dn_id'=>$inv_id));
		$get_inv_details=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$get_dt_details[0]->dn_sales_inv_id));
		}
		elseif($page_type=="ksa")
		{
				$get_dt_details=$this->Admin_model->get_data('delivery_note_ksa',array('dn_id'=>$inv_id));
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$get_dt_details[0]->dn_sales_inv_id));
		}
		elseif($page_type=="dragon")
		{		
			$get_dt_details=$this->Admin_model->get_data('delivery_note_dragon',array('dn_id'=>$inv_id));
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$get_dt_details[0]->dn_sales_inv_id));
		}
		elseif($page_type=="export")
		{
			$get_dt_details=$this->Admin_model->get_data('delivery_note_export',array('dn_id'=>$inv_id));
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$get_dt_details[0]->dn_sales_inv_id));
		}
		else{}
		//print_r($total_gross);
		//print_r($warehouses[$array_position]);
		$data=array(
			'warehouse'=>$get_dt_details[0]->dn_warehouse,
			'sales_ac_id'=>$get_inv_details[0]->si_sales_acc_id,
			'company'=>$get_inv_details[0]->si_company,
			'payment'=>$get_inv_details[0]->si_payment_type,
			'project'=>$get_inv_details[0]->si_project,			
			'salesman'=>$get_inv_details[0]->si_salesman,
			'mark'=>$get_inv_details[0]->si_mark,
			'narration'=>$get_inv_details[0]->si_narration,
			'pls_sup'=>$get_inv_details[0]->si_plc_supply,
			'jurisdiction'=>$get_inv_details[0]->si_jurisdiction,
			'currency'=>$get_inv_details[0]->si_currency,
			'currency_val'=>$get_inv_details[0]->si_conv_value,
			'tot_vat'=>$get_dt_details[0]->dn_vat_total,
			'tot_net'=>$get_dt_details[0]->dn_final_total,
			'sales_invoice_id'=>$get_inv_details[0]->si_id,
			'delivery_note_id'=>$get_dt_details[0]->dn_id,
		);
		echo json_encode($data);
	}

function get_inv_table_checked()
	{
		$checked_vals=explode(',',$this->input->post('checked_inv'));
		$inv_id=$checked_vals[0];
		$array_position=$checked_vals[1];
		$page_type=$this->input->post('page_type');
//echo $page_type;
		if($page_type=="uae")
		{
		$get_inv_details=$this->Admin_model->get_data('delivery_note',array('dn_id'=>$inv_id));
		$sales_inv_details=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$get_inv_details[0]->dn_sales_inv_id));
		}
		elseif($page_type=="ksa")
		{
				$get_inv_details=$this->Admin_model->get_data('delivery_note_ksa',array('dn_id'=>$inv_id));
		$sales_inv_details=$this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$get_inv_details[0]->dn_sales_inv_id));
		}
		elseif($page_type=="dragon")
		{		
			$get_inv_details=$this->Admin_model->get_data('delivery_note_dragon',array('dn_id'=>$inv_id));
		$sales_inv_details=$this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$get_inv_details[0]->dn_sales_inv_id));
		}
		elseif($page_type=="export")
		{
			$get_inv_details=$this->Admin_model->get_data('delivery_note_export',array('dn_id'=>$inv_id));
		$sales_inv_details=$this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$get_inv_details[0]->dn_sales_inv_id));
		}
		else{}
	//	print_r($get_inv_details);
	//print_r($sales_inv_details);
		$prd_ids=explode('|#|',$get_inv_details[0]->dn_product);
		$qntys=explode('|#|',$get_inv_details[0]->dn_qnty);
		$rates=explode('|#|',$get_inv_details[0]->dn_rate);
		$gross=explode('|#|',$get_inv_details[0]->dn_gross);
		$add_charges=explode('|#|',$get_inv_details[0]->dn_add_charges);
		$dis_charges=explode('|#|',$sales_inv_details[0]->si_dis_amount);
		$dis_per_charges=explode('|#|',$sales_inv_details[0]->si_dis_per);
		$fnet=explode('|#|',$get_inv_details[0]->dn_fnet);
		$vat=explode('|#|',$get_inv_details[0]->dn_vat);
		$tax_code=explode('|#|',$get_inv_details[0]->dn_tax_code);
		$delivery_date=explode('|#|',$get_inv_details[0]->dn_delivery_date);
		$warehouse=explode('|#|',$get_inv_details[0]->dn_warehouse);
		$ik=1;
		foreach($prd_ids as $ind=>$val)
		{
			if($ind==$array_position)
			{
			$gros_calc=$qntys[$ind]*$rates[$ind];

			if(!empty($add_charges[$ind]))
			$gross_add_charges=$add_charges[$ind];
			else
			$gross_add_charges=0;

			if(!empty($dis_per_charges[$ind]))
			$gross_desc_per=($gros_calc*($dis_per_charges[$ind]/100));
			else
			$gross_desc_per=0;

		if(!empty($dis_charges[$ind]))
			$gross_desc_charges=$dis_charges[$ind];
			else
			$gross_desc_charges=0;

		$total_gross_calc=$gros_calc+$gross_add_charges-$gross_desc_per-$gross_desc_charges;
		$vat_val_calc=$total_gross_calc*($vat[$ind]/100);
		$total_final_net=$total_gross_calc+$vat_val_calc;

				$prd_details=$this->tm->get_data('products',array('pid'=>$val));
				$unit_details=$this->tm->get_data('prd_units',array('pu_pid_focus'=>$prd_details[0]->prod_id_focus));
				$html='<tr>
			<td><input type="text" name="srt_product[]"  value="'.$prd_details[0]->pname.'"  step="any"  class="form-control "> <input type="hidden" name="each_prd[]" value="'.$prd_details[0]->pid.'"><input type="hidden" name="prd_index_position[]" value="'.$array_position.'"> </td>
			<td><input type="text" name="srt_desc[]"  value="'.$prd_details[0]->pname.'"  step="any"  class="form-control "> </td>';
			if(!empty($unit_details[0]->pu_base_unit))
			{
			 $html.= '<td><input type="text" name="srt_units[]"  value="'.$unit_details[0]->pu_base_unit.'"  step="any"  class="form-control"> </td>';
			}
			else
			{
				$html.= '<td><input type="text" name="srt_units[]"  value="Default"  step="any"  class="form-control"> </td>';
			}
			    $html.=' <td><input type="number" name="srt_qnty[]" onchange="get_new_qnty_val('.$ik.')"  value="'.$qntys[$ind].'"  step="any"  class="form-control qnty'.$ik.'"  oninput="maxLengthCheck(this)"   max="'.$qntys[$ind].'" min="0"><input type="hidden" name="org_qnty" value="'.$qntys[$ind].'"> </td>
			    <td><input type="text" readonly="" name="srt_label[]" value="'.$get_inv_details[0]->dn_doc_no.'"  step="any"  class="form-control"> </td>
			    <td><input type="number" name="srt_rate[]" value="'.$rates[$ind].'" step="any" readonly="" class="form-control rate'.$ik.'"> </td>
			    <td><input type="number" name="srt_gross[]" value="'.$gross[$ind].'" step="any"  readonly="" class="form-control gross'.$ik.'"></td>

			    <td><input type="number"  name="srt_dis_per[]" value="'.$dis_per_charges[$ind].'" readonly="" step="any"  class="form-control dis_per'.$ik.'"> <input type="hidden"  class="form-control dis_per_each_prd'.$ik.'" name="each_disc_per_amount[]" value="'.$gross_desc_per.'"></td>
			    <td><input type="number"  name="srt_dis_amount[]" value="'.$dis_charges[$ind].'" readonly="" step="any"  class="form-control dis_amount'.$ik.'"> </td>

			    <td><input type="number"  name="srt_add_charges[]" value="'.$add_charges[$ind].'" readonly="" step="any"  class="form-control add_charges'.$ik.'"> </td>
			    <td><input type="text"  name="srt_vat[]" class="form-control vat'.$ik.'" value="'.$vat[$ind].'" readonly="" ></td> 
			    <td><input type="number" name="srt_fnet[]"  value="'.$total_gross_calc.'"  step="any"  readonly="" class="form-control fnet'.$ik.'" >
			   	<input type="hidden" name="each_vat_total[]" class="form-control vat_each_prd_val'.$ik.'" value="'.$vat_val_calc.'">
			   	<input type="hidden" name="each_fnet_total[]" value="'.$total_gross_calc.'"><input type="hidden" name="each_fnet_total[]" value="'.$total_gross_calc.'">
			   </td> 
			    </tr>';
			   $data['html_result']=$html;
			   	echo json_encode($data);
			}
			$ik++;
		}
	}

function submit_sales_return($srt_id=null)
{
	if(logged_in())
{
		$edit_ret_id=$this->input->post('return_id');
		$page_type=$this->input->post('page_type');
		$array_index_pos=explode('|#|',$this->input->post('hi_aray_index_pos'));
		$main_date=$this->input->post('srt_date');
$main_date1=explode('/',$main_date);
			$month2=$main_date1[0];
			$date2=$main_date1[1];
			$year2=$main_date1[2];
$new_formated_date1=$year2.'-'.$month2.'-'.$date2;

$data['srt_user_created']=$this->session->userdata['user']['username'];
$data['srt_doc_no']=$this->input->post('srt_doc_no');
$data['srt_date']=$new_formated_date1;
$data['srt_customer_acc_id']=$this->input->post('srt_customer_acc_id');
$data['srt_sales_acc_id']=$this->input->post('srt_sales_acc_id');
$data['srt_company']=$this->input->post('srt_company');
$data['srt_project']=$this->input->post('srt_project');
$data['srt_salesman']=$this->input->post('srt_salesman');
$data['srt_payment_type']=$this->input->post('srt_payment_type');
$data['srt_narration']=$this->input->post('srt_narration');
$data['srt_mark']=$this->input->post('srt_mark');

$data['srt_dlvry_terms']=$this->input->post('srt_dlvry_terms');
$data['srt_plc_supply']=$this->input->post('srt_plc_supply');
$data['srt_jurisdiction']=$this->input->post('srt_jurisdiction');
$data['srt_currency']=$this->input->post('srt_currency');
$data['srt_conv_value']=$this->input->post('srt_conv_value');
$data['srt_warehouse']=$this->input->post('srt_warehouse');

$data['srt_product']=$this->input->post('hi_prd_id');
$data['srt_desc']=$this->input->post('hi_prd_desc');
$data['srt_qnty']=$this->input->post('hi_qnty');
$data['srt_units']=$this->input->post('hi_unit');
$data['srt_label']=$this->input->post('hi_label');
$data['srt_rate']=$this->input->post('hi_rate');
$data['srt_gross']=$this->input->post('hi_gross');
$data['srt_dis_per']=$this->input->post('hi_disc_per');
$data['srt_dis_amount']=$this->input->post('hi_disc_charges');
$data['srt_add_charges']=$this->input->post('hi_add_charges');
$data['srt_vat']=$this->input->post('hi_vat');
$data['srt_fnet']=$this->input->post('hi_fnet');
$data['srt_vat_total']=$this->input->post('srt_tot_vat');
$data['srt_final_total']=$this->input->post('srt_tot_amount');
$data['srt_sts']='1';
//we will add new column to sales return table that help us to detremine approval
$data['srt_po_sts']='1';
$data['srt_po_warehouserep']='1';
$data['srt_dl_id']=$this->input->post('dl_id');

if(empty($edit_ret_id))////willl insert
	{
		$document_bal_number=str_replace("SRT ", "", $this->input->post('srt_doc_no'));
		$data['srt_doc_number']=$document_bal_number;
	}

				if($page_type=="uae")
				{
					$dlvry_details=$this->Admin_model->get_data('delivery_note',array('dn_id'=>$this->input->post('dl_id')));
			$dlvry_stock_details=$this->Admin_model->get_data('stock_delivery_details',array('sd_delivered_id'=>$this->input->post('dl_id')) );
				}
				if($page_type=="ksa")
				{
					$dlvry_details=$this->Admin_model->get_data('delivery_note_ksa',array('dn_id'=>$this->input->post('dl_id')));
			$dlvry_stock_details=$this->Admin_model->get_data('stock_delivery_details_ksa',array('sd_delivered_id'=>$this->input->post('dl_id')) );
				}
				if($page_type=="dragon")
				{
					$dlvry_details=$this->Admin_model->get_data('delivery_note_dragon',array('dn_id'=>$this->input->post('dl_id')));
			$dlvry_stock_details=$this->Admin_model->get_data('stock_delivery_details_dragon',array('sd_delivered_id'=>$this->input->post('dl_id')) );
				}
				if($page_type=="export")
				{
					$dlvry_details=$this->Admin_model->get_data('delivery_note_export',array('dn_id'=>$this->input->post('dl_id')));
			$dlvry_stock_details=$this->Admin_model->get_data('stock_delivery_details_export',array('sd_delivered_id'=>$this->input->post('dl_id')) );
				}
				else{}

		$dlvry_prd=explode('|#|',$dlvry_details[0]->dn_product);
		$dlvry_units=explode('|#|',$dlvry_details[0]->dn_units);
		$dlvry_label=explode('|#|',$dlvry_details[0]->dn_label);
		$dlvry_qnty=explode('|#|',$dlvry_details[0]->dn_qnty);
		$dlvry_rate=explode('|#|',$dlvry_details[0]->dn_rate);
		$dlvry_gross=explode('|#|',$dlvry_details[0]->dn_gross);
		$dlvry_add_charges=explode('|#|',$dlvry_details[0]->dn_add_charges);
		$dlvry_vat=explode('|#|',$dlvry_details[0]->dn_vat);
		$dlvry_fnet=explode('|#|',$dlvry_details[0]->dn_fnet);
$srt_prd_id=explode('|#|',$this->input->post('hi_prd_id'));
$srt_qnty=explode('|#|',$this->input->post('hi_qnty'));
$srt_rate=explode('|#|',$this->input->post('hi_rate'));
$srt_gross=explode('|#|',$this->input->post('hi_gross'));
$srt_fnet=explode('|#|',$this->input->post('hi_fnet'));
$srt_vat=explode('|#|',$this->input->post('hi_vat'));
$srt_add_charges=explode('|#|',$this->input->post('hi_add_charges'));

$sales_invoice_id=$this->input->post('sales_inv_id');
// pre_list($dlvry_prd);
// pre_list($array_index_pos);
	$ref_sales_inv_id=array_filter(explode('|#|',$this->input->post('ref_sales_inv_id')));
	$ref_sales_inv_amount=array_filter(explode('|#|',$this->input->post('ref_sales_inv_amount')));
	$ref_sales_inv_amount_paid=array_filter(explode('|#|',$this->input->post('ref_sales_inv_amount_paid')));
	$ref_sales_doc_num=array_filter(explode('|#|',$this->input->post('ref_sales_doc_num')));
	$tot_inv_amount_paid_from_ref=array_sum($ref_sales_inv_amount_paid);

		$qnty_details=explode('|#|',$this->input->post('hi_qnty'));

$insert_id=$this->Admin_model->insert_data('sales_return',$data);
	//$insert_id='12';
		foreach($array_index_pos as $indx=>$v)///comparing index as value to value
		{
			//print_r($v);print_r($dlvry_prd[$v]);
			if(array_key_exists($v,$dlvry_prd))
			{
				if($srt_qnty[$indx]==$dlvry_qnty[$v])
				{
					unset($dlvry_prd[$v]);
					unset($dlvry_units[$v]);
					unset($dlvry_label[$v]);
					unset($dlvry_qnty[$v]);
					unset($dlvry_rate[$v]);
					unset($dlvry_gross[$v]);
					unset($dlvry_add_charges[$v]);
					unset($dlvry_vat[$v]);
					unset($dlvry_fnet[$v]);
				}
				elseif($srt_qnty[$indx]<$dlvry_qnty[$v])
				{	
					$dlvry_qnty[$v]=$dlvry_qnty[$v]-$srt_qnty[$indx];
					$dlvry_gross[$v]=$dlvry_qnty[$v]*$dlvry_rate[$v];
					if(!empty($srt_add_charges[$indx]))
					{
						$dlvry_fnet[$v]=$dlvry_gross[$v]+$dlvry_add_charges[$v];
					}
					else
					{
						$dlvry_fnet[$v]=$dlvry_gross[$v];
					}	
				}
				else
				{}
			$stock_dlvry_details_id[]=$dlvry_stock_details[$v]->sd_id;///the id from stock details table , in which the return value is affected	
			}
		}
	
foreach($stock_dlvry_details_id as $indx=>$sd)//ths will update stock details table as per the stock returned index
{	
	if($page_type=="uae")
				{
	$this->Admin_model->update_data('stock_delivery_details',array('sd_qnty_returned'=>$srt_qnty[$indx],'sd_return_id'=>$insert_id),array('sd_id'=>$sd));
				}
				if($page_type=="ksa")
				{
	$this->Admin_model->update_data('stock_delivery_details_ksa',array('sd_qnty_returned'=>$srt_qnty[$indx],'sd_return_id'=>$insert_id),array('sd_id'=>$sd));
				}
				if($page_type=="dragon")
				{
$this->Admin_model->update_data('stock_delivery_details_dragon',array('sd_qnty_returned'=>$srt_qnty[$indx],'sd_return_id'=>$insert_id),array('sd_id'=>$sd));
				}
				if($page_type=="export")
				{
$this->Admin_model->update_data('stock_delivery_details_export',array('sd_qnty_returned'=>$srt_qnty[$indx],'sd_return_id'=>$insert_id),array('sd_id'=>$sd));
				}
				else{}
}

foreach($dlvry_prd as $indx=>$dp)
{
	$new_vat= $dlvry_gross[$indx]*($dlvry_vat[$indx]/100);
	$new_vat_value[]=$new_vat;
	$new_fnet=$dlvry_fnet[$indx]+$new_vat;
	$new_fnet_value[]=$new_fnet;
}

$new_delivery_data=array(
	'dn_product'=>implode('|#|',$dlvry_prd),
	'dn_qnty'=>implode('|#|',$dlvry_qnty),
	'dn_rate'=>implode('|#|',$dlvry_rate),
	'dn_gross'=>implode('|#|',$dlvry_gross),
	'dn_add_charges'=>implode('|#|',$dlvry_add_charges),
	'dn_fnet'=>implode('|#|',$dlvry_fnet),
	'dn_vat'=>implode('|#|',$dlvry_vat),	
	'dn_vat_total'=>array_sum($new_vat_value),
	'dn_final_total'=>array_sum($new_fnet_value),
);
//pre_list($new_delivery_data);
if($page_type=="uae")
			{
				$this->Admin_model->update_data('delivery_note',$new_delivery_data,array('dn_id'=>$this->input->post('dl_id')));
					if(empty(array_filter($dlvry_qnty)))
					{
						$this->Admin_model->update_data('sales_invoice',array('si_delivery_sts'=>'fully_returned','si_fullreturn_sts'=>'1'),array('si_id'=>$sales_invoice_id));
					}
					else
					{
						$this->Admin_model->update_data('sales_invoice',array('si_delivery_sts'=>'partially_returned','si_fullreturn_sts'=>'2'),array('si_id'=>$sales_invoice_id));
					}
			}
			elseif($page_type=="ksa")
			{
				$this->Admin_model->update_data('delivery_note_ksa',$new_delivery_data,array('dn_id'=>$this->input->post('dl_id')));
					if(empty(array_filter($dlvry_qnty)))
					{
						$this->Admin_model->update_data('sales_invoice_ksa',array('si_delivery_sts'=>'fully_returned','si_fullreturn_sts'=>'1'),array('si_id'=>$sales_invoice_id));
					}
					else
					{
					$this->Admin_model->update_data('sales_invoice_ksa',array('si_delivery_sts'=>'partially_returned','si_fullreturn_sts'=>'2'),array('si_id'=>$sales_invoice_id));
					}
			}
			elseif($page_type=="dragon")
			{
				$this->Admin_model->update_data('delivery_note_dragon',$new_delivery_data,array('dn_id'=>$this->input->post('dl_id')));
				if(empty(array_filter($dlvry_qnty)))
				{
					$this->Admin_model->update_data('sales_invoice_dragon',array('si_delivery_sts'=>'fully_returned','si_fullreturn_sts'=>'1'),array('si_id'=>$sales_invoice_id));
				}
				else
				{
					$this->Admin_model->update_data('sales_invoice_dragon',array('si_delivery_sts'=>'partially_returned','si_fullreturn_sts'=>'2'),array('si_id'=>$sales_invoice_id));
				}	
			}
			elseif($page_type=="export")
			{
				$this->Admin_model->update_data('delivery_note_export',$new_delivery_data,array('dn_id'=>$this->input->post('dl_id')));
					if(empty(array_filter($dlvry_qnty)))
					{
						$this->Admin_model->update_data('sales_invoice_export',array('si_delivery_sts'=>'fully_returned','si_fullreturn_sts'=>'1'),array('si_id'=>$sales_invoice_id));
					}
					else
					{
						$this->Admin_model->update_data('sales_invoice_export',array('si_delivery_sts'=>'partially_returned','si_fullreturn_sts'=>'2'),array('si_id'=>$sales_invoice_id));
					}
			}
			else{}



 //Get All Shopify Product 
		if($page_type=="uae")	
		{			
  $shopify_products = json_decode( file_get_contents('https://3527ef9b39427d1d11184c88b2940757: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@biri-group.myshopify.com/admin/api/2022-10/products.json'));
	//$shopify_products = json_decode($shopify_products);
	//print_r($shopify_products);

	////test end ////
	foreach($shopify_products->products as $key => $shopify_product)
	{
		
		$sku_array[$key]=$shopify_product->variants[0]->sku;
		$inventory_array[$key]=$shopify_product->variants[0]->inventory_quantity;
		$inventory_item_array[$key]=$shopify_product->variants[0]->inventory_item_id;
		
	}

	$headerss = array(
		'X-Shopify-Access-Token: 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',
		'Content-Type: application/json'
		
	);
		// // Get the location ID for the inventory level update
					$location_url = 'https://biri-group.myshopify.com/admin/api/2022-10/locations.json';
					//$location_response = shopify_api_call('GET', $location_url, array(), $headers);
					$inventory_url ='https://biri-group.myshopify.com/admin/api/2022-10/inventory_levels/set.json';

					$curl = curl_init();
					curl_setopt($curl, CURLOPT_URL, $location_url);
					curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
					curl_setopt($curl, CURLOPT_HTTPHEADER, $headerss);
					curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
					$location_response = curl_exec($curl);
					curl_close($curl);
					$test3=json_decode($location_response);
					$location_id = $test3->locations[1]->id; // Replace 0 with the index of the location you want to use
				}	   
	////////end shopify setting /////////////////////////////////////








foreach($srt_prd_id as $indx_srt=>$sales_return_pid)
{
	$stock_details_data_stock_table=$this->tm->get_data('stock_details',array('sd_prd_id'=>$sales_return_pid,'sd_warehouse_id'=>$this->input->post('srt_warehouse')));
	
	$avlb_stock=$stock_details_data_stock_table[0]->sd_stock_qnty+$srt_qnty[$indx_srt];
	$this->tm->update_data('stock_details',array('sd_stock_qnty'=>$avlb_stock),array('sd_id'=>$stock_details_data_stock_table[0]->sd_id));



   ////////start shopify part1/////
                                   //For Inserting New Quantity when update dashboard inventory

									////here must to get the Sku product
									if($page_type=="uae")
									{
									$sku_prod=$stock_product_id_sku[0]->pcode;

												foreach($sku_array as $key_key => $sku)
												{
													if($sku==$sku_prod)
												{
													print_r('yes');
													$nventory_item[]=$inventory_item_array[$key_key];
													$avlb_stock_arr[]=$avlb_stock;
											}
											else{
												print_r('NO');
											}
											}
                                     }
                                 ////////////////////end shopify part1///////////////////


	
}

       ////////////////start sopify part 2////////////////////////
	   if($page_type=="uae"){
	if(!empty($nventory_item)){
		foreach($nventory_item as $ke=>$inventory_item_idn)
	{
			   $inventory_item_id=$inventory_item_idn;				
			   $datashop[$ke] = array(
	   'location_id' => $location_id,
	   'inventory_item_id' => $inventory_item_id,
		   'available' => $avlb_stock_arr[$ke] // Replace with the new inventory level
	   );

	   $curl = curl_init();
	   curl_setopt($curl, CURLOPT_URL, $inventory_url);
	   curl_setopt($curl, CURLOPT_CUSTOMREQUEST,'POST');
	   curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($datashop[$ke]));
	   curl_setopt($curl, CURLOPT_HTTPHEADER, $headerss);
	   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	   $responsess = curl_exec($curl);
	   curl_close($curl);
   }	
}
}
/////////////////////end sopify part 2/////////////////////////////////////////

	if(!empty($insert_id) || !empty($edit_inv_id) )
		{
			if(!empty($insert_id))
			{
				$sales_id_inv_id=$insert_id;
			}
			elseif (!empty($edit_inv_id)) 
			{
				$sales_id_inv_id=$edit_inv_id;
			}
			else
			{
				$sales_id_inv_id='';
			}
			if(!empty($sales_id_inv_id))
			{
		/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////	
					$data_tx['atx_user_created']=$this->session->userdata['user']['username'];
					$data_tx['atx_type_tx']='Sales_Return';
					$data_tx['atx_date']=$new_formated_date1;
					$data_tx['atx_doc_no']=$this->input->post('srt_doc_no');
					$data_tx['atx_main_id']=$sales_id_inv_id;
					$data_tx['atx_acc_id']=$this->input->post('srt_sales_acc_id');
					$data_tx['atx_cust_id']=$this->input->post('srt_customer_acc_id');
					$data_tx['atx_tot_amount']=$this->input->post('srt_tot_amount');
					$data_tx['atx_vat_amount']=$this->input->post('srt_tot_vat');
					$data_tx['atx_region']=$page_type;
					$data_tx['atx_narration']=$this->input->post('srt_narration');
					$data_tx['atx_quantity']=array_sum($qnty_details);
					$data_tx['atx_salesman']=$this->input->post('srt_salesman');
					$data_tx['atx_currency_value']=$this->input->post('srt_conv_value');
					$data_tx['atx_currency_type']=$this->input->post('srt_currency');

				// if(empty($edit_inv_id))////
				// 	$data_tx['atx_paid_amount']='0';////
				if(!empty(array_sum($ref_sales_inv_amount_paid)))
							{
								//echo "inside the sales inv paid";echo "<br/>";
								//print_r($ref_sales_inv_amount_paid);
							//echo "inside last if";echo "<br/>";
								$data_final_bal_amount=$this->input->post('srt_tot_amount')-array_sum($ref_sales_inv_amount_paid);
								//print_r($data_final_bal_amount);echo "<br/>";
								$data_tx['atx_bal_amount']=$data_final_bal_amount;
								$data_tx['atx_paid_amount']=array_sum($ref_sales_inv_amount_paid);
							}
							else
							{
								$data_tx['atx_bal_amount']=$this->input->post('srt_tot_amount');
								$data_tx['atx_paid_amount']='0';
							}	

					$data_tx['atx_dt_updt']=get_date_time();
					$data_tx['atx_sts']='1';
					$data_tx['atx_amount_type']='Expense';
				
		if(!empty($edit_inv_id))////if edit selected, then update the tx table details 
			{
				// echo "in if - with edit id";
			$this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_main_id'=>$edit_inv_id,'atx_doc_no'=>$this->input->post('srt_doc_no'),'atx_type_tx'=>'Sales_Return'));
				//pre_list($data_tx);
				// print_r($current_sales_inv_amount[0]->atx_id);
				$insert_id_acc_tx=$current_sales_inv_amount[0]->atx_id;
			}
			else
			{
				//echo "in else - no edit id";
				//pre_list($data_tx);
				$insert_id_acc_tx=$this->Admin_model->insert_data('account_all_tx',$data_tx);
			}
		
			foreach($ref_sales_inv_id as $index=>$si)
			{		
			if(!empty($ref_sales_inv_amount_paid[$index]))
				{
					if(!empty($ref_sales_inv_amount_paid[$index]))
					{
						$amount_paid_till_now=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$si));
				  		$bal_amount_sales_inv=$ref_sales_inv_amount[$index]-$ref_sales_inv_amount_paid[$index];
				  		
				  		$data_si_array=array(
				  			'atx_paid_amount'=>$amount_paid_till_now[0]->atx_paid_amount+$ref_sales_inv_amount_paid[$index],
				  			'atx_bal_amount'=>$bal_amount_sales_inv,
				  		);
				 // print_r($data_si_array);
				 // print_r($si);
			  	$this->Admin_model->update_data('account_all_tx',$data_si_array,array('atx_id'=>$si));  

				$data_tx_bal=array(
					'actb_tx_id'=>$insert_id_acc_tx,
					'actb_to_type'=>$ref_sales_doc_num[$index],
					'actb_paid_amount'=>$ref_sales_inv_amount_paid[$index],
					'actb_to_id'=>$si,
					'actd_sts'=>'1',
					'actb_user_created'=>$this->session->userdata['user']['username'],
				);	
			// print_r($data_tx_bal);
				$this->Admin_model->insert_data('account_tx_bal_data',$data_tx_bal);
					}
				}
			} 

			if($page_type=="uae")
				{
			$sales_invoice_id_details=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$sales_invoice_id));
				}
				if($page_type=="ksa")
				{
			$sales_invoice_id_details=$this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$sales_invoice_id));
				}
				if($page_type=="dragon")
				{
			$sales_invoice_id_details=$this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$sales_invoice_id));
				}
				if($page_type=="export")
				{
			$sales_invoice_id_details=$this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$sales_invoice_id));
				}
				else{}

		if($sales_invoice_id_details[0]->si_vat_type=="1")////taxable invoice
		{
			if($page_type=="uae")
						{
							$vat_acc_id_to_use='1014';/////if vat os other customers, normal vat output a/c is affected///////
						}
						elseif($page_type=="ksa")
						{
							$vat_acc_id_to_use='759';/////if vat os other customers, normal vat output a/c is affected///////
						}
						elseif($page_type=="dragon")
						{
							$vat_acc_id_to_use='1016';////if customer is dragon-sales cust, need to affect the vat of dragon sales/////
						}
						else{}
			  /////////////////vat o/p account data //////////////////			 	
					$data_tx['atx_user_created']=$this->session->userdata['user']['username'];
					$data_tx['atx_type_tx']='Vat_OP';
					$data_tx['atx_date']=$new_formated_date1;
					$data_tx['atx_doc_no']=$this->input->post('srt_doc_no');
					$data_tx['atx_main_id']=$sales_id_inv_id;
					$data_tx['atx_acc_id']=$vat_acc_id_to_use;
					$data_tx['atx_cust_id']=$this->input->post('srt_customer_acc_id');
					$data_tx['atx_tot_amount']=$this->input->post('srt_tot_vat');
					$data_tx['atx_paid_amount']='0';
					$data_tx['atx_bal_amount']=$this->input->post('srt_tot_vat');
					$data_tx['atx_dt_updt']=get_date_time();
					$data_tx['atx_sts']='1';
					$data_tx['atx_amount_type']='Expense';
					$data_tx['atx_tranfer_type']='sales_return';

					$data_tx['atx_region']=$page_type;
					$data_tx['atx_narration']=$this->input->post('srt_narration');
					$data_tx['atx_quantity']=array_sum($qnty_details);
					$data_tx['atx_salesman']=$this->input->post('srt_salesman');
					$data_tx['atx_currency_value']=$this->input->post('srt_conv_value');
					$data_tx['atx_currency_type']=$this->input->post('srt_currency');

					
				if(!empty($edit_inv_id))
				{	
					// echo "inside if - vat";
					// pre_list($data_tx);
					$this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_main_id'=>$edit_inv_id,'atx_doc_no'=>$this->input->post('si_doc_no'),'atx_type_tx'=>'Vat_OP' ));
				}
				else
				{
					// echo "inside else - vat";
					// pre_list($data_tx);
			$insert_id_acc_vat_tx=$this->Admin_model->insert_data('account_all_tx',$data_tx);
				}
		} 		
	 	$this->session->set_flashdata('success', 'Data sucessfully entered.');
		/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////
		}
		else
		{
		 $this->session->set_flashdata('errors', 'Error on data found. Please try again.');
		}
	}
	////////////ending if for checking insert_id exist here////////////////////////////////////////////////
 redirect('list-sales-return');
}
}

function get_cust_pop_up_ref()
{
	$cust_id=$this->input->post('cust_id');
	$cust_paid_amount=$this->input->post('cust_amount_paid');
	$account_id=$this->input->post('ac_tx_id');/////////used or will get at the time of edit function///////////// 
	//pre_list($account_id);
	if(!empty($account_id))
	{	
	$account_tx_details=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$account_id,'atx_sts'=>'1'));
	$acc_tx_bal_data=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_details[0]->atx_id,'actd_sts'=>'1'));
//pre_list($acc_tx_bal_data);
		foreach($acc_tx_bal_data as $to_id)
		{
			$to_id_details[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$to_id->actb_to_id,'atx_sts'=>'1'));
		}
	$cust_id=$account_tx_details[0]->atx_cust_id;
	}
	$sql2=$this->db->query("SELECT * FROM account_all_tx where atx_cust_id=".$cust_id." and atx_type_tx IN ('Payments','Petty_Cash','PDP','Sales_Invoice','JRN_Debit') and atx_bal_amount!='0' and atx_sts='1' ");
		$cust_sales=$sql2->result_array();

		$ij=1;$kl=551;
		$html="
		<div class='row'>
		<div class='col-md-12'>
		<div class='col-md-10'>
		<span class='pull-left'>";
		if(!empty($account_id))
		{	
		if(empty($acc_tx_bal_data))
			{
				$tot_amount_ref=$account_tx_details[0]->atx_tot_amount;
			}
			else
			{
				$tot_amount_ref='0';
			}
		}
		else
		{
			$tot_amount_ref='0';
		}
$html.="<input type='text'  class='refrence_amount' value='".$tot_amount_ref."' name='refrence'><br/><p>Add as new reference </p></span><br/>
		
		<table class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
			$html.="<thead>";
			$html.="<th></th>";
			$html.="<th>Reference</th>";
			$html.="<th>Due-Date</th>";
			$html.="<th>Bill Amount</th>";
			$html.="<th>Amount Adjusted</th>";
			// $html.="<th>Balance Amount</th>";
			$html.="</thead>";
			$html.="<tbody>";
	// if(!empty($to_id_details))
	// {
	// 	foreach($to_id_details as $tid)
	// 	{
	// 		//pre_list($tid);
	// 		$array_atx_id[]=$tid[0]->atx_id;
	// 	$html.="<tr>";
	// 	$html.="<td><input name='cust_id_modal' type='hidden' value='".$tid[0]->atx_cust_id."'>
	// 	<input type='checkbox' class='class_checkbox inv_selected_".$kl."' onclick='pass_param();' value='".$kl."' name='inv_selected[]'>
	// 	</td>";
	// 		$html.="<td><input name='inv_id_modal[]' type='hidden' value='".$tid[0]->atx_id."'><input name='inv_doc_numbers_modal[]' class='ref_doc_numbers_".$kl."' type='hidden' value='".$tid[0]->atx_doc_no."'>".$tid[0]->atx_doc_no."</td>";

	// 		if(empty($account_id))
	// 		{
	// 		if(empty($tid[0]->atx_paid_amount))
		//		{
					// if($tid[0]->atx_type_tx=="Sales_Invoice" )
					// {
					// 	$tot_amount_to_show=$tid[0]->atx_tot_amount;
					// }
					// else
					// {
					// 	if(!empty($tid[0]->atx_vat_amount))
					// 	$tot_amount_to_show=$tid[0]->atx_tot_amount+$tid[0]->atx_vat_amount;
					// 	else
					// 	$tot_amount_to_show=$tid[0]->atx_tot_amount+0;
					// }
		//		}
	// 		else
		//		{
	// 			$tot_amount_to_show=$tid[0]->atx_bal_amount;
		//		}
	// 		}
	// 		else
	// 		{
	// 			if(empty($acc_tx_bal_data[0]->atx_bal_amount))
	// 			{
					// if($account_tx_details[0]->atx_type_tx=="Sales_Invoice" )
					// {
					// 	$tot_amount_to_show=$account_tx_details[0]->atx_tot_amount;
					// }
					// else
					// {
					// 	if(!empty($account_tx_details[0]->atx_vat_amount))
					// 	$tot_amount_to_show=$account_tx_details[0]->atx_tot_amount+$account_tx_details[0]->atx_vat_amount;
					// 	else
					// 	$tot_amount_to_show=$account_tx_details[0]->atx_tot_amount+0;
					// }	
	// 			}
	// 			else
	// 			{
	// 				$tot_amount_to_show=$acc_tx_bal_data[0]->atx_bal_amount;
	// 			}
	// 		}

	// 		$html.="<td><input name='sales_inv_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_amount_".$kl." org_amounts'><br/>
	// 		<p>Total Amount:".$tid[0]->atx_tot_amount."</p>
	// 		</td>";
	// 		if(empty($account_id))
	// 		{
	// 		$html.="<td><input name='paid_amount_modal[]' type='number' step='any' value='0' min='0' max='".$tot_amount_to_show."' onchange='check_val_less_than_amount(".$kl.");' class='tot_sales_amount_paid_".$kl."'><br/>";
	// 		}
	// 		else
	// 		{
	// 		$html.="<td><input name='paid_amount_modal[]' type='number' step='any' value='".$account_tx_details[0]->atx_paid_amount."' min='0' max='".$account_tx_details[0]->atx_paid_amount."' onchange='check_val_less_than_amount(".$kl.");' class='tot_sales_amount_paid_".$kl."'><br/>";	
	// 		}
		
	// 		$html.="<br/><small class='amount_overdue_".$kl." text_data_issue' style='color:red;'></small>
	// 		</td>";
	// 		// $html.="<td>
	// 		// <input name='sales_inv_bal_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_bal_amount_".$ij."'>
	// 		// </td>";
	// 		$html.="</tr>"; 
	// 		$kl++;
	// 	}
	// 	}	
	if(!empty($cust_sales))
	{
		foreach($cust_sales as $civ)
		{
			$html.="<tr>";
		$html.="<td><input name='cust_id_modal' type='hidden' value='".$cust_id."'>
		<input type='checkbox' class='class_checkbox inv_selected_".$ij."' onclick='pass_param();' value='".$ij."' name='inv_selected[]'>
		</td>";
			$html.="<td><input name='inv_id_modal[]' type='hidden' value='".$civ['atx_id']."'><input name='inv_doc_numbers_modal[]' class='ref_doc_numbers_".$ij."' type='hidden' value='".$civ['atx_doc_no']."'>".$civ['atx_doc_no']."</td>";

			$html.="<td>".$civ['atx_date']."</td>";
			if(empty($civ['atx_paid_amount']))
			{
				if($civ['atx_type_tx']=="Sales_Invoice" )
					{
						$tot_amount_to_show=$civ['atx_tot_amount'];
					}
					else
					{
						if(!empty($civ['atx_vat_amount']))
						$tot_amount_to_show=$civ['atx_tot_amount']+$civ['atx_vat_amount'];
						else
						$tot_amount_to_show=$civ['atx_tot_amount']+0;
					}
			}
			else
			{
				$tot_amount_to_show=$civ['atx_bal_amount'];
			}

			$html.="<td><input name='sales_inv_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_amount_".$ij." org_amounts'><br/>
			<p>Total Amount:".$civ['atx_tot_amount']."</p>
			</td>";
			
			$html.="<td><input name='paid_amount_modal[]' type='number' step='any' value='0' min='0' max='".$tot_amount_to_show."' onchange='check_val_less_than_amount(".$ij.");' class='tot_sales_amount_paid_".$ij."'><br/>
		
			<br/><small class='amount_overdue_".$ij." text_data_issue' style='color:red;'></small>
			</td>";
			// $html.="<td>
			// <input name='sales_inv_bal_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_bal_amount_".$ij."'>
			// </td>";
			$html.="</tr>"; 
			$ij++;
		}
		}	
		$html.="</tbody>";
			$html.="</table>";
			$html.="</div>		
<div class='col-md-2'>
<button class='btn btn-primary pull-right get_pick_amount' onclick='get_pick_amount();'>Pick Amount</button>
</div>
</div>
<div class='col-md-12'>
	<div class='col-md-4'>";
	if(!empty($cust_paid_amount))
	$html.="<p> Amount to adjust:<span class='amount_to_adj'>".$cust_paid_amount."</span></p>";
	else
	$html.="<p> Amount to adjust:<span class='amount_to_adj'>0</span></p>";
	$html.="</div>
	<div class='col-md-4'>
	<p> Amount adjusted:<span class='amount_adjusted'>0</span></p>
	</div>
	<div class='col-md-4'>
	<p>To be adjusted:<span class='to_be_adjust'>0</span></p>
	</div>";

	$html.="<div class='col-md-12'>
	<p><button class='btn btn-danger' type='button' onclick='reset_fields()'>Reset Fields</button></p>
	</div>";

$html.="</div>
		</div>	";

			echo $html;	
}


function get_doc_details()
{
	$cbr_id=$this->input->post('main_id');
	
$dataa=$this->Admin_model->get_data('sales_return',array('srt_id'=>$cbr_id));
	
		if($dataa)
			{
				$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->srt_company));
				$sales_acc=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->srt_sales_acc_id));
				$cust_acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->srt_customer_acc_id));
				$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->srt_currency));
				$price_level=$this->Admin_model->get_data('master_price_level',array('mpc_id'=>$dataa[0]->srt_pc_level));
				$salesman=$this->Admin_model->get_data('employee_details',array('ed_id'=>$dataa[0]->srt_salesman));
				$payment_type=$this->Admin_model->get_data('master_payment_method',array('mpm_id'=>$dataa[0]->srt_payment_type));
				$country=$this->Admin_model->get_data('master_region',array('mr_id'=>$dataa[0]->srt_country));
				$place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->srt_plc_supply));
				$jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->srt_jurisdiction));
				$warehouse= $this->Admin_model->get_data('master_warehouse',array('mw_id'=>$dataa[0]->srt_warehouse));

				$account_tx_data=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_type_tx'=>'Sales_Return'));
				if(!empty($account_tx_data))
				{
					$account_bal_data_1=$this->Admin_model->get_data('account_tx_bal_data',array('actb_to_id'=>$account_tx_data[0]->atx_id));
					if(!empty($account_bal_data_1))
					{
						foreach($account_bal_data_1 as $abd)
						{
							$tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_tx_id));
						}
					}
					else
					{
						$account_bal_data_2=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_data[0]->atx_id));
						if(!empty($account_bal_data_2))
						{
							foreach($account_bal_data_2 as $abd)
							{
								$tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_to_id));
							}	
						}
					}
				}
			
				$prd_list=explode('|#|',$dataa[0]->srt_product);
				foreach($prd_list as $pl)
				{
					$data_pl[]=$this->tm->get_data('products',array('pid'=>$pl));
				}

				$qnty_list=explode('|#|',$dataa[0]->srt_qnty);
				$rate_list=explode('|#|',$dataa[0]->srt_rate);

				$desc_list=explode('|#|',$dataa[0]->srt_desc);
				$label_list=explode('|#|',$dataa[0]->srt_label);
				$unit_list=explode('|#|',$dataa[0]->srt_units);

				$gross_list=explode('|#|',$dataa[0]->srt_gross);
				$disc_per_list=explode('|#|',$dataa[0]->srt_dis_per);
				$disc_amount_list=explode('|#|',$dataa[0]->srt_dis_amount);
				$add_charges_list=explode('|#|',$dataa[0]->srt_add_charges);
				$fnet_list=explode('|#|',$dataa[0]->srt_fnet);
				$vat_list=explode('|#|',$dataa[0]->srt_vat);
					$rmk_list=explode('|#|',$dataa[0]->srt_remrk);
					$tax_list=explode('|#|',$dataa[0]->srt_tax_code);
					$delivery_date_list=explode('|#|',$dataa[0]->srt_delivery_date);

					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Sales Invoice Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->srt_doc_no."</p>";
					$html.="<p>User Created: ".$dataa[0]->srt_user_created."</p>";
					$html.="<p>Date: ".$dataa[0]->srt_date."</p>";
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					$html.="<p>Vat Type: ";
					if($dataa[0]->si_vat_type=='1')
					{
						$vat_tyype='Taxable';
					}
					else
					{
						$vat_tyype='Non-Taxable';
					}
					$html.=$vat_tyype;
					$html.="</p>";

					$html.="<p style='color:blue'><b>Linked to :</b></p>";
					if(!empty($tx_data_related))
					{
						foreach($tx_data_related as $tx)
						{
							$html.="<p style='color:blue'>".$tx[0]->atx_doc_no."</p>";
						}
					}	

					if(!empty($label_list))
					{
						foreach($label_list as $ll)
						{
							$html.="<p style='color:blue'>".$ll."</p>";
						}
					}
					$html.="</div>";

					$html.="<div class='col-md-4'>";
				
					$html.="<p>Sales Account: ".$sales_acc[0]->label."</p>";
					$html.="<p>LPO No.: ".$dataa[0]->srt_lpo_no."</p>";
					$html.="<p>Company: ".$company_details[0]->mcomp_name."</p>";
					$html.="<p>Price Level: ";
					if(!empty($price_level[0]->mpc_name))
						$html.=$price_level[0]->mpc_name;
					$html.="</p>";
					$html.="<p>Salesman: ".$salesman[0]->ed_name."</p>";
				$html.="<p>Payment Type: ".$payment_type[0]->mpm_name."</p>";
				
					$html.="<p>Place of Supply: ".$place_supply[0]->mps_name."</p>";
					$html.="<p>Jurisdiction: ".$jurisdaction[0]->mps_name."</p>";
					$html.="<p>Narration: ".$dataa[0]->srt_narration."</p>";
					$html.="<p>Warehouse Location: ".$warehouse[0]->mw_name."</p>";
					
				$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Customer : ".$cust_acc_details[0]->label."</p>";
					$html.="<p>Contact : ".$dataa[0]->srt_contact."</p>";
					$html.="<p>Delivery Address: ".$dataa[0]->srt_delivery_address."</p>";
					$html.="<p>Mark: ".$dataa[0]->srt_mark."</p>";
				$html.="<p>Ship Contact : ".$dataa[0]->srt_shipping_contact."</p>";
					$html.="<p>Country : ".$country[0]->mr_name."</p>";
						
				$html.="<p>Current Status: ".$dataa[0]->srt_current_sts."</p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

						$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th>
					<th>Product</th><th>Description</th>
					<th>Units</th><th>Label</th>
					<th>Quantity</th><th>Rate</th>
					<th>Gross</th><th>Discount(%)</th>
					<th>Discount Amount</th><th>Add.Charges</th>
					<th>Fnet</th><th>Vat(%)</th>
					<th>Delivery Date</th>
					<th>Remark</th><th>Tax Code</th></thead>";
					$html.="<tbody>";
					foreach($data_pl as $key=>$d)
					{
						$qnty_tot[]=$qnty_list[$key];
						$rate_tot[]=$rate_list[$key];
						$gross_tot[]=$gross_list[$key];
						
						$dis_amnt_tot[]=$disc_amount_list[$key];
						$adchrg_tot[]=$add_charges_list[$key];
						$fent_tot[]=$fnet_list[$key];
					
						$html.="<tr>";
						$html.="<td></td>";
						
						$html.="<td>".$d[0]->pname."</td>";

						

						$html.="<td>".$desc_list[$key]."</td>";
						$html.="<td>".$unit_list[$key]."</td>";
						$html.="<td>".$label_list[$key]."</td>";

						$html.="<td>".$qnty_list[$key]."</td>";
						$html.="<td>".$rate_list[$key]."</td>";
						$html.="<td>".$gross_list[$key]."</td>";

						$html.="<td>".$gross_list[$key]*($disc_per_list[$key]/100);
						$dis_per_tot[]=$gross_list[$key]*($disc_per_list[$key]/100);
						$html.="</td>";
						$disc_per_list[$key]."</td>";
						$html.="<td>".$disc_amount_list[$key]."</td>";
						$html.="<td>".$add_charges_list[$key]."</td>";

						$html.="<td>".$fnet_list[$key]."</td>";
						$html.="<td>".$fnet_list[$key]*($vat_list[$key]/100);
						$vat_amount_tot[]=$fnet_list[$key]*($vat_list[$key]/100);
						$html.="</td>";

						$html.="<td>".$delivery_date_list[$key]."</td>";
						$html.="<td>".$rmk_list[$key]."</td>";
						$html.="<td>".$tax_list[$key]."</td>";
					
						$html.="</tr>";
					}
					$html.="</tbody>";
					$html.="</table>";
						$html.="<div class='row'>";
					$html.="<div class='col-md-12'><div class='col-md-4'>";
						$html.="<p>Total Quantity : ".array_sum($qnty_tot)."</p>";
					$html.="<p>Total Rate  : ".array_sum($rate_tot)."</p>";
					$html.="<p>Total Gross : ".array_sum($gross_tot)."</p>";
					$html.="</div>";
					$html.="<div class='col-md-4'>";
					$html.="<p>Total Discount(%) : ".array_sum($dis_per_tot)."</p>";
					$html.="<p>Total Discount Amount : ".array_sum($dis_amnt_tot)."</p>";
					$html.="<p>Total Additional Charges : ".array_sum($adchrg_tot)."</p>";
						$html.="</div>";
					$html.="<div class='col-md-4'>";
					$html.="<p>Total Fnet : ".array_sum($fent_tot)."</p>";
					$html.="<p>Total VAT Amount : ".array_sum($vat_amount_tot)."</p>";
					$html.="<p>Final Amount : ".$dataa[0]->srt_tot_amount."</p>";
					$html.="</div>";$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/
					echo $html;
			}
}




function delete_srt($srt)
{
	if(logged_in())
	{
		

	
			$this->Admin_model->update_data('sales_return',array('srt_sts'=>'0'),array('srt_id'=>$srt));
			


		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'sales Return deleted',
			'act_status'=>'sales return id '.$srt.' deleted',
			'act_receipt_id'=>$srt,

		);
		  $this->Admin_model->insert_data('activities',$activity_data);

		  $this->session->set_flashdata('success', 'Data Successfully deleted');
	redirect('list-sales-return/');
	}
}






function generate_srt_pdf($page_type)
{
	if(logged_in())
	{
		$page_type='ksa';
		$srt_pdf=$this->input->post('sales_return_id');
		$return_pdf_type=$this->input->post('pdf-print-option');

		///for english - arabic number in words//////
 		$Arabic = new \ArPHP\I18N\Arabic();
 		 $Arabic->setNumberFeminine(1);
    	$Arabic->setNumberFormat(1);
    	///////end en-ar words/////////
  

		if(!empty($srt_pdf))
		{

if($page_type=="uae")
    
      
      $srt_data= $this->Admin_model->get_data('sales_return',array('srt_id'=>$srt_pdf));
    
elseif($page_type=="ksa")
 
 	 
     $srt_data= $this->Admin_model->get_data('sales_return',array('srt_id'=>$srt_pdf));  
 
 
	elseif($page_type=="dragon")
	
		
		$srt_data= $this->Admin_model->get_data('sales_return',array('srt_id'=>$srt_pdf));
	
   
		elseif($page_type=="export")
		
			
          $srt_data= $this->Admin_model->get_data('sales_return',array('srt_id'=>$srt_pdf));  
		
      else{}

$prd_details=explode('|#|',$srt_data[0]->srt_product);
$qty_details=explode('|#|',$srt_data[0]->srt_qnty);
$qnty_fnet=explode('|#|',$srt_data[0]->srt_fnet);
$percentage_vat=explode('|#|',$srt_data[0]->srt_vat);
//$gross_details=explode('|#|',$siv_data[0]->si_gross);//
//$discount_per_details=explode('|#|',$siv_data[0]->si_dis_per);//
//$disc_amount_details=explode('|#|',$siv_data[0]->si_dis_amount);//
//$add_charge_details=explode('|#|',$siv_data[0]->si_add_charges);//
//$fnet_details=explode('|#|',$siv_data[0]->si_fnet);//
//$vat_pre_details=explode('|#|',$siv_data[0]->si_vat);//
//$delivery_date_details=explode('|#|',$siv_data[0]->si_delivery_date);//
//$remark_details=explode('|#|',$siv_data[0]->si_remrk);//
//$tax_code_details=explode('|#|',$siv_data[0]->si_tax_code);//

foreach($prd_details as $index=>$pd)
{
	$prd_table_data[]=$this->tm->get_data('products',array('pid'=>$pd));	
}

$salesman=$this->Admin_model->get_data('employee_details',array('ed_id'=>$srt_data[0]->srt_salesman));

$customer_extra_data=$this->Admin_model->get_data('master_accounts_tree_file_data',array('accounts_tree_id'=>$srt_data[0]->srt_customer_acc_id));

 $acc_customer_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$srt_data[0]->srt_customer_acc_id));	
	
$currency=$this->Admin_model->get_data('master_currency_conv',array('currency_name'=>$srt_data[0]->srt_currency));

$warehose_from=$this->Admin_model->get_data('master_warehouse',array('mw_id'=>$srt_data[0]->srt_warehouse));
$label_list=explode('|#|',$srt_data[0]->srt_label);

// print_r($label_list);
// exit(0);

$stylesheet = file_get_contents('style_mpdf.css');
////////////////for qr code////////////////////////////
/*$this->load->library('ciqrcode');
//header("Content-Type: image/png");

$params['data'] = base_url('load_delivery_data/'.$doc_details_id[1]);
$params['level'] = 'H';
$params['size'] = 10;
$params['savename'] = './uploads/qr_code/'.$doc_details_id[1].'.png';
 $this->ciqrcode->generate($params);*/
//echo '<img src="'.base_url().'/uploads/inv_pdf/tes.png" />';
///////////qr code ends//////////////////////////////////////////

$html='<!doctype html>';
if($return_pdf_type!='1')
{
$html.='<br/><br/><br/><br/>';
}

$html.='<head></head><body>';
if ($return_pdf_type == '1') {
					$html .= '<div style="position: absolute; visibility: visible; left: 680px; top: 120px; z-index: 200;"></div>';
				}
				else{
					$html .= '<div style="position: absolute; visibility: visible; left: 680px; top: 230px; z-index: 200;"></div>';

				}
$html.='<div class="content" ><br/>';
	$head_all = '';
				$head_all.= '<table border="0" width="100%">';
				$head_all.= '<tr> <td>  </td></tr>';
				$head_all.= '<tr> <td>  </td></tr>';
				
				$head_all.= '<tr> <td> <br> </td></tr>';
				$head_all.= '<tr><td style="text-align:left;">';
				$head_all.= '<table border="0" width="100%" >';
				$head_all.= '<tbody>';

				if ($page_type == "ksa") {
					$head_all.= '<tr>';
					$head_all.= '<td>الرقم الضريبي  :310159338600003</b></td>';
					$head_all.= '</tr><br/>';
					$head_all.= '<tr>';
					$head_all.= '<td >' . $srt_data[0]->srt_narration . '</td>';
					$head_all.= '</tr><br/>';
				} else {

					$head_all.= '<tr>';
					$head_all.= '<td align="right"><b align="right">Our TRN:100301351100003</b></td>';
					$head_all.= '</tr><br/>';
					$head_all.= '<tr>';
					$head_all.= '<td >TRN#100567461700003</td>';
					$head_all.= '</tr><br/>';
				}
				$head_all.= '<tr>';
				$head_all.= '<td ><b>' . $acc_customer_details[0]->label . '</b></td>';
				$head_all.= '</tr>';
			if ($page_type == "ksa") {

					$head_all.= '<tr>';
					$head_all.= '<td></td><td></td>';
					$head_all.= '</tr>';
				} else {
					$head_all.= '<tr>';
					$head_all.= '<td ></td>';
					$head_all.= '</tr>';
				}
				
				$head_all.= '<tr>';

				if ($page_type == "ksa") {
					$head_all.= '<td>رقم الهاتف   :' . $customer_extra_data[0]->phone . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
	                $head_all.= '<td>رقم الفاكس :' . $customer_extra_data[0]->fax . '</td>';
				} else {
					$head_all.= '<td>Tel No.:' . $customer_extra_data[0]->phone . '</td>';
						$head_all.= '</tr>';
						$head_all.= '<tr>';
					$head_all.= '<td>Fax No :' . $customer_extra_data[0]->fax . '</td>';
				}



				$head_all.= '</tr>';
				if ($page_type == "ksa") {
					$head_all.= '<tr>';
					$head_all.= '<td> عنوان الشحن   </td><td> ' . character_limiter($srt_data[0]->srt_delivery_address, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td> جهة اتصال الشحن   </td><td>' . $srt_data[0]->dn_shipping_contact . '</td>';
					$head_all.= '</tr>';
				} else {
					$head_all.= '<tr>';
					$head_all.= '<td>Shipping Address : </td><td> ' . character_limiter($srt_data[0]->srt_delivery_address, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Shipping Contact : </td><td>' . $srt_data[0]->srt_shipping_contact . '</td>';
					$head_all.= '</tr>';
				}
				$head_all.= '</tbody>';
				$head_all.= '</table>';
				$head_all.= '</td>';

				$head_all.= '<td style="text-align:right;">';
				$head_all.= '<table border="0" width="100%" >';
				$head_all.= '<tbody>';
			
				if ($page_type == "ksa") {
                    $head_all.= '<tr>';
						$head_all.= '<td align="left"><b align="left"> Return Order فاتورة مرتجع   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</b></td>';
					$head_all.= '</tr><br/><br/>';

				} else {

					$head_all.= '<tr>';
					$head_all.= '<td align="left"><b align="left">Return Order</b></td>';
					$head_all.= '</tr><br/><br/>';
					
				}

				if ($page_type == "ksa") {

					$head_all.= '<tr>';
					$head_all.= '<td>مندوب المبيعات   :</td><td> ' . character_limiter($salesman[0]->ed_name, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td> رقم اذن المرتجع :</td><td> ' . $srt_data[0]->srt_doc_no . '</td>';
					$head_all.= '</tr>';
                    $head_all.= '<tr>';
					$head_all.= '<td>رقم فاتورة التسليم  :</td><td> ' . $label_list[0]. '</td>';
					$head_all.= '</tr>';

					$head_all.= '<tr>';
					$head_all.= '<td> التاريخ: </td><td>' . $srt_data[0]->srt_date . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td> علامة الشحن  :</td><td> ' . character_limiter($srt_data[0]->srt_mark, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td> جهة اتصال العميل  :</td><td> ' . $srt_data[0]->srt_contact . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>رقم الطلب  :</td><td> ' . $srt_data[0]->srt_lpo_no . '</td>';
					$head_all.= '</tr>';
				} else {
					$head_all.= '<tr>';
					$head_all.= '<td>Sales Person :</td><td> ' . character_limiter($salesman[0]->ed_name, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Return No. :</td><td> ' . $srt_data[0]->srt_doc_no . '</td>';
					$head_all.= '</tr>';
					 $head_all.= '<tr>';
					$head_all.= '<td> Delivery No. :</td><td> ' . $label_list[0] . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Date  : </td><td>' . $srt_data[0]->srt_date . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Mark :</td><td> ' . character_limiter($srt_data[0]->srt_mark, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Customer Contact :</td><td> ' . $srt_data[0]->srt_contact . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>L.P.O No :</td><td> ' . $srt_data[0]->srt_lpo_no . '</td>';
					$head_all.= '</tr>';
				}

             
				$head_all.= '</tbody>';
				$head_all.= '</table>';
				$head_all.= '</td>';
				$head_all.= '</tr>';

				$head_all.= '</table>';
				$head_all.= '</div>';
$html.='</div>';

$html.='<div class="content">
<table  align="center"  width="100%">';
$html.='<tbody>';
if($page_type=="ksa")
{
$html.='<tr >';
$html.='<td align="center" class="prd_info_2">المستودع المصدر</td>';
$html.='<td align="center" class="prd_info_2">رمز الصنف  </td>';
$html.='<td align="center" class="prd_info_2">الصنف  </td>';
$html.='<td align="center" class="prd_info_2">وصف  </td>';
$html.='<td align="center" class="prd_info_2">الكمية </td>';
$html.='<td align="center" class="prd_info_2">المبلغ دون ضريبة </td>';
$html.='<td align="center" class="prd_info_2">الضريبة </td>';
/*$html.='<td align="center" class="prd_info_2"></td>';
$html.='<td align="center" class="prd_info_2"></td>';*/
}
else
{
$html.='<tr >';
$html.='<td align="center" class="prd_info_2">Warehouse des</td>';
$html.='<td align="center" class="prd_info_2">Item Code</td>';
$html.='<td align="center" class="prd_info_2">Class </td>';
$html.='<td align="center" class="prd_info_2">Description</td>';
$html.='<td align="center" class="prd_info_2">Qty</td>';
/*$html.='<td align="center" class="prd_info_2"></td>';
$html.='<td align="center" class="prd_info_2"></td>';*/
}
	if($page_type=="uae")
	$html.='<td align="center" class="prd_info_2">VAT @5%</td>';
	elseif($page_type=="ksa")
		$html.='<td align="center" class="prd_info_2"></td>';
	elseif($page_type=="dragon")
	$html.='<td align="center" class="prd_info_2">VAT @5%</td>';
	elseif($page_type=="export")
	$html.='';

$html.='</tr>';
$i=1;
$total_sum_prd='';
$total_vat_sum_prd='';
$total_discount_sum_prd='';


					foreach($prd_table_data as $index=>$pd3)
					{
						

						if($index % 10 == 0 && $index != 0){
						
						$html .= '<table align="center"  width="100%">';
						$html .= '<tbody>';
						if ($return_pdf_type == '1') {
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
						}
						else{
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
						}
						
						
						if ($page_type == "ksa") {
							$html .= '<tr >';
							$html .= '<td align="center" class="prd_info_2">المستودع المصدّر</td>';
							$html .= '<td align="center" class="prd_info_2">رمز الصنف  </td>';
							$html .= '<td align="center" class="prd_info_2">الصنف   </td>';
							$html .= '<td align="center" class="prd_info_2">وصف  </td>';
							$html .= '<td align="center" class="prd_info_2">الكمية  </td>';
						/*	$html .= '<td align="center" class="prd_info_2"></td>';
							$html .= '<td align="center" class="prd_info_2"></td>';*/
						} else {
							$html .= '<tr >';
							$html .= '<td align="center" class="prd_info_2">Warehouse des</td>';
							$html .= '<td align="center" class="prd_info_2">Item Code</td>';
							$html .= '<td align="center" class="prd_info_2">Class </td>';
							$html .= '<td align="center" class="prd_info_2">Description</td>';
							$html .= '<td align="center" class="prd_info_2">Qty  </td>';
							/*$html .= '<td align="center" class="prd_info_2"></td>';
							$html .= '<td align="center" class="prd_info_2"></td>*/					
								}
						if ($page_type == "uae")
							$html .= '<td align="center" class="prd_info_2">VAT @5%</td>';
						elseif ($page_type == "ksa")
							$html .= '<td align="center" class="prd_info_2"></td>';
						elseif ($page_type == "dragon")
							$html .= '<td align="center" class="prd_info_2">VAT @5%</td>';
						elseif ($page_type == "export")
							$html .= '';
						$html .= '</tr >';
					}
$html.='<tr>';
$html.='<td align="center" width="15%">'.$warehose_from[0]->mw_name.'</td>';
$html.='<td align="center" width="10%">'.$pd3[0]->pcode.'</td>';
$html .= '<td align="center" width="15%"><p style="font-size:12px;">' . $pd3[0]->pcat . '</p></td>';
if($page_type!="ksa")
$html.='<td align="center" width="35%">'.$pd3[0]->pname;
else
{
	if(!empty($pd3[0]->pname_ar))
	{
		$html .= '<td align="center" style="height:25px !important;overflow: hidden !important;" width="30%"><p style="font-size:11px;">' . $pd3[0]->pname_ar .'<br>'.$pd3[0]->pname .'</p>';
	}
	else
	{
		$html.='<td align="center" width="35%">'.$pd3[0]->pname;
	}
}
$html.='</td>';
$html.='<td align="center" width="10%">'.$qty_details[$index].'</td>';
$html.='<td align="center" width="10%">'.$qnty_fnet[$index].'</td>';

$vat[$index]=(0.01*$percentage_vat[$index])*$qnty_fnet[$index];
$html.='<td align="center" width="10%">'.$vat[$index].'</td>';


/*$html.='<td align="center" width="11%"></td>';
$html.='<td align="center" width="11%"></td>';
/*$vat_perce=$fnet_details[$index]*($vat_pre_details[$index]/100);
$vat_amount_tot[]=$fnet_details[$index]*($vat_pre_details[$index]/100);
$dis_per_tot[]=$gross_details[$index]*($discount_per_details[$index]/100);*/
/*if($page_type!="export")
{
$html.='<td align="center" width="11%"></td>';
}*/
$html.='</tr>';

					if($index % 9 == 0 && $index != 0)
					{
						$html .= '</tbody>';
						$html .= '</table>';
						
						$html .= "<pagebreak />";
					}
					$total_qty=$total_qty+($qty_details[$index]);
					$total_pricenovat=$total_pricenovat+($qnty_fnet[$index]);
					$total_vatprice=$total_vatprice+($vat[$index]);
					}
$html.='</tbody>';
$html.='</table>';
$html.='</div>';


///////////////////////////////////////////////////////////////////////////////////////////






//////////////////////////////////////////////////////////////////////////////////////////////////




$html.='<div class="content_2">';
//$html.='<img align="bottom"  src="'.base_url().'/uploads/qr_code/'.$siv_data[0]->si_doc_no.'.png" width="100" height="100"/>';

$html.='<table class="prd_info_2" align="center" width="100%">';


if($page_type=="ksa")
{
     
   //$ar_number_word = number_format((float)$siv_data[0]->si_tot_amount, 2, '.', '');
    //$text   = $Arabic->money2str($ar_number_word, 'SAR', 'ar');
    $ar_number_word = number_format((float)$srt_data[0]->srt_final_total,2,'.','');
	 $text   = $Arabic->money2str($ar_number_word, 'SAR', 'ar');
    //$text   = $Arabic->int2str($ar_number_word);
    
    // echo "<p align=center>$number<br />$text</p>";////not to use////

    $html.='<tr>';
$html.='<td align="right" >         ' .$total_pricenovat. ':الصافي   </td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td align="right" >      ' .$total_vatprice. ':الضريبة   </td>';
$html.='</tr>';

$html.='<tr>';
$html.='<td align="right" >      ' .$srt_data[0]->srt_final_total. ':المجموع  </td>';
$html.='</tr>';

$html.='<tr>';
$html.='<td align="right" >  المجموع بالكلمات   :     ' .$text. ' </td>';
$html.='</tr>';



}


else
	
{
$html.='<tr>';
$html.='<td align="right" > '.$this->numbertowordconvertsconver->convert_number($srt_data[0]->srt_final_total).'  </td>   <td align="right" width="11%">  ' . $srt_data[0]->srt_final_total. ':Total   </td>'; 
$html.='</tr>';
}
$html.='</table>';


$html.='<table width="100%">';
$html.='<tr>';

$html.='<td>';
$html.='<table width="80%">';
$html.='<tbody>';
$html.='<tr>';
if($page_type=="ksa")
$html.='<td ><u class="underline_space"></u></td>';
else
$html.='<td><u class="underline_space"></u></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td></td>';
if($page_type=="ksa")
{
  
    /*$ar_number_word = number_format((float)$siv_data[0]->si_tot_amount, 2, '.', '');
    $text   = $Arabic->money2str($ar_number_word, 'SAR', 'ar');*/
    
    // echo "<p align=center>$number<br />$text</p>";////not to use////
$html.='<td colspan="2"></td>';
}
else
$html.='<td colspan="2"></td>';
$html.='</tr>';

if($page_type=="ksa")
{
$html.='<tr>';
$html.='<td> توقيع المستلم   :</td>';
$html.='<td></td>';
$html.='<td>  توقيع المفوض   </td>';
$html.='</tr>';
}
else
{
	$html.='<tr>';
$html.='<td>Receiver`s Signature:</td>';
$html.='<td></td>';
$html.='<td>Authorised   </td>';
$html.='</tr>';
}

$html.='</tbody>';
$html.='</table>';
$html.='</td>';

$html.='<td>';
$html.='<table width="80%">';
$html.='<tbody>';
if($page_type=="ksa")
{
$html.='<tr>';
$html.='<td> </td>';
$html.='</tr>';

$html.='<tr>';
$html.='<td><b></b></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td></td>';
$html.='<td></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td> </td>';
$html.='<td></td>';
$html.='</tr>';
$html.='<tr>';
}
else
{
$html.='<tr>';
$html.='<td></td>';
$html.='</tr>';

$html.='<tr>';
$html.='<td><b></b></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td></td>';
$html.='<td></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td></td>';
$html.='<td></td>';
$html.='</tr>';
$html.='<tr>';
}

if($page_type=="uae")
{
	$html.='<td>VAT @5%</td>';
$html.='<td></td>';
}
elseif($page_type=="ksa")
{
	$html.='<td></td>';
$html.='<td></td>';
}
elseif($page_type=="dragon")
{
$html.='<td>VAT @5%</td>';
$html.='<td></td>';
}
elseif($page_type=="export")
$html.='';


$html.='</tr>';
$html.='<tr>';
if($page_type=="ksa")
$html.='<td> </td>';
else
$html.='<td></td>';

$html.='<td></td>';	
$html.='</tr>';
$html.='</tbody>';
$html.='</table>';
$html.='</td>';

$html.='</tr>';
$html.='</table ><br/><br/>';

$html.='</div>';


$html.='</body>';
$html.='</html>';

//echo $html;
$pdfFilePath = $srt_data[0]->srt_doc_no.'.pdf';

	 $mpdf = new \Mpdf\Mpdf();
	 $mpdf->autoScriptToLang = true;
	$mpdf->autoLangToFont = true;
    $mpdf->autoArabic=true;
	$mpdf->defaultfooterline = 0;





  if($page_type=="uae")
		{    
			$delivery_company_details=$this->Admin_model->get_data('sales_invoice',array('si_doc_no'=>$srt_data[0]->srt_bill_no));
	       $company_details_si=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$delivery_company_details[0]->si_company));
	    }

	elseif($page_type=="ksa"){
		
		$delivery_company_details=$this->Admin_model->get_data('sales_invoice_ksa',array('si_doc_no'=>$srt_data[0]->srt_bill_no));
	       $company_details_si=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$delivery_company_details[0]->si_company));
	}
		elseif($page_type=="dragon"){
			
			$delivery_company_details=$this->Admin_model->get_data('sales_invoice_dragon',array('si_doc_no'=>$srt_data[0]->srt_bill_no));
	       $company_details_si=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$delivery_company_details[0]->si_company));
		}
			
			elseif($page_type=="export"){
				
		$delivery_company_details=$this->Admin_model->get_data('sales_invoice_export',array('si_doc_no'=>$srt_data[0]->srt_bill_no));
	     $company_details_si=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$delivery_company_details[0]->si_company));
				}
				else{}




 






 
if($return_pdf_type=='1')
{
if ( strpos($company_details_si[0]->mcomp_name, 'UAE ') !== false) {

 	$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');
}
elseif ( strpos($company_details_si[0]->mcomp_name, 'UAE') !== false) {

 	$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');
}
elseif(strpos($company_details_si[0]->mcomp_name, 'Dubai ') !== false)
{
 $mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');

}
elseif(strpos($company_details_si[0]->mcomp_name, 'FACTORY') !== false)
{
 	$mpdf->SetHeader('<img src="'.base_url("biri_industries_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("biri_industries_footer.png").'">');
}
elseif($page_type=="ksa")
{
 $mpdf->SetHeader('<img src="'.base_url("ksa-header-new.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("ksa-footer-new.png").'">');

}
else
{}

}
else
{
	$mpdf->SetHeader($head_all);
	$mpdf->SetFooter('<div style="margin-bottom:100px;">Page {PAGENO} of {nb}</div>');
}
//echo $html;
//print_r($fnet_details);
		 $mpdf->WriteHTML($stylesheet,1);
		 if ($return_pdf_type == '1') {
					$mpdf->AddPage(
						'', // L - landscape, P - portrait 
						'',
						'',
						'',
						'',
						5, // margin_left
						5, // margin right
						89, // margin top
						20, // margin bottom
						0, // margin header
						0
					); // margin footer
				}
				else{
					$mpdf->AddPage(
						'', // L - landscape, P - portrait 
						'',
						'',
						'',
						'',
						5, // margin_left
						5, // margin right
						97, // margin top
						20, // margin bottom
						60, // margin header
						30
					); // margin footer
				}
   
	     $mpdf->WriteHTML($html,2);	     
	     //save in folder
		$mpdf->Output("./uploads/inv_pdf/".$pdfFilePath, "F");
  		$mpdf->Output($pdfFilePath,'D');
				
 		}
	}
}





































}