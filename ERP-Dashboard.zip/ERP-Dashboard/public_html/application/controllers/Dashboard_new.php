<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_new extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper('session');
	}


function this_range_date()
{
// 	$start_date_selected= $this->input->post('start_date_selected');
// 	$end_date_selected=$this->input->post('end_date_selected');

// 	$new_bal_amount='';
// 			$i=0;
// 			$j=1;
// 	$start_date_selected= '09/01/2019';
//  	$end_date_selected='09/05/2019';
			
// $date_rng_strt1 = str_replace("/", "-", $start_date_selected);
// $date1_start=explode('-', $date_rng_strt1);
// 			$month1=$date1_start[0];
// 			$date1=$date1_start[1];
// 			$year1=$date1_start[2];
// $start_date=$year1.'-'.$month1.'-'.$date1;
// $start_day_month=$year1.'-'.$month1.'-01';

// $prev_month = $month1-'1';
// $prev_month_val=str_pad($prev_month, 2, '0', STR_PAD_LEFT);
// if($prev_month=='00')
// $prev_month_val = '12';


// $date_rng_end2 = str_replace("/", "-", $end_date_selected);
// $date1_end=explode('-', $date_rng_end2);
// 			$month2=$date1_end[0];
// 			$date2=$date1_end[1];
// 			$year2=$date1_end[2];
// $end_date=$year2.'-'.$month2.'-'.$date2;

// if(!empty($start_date) && !empty($end_date))
// {
// 	 $date_selected= ' from '.$start_date.' to '.$end_date;
// }
// else{
// 	 $date_selected= '';
// }

$banks_array=array('ADIB-BBMS','ADIB-Factory','ENBD','EI Bank','Cash Mr. Bachir Book','Cash Garhoud','Cash Factory','Other Bank');
$j=1;
foreach($banks_array as $bank)
{
	$cond_new=array('ae_bank'=>$bank,'ae_status'=>'1');
		$opening_bal_bbms=$this->Admin_model->get_opening_bal($cond_new);
	$base_opening_amount=$opening_bal_bbms[0]->ae_amount;
	
			$order_by='ae_date';
			$order_type="ASC";
	$data_amount=$this->Admin_model->get_data('account_entry1',array('ae_bank'=>$bank,'ae_desc !='=>'Opening Balances','ae_status'=>'1'),'','',$order_by,$order_type);

	// $data_balances_spend[]=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$bank),'',$end_date,array('ae_desc !='=>'Opening Balances'),'','','','',$order_by,$order_type);
	// echo "<pre>";
	// print_r($data_amount);
	// echo "</pre>";
	foreach($data_amount as $t)
	{

		
		if(!empty($base_opening_amount) && ($j==1))
				{
					echo "in if";
					echo "<br/>";
					if($t->ae_cash_type=="Spend")
						$new_bal_amount=$base_opening_amount-$t->ae_amount;
					else
						$new_bal_amount=$base_opening_amount+$t->ae_amount;

					
				}
			elseif(!empty($new_bal_amount) && ($j>1))
				{
				echo "in else-if";
				echo "<br/>";
					if($t->ae_cash_type=="Spend")
					$new_bal_amount=$new_bal_amount-$t->ae_amount;
						else
					$new_bal_amount=$new_bal_amount+$t->ae_amount;
				}
				else
				{
					echo "in else";
					$new_bal_amount='';
					$base_opening_amount='';
				}

				// echo "<pre>";
				// print_r($base_opening_amount.'-"'.$t->ae_bank.'"-``'.$t->ae_date.'``-!!'.$t->ae_amount.'!!'.$new_bal_amount);
				// echo "</pre>";
				$data1=array('ae_bal_amount'=>$new_bal_amount);
		        $cond1=array('ae_id'=>$t->ae_id,'ae_status'=>'1');
				$this->Admin_model->update_data('account_entry1',$data1,$cond1);
				$j++;
	}
$j=1;

}

// $category_array=array('Shipping','Sales','General Expenses','Salaries','Raw Material Purchases','Import Purchases','Export Purchases','Rent','Others');
// foreach($category_array as $cat)
// {
// 			$order_by='ae_date';
// 			$order_type="ASC";
// 	$data_balances_rx[]=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_cat'=>$cat),'',$end_date,array('ae_desc !='=>'Opening Balances'),'','','','',$order_by,$order_type);

// 	$data_balances_spend[]=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_cat'=>$cat),'',$end_date,array('ae_desc !='=>'Opening Balances'),'','','','',$order_by,$order_type);
// }

// 	$BBMS=($data_balances_rx[0][0]->rx_total+$base_opening_amount[0])-($data_balances_spend[0][0]->spend_total);
// 	$fact=($data_balances_rx[1][0]->rx_total+$base_opening_amount[1])-($data_balances_spend[1][0]->spend_total);
// 	$enbd=($data_balances_rx[2][0]->rx_total+$base_opening_amount[2])-($data_balances_spend[2][0]->spend_total);
// 	$ei=($data_balances_rx[3][0]->rx_total+$base_opening_amount[3])-($data_balances_spend[3][0]->spend_total);
// 	$bachir=($data_balances_rx[4][0]->rx_total+$base_opening_amount[4])-($data_balances_spend[4][0]->spend_total);
// 	$garhoud=($data_balances_rx[5][0]->rx_total+$base_opening_amount[5])-($data_balances_spend[5][0]->spend_total);
// 	$cash_fact=($data_balances_rx[6][0]->rx_total+$base_opening_amount[6])-($data_balances_spend[6][0]->spend_total);
// 	$other_bank=($data_balances_rx[7][0]->rx_total+$base_opening_amount[7])-($data_balances_spend[7][0]->spend_total);

// 	$bank_total=($BBMS+$fact+$enbd+$ei+$other_bank);
// 	$cash_total=($bachir+$garhoud+$cash_fact);

// 	$shipping=($data_balances_rx[0][0]->rx_total)-($data_balances_spend[0][0]->spend_total);
// 	$sales=($data_balances_rx[1][0]->rx_total)-($data_balances_spend[1][0]->spend_total);
// 	$gnrl_exp=($data_balances_rx[2][0]->rx_total)-($data_balances_spend[2][0]->spend_total);
// 	$salary=($data_balances_rx[3][0]->rx_total)-($data_balances_spend[3][0]->spend_total);
// 	$raw_mat=($data_balances_rx[4][0]->rx_total)-($data_balances_spend[4][0]->spend_total);
// 	$import=($data_balances_rx[5][0]->rx_total)-($data_balances_spend[5][0]->spend_total);
// 	$export=($data_balances_rx[6][0]->rx_total)-($data_balances_spend[6][0]->spend_total);
// 	$rent=($data_balances_rx[7][0]->rx_total)-($data_balances_spend[7][0]->spend_total);
// 	$others=($data_balances_rx[8][0]->rx_total)-($data_balances_spend[8][0]->spend_total);

// $total_cat=($shipping+$sales+$gnrl_exp+$salary+$raw_mat+$import+$export+$rent+$others);


// $data=array(
// 	'bbms'=>number_format((float)$BBMS, 2, '.', ''),
// 	'factory'=>number_format((float)$fact, 2, '.', ''),
// 	'ENBD'=>number_format((float)$enbd, 2, '.', ''),
// 	'other_bank'=>number_format((float)$ei, 2, '.', ''),
// 	'ei_bank'=>number_format((float)$bachir, 2, '.', ''),
// 	'Garhoud'=>number_format((float)$garhoud, 2, '.', ''),
// 	'cash_bachir'=>number_format((float)$cash_fact, 2, '.', ''),
// 	'cash_fact'=>number_format((float)$other_bank, 2, '.', ''),
// 	'total_bank_bal'=>number_format((float)$bank_total, 2, '.', ''),
// 	'total_cash_bal'=>number_format((float)$cash_total, 2, '.', ''),

// 	'shipping'=>number_format((float)$shipping, 2, '.', ''),
// 	'sales'=>number_format((float)$sales, 2, '.', ''),
// 	'gnrl'=>number_format((float)$gnrl_exp, 2, '.', ''),
// 	'salary'=>number_format((float)$salary, 2, '.', ''),
// 	'raw_mat'=>number_format((float)$raw_mat, 2, '.', ''),
// 	'import'=>number_format((float)$import, 2, '.', ''),
// 	'export'=>number_format((float)$export, 2, '.', ''),
// 	'rent'=>number_format((float)$rent, 2, '.', ''),
// 	'other'=>number_format((float)$others, 2, '.', ''),
// 	'total_cat'=>number_format((float)$total_cat, 2, '.', ''),
// 	'bank_date'=>$date_selected,
// 			);
//  print_r($data);
	//	echo json_encode($data);

}









































}