<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cron_jobs extends CI_Controller 
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        //$this->load->model('cron_model');
        $this->load->model('Third_db_model','tm');
        $this->load->helper(array('session','gnrl','email'));
    }
    
    public function sample_cron_check()
    {            
        $total_pending=$this->Admin_model->get_data('ticket_stock',array('ts_ticket_action'=>'0'));
        hi_arya();
     //   echo $total_pending;
      //  foreach($total_pending as $)
    }
    /**
     * This function is used to update the age of users automatically
     * This function is called by cron job once in a day at midnight 00:00
     */
    public function check_stock_update()
    {            
    $current_stock_details=$this->Admin_model->get_data('product_stock',array('ps_sts'=>'1'));
    $current_stock_date=$current_stock_details[0]->ps_date;
    $current_date=date('Y-m-d');
   
    $date_diff=strtotime($current_date)-strtotime($current_stock_date);
        $final_date_diff=round($date_diff / (60 * 60 * 24));
      //  print_r($final_date_diff);
        if($final_date_diff>=3)
        {
            if($final_date_diff==3)
            {
                send_mail_store();
            }
            else
            {
                // if($final_date_diff==4)
                // {
                    send_mail_store_mngmnt();
               // }
            }
            // is_cli_request() is provided by default input library of codeigniter
        }
        
    }
        
    function check_stock_staff_email()
    {
        if(date('D') == 'Sat')
        {
          $all_sort=$this->Admin_model->get_data('product_stock',array('ps_dxb_qnty!='=>''),'','','ps_dxb_qnty','DESC');
        foreach($all_sort as $p)
        {
        $prd_details[]=$this->tm->get_data('products',array('pcode'=>$p->ps_prd_code),'','','','',('p_prd_img,pname,pcat,pcode'));
        }
            $mail_data['result']=$all_sort;
            $mail_data['prd_details']=$prd_details;
            send_mail_stock_staff($mail_data);
        }
    }

    function check_item_req_expected_date_ordered()
    {
        $result=$this->Admin_model->get_data('item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
       $current_date=date('Y-m-d');
 $a=array();$flag=0;
        foreach($result as $d)
        { 
            if(!empty($d->date_expected))
            {
                 $prd_data=explode('|#|', $d->ir_prd_id);
                $prd_qnty=explode('|#|', $d->ir_prd_qnty);
                $date_diff=strtotime($current_date)-strtotime($d->date_expected);
                $final_date_diff=round($date_diff / (60 * 60 * 24));
                if($final_date_diff>='1')//////////if the expected date has passed, and its already the next day from the date of expected
                {
                    $flag=1;
                  $mail_body="<table class='table table-bordered'>";
         $mail_body.="<tbody>";
         $mail_body.="<tr>";
         $mail_body.="<td>Item Request No.</td>";
         $mail_body.="<td> Date</td>";
         $mail_body.="<td> Issued by</td>";
         $mail_body.="<td>Item Details</td>";
         $mail_body.="</tr>";
         $mail_body.="<tr>";
         $mail_body.="<td>".$d->ir_req_no."</td>";
          $mail_body.="<td>".$d->ir_order_date."</td>";
          $mail_body.="<td>".$d->ir_user_created."</td>";
          $mail_body.="<td>";
            $mail_body.="<table class='table table-bordered'>";
            $mail_body.="<tbody>";
            $mail_body.="<tr>";
            $mail_body.="<td> Photo </td>";
            $mail_body.="<td>Item Name</td>";
            $mail_body.="<td> Quantity</td>";
            $mail_body.="</tr>";

         foreach($prd_data as $index=>$pd3)
            {
                $prd_info=$this->tm->get_data('products',array('pid'=>$pd3));
                $prd_name_db=explode('|--|',$prd_info[0]->pname);

                if(empty($prd_info[0]->p_prd_img))
                        {
                            $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
                         if (file_exists($filename)) {
                            $img_path=$filename;
                            } else {
                            $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
                            }
                        }
                        else
                        {
                            $first_img_prd=explode(',',$prd_info[0]->p_prd_img);
                            if(!empty($first_img_prd[0]))
                            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
                            else
                            $img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
                            
                        }

                if(!empty($prd_name_db[1]))
                    $prd_name= $prd_name_db[0].'<br/>'.$prd_name_db[1];
                else
                    $prd_name= $prd_info[0]->pname;

             $mail_body.="<tr>";
             $mail_body.="<td><img src='".$img_path."' width='100' height='100'></td>";
             $mail_body.="<td>".$prd_name."</td>";
             $mail_body.="<td>".$prd_qnty[$index]."</td>";
             $mail_body.="</tr>";
            }
              $mail_body.="<tbody>";
              $mail_body.="</table>";
            $mail_body.="</td>";

            $mail_body.="</tr>";
            $mail_body.="</tbody>";
            $mail_body.="</table>";
            // print_r($mail_body);  

            $a[].=$mail_body;  
                }
            }
        }
        //pre_list($a);
        if($flag==1)
         mail_item_req_sts_ordred($a);
    }

    function check_item_req_expected_date_shipped()
    {
         $result=$this->Admin_model->get_data('item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
       $current_date=date('Y-m-d');
$flag=0;
        foreach($result as $d)
        {
            if(!empty($d->new_expected_date))
            {
                $date_eta=$d->new_expected_date;
            }
            else
            {
                $date_eta=$d->date_expected;
            }
            if(!empty($date_eta))
            {
                $date_diff=strtotime($current_date)-strtotime($date_eta);
                $final_date_diff=round($date_diff / (60 * 60 * 24));
                if($final_date_diff>'3')//////////if the expected date has passed, and its already the next day from the date of expected
                {
                    $flag=1;
                   $mail_body="<table class='table table-bordered'>";
         $mail_body.="<tbody>";
         $mail_body.="<tr>";
         $mail_body.="<td>Item Request No.</td>";
         $mail_body.="<td> Date</td>";
         $mail_body.="<td> Issued by</td>";
         $mail_body.="<td>Item Details</td>";
         $mail_body.="</tr>";
         $mail_body.="<tr>";
         $mail_body.="<td>".$d->ir_req_no."</td>";
          $mail_body.="<td>".$d->ir_order_date."</td>";
          $mail_body.="<td>".$d->ir_user_created."</td>";
          $mail_body.="<td>";
            $mail_body.="<table class='table table-bordered'>";
            $mail_body.="<tbody>";
            $mail_body.="<tr>";
            $mail_body.="<td> Photo </td>";
            $mail_body.="<td>Item Name</td>";
            $mail_body.="<td> Quantity</td>";
            $mail_body.="</tr>";

         foreach($prd_data as $index=>$pd3)
            {
                $prd_info=$this->tm->get_data('products',array('pid'=>$pd3));
                $prd_name_db=explode('|--|',$prd_info[0]->pname);

                if(empty($prd_info[0]->p_prd_img))
                        {
                            $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
                         if (file_exists($filename)) {
                            $img_path=$filename;
                            } else {
                            $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
                            }
                        }
                        else
                        {
                            $first_img_prd=explode(',',$prd_info[0]->p_prd_img);
                            if(!empty($first_img_prd[0]))
                            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
                            else
                            $img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
                            
                        }

                if(!empty($prd_name_db[1]))
                    $prd_name= $prd_name_db[0].'<br/>'.$prd_name_db[1];
                else
                    $prd_name= $prd_info[0]->pname;

             $mail_body.="<tr>";
             $mail_body.="<td><img src='".$img_path."' width='100' height='100'></td>";
             $mail_body.="<td>".$prd_name."</td>";
             $mail_body.="<td>".$prd_qnty[$index]."</td>";
             $mail_body.="</tr>";
            }
              $mail_body.="<tbody>";
              $mail_body.="</table>";
            $mail_body.="</td>";

            $mail_body.="</tr>";
            $mail_body.="</tbody>";
            $mail_body.="</table>";
            // print_r($mail_body);  

            $a[].=$mail_body;  
                   
                }
            }
        }
     if($flag==1)
         mail_item_req_sts_shipped($a);
    }



    function check_new_item_request()
    {
        $data=$this->Admin_model->get_data('item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
        $count_new_req=count($data);$flag=0;
        if(!empty($data))
        {
            $a=array();
             $current_date=date('Y-m-d');            
             foreach($data as $d)
             {
              //  pre_list($d);echo "<br/>";
                $prd_data=explode('|#|', $d->ir_prd_id);
                $prd_qnty=explode('|#|', $d->ir_prd_qnty);
                $date_diff=strtotime($current_date)-strtotime($d->ir_order_date);
                $final_date_diff=round($date_diff / (60 * 60 * 24));
            //  print_r( $final_date_diff);echo "<br/>";
               // if($final_date_diff>'2')
              //  {
               $flag=1;      
        $mail_body="<table class='table table-bordered'>";
         $mail_body.="<tbody>";
         $mail_body.="<tr>";
         $mail_body.="<td>Item Request No.</td>";
         $mail_body.="<td> Date</td>";
         $mail_body.="<td> Issued by</td>";
         $mail_body.="<td>Item Details</td>";
         $mail_body.="</tr>";
         $mail_body.="<tr>";
         $mail_body.="<td>".$d->ir_req_no."</td>";
          $mail_body.="<td>".$d->ir_order_date."</td>";
          $mail_body.="<td>".$d->ir_user_created."</td>";
          $mail_body.="<td>";
            $mail_body.="<table class='table table-bordered'>";
            $mail_body.="<tbody>";
            $mail_body.="<tr>";
            $mail_body.="<td> Photo </td>";
            $mail_body.="<td>Item Name</td>";
            $mail_body.="<td> Quantity</td>";
            $mail_body.="</tr>";

         foreach($prd_data as $index=>$pd3)
            {
                $prd_info=$this->tm->get_data('products',array('pid'=>$pd3));
                $prd_name_db=explode('|--|',$prd_info[0]->pname);
                if(empty($prd_info[0]->p_prd_img))
                        {
                            $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
                         if (file_exists($filename)) {
                            $img_path=$filename;
                            } else {
                            $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
                            }
                        }
                        else
                        {
                            $first_img_prd=explode(',',$prd_info[0]->p_prd_img);
                            if(!empty($first_img_prd[0]))
                            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
                            else
                            $img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
                            
                        }

                if(!empty($prd_name_db[1]))
                    $prd_name= $prd_name_db[0].'<br/>'.$prd_name_db[1];
                else
                    $prd_name= $prd_info[0]->pname;

             $mail_body.="<tr>";
             $mail_body.="<td><img src='".$img_path."' width='100' height='100'></td>";
             $mail_body.="<td>".$prd_name."</td>";
             $mail_body.="<td>".$prd_qnty[$index]."</td>";
             $mail_body.="</tr>";
            }
              $mail_body.="<tbody>";
              $mail_body.="</table>";
            $mail_body.="</td>";

            $mail_body.="</tr>";
            $mail_body.="</tbody>";
            $mail_body.="</table>";
            // print_r($mail_body);  

            $a[].=$mail_body;           
              //  }
             }
             if($flag==1)
             mail_new_item_req_reminder($a);
        }
    }




    function check_pallet_uk()
    {

           $CbM=$this->Admin_model->CBM_Ready_count('uk_item_request',null);
       $NumberofCBM=$CbM[0]->total_cbm;
        $palletSize = 3.3;

      $numberOfPallets = $NumberofCBM / $palletSize;
      
      $condition_pallet=round($numberOfPallets);
       if($condition_pallet>=15)
       {
           
            $data = $this->Admin_model->get_data_multiple('uk_item_request', array( array('ir_req_status' => '3', 'ir_sts' => '1'), array('ir_req_status' => '4', 'ir_sts' => '1') ));
     
   
        $count_new_req=count($data);$flag=0;
        if(!empty($data))
        {
            $a=array();
             $current_date=date('Y-m-d');            
             foreach($data as $d)
             {
              //  pre_list($d);echo "<br/>";
			  $Shipment_method_id=$d->Shipment_method_id;
              
			  $CBM_Size=$d->CBM_Size;
             
			  $Country_dest_id=$d->Country_dest_id;
			  $Port_land_id=$d->Port_land_id;

              $Shipment_method_arr=$this->Admin_model->get_data('Shipment_Method',array('Shipment_id'=>$Shipment_method_id));
             
			  $Country_dest_arr=$this->Admin_model->get_data('country_val',array('country_id'=>$Country_dest_id));
			  $Port_land_arr=$this->Admin_model->get_data('ports_loading',array('ports_id'=>$Port_land_id));

            $Port_land=$Port_land_arr[0]->Port_name;
                $Country_dest=$Country_dest_arr[0]->name;
            $Shipment_method=$Shipment_method_arr[0]->Shipment_name;


                $prd_data=explode('|#|', $d->ir_prd_id);
                $prd_qnty=explode('|#|', $d->ir_prd_qnty);
                $date_diff=strtotime($current_date)-strtotime($d->ir_order_date);
                $final_date_diff=round($date_diff / (60 * 60 * 24));
            //  print_r( $final_date_diff);echo "<br/>";
              // if($final_date_diff>'3')
              //  {
               $flag=1;      
        $mail_body="<table class='table table-bordered'>";
         $mail_body.="<tbody>";
         $mail_body.="<tr>";
         $mail_body.="<td>Item Request No.</td>";
         $mail_body.="<td> Date</td>";
         $mail_body.="<td> Issued by</td>";
		 $mail_body.="<td>CBM Size</td>";
            $mail_body.="<td>Port_land</td>"; 
           $mail_body.="<td>Country_dest</td>";
          $mail_body.="<td>Shipment_method</td>";

         $mail_body.="<td>Item Details</td>";
		 
         $mail_body.="</tr>";
         $mail_body.="<tr>";
         $mail_body.="<td>".$d->ir_req_no."</td>";
          $mail_body.="<td>".$d->ir_order_date."</td>";
          $mail_body.="<td>".$d->ir_user_created."</td>";
		  $mail_body.="<td>".$CBM_Size."</td>";
		   $mail_body.="<td>".$Port_land."</td>";
		    $mail_body.="<td>".$Country_dest."</td>";
			 $mail_body.="<td>".$Shipment_method."</td>";
          $mail_body.="<td>";
            $mail_body.="<table class='table table-bordered'>";
            $mail_body.="<tbody>";
            $mail_body.="<tr>";
            $mail_body.="<td> Photo </td>";
            $mail_body.="<td>Item Name</td>";
            $mail_body.="<td> Quantity</td>";
            $mail_body.="</tr>";

         foreach($prd_data as $index=>$pd3)
            {
                $prd_info=$this->tm->get_data('products',array('pid'=>$pd3));
                $prd_name_db=explode('|--|',$prd_info[0]->pname);
                if(empty($prd_info[0]->p_prd_img))
                        {
                            $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
                         if (file_exists($filename)) {
                            $img_path=$filename;
                            } else {
                            $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
                            }
                        }
                        else
                        {
                            $first_img_prd=explode(',',$prd_info[0]->p_prd_img);
                            if(!empty($first_img_prd[0]))
                            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
                            else
                            $img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
                            
                        }

                if(!empty($prd_name_db[1]))
                    $prd_name= $prd_name_db[0].'<br/>'.$prd_name_db[1];
                else
                    $prd_name= $prd_info[0]->pname;

             $mail_body.="<tr>";
             $mail_body.="<td><img src='".$img_path."' width='100' height='100'></td>";
             $mail_body.="<td>".$prd_name."</td>";
             $mail_body.="<td>".$prd_qnty[$index]."</td>";
             $mail_body.="</tr>";
            }
              $mail_body.="<tbody>";
              $mail_body.="</table>";
            $mail_body.="</td>";

            $mail_body.="</tr>";
            $mail_body.="</tbody>";
            $mail_body.="</table>";
            // print_r($mail_body);  

            $a[].=$mail_body;           
              //  }
             }
             if($flag==1)
             {  mail_ready_pallet_reminder($a);}
             
        }
           

       }
       

     
    }




///ksa////

 function check_pallet_ksa()
    {

           $CbM=$this->Admin_model->CBM_Ready_count('ksa_item_request',null);
       $NumberofCBM=$CbM[0]->total_cbm;
        $palletSize = 3.3;

      $numberOfPallets = $NumberofCBM / $palletSize;
      
      $condition_pallet=round($numberOfPallets);
       if($condition_pallet>=15)
       {
           
            $data = $this->Admin_model->get_data_multiple('ksa_item_request', array( array('ir_req_status' => '3', 'ir_sts' => '1'), array('ir_req_status' => '4', 'ir_sts' => '1') ));
     
   
        $count_new_req=count($data);$flag=0;
        if(!empty($data))
        {
            $a=array();
             $current_date=date('Y-m-d');            
             foreach($data as $d)
             {
              //  pre_list($d);echo "<br/>";
			  $Shipment_method_id=$d->Shipment_method_id;
              
			  $CBM_Size=$d->CBM_Size;
             
			  $Country_dest_id=$d->Country_dest_id;
			  $Port_land_id=$d->Port_land_id;

              $Shipment_method_arr=$this->Admin_model->get_data('Shipment_Method',array('Shipment_id'=>$Shipment_method_id));
             
			  $Country_dest_arr=$this->Admin_model->get_data('country_val',array('country_id'=>$Country_dest_id));
			  $Port_land_arr=$this->Admin_model->get_data('ports_loading',array('ports_id'=>$Port_land_id));

            $Port_land=$Port_land_arr[0]->Port_name;
                $Country_dest=$Country_dest_arr[0]->name;
            $Shipment_method=$Shipment_method_arr[0]->Shipment_name;


                $prd_data=explode('|#|', $d->ir_prd_id);
                $prd_qnty=explode('|#|', $d->ir_prd_qnty);
                $date_diff=strtotime($current_date)-strtotime($d->ir_order_date);
                $final_date_diff=round($date_diff / (60 * 60 * 24));
            //  print_r( $final_date_diff);echo "<br/>";
            //   if($final_date_diff>'3')
              //  {
               $flag=1;      
        $mail_body="<table class='table table-bordered'>";
         $mail_body.="<tbody>";
         $mail_body.="<tr>";
         $mail_body.="<td>Item Request No.</td>";
         $mail_body.="<td> Date</td>";
         $mail_body.="<td> Issued by</td>";
		 $mail_body.="<td>CBM Size</td>";
            $mail_body.="<td>Port_land</td>"; 
           $mail_body.="<td>Country_dest</td>";
          $mail_body.="<td>Shipment_method</td>";

         $mail_body.="<td>Item Details</td>";
		 
         $mail_body.="</tr>";
         $mail_body.="<tr>";
         $mail_body.="<td>".$d->ir_req_no."</td>";
          $mail_body.="<td>".$d->ir_order_date."</td>";
          $mail_body.="<td>".$d->ir_user_created."</td>";
		  $mail_body.="<td>".$CBM_Size."</td>";
		   $mail_body.="<td>".$Port_land."</td>";
		    $mail_body.="<td>".$Country_dest."</td>";
			 $mail_body.="<td>".$Shipment_method."</td>";
          $mail_body.="<td>";
            $mail_body.="<table class='table table-bordered'>";
            $mail_body.="<tbody>";
            $mail_body.="<tr>";
            $mail_body.="<td> Photo </td>";
            $mail_body.="<td>Item Name</td>";
            $mail_body.="<td> Quantity</td>";
            $mail_body.="</tr>";

         foreach($prd_data as $index=>$pd3)
            {
                $prd_info=$this->tm->get_data('products',array('pid'=>$pd3));
                $prd_name_db=explode('|--|',$prd_info[0]->pname);
                if(empty($prd_info[0]->p_prd_img))
                        {
                            $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
                         if (file_exists($filename)) {
                            $img_path=$filename;
                            } else {
                            $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
                            }
                        }
                        else
                        {
                            $first_img_prd=explode(',',$prd_info[0]->p_prd_img);
                            if(!empty($first_img_prd[0]))
                            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
                            else
                            $img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
                            
                        }

                if(!empty($prd_name_db[1]))
                    $prd_name= $prd_name_db[0].'<br/>'.$prd_name_db[1];
                else
                    $prd_name= $prd_info[0]->pname;

             $mail_body.="<tr>";
             $mail_body.="<td><img src='".$img_path."' width='100' height='100'></td>";
             $mail_body.="<td>".$prd_name."</td>";
             $mail_body.="<td>".$prd_qnty[$index]."</td>";
             $mail_body.="</tr>";
            }
              $mail_body.="<tbody>";
              $mail_body.="</table>";
            $mail_body.="</td>";

            $mail_body.="</tr>";
            $mail_body.="</tbody>";
            $mail_body.="</table>";
            // print_r($mail_body);  

            $a[].=$mail_body;           
               // }
             }
             if($flag==1)
             {  mail_ready_pallet_reminder($a);}
             
        }
           

       }
       

     
    }


////end ksa///


/////ca/////

 function check_pallet_ca()
    {

           $CbM=$this->Admin_model->CBM_Ready_count('ca_item_request',null);
       $NumberofCBM=$CbM[0]->total_cbm;
        $palletSize = 3.3;

      $numberOfPallets = $NumberofCBM / $palletSize;
      
      $condition_pallet=round($numberOfPallets);
       if($condition_pallet>=15)
       {
           
            $data = $this->Admin_model->get_data_multiple('ca_item_request', array( array('ir_req_status' => '3', 'ir_sts' => '1'), array('ir_req_status' => '4', 'ir_sts' => '1') ));
     
   
        $count_new_req=count($data);$flag=0;
        if(!empty($data))
        {
            $a=array();
             $current_date=date('Y-m-d');            
             foreach($data as $d)
             {
              //  pre_list($d);echo "<br/>";
			  $Shipment_method_id=$d->Shipment_method_id;
              
			  $CBM_Size=$d->CBM_Size;
             
			  $Country_dest_id=$d->Country_dest_id;
			  $Port_land_id=$d->Port_land_id;

              $Shipment_method_arr=$this->Admin_model->get_data('Shipment_Method',array('Shipment_id'=>$Shipment_method_id));
             
			  $Country_dest_arr=$this->Admin_model->get_data('country_val',array('country_id'=>$Country_dest_id));
			  $Port_land_arr=$this->Admin_model->get_data('ports_loading',array('ports_id'=>$Port_land_id));

            $Port_land=$Port_land_arr[0]->Port_name;
                $Country_dest=$Country_dest_arr[0]->name;
            $Shipment_method=$Shipment_method_arr[0]->Shipment_name;


                $prd_data=explode('|#|', $d->ir_prd_id);
                $prd_qnty=explode('|#|', $d->ir_prd_qnty);
                $date_diff=strtotime($current_date)-strtotime($d->ir_order_date);
                $final_date_diff=round($date_diff / (60 * 60 * 24));
            //  print_r( $final_date_diff);echo "<br/>";
             //  if($final_date_diff>'3')
               // {
               $flag=1;      
        $mail_body="<table class='table table-bordered'>";
         $mail_body.="<tbody>";
         $mail_body.="<tr>";
         $mail_body.="<td>Item Request No.</td>";
         $mail_body.="<td> Date</td>";
         $mail_body.="<td> Issued by</td>";
		 $mail_body.="<td>CBM Size</td>";
            $mail_body.="<td>Port_land</td>"; 
           $mail_body.="<td>Country_dest</td>";
          $mail_body.="<td>Shipment_method</td>";

         $mail_body.="<td>Item Details</td>";
		 
         $mail_body.="</tr>";
         $mail_body.="<tr>";
         $mail_body.="<td>".$d->ir_req_no."</td>";
          $mail_body.="<td>".$d->ir_order_date."</td>";
          $mail_body.="<td>".$d->ir_user_created."</td>";
		  $mail_body.="<td>".$CBM_Size."</td>";
		   $mail_body.="<td>".$Port_land."</td>";
		    $mail_body.="<td>".$Country_dest."</td>";
			 $mail_body.="<td>".$Shipment_method."</td>";
          $mail_body.="<td>";
            $mail_body.="<table class='table table-bordered'>";
            $mail_body.="<tbody>";
            $mail_body.="<tr>";
            $mail_body.="<td> Photo </td>";
            $mail_body.="<td>Item Name</td>";
            $mail_body.="<td> Quantity</td>";
            $mail_body.="</tr>";

         foreach($prd_data as $index=>$pd3)
            {
                $prd_info=$this->tm->get_data('products',array('pid'=>$pd3));
                $prd_name_db=explode('|--|',$prd_info[0]->pname);
                if(empty($prd_info[0]->p_prd_img))
                        {
                            $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
                         if (file_exists($filename)) {
                            $img_path=$filename;
                            } else {
                            $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
                            }
                        }
                        else
                        {
                            $first_img_prd=explode(',',$prd_info[0]->p_prd_img);
                            if(!empty($first_img_prd[0]))
                            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
                            else
                            $img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
                            
                        }

                if(!empty($prd_name_db[1]))
                    $prd_name= $prd_name_db[0].'<br/>'.$prd_name_db[1];
                else
                    $prd_name= $prd_info[0]->pname;

             $mail_body.="<tr>";
             $mail_body.="<td><img src='".$img_path."' width='100' height='100'></td>";
             $mail_body.="<td>".$prd_name."</td>";
             $mail_body.="<td>".$prd_qnty[$index]."</td>";
             $mail_body.="</tr>";
            }
              $mail_body.="<tbody>";
              $mail_body.="</table>";
            $mail_body.="</td>";

            $mail_body.="</tr>";
            $mail_body.="</tbody>";
            $mail_body.="</table>";
            // print_r($mail_body);  

            $a[].=$mail_body;           
            //    }
             }
             if($flag==1)
             {  mail_ready_pallet_reminder($a);}
             
        }
           

       }
       

     
    }



//////end ksa/////


///uae////

 function check_pallet_uae()
    {

           $CbM=$this->Admin_model->CBM_Ready_count('item_request',null);
       $NumberofCBM=$CbM[0]->total_cbm;
        $palletSize = 3.3;

      $numberOfPallets = $NumberofCBM / $palletSize;
      
      $condition_pallet=round($numberOfPallets);
       if($condition_pallet>=15)
       {
           
            $data = $this->Admin_model->get_data_multiple('item_request', array( array('ir_req_status' => '3', 'ir_sts' => '1'), array('ir_req_status' => '4', 'ir_sts' => '1') ));
     
   
        $count_new_req=count($data);$flag=0;
        if(!empty($data))
        {
            $a=array();
             $current_date=date('Y-m-d');            
             foreach($data as $d)
             {
              //  pre_list($d);echo "<br/>";
			  $Shipment_method_id=$d->Shipment_method_id;
              
			  $CBM_Size=$d->CBM_Size;
             
			  $Country_dest_id=$d->Country_dest_id;
			  $Port_land_id=$d->Port_land_id;

              $Shipment_method_arr=$this->Admin_model->get_data('Shipment_Method',array('Shipment_id'=>$Shipment_method_id));
             
			  $Country_dest_arr=$this->Admin_model->get_data('country_val',array('country_id'=>$Country_dest_id));
			  $Port_land_arr=$this->Admin_model->get_data('ports_loading',array('ports_id'=>$Port_land_id));

            $Port_land=$Port_land_arr[0]->Port_name;
                $Country_dest=$Country_dest_arr[0]->name;
            $Shipment_method=$Shipment_method_arr[0]->Shipment_name;


                $prd_data=explode('|#|', $d->ir_prd_id);
                $prd_qnty=explode('|#|', $d->ir_prd_qnty);
                $date_diff=strtotime($current_date)-strtotime($d->ir_order_date);
                $final_date_diff=round($date_diff / (60 * 60 * 24));
            //  print_r( $final_date_diff);echo "<br/>";
               //if($final_date_diff>'3')
               // {
               $flag=1;      
        $mail_body="<table class='table table-bordered'>";
         $mail_body.="<tbody>";
         $mail_body.="<tr>";
         $mail_body.="<td>Item Request No.</td>";
         $mail_body.="<td> Date</td>";
         $mail_body.="<td> Issued by</td>";
		 $mail_body.="<td>CBM Size</td>";
            $mail_body.="<td>Port_land</td>"; 
           $mail_body.="<td>Country_dest</td>";
          $mail_body.="<td>Shipment_method</td>";

         $mail_body.="<td>Item Details</td>";
		 
         $mail_body.="</tr>";
         $mail_body.="<tr>";
         $mail_body.="<td>".$d->ir_req_no."</td>";
          $mail_body.="<td>".$d->ir_order_date."</td>";
          $mail_body.="<td>".$d->ir_user_created."</td>";
		  $mail_body.="<td>".$CBM_Size."</td>";
		   $mail_body.="<td>".$Port_land."</td>";
		    $mail_body.="<td>".$Country_dest."</td>";
			 $mail_body.="<td>".$Shipment_method."</td>";
          $mail_body.="<td>";
            $mail_body.="<table class='table table-bordered'>";
            $mail_body.="<tbody>";
            $mail_body.="<tr>";
            $mail_body.="<td> Photo </td>";
            $mail_body.="<td>Item Name</td>";
            $mail_body.="<td> Quantity</td>";
            $mail_body.="</tr>";

         foreach($prd_data as $index=>$pd3)
            {
                $prd_info=$this->tm->get_data('products',array('pid'=>$pd3));
                $prd_name_db=explode('|--|',$prd_info[0]->pname);
                if(empty($prd_info[0]->p_prd_img))
                        {
                            $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
                         if (file_exists($filename)) {
                            $img_path=$filename;
                            } else {
                            $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
                            }
                        }
                        else
                        {
                            $first_img_prd=explode(',',$prd_info[0]->p_prd_img);
                            if(!empty($first_img_prd[0]))
                            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
                            else
                            $img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
                            
                        }

                if(!empty($prd_name_db[1]))
                    $prd_name= $prd_name_db[0].'<br/>'.$prd_name_db[1];
                else
                    $prd_name= $prd_info[0]->pname;

             $mail_body.="<tr>";
             $mail_body.="<td><img src='".$img_path."' width='100' height='100'></td>";
             $mail_body.="<td>".$prd_name."</td>";
             $mail_body.="<td>".$prd_qnty[$index]."</td>";
             $mail_body.="</tr>";
            }
              $mail_body.="<tbody>";
              $mail_body.="</table>";
            $mail_body.="</td>";

            $mail_body.="</tr>";
            $mail_body.="</tbody>";
            $mail_body.="</table>";
            // print_r($mail_body);  

            $a[].=$mail_body;           
               // }
             }
             if($flag==1)
             {  mail_ready_pallet_reminder($a);}
             
        }
           

       }
       

     
    }


//end uae///






















}