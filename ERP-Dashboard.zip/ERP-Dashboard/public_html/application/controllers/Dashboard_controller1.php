<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_controller1 extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper('session');
	}


function this_range_date()
{
if(logged_in())
	{
	$start_date_selected= $this->input->post('start_date_selected');
	$end_date_selected=$this->input->post('end_date_selected');
		
if(!empty($start_date_selected))
{	
$date_rng_strt1 = str_replace("/", "-", $start_date_selected);
$date1_start=explode('-', $date_rng_strt1);
			$month1=$date1_start[0];
			$date1=$date1_start[1];
			$year1=$date1_start[2];
$start_date=$year1.'-'.$month1.'-'.$date1;
}
else
{
	$start_date='';
}

if(!empty($end_date_selected))
{
$date_rng_end2 = str_replace("/", "-", $end_date_selected);
$date1_end=explode('-', $date_rng_end2);
			$month2=$date1_end[0];
			$date2=$date1_end[1];
			$year2=$date1_end[2];
$current_date=$year2.'-'.$month2.'-'.$date2;
}
else
{
$current_date='';
}


$banks_array=array('ADIB-BBMS','ADIB-Factory','ENBD','EI Bank','Cash Mr. Bachir Book','Cash Garhoud','Cash Factory','Other Bank');
		$limit='1';
		$order_by=('ae_date,ae_bal_amount');
			$order_type="DESC";
			$opening_balances=array();
	foreach($banks_array as $bank)
	{
		$cond_new=array('ae_bank'=>$bank,'ae_status'=>'1');
		$opening_balances=$this->Admin_model->get_opening_bal($cond_new);
		$base_opening_amount[]=$opening_balances[0]->ae_amount;
	}
	
	//print_r($banks_array);						
	$bbms_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);
	$bbms_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);

	$bbms['result']=(($bbms_rx2[0]->rx_total+$base_opening_amount[0])-($bbms_spend2[0]->spend_total));///upto this financial year
//////////////////////////////

	///////for only approved and not expected////
$bbms_rx2_approved=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);
	$bbms_spend2_approved=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);

	$bbms_approved['result']=(($bbms_rx2_approved[0]->rx_total+$base_opening_amount[0])-($bbms_spend2_approved[0]->spend_total));

// print_r($bbms_rx2);
// echo "<br/>";
// print_r($bbms_spend2);
// 	echo "<br/>";
// 	echo "for approved transcations";
// 	print_r($bbms_rx2_approved);
// 	echo "<br/>";
// 	print_r($bbms_spend2_approved);
// 	echo "<br/>";



	$factory_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);
	$factory_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);

	$factory['result']=(($factory_rx2[0]->rx_total+$base_opening_amount[1])-($factory_spend2[0]->spend_total));///upto this financial year//////

	///////for only approved and not expected////
$factory_rx2_approved=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);
	$factory_spend2_approved=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);

	$factory_approved['result']=(($factory_rx2_approved[0]->rx_total+$base_opening_amount[0])-($factory_spend2_approved[0]->spend_total));

	$enbd_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);
	$enbd_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);

	$enbd['result']=(($enbd_rx2[0]->rx_total+$base_opening_amount[2])-($enbd_spend2[0]->spend_total));///upto this financial year
//////////////////////////////////////////////////////

	///////for only approved and not expected////
	$enbd_rx2_approved=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);
	$enbd_spend2_approved=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);

	$enbd_approved['result']=(($enbd_rx2_approved[0]->rx_total+$base_opening_amount[2])-($enbd_spend2_approved[0]->spend_total));

	$ei_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);
	$ei_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);

	$ei['result']=(($ei_rx2[0]->rx_total+$base_opening_amount[3])-($ei_spend2[0]->spend_total));///upto this financial year
//////////////////////////////////////////////////////

	///////for only approved and not expected////
	$ei_rx2_approved=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);
	$ei_spend2_approved=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);

$ei_approved['result']=(($ei_rx2_approved[0]->rx_total+$base_opening_amount[3])-($ei_spend2_approved[0]->spend_total));


		$bachir_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);
	$bachir_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);

	$bachir['result']=(($bachir_rx2[0]->rx_total+$base_opening_amount[4])-($bachir_spend2[0]->spend_total));///upto this financial year
//////////////////////////////////////////////////////

	///////for only approved and not expected////
	$bachir_rx2_approved=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);
	$bachir_spend2_approved=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);

	$bachir_approved['result']=(($bachir_rx2_approved[0]->rx_total+$base_opening_amount[4])-($bachir_spend2_approved[0]->spend_total));


$garhoud_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);
	$garhoud_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);

	$garhoud['result']=(($garhoud_rx2[0]->rx_total+$base_opening_amount[5])-($garhoud_spend2[0]->spend_total));///upto this financial year
//////////////////////////////////////////////////////

	///////for only approved and not expected////
	$garhoud_rx2_approved=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);
	$garhoud_spend2_approved=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);

	$garhoud_approved['result']=(($garhoud_rx2_approved[0]->rx_total+$base_opening_amount[5])-($garhoud_spend2_approved[0]->spend_total));

	$cash_fact_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);
	$cash_fact_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);

	$cash_fact['result']=(($cash_fact_rx2[0]->rx_total+$base_opening_amount[6])-($cash_fact_spend2[0]->spend_total));///upto this financial year
//////////////////////////////////////////////////////
	///////for only approved and not expected////
	$cash_fact_rx2_approved=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);
	$cash_fact_spend2_approved=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);

	$cash_fact_approved['result']=(($cash_fact_rx2_approved[0]->rx_total+$base_opening_amount[6])-($cash_fact_spend2_approved[0]->spend_total));

$other_bank_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);
	$other_bank_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances'),$start_date,$current_date);

	$other_bank['result']=(($other_bank_rx2[0]->rx_total+$base_opening_amount[7])-($other_bank_spend2[0]->spend_total));///upto this financial year
//////////////////////////////////////////////////////

	///////for only approved and not expected////
	$other_bank_rx2_approved=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);
	$other_bank_spend2_approved=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date,$current_date);

	$other_bank_approved['result']=(($other_bank_rx2_approved[0]->rx_total+$base_opening_amount[7])-($other_bank_spend2_approved[0]->spend_total));

	/////////////done//////////

	if(!empty($bbms['result']))
		$bbms_result=$bbms['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$bbms_result='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$bbms_result=$base_opening_amount[0];
		else
		$bbms_result=$base_opening_amount[0];

	}

	if(!empty($factory['result']))
		$fact_result=$factory['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$fact_result='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$fact_result=$base_opening_amount[1];
		else
		$fact_result=$base_opening_amount[1];
		
	}

	if(!empty($enbd['result']))
		$ENBD=$enbd['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$ENBD='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$ENBD=$base_opening_amount[2];
		else
		$ENBD=$base_opening_amount[2];
	}

	if(!empty($ei['result']))
		$ei_bank=$ei['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$ei_bank='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$ei_bank=$base_opening_amount[3];
		else
		$ei_bank=$base_opening_amount[3];
	}

	if(!empty($bachir['result']))
		$cash_bachir=$bachir['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$cash_bachir='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$cash_bachir=$base_opening_amount[4];
		else
		$cash_bachir=$base_opening_amount[4];
	}

	if(!empty($garhoud['result']))
		$Garhoud=$garhoud['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$Garhoud='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$Garhoud=$base_opening_amount[5];
		else
		$Garhoud=$base_opening_amount[5];
	}

	if(!empty($cash_fact['result']))
		$cash_fact=$cash_fact['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$cash_fact='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$cash_fact=$base_opening_amount[6];
		else
		$cash_fact=$base_opening_amount[6];
	}

	if(!empty($other_bank['result']))
		$others=$other_bank['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$others='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$others=$base_opening_amount[7];
		else
		$others=$base_opening_amount[7];
	}

	// $total_bank_bal=(($bbms_result)+($fact_result)+($ENBD)+($ei_bank)+($others) );

	// $total_cash_bal=(($cash_bachir)+($Garhoud)+($cash_fact));


	if(!empty($bbms_approved['result']))
		$bbms_result_approved=$bbms_approved['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$bbms_result_approved='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$bbms_result_approved=$base_opening_amount[0];
		else
		$bbms_result_approved=$base_opening_amount[0];

	}

	if(!empty($factory_approved['result']))
		$fact_result_approved=$factory_approved['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$fact_result_approved='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$fact_result_approved=$base_opening_amount[1];
		else
		$fact_result_approved=$base_opening_amount[1];
		
	}

	if(!empty($enbd_approved['result']))
		$ENBD_approved=$enbd_approved['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$ENBD_approved='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$ENBD_approved=$base_opening_amount[2];
		else
		$ENBD_approved=$base_opening_amount[2];
	}

	if(!empty($ei_approved['result']))
		$ei_bank_approved=$ei_approved['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$ei_bank_approved='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$ei_bank_approved=$base_opening_amount[3];
		else
		$ei_bank_approved=$base_opening_amount[3];
	}

	if(!empty($bachir_approved['result']))
		$cash_bachir_approved=$bachir_approved['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$cash_bachir_approved='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$cash_bachir_approved=$base_opening_amount[4];
		else
		$cash_bachir_approved=$base_opening_amount[4];
	}

	if(!empty($garhoud_approved['result']))
		$Garhoud_approved=$garhoud_approved['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$Garhoud_approved='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$Garhoud_approved=$base_opening_amount[5];
		else
		$Garhoud_approved=$base_opening_amount[5];
	}

	if(!empty($cash_fact_approved['result']))
		$cash_fact_approved=$cash_fact_approved['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$cash_fact_approved='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$cash_fact_approved=$base_opening_amount[6];
		else
		$cash_fact_approved=$base_opening_amount[6];
	}

	if(!empty($other_bank_approved['result']))
		$others_approved=$other_bank_approved['result'];
	else
	{
		if(!empty($start_date_selected) && !empty($end_date_selected))
		$others_approved='0';
		elseif(empty($start_date_selected) && !empty($end_date_selected))
		$others_approved=$base_opening_amount[7];
		else
		$others_approved=$base_opening_amount[7];
	}

	$total_bank_bal=(($bbms_result_approved)+($fact_result_approved)+($ENBD_approved)+($ei_bank_approved)+($others_approved) );

	$total_cash_bal=(($cash_bachir_approved)+($Garhoud_approved)+($cash_fact_approved));
		
		/////category based data///
$cat_array=array('Shipping','Sales','General Expenses','Salaries','Raw Material Purchases','Import Purchases','Personal Accounts','Rent','Others');
		// $limit='1';
		// $order_by='ae_date';
		// 	$order_type="DESC";
	
	//print_r($banks_array);					
	$ship=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[0],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date,'ae_date <='=>$current_date),'','','','');
$ship_result=0;
	foreach ($ship as $sr) {
		# code...
		if(($sr->ae_cash_type)=="Received")
			{
				$ship_result=$ship_result+$sr->ae_amount;
			}
		else
			{
				$ship_result=$ship_result-$sr->ae_amount;
			}
	}
	
	$sales=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[1],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date,'ae_date <='=>$current_date),'','','','');
	$sales_result=0;
	foreach ($sales as $sl) {
		# code...
		if(($sl->ae_cash_type)=="Received")
			{
				$sales_result=$sales_result+$sl->ae_amount;
			}
		else
			{
				$sales_result=$sales_result-$sl->ae_amount;
			}
	}

	$gnrl=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[2],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date,'ae_date <='=>$current_date),'','','','');
	$gnrl_result=0;
	foreach ($gnrl as $gl) {
		# code...
		if(($gl->ae_cash_type)=="Received")
			{
				$gnrl_result=$gnrl_result+$gl->ae_amount;
			}
		else
			{
				$gnrl_result=$gnrl_result-$gl->ae_amount;
			}
	}

	$salary=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[3],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date,'ae_date <='=>$current_date),'','','','');
	$salary_result=0;
	foreach ($salary as $sa) {
		# code...
		if(($sa->ae_cash_type)=="Received")
			{
				$salary_result=$salary_result+$sa->ae_amount;
			}
		else
			{
				$salary_result=$salary_result-$sa->ae_amount;
			}
	}

	$raw_mat=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[4],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date,'ae_date <='=>$current_date),'','','','');
	$raw_result=0;
	foreach ($raw_mat as $rm) {
		# code...
		if(($rm->ae_cash_type)=="Received")
			{
				$raw_result=$raw_result+$rm->ae_amount;
			}
		else
			{
				$raw_result=$raw_result-$rm->ae_amount;
			}
	}

	$import=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[5],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date,'ae_date <='=>$current_date),'','','','');
	$import_result=0;
	foreach ($import as $im) {
		# code...
		if(($im->ae_cash_type)=="Received")
			{
				$import_result=$import_result+$im->ae_amount;
			}
		else
			{
				$import_result=$import_result-$im->ae_amount;
			}
	}

	$export=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[6],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date,'ae_date <='=>$current_date),'','','','');
	$exprt_result=0;
	foreach ($export as $xpt) {
		# code...
		if(($xpt->ae_cash_type)=="Received")
			{
				$exprt_result=$exprt_result+$xpt->ae_amount;
			}
		else
			{
				$exprt_result=$exprt_result-$xpt->ae_amount;
			}
	}

	$rent=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[7],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date,'ae_date <='=>$current_date),'','','','');
	$rent_result=0;
	foreach ($rent as $rnt) {
		# code...
		if(($rnt->ae_cash_type)=="Received")
			{
				$rent_result=$rent_result+$rnt->ae_amount;
			}
		else
			{
				$rent_result=$rent_result-$rnt->ae_amount;
			}
	}

	$other_cat=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[8],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date,'ae_date <='=>$current_date),'','','','');
	$other_cat_result=0;
	foreach ($other_cat as $oc) {
		# code...
		if(($oc->ae_cash_type)=="Received")
			{
				$other_cat_result=$other_cat_result+$oc->ae_amount;
			}
		else
			{
				$other_cat_result=$other_cat_result-$oc->ae_amount;
			}
	}


	if(!empty($ship_result))
		$shipping=$ship_result;
	else
		$shipping="0";

	if(!empty($salary_result))
		$salaries=$salary_result;
	else
		$salaries="0";

	if(!empty($gnrl_result))
		$gnrl=$gnrl_result;
	else
		$gnrl="0";

	if(!empty($sales_result))
		$sales=$sales_result;
	else
		$sales="0";

	if(!empty($raw_result))
		$raw_mat=$raw_result;
	else
		$raw_mat="0";

	if(!empty($import_result))
		$import=$import_result;
	else
		$import="0";

	if(!empty($exprt_result))
		$export=$exprt_result;
	else
		$export="0";

	if(!empty($rent_result))
		$rent=$rent_result;
	else
		$rent="0";

	if(!empty($other_cat_result))
		$other_cat=$other_cat_result;
	else
		$other_cat="0";

	$total_cat=($other_cat + $rent + $export + $import + $raw_mat + $salaries + $gnrl + $shipping + $sales );

	if(!empty($start_date) && !empty($current_date))
	{
		 $date_selected= ' from '.$start_date.' to '.$current_date;
	}
	else{
		 $date_selected= '';
	}

		$data=array(
			'bbms'=>number_format((float)$bbms_result, 2, '.', ''),
		'factory'=>number_format((float)$fact_result, 2, '.', ''),
				'ENBD'=>number_format((float)$ENBD, 2, '.', ''),
			'other_bank'=>number_format((float)$others, 2, '.', ''),
			'ei_bank'=>number_format((float)$ei_bank, 2, '.', ''),
			'Garhoud'=>number_format((float)$Garhoud, 2, '.', ''),
	'cash_bachir'=>number_format((float)$cash_bachir, 2, '.', ''),
	'cash_fact'=>number_format((float)$cash_fact, 2, '.', ''),
				'total_bank_bal'=>number_format((float)$total_bank_bal, 2, '.', ''),
				'total_cash_bal'=>number_format((float)$total_cash_bal, 2, '.', ''),

'bbms_approved'=>number_format((float)$bbms_result_approved, 2, '.', ''),
		'factory_approved'=>number_format((float)$fact_result_approved, 2, '.', ''),
				'ENBD_approved'=>number_format((float)$ENBD_approved, 2, '.', ''),
			'other_bank_approved'=>number_format((float)$others_approved, 2, '.', ''),
			'ei_bank_approved'=>number_format((float)$ei_bank_approved, 2, '.', ''),
			'Garhoud_approved'=>number_format((float)$Garhoud_approved, 2, '.', ''),
	'cash_bachir_approved'=>number_format((float)$cash_bachir_approved, 2, '.', ''),
	'cash_fact_approved'=>number_format((float)$cash_fact_approved, 2, '.', ''),

			'shipping'=>number_format((float)$shipping, 2, '.', ''),
				'sales'=>number_format((float)$sales, 2, '.', ''),
				'gnrl'=>number_format((float)$gnrl, 2, '.', ''),
			'salary'=>number_format((float)$salaries, 2, '.', ''),
			'raw_mat'=>number_format((float)$raw_mat, 2, '.', ''),
				'rent'=>number_format((float)$rent, 2, '.', ''),
				'import'=>number_format((float)$import, 2, '.', ''),
				'export'=>number_format((float)$export, 2, '.', ''),
			'other'=>number_format((float)$other_cat, 2, '.', ''),
		'total_cat'=>number_format((float)$total_cat, 2, '.', ''),
		'bank_date'=>$date_selected,
			);
 //print_r($data);
		echo json_encode($data);
	}
}
















}