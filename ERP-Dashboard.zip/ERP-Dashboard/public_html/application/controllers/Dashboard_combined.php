<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_combined extends CI_Controller {

public function __construct() {
		parent::__construct();
	
			$this->load->helper(array('session','email','img','gnrl','email_survey','text'));
		$this->load->model('Third_db_model','tm');
	}

function combined_dashboard()
{

   if(logged_in())
	{

     
			 $this->send_mail_loguser();  

				$activitylogin_data=array(
				'page_user'=>$this->session->userdata['user']['username'],
				'user_activity'=>'User Logged',
				'page_userip'=>$this->session->userdata['user']['location_ip'],
				'page_pc'=>$this->session->userdata['user']['devicedetailsinfo'],
				'page_country'=>$this->session->userdata['user']['state'],
				'date_time_logged'=>get_date_time(),
			);
			   $this->Admin_model->insert_data('activitieslogin',$activitylogin_data);


	$data['item_request_data']=$this->Admin_model->get_data('item_request',array('ir_sts'=>'1'));
	$data['po_data']=$this->tm->get_data('prd_order',array('po_sts'=>'1'));
	$this->load->view('admin/dashboard_combined_po_ir',$data);

}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 






}


function send_mail_loguser()
{
	     $this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
$config['smtp_crypto'] = 'tls'; 
$config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

$page_user= $this->session->userdata['user']['username'];
//$page_userip=$this->session->userdata['user']['location_ip'];

$page_userip=$this->session->userdata['user']['ipsession'];
$page_serverip= $this->session->userdata['user']['server_ip'];
$page_email=$this->session->userdata['user']['user_email'];
$page_pc=$this->session->userdata['user']['computername'];
$page_state=$this->session->userdata['user']['state'];
$page_country=$this->session->userdata['user']['country'];
$page_cityserverprovider=$this->session->userdata['user']['cityserverprovider'];
$page_hostname=$this->session->userdata['user']['hostname'];
$page_lat=$this->session->userdata['user']['user_lat'];
$user_long=$this->session->userdata['user']['user_long'];
  
$user_serverorg=$this->session->userdata['user']['user_serverorg'];

$browsername=$this->session->userdata['user']['browsername'];
$browserversion=$this->session->userdata['user']['browserversion'];
$operatingsystem=$this->session->userdata['user']['operatingsystem'];


$devicedetailsinfo=$this->session->userdata['user']['devicedetailsinfo'];
$ipsession=$this->session->userdata['user']['ipsession'];
// $mobile=$this->session->userdata['user']['mobile'];
$date_time=get_date_time();

// print_r($page_email);
// exit(0);


     
          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to("support@birigroup.com");
          $this->email->to($page_email);    

          $this->email->subject('Loggedin Activity Happend :');
		 $msg="Dear ".$page_user.", <br/> Your Account Loggedin From Device Below  <br/><br/>";

		 $msg.="You Loggedin From  :  "  .$page_country."<br/><br/>";
		  $msg.="State :  "  .$page_state."<br/><br/>";
		  $msg.="Using IP Adress :  "  .$ipsession."<br/><br/>";
	
		  $msg.="from Device :  "  .$devicedetailsinfo." on server  " .   $page_pc  .     "<br/><br/>";
		  $msg.="Operating System:  "  .$operatingsystem.  "  <br/><br/>";
        $msg.="Browser:  ".$browsername." Version :  " .$browserversion. "  <br/><br/>";

         $msg.="Server Provider :  "  .$user_serverorg."<br/><br/>";

          $msg.="Host Name :  "  .$page_hostname."<br/><br/>";
           $msg.="Latitude :  "  .$page_lat. "<br/><br/>"; 
           $msg.="Longtude :  "  .$user_long. "<br/><br/>";        
                       
        
		  $msg.="Login date  :  "  .$date_time."<br/><br/>";
		
		  $msg.="<br/><br/>";
 $msg.="Thank you!<br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}








}