<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Masters_essentials extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','email_survey'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
	}



	function create_company()
	{
		if(logged_in())
		{


			 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='master-company')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



		$data['result']=$this->Admin_model->get_data('master_company',array('mcomp_sts'=>'1','mcomp_pid'=>'0'));
		foreach($data['result'] as $key=>$er)
		{
			$data['child'][$key][]=$this->Admin_model->get_data('master_company',array('mcomp_sts'=>'1','mcomp_pid'=>$er->mcomp_id));
		}
		$this->load->view('admin/master_essential/company_master',$data);
    }

else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


	}

	public function currecny_convt()
	{



		if(logged_in())
		{
  
        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='master-currency-converter')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

		$data['result']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
		$this->load->view('admin/master_essential/currency_conv',$data);
	}

  else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 



	} 
		
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	

   }

} 
	
function submit_curency_values()
{
	$edit_convi_id=$this->input->post('conv_id');
		$data=array(
		'currency_name'=>$this->input->post('currency_name'),
		'currency_val'=>$this->input->post('currency_val'),
		'c_sts'=>'1',
		'c_user_id'=>$this->session->userdata['user']['username'],
	);

	if(empty($edit_convi_id))
	{
	$insert_id=$this->Admin_model->insert_data('master_currency_conv',$data);
	$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	else
	{
		$insert_id=$this->Admin_model->update_data('master_currency_conv',$data,array('c_id'=>$edit_convi_id));
		$this->session->set_flashdata('success', 'Data Successfully edited');
	}
		redirect('master-currency-converter');
}

function discussion_module()
{
	$data=array(
	'msg_data'=>$this->input->post('msg_data'),
	'user_created'=>$this->input->post('user_created'),
	'page_url'=>$this->input->post('page_url'),
	);
	$this->Admin_model->insert_data('discussion_chat',$data);

	$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>$this->input->post('page_url')));

	$html_data=$this->load->view('admin/master_essential/chat_data',$data);

	return $html_data;
}

function refresh_chat_data()
{
	$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>$this->input->post('page_url')));

	$html_data=$this->load->view('admin/master_essential/chat_data',$data);

	return $html_data;
}
	function asset_register()
	{
		if(logged_in())
		{

           $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='asset-register')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {
				$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
		      $this->load->view('admin/master_essential/assets_register',$data);
             } 
		
        else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
          }

		}
	}


	 function submit_asset_reg($value='')
	{
		$asset_class=$this->input->post('asset_class');
		$code_start='';
				$life='';
		switch ($asset_class) {
			case '1':
				$code_start='1';
				$life='1';
				break;

				case '2':
				$code_start='2';
				$life='25';
				break;

				case '3':
				$code_start='3';
				$life='10';
				break;

				case '4':
				$code_start='4';
				$life='5';
				break;

				case '5':
				$code_start='5';
				$life='5';
				break;

				case '6':
				$code_start='6';
				$life='3';
				break;
			
			default:
				$code_start='';
				$life='';
				break;
		}

		
		$date_commisioning=$this->input->post('date_ref');
$date1=explode('/',$date_commisioning);
			$month=$date1[0];
			$date=$date1[1];
			$year=$date1[2];
$new_formated_date=$year.'-'.$month.'-'.$date;

$asset_gross=$this->input->post('groos_val');
$annual_dep=($asset_gross/$life);
$monthly_dep=($annual_dep/12);
$accumulated_dep=(($annual_dep*2)+($monthly_dep*4));
$net_book_value= ($asset_gross-$accumulated_dep);

		$data=array(
			'asset_class'=>$this->input->post('asset_class'),
			'asset_life'=>$life,
			'asset_desc'=>$this->input->post('asset_desc'),
			'asset_gross'=>$this->input->post('groos_val'),
			'commisiong_date'=>$new_formated_date,
			'annual_depriciation'=>number_format((float)$annual_dep, 2, '.', ''),
			'monthly_depriciation'=>number_format((float)$monthly_dep, 2, '.', ''),
			'accumulated_dep'=>number_format((float)$accumulated_dep, 2, '.', ''),
			'net_book_value'=>number_format((float)$net_book_value, 2, '.', ''),
			'company'=>$this->input->post('company_masters'),
			'asset_sts'=>'1',
			'user_id'=>$this->session->userdata['user']['username'],
			);

		$insert_id=$this->Admin_model->insert_data('asset_reg',$data);
		$this->Admin_model->update_data('asset_reg',array('asset_code'=>$code_start.'000'.$insert_id),array('asset_id'=>$insert_id));
		$this->session->set_flashdata('success', 'Data Successfully inserted');
		redirect('list-asset-register');
	}


function list_asset_register()
{
    if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-asset-register')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



	$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
    $data['result']=$this->Admin_model->get_data('asset_reg',array('asset_sts'=>'1'));
	$this->load->view('admin/master_essential/list_assets_register',$data);

}

else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 




}


function product_master()
{


 if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='product-master')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

$data_result_set12=$this->tm->get_data('products',array('p_sts'=>'1'),'','','pcat','ASC');
$cat_array=array();
$new_prd_array=array();
foreach ($data_result_set12 as $key => $value) {
	if(empty($new_prd_array))
	{
	$new_prd_array[$value->pcat]['name'][]=$value->pname;
	$new_prd_array[$value->pcat]['price'][]=$value->p_uae_final;
	$new_prd_array[$value->pcat]['code'][]=$value->pcode;
	}
	else
	{
		if($value->pcat==$new_prd_array[$value->pcat])
		{
			$new_prd_array[$value->pcat]['name'][]=$value->pname;
			$new_prd_array[$value->pcat]['price'][]=$value->p_uae_final;
			$new_prd_array[$value->pcat]['code'][]=$value->pcode;
		}
		else
		{
			$new_prd_array[$value->pcat]['name'][]=$value->pname;
			$new_prd_array[$value->pcat]['price'][]=$value->p_uae_final;
			$new_prd_array[$value->pcat]['code'][]=$value->pcode;
		}
	}
}
$data['result']=$new_prd_array;
$this->load->view('admin/master_essential/product_master',$data);	
}

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 




}
function test_tree_acc()
{
$data_result_set12=$this->tm->get_data('products',array('p_sts'=>'1'),'','','pcat','ASC');
$cat_array=array();
$new_prd_array=array();
foreach ($data_result_set12 as $key => $value) {
	if(empty($new_prd_array))
	{
	$new_prd_array[$value->pcat][]=$value->pname;
	}
	else
	{
		if($value->pcat==$new_prd_array[$value->pcat])
		{
			$new_prd_array[$value->pcat][]=$value->pname;
		}
		else
		{
			$new_prd_array[$value->pcat][]=$value->pname;
		}
	}
}
pre_list($new_prd_array);
		// foreach($data_result_set12 as $ds2)
		//  	{
		//  		//pre_list($ds2['id']);
		//  		$data['result_child'][$ds2['id']][]=$this->Admin_model->get_data('master_accounts_tree_file_data',array('accounts_tree_id'=>$ds2['id']));
		// 	}


	// $sql=$this->db->query("SELECT mt.id as Master_id, mt.label , mt.parent, master_accounts_tree_file_data.* FROM master_accounts_tree as mt  join master_accounts_tree_file_data on master_accounts_tree_file_data.accounts_tree_id=mt.id");
	// 	$data_result_set1=$sql->result_array();
		//pre_list($data_result_set12);
//$data['result']=$this->buildTree($data_result_set12);
	//$this->load->view('admin/master_essential/list_assets_register',$data);	
}

function master_fixed_asset()
{
	

 if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='fixed-asset-tree')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


	$sql2=$this->db->query("SELECT *
     FROM master_accounts_tree
     UNION
     SELECT * 
      FROM master_accounts_tree
      WHERE parent IN 
       (SELECT id FROM master_accounts_tree )");
		$data_result_set1=$sql2->result_array();
		$data['fixed_asset_head'] = $this->buildtree_new($data_result_set1, 235);
//pre_list($list);

		$this->load->view('admin/master_essential/fixed_assets_master',$data);	

  }

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 




}

function fetch_recursive($src_arr, $currentid, $parentfound = false, $cats = array())
{
    foreach($src_arr as $row)
    {
        if((!$parentfound && $row['id'] == $currentid) || $row['parent'] == $currentid)
        {
            $rowdata = array();
            foreach($row as $k => $v)
                $rowdata[$k] = $v;
            $cats[] = $rowdata;
            if($row['parent'] == $currentid)
                $cats = array_merge($cats, $this->fetch_recursive($src_arr, $row['id'], true));
        }
    }
    return $cats;
}
function buildtree_new($src_arr, $parent_id = 0, $tree = array())
{
    foreach($src_arr as $idx => $row)
    {
        if($row['parent'] == $parent_id)
        {
            foreach($row as $k => $v)
                $tree[$row['id']][$k] = $v;
            unset($src_arr[$idx]);
            $tree[$row['id']]['children'] = $this->buildtree_new($src_arr, $row['id']);
        }
    }
    ksort($tree);
    return $tree;
}

function buildTree_org($items) {
    $childs = array();
    foreach($items as &$item){
    	$childs[$item['parent']][] = &$item;
    	unset($item);
    }
    foreach($items as &$item){
    	if (isset($childs[$item['id']])){
    		$item['childs'] = $childs[$item['id']];
    	}
    }
    return $childs;
}

//printtree(parseTree($data_result_set12));


function database_backup()
{

	if(logged_in())
	{
      $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='master-db-backup')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


	$this->load->helper('file');
        $data['backups'] = get_filenames('./uploads/backup/');
	$this->load->view('admin/master_essential/back_up',$data);

}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


	}
	

}



function db_backup()
{
	if(logged_in())
	{
	 $this->load->helper('file');

            $this->load->dbutil();

            $prefs = array(
            	'ignore'        => array('sales_book_product', 'sales_book_report'), 
            	'format' => 'zip',
            	 'filename' => 'BD-backup_' . date('Y-m-d_H-i'));

            $backup = $this->dbutil->backup($prefs);

            if (!write_file('./uploads/backup/BD-backup_' . date('Y-m-d_H-i') . '.zip', $backup)) {

                $type = 'error';

              $this->session->set_flashdata('errors', 'Error on creating backup ');
            } else {
                $type = 'success';
             $this->session->set_flashdata('success', 'Backup Created Successfully');
            }
            redirect('master-db-backup');
	}
}

  function download_backup($file)
    {
            $this->load->helper('file');
            $this->load->helper('download');
            $data = file_get_contents('./uploads/backup/' . $file);
            force_download($file, $data);
       redirect('master-db-backup');
    }


function delete_backup($file)
{
	if(logged_in())
	{
	  $backup = file_exists('./uploads/backup/' . $file);

            if (!empty($backup)) {
                unlink('./uploads/backup/' . $file);
 $this->session->set_flashdata('success', 'Backup deleted Successfully ');
           } else {
 $this->session->set_flashdata('errors', 'Error on deleting backup ');
             }
             redirect('master-db-backup');
    }      
}


function price_level_master()
{
	if(logged_in())
	{

      
      $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='master-price-level')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



	    $data['result'] = $this->Admin_model->get_data('master_price_level',array('mpc_sts'=>'1'));
	    $this->load->view('admin/master_essential/price_level_master',$data);

       }
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 



	}
 


}



function project_master()
{
	if(logged_in())
	{

        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='master-project')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {
   

	    $data['result'] = $this->Admin_model->get_data('master_project',array('mpj_sts'=>'1'));
	   $this->load->view('admin/master_essential/project_master',$data);
    }
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 



	}
 
}


function region_master()
{
	if(logged_in())
	{


        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='master-region')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

		$sql2=$this->db->query("SELECT *
FROM master_region
UNION
SELECT * 
FROM master_region
WHERE mr_parent IN 
    (SELECT mr_id FROM master_region Order By mr_sequence ASC)");
		$data_result_set1=$sql2->result_array();
		//pre_list($data_result_set1);
		$data['result'] = $this->buildtree_region($data_result_set1);
		$this->load->view('admin/master_essential/region_master',$data);
}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 



	}


}


function buildtree_region($items) {
    $childs = array();
    foreach($items as &$item){
    	$childs[$item['mr_parent']][] = &$item;
    	unset($item);
    }
    foreach($items as &$item){
    	if (isset($childs[$item['mr_id']])){
    		$item['childs'] = $childs[$item['mr_id']];
    	}
    }
    return $childs;
}


function payment_method_masterss()
{
	if(logged_in())
	{

    $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='master-payment-methods-master')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

	    $data['result'] = $this->Admin_model->get_data('master_payment_method',array('mpm_sts'=>'1'));
	$this->load->view('admin/master_essential/payment_method_master',$data);



	}
	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
	}


}




function warehouse_master()
{
	if(logged_in())
	{
 
    $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='master-warehouse')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


		$sql2=$this->db->query("SELECT *
      FROM master_warehouse where mw_status ='1'
      UNION
     SELECT * 
      FROM master_warehouse
      WHERE mw_parent and mw_status ='1' IN 
     (SELECT mw_id FROM master_warehouse Order By mw_sequence ASC)");
		$data_result_set1=$sql2->result_array();
		//pre_list($data_result_set1);
		$data['result'] = $this->buildtree_warehouse($data_result_set1);
		$this->load->view('admin/master_essential/warehouse_master',$data);
}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
	
	}
	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 



}



function buildtree_warehouse($items) {
    $childs = array();
    foreach($items as &$item){
    	$childs[$item['mw_parent']][] = &$item;
    	unset($item);
    }
    foreach($items as &$item){
    	if (isset($childs[$item['mw_id']])){
    		$item['childs'] = $childs[$item['mw_id']];
    	}
    }
    return $childs[0];
}



function place_supply_master()
{
	if(logged_in())
	{
     
      $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='master-place-supply')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



		$sql2=$this->db->query("SELECT *
        FROM master_place_supply WHERE mps_sts='1'
        UNION
        SELECT * 
        FROM master_place_supply
         WHERE mps_sts='1' and mw_parent IN 
        (SELECT mw_id FROM master_place_supply WHERE mps_sts='1' Order By mps_sequence ASC)");
		 $data_result_set1=$sql2->result_array();
		//pre_list($data_result_set1);
	   	$data['result'] = $this->buildtree_warehouse($data_result_set1);
		 $this->load->view('admin/master_essential/place_supply',$data);
	}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
	
	}
	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 

}


function submit_master_comp()
{
	$type=$this->input->post('type');
	$root_id=$this->input->post('root_id');
	
	if($type=="new_comp")
	{
		$data= array(
		'mcomp_name'=>$this->input->post('comp_master_name'),
		'mcomp_pid'=>'0',
		'mcomp_created'=>'manager',
		'mcomp_sts'=>'1',
	 	);
		$this->Admin_model->insert_data('master_company',$data);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="creating_child")
	{
		$data2= array(
		'mcomp_name'=>$this->input->post('comp_master_name'),
		'mcomp_pid'=>$root_id,
		'mcomp_created'=>'manager',
		'mcomp_sts'=>'1',
	 );
		$this->Admin_model->insert_data('master_company',$data2);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="editing_child")
	{
		$this->Admin_model->update_data('master_company',array('mcomp_name'=>$this->input->post('comp_master_name')),array('mcomp_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully updated');
		
	}
	else{}
	redirect('master-company');
}

function delete_comp($root_id)
{
	$this->Admin_model->update_data('master_company',array('mcomp_sts'=>'0'),array('mcomp_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully deleted');
	redirect('master-company');	
}



function submit_master_warehouse()
{
	$type=$this->input->post('type');
	$root_id=$this->input->post('root_id');
	
	$sql2=$this->db->query("SELECT MAX(mw_sequence) as seq_last FROM master_warehouse ");
	$sequence_val=$sql2->result_array();

	$new_seq=$sequence_val[0]['seq_last']+1;

	if($type=="new_comp")
	{
		$data= array(
		'mw_name'=>$this->input->post('comp_master_name'),
		'mw_parent'=>'0',
		'mw_created_by'=>'manager',
		'mw_sequence'=>$new_seq,
		'mw_status'=>'1',
	 	);
		$this->Admin_model->insert_data('master_warehouse',$data);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="creating_child")
	{
		$data2= array(
		'mw_name'=>$this->input->post('comp_master_name'),
		'mw_parent'=>$root_id,
		'mw_created_by'=>'manager',
		'mw_sequence'=>$new_seq,
		'mw_status'=>'1',
	 );
		$this->Admin_model->insert_data('master_warehouse',$data2);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="editing_child")
	{
		$this->Admin_model->update_data('master_warehouse',array('mw_name'=>$this->input->post('comp_master_name')),array('mw_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully updated');
		
	}
	else{}
	redirect('master-warehouse');
}

function delete_warehouse($root_id)
{
	$this->Admin_model->update_data('master_warehouse',array('mw_status'=>'0'),array('mw_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully deleted');
	redirect('master-warehouse');	
}


function submit_plc_of_supply()
{
	$type=$this->input->post('type');
	$root_id=$this->input->post('root_id');
	
	$sql2=$this->db->query("SELECT MAX(mps_sequence) as seq_last FROM master_place_supply ");
	$sequence_val=$sql2->result_array();

	$new_seq=$sequence_val[0]['seq_last']+1;

	if($type=="new_comp")
	{
		$data= array(
		'mps_name'=>$this->input->post('comp_master_name'),
		'mw_parent'=>'0',
		'mps_created'=>'manager',
		'mps_sequence'=>$new_seq,
		'mps_sts'=>'1',
	 	);
		$this->Admin_model->insert_data('master_place_supply',$data);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="creating_child")
	{
		$data2= array(
		'mps_name'=>$this->input->post('comp_master_name'),
		'mw_parent'=>$root_id,
		'mps_created'=>'manager',
		'mps_sequence'=>$new_seq,
		'mps_sts'=>'1',
	 );
		$this->Admin_model->insert_data('master_place_supply',$data2);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="editing_child")
	{
		$this->Admin_model->update_data('master_place_supply',array('mps_name'=>$this->input->post('comp_master_name')),array('mw_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully updated');
		
	}
	else{}
	redirect('master-place-supply');
}

function delete_plc_of_supply($root_id)
{
	$this->Admin_model->update_data('master_place_supply',array('mps_sts'=>'0'),array('mw_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully deleted');
	redirect('master-place-supply');	
}


function submit_price_level()
{
	$type=$this->input->post('type');
	$root_id=$this->input->post('root_id');
	
	if($type=="new_comp")
	{
		$data= array(
		'mpc_name'=>$this->input->post('comp_master_name'),
		'mpc_created_by'=>'manager',
		'mpc_sts'=>'1',
	 	);
		$this->Admin_model->insert_data('master_price_level',$data);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="creating_child")
	{
		$data2= array(
		'mpc_name'=>$this->input->post('comp_master_name'),
		'mpc_created_by'=>'manager',
		'mpc_sts'=>'1',
	 );
		$this->Admin_model->insert_data('master_price_level',$data2);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="editing_child")
	{
		$this->Admin_model->update_data('master_price_level',array('mpc_name'=>$this->input->post('comp_master_name')),array('mpc_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully updated');
		
	}
	else{}
	redirect('master-price-level');
}

function delete_price_level($root_id)
{
	$this->Admin_model->update_data('master_price_level',array('mpc_sts'=>'0'),array('mpc_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully deleted');
	redirect('master-price-level');	
}


function submit_project()
{
	$type=$this->input->post('type');
	$root_id=$this->input->post('root_id');
	
	if($type=="new_comp")
	{
		$data= array(
		'mpj_name'=>$this->input->post('comp_master_name'),
		'mpj_created_by'=>'manager',
		'mpj_sts'=>'1',
	 	);
		$this->Admin_model->insert_data('master_project',$data);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="creating_child")
	{
		$data2= array(
		'mpj_name'=>$this->input->post('comp_master_name'),
		'mpj_created_by'=>'manager',
		'mpj_sts'=>'1',
	 );
		$this->Admin_model->insert_data('master_project',$data2);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="editing_child")
	{
		$this->Admin_model->update_data('master_project',array('mpj_name'=>$this->input->post('comp_master_name')),array('mpj_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully updated');
		
	}
	else{}
	redirect('master-project');
}

function delete_project($root_id)
{
	$this->Admin_model->update_data('master_project',array('mpj_sts'=>'0'),array('mpj_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully deleted');
	redirect('master-project');	
}

function submit_payment_method()
{
	$type=$this->input->post('type');
	$root_id=$this->input->post('root_id');
	
	if($type=="new_comp")
	{
		$data= array(
		'mpm_name'=>$this->input->post('comp_master_name'),
		'mpm_created_by'=>'manager',
		'mpm_sts'=>'1',
	 	);
		$this->Admin_model->insert_data('master_payment_method',$data);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="creating_child")
	{
		$data2= array(
		'mpm_name'=>$this->input->post('comp_master_name'),
		'mpm_created_by'=>'manager',
		'mpm_sts'=>'1',
	 );
		$this->Admin_model->insert_data('master_payment_method',$data2);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
	}
	elseif($type=="editing_child")
	{
		$this->Admin_model->update_data('master_payment_method',array('mpm_name'=>$this->input->post('comp_master_name')),array('mpm_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully updated');
		
	}
	else{}
	redirect('master-payment-methods-master');
}

function delete_payment_method($root_id)
{
	$this->Admin_model->update_data('master_payment_method',array('mpm_sts'=>'0'),array('mpm_id'=>$root_id));
		$this->session->set_flashdata('success', 'Data Successfully deleted');
	redirect('master-payment-methods-master');	
}



}