<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manage_PO extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','gnrl','email','email_po'));	
		$this->load->model('Third_db_model','tm');
	}

function manage_approve_po($po_id)
{
	if(logged_in())
		{
			if(!empty($po_id))
			{
				$data['po_id']=$po_id;
				$data['result']=$this->tm->get_po_details('prd_order',array('po_id'=>$po_id));
				$prd_id=explode('|#|',$data['result'][0]->po_prd_name);	
				foreach ($prd_id as $key => $value) {
					 $data['prd_data'][]=$this->tm->get_data('products',array('pid'=>$value));
				}
				//pre_list($data['result']);
				$this->load->view('admin/production/prd_order/manage_approve_po',$data);
			}
		}     
}


function submit_manage_approve_po()
{
	$po_id=$this->input->post('po_id');
	$remaining_qnty=$this->input->post('remaining_qnty[]');
	$approved_qnty=$this->input->post('approved_qnty[]');
	$new_qnty=$this->input->post('new_qnty[]');

	$po_new_qnty=implode(',',$this->input->post('new_qnty[]'));
	$po_remaining_qnty=implode(',',$this->input->post('remaining_qnty[]'));

	$po_approved_qnty=implode(',',$this->input->post('approved_qnty[]'));

	$result=$this->tm->get_po_details('prd_order',array('po_id'=>$po_id));
	$table_new_qnty=$result[0]->approved_qnty;
	$table_qntys=explode('|#|',$result[0]->po_qnty);

	//$approved_sum=array();
	if(!empty($table_new_qnty))
	{
		//echo "inside if";
		$qnty_val_table=explode(',', $table_new_qnty);
		foreach($qnty_val_table as $index=>$val)
		{
			$approved_sum[]=$val+$new_qnty[$index];
		}
	}
	else
	{
		//echo "inside else";
		$approved_sum=$this->input->post('new_qnty[]');
	}

	//pre_list($approved_sum);

	if($this->session->userdata['user']['main_dept']=="Main factory")
	{
		$sts_partial_main_factory='2';
		$sts_partial_adv='';
		$main_sts_factory='2';
		$main_sts_adv='';
	}
	else
	{
		$sts_partial_main_factory='';
		$sts_partial_adv='2';
		$main_sts_adv='2';
		$main_sts_factory='';
	}		
//pre_list($data);
if(empty(array_filter($remaining_qnty)))
	{
		$data=array(
		'new_qnty'=>$po_new_qnty,
		'remaining_qnty'=>$po_remaining_qnty,
		'po_order_partial_status_fact'=>'',
		'po_order_partial_status_adv'=>'',
		'approved_qnty'=>implode(',',$approved_sum),
		'po_order_status_fact'=>$main_sts_factory,
		'po_order_status_adv'=>$main_sts_adv
		);
		$this->tm->update_data('prd_order',$data,array('po_id'=>$po_id));
		
		$data_activity=array(
		'act_function'=>'order status change',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$po_id,
		'act_status'=>'approved partially',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);	

		$mail_info=send_po_sts_mail($po_id,'Approved');
	}
	else
	{
		$data=array(
		'new_qnty'=>$po_new_qnty,
		'remaining_qnty'=>$po_remaining_qnty,
		'po_order_partial_status_fact'=>$sts_partial_main_factory,
		'po_order_partial_status_adv'=>$sts_partial_adv,
		'approved_qnty'=>implode(',',$approved_sum),
		);
			$this->tm->update_data('prd_order',$data,array('po_id'=>$po_id));

		$data_activity=array(
		'act_function'=>'order status change',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$po_id,
		'act_status'=>'approved partially',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);	

		$mail_info=send_po_sts_mail($po_id,'PARTIALLY APPROVED');
	}
	
	redirect('po-dashboard');
}
























}