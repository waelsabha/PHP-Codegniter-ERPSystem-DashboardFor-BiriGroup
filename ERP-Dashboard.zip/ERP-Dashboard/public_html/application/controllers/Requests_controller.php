<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Requests_controller extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->model(array('Account_model'));
		$this->load->helper(array('session','gnrl','img','email'));	
	}


function add_employee_request($emp_req_id=null)
{
	if(logged_in())
	{

	$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='add-leave')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {
		//$data['emp_details']=$this->Admin_model->get_data('employee_details',array('ed_sts'=>'1'));

		$data['emp_details']=$this->Admin_model->get_data('tbl_emp_tree',array('et_sts'=>'1'));
	




		if(empty($emp_req_id))
	     $this->load->view('admin/hr/add_employee_request',$data);
		else
		{
		$data['result']=$this->Admin_model->get_data('emp_request_money',array('r_sts'=>'1','r_id'=>$emp_req_id));
		$this->load->view('admin/hr/add_employee_request',$data);
		}
}

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}

function list_employee_request()
{
	if(logged_in())
	{
       $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='list-leave')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

	           $data['result']=$this->Admin_model->get_request_money(array('r_sts'=>'1'));
	           
	          // print_r( $data['result']);
	          // exit(0);
	             $this->load->view('admin/hr/list_employee_request',$data);
         }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}

function delete_emp_req($lv_id)
{
if(logged_in())
	{
	$this->Admin_model->update_data('emp_request_money',array('r_sts'=>'0'),array('r_id'=>$lv_id));
$this->session->set_flashdata('success', 'Data deleted successfully');
redirect('list-employee-request','refersh');
	}
}

function submit_emp_request()
{
	if(logged_in())
	{

		$targetfolder='./uploads/leave_managment/';
		
		if (isset($_FILES['r_supporting_files']['name']) && $_FILES['r_supporting_files']['name'] != "") 	
		{

			$img_array1=array(
				'img_name'=>'r_supporting_files',
				'upload_path'=>$targetfolder,
			);
			$emp_pic_names=img_upload($img_array1);
			
			if(!empty($emp_pic_names[0][0]['file_name']))
			{
				foreach($emp_pic_names[0] as $k1)
				{
					$pp_aray[]=$k1['file_name'];
					$value_pp_aray=implode(',',$pp_aray);
				}
			}
			
			else
			{
				$value_pp_aray='';
			}	
		}
		elseif(!empty($this->input->post('file_exist')))
		{
		$value_pp_aray=$this->input->post('file_exist');
		}
		else
		{
			$value_pp_aray='';
		}
		


	$data1=array(
			'r_user'=>$this->input->post('r_user'),
			// 'r_type'=>$this->input->post('r_type'),
			'r_amt_loan'=>$this->input->post('r_amt_loan'),
			'r_amt_advanced'=>$this->input->post('r_amt_advanced'),
			'loan_checked'=>$this->input->post('loan_checked'),
			'advanced_checked'=>$this->input->post('advanced_checked'),
			'r_subject'=>$this->input->post('r_subject'),
		
		
			'r_desc'=>$this->input->post('r_desc'),
			'r_approval_sts'=>'1',
			'r_supported'=>$value_pp_aray,
			'r_sts'=>'1',
			);
	$edit_empreq_id=$this->input->post('edit_empreq_id');		
	if(empty($edit_empreq_id))		
	{
	$this->Admin_model->insert_data('emp_request_money',$data1);

	$this->send_mail_hr($data1);
	$this->session->set_flashdata('success', 'Data inserted successfully');
	redirect('add-emp-request','refersh');
	}
	else
	{
		$this->Admin_model->update_data('emp_request_money',$data1,array('r_id'=>$edit_empreq_id));

	//$this->send_mail_hr($data1);
	$this->session->set_flashdata('success', 'Data updated successfully');
	redirect('list-employee-request','refersh');
	}
		
	}
}


function send_mail_hr($data1)
{
        $this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
         $config['smtp_crypto'] = 'tls'; 
         $config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;
         
          $this->email->initialize($config);

      $logged_users_details=$this->Admin_model->join_qry('login_credentials','tbl_emp_tree','ed_login_id','log_id',array('et_id'=>$data1['r_user']),('tbl_emp_tree.*,login_credentials.*'));
         
          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to("support@birigroup.com");
         $this->email->to('hr@birigroup.com');
		 //$this->email->to('support@birigroup.com');
       
      

		  $this->email->subject('request Application from :'.$logged_users_details[0]->ed_name);
		 
		  if(!empty($data1['l_supporting_files']))	
		  {
		    $this->email->attach("./uploads/leave_managment/".$data1['r_supporting_files']);
		   }	

$msg.="Dear HR, <br/> You got a new  request from ".$logged_users_details[0]->ed_name." . <br/><br/>Below are the details. <br/><br/>";
		  $msg.="Subject :".$data1['r_subject']."<br/><br/>";
        
  

  

           $msg.="request Description :".$data1['r_desc']."<br/><br/>";



		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  

}

function submit_request_status()
{
	$emp_req_id=$this->input->post('emp_req_id');
	$leave_details=$this->Admin_model->get_data('emp_request_money',array('r_id'=>$emp_req_id));
	$date_ref1=$this->input->post('r_date_from');


$date_ref2=$this->input->post('r_date_to');





	$data1=array(

			'r_approval_sts'=>$this->input->post('r_approval_sts'),
		
			'r_rejected_desc'=>$this->input->post('r_reject_desc')
		);
$this->Admin_model->update_data('emp_request_money',$data1,array('r_id'=>$emp_req_id));

$this->send_mail_user($data1,$emp_req_id);

$this->session->set_flashdata('success', 'request status changed successfully');
redirect('list-employee-request','refersh');
}

function send_mail_user($data,$lv_id)
{
	$this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
 $config['smtp_crypto'] = 'tls'; 
         $config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

      $leave_details=$this->Admin_model->get_data('emp_request_money',array('r_id'=>$lv_id));

      $logged_users_details=$this->Admin_model->join_qry('login_credentials','tbl_emp_tree','ed_login_id','log_id',array('et_id'=>$leave_details[0]->r_user),('tbl_emp_tree.*,login_credentials.*'));

      if($data['r_approval_sts']=="2")
      {
      	$leave_sts="Approved";
      	$leave_sts_reason='';
      }
      elseif($data['r_approval_sts']=="3")
      {
      	$leave_sts="Approved with Change in Date";
     
      }
      elseif($data['r_approval_sts']=="4")
      {
      	$leave_sts="Approved with change in days";
      
      }
      elseif($data['r_approval_sts']=="5")
      {
      	$leave_sts="Rejected";
      	$leave_sts_reason='Reason for Rejection :'.$data['r_rejected_desc'];
      }
      else
      {
      	$leave_sts="";
      	$leave_sts_reason='';
      }
         
          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to("support@birigroup.com");
          $this->email->to($logged_users_details[0]->log_email);    

          $this->email->subject('Your request Application is :'.$leave_sts);
		 $msg="Dear ".$logged_users_details[0]->ed_name.", <br/> Your request status is below  <br/><br/>";

		 $msg.="Subject of request :".$leave_details[0]->r_subject."<br/><br/>";
		  $msg.="request Status :".$leave_sts."<br/><br/>";
		  if(!empty($leave_sts_reason))
		  $msg.=$leave_sts_reason."<br/><br/>";
 $msg.="Thank you!<br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}








}