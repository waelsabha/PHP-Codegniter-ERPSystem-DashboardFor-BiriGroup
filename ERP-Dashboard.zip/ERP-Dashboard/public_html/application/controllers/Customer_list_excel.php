<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_list_excel extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','gnrl'));	
	}
	function customer_excel() {
		if(logged_in())
		{


    $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='customer_excel')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

			$this ->load-> view('admin/customer_excel_data');



       }
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}


		}
	}
	
	
function list_customer_excel()
	{
		if(logged_in())
		{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='list_customer_excel')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

		$data['result']=$this->Admin_model->get_data('cusotmer_excel_details',array('ce_sts'=>'1'));
			$this ->load-> view('admin/list_customer_excel_data',$data);

  }
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}
	
		}
	}	
public function submit_customer_excel() 
	{
		$page_name=$this->input->post('page_name');
		$flag = 0;
		$er=array();
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/excel/customer_list/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load -> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this ->upload -> do_upload('userfile')) 
		{
			$error = array('error' => $this ->upload -> display_errors());
			$this ->session -> set_flashdata('errors', $error['error']);

		redirect("customer_excel","refresh");
		
		} 
		else 
		{
			$data = array('userfile' => $this -> upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
		$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
			$flag=1;
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			$email_data = trim($allDataInSheet[$i]['A']);

		}
		if($flag==1)
		{		
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/excel/customer_list/".$import_xls_file);
			redirect("customer_excel","refresh");
				
		}
		else
		{
			$dwnload_title=$this->input->post('dwnload_title');
			$data23=array(
			'excl_title'=>$dwnload_title,
			'excl_file'=>$inputFileName,
			'excl_status'=>"1",
			'excl_type' =>'result');
			$insert_id=$this ->Admin_model-> insert_data("excel_file", $data23);
			 $this -> insert_table($allDataInSheet,$insert_id,$page_name);
		}
	}


	function insert_table($allDataInSheet,$insert_id,$page_name) 
	{
		$arrayCount = count($allDataInSheet);
		$flag = 0;
		$status = true;
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			$fetchData = array(
					'ce_email'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['A']))),
					'ce_sts'=>'1'
                   	);
				//print_r($fetchData);
			$insert_id_table=$this->Admin_model->insert_data("cusotmer_excel_details", $fetchData);
			
		}	
			$this ->session-> set_flashdata('success', 'Successfully submitted data.');
		redirect("customer_excel", "refresh");	
		
	}








}