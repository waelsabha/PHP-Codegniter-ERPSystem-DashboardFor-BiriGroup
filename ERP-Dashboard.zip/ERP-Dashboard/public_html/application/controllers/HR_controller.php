<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class HR_controller extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->model(array('Account_model'));
		
		$this->load->helper(array('session','email','img','gnrl','email_survey','text'));
	}

function add_emp($edit_id=null)
{
	if(logged_in())
	{	

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='add-employees')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



     $this->send_mail_loguser();  

				$activitylogin_data=array(
				'page_user'=>$this->session->userdata['user']['username'],
				'user_activity'=>'User Logged',
				'page_userip'=>$this->session->userdata['user']['location_ip'],
				'page_pc'=>$this->session->userdata['user']['computername'],
				'page_country'=>$this->session->userdata['user']['state'],
				'date_time_logged'=>get_date_time(),
			);
			   $this->Admin_model->insert_data('activitieslogin',$activitylogin_data);



	$cond=array('status'=>'1');
$data['country']=$this->Admin_model->get_data('country_val',$cond);	
$data['login_emp']=$this->Admin_model->get_data('login_credentials',array('log_status'=>'1'));	

	if(empty($edit_id))
	{
$this->load->view('admin/hr/add_emp',$data);
	}
	else
	{
		$data['result']=$this->Admin_model->get_data('employee_details',array('ed_id'=>$edit_id,'ed_sts'=>'1'));
$this->load->view('admin/hr/add_emp',$data);
	}


}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 



}
}

function submit_emp()
{
	$edit_id=$this->input->post('edit_emp_id');

	$this->form_validation->set_rules('login_emp_id', 'Employee login ID', 'trim|required');
	$this->form_validation->set_rules('emp_name', 'Employee Name', 'trim|required');
	$this->form_validation->set_rules('pos_name', 'Position Name', 'trim|required');
	$this->form_validation->set_rules('doj', 'Customer Date of Joining', 'trim|required');
	$this->form_validation->set_rules('country', 'Nationality', 'trim|required');
	$this->form_validation->set_rules('gender', 'Gender', 'trim|required');
	$this->form_validation->set_rules('maritial_sts', 'Maritial Status', 'trim|required');
	$this->form_validation->set_rules('mobile_num', 'Mobile', 'trim|required');
	$this->form_validation->set_rules('branch', 'Branch/location Name', 'trim|required');
	$this->form_validation->set_rules('emp_pic', 'Passport Photo');

	$this->form_validation->set_rules('jol', 'Job offer letter');
$this->form_validation->set_rules('emp_ltr', 'emmployment letter Photo');
	$this->form_validation->set_rules('visa_copy', 'Visa Copy');
	$this->form_validation->set_rules('psprt', 'Passport Copy');
	$this->form_validation->set_rules('emirts_copy', 'Emirates ID Copy');

	$this->form_validation->set_rules('vac_date', 'Vacation Date');
	$this->form_validation->set_rules('ticket_sts', 'Ticket Status');
	$this->form_validation->set_rules('sick_salary', 'Sick Leave Salary');

	if ($this->form_validation->run() == FALSE)
   	{          
   
   	 $this->session->set_flashdata('login_emp_id', form_error('login_emp_id'));
        $this->session->set_flashdata('emp_name', form_error('emp_name'));
         $this->session->set_flashdata('pos_name', form_error('pos_name'));
		$this->session->set_flashdata('doj',form_error('doj'));
		$this->session->set_flashdata('jol', form_error('jol'));
		$this->session->set_flashdata('country', form_error('country'));
		$this->session->set_flashdata('mobile_num', form_error('mobile_num'));
		$this->session->set_flashdata('gender', form_error('gender'));
		$this->session->set_flashdata('maritial_sts', form_error('maritial_sts'));
		$this->session->set_flashdata('branch', form_error('branch'));
		$this->session->set_flashdata('emp_pic', form_error('emp_pic'));
//print_r(validation_errors());
		redirect('add-employees','refresh');
	}

	else
	{
		if(empty($edit_id))	
		{
			$employee_data_position=$this->Admin_model->get_data('employee_details',array('ed_pos'=>'FOREMAN','ed_sts'=>'1'));
			$form_position_name=strtoupper($this->input->post('pos_name'));
			if($form_position_name=="FOREMAN")
			{
				if(!empty($employee_data_position))
				{
					$not_allow_position=true;
				}
			}
		}
		else
		{
			$not_allow_position=false;
		}

	if($not_allow_position==false)
	{
		$emp_name=$this->input->post('emp_name');

$folder_name=strtolower(preg_replace('/\s+/', '_', $emp_name));

		$targetfolder='./uploads/employee_data/'.$folder_name;
		if (!is_dir($targetfolder)) 
            {
            	mkdir('./'.$targetfolder, 0777, TRUE);
			}

		if (isset($_FILES['emp_pic']['name']) && $_FILES['emp_pic']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'emp_pic',
				'upload_path'=>$targetfolder,
			);
			$emp_pic_names=img_upload($img_array1);
			if(!empty($emp_pic_names[0][0]['file_name']))
			{
				foreach($emp_pic_names[0] as $k1)
				{
					$pp_aray[]=$k1['file_name'];
					$value_pp_aray=implode(',',$pp_aray);
				}
			}
			else
			{
				$value_pp_aray='';
			}	
		}

		if (isset($_FILES['jol']['name']) && $_FILES['jol']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'jol',
				'upload_path'=>$targetfolder,
			);
			$job_offer=img_upload($img_array1);
			if(!empty($job_offer[0][0]['file_name']))
			{
				foreach($job_offer[0] as $k2)
				{
					$jo_aray[]=$k2['file_name'];
					$value_jo_aray=implode(',',$jo_aray);
				}
			}
			else
			{
				$value_jo_aray='';
			}
		}

		if (isset($_FILES['emp_ltr']['name']) && $_FILES['emp_ltr']['name'] != "") 	
		{
			$img_array1=array(
			'img_name'=>'emp_ltr',
				'upload_path'=>$targetfolder,
			);
			$emply_ltr=img_upload($img_array1);
			if(!empty($emply_ltr[0][0]['file_name']))
			{
				foreach($emply_ltr[0] as $k3)
				{
					$el_aray[]=$k3['file_name'];
					$value_el_aray=implode(',',$el_aray);
				}
			}
			else
			{
				$value_el_aray='';
			}
		}

		
		if (isset($_FILES['visa_copy']['name']) && $_FILES['visa_copy']['name'] != "") 		
		{
			$img_array1=array(
				'img_name'=>'visa_copy',
				'upload_path'=>$targetfolder,
			);
			$visa=img_upload($img_array1);
			if(!empty($visa[0][0]['file_name']))
			{
				foreach($visa[0] as $k4)
				{
					$vsa_aray[]=$k4['file_name'];
					$value_vsa_aray=implode(',',$vsa_aray);
				}
			}
			else
			{
				$value_vsa_aray='';
			}
		}

		
		if (isset($_FILES['psprt']['name']) && $_FILES['psprt']['name'] != "") 	
		{
			$img_array1=array(
			'img_name'=>'psprt',
				'upload_path'=>$targetfolder,
			);
			$passprt=img_upload($img_array1);
			if(!empty($passprt[0][0]['file_name']))
			{
				foreach($passprt[0] as $k5)
				{
					$psport_aray[]=$k5['file_name'];
					$val_psport_aray=implode(',',$psport_aray);
				}
			}
			else
			{
				$val_psport_aray='';
			}
		}

		if (isset($_FILES['emirts_copy']['name']) && $_FILES['emirts_copy']['name'] != "") 
		{
			$img_array1=array(
			'img_name'=>'emirts_copy',
				'upload_path'=>$targetfolder,
			);
			$emirates_copy=img_upload($img_array1);
			if(!empty($emirates_copy[0][0]['file_name']))
			{
				foreach($emirates_copy[0] as $k6)
				{
					$ec_aray[]=$k6['file_name'];
					$val_ec_aray=implode(',',$ec_aray);
				}
			}
			else
			{
				$val_ec_aray='';
			}
		} 

		$data1=array(
			'ed_login_id'=>$this->input->post('login_emp_id'),
			'ed_name'=>$this->input->post('emp_name'),
			'ed_branch'=>$this->input->post('branch'),
			'ed_martial_sts'=>$this->input->post('maritial_sts'),
			'ed_gender'=>$this->input->post('gender'),
			'ed_mob'=>$this->input->post('mobile_num'),
			'ed_nationality'=>$this->input->post('country'),
			'ed_doj'=>date("Y-m-d", strtotime($this->input->post('doj'))),
			'ed_pos'=>$this->input->post('pos_name'),
			'ed_sick_leave_pay'=>$this->input->post('sick_salary'),
			'ed_tkt_sts'=>$this->input->post('ticket_sts'),
			'ed_vacation_date'=>date("Y-m-d", strtotime($this->input->post('vac_date'))),
		);
			if(empty($edit_id))	
			{
				$insert_id=$this->Admin_model->insert_data('employee_details',$data1);
				if(!empty($insert_id))
				{
					$data2=array(
						'ed_sts'=>'1',
					'ed_pic'=>$value_pp_aray,
					'ed_jol'=>$value_jo_aray,
					'ed_emp_ltr'=>$value_el_aray,
					'ed_visa'=>$value_vsa_aray,
					'ed_psprt'=>$val_psport_aray,
					'ed_emirates_id'=>$val_ec_aray,
					);
					$cond1=array('ed_id'=>$insert_id);
					$this->Admin_model->update_data('employee_details',$data2,$cond1);

				$this->session->set_flashdata('success', 'Data added successfully');
				redirect('add-employees','refersh');
				}
				else
				{
				$this->session->set_flashdata('errors', 'Failed to insert the data successfully.Please check the file upload.');
				redirect('add-employees','refresh');
				}
			}
			else///edit
			{
				$cond1=array('ed_id'=>$edit_id);
				$this->Admin_model->update_data('employee_details',$data1,$cond1);

			if (isset($_FILES['emp_pic']['name']) && $_FILES['emp_pic']['name'] != "") 
				{
					if(!empty($pp_aray))
					{
					$data_edit_pic=array('ed_pic'=>implode(',',$pp_aray));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
					else
					{
						$data_edit_pic=array('ed_pic'=>$this->input->post('edit_pic'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
				}
				else
				{
					$data_edit_pic=array('ed_pic'=>$this->input->post('edit_pic'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
				}

				if (isset($_FILES['jol']['name']) && $_FILES['jol']['name'] != "") 
				{
					if(!empty($jo_aray))
					{
					$data_edit_pic=array('ed_jol'=>implode(',',$jo_aray));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
					else
					{
						$data_edit_pic=array('ed_jol'=>$this->input->post('edit_jo'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
				}
				else
				{
					$data_edit_pic=array('ed_jol'=>$this->input->post('edit_jo'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
				}

				if (isset($_FILES['emp_ltr']['name']) && $_FILES['emp_ltr']['name'] != "") 
				{
					if(!empty($el_aray))
					{
						$data_edit_pic=array('ed_emp_ltr'=>implode(',',$el_aray));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
					else
					{
						$data_edit_pic=array('ed_emp_ltr'=>$this->input->post('edit_el'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
					
				}
				else
				{
					$data_edit_pic=array('ed_emp_ltr'=>$this->input->post('edit_el'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
				}

				if (isset($_FILES['visa_copy']['name']) && $_FILES['visa_copy']['name'] != "") 
				{
					if(!empty($vsa_aray))
					{
						$data_edit_pic=array('ed_visa'=>implode(',',$vsa_aray));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
					else{
						$data_edit_pic=array('ed_visa'=>$this->input->post('edit_vc'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
				}
				else
				{
					$data_edit_pic=array('ed_visa'=>$this->input->post('edit_vc'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
				}

				if (isset($_FILES['psprt']['name']) && $_FILES['psprt']['name'] != "") 
				{
					if(!empty($psport_aray))
					{
						$data_edit_pic=array('ed_psprt'=>implode(',',$psport_aray));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
					else
					{
						$data_edit_pic=array('ed_psprt'=>$this->input->post('edit_pc'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
				}
				else
				{
					$data_edit_pic=array('ed_psprt'=>$this->input->post('edit_pc'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
				}

				if (isset($_FILES['emirts_copy']['name']) && $_FILES['emirts_copy']['name'] != "") 
				{
					if(!empty($ec_aray))
					{
					$data_edit_pic=array('ed_emirates_id'=>implode(',',$ec_aray));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
					else
					{
						$data_edit_pic=array('ed_emirates_id'=>$this->input->post('edit_eidc'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
					}
				}
				else
				{
					$data_edit_pic=array('ed_emirates_id'=>$this->input->post('edit_eidc'));
					$this->Admin_model->update_data('employee_details',$data_edit_pic,$cond1);
				}
				
				
				$this->session->set_flashdata('success', 'Data updated successfully');
				redirect('list-employees','refresh');

			}	
	}
	else
	{
			$this->session->set_flashdata('errors', 'This position already exist .');
				redirect('list-employees','refresh');
	}	
	}
}

function list_emp()
{
  if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-employees')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {




	$cond1=array('ed_sts'=>'1');
	$data['result']=$this->Admin_model->emp_country();
     $this->load->view('admin/hr/list_emp',$data);


}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 






}

function delete_emp($id)
{
	if(logged_in())
	{
		$data1=array('ed_sts'=>'0');
	$cond1=array('ed_id'=>$id);
	$this->Admin_model->update_data('employee_details',$data1,$cond1);
	$this->session->set_flashdata('success', 'Data successfully deleted');
		redirect('list-employees');
	}
}

function download_emp_files($emp_id)
{
$this->load->helper(array('download'));
$this->load->library('zip');

$cond=array('ed_id'=>$emp_id);
$data_result=$this->Admin_model->get_data('employee_details',$cond);

$folder_name=strtolower(preg_replace('/\s+/', '_', $data_result[0]->ed_name));

$pic=explode(',',$data_result[0]->ed_pic);
$jol=explode(',',$data_result[0]->ed_jol);
$emp_ltr=explode(',',$data_result[0]->ed_emp_ltr);
$visa_copy=explode(',',$data_result[0]->ed_visa);
$passport_copy=explode(',',$data_result[0]->ed_psprt);
$emirates_id=explode(',',$data_result[0]->ed_emirates_id);

$main_array = array_merge($pic,$jol,$emp_ltr,$visa_copy,$passport_copy,$emirates_id);
 
	foreach($main_array as $j)
	{
			$this->zip->read_file('./uploads/employee_data/'.$folder_name.'/'.$j);
	}	
	$this->zip->download(''.$folder_name.'.zip');

}

function download_emp_files_req($requested,$emp_id)
{
$this->load->helper(array('download'));
$this->load->library('zip');

$cond=array('ed_id'=>$emp_id);
$data_result=$this->Admin_model->get_data('employee_details',$cond);

$folder_name=strtolower(preg_replace('/\s+/', '_', $data_result[0]->ed_name));

if($requested=="pic")
{
	$folder_name1='employee_pic';
$data_download=explode(',',$data_result[0]->ed_pic);
}
elseif($requested=="jo")
{
	$folder_name1='job_offer';
$data_download=explode(',',$data_result[0]->ed_jol);
}
elseif($requested=="el")
{
	$folder_name1='employment_letter';
$data_download=
explode(',',$data_result[0]->ed_emp_ltr);
}
elseif($requested=="vc")
{
	$folder_name1='visa_copy';
$data_download=explode(',',$data_result[0]->ed_visa);
}
elseif($requested=="pc")
{
	$folder_name1='passport_copy';
$data_download=explode(',',$data_result[0]->ed_psprt);
}
else
{
	$folder_name1='emirates_id';
$data_download=explode(',',$data_result[0]->ed_emirates_id);
}

foreach($data_download as $j)
	{
			$this->zip->read_file('./uploads/employee_data/'.$folder_name.'/'.$j);
	}	
	$this->zip->download(''.$folder_name1.'.zip');
}

function list_jobs()
{

  if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-jobs-applied')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {




	$data['result']=$this->Admin_model->get_data('jobs_applied',array('j_sts'=>'1','j_app_sts !='=>'6'),'','','jid','DESC');
	$this->load->view('admin/hr/jobs_applied',$data);

    }

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 

}

function edit_job_sts()
{
	$job_id=$this->input->post('job_id');
	$job_sts=$this->input->post('job_sts_curnt');
	$job_sts=$this->input->post('job_sts_curnt');
	
	if($job_sts=='6')
	{
	$mail_data=array(
			'job_id'=>$job_id,
			'reason_rej'=>$reason_rejec
		);
		send_mail_rejected($mail_data);
		
	redirect('https://birigroup.com/reject_job/'.$job_id);
	}
	else
	{
$this->Admin_model->update_data('jobs_applied',array('j_app_sts'=>$job_sts),array('jid'=>$job_id));
$this->session->set_flashdata('success', 'Status changed successfully');
		redirect('list-jobs-applied');
	}
}

function delete_job_details($job_id=null)
{
	if(logged_in())
	{
	$job_data=$this->Admin_model->get_data('jobs_applied',array('jid'=>$job_id));
	$this->Admin_model->update_data('jobs_applied',array('j_sts'=>'0'),array('jid'=>$job_id));

	$this->session->set_flashdata('success', 'Data successfully removed');
		redirect('list-jobs-applied');
	}
}


public function file_check1($str) {

		$allowed_mime_type_arr = array('image/jpeg', 'image/jpg', 'image/png');

		$mime = get_mime_by_extension($_FILES['emp_pic']['name']);
		if (isset($_FILES['emp_pic']['name']) && $_FILES['emp_pic']['name'] != "") {
			if (in_array($mime, $allowed_mime_type_arr)) {
				return true;
			} else {
				$this ->form_validation ->set_message('file_check1', 'Please select only jpg/png file.');
				return false;
			}
		}
		else {
		$this ->form_validation ->set_message('file_check1', 'Please choose a file to upload.');
		return false;
		}
		return true;
	}

public function file_check2($str) {

		$allowed_mime_type_arr = array('image/jpeg', 'image/jpg', 'image/png','application/pdf','application/doc','application/docx','application/msword');

		$mime = get_mime_by_extension($_FILES['jol']['name'][0]);
		if (isset($_FILES['jol']['name'][0]) && $_FILES['jol']['name'][0] != "") {
			if (in_array($mime, $allowed_mime_type_arr)) {
				return true;
			} else {
				$this ->form_validation ->set_message('file_check2', 'Please select a valid pdf/word file.');
				return false;
			}
		}
		else {
		$this ->form_validation ->set_message('file_check2', 'Please choose a file to upload.');
		return false;
		}
		return true;
	}



function send_mail_loguser()
{
	     $this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
$config['smtp_crypto'] = 'tls'; 
$config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

$page_user= $this->session->userdata['user']['username'];
//$page_userip=$this->session->userdata['user']['location_ip'];

$page_userip=$this->session->userdata['user']['ipsession'];
$page_serverip= $this->session->userdata['user']['server_ip'];
$page_email=$this->session->userdata['user']['user_email'];
$page_pc=$this->session->userdata['user']['computername'];
$page_state=$this->session->userdata['user']['state'];
$page_country=$this->session->userdata['user']['country'];
$page_cityserverprovider=$this->session->userdata['user']['cityserverprovider'];
$page_hostname=$this->session->userdata['user']['hostname'];
$page_lat=$this->session->userdata['user']['user_lat'];
$user_long=$this->session->userdata['user']['user_long'];
  
$user_serverorg=$this->session->userdata['user']['user_serverorg'];

$browsername=$this->session->userdata['user']['browsername'];
$browserversion=$this->session->userdata['user']['browserversion'];
$operatingsystem=$this->session->userdata['user']['operatingsystem'];


$devicedetailsinfo=$this->session->userdata['user']['devicedetailsinfo'];
$ipsession=$this->session->userdata['user']['ipsession'];
// $mobile=$this->session->userdata['user']['mobile'];
$date_time=get_date_time();

// print_r($page_email);
// exit(0);


     
          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to("support@birigroup.com");
          $this->email->to($page_email);    

          $this->email->subject('Loggedin Activity Happend :');
		 $msg="Dear ".$page_user.", <br/> Your Account Loggedin From Device Below  <br/><br/>";

		 $msg.="You Loggedin From  :  "  .$page_country."<br/><br/>";
		  $msg.="State :  "  .$page_state."<br/><br/>";
		  $msg.="Using IP Adress :  "  .$ipsession."<br/><br/>";
	
		  $msg.="from Device :  "  .$devicedetailsinfo." on server  " .   $page_pc  .     "<br/><br/>";
		  $msg.="Operating System:  "  .$operatingsystem.  "  <br/><br/>";
        $msg.="Browser:  ".$browsername." Version :  " .$browserversion. "  <br/><br/>";

         $msg.="Server Provider :  "  .$user_serverorg."<br/><br/>";

          $msg.="Host Name :  "  .$page_hostname."<br/><br/>";
           $msg.="Latitude :  "  .$page_lat. "<br/><br/>"; 
           $msg.="Longtude :  "  .$user_long. "<br/><br/>";        
                       
        
		  $msg.="Login date  :  "  .$date_time."<br/><br/>";
		
		  $msg.="<br/><br/>";
 $msg.="Thank you!<br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}
















}