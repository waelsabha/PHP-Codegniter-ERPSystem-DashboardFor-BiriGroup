<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_controller extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper('session');
		$session_data = array(
		 	'cash_type'=>'',
		 	'bank_name'=>'',
		 	'month'=>'',
		 	'year'=>'',
		 	'start_date'=>'',
		 	'end_date'=>'',
		 	'entry_date'=>'',
		 );
		 $this->session->unset_userdata('selection_val',$session_data);
		// $qry1=$this->Admin_model->update_data_acc();
		// $qry2=$this->Admin_model->update_data_fund();
		//print_r($qry2);
	}

function dashboard()
	{		
		if(logged_in())
		{
		$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp); //adjust the object to correct timestamp
// echo $dt->format('Y/m/d H:i:s');
//echo 
		$current_year= $dt->format('Y');//date('Y');
		$start_date1=$current_year.'-01-01';
	
		$current_date=$dt->format('Y-m-d');
		$explode_current_date=explode('-',$current_date);

		$previous_year=date("Y",strtotime("-1 year"));
		$last_day_previous_yr=$previous_year.'-12-31';

		// $main_cond_current_month= array('ae_desc !='=>'Opening Balances');
		$main_cond_current_month= null;
	$main_cond_prev_month=array('ae_date'=>$last_day_previous_yr);


$banks_array=array('ADIB-BBMS','ADIB-Factory','ENBD','EI Bank','Cash Mr. Bachir Book','Cash Garhoud','Cash Factory','Other Bank');
		$limit='1';
		$order_by=('ae_date,ae_bal_amount');
			$order_type="DESC";
			$opening_balances=array();
	foreach($banks_array as $bank)
	{
		$cond_new=array('ae_bank'=>$bank,'ae_status'=>'1');
		$opening_balances=$this->Admin_model->get_opening_bal($cond_new);
		$base_opening_amount[]=$opening_balances[0]->ae_amount;
	}
	//echo $current_date;
	//print_r($banks_array);
	$bbms_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);
	$bbms_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);

	$bbms['result']=(($bbms_rx2[0]->rx_total+$base_opening_amount[0])-($bbms_spend2[0]->spend_total));///upto this financial year	

///////for only approved and not expected////
$bbms_rx2_aprvd=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);

	$bbms_spend2_aprvd=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);
// print_r($bbms_rx2_aprvd);
// echo "<br/>";
// print_r($bbms_spend2_aprvd);

$bbms_approved['result']=(($bbms_rx2_aprvd[0]->rx_total+$base_opening_amount[0])-($bbms_spend2_aprvd[0]->spend_total));
// print_r($bbms_approved['result']);
// echo "<br/>";

//print_r($bbms['result']);
	$factory_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);
	$factory_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);

	$factory['result']=(($factory_rx2[0]->rx_total+$base_opening_amount[1])-($factory_spend2[0]->spend_total));///upto this financial year	

	///////for only approved and not expected////
	$factory_rx2_aprvd=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);
	$factory_spend2_aprvd=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);

	$factory_approved['result']=(($factory_rx2_aprvd[0]->rx_total+$base_opening_amount[1])-($factory_spend2_aprvd[0]->spend_total));


	$enbd_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);
	$enbd_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);

	$enbd['result']=(($enbd_rx2[0]->rx_total+$base_opening_amount[2])-($enbd_spend2[0]->spend_total));///upto this financial year	
	
	///////for only approved and not expected////
	$enbd_rx2_aprvd=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);
	$enbd_spend2_aprvd=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);

	$enbd_approved['result']=(($enbd_rx2_aprvd[0]->rx_total+$base_opening_amount[2])-($enbd_spend2_aprvd[0]->spend_total));

$ei_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);
	$ei_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);

	$ei['result']=(($ei_rx2[0]->rx_total+$base_opening_amount[3])-($ei_spend2[0]->spend_total));///upto this financial year	

	///////for only approved and not expected////

	$ei_rx2_aprvd=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);
	
	$ei_spend2_aprvd=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);

	$ei_approved['result']=(($ei_rx2_aprvd[0]->rx_total+$base_opening_amount[3])-($ei_spend2_aprvd[0]->spend_total));
	
	$bachir_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);
	$bachir_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);

	$bachir['result']=(($bachir_rx2[0]->rx_total+$base_opening_amount[4])-($bachir_spend2[0]->spend_total));///upto this financial year

	///////for only approved and not expected////
	$bachir_rx2_aprvd=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);
	$bachir_spend2_aprvd=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);

	$bachir_approved['result']=(($bachir_rx2_aprvd[0]->rx_total+$base_opening_amount[4])-($bachir_spend2_aprvd[0]->spend_total));	

	$garhoud_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);
	$garhoud_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);

	$garhoud['result']=(($garhoud_rx2[0]->rx_total+$base_opening_amount[5])-($garhoud_spend2[0]->spend_total));///upto this financial year	

	///////for only approved and not expected////
	$garhoud_rx2_aprvd=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);
	$garhoud_spend2_aprvd=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances','ae_sts !='=>'Expected','ae_status_data'=>'2'),$start_date1,$current_date);

	$garhoud_approved['result']=(($garhoud_rx2_aprvd[0]->rx_total+$base_opening_amount[5])-($garhoud_spend2_aprvd[0]->spend_total));

	$cash_fact_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);
	$cash_fact_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);

	$cash_fact['result']=(($cash_fact_rx2[0]->rx_total+$base_opening_amount[6])-($cash_fact_spend2[0]->spend_total));///upto this financial year	

	///////for only approved and not expected////
	$cash_fact_rx2_aprvd=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);
	$cash_fact_spend2_aprvd=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);

	$cash_fact_approved['result']=(($cash_fact_rx2_aprvd[0]->rx_total+$base_opening_amount[6])-($cash_fact_spend2_aprvd[0]->spend_total));


	$other_bank_rx2=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);
	$other_bank_spend2=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);

	$other_bank['result']=(($other_bank_rx2[0]->rx_total+$base_opening_amount[7])-($other_bank_spend2[0]->spend_total));///upto this financial year	

	///////for only approved and not expected////
	$other_bank_rx2_aprvd=$this->Admin_model->bnk_bal_rx_btw_dates(array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);
	$other_bank_spend2_aprvd=$this->Admin_model->bnk_bal_spend_btw_dates(array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances'),$start_date1,$current_date);

	$other_bank_approved['result']=(($other_bank_rx2_aprvd[0]->rx_total+$base_opening_amount[7])-($other_bank_spend2_aprvd[0]->spend_total));

	if(!empty($bbms['result']))
		$data['bbms_result']=$bbms['result'];
	else
		$data['bbms_result']=$base_opening_amount[0];

	if(!empty($factory['result']))
		$data['fact_result']=$factory['result'];
	else
		$data['fact_result']=$base_opening_amount[1];

	if(!empty($enbd['result']))
		$data['ENBD']=$enbd['result'];
	else
		$data['ENBD']=$base_opening_amount[2];

	if(!empty($ei['result']))
		$data['ei_bank']=$ei['result'];
	else
		$data['ei_bank']=$base_opening_amount[3];

	if(!empty($bachir['result']))
		$data['cash_bachir']=$bachir['result'];
	else
		$data['cash_bachir']=$base_opening_amount[4];

	if(!empty($garhoud['result']))
		$data['Garhoud']=$garhoud['result'];
	else
		$data['Garhoud']=$base_opening_amount[5];

	if(!empty($cash_fact['result']))
		$data['cash_fact']=$cash_fact['result'];
	else
		$data['cash_fact']=$base_opening_amount[6];

	if(!empty($other_bank['result']))
		$data['others']=$other_bank['result'];
	else
		$data['others']=$base_opening_amount[7];

	// $data['total_bank_bal']=(($data['bbms_result'])+($data['fact_result'])+($data['ENBD'])+($data['ei_bank'])+($data['others']) );

	// $data['total_cash_bal']=(($data['cash_bachir'])+($data['Garhoud'])+($data['cash_fact']));


	//////for the complete approved transaction///
	if(!empty($bbms_approved['result']))
		$data['bbms_result_approved']=$bbms_approved['result'];
	else
		$data['bbms_result_approved']=$base_opening_amount[0];

	if(!empty($factory_approved['result']))
		$data['fact_result_approved']=$factory_approved['result'];
	else
		$data['fact_result_approved']=$base_opening_amount[1];

	if(!empty($enbd_approved['result']))
		$data['ENBD_approved']=$enbd_approved['result'];
	else
		$data['ENBD_approved']=$base_opening_amount[2];

	if(!empty($ei_approved['result']))
		$data['ei_bank_approved']=$ei_approved['result'];
	else
		$data['ei_bank_approved']=$base_opening_amount[3];

	if(!empty($bachir_approved['result']))
		$data['cash_bachir_approved']=$bachir_approved['result'];
	else
		$data['cash_bachir_approved']=$base_opening_amount[4];

	if(!empty($garhoud_approved['result']))
		$data['Garhoud_approved']=$garhoud_approved['result'];
	else
		$data['Garhoud_approved']=$base_opening_amount[5];

	if(!empty($cash_fact_approved['result']))
		$data['cash_fact_approved']=$cash_fact_approved['result'];
	else
		$data['cash_fact_approved']=$base_opening_amount[6];

	if(!empty($other_bank_approved['result']))
		$data['others_approved']=$other_bank_approved['result'];
	else
		$data['others_approved']=$base_opening_amount[7];

	$data['total_bank_bal']=(($data['bbms_result_approved'])+($data['fact_result_approved'])+($data['ENBD_approved'])+($data['ei_bank_approved'])+($data['others_approved']) );

	$data['total_cash_bal']=(($data['cash_bachir_approved'])+($data['Garhoud_approved'])+($data['cash_fact_approved']));
	
		
		/////category based data///
$cat_array=array('Shipping','Sales','General Expenses','Salaries','Raw Material Purchases','Import Purchases','Personal Accounts','Rent','Others');
		// $limit='1';
		// $order_by='ae_date';
		// 	$order_type="DESC";
	
	//print_r($banks_array);					
	$ship=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[0],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date1,'ae_date <='=>$current_date),'','','','');
$ship_result=0;
	foreach ($ship as $sr) {
		# code...
		if(($sr->ae_cash_type)=="Received")
			{
				$ship_result=$ship_result+$sr->ae_amount;
			}
		else
			{
				$ship_result=$ship_result-$sr->ae_amount;
			}
	}
	
	$sales=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[1],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date1,'ae_date <='=>$current_date),'','','','');
	$sales_result=0;
	foreach ($sales as $sl) {
		# code...
		if(($sl->ae_cash_type)=="Received")
			{
				$sales_result=$sales_result+$sl->ae_amount;
			}
		else
			{
				$sales_result=$sales_result-$sl->ae_amount;
			}
	}

	$gnrl=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[2],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date1,'ae_date <='=>$current_date),'','','','');
	$gnrl_result=0;
	foreach ($gnrl as $gl) {
		# code...
		if(($gl->ae_cash_type)=="Received")
			{
				$gnrl_result=$gnrl_result+$gl->ae_amount;
			}
		else
			{
				$gnrl_result=$gnrl_result-$gl->ae_amount;
			}
	}

	$salary=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[3],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date1,'ae_date <='=>$current_date),'','','','');
	$salary_result=0;
	foreach ($salary as $sa) {
		# code...
		if(($sa->ae_cash_type)=="Received")
			{
				$salary_result=$salary_result+$sa->ae_amount;
			}
		else
			{
				$salary_result=$salary_result-$sa->ae_amount;
			}
	}

	$raw_mat=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[4],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date1,'ae_date <='=>$current_date),'','','','');
	$raw_result=0;
	foreach ($raw_mat as $rm) {
		# code...
		if(($rm->ae_cash_type)=="Received")
			{
				$raw_result=$raw_result+$rm->ae_amount;
			}
		else
			{
				$raw_result=$raw_result-$rm->ae_amount;
			}
	}

	$import=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[5],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date1,'ae_date <='=>$current_date),'','','','');
	$import_result=0;
	foreach ($import as $im) {
		# code...
		if(($im->ae_cash_type)=="Received")
			{
				$import_result=$import_result+$im->ae_amount;
			}
		else
			{
				$import_result=$import_result-$im->ae_amount;
			}
	}

	$export=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[6],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date1,'ae_date <='=>$current_date),'','','','');
	$exprt_result=0;
	foreach ($export as $xpt) {
		# code...
		if(($xpt->ae_cash_type)=="Received")
			{
				$exprt_result=$exprt_result+$xpt->ae_amount;
			}
		else
			{
				$exprt_result=$exprt_result-$xpt->ae_amount;
			}
	}

	$rent=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[7],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date1,'ae_date <='=>$current_date),'','','','');
	$rent_result=0;
	foreach ($rent as $rnt) {
		# code...
		if(($rnt->ae_cash_type)=="Received")
			{
				$rent_result=$rent_result+$rnt->ae_amount;
			}
		else
			{
				$rent_result=$rent_result-$rnt->ae_amount;
			}
	}

	$other_cat=$this->Admin_model->get_data_2('account_entry1',array('ae_cat'=>$cat_array[8],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date >='=>$start_date1,'ae_date <='=>$current_date),'','','','');
	$other_cat_result=0;
	foreach ($other_cat as $oc) {
		# code...
		if(($oc->ae_cash_type)=="Received")
			{
				$other_cat_result=$other_cat_result+$oc->ae_amount;
			}
		else
			{
				$other_cat_result=$other_cat_result-$oc->ae_amount;
			}
	}


	if(!empty($ship_result))
		$data['shipping']=$ship_result;
	else
		$data['shipping']="0";

	if(!empty($salary_result))
		$data['salaries']=$salary_result;
	else
		$data['salaries']="0";

	if(!empty($gnrl_result))
		$data['gnrl']=$gnrl_result;
	else
		$data['gnrl']="0";

	if(!empty($sales_result))
		$data['sales']=$sales_result;
	else
		$data['sales']="0";

	if(!empty($raw_result))
		$data['raw_mat']=$raw_result;
	else
		$data['raw_mat']="0";

	if(!empty($import_result))
		$data['import']=$import_result;
	else
		$data['import']="0";

	if(!empty($exprt_result))
		$data['export']=$exprt_result;
	else
		$data['export']="0";

	if(!empty($rent_result))
		$data['rent']=$rent_result;
	else
		$data['rent']="0";

	if(!empty($other_cat_result))
		$data['other_cat']=$other_cat_result;
	else
		$data['other_cat']="0";

	$data['total_cat']=($data['other_cat'] + $data['rent'] + $data['export'] + $data['import'] + $data['raw_mat'] + $data['salaries'] + $data['gnrl'] + $data['shipping'] + $data['sales'] );

$lnToday2 = date("Y-m-d", strtotime("-7 days"));
$Today = date("Y-m-d");
$limit='25';
$order_by='ae_date';
$order_type="ASC";

// $cond_array1=array('ae_status'=>'1','ae_date <=' =>$lnToday,'ae_date >' =>$Today,'ae_cash_type'=>"Spend");
$cond_array1=array('ae_status'=>'1','ae_date >=' =>$lnToday2,'ae_cash_type'=>"Spend");
$data['cash_spend']=$this->Admin_model->get_data('account_entry1',$cond_array1,$limit,'',$order_by,$order_type);

// $cond_array2=array('ae_status'=>'1','ae_date <=' =>$lnToday,'ae_date >' =>$Today,'ae_cash_type'=>"Received");
$cond_array2=array('ae_status'=>'1','ae_date >=' =>$lnToday2,'ae_cash_type'=>"Received");
$data['cash_received']=$this->Admin_model->get_data('account_entry1',$cond_array2,$limit,'',$order_by,$order_type);


$lnToday2 = date("Y-m-d", strtotime("-7 days"));
$Today = date("Y-m-d");
$order_by='ae_date';
$order_type="ASC";
$cond_array_entire=array('ae_date >='=>$lnToday2);
$data['cash_entire']=$this->Admin_model->entire_bnk_bal($cond_array_entire,'',$order_by,$order_type);


$banks_array=array('ADIB-BBMS','ADIB-Factory','ENBD','EI Bank','Cash Mr. Bachir Book','Cash Garhoud','Cash Factory','Other Bank');

foreach($banks_array as $indx_ba=>$g)
{
$cond_df=array('ae_bank'=>$g,'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date <='=>date("Y-m-d", strtotime("-8 days")) );
$order_by_1=('ae_date');
$order_type_1="ASC";
$bank_result_1=$this->Admin_model->bnk_bal_sum_amount1($cond_df,'',$order_by_1,$order_type_1);


$bank_result_2=$this->Admin_model->bnk_bal_sum_amount2($cond_df,'',$order_by_1,$order_type_1);

$data['result_bal_date'][]=(($bank_result_1[0]->total_amount)+$base_opening_amount[$indx_ba])-($bank_result_2[0]->total_amount);
}

$cond_pndg_tx=array('ae_status_data'=>'1','ae_status'=>'1','ae_date <='=>$Today);
$data['count_pending_tx']=$this->Admin_model->record_count2('account_entry1',$cond_pndg_tx);


// echo "<br/>";
$this->load->view('admin/dashboard',$data);
		}
	}


function this_month()
{
$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
	
	$data_ajax=$this->input->post('date_data');
$query_date=$dt->format('Y-m-d');
$last_day_month=$dt->format('Y-m-t');
$start_day_month=$dt->format('Y-m-01');

	//$use_cond;
if(empty($data_ajax))////checking if selected month filteration
{
				$current_year= $dt->format('Y');
			$current_mnth=$dt->format('m');////this month filter
}			
else{
	 $current_date=$dt->format('Y-m-d');
		//$current_date='2019-09-15';
	///todays date,filter
	//$use_cond=array('ae_date'=>$current_date);
}


$banks_array=array('ADIB-BBMS','ADIB-Factory','ENBD','EI Bank','Cash Mr. Bachir Book','Cash Garhoud','Cash Factory','Other Bank');
		$limit='1';
		$order_by=('ae_date,ae_id');
			$order_type="ASC,DESC";
			$opening_balances=array();
	foreach($banks_array as $bank)
	{
		$cond_new=array('ae_bank'=>$bank,'ae_status'=>'1');
		$opening_balances=$this->Admin_model->get_opening_bal($cond_new);
		$base_opening_amount[]=$opening_balances[0]->ae_amount;
	}

	//print_r($banks_array);
	$cond='';
	if(empty($data_ajax))////based on month
	{
		$cond=array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);	

		$cond_approved=array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year,'ae_sts !='=>'Expected','ae_status_data'=>'2');	
	}
	else///based on the date 
	{
		$cond=array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);	

		$cond_approved=array('ae_bank'=>$banks_array[0],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date,'ae_sts !='=>'Expected','ae_status_data'=>'2');	
	}	
	$bbms_rx=$this->Admin_model->bnk_bal_sum_amount1($cond,'',$order_by,$order_type);

	$bbms_sx=$this->Admin_model->bnk_bal_sum_amount2($cond,'',$order_by,$order_type);

	$bbms['result']=($bbms_rx[0]->total_amount)-($bbms_sx[0]->total_amount);	



	///////for only approved and not expected////
	$bbms_rx_aprvd=$this->Admin_model->bnk_bal_sum_amount1($cond_approved,'',$order_by,$order_type);
	$bbms_sx_aprvd=$this->Admin_model->bnk_bal_sum_amount2($cond_approved,'',$order_by,$order_type);

	$bbms_approved['result']=($bbms_rx_aprvd[0]->total_amount)-($bbms_sx_aprvd[0]->total_amount);


	$cond='';$cond_approved='';
	if(empty($data_ajax))
	{
		$cond=array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);	

		$cond_approved=array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year,'ae_sts !='=>'Expected','ae_status_data'=>'2');		
	}
	else
	{
		$cond=array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);	

	$cond_approved=array('ae_bank'=>$banks_array[1],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date,'ae_sts !='=>'Expected','ae_status_data'=>'2');		
	}
	$fact_rx=$this->Admin_model->bnk_bal_sum_amount1($cond,'',$order_by,$order_type);

	$fact_sx=$this->Admin_model->bnk_bal_sum_amount2($cond,'',$order_by,$order_type);

	$factory['result']=($fact_rx[0]->total_amount)-($fact_sx[0]->total_amount);	

	///////for only approved and not expected////
	$fact_rx_aprvd=$this->Admin_model->bnk_bal_sum_amount1($cond_approved,'',$order_by,$order_type);
	$fact_sx_aprvd=$this->Admin_model->bnk_bal_sum_amount2($cond_approved,'',$order_by,$order_type);

	$factory_approved['result']=($fact_rx_aprvd[0]->total_amount)-($fact_sx_aprvd[0]->total_amount);
	
	// print_r($fact_rx);
	// echo "<br/>";
	// print_r($fact_sx);
	// echo "<br/>";
	// //print_r($factory['result']);
	// echo "checking approved";
	// echo "<br/>";
	// print_r($fact_rx_aprvd);
	// echo "<br/>";
	// print_r($fact_sx_aprvd);
	// echo "<br/>";


	$cond='';$cond_approved='';
	if(empty($data_ajax))
	{
		$cond=array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		

		$cond_approved=array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year,'ae_sts !='=>'Expected','ae_status_data'=>'2');	
	}
	else
	{
			$cond=array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);		

			$cond_approved=array('ae_bank'=>$banks_array[2],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date,'ae_sts !='=>'Expected','ae_status_data'=>'2');	
	}
	$enbd_rx=$this->Admin_model->bnk_bal_sum_amount1($cond,'',$order_by,$order_type);

	$enbd_sx=$this->Admin_model->bnk_bal_sum_amount2($cond,'',$order_by,$order_type);

	$enbd['result']=($enbd_rx[0]->total_amount)-($enbd_sx[0]->total_amount);
		///////for only approved and not expected////
	$enbd_rx_aprvd=$this->Admin_model->bnk_bal_sum_amount1($cond_approved,'',$order_by,$order_type);
	$enbd_sx_aprvd=$this->Admin_model->bnk_bal_sum_amount2($cond_approved,'',$order_by,$order_type);

	$enbd_approved['result']=($enbd_rx_aprvd[0]->total_amount)-($enbd_sx_aprvd[0]->total_amount);	


	$cond='';$cond_approved='';
	if(empty($data_ajax))
	{
		$cond=array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);

		$cond_approved=array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year,'ae_sts !='=>'Expected','ae_status_data'=>'2');			
	}
	else
	{
		$cond=array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);	

		$cond_approved=array('ae_bank'=>$banks_array[3],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date,'ae_sts !='=>'Expected','ae_status_data'=>'2');		
	}
	$ei_rx=$this->Admin_model->bnk_bal_sum_amount1($cond,'',$order_by,$order_type);

	$ei_sx=$this->Admin_model->bnk_bal_sum_amount2($cond,'',$order_by,$order_type);

$ei['result']=($ei_rx[0]->total_amount)-($ei_sx[0]->total_amount);
	
	///////for only approved and not expected////
	$ei_rx_aprvd=$this->Admin_model->bnk_bal_sum_amount1($cond_approved,'',$order_by,$order_type);
	$ei_sx_aprvd=$this->Admin_model->bnk_bal_sum_amount2($cond_approved,'',$order_by,$order_type);

	$ei_approved['result']=($ei_rx_aprvd[0]->total_amount)-($ei_sx_aprvd[0]->total_amount);	

	$cond='';$cond_approved='';
	if(empty($data_ajax))
	{
		$cond=array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);	

		$cond_approved=array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year,'ae_sts !='=>'Expected','ae_status_data'=>'2');		
	}
	else
	{
		$cond=array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);	

		$cond_approved=array('ae_bank'=>$banks_array[4],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date,'ae_sts !='=>'Expected','ae_status_data'=>'2');		
	}
	$bachir_rx=$this->Admin_model->bnk_bal_sum_amount1($cond,'',$order_by,$order_type);

	$bachir_sx=$this->Admin_model->bnk_bal_sum_amount2($cond,'',$order_by,$order_type);

	$bachir['result']=($bachir_rx[0]->total_amount)-($bachir_sx[0]->total_amount);

	///////for only approved and not expected////
	$bachir_rx_aprvd=$this->Admin_model->bnk_bal_sum_amount1($cond_approved,'',$order_by,$order_type);
	$bachir_sx_aprvd=$this->Admin_model->bnk_bal_sum_amount2($cond_approved,'',$order_by,$order_type);

	$bachir_approved['result']=($bachir_rx_aprvd[0]->total_amount)-($bachir_sx_aprvd[0]->total_amount);	

	$cond='';$cond_approved='';
	if(empty($data_ajax))
	{
		$cond=array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);	

		$cond_approved=array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year,'ae_sts !='=>'Expected','ae_status_data'=>'2');		
	}
	else
	{
		$cond=array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);	

		$cond_approved=array('ae_bank'=>$banks_array[5],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date,'ae_sts !='=>'Expected','ae_status_data'=>'2');		
	}
	$garhoud_rx=$this->Admin_model->bnk_bal_sum_amount1($cond,'',$order_by,$order_type);

	$garhoud_sx=$this->Admin_model->bnk_bal_sum_amount2($cond,'',$order_by,$order_type);

	$garhoud['result']=($garhoud_rx[0]->total_amount)-($garhoud_sx[0]->total_amount);
	///////for only approved and not expected////
	$garhoud_rx_aprvd=$this->Admin_model->bnk_bal_sum_amount1($cond_approved,'',$order_by,$order_type);
	$garhoud_sx_aprvd=$this->Admin_model->bnk_bal_sum_amount2($cond_approved,'',$order_by,$order_type);

	$garhoud_approved['result']=($garhoud_rx_aprvd[0]->total_amount)-($garhoud_sx_aprvd[0]->total_amount);	


	$cond='';$cond_approved='';
	if(empty($data_ajax))
	{
		$cond=array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		

		$cond_approved=array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year,'ae_sts !='=>'Expected','ae_status_data'=>'2');	
	}
	else
	{
		$cond=array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);	

		$cond_approved=array('ae_bank'=>$banks_array[6],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date,'ae_sts !='=>'Expected','ae_status_data'=>'2');		
	}
	$cash_fact_rx=$this->Admin_model->bnk_bal_sum_amount1($cond,'',$order_by,$order_type);

	$cash_fact_sx=$this->Admin_model->bnk_bal_sum_amount2($cond,'',$order_by,$order_type);

	$cash_fact['result']=($cash_fact_rx[0]->total_amount)-($cash_fact_sx[0]->total_amount);
	///////for only approved and not expected////
	$cash_fact_rx_aprvd=$this->Admin_model->bnk_bal_sum_amount1($cond_approved,'',$order_by,$order_type);
	$cash_fact_sx_aprvd=$this->Admin_model->bnk_bal_sum_amount2($cond_approved,'',$order_by,$order_type);

	$cash_fact_approved['result']=($cash_fact_rx_aprvd[0]->total_amount)-($cash_fact_sx_aprvd[0]->total_amount);	

	$cond='';$cond_approved='';
	if(empty($data_ajax))
	{
		$cond=array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		

		$cond_approved=array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year,'ae_sts !='=>'Expected','ae_status_data'=>'2');	
	}
	else
	{
		$cond=array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);	

		$cond_approved=array('ae_bank'=>$banks_array[7],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date,'ae_sts !='=>'Expected','ae_status_data'=>'2');		
	}
	$other_bank_rx=$this->Admin_model->bnk_bal_sum_amount1($cond,'',$order_by,$order_type);

	$other_bank_sx=$this->Admin_model->bnk_bal_sum_amount2($cond,'',$order_by,$order_type);

	$other_bank['result']=($other_bank_rx[0]->total_amount)-($other_bank_sx[0]->total_amount);
	///////for only approved and not expected////
	$other_bank_rx_aprvd=$this->Admin_model->bnk_bal_sum_amount1($cond_approved,'',$order_by,$order_type);
	$other_bank_sx_aprvd=$this->Admin_model->bnk_bal_sum_amount2($cond_approved,'',$order_by,$order_type);

	$other_bank_approved['result']=($other_bank_rx_aprvd[0]->total_amount)-($other_bank_sx_aprvd[0]->total_amount);


	if(!empty($bbms['result']))
		$bbms_result=$bbms['result'];
	else
		$bbms_result='0';	

	if(!empty($factory['result']))
		$fact_result=$factory['result'];
	else
		$fact_result='0';	

	if(!empty($enbd['result']))
		$ENBD=$enbd['result'];
	else
		$ENBD='0';

	if(!empty($ei['result']))
		$ei_bank=$ei['result'];
	else
		$ei_bank='0';
	
	if(!empty($bachir['result']))
		$cash_bachir=$bachir['result'];
	else
		$cash_bachir='0';
	
	if(!empty($garhoud['result']))
		$Garhoud=$garhoud['result'];
	else
		$Garhoud='0';
	
	if(!empty($cash_fact['result']))
		$cash_fact=$cash_fact['result'];
	else
		$cash_fact='0';
	
	if(!empty($other_bank['result']))
		$others=$other_bank['result'];
	else
		$others='0';

	// $total_bank_bal=(($bbms_result)+($fact_result)+($ENBD)+($ei_bank)+($others) );

	// $total_cash_bal=(($cash_bachir)+($Garhoud)+($cash_fact));
	
	//////for the complete approved transaction///
	if(!empty($bbms_approved['result']))
		$bbms_result_approved=$bbms_approved['result'];
	else
		$bbms_result_approved='0';	

	if(!empty($factory_approved['result']))
		$fact_result_approved=$factory_approved['result'];
	else
		$fact_result_approved='0';	

	if(!empty($enbd_approved['result']))
		$ENBD_approved=$enbd_approved['result'];
	else
		$ENBD_approved='0';

	if(!empty($ei_approved['result']))
		$ei_bank_approved=$ei_approved['result'];
	else
		$ei_bank_approved='0';
	
	if(!empty($bachir_approved['result']))
		$cash_bachir_approved=$bachir_approved['result'];
	else
		$cash_bachir_approved='0';
	
	if(!empty($garhoud_approved['result']))
		$Garhoud_approved=$garhoud_approved['result'];
	else
		$Garhoud_approved='0';
	
	if(!empty($cash_fact_approved['result']))
		$cash_fact_approved=$cash_fact_approved['result'];
	else
		$cash_fact_approved='0';
	
	if(!empty($other_bank_approved['result']))
		$others_approved=$other_bank_approved['result'];
	else
		$others_approved='0';

	$total_bank_bal=(($bbms_result_approved)+($fact_result_approved)+($ENBD_approved)+($ei_bank_approved)+($others_approved) );

	$total_cash_bal=(($cash_bachir_approved)+($Garhoud_approved)+($cash_fact_approved));

		/////category based data///
$cat_array=array('Shipping','Sales','General Expenses','Salaries','Raw Material Purchases','Import Purchases','Personal Accounts','Rent','Others');
		// $limit='1';
		// $order_by='ae_date';
		// 	$order_type="DESC";
	
	//print_r($banks_array);
	$cond='';
	if(empty($data_ajax))
	{
		$cond=array('ae_cat'=>$cat_array[0],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		
	}
	else
	{
		$cond=array('ae_cat'=>$cat_array[0],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);		
	}					
	$ship=$this->Admin_model->get_data_2('account_entry1',$cond,'','','','');
$ship_result=0;
	foreach ($ship as $sr) {
		# code...
		if(($sr->ae_cash_type)=="Received")
			{
				$ship_result=$ship_result+$sr->ae_amount;
			}
		else
			{
				$ship_result=$ship_result-$sr->ae_amount;
			}
	}
	
	$cond='';
	if(empty($data_ajax))
	{
		$cond=array('ae_cat'=>$cat_array[1],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		
	}
	else
	{
		$cond=array('ae_cat'=>$cat_array[1],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);		
	}
	$sales=$this->Admin_model->get_data_2('account_entry1',$cond,'','','','');
	$sales_result=0;
	foreach ($sales as $sl) {
		# code...
		if(($sl->ae_cash_type)=="Received")
			{
				$sales_result=$sales_result+$sl->ae_amount;
			}
		else
			{
				$sales_result=$sales_result-$sl->ae_amount;
			}
	}

	$cond='';
	if(empty($data_ajax))
	{
		$cond=array('ae_cat'=>$cat_array[2],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		
	}
	else
	{
		$cond=array('ae_cat'=>$cat_array[2],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);		
	}
	$gnrl=$this->Admin_model->get_data_2('account_entry1',$cond,'','','','');
	$gnrl_result=0;
	foreach ($gnrl as $gl) {
		# code...
		if(($gl->ae_cash_type)=="Received")
			{
				$gnrl_result=$gnrl_result+$gl->ae_amount;
			}
		else
			{
				$gnrl_result=$gnrl_result-$gl->ae_amount;
			}
	}

	$cond='';
	if(empty($data_ajax))
	{
		$cond=array('ae_cat'=>$cat_array[3],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		
	}
	else
	{
		$cond=array('ae_cat'=>$cat_array[3],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);		
	}
	$salary=$this->Admin_model->get_data_2('account_entry1',$cond,'','','','');
	$salary_result=0;
	foreach ($salary as $sa) {
		# code...
		if(($sa->ae_cash_type)=="Received")
			{
				$salary_result=$salary_result+$sa->ae_amount;
			}
		else
			{
				$salary_result=$salary_result-$sa->ae_amount;
			}
	}

	$cond='';
	if(empty($data_ajax))
	{
		$cond=array('ae_cat'=>$cat_array[4],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		
	}
	else
	{
		$cond=array('ae_cat'=>$cat_array[4],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);		
	}
	$raw_mat=$this->Admin_model->get_data_2('account_entry1',$cond,'','','','');
	$raw_result=0;
	foreach ($raw_mat as $rm) {
		# code...
		if(($rm->ae_cash_type)=="Received")
			{
				$raw_result=$raw_result+$rm->ae_amount;
			}
		else
			{
				$raw_result=$raw_result-$rm->ae_amount;
			}
	}

	$cond='';
	if(empty($data_ajax))
	{
		$cond=array('ae_cat'=>$cat_array[5],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		
	}
	else
	{
		$cond=array('ae_cat'=>$cat_array[5],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);		
	}
	$import=$this->Admin_model->get_data_2('account_entry1',$cond,'','','','');
	$import_result=0;
	foreach ($import as $im) {
		# code...
		if(($im->ae_cash_type)=="Received")
			{
				$import_result=$import_result+$im->ae_amount;
			}
		else
			{
				$import_result=$import_result-$im->ae_amount;
			}
	}

	$cond='';
	if(empty($data_ajax))
	{
		$cond=array('ae_cat'=>$cat_array[6],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		
	}
	else
	{
		$cond=array('ae_cat'=>$cat_array[6],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);		
	}
	$export=$this->Admin_model->get_data_2('account_entry1',$cond,'','','','');
	$exprt_result=0;
	foreach ($export as $xpt) {
		# code...
		if(($xpt->ae_cash_type)=="Received")
			{
				$exprt_result=$exprt_result+$xpt->ae_amount;
			}
		else
			{
				$exprt_result=$exprt_result-$xpt->ae_amount;
			}
	}

	$cond='';
	if(empty($data_ajax))
	{
		$cond=array('ae_cat'=>$cat_array[7],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		
	}
	else
	{
		$cond=array('ae_cat'=>$cat_array[7],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);		
	}
	$rent=$this->Admin_model->get_data_2('account_entry1',$cond,'','','','');
	$rent_result=0;
	foreach ($rent as $rnt) {
		# code...
		if(($rnt->ae_cash_type)=="Received")
			{
				$rent_result=$rent_result+$rnt->ae_amount;
			}
		else
			{
				$rent_result=$rent_result-$rnt->ae_amount;
			}
	}

	$cond='';
	if(empty($data_ajax))
	{
		$cond=array('ae_cat'=>$cat_array[8],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_month'=>$current_mnth,'ae_year'=>$current_year);		
	}
	else
	{
		$cond=array('ae_cat'=>$cat_array[8],'ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_date'=>$current_date);		
	}
	$other_cat=$this->Admin_model->get_data_2('account_entry1',$cond,'','','','');
	$other_cat_result=0;
	foreach ($other_cat as $oc) {
		# code...
		if(($oc->ae_cash_type)=="Received")
			{
				$other_cat_result=$other_cat_result+$oc->ae_amount;
			}
		else
			{
				$other_cat_result=$other_cat_result-$oc->ae_amount;
			}
	}


	if(!empty($ship_result))
		$shipping=$ship_result;
	else
		$shipping="0";

	if(!empty($salary_result))
		$salaries=$salary_result;
	else
		$salaries="0";

	if(!empty($gnrl_result))
		$gnrl=$gnrl_result;
	else
		$gnrl="0";

	if(!empty($sales_result))
		$sales=$sales_result;
	else
		$sales="0";

	if(!empty($raw_result))
		$raw_mat=$raw_result;
	else
		$raw_mat="0";

	if(!empty($import_result))
		$import=$import_result;
	else
		$import="0";

	if(!empty($exprt_result))
		$export=$exprt_result;
	else
		$export="0";

	if(!empty($rent_result))
		$rent=$rent_result;
	else
		$rent="0";

	if(!empty($other_cat_result))
		$other_cat=$other_cat_result;
	else
		$other_cat="0";

	$total_cat=($other_cat + $rent + $export + $import + $raw_mat + $salaries + $gnrl + $shipping + $sales );

	
	//print_r($total_cat);

	if(empty($current_date))
	{
		 $date_selected= ' from '.$start_day_month.' to '.$last_day_month;
	}
	else{
		 $date_selected= ' for '.$current_date;
	}
		
		$data=array(
			'bbms'=>number_format((float)$bbms_result, 2, '.', ''),
		'factory'=>number_format((float)$fact_result, 2, '.', ''),
				'ENBD'=>number_format((float)$ENBD, 2, '.', ''),
			'other_bank'=>number_format((float)$others, 2, '.', ''),
			'ei_bank'=>number_format((float)$ei_bank, 2, '.', ''),
			'Garhoud'=>number_format((float)$Garhoud, 2, '.', ''),
	'cash_bachir'=>number_format((float)$cash_bachir, 2, '.', ''),
		'cash_fact'=>number_format((float)$cash_fact, 2, '.', ''),
	
	/////for approved///	
	'bbms_approved'=>number_format((float)$bbms_result_approved, 2, '.', ''),
	'factory_approved'=>number_format((float)$fact_result_approved, 2, '.', ''),
	'ENBD_approved'=>number_format((float)$ENBD_approved, 2, '.', ''),
	'other_bank_approved'=>number_format((float)$others_approved, 2, '.', ''),
	'ei_bank_approved'=>number_format((float)$ei_bank_approved, 2, '.', ''),
	'Garhoud_approved'=>number_format((float)$Garhoud_approved, 2, '.', ''),
	'cash_bachir_approved'=>number_format((float)$cash_bachir_approved, 2, '.', ''),
	'cash_fact_approved'=>number_format((float)$cash_fact_approved, 2, '.', ''),
			

				'total_bank_bal'=>number_format((float)$total_bank_bal, 2, '.', ''),
				'total_cash_bal'=>number_format((float)$total_cash_bal, 2, '.', ''),
			'shipping'=>number_format((float)$shipping, 2, '.', ''),
				'sales'=>number_format((float)$sales, 2, '.', ''),
				'gnrl'=>number_format((float)$gnrl, 2, '.', ''),
			'salary'=>number_format((float)$salaries, 2, '.', ''),
			'raw_mat'=>number_format((float)$raw_mat, 2, '.', ''),
				'rent'=>number_format((float)$rent, 2, '.', ''),
				'import'=>number_format((float)$import, 2, '.', ''),
				'export'=>number_format((float)$export, 2, '.', ''),
			'other'=>number_format((float)$other_cat, 2, '.', ''),
		'total_cat'=>number_format((float)$total_cat, 2, '.', ''),
		'bank_date'=>$date_selected,
			);
//print_r($data);
			echo json_encode($data);

}























}