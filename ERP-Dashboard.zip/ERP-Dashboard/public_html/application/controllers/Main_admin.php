<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main_admin extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper('session');	
		$this->load->library('encryption');
        $this->load->model('Second_db_model');
	}

function add_users($id=null)
{
if(logged_in())
	{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
        if ((($page_cred[$i]=='add-users')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

	if(empty($id))
	$this->load->view('admin/add_users');
	else
	{
		 $cond=array('log_id'=>$id);
		$data['result']=$this->Admin_model->get_data('login_credentials',$cond);
		$this->load->view('admin/add_users',$data);
	}
	}
     else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	    	redirect('login','refersh');
	}

	}
}


///////new edit 14--9-20022
function current_user_activity($id=null)
{
 if(logged_in())
	{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
        if ((($page_cred[$i]=='activity-users')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

	if(empty($id))
	$this->load->view('admin/list_users');
	else
	{


		 $cond=array('log_id'=>$id);


		$data['result']=$this->Admin_model->get_data('login_credentials',$cond);
             $username=$data['result'][0]->log_uname;
        $condactivity=array('act_user'=>$username);
 
		

		$data['resultactivity']=$this->Admin_model->get_data('activities',$condactivity);





		$this->load->view('admin/activity_users',$data);
	}
	}
     else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	    	redirect('login','refersh');
	}

	}
}





function list_users()
{
if(logged_in())
		{
			$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
        if ((($page_cred[$i]=='list-users')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {
	 $cond=array('log_status'=>'1');
		$order_by='log_id';
		$order_type="DESC";
		$data['result']=$this->Admin_model->get_data('login_credentials',$cond,'','',$order_by,$order_type);
	$this->load->view('admin/list_users',$data);

     }
     else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	    	redirect('login','refersh');
	   }



	}
}
function submit_user_mng()
{
	$user_id=$this->input->post('user_id');

	$this->form_validation->set_rules('dept', 'Department', 'trim|required');

    $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');

if(empty($user_id))
{

    $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[login_credentials.log_email]');

    $this->form_validation->set_rules('user_name', 'User Name', 'trim|required|is_unique[login_credentials.log_uname]');

$this->form_validation->set_rules('pwd', 'Password', 'trim|required');
	$this->form_validation->set_rules('confrm_pwd', 'Confirm Password', 'trim|required|matches[pwd]');
}
	$this->form_validation->set_rules('view_options[]', 'Options', 'trim|required');


		if ($this->form_validation->run() == FALSE)
        {          
       
		$this->session->set_flashdata('dept',form_error('dept'));

        	if(empty($user_id))
        	{
                 $this->session->set_flashdata('user_name', form_error('user_name'));
        		$this->session->set_flashdata('pwd', form_error('pwd'));
                $this->session->set_flashdata('email', form_error('email'));
        		$this->session->set_flashdata('confrm_pwd', form_error('confrm_pwd'));
        		 if($post_dept=="Sales")
			    {
			      $this->form_validation->set_rules('sale_type', 'Sales Type', 'trim|required');  
			    }
        	}
		$this->session->set_flashdata('view_options[]', form_error('view_options[]'));
		 redirect('add-users','refresh');
        }
        else
        {
     	
         	if(empty($user_id))
         	{
         		$to_encrypt= $this->input->post('pwd');
            	$ciphertext =$this->encryption->encrypt($to_encrypt);
         	}        	
        	$cust_interest_array=$this->input->post('view_options[]');
        	$new_interest=implode(',',$cust_interest_array);

        		$role;
        		$dept=$this->input->post('dept');
        		switch($dept)
        		{
        			case 'Main':
        			$role='1';
        			break;
        			case 'Accounts':
        			$role='2';
        			break;
        			case 'Sales':
        			$role='2';
        			break;
        			case 'Marketing':
        			$role='2';
        			break;
                    case 'Main factory':
                    $role='2';
                    break;
                    case 'Traffic Safety-Advertisement':
                    $role='2';
                    break;
                     case 'HR':
                    $role='2';
                    break;
                     case 'Purchase':
                    $role='2';
                    break;
                    case 'Factory Staff':
                    $role='2';
                    break;
                    case 'Project Department':
                    $role='2';
                    break;
        			default:
        			break;
        		}
         if($dept=="Sales")
            {
           $sub_type=$this->input->post('sale_type');
            }
            else
            {
            $sub_type='';    
            }
        				
        	$data=array(
           'log_uname'=>$this->input->post('user_name'),
            'log_role'=>$role,
           'log_dept'=>$dept,
           'log_page'=>$new_interest,   
            'log_email'=>$this->input->post('email'),
             'log_sub_type'=>$sub_type,     
           );
          // print_r($data);
        if(empty($user_id))
     	{	
     	//echo "in if";
        	$insert_id=$this->Admin_model->insert_data('login_credentials',$data);
        	if($insert_id)
        	{
        		$data1=array('log_pwd'=>$ciphertext,
        			'log_status'=>'1');
        		$cond1=array('log_id'=>$insert_id);
	       		$this->Admin_model->update_data('login_credentials',$data1,$cond1);
        		$this->session->set_flashdata('success', 'Data successfully inserted');
	     		redirect('add-users');
        	}
        }	
        	else
        	{
	//echo "in else";
        		$cond1=array('log_id'=>$user_id);
	       		$this->Admin_model->update_data('login_credentials',$data,$cond1);
	       		$this->session->set_flashdata('success', 'Data successfully updated');
	     		redirect('list-users');
        	}
        	
        }
}


function update_password()
{
if(logged_in())
		{
	$user_id=$this->input->post('user_id');
	
	$to_encrypt= $this->input->post('new_pwd');
    $ciphertext =$this->encryption->encrypt($to_encrypt);

	$data=array('log_pwd'=>$ciphertext);
		$cond1=array('log_id'=>$user_id);
	       		$this->Admin_model->update_data('login_credentials',$data,$cond1);

	echo true;
	}
}



function list_user_files()
{
 if(logged_in())
 {

   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
        if ((($page_cred[$i]=='list-user-files')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {
	     $cond=array('bc_status'=>'1');
	     $data['result']=$this->Second_db_model->get_data('file_manager',$cond);  
	     $this->load->view('admin/list_user_files',$data);  

	}
     else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	    	redirect('login','refersh');
	}

  }
}

function delete_user($user_id)
{
if(logged_in())
	{
$data=array('log_status'=>'0');
$cond1=array('log_id'=>$user_id);
$this->Admin_model->update_data('login_credentials',$data,$cond1);

$this->session->set_flashdata('success', 'user successfully deleted');
	     		redirect('list-users'); 
   }
}


















}