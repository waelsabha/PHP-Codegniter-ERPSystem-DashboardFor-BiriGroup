<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_user_dashboard extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper('session');	
		$this->load->model(array('Third_db_model'=>'tm','Sales_book_model'));
	}

function dashboard()
{
	if(logged_in())
	{
	$dept_logged_in=$this->session->userdata['user']['main_dept'];
	
	if($dept_logged_in=="KSA Sales")
	{
	
	 $city_list=array('Al Dammam','Jeddah','Riyadh');
	}
	else
	{	
	$city_list=array();
	}
	
	
	$sales_man_focus_name=$this->Admin_model->get_data('login_credentials',array('log_uname'=>$this->session->userdata['user']['username']));
	if(!empty($sales_man_focus_name[0]->focus_user_name))
	{
		$sales_man_name=$sales_man_focus_name[0]->focus_user_name;
	}
	else
	{
		$sales_man_name=$this->session->userdata['user']['username'];
	}

$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
$current_month= $dt->format('m');
$current_year= $dt->format('Y');
$previous_year=$dt->format('Y')-1;
$last_previous_year=$dt->format('Y')-2;

$months=array('01','02','03','04','05','06','07','08','09','10','11','12');
foreach($months as $m)
{
	$datt['curnt_yr'][]=$this->Sales_book_model->bar_chart_data_curnt_year($current_year,$m,$city_list,array('sbr_salesman'=>$sales_man_name));

	$datt['prev_yr'][]=$this->Sales_book_model->bar_chart_data_prev_year($previous_year,$m,$city_list,array('sbr_salesman'=>$sales_man_name));	
	$datt['last_prev_yr'][]=$this->Sales_book_model->bar_chart_data_prev_year($last_previous_year,$m,$city_list,array('sbr_salesman'=>$sales_man_name));
}

foreach($datt['curnt_yr'] as $dc)
{
	$data['months_curnt'][]=$dc[0]->total_amount;
}

foreach($datt['prev_yr'] as $dp)
{
	$data['months_prev'][]=$dp[0]->total_amount;
}

foreach($datt['last_prev_yr'] as $dp)
{
	$data['months_last_prev'][]=$dp[0]->total_amount;
}

$datt['cat_curnt_yr'][]=$this->Sales_book_model->all_category($current_year,'','',$city_list,array('sbr_salesman'=>$sales_man_name));
if(empty($datt['cat_curnt_yr'][0]))
{
$datt2['cat_curnt_yr'][]=$this->Sales_book_model->all_category($previous_year,'','',$city_list,array('sbr_salesman'=>$sales_man_name));
}


if(!empty($datt['cat_curnt_yr'][0]))
{
$all_cat_names=array();$all_cat_sum1=array();
foreach($datt['cat_curnt_yr'][0] as $cat_c)
{
	if(!empty($all_cat_names))
	{
	if(!in_array($cat_c->sbp_ar_category, $all_cat_names))
	$all_cat_names[]=$cat_c->sbp_ar_category;
	}
	else
	{
	$all_cat_names[]=$cat_c->sbp_ar_category;
	}
$all_cat_sum1[$cat_c->sbp_ar_category][]=$cat_c->total_gross_amount;
}
foreach($all_cat_names as $c)
{
$datt['cat_prev_yr'][]=$this->Sales_book_model->all_category($previous_year,array('sbp_ar_category'=>$c),'',$city_list,array('sbr_salesman'=>$sales_man_name));
$datt['cat_last_prev_yr'][]=$this->Sales_book_model->all_category($last_previous_year,array('sbp_ar_category'=>$c),'',$city_list,array('sbr_salesman'=>$sales_man_name));
}


foreach($datt['cat_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum2[]=$c2;
	}
	
	foreach($datt['cat_last_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum3[]=$c2;
	}	
	$data['cat_amount_curnt']=$all_cat_sum1;
	$data['cat_amount_prev']=$all_cat_sum2;
	$data['cat_amount_last_prev']=$all_cat_sum3;
}
else
{
$all_cat_names=array();$all_cat_sum1=array();
	foreach($datt2['cat_curnt_yr'][0] as $cat_c)
	{
		if(!empty($all_cat_names))
		{
		if(!in_array($cat_c->sbp_ar_category, $all_cat_names))
		$all_cat_names[]=$cat_c->sbp_ar_category;
		}
		else
		{
		$all_cat_names[]=$cat_c->sbp_ar_category;
		}
	$all_cat_sum1[$cat_c->sbp_ar_category][]=$cat_c->total_gross_amount;
	}
	
	foreach($all_cat_names as $c)
	{
	$datt['cat_prev_yr'][]=$this->Sales_book_model->all_category($previous_year,array('sbp_ar_category'=>$c),'',$city_list,array('sbr_salesman'=>$sales_man_name));	
	$datt['cat_last_prev_yr'][]=$this->Sales_book_model->all_category($last_previous_year,array('sbp_ar_category'=>$c),'',$city_list,array('sbr_salesman'=>$sales_man_name));
	}
	
	
	foreach($datt['cat_last_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum3[]=$c2;
	}
	
	foreach($datt['cat_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum2[]=$c2;
	}
	
	$data['cat_amount_curnt']=array();
	$data['cat_amount_prev']=$all_cat_sum2;
	$data['cat_amount_last_prev']=$all_cat_sum3;
}
$data['all_category_comparison']=$all_cat_names;	
$data['current_year']=$current_year;
$data['previous_year']=$previous_year;
$data['last_previous_year']=$last_previous_year;

$strt_range=$this->input->post('start_date_rng');
$end_range=$this->input->post('end_date_rng');
$select_month=$this->input->post('month_selected');

if(!empty($strt_range) && !empty($end_range))
{
$cond_both_dates=array(
	'sbr_vou_date >='=>date("Y-m-d", strtotime($strt_range)),
	'sbr_vou_date <='=>date("Y-m-d", strtotime($end_range)),
	);
	
	$current_year='';
}
else if(!empty($end_range))
{
$cond_both_dates=array(
	'sbr_vou_date <='=>date("Y-m-d", strtotime($end_range)),
	);
	$current_year='';
}
else if(!empty($strt_range))
{
$cond_both_dates=array(
	'sbr_vou_date >='=>date("Y-m-d", strtotime($strt_range)),
	);
	$current_year='';
}
else{
	$cond_both_dates='';
}

if(!empty($select_month))
{
	$cond_month=array(
	'sbr_voc_month'=>$select_month,
	);	
}	
else
{
$cond_month='';
}

$data['start_date']=$strt_range;
$data['end_date']=$end_range;
$data['selected_month']=$select_month;

$data['salesman']=$this->Sales_book_model->sales_per_salesperson($current_year,$cond_both_dates,$cond_month,$city_list,array('sbr_salesman'=>$sales_man_name));

foreach($data['salesman'] as $ind1=>$a_sales)
{	
$prd2[]=$this->Sales_book_model->all_prd('','',$a_sales->sbr_salesman,$current_year,$cond_both_dates,$cond_month,$city_list,'');
}

$groups2 = [];
foreach ($prd2 as $key2 => $pd) 
{
	foreach($pd as $pd3)
	{
$groups2[$pd3->sbr_salesman][$pd3->sbp_prd_code]['sum'][]=$pd3->sbp_gross;   
$groups2[$pd3->sbr_salesman][$pd3->sbp_prd_code]['qnty'][]=$pd3->sbp_qty;   
	 }
}

 $sum_array=[];
foreach ($groups2 as $key4 => $value) {
	foreach($value as $key5=>$v1)
	{
	 $data['sp_prd'][$key4][]=array(
 		'prd_qnty'=>array_sum(str_replace(',', '', $v1['qnty'])) ,
		'prd_code'=>$key5,
		);
	}
}	


//echo $current_month;
$data['all_category']=$this->Sales_book_model->all_category($current_year,$cond_both_dates,$cond_month,$city_list,'');
foreach($data['all_category'] as $indx1=>$a_cat)
{	

$prd[]=$this->Sales_book_model->all_prd($a_cat->sbp_ar_category,'','',$current_year,$cond_both_dates,$cond_month,$city_list,'');
}

$groups = [];
foreach ($prd as $key2 => $pd) 
{
	foreach($pd as $pd3)
	{
$groups[$pd3->sbp_ar_category][$pd3->sbp_prd_code]['sum'][]=$pd3->sbp_gross;   
$groups[$pd3->sbp_ar_category][$pd3->sbp_prd_code]['qnty'][]=$pd3->sbp_qty;   
	 }
}

 $sum_array=[];
foreach ($groups as $key4 => $value) {
	foreach($value as $key5=>$v1)
	{
	 $data['cat_prd'][$key4][]=array(
 		'sum'=>array_sum(str_replace(',', '', $v1['sum'])),
		'prd_qnty'=>array_sum(str_replace(',', '', $v1['qnty'])) ,
		'prd_code'=>$key5,
		);
	}
}
	
$cash_customer_top=$this->Sales_book_model->cash_customer_top(array('sbr_salesman'=>$sales_man_name));
	foreach($cash_customer_top as $cct)
	{
		if(!empty($cct->sbr_narration))
		$data['narration_data'][]=$this->Sales_book_model->cash_customer_top_data($cct->sbr_narration,$sales_man_name);
	}
	
			
$this->load->view('admin/sales_users/sales_user_dashboard',$data);
	}
}













}