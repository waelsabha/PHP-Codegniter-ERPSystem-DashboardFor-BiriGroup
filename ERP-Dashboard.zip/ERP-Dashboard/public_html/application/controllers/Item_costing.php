<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item_costing extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','email_survey'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm','UK_product_db'=>'ukdb'));
	}

function create_prd_grps_pricing()
{
	if(logged_in())
	{


 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='create-prd-grps-pricing')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

	$data['result']=$this->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>'','gc_sts'=>'1'));
	foreach($data['result'] as $index=>$r)
	{
		$data['sub_prd'][$index][$index][]=$this->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>$r->gc_id ,'gc_sts'=>'1'));
	}
	//$data['prd']=$this->tm->get_items_for_costing();
	
	 $this->load->view('admin/production/create_prd_grps_pricing',$data);

 }
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}





	 }
}
function submit_prd_grps_pricing()
{
	if(logged_in())
	{
	$this->Admin_model->insert_data('prd_grps_pricing',array('gc_grp_name'=>$this->input->post('prd_grp_name'),'gc_sts'=>'1'));
	
 		$this->session->set_flashdata('success', 'Group name added successfully ');
 		redirect('create-prd-grps-pricing');
 	}
}

function submit_add_sub_prds()
{
if(logged_in())
	{
	$this->Admin_model->insert_data('prd_grps_pricing',array('gc_grp_main_id'=>$this->input->post('main_grp_id'),'gc_grp_sub_name'=>$this->input->post('add_sub_prd_name'),'gc_sts'=>'1'));
	
 		$this->session->set_flashdata('success', 'Sub-Group name added successfully ');
 		redirect('create-prd-grps-pricing');
 	}
}

function set_prd_grps_pricing()
{
	if(logged_in())
	{


$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='set-prd-grps-pricing')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

	//$data['base']=$this->tm->get_items_for_costing();
    $data['base']=$this->tm->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>'1','gc_sts'=>'1'));
	$data['reflective']=$this->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>'3','gc_sts'=>'1'));
	$data['printing']=$this->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>'4','gc_sts'=>'1'));
	$data['channels']=$this->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>'6','gc_sts'=>'1'));
	$data['painting']=$this->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>'7','gc_sts'=>'1'));
	$data['powder_coating']=$this->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>'31','gc_sts'=>'1'));

	$data['result']=$this->Admin_model->get_data('prd_set_pricing',array('pps_sts'=>'1','pps_grp_ids'=>'1'));
	$data['result_reflective']=$this->Admin_model->get_data('prd_set_pricing',array('pps_sts'=>'1','pps_grp_ids'=>'2'));
	$data['result_print']=$this->Admin_model->get_data('prd_set_pricing',array('pps_sts'=>'1','pps_grp_ids'=>'3'));
	$data['result_channel']=$this->Admin_model->get_data('prd_set_pricing',array('pps_sts'=>'1','pps_grp_ids'=>'4'));
	$data['result_paint']=$this->Admin_model->get_data('prd_set_pricing',array('pps_sts'=>'1','pps_grp_ids'=>'5'));
	$data['result_pow']=$this->Admin_model->get_data('prd_set_pricing',array('pps_sts'=>'1','pps_grp_ids'=>'6'));
	
	$this->load->view('admin/production/set_grp_pricing',$data);


 }
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}

	
	}
}

function submit_set_pricing()
{
	$base_ids=$this->input->post('prd_id[]');
	$base_name=$this->input->post('base_name_prd[]');
	$base_width=$this->input->post('width_base[]');
	$base_hgt=$this->input->post('length_base[]');
	$base_unit_price=$this->input->post('unit_price_base[]');
	$base_price=$this->input->post('price_base[]');
	$base_percentage=$this->input->post('percenatge_base[]');
	$base_final_price=$this->input->post('final_base[]');

	$base_edit_ids=$this->input->post('edit_prd_id[]');

	$refl_id=$this->input->post('reflective_id[]');
	$refl_name=$this->input->post('reflective[]');
	$refl_width=$this->input->post('width_reflective[]');
	$refl_hgt=$this->input->post('length_reflective[]');
	$refl_unit_price=$this->input->post('unit_price_reflective[]');
	$refl_price=$this->input->post('price_reflective[]');
	$refl_percentage=$this->input->post('percenatge_reflective[]');
	$refl_final_price=$this->input->post('final_reflective[]');

	$edit_refl_ids=$this->input->post('edit_refl_id[]');

	$print_id=$this->input->post('print_id[]');
	$print_name=$this->input->post('printing[]');
	$print_width=$this->input->post('width_printing[]');
	$print_hgt=$this->input->post('length_printing[]');
	$print_unit_price=$this->input->post('unit_price_printing[]');
	$print_price=$this->input->post('price_print[]');
	$print_percentage=$this->input->post('percenatge_printing[]');
	$print_final_price=$this->input->post('final_print[]');

	$edit_print_ids=$this->input->post('edit_print_id[]');

	$channel_ids=$this->input->post('channel_id[]');
	$channel_name=$this->input->post('channel[]');
	$channel_width=$this->input->post('width_channel[]');
	$channel_hgt=$this->input->post('length_channel[]');
	$channel_unit_price=$this->input->post('unit_price_channel[]');
	$channel_price=$this->input->post('price_channel[]');
	$channel_percentage=$this->input->post('percenatge_channel[]');
	$channel_final_price=$this->input->post('final_channel[]');

	$edit_channel_ids=$this->input->post('edit_channel_id[]');

	$paint_ids=$this->input->post('painting_id[]');
	$paint_name=$this->input->post('painting[]');
	$paint_width=$this->input->post('width_painting[]');
	$paint_hgt=$this->input->post('length_painting[]');
	$paint_unit_price=$this->input->post('unit_price_painting[]');
	$paint_price=$this->input->post('price_painting[]');
	$paint_percentage=$this->input->post('percenatge_painting[]');
	$paint_final_price=$this->input->post('final_painting[]');

	$edit_paint_ids=$this->input->post('edit_paint_id[]');

	$pow_ids=$this->input->post('pow_id[]');
	$pow_name=$this->input->post('pow[]');
	$pow_width=$this->input->post('width_pow[]');
	$pow_hgt=$this->input->post('length_pow[]');
	$pow_unit_price=$this->input->post('unit_price_pow[]');
	$pow_price=$this->input->post('price_pow[]');
	$pow_percentage=$this->input->post('percenatge_pow[]');
	$pow_final_price=$this->input->post('final_pow[]');

	$edit_pow_ids=$this->input->post('edit_pow_id[]');

	foreach($base_ids as $index=>$b)
	{
		$data=array(
			'pps_name'=>$base_name[$index],
			'pps_prd_id'=>$b,
			'pps_width'=>$base_width[$index],
			'pps_length'=>$base_hgt[$index],
			'pps_unit_price'=>$base_unit_price[$index],
			'pps_price'=>$base_price[$index],
			'pps_added_per'=>$base_percentage[$index],
			'pps_final_price'=>$base_final_price[$index],
			'pps_sts'=>'1',
			'pps_grp_ids'=>'1'
			);

		if(empty($base_edit_ids[$index]))
		$this->Admin_model->insert_data('prd_set_pricing',$data);
		else
		$this->Admin_model->update_data('prd_set_pricing',$data,array('pps_id'=>$base_edit_ids[$index]));	
	}

	foreach($refl_id as $index1=>$r)
	{
		$data=array(
			'pps_name'=>$refl_name[$index1],
			'pps_prd_id'=>$r,
			'pps_width'=>$refl_width[$index1],
			'pps_length'=>$refl_hgt[$index1],
			'pps_unit_price'=>$refl_unit_price[$index1],
			'pps_price'=>$refl_price[$index1],
			'pps_added_per'=>$refl_percentage[$index1],
			'pps_final_price'=>$refl_final_price[$index1],
			'pps_sts'=>'1',
			'pps_grp_ids'=>'2'
			);
		if(empty($edit_refl_ids[$index1]))
		$this->Admin_model->insert_data('prd_set_pricing',$data);
		else
		$this->Admin_model->update_data('prd_set_pricing',$data,array('pps_id'=>$edit_refl_ids[$index1]));
	}

	foreach($print_id as $index11=>$pr)
	{
		$data=array(
			'pps_name'=>$print_name[$index11],
			'pps_prd_id'=>$pr,
			'pps_width'=>$print_width[$index11],
			'pps_length'=>$print_hgt[$index11],
			'pps_unit_price'=>$print_unit_price[$index11],
			'pps_price'=>$print_price[$index11],
			'pps_added_per'=>$print_percentage[$index11],
			'pps_final_price'=>$print_final_price[$index11],
			'pps_sts'=>'1',
			'pps_grp_ids'=>'3',
			);
		if(empty($edit_print_ids[$index11]))
			$this->Admin_model->insert_data('prd_set_pricing',$data);
		else
		$this->Admin_model->update_data('prd_set_pricing',$data,array('pps_id'=>$edit_print_ids[$index11]));
	}

	foreach($channel_ids as $index12=>$ch)
	{
		$data=array(
			'pps_name'=>$channel_name[$index12],
			'pps_prd_id'=>$ch,
			'pps_width'=>$channel_width[$index12],
			'pps_length'=>$channel_hgt[$index12],
			'pps_unit_price'=>$channel_unit_price[$index12],
			'pps_price'=>$channel_price[$index12],
			'pps_added_per'=>$channel_percentage[$index12],
			'pps_final_price'=>$channel_final_price[$index12],
			'pps_sts'=>'1',
			'pps_grp_ids'=>'4',
			);
		if(empty($edit_channel_ids[$index12]))
			$this->Admin_model->insert_data('prd_set_pricing',$data);
		else
		$this->Admin_model->update_data('prd_set_pricing',$data,array('pps_id'=>$edit_channel_ids[$index12]));
	}

	foreach($paint_ids as $index13=>$pa)
	{
		$data=array(
			'pps_name'=>$paint_name[$index13],
			'pps_prd_id'=>$pa,
			'pps_width'=>$paint_width[$index13],
			'pps_length'=>$paint_hgt[$index13],
			'pps_unit_price'=>$paint_unit_price[$index13],
			'pps_price'=>$paint_price[$index13],
			'pps_added_per'=>$paint_percentage[$index13],
			'pps_final_price'=>$paint_final_price[$index13],
			'pps_sts'=>'1',
			'pps_grp_ids'=>'5',
			);
		if(empty($edit_paint_ids[$index13])) 
		$this->Admin_model->insert_data('prd_set_pricing',$data);
		else
		$this->Admin_model->update_data('prd_set_pricing',$data,array('pps_id'=>$edit_paint_ids[$index13]));
	}

	foreach($pow_ids as $index15=>$po)
	{
		$data=array(
			'pps_name'=>$pow_name[$index15],
			'pps_prd_id'=>$po,
			'pps_width'=>$pow_width[$index15],
			'pps_length'=>$pow_hgt[$index15],
			'pps_unit_price'=>$pow_unit_price[$index15],
			'pps_price'=>$pow_price[$index15],
			'pps_added_per'=>$pow_percentage[$index15],
			'pps_final_price'=>$pow_final_price[$index15],
			'pps_sts'=>'1',
			'pps_grp_ids'=>'6'
			);
		if(empty($edit_pow_ids[$index15])) 
		$this->Admin_model->insert_data('prd_set_pricing',$data);
		else
		$this->Admin_model->update_data('prd_set_pricing',$data,array('pps_id'=>$edit_pow_ids[$index15]));
	}

// //print_r($data);
	$this->session->set_flashdata('success', 'Standard Item Price created successfully ');
 		redirect('set-prd-grps-pricing');
}

function check_standard_pricing()
{
	if(logged_in())
	{
	$data['result']=$this->Admin_model->get_data('prd_set_pricing',array('pps_sts'=>'1'));
	$this->load->view('admin/production/check_standard_pricing',$data);
	}
}

function check_customized_pricing()
{
	if(logged_in())
	{
	$data['result']=$this->Admin_model->get_data('prd_set_pricing',array('pps_sts'=>'1'));
	$this->load->view('admin/production/check_standard_pricing',$data);
	}
}

function prd_std_pricing()
{
	if(logged_in())
	{
     $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='check-standard-pricing')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

	   $data['result']=$this->Admin_model->get_data('prd_set_pricing',array('pps_sts'=>'1'));
	   $this->load->view('admin/production/create_prd_set_std',$data);

  }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}



function custom_pricing()
{

	if(logged_in())
	{

  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
         $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {
            if ($page_cred[$i]=='check-customized-pricing')
            {
               $excist=true;
               $i=$cred_count;
            }   

           else
                {$excist=false;}

        }
       if ($excist) {

	$data['base']=$this->Admin_model->get_data('prd_set_pricing',array('pps_grp_ids'=>'1','pps_sts'=>'1'));
	$data['reflective']=$this->Admin_model->get_data('prd_set_pricing',array('pps_grp_ids'=>'2','pps_sts'=>'1'));
	$data['printing']=$this->Admin_model->get_data('prd_set_pricing',array('pps_grp_ids'=>'3','pps_sts'=>'1'));
	$data['channels']=$this->Admin_model->get_data('prd_set_pricing',array('pps_grp_ids'=>'4','pps_sts'=>'1'));
	$data['painting']=$this->Admin_model->get_data('prd_set_pricing',array('pps_grp_ids'=>'5','pps_sts'=>'1'));
	$data['powder_coating']=$this->Admin_model->get_data('prd_set_pricing',array('pps_grp_ids'=>'6','pps_sts'=>'1'));
	$this->load->view('admin/production/prd_custom_pricing',$data);

}

 else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
        } 



	}




}





///////new pricing uk testing  
function pricing_show_uk()
{
	if(logged_in())
	{


 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='pricing-uk')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

	//$data['result']=$this->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>'','gc_sts'=>'1'));

   	$data['products_list']=$this->ukdb->get_data('products',array('published'=>'1'));
	
    $currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>'4'));
$currencyval=$currency[0]->currency_val;
   	//print_r($currencyval);exit(0);


	 foreach($data['products_list'] as $index=>$t)
	 {
            $purchase_price=$t->purchase_price;
            $shipping_val_perce=$t->shipping_val_perce;
            $added_val_perce=$t->added_val_perce;
            $shipping_calc_val=(($t->purchase_price)*($t->shipping_val_perce/100));
            $added_calc_val=(($t->purchase_price)*($t->added_val_perce/100));
            $webprice_aed=($purchase_price+$shipping_calc_val+$added_calc_val);
            $webprice_GBP=number_format((float)($webprice_aed/$currencyval),2,'.','');

          $dataresult['test'][$index]=array(
			'id'=>$t->id,
			'name'=>$t->name,
			'sku'=>$t->sku,
			'purchase_price'=>$t->purchase_price,
			'shipping_val_perce'=>$t->shipping_val_perce,
			'added_val_perce'=>$t->added_val_perce,
			'shipping_calc_val'=>$shipping_calc_val,
			'added_calc_val'=>$added_calc_val,
			'webprice_aed'=>$webprice_aed,
			'webprice_GBP'=>$webprice_GBP,

			);



	 	
	}



 


// print_r($dataresult);


// //print_r($dataresult);
// exit(0);




	
	
	 $this->load->view('admin/production/create_prd_pricing',$dataresult);

 }
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}





	 }
}




function submit_prd_pricing_uk()
{
if(logged_in())
	{
	// $this->Admin_model->insert_data('prd_grps_pricing',array('gc_grp_main_id'=>$this->input->post('main_grp_id'),'gc_grp_sub_name'=>$this->input->post('add_sub_prd_name'),'gc_sts'=>'1'));
    $main_code=$this->input->post('main_prd_code');
    $main_prd_id=$this->input->post('main_prd_id');



$datadashboard=array(
			'p_purchase_price'=>$this->input->post('add_prd_purchase'),
			'shipping_perc'=>$this->input->post('add_prd_shipp_perce'),
			'added_value_perc'=>$this->input->post('add_prd_addedval_perce'),
		    'p_alert_uk'=>$this->input->post('alert_qnty_uk'),
			'pbin_capacity_uk'=>$this->input->post('bin_capacity_uk'),
			
			
			);

	$this->tm->update_data('products',$datadashboard,array('pcode'=>$main_code));






	$data=array(
			'purchase_price'=>$this->input->post('add_prd_purchase'),
			'shipping_val_perce'=>$this->input->post('add_prd_shipp_perce'),
			'added_val_perce'=>$this->input->post('add_prd_addedval_perce'),
			 'alert_qnty'=>$this->input->post('alert_qnty_uk'),
			'bin_capacity'=>$this->input->post('bin_capacity_uk'),
			);

	$this->ukdb->update_data('products',$data,array('id'=>$main_prd_id));
        
			$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'Product Pricing',
				'act_status'=>'product in Uk code ('.$main_code.')  mkae Change in the Pricing Percentage-  ',
				
			     'act_doc_num'=>$main_code,
				'act_type'=>'Product Pricing ',
				
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()
			);
			   $this->Admin_model->insert_data('activities',$activity_data); 
	

    

 		$this->session->set_flashdata('success', 'New Percentage added successfully ');
 		redirect('pricing-uk');
 	}
}













///////new productdetails    purchase uk testing  
function product_show_details_uk()
{
	if(logged_in())
	{
   

      $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='pricing-purchase-uk')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

			

	//$data['result']=$this->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>'','gc_sts'=>'1'));

   	$dataresult2['products_list_pur']=$this->tm->get_data('products',array('p_sts'=>'1'));
        // print_r($dataresult2['products_list_pur'][0]->prod_id_focus);exit();

   	///for UK
    $currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>'4'));


   $currencyval=$currency[0]->currency_val;
$dataresult2['resultnoapprove']=$this->tm->get_data('products',array('temp_p_purchase_price !='=>'0'));



	 foreach($dataresult2['resultnoapprove'] as $index=>$t)
	 {

	//	 print_r('test');

           $purchase_price_old=$t->p_purchase_price;
           $purchase_price_new=$t->temp_p_purchase_price;
            $shipping_val_perce=$t->shipping_perc;
            $added_val_perce=$t->added_value_perc;




          ////for old purchase price////////////////////////////////
            $shipping_calc_val_old=($purchase_price_old*(($t->shipping_perc)/100));
            $added_calc_val_old=($purchase_price_old*(($t->added_value_perc)/100));

            $webprice_aed_old=($purchase_price_old+$shipping_calc_val_old+$added_calc_val_old);
            $webprice_GBP_old=number_format((float)($webprice_aed_old/$currencyval),2,'.','');


            /////////////////////////////////////////////////

     ////for old purchase price////////////////////////////////
            $shipping_calc_val_new=($purchase_price_new*(($t->shipping_perc)/100));
            $added_calc_val_new=($purchase_price_new*(($t->added_value_perc)/100));

            $webprice_aed_new=($purchase_price_new+$shipping_calc_val_new+$added_calc_val_new);
            $webprice_GBP_new=number_format((float)($webprice_aed_new/$currencyval),2,'.','');

            /////////////////////////////////////////////////








            $arrycountry=$this->tm->get_data('country_val',array('country_id'=>$t->p_country));
	

           $country_origin=$arrycountry[0]->name;

           $supplier=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$t->p_last_supplier));

           $suppliername=$supplier[0]->label;

   
          $dataresult2['resulttoapprove'][$index]=array(
			'pid'=>$t->pid,
			'pname'=>$t->pname,
			'pcode'=>$t->pcode,
			'prd_width'=>$t->p_pack_width,
			'prd_height'=>$t->p_pack_hgt,
			'p_pack_lgth'=>$t->p_pack_lgth,
			'p_wgt'=>$t->p_wgt,
			'p_country'=>$country_origin,
			'p_country_id'=>$t->p_country,
			'p_last_supplier'=>$suppliername,
			'p_last_supplier_id'=>$t->p_last_supplier,
		    'shipping_calc_val_old'=>$shipping_calc_val_old,
		    'shipping_calc_val_new'=>$shipping_calc_val_new,
			'added_calc_val_old'=>$added_calc_val_old,
			'added_calc_val_new'=>$added_calc_val_new,
			'new_purchase_price'=>$t->temp_p_purchase_price,
			'old_purchase_price'=>$t->p_purchase_price,
			'webprice_aed_old'=>$webprice_aed_old,
		    'webprice_GBP_old'=>$webprice_GBP_old,
		    'webprice_aed_new'=>$webprice_aed_new,
		    'webprice_GBP_new'=>$webprice_GBP_new,

			);



	 	
	
	}
	//print_r('sdf');exit();

	 $this->load->view('admin/production/product_show_details_uk',$dataresult2);

 }
		   else {

		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}





	 }
}





function product_purchase_extra($pid)
{
if(logged_in())
	{


	$data['products_extra']=$this->tm->get_data('products',array('pid'=>$pid));

	
    $data['countrys']=$this->tm->get_data('country_val',array('status'=>'1'));

          $vendors = array();
            $data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'245'));
            

            foreach($data['customers'] as $vendor_list)
            {


                $result = array();


                $child[] = $this->getChild($vendor_list->id);
             
                $result[]= array_merge($data['customers'], $child);
                
            }





           
            $vendors = $this->nestedToSingle($result[0]);
            // $customers_list =$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'638'));
            // $merge_customer_vendor = array_merge($vendors,$customers_list);
            // print_r($merge);
            // exit(0);
           
$data['suppliers']=$vendors;

 $data['newsupplier']=$this->Admin_model->get_data('import_supplier_tree',array('id !='=>'0'));


// print_r( $data);exit();

		$this->load->view('admin/production/product_purchase_extra',$data);

	}
}


function submit_prd_purchase_pricing()
{
if(logged_in())
	{
 

// 	// $this->Admin_model->insert_data('prd_grps_pricing',array('gc_grp_main_id'=>$this->input->post('main_grp_id'),'gc_grp_sub_name'=>$this->input->post('add_sub_prd_name'),'gc_sts'=>'1'));
 $main_code=$this->input->post('prd_code');
//     $main_prd_id=$this->input->post('main_prd_id');
$last_suppliers=$this->input->post('suppliers');
$new_last_supplier=$this->input->post('newsuppliers');

 
// print_r($last_suppliers);
// print_r($new_last_supplier);
// exit(0);

if(!empty($new_last_supplier))
{

$last_supplier=$new_last_supplier;

	
}
else
{
	$last_supplier=$last_suppliers;


}

$datadashboard=array(
			'p_pack_width'=>$this->input->post('edit_prd_width'),
			'p_pack_hgt'=>$this->input->post('edit_prd_height'),
			'p_pack_lgth'=>$this->input->post('edit_prd_length'),
			'p_wgt'=>$this->input->post('edit_prd_weight'),
			'p_country'=>$this->input->post('countries'),
			'p_last_supplier'=>$last_supplier,
			'temp_p_purchase_price'=>$this->input->post('edit_prd_purchase'),

			);




$res=$this->tm->update_data('products',$datadashboard,array('pcode'=>$main_code));






// 	$data=array(
// 			'temp_p_purchase_price'=>$this->input->post('edit_prd_purchase'),
			
// 			);

// 	$skures=$this->ukdb->update_data('products',$data,array('pcode'=>$main_code));
// print_r($skures);exit();
	$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'Product details&Purchase price',
				'act_status'=>'product in Uk code ('.$main_code.')  changed in some dimention details and (purchase price wait approve)',
				
			     'act_doc_num'=>$main_code,
				'act_type'=>'Product details&Purchase price ',
				
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()
			);
			   $this->Admin_model->insert_data('activities',$activity_data); 



      
	
 		$this->session->set_flashdata('success', 'Details Edit Successfully (Wait Approve For Purchase price) ');
		// print_r('here');exit();

		 
 		redirect('list-product-costing-details');
 	}
}











/////for make approval for manager 


function product_purchase_approve($pid)
{
if(logged_in())
	{

$products_purchace_approve=$this->tm->get_data('products',array('pid'=>$pid));

 $main_code=$products_purchace_approve[0]->pcode;
$new_purchcase_price=$products_purchace_approve[0]->temp_p_purchase_price;
$reset_temp='0';


$datadashboard=array(
		    'p_purchase_price'=>$new_purchcase_price,
			'temp_p_purchase_price'=>$reset_temp,
			'purchase_date'=>get_date(),

			);

	$this->tm->update_data('products',$datadashboard,array('pcode'=>$main_code));

	$data=array(
		    'purchase_price'=>$new_purchcase_price,
			'temp_purchaseprice'=>$reset_temp,
			'purchase_date'=>get_date(),
			
			);

	$this->ukdb->update_data('products',$data,array('sku'=>$main_code));

	$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'purchase Price Approve',
				'act_status'=>'product in Uk code ('.$main_code.')  purchase price approved',
			     'act_doc_num'=>$main_code,
				'act_type'=>'Purchase price Approve',
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()
			);
			   $this->Admin_model->insert_data('activities',$activity_data); 


	
 		$this->session->set_flashdata('success', 'Details Approved Successfully ');
 		redirect('list-product-costing-details');
 	}
}



/////for Reject for manager 


function product_purchase_decline($pid)
{
if(logged_in())
	{

$products_purchace_approve=$this->tm->get_data('products',array('pid'=>$pid));

 $main_code=$products_purchace_approve[0]->pcode;
$temp_purchcase_price='0';
$purchcase_price=$products_purchace_approve[0]->p_purchase_price;


$datadashboard=array(
		    'p_purchase_price'=>$purchcase_price,
			'temp_p_purchase_price'=>$temp_purchcase_price,

			);

	$this->tm->update_data('products',$datadashboard,array('pcode'=>$main_code));

	$data=array(
		    'purchase_price'=>$purchcase_price,
			'temp_purchaseprice'=>$temp_purchcase_price,
			
			);

	$this->ukdb->update_data('products',$data,array('sku'=>$main_code));



$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'purchase Price Rejected',
				'act_status'=>'product in Uk code ('.$main_code.')  purchase price Rejected',
				
			     'act_doc_num'=>$main_code,
				'act_type'=>'Purchase price Rejected',
				
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()
			);
			   $this->Admin_model->insert_data('activities',$activity_data); 



	
 		$this->session->set_flashdata('success', 'Details Rejected');
 		redirect('list-product-costing-details');
 	}
}





///////new pricing Amazon UK 
function pricing_amazon_uk()
{
	if(logged_in())
	{


 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='list-Amazon-price-uk')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {
			
   //$ip = gethostbyname('gcam1231.siteground.biz');
    //$ip = gethostbyname('us183.siteground.us');
	//$data['result']=$this->Admin_model->get_data('prd_grps_pricing',array('gc_grp_main_id'=>'','gc_sts'=>'1'));
  //print_r($ip);exit();
   	$data['products_list']=$this->ukdb->get_data('products',array('published'=>'1'));
	   
	 
    $currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>'4'));
	 
    $currencyval=$currency[0]->currency_val;




   	//print_r($currencyval);exit(0);


	 foreach($data['products_list'] as $index=>$t)
	 {

            $purchase_price=$t->purchase_price;
            $shipping_val_perce=$t->shipping_val_perce;
            $added_val_perce=$t->added_val_perce;

            $shipping_calc_val=(($t->purchase_price)*($t->shipping_val_perce/100));
            $added_calc_val=(($t->purchase_price)*($t->added_val_perce/100));

            $webprice_aed=($purchase_price+$shipping_calc_val+$added_calc_val);
            $webprice_GBP=number_format((float)($webprice_aed/$currencyval),2,'.','');
            $vat_price=($webprice_GBP*0.20);

            $Amazon_fba=$webprice_GBP+$vat_price+($t->fba_fees);
            $Amazon_fbm=($webprice_GBP+$vat_price+($t->fbm_fees)+($t->our_shipping)-(($t->amazon_shipping)));

          $dataresult['test'][$index]=array(
			'id'=>$t->id,
			'thumbnail_img'=>$t->thumbnail_img,
			'name'=>$t->name,
			'sku'=>$t->sku,
			'webprice_GBP'=>$webprice_GBP,
            'Amazon_fba'=>$Amazon_fba,
			'Amazon_fbm'=>$Amazon_fbm,
			'fba_fees'=>$t->fba_fees,
             'fbm_fees'=>$t->fbm_fees,
             'amazon_shipping'=>$t->amazon_shipping,
             'our_shipping'=>$t->our_shipping,
			);



	 	
	}


	 $this->load->view('admin/production/create_amazon_pricing',$dataresult);

 }
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}





	 }
}



//////for moda fba 
function submit_fba_fees_uk()
{
if(logged_in())
	{
	// $this->Admin_model->insert_data('prd_grps_pricing',array('gc_grp_main_id'=>$this->input->post('main_grp_id'),'gc_grp_sub_name'=>$this->input->post('add_sub_prd_name'),'gc_sts'=>'1'));
    $main_code=$this->input->post('main_prd_code');
    $main_prd_id=$this->input->post('main_prd_id');




	$datafba=$this->ukdb->get_data('products',array('sku'=>$main_code));
    $currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>'4'));
$currencyval=$currency[0]->currency_val;




            $purchase_price=$datafba[0]->purchase_price;
            $shipping_val_perce=$datafba[0]->shipping_val_perce;
            $added_val_perce=$datafba[0]->added_val_perce;

            $shipping_calc_val=(($datafba[0]->purchase_price)*($datafba[0]->shipping_val_perce/100));
            $added_calc_val=(($datafba[0]->purchase_price)*($datafba[0]->added_val_perce/100));

            $webprice_aed=($purchase_price+$shipping_calc_val+$added_calc_val);
            $webprice_GBP=number_format((float)($webprice_aed/$currencyval),2,'.','');
            $vat_price=($webprice_GBP*0.20);

           $newfba_fee=$this->input->post('fba_fees_amazon');

            $Amazon_fba= $webprice_GBP+$vat_price+$newfba_fee;


           // $Amazon_fbm=($vat_price+($datafba[0]->fbm_fees)-(($datafba[0]->amazon_shipping)+($datafba[0]->our_shipping)));


$datadashboard=array(
			'fba_amazon'=>$Amazon_fba,
			'fba_fees'=>$newfba_fee,

			);

	$this->tm->update_data('products',$datadashboard,array('pcode'=>$main_code));






	$data=array(
			'fba_amazon'=>$Amazon_fba,
			'fba_fees'=>$newfba_fee,
			);

	$this->ukdb->update_data('products',$data,array('sku'=>$main_code));



$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'FBA Details',
				'act_status'=>'product in Uk code ('.$main_code.')  FBA Fee Changed',
				
			    'act_doc_num'=>$main_code,
				'act_type'=>'FBA changed',
				
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()
			);
			   $this->Admin_model->insert_data('activities',$activity_data); 
	
 		$this->session->set_flashdata('success', 'New FBA Fee added successfully ');
 		redirect('list-price-amazon-uk');
 	}
}


/////end of fba 



//// for modal fbm///////
function submit_fbm_fees_uk()
{
if(logged_in())
	{
	// $this->Admin_model->insert_data('prd_grps_pricing',array('gc_grp_main_id'=>$this->input->post('main_grp_id'),'gc_grp_sub_name'=>$this->input->post('add_sub_prd_name'),'gc_sts'=>'1'));
    $main_code=$this->input->post('main_prd_code');
    $main_prd_id=$this->input->post('main_prd_id');



    $datafbm=$this->ukdb->get_data('products',array('sku'=>$main_code));
    $currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>'4'));
    $currencyval=$currency[0]->currency_val;




            $purchase_price=$datafbm[0]->purchase_price;
            $shipping_val_perce=$datafbm[0]->shipping_val_perce;
            $added_val_perce=$datafbm[0]->added_val_perce;

            $shipping_calc_val=(($datafbm[0]->purchase_price)*($datafbm[0]->shipping_val_perce/100));
            $added_calc_val=(($datafbm[0]->purchase_price)*($datafbm[0]->added_val_perce/100));

            $webprice_aed=($purchase_price+$shipping_calc_val+$added_calc_val);
            $webprice_GBP=number_format((float)($webprice_aed/$currencyval),2,'.','');
            $vat_price=($webprice_GBP*0.20);

           $newfbm_fee=$this->input->post('fbm_fees_amazon');
           $newamazon_shipping=$this->input->post('shipping_amazon');
           $new_our_shipping=$this->input->post('shipping_our');
           // $Amazon_fba=$vat_price+$newfba_fee;


         $Amazon_fbm=($webprice_GBP+$vat_price+$newfbm_fee+$new_our_shipping-($newamazon_shipping));


$datadashboard=array(
			'fba_amazon'=>$Amazon_fba,
			'fba_fees'=>$newfba_fee,

			);

	$this->tm->update_data('products',$datadashboard,array('pcode'=>$main_code));






	$data=array(
			'fbm_amazon'=>$Amazon_fbm,
			'fbm_fees'=>$newfbm_fee,
			'our_shipping'=>$new_our_shipping,
			'amazon_shipping'=>$newamazon_shipping,

			);

	$this->ukdb->update_data('products',$data,array('sku'=>$main_code));



	$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'FBm Details',
				'act_status'=>'product in Uk code ('.$main_code.')  FBM details Changed',
				
			    'act_doc_num'=>$main_code,
				'act_type'=>'FBM changed',
				
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()
			);
			   $this->Admin_model->insert_data('activities',$activity_data); 

	
 		$this->session->set_flashdata('success', 'FBM details Added successfully ');
 		redirect('list-price-amazon-uk');
 	}
}

////end of fbm submit////







/////for adding country and supplier if its not exist



function credinals()
{
	$name=$this->input->post('name');
	$val=$this->input->post('val');
	$type=$this->input->post('type');
// print_r($name);
// //print_r($val);
// print_r($type);
// exit(0);
	
	if($type=="supp_form")
	{

		
		$data=array(
		    'label'=>$name,
			'parent'=>'852',
			'link'=>'#',
	);
		$insert_id=$this->Admin_model->insert_data('import_supplier_tree',$data);
			$list = array();
        $list[] = array(
            'id'   => $insert_id,
            'name' => $name,
        );
    	 echo json_encode($list);

		// $list = array();
  //       $list[] = array(
  //           'id'   => $insert_id,
  //           'name_en' => $hse_name[0],
  //           'name_ar'=>$hse_name[1],
  //           'code'=>$val,
  //       );
    
    //	 echo json_encode($list);
	}
	else
	{
		echo false;
	}

}

function country_code_val()
{
if(logged_in())
		{
	$country_id=$this->input->post('country_id');
	

	$cond=array('country_id'=>$country_id);
	$cat_result=$this->tm->get_data('country_val',$cond);
	$code_value=$cat_result[0]->country_id;

	if(!empty($code_value))
	{
	  	echo $code_value;
	}
	else{
		echo "";
	}
  }
}

   function getChild($id)
    {
        $child = $this->Admin_model->get_data('master_accounts_tree',array('parent'=>$id));
        
        return $child;
    }

    function nestedToSingle(array $array)
    {
        $singleDimArray = [];

        foreach ($array as $item) {

            if (is_array($item)) {
                $singleDimArray = array_merge($singleDimArray, $this->nestedToSingle($item));

            } else {
                $singleDimArray[] = $item;
            }
        }

        return $singleDimArray;
    }
 







}