<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ledger2 extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
		$this->load->library('numbertowordconvertsconver');	
	}


function sub_ledger()
{
	if(logged_in())
	{
		$data['acc']=$this->Admin_model->get_data('master_accounts_tree');
	$this->load->view('admin/financial_accounting/sub_ledger',$data);
	}
}

function submit_sub_ledger_org()
{
	if(logged_in())
	{
		$start_date=$this->input->post('start_date');
$start_date1=explode('/',$start_date);
			$month1=$start_date1[0];
			$date1=$start_date1[1];
			$year1=$start_date1[2];
$new_formated_date1=$year1.'-'.$month1.'-'.$date1;

$end_date=$this->input->post('end_date');
$end_date1=explode('/',$end_date);
			$month2=$end_date1[0];
			$date2=$end_date1[1];
			$year2=$end_date1[2];
$new_formated_date2=$year2.'-'.$month2.'-'.$date2;

//echo $new_formated_date1;
		$data['form_input']=array(
			'acc_master_id'=>$this->input->post('acc_master_id'),
			'start_date'=>$this->input->post('start_date'),
			'end_date'=>$this->input->post('end_date'),
			'type'=>$this->input->post('type'),
			's_type'=>$this->input->post('s_type'),
		);
//pre_list($data);
		$type_transfer='';
		if($this->input->post('type')!='all')
		{
			if($this->input->post('type')=="credit")
			{
				$type_transfer='Income';
			}
			else
			{
				$type_transfer='Expense';
			}
		}

		if($this->input->post('type')=='all')
		{
		//	echo "in alll";echo"<br/>";echo $new_formated_date1;echo"<br/>";echo $this->input->post('acc_master_id');echo"<br/>";
$sql2=$this->db->query("
 SELECT 
  ( 
     CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)  
 WHEN mat.atx_type_tx='Sales_Return' THEN  mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)  
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0) )
ELSE
    mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)  
 END
   ) 
   as atx_tot_amount,mat.atx_date, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,mat.atx_id ,
    mat.atx_vat_amount , mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
 WHERE mat.atx_sts = '1' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."'  order by mat.atx_date ASC");
	$result=$sql2->result_array();
	
	//pre_list($data['result']);

	if(  ($this->input->post('acc_master_id') !='1014') && ($this->input->post('acc_master_id')!='1013') 
	&& ($this->input->post('acc_master_id')!='1016') && ($this->input->post('acc_master_id')!='759') )
	{
	//	echo "in if-without vat  a/c as master a/c"; echo "<br/>";
	$old_sql_income1=$this->db->query("
  SELECT 
  ( 
     CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN 
     sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0)     
 WHEN mat.atx_type_tx='Sales_Return' THEN (sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0))    
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',sum(mat.atx_tot_amount),sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0))
ELSE sum(mat.atx_tot_amount)+COALESCE(sum(mat.atx_vat_amount),0)     
 END
   ) 
   as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' 
  and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'
   order by mat.atx_date ASC");

	//print_r("SELECT IF(mat.atx_type_tx='Sales_Invoice',sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0) , (sum(mat.atx_tot_amount) + 
  //COALESCE(sum(mat.atx_vat_amount),0) ) ) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' 
  //and mat.atx_amount_type='Income' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");echo"<br/>";
	$income1=$old_sql_income1->result_array();
  //print_r(	$income1);

		//print_r($income1);echo"<br/>";
	$old_sql_exp1=$this->db->query("
  SELECT 
  ( 
     CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN (sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0) )   
 WHEN mat.atx_type_tx='Sales_Return' THEN (sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0))     
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',sum(mat.atx_tot_amount),sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0))
ELSE (sum(mat.atx_tot_amount)+COALESCE(sum(mat.atx_vat_amount),0))      
 END
   ) 
    as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
	//print_r("SELECT IF(mat.atx_type_tx='Sales_Invoice',sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0) , (sum(mat.atx_tot_amount) + COALESCE(sum(mat.atx_vat_amount),0)) )
  // as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
	//echo"<br/>";
	$exp1=$old_sql_exp1->result_array();
  //print_r(	$exp1);
	//print_r($exp1);echo"<br/>";
	$data['old_result']=$exp1[0]['tot_old_exp']-$income1[0]['tot_old_income'];
  //print_r($data['old_result']);
	}
	else
	{
		//echo "in else-with vvat  a/c as master a/c"; echo "<br/>";
		$old_sql_income1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount),0) 
			 as tot_old_income FROM account_all_tx as mat 
		WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
		//print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");echo"<br/>";
		$income1=$old_sql_income1->result_array();

		//	print_r($income1);echo"<br/>";
		$old_sql_exp1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount,0)) as tot_old_exp FROM account_all_tx as mat 
		WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
		//print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
		//echo"<br/>";
		$exp1=$old_sql_exp1->result_array();
		//print_r($exp1);echo"<br/>";
		$data['old_result']=$exp1[0]['tot_old_exp']-$income1[0]['tot_old_income'];
	}
	//print_r($data['old_result']);
		if(empty($result))
		{
			//echo "in alll-in if";echo"<br/>";
			$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)    
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)   
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0) )
-- ELSE
--    mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)  
--  END
--    ) 
--    as atx_tot_amount,
  mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='759' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
	$result=$sql2->result_array();

			if(empty($data['old_result']))
			{
    //  echo "in alll-in if-old result";echo"<br/>";
	if( ($this->input->post('acc_master_id') !='1014') && ($this->input->post('acc_master_id')!='1013') 
	&& ($this->input->post('acc_master_id')!='1016') && ($this->input->post('acc_master_id')!='759') )
				{
				$old_sql_income1=$this->db->query("
       SELECT mat.atx_tot_amount as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income'
		 and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
			//	print_r("SELECT sum(mat.atx_tot_amount) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo"<br/>";
				$income1=$old_sql_income1->result_array();
			
				$old_sql_exp1=$this->db->query("
        SELECT mat.atx_tot_amount as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
			//	print_r("SELECT sum(mat.atx_tot_amount) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo "<br/>";
				$exp1=$old_sql_exp1->result_array();

				$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
			//print_r($data['old_result']);
				}
				else
				{
          //  echo "in alll-in else-old result";echo"<br/>";
					$old_sql_income1=$this->db->query("SELECT mat.atx_tot_amount as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
				//  print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo"<br/>";
					$income1=$old_sql_income1->result_array();
				
					$old_sql_exp1=$this->db->query("SELECT mat.atx_tot_amount as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
				//	print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo "<br/>";
					$exp1=$old_sql_exp1->result_array();

					$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
				//print_r($data['old_result']);
				}
			}
		}
		else
		{
			//	echo "in alll-in else";echo"<br/>";
				$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)     
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)  
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0) )
-- ELSE
--     mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)   
--  END
--    ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id , mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount 
    mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
			FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' 
			and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' or mat.atx_acc_id='".$this->input->post('acc_master_id')."' 
			and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
			$result=$sql2->result_array();

		//	print_r($result);

			if(empty($data['old_result']))
			{
   //   echo "in alll-in else-in if-old result";echo"<br/>";
				if(  ($this->input->post('acc_master_id') !='1014') && ($this->input->post('acc_master_id')!='1013') 
				&& ($this->input->post('acc_master_id')!='1016') && ($this->input->post('acc_master_id')!='759') )
				{
				$old_sql_income1=$this->db->query(" SELECT
	 COALESCE(sum(mat.atx_tot_amount),0)  as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and
		  mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'
		   or mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
				//print_r("SELECT sum(mat.atx_tot_amount) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo"<br/>";
				$income1=$old_sql_income1->result_array();
			
				$old_sql_exp1=$this->db->query("
        SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and
		  mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and
		   mat.atx_date < '".$new_formated_date1."' 
		  or mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'
		  order by mat.atx_date ASC");
				//print_r("SELECT sum(mat.atx_tot_amount) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo "<br/>";
				$exp1=$old_sql_exp1->result_array();

				$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
			//print_r($data['old_result']);
				}
				else
				{
         //  echo "in alll-in else-in else- old result";echo"<br/>";
					$old_sql_income1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' or mat.atx_acc_id='".$this->input->post('acc_master_id')."'
					    and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'
					   order by mat.atx_date ASC");
				//  print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo"<br/>";
					$income1=$old_sql_income1->result_array();
				
					$old_sql_exp1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount),0)  as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  
					 and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' or mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'
					  order by mat.atx_date ASC");
				//	print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo "<br/>";
					$exp1=$old_sql_exp1->result_array();

					$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
				//print_r($data['old_result']);
				}
			}

			// print_r("SELECT mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
			// FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
			// WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' 
			// and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' or mat.atx_acc_id='".$this->input->post('acc_master_id')."' 
			// and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");echo"<br/>";
		}
		$data['result']=$result;
	}
	else
	{
	//	echo "in type";echo"<br/>";
		$sql2=$this->db->query("
	SELECT 
  ( 
     CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN  mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)   
 WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)   
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0) )
ELSE
   mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)  
    
 END
   ) 
   as atx_tot_amount,mat.atx_date, mat.atx_id,mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
    mat.atx_vat_amount ,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' 
and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
	$result=$sql2->result_array();

	$old_sql_income1=$this->db->query("
  SELECT 
  ( 
   CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN
   sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0)   
 WHEN mat.atx_type_tx='Sales_Return' THEN  sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0)
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',sum(mat.atx_tot_amount),sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0))
ELSE
   sum(mat.atx_tot_amount)+COALESCE(sum(mat.atx_vat_amount),0) 
 END
   )  
  as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
	$income1=$old_sql_income1->result_array();
	
	$old_sql_exp1=$this->db->query("
  SELECT 
  ( 
    CASE 
    WHEN mat.atx_type_tx='Sales_Invoice' THEN sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0)  
 WHEN mat.atx_type_tx='Sales_Return' THEN sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0)
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',sum(mat.atx_tot_amount),sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0) )
ELSE
   sum(mat.atx_tot_amount)+COALESCE(sum(mat.atx_vat_amount),0)  
    
 END
   ) 
   as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
	$exp1=$old_sql_exp1->result_array();
	$data['old_result']=$exp1[0]['tot_old_exp']-$income1[0]['tot_old_income'];

		if(empty($result))
		{
		//	echo "in type-in if";echo"<br/>";
			if($this->input->post('type')=="credit")
			{
			//	echo "in type credit-in if";echo"<br/>";
				$type_transfer='Expense';
					$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)
--  WHEN mat.atx_tranfer_type='journal' THEN 
--  if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0) )
-- ELSE mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0) 
--  END
--    ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount 
    mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' 
and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
				if(empty($data['old_result']))
				{
					$old_sql_income1=$this->db->query("SELECT sum(mat.atx_tot_amount) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' 
					and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
					$income1=$old_sql_income1->result_array();
				
					$old_sql_exp1=$this->db->query("SELECT sum(mat.atx_tot_amount) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' 
					and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
					$exp1=$old_sql_exp1->result_array();
					$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
				}
			}
			else
			{
				//echo "in type debit-in if";echo"<br/>";
				$type_transfer='Income';
	$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)
--  WHEN mat.atx_type_tx='Sales_Return' THEN  mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)
--  WHEN mat.atx_tranfer_type='journal' THEN 
--  if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0))
-- ELSE mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)  
--  END
--    ) 
--    as atx_tot_amount  ,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
    -- mat.atx_vat_amount ,
    mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014'
 and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");

				if(empty($data['old_result']))
				{
					$old_sql_income1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and 
					mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
					$income1=$old_sql_income1->result_array();
				
					$old_sql_exp1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount),0)  as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and
					 mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
					$exp1=$old_sql_exp1->result_array();
				}
			}
			$result=$sql2->result_array();
			$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
		}
		else
		{
			//	echo "in type-in else";echo"<br/>";
			if($this->input->post('type')=="credit")
			{
				$type_transfer='Expense';
				$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)  
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0) )
-- ELSE mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)  
--  END
--  ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount ,
     mat.*, mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
					FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
					WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' 
					and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and 
					mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' or mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' 
					and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' 
					order by mat.atx_date ASC");
			}
			else
			{
				$type_transfer='Income';
				$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)   
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)  
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0) )
-- ELSE mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)   
--  END
--    ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount ,
  mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
				FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
				WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759'
				and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."'
				 or mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' 
				and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
			}
			$result=$sql2->result_array();
		}
		$data['result']=$result;
	}
///////////////////start of pdp or pdr based reporting ////////////////////////////////////////////////////////////////////

		if($this->input->post('type')=='all')
		{
$sql21=$this->db->query("
SELECT 
  ( 
     CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)
 WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0))
ELSE
	mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)   
    
 END
   ) 
   as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
    mat.atx_vat_amount ,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx='PDR' or mat.atx_type_tx='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
	$data['result2']=$sql21->result_array();

		if(empty($data['result2']))
		{
			$sql21=$this->db->query(" SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)  
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount)
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0) )
-- ELSE mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)   
--  END
--    ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount ,
      mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx='PDR' or mat.atx_type_tx='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
	$data['result2']=$sql21->result_array();

		}
	}
	else
	{
		$sql21=$this->db->query(" SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount)
--  WHEN mat.atx_type_tx='Sales_Return' THEN  mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',sum(mat.atx_tot_amount),sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0))
-- ELSE
--   mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)    
--  END
--    ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount ,
    mat.*, mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_type_tx='PDR' or mat.atx_type_tx='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
	$data['result2']=$sql21->result_array();

		if(empty($data['result2']))
		{
			if($this->input->post('type')=="credit")
			{
				$type_transfer='Expense';
					$sql21=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)     
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)     
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0))
-- ELSE
--    mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)      
--  END
--    ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount ,
      mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx='PDR' or mat.atx_type_tx='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
			}
			else
			{
					$type_transfer='Income';
	$sql21=$this->db->query("SELECT 
--   ( 
--  CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN  mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)    
--  WHEN mat.atx_type_tx='Sales_Return' THEN  mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0)  
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount,mat.atx_tot_amount-COALESCE(mat.atx_vat_amount,0))
-- ELSE mat.atx_tot_amount+COALESCE(mat.atx_vat_amount,0)    
--  END
--    ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount ,
      mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx='PDR' or mat.atx_type_tx='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
			}
			$data['result2']=$sql21->result_array();
		}
	}
$data['account_name']=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$this->input->post('acc_master_id')));
$data['acc']=$this->Admin_model->get_data('master_accounts_tree');

	//pre_list($data['old_result']);
//print_r($sql2); 
	//pre_list($data['result']);
	$this->load->view('admin/financial_accounting/sub_ledger_org',$data);
	}
}
























































































}