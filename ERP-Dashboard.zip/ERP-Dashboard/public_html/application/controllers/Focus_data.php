<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Focus_data extends CI_Controller {

public function __construct() {
	parent::__construct();
	$this->load->model(array('Four_db_model'=>'fm'));
	$this->load->model('Third_db_model','tm');
	$connectionInfo = array('Database'=>'Focus5020','UID'=>'sa','PWD'=>'focus123');
	$this->connection = sqlsrv_connect('SERVER\SQLEXPRESS',$connectionInfo);

	if( $this->connection === false ) {
		die( print_r( sqlsrv_errors(), true));
	}
		else
	{}

}



function pending_invoice()
{
	

$cat_names=array();
$qry_result1=$this->fm->get_data();
foreach ($qry_result1 as $key1 => $value1) {

	if(($value1->ClassYH=='') || ($value1->ClassYH=="NULL"))
		$cat_names[]='NULL Cat';


	if(empty($cat_names))
	{
		$cat_names[]=$value1->ClassYH;
	}
	else
	{

		if(!in_array($value1->ClassYH, $cat_names))
		{
			$cat_names[]=$value1->ClassYH;
		}

	}
}

$cat_list=array_unique($cat_names);

$qry_result2=$this->fm->get_data3();
foreach ($qry_result2 as $key1 => $v1) {

	$data[]=array(
		'prod_id_focus'=>$v1->masterid,
		'pname'=>$v1->Name.'|~~|'.$v1->Code,
		'pcode'=>$v1->Code2,
		'phse_code'=>$v1->HSCODEYH,
		'pcat'=>$v1->ClassYH,
		'p_wgt'=>$v1->WeightYH,
		'p_sts'=>'1',
	);
	//$this->tm->insert_data('products',$data);
}

// $data=array();
// $index_array=array();
$qryy=$this->tm->get_data('products',array('p_sts'=>'1','prod_id_focus >='=>'2420'));
//$qryy=$this->tm->get_data('products',array('p_sts'=>'1'));
echo "<pre>";
print_r($data);
echo "</pre>";
foreach($qryy as $key=>$t)
{
	$qry_result=$this->fm->get_data33(array('c.prod'=>$t->prod_id_focus));
	foreach($qry_result as $key2=>$t2)
	{
		if($t->prod_id_focus==$t2->prod)
		{
			if($t2->pty=='1')
			{
				$data=array('p_uae_final'=>$t2->vals0);
			}
			elseif($t2->pty=='2')
			{
				$data=array('p_uae_l1'=>$t2->vals0);
			}
			elseif($t2->pty=='3')
			{
				$data=array('p_uae_l2'=>$t2->vals0);
			}
			elseif($t2->pty=='4')
			{
				$data=array('p_ksa'=>$t2->vals0);
			}
			elseif($t2->pty=='5')
			{
				$data=array('p_ksa_reg_1'=>$t2->vals0);
			}
			elseif($t2->pty=='6')
			{
				$data=array('p_ksa_comp_2'=>$t2->vals0);
			}
			elseif($t2->pty=='7')
			{
				$data=array('p_ksa_retail_3'=>$t2->vals0);
			}
			else{}
		}	

	//$this->tm->update_data('products',$data,array('prod_id_focus'=>$t->prod_id_focus));
	}

}


$qryy2=$this->fm->get_data();
foreach($qryy2 as $k2=>$v2)
{
	if($v2->L2=='13')
	{
		$loc_name='KSA';
	}
	else
	{
		$loc_name='UAE';
	}
	$data=array(
		'w_main_loc'=>$loc_name,
		'w_type'=>$v2->L2,
		'w_name'=>$v2->Name,
		'w_sts'=>'1',
	);
//	$this->tm->insert_data('warehouse_data',$data);
}

// foreach($new_array as $key2=>$v2)
// {
// 	echo $key2;
// 	echo "<br/>";
// 	foreach ($v2 as $key3 => $v3) 
// 	{
		
// 		 echo "<pre>";
//  print_r($v3);
//  echo "</pre>";
// 	}
	
// }





	$sql = "select a.Name Customer,d.VoucherNo,d.tags5, dbo.convertfocusdatedisplay( d.date_) as date_converted,p.* from pendingrefs p
	inner join data d on d.BillWiseOff=p.RefId
	inner join mr000 a on p.code=a.masterid 
	";
	$stmt = sqlsrv_query( $this->connection, $sql );
	if( $stmt === false) {
	    die( print_r( sqlsrv_errors(), true) );
	}

	while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) 
	{
		$data['result'][]=$row;
	}

	foreach($data['result'] as $indx=>$rs)
	{
		$data2=$this->fm->get_data_main('header',array('VoucherNo'=>$rs['VoucherNo']));

		// echo"<pre>";
		// print_r($data2);
		// echo"</pre>";
	}
	// echo "<pre>";
	// print_r($data['result']);
	// echo "</pre>";
//$this->load->view('admin/focus_data/invoice_pending',$data);
}











}