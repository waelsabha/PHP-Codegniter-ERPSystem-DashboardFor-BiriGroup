// <?php

// /* * ***
//  * Version: 1.0.0
//  *
//  * Description of Google Calendar Controller
//  *
//  * @author TechArise Team
//  *
//  * @email  info@techarise.com
//  *
//  * *** */
// if (!defined('BASEPATH'))
//     exit('No direct script access allowed');

// class GoogleCalendar extends CI_Controller {

//     public function __construct() {
//         parent::__construct();
//         //load library  
//         $this->load->library('googleapi');
//            $this->load->helper(array('session','email','img','gnrl'));	
//         $this->calendarapi = new Google_Service_Calendar($this->googleapi->client());
// 			$this->load->library('encryption');
// 			$this->load->library('Geolocation');
// 			$this->load->library('googleapi');
// 		    $this->load->config('geolocation', true);
		   

//     }

//     public function index() { 



//     if(logged_in())
//     {
     
//   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);

// $username=$this->session->userdata['user']['username'];
// $passworduser=$this->session->userdata['user']['password'];
// // print_r($username);
// // print_r($passworduser);
// // exit(0);
  
//       $cred_count=count($page_cred);


//          for($i=0;$i<$cred_count;$i++)
//          {
//           if ((($page_cred[$i]=='create-receipt')||($this ->session->userdata['user']['main_dept'])=="Main"))
//           {
//             $excist=true;
//                $i=$cred_count;
//           } 

//             else
//               {$excist=false;}

//          }
//        if ($excist) {

//         if (!$this->isLogin()) {

        
//             $this->session->sess_destroy();    
//             redirect('gc/auth/login');
//         } else {
//             $data = array();
//             $data['metaDescription'] = 'Google Calendar';
//             $data['metaKeywords'] = 'Google Calendar';
//             $data['title'] = "Google Calendar - BiriGroup";
//             $data['breadcrumbs'] = array('Google Calendar' => '#');

//             $this->load->view('google-calendar/index', $data);
//         }
//        }
//     }
//     }
//     // index method
//     public function getCalendar() { 
//         if (!$this->isLogin()) {
//             $this->session->sess_destroy();    
//             redirect('gc/auth/login');
//         } else {     
//             $data = array();
//             $curentDate = date('Y-m-d', time());
//             if ($this->input->post('page') !== null) {
//                 $malestr = str_replace("?", "", $this->input->post('page'));
//                 $navigation = explode('/', $malestr);
//                 $getYear = $navigation[1];
//                 $getMonth = $navigation[2];
//                 $start = date($getYear.'-'.$getMonth.'-01').' 00:00:00';
//                 $end = date($getYear.'-'.$getMonth.'-t').' 23:59:59';
//             } else {
//                 $getYear = date('Y');
//                 $getMonth = date('m');
//                 $start = date('Y-m-01').' 00:00:00';
//                 $end = date('Y-m-t').' 23:59:59';
//             }
//             if ($this->input->post('year') !== null) {
//                 $getYear = $this->input->post('year');
//                 $start = date($getYear.'-m-01').' 00:00:00';
//                 echo $end = date($getYear.'-m-t').' 23:59:59';
//             }
//             if ($this->input->post('month') !== null) {
//                 $getMonth = $this->input->post('month');    
//                 $start = date($getYear.'-'.$getMonth.'-01').' 00:00:00';
//                 $end = date($getYear.'-'.$getMonth.'-t').' 23:59:59';
//             }

//             $already_selected_value = $getYear;
//             $earliest_year = 1950;
//             $startYear = '';
//             $googleEventArr = array();
//             $calendarData = array();

//             $eventData = $this->getEvents('primary', $start, $end, 40);    
            
//             foreach ($eventData as $element) {
//                 $googleEventArr[ltrim(date('d', strtotime($element['start_date'])), 0)] = '<a data-google_event="' . ltrim(date('Y-m-d', strtotime($element['start_date'])), 0) . '" href="#" data-caltoggle="tooltip" data-placement="bottom" title="Google Events" class="small google-event" data-toggle="modal" data-target="#google-cal-data"><i class="fa fa-fw fa-circle text-primary"></i></a>';            
//             }


//             foreach (array_keys($googleEventArr) as $key) {
//                 $calendarData[$key] =  '<div class="calendar-dot-area small" style="position: relative;z-index: 2;">' . (isset($googleEventArr[$key]) ? $googleEventArr[$key] : '')  . '</div>';
//             }
           
//             $class = 'href="#" data-currentdate="' . $curentDate . '" class="add-gc-event" data-toggle="modal" data-target="#gc-create-event" data-year="' . $getYear . '" data-month="' . $getMonth . '" data-days="{day}"';

//             $startYear .= '<div class="col-md-3 col-sm-5 col-xs-7 col-md-offset-3 col-sm-offset-1"><div class="select-control"><select name="year" id="setYearVal" class="form-control">';
//         foreach (range
//                 (date
//                         ('Y') + 50, $earliest_year) as $x) {
//             $startYear .= '<option value="' . $x . '"' . ($x == $already_selected_value ? ' selected="selected"' : '') . '>' . $x . '</option>';
//         }
//         $startYear .= '</select></div></div>';
//         $startMonth = '<div class="col-md-3 col-sm-5 col-xs-7 col-md-offset-3 col-sm-offset-1"><div class="select-control"><select name="mont h" id="setMonthVal" class="form-control"><option value="0">Select Month</option>
//             <option value="01" ' . ('01' == $getMonth ? ' selected="selected"' : '') . '>January</option>
//             <option value="02" ' . ('02' == $getMonth ? ' selected="selected"' : '') . '>February</option>
//             <option value="03" ' . ('03' == $getMonth ? ' selected="selected"' : '') . '>March</option>
//             <option value="04" ' . ('04' == $getMonth ? ' selected="selected"' : '') . '>April</option>
//             <option value="05" ' . ('05' == $getMonth ? ' selected="selected"' : '') . '>May</option>
//             <option value="06" ' . ('06' == $getMonth ? ' selected="selected"' : '') . '>June</option>
//             <option value="07" ' . ('07' == $getMonth ? ' selected="selected"' : '') . '>July</option>
//             <option value="08" ' . ('08' == $getMonth ? ' selected="selected"' : '') . '>August</option>
//             <option value="09" ' . ('09' == $getMonth ? ' selected="selected"' : '') . '>September</option>
//             <option value="10" ' . ('10' == $getMonth ? ' selected="selected"' : '') . '>October</option>
//             <option value="11" ' . ('11' == $getMonth ? ' selected="selected"' : '') . '>November</option>
//             <option value="12" ' . ('12' == $getMonth ? ' selected="selected"' : '') . '>December</option>
//     </select></div></div>';

//         //{heading_title_cell}<th colspan="{colspan}">'.$startMonth.'&nbsp;'.$startYear.'{heading}</th>{/heading_title_cell}      
//         $prefs['template'] = '
        

//         {table_open}<table border="0" width="100%" height="100%" cellpadding="0" cellspacing="0" class="calendar">{/table_open}

//         {heading_row_start}<tr style="border:none;">{/heading_row_start}

//         {heading_previous_cell}<th style="border:none;" class="padB"><a class="calnav" data-calvalue="{previous_url}" href="javascript:void(0);"><i class="fa fa-chevron-left fa-fw"></i></a></th>{/heading_previous_cell}
//         {heading_title_cell}<th style="border:none;" colspan="{colspan}"><div class="row">' . $startMonth . '' . $startYear . '</div></th>{/heading_title_cell}
//         {heading_next_cell}<th style="border:none;" class="padB"><a class="calnav" data-calvalue="{next_url}" href="javascript:void(0);"><i class="fa fa-chevron-right fa-fw"></i></a></th>{/heading_next_cell}

//         {heading_row_end}</tr>{/heading_row_end}

//         {week_row_start}<tr>{/week_row_start}
//         {week_day_cell}<th>{week_day}</th>{/week_day_cell}
//         {week_row_end}</tr>{/week_row_end}

//         {cal_row_start}<tr>{/cal_row_start}
//         {cal_cell_start}<td>{/cal_cell_start}
//         {cal_cell_start_today}<td>{/cal_cell_start_today}
//         {cal_cell_start_other}<td class="other-month">{/cal_cell_start_other}

//         {cal_cell_content}<a ' . $class . '>{day}</a>{content}{/cal_cell_content}
//         {cal_cell_content_today}<a ' . $class . '>{day}</a>{content}<div class="highlight"></div>{/cal_cell_content_today}

//         {cal_cell_no_content}<a ' . $class . '>{day}</a>{/cal_cell_no_content}
//         {cal_cell_no_content_today}<a ' . $class . '>{day}</a><div class="highlight"></div>{/cal_cell_no_content_today}

//         {cal_cell_blank}&nbsp;{/cal_cell_blank}

//         {cal_cell_other}{day}{/cal_cel_other}

//         {cal_cell_end}</td>{/cal_cell_end}
//         {cal_cell_end_today}</td>{/cal_cell_end_today}
//         {cal_cell_end_other}</td>{/cal_cell_end_other}
//         {cal_row_end}</tr>{/cal_row_end}

//         {table_close}</table>{/table_close}';
//         $prefs['start_day'] = 'monday';
//         $prefs['day_type'] = 'short';
//         $prefs['show_next_prev'] = TRUE;
//         $prefs['next_prev_url'] = '?';

//         $this->load->library('calendar', $prefs);
//         $data['calendar'] = $this->calendar->generate($getYear, $getMonth, $calendarData, $this->uri->segment(3), $this->uri->segment(4));
//         echo $data['calendar'];
//         }
//     }

//     // login method
//     public function login() { 
//       //       print_r($this->session->userdata);
//       //  exit(0);
//     if ($this->session->userdata('is_authenticate_user') == TRUE) {
//             redirect('gc/auth/index');
//         } else {
                    
//             $data = array();
//             $data['metaDescription'] = 'Google Plus Login';
//             $data['metaKeywords'] = 'Google Plus Login';
//             $data['title'] = "Google Plus Login - TechArise";
//             $data['breadcrumbs'] = array('Google Plus Login' => '#');
//             $data['loginUrl'] = $this->loginUrl();
//             $this->load->view('google-calendar/login', $data);
//         }
//     }

//     // oauth method
//     public function oauth() {

// //   $username=$this->session->userdata['user']['username'];
// // $passworduser=$this->session->userdata['user']['password'];
// // print_r($username);
// // exit(0);
//         $code = $this->input->get('code', true);
//         $this->oauthLogin($code);
       

// // print_r($code);
// // print_r( $this->oauthLogin($code));

//        //redirect('gc/auth/index','refresh');
//      redirect(base_url(), 'refresh');
//     }
//     // check login session
//     public function isLogin() {
//         // print_r($this->session->userdata('google_calendar_access_token'));
//         // exit(0);
//         $token = $this->session->userdata('google_calendar_access_token');
//         if ($token) {
//             $this->googleapi->client->setAccessToken($token);
//         }
//         if ($this->googleapi->isAccessTokenExpired()) {
//             return false;
//         }
//         return $token;
//     }

//     public function loginUrl() {
//         // print_r($this->googleapi->loginUrl());
//         // exit(0);
//         return $this->googleapi->loginUrl();
       
         
//         //redirect('gc/auth/index');
//     }
//     // oauthLogin
//     public function oauthLogin($code) {
//         $login = $this->googleapi->client->authenticate($code);
//         if ($login) {
//             $token = $this->googleapi->client->getAccessToken();
//             $this->session->set_userdata('google_calendar_access_token', $token);
//             $this->session->set_userdata('is_authenticate_user', TRUE);
//             return true;
//         }
//     }
//     // get User Info
//     public function getUserInfo() {
//         return $this->googleapi->getUser();
//     }
//     // get Events
//     public function getEvents($calendarId = 'primary', $timeMin = false, $timeMax = false, $maxResults = 10) {
//         if ( ! $timeMin) {
//             $timeMin = date("c", strtotime(date('Y-m-d ').' 00:00:00'));

//         } else {
//             $timeMin = date("c", strtotime($timeMin));
//         }

//         if ( ! $timeMax) {
//             $timeMax = date("c", strtotime(date('Y-m-d ').' 23:59:59'));
//         } else {  
//             $timeMax = date("c", strtotime($timeMax));

//         }
//         $optParams = array(
//             'maxResults'   => $maxResults,
//             'orderBy'      => 'startTime',
//             'singleEvents' => true,
//             'timeMin'      => $timeMin,
//             'timeMax'      => $timeMax,
//             'timeZone'     => 'Asia/Kolkata',
//         );

//         $results = $this->calendarapi->events->listEvents($calendarId, $optParams);
       
//         $data = array();
//         $creator = new Google_Service_Calendar_EventCreator();
//         foreach ($results->getItems() as $item) {

//             if(!empty($item->getStart()->date) && !empty($item->getEnd()->date)) {
//                 $startDate = date('d-m-Y H:i', strtotime($item->getStart()->date));
//                 $endDate = date('d-m-Y H:i', strtotime($item->getEnd()->date));
//             } else {
//                 $startDate = date('d-m-Y H:i', strtotime($item->getEnd()->dateTime));
//                 $endDate = date('d-m-Y H:i', strtotime($item->getEnd()->dateTime));
//             }
            
//             $created = date('d-m-Y H:i', strtotime($item->getCreated()));
//             $updated = date('d-m-Y H:i', strtotime($item->getUpdated()));
            
//             array_push(
//                 $data,
//                 array(
//                     'id'          => $item->getId(),
//                     'summary'     => trim($item->getSummary()),
//                     'description' => trim($item->getDescription()),
//                     'creator'     => $item->getCreator()->getEmail(),
//                     'organizer'     => $item->getOrganizer()->getEmail(),
//                     'creatorDisplayName'     => $item->getCreator()->getDisplayName(),
//                     'organizerDisplayName'     => $item->getOrganizer()->getDisplayName(),
//                     'created'         => $created,
//                     'updated'       => $updated,
//                     'start_date'       => $startDate,
//                     'end_date'         => $endDate,
//                     'status'          => $item->getStatus(),
//                 )
//             );
//         }
//         return $data;
//     }

//     // add google calendar event
//     public function addEvent() {
//         if (!$this->isLogin()) {
//             $this->session->sess_destroy();    
//             redirect(base_url(), 'refresh');
//         } else {
//             $json = array();
//             $calendarId = 'primary';
//             $post = $this->input->post();
//             if(empty(trim($post['summary']))){
//                 $json['error']['summary'] = 'Please enter summary';
//             }
//             // start date time validation
//             if(empty(trim($post['startDate'])) && empty($post['startTime'])){
//                 $json['error']['startdate'] = 'Please enter start date time';
//             }
//             if(empty(trim($post['endDate'])) && empty($post['endTime'])){
//                 $json['error']['enddate'] = 'Please enter end date time';
//             }
//             if(empty(trim($post['description']))){
//                 $json['error']['description'] = 'Please enter description';
//             }

//             if(empty($json['error'])){
//                 $event = array(
//                     'summary'     => $post['summary'],
//                     'start'       => $post['startDate'].'T'.$post['startTime'].':00+03:00',
//                     'end'         => $post['endDate'].'T'.$post['endTime'].':00+03:00',
//                     'description' => $post['description'],

//                 );
//                 $data = $this->actionEvent($calendarId, $event);
//                 if ($data->status == 'confirmed') {
//                     $json['message'] = 1;
//                 } else {
//                     $json['message'] = 0;
//                 }
//             }
//             $this->output->set_header('Content-Type: application/json');
//             echo json_encode($json);
//         }
        
//     }

//     // actionEvent
//     public function actionEvent($calendarId, $data) {
//         //Date Format: 2016-06-18T17:00:00+03:00
//         $event = new Google_Service_Calendar_Event(
//             array(
//                 'summary'     => $data['summary'],
//                 'description' => $data['description'],
//                 'start'       => array(
//                     'dateTime' => $data['start'],
//                     'timeZone' => 'Asia/Kolkata',
//                 ),
//                 'end'         => array(
//                     'dateTime' => $data['start'],
//                     'timeZone' => 'Asia/Kolkata',
//                 ),
//                 'attendees'   => array(
//                     array('email' => 'info@techarise.com'),
//                 ),
//             )
//         );
//         return $this->calendarapi->events->insert($calendarId, $event);
//     }

//     // get event list
//     public function viewEvent() {        
//         $json = array();
//         if (!$this->isLogin()) {
//             $this->session->sess_destroy();    
//             redirect(base_url(), 'refresh');
//         } else { 
//             $google_event_date = $this->input->post('google_event_date');
//             $start = date($google_event_date).' 00:00:00';
//             $end = date($google_event_date).' 23:59:59';
//             $eventData = $this->getEvents('primary', $start, $end, null);   
//             /*echo "<pre>";
//             print_r($eventData);die; */         
//             $json['eventData'] = $eventData;
//             $this->output->set_header('Content-Type: application/json');
//             $this->load->view('google-calendar/popup/render', $json);
//         }

//     }
//     // render Event Form
//     public function renderEventForm() {        
//         $json = array();
//         if (!$this->isLogin()) {
//             $this->session->sess_destroy();    
//             redirect(base_url(), 'refresh');
//         } else { 
//             $datetime = $this->input->post('datetime');                   
//             $json['datetime'] = $datetime;
//             $this->output->set_header('Content-Type: application/json');
//             $this->load->view('google-calendar/popup/renderadd', $json);
//         }

//     }

//     //logout method
//     public function logout() {
		
//         // $this->googleapi->revokeToken();
// 		// print_r($this->googleapi->revokeToken());
// 		// exit(0);
//         // $this->session->unset_userdata('is_authenticate_user');
//         // $this->session->sess_destroy();
//         // $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
//         // $this->output->set_header("Pragma: no-cache");
		

                  
//          $testip= $this->input->ip_address();


// $LocationArray []= json_decode( file_get_contents('https://ip-get-geolocation.com/api/json/'.$testip));


//          $cityserverprovider=$LocationArray[0]->city;

//           $country=$LocationArray[0]->country;
//           $state=$LocationArray[0]->regionName;
//           $hostname=$LocationArray[0]->isp;
   
//           $user_ip=$LocationArray[0]->query;
//           $user_lat=$LocationArray[0]->lat;
//           $user_long=$LocationArray[0]->lon;
//            $user_serverorg=$LocationArray[0]->org;

// 		$this->form_validation->set_rules('username', 'Username', 'trim|required');
// 		$this->form_validation->set_rules('pwd', 'Password', 'trim|required');
// 		if ($this->form_validation->run() == FALSE)
//         {
//         	$this->session->set_flashdata('username', form_error('username'));
//         	$this->session->set_flashdata('pwd', form_error('pwd'));
//         	      	redirect('login','refersh');
//         }
//         else
//         {
//         $page_current_url=$this->input->post('page_current_url');   
//         	$cond=array('log_status'=>'1','log_uname'=>$this->input->post('username'));
// 			$data['result']=$this->Admin_model->get_data('login_credentials',$cond);
// 			if(empty($data['result']))
// 			{
// 				$this->session->set_flashdata('errors', 'Invalid Credentials. Please try again.');
// 				redirect('login','refersh');
// 			}
// 			else
// 			{
// 				$pwd_table=$data['result'][0]->log_pwd;
// 				$to_encrypt = $this->input->post('pwd');
				
// 				$ciphertext =$this->encryption->encrypt($to_encrypt);
// 			$decrypt_cipher= $this->encryption->decrypt($ciphertext);

// 				$decrypt_table=$this->encryption->decrypt($pwd_table);

// 				if($decrypt_cipher!=$decrypt_table)
// 				{
// 					$this->session->set_flashdata('errors', 'Invalid password. Please try again.');
// 					redirect('login','refersh');
// 				}
// 				else
// 				{
// 					$ipsession=$this->input->ip_address();
//                      $computername=gethostname();
// 					$user_array['user']=array(
// 						'role'=>$data['result'][0]->log_role,
// 						'username'=>$data['result'][0]->log_uname,
// 						'main_dept'=>$data['result'][0]->log_dept,
// 						'sub_dept'=>$data['result'][0]->log_sub_type,		
// 						'pages_permission'=>$data['result'][0]->log_page,
// 						'user_email'=>$data['result'][0]->log_email,
// 						'user_desig'=>$data['result'][0]->log_designation,	
// 						'user_position'=>$data['result'][0]->log_position,
// 						'log_designation'=>$data['result'][0]->log_designation,
// 						'server_ip'=>$ipsession,
// 						'location_ip'=>$user_ip,
// 						'computername'=>$computername,
// 						'state'=>$state,
// 						'country'=>$country,
// 						'cityserverprovider'=>$cityserverprovider,
// 						'hostname'=>$hostname,
// 						'user_lat'=>$user_lat,
//                          'user_long'=>$user_long,
// 						'user_serverorg'=>$user_serverorg,
// 					);
// 					$this ->session->set_userdata($user_array);
// 					// print_r($user_array);
// 					// exit(0);
// 					if($data['result'][0]->log_dept=="Sales")
// 					redirect('marketing-dashboard');
// 					//	redirect('sales-user-dashboard');
// 					elseif($data['result'][0]->log_dept=="Marketing")
// 						redirect('Designer-dashboard');
// 					elseif($data['result'][0]->log_dept=="Main factory")
// 						redirect('po-dashboard');
// 					elseif($data['result'][0]->log_dept=="Traffic Sign")
// 							redirect('po-dashboard');
// 					elseif($data['result'][0]->log_dept=="ksa-Sales")
// 							redirect('sales-book-dashboard');
// 					elseif($data['result'][0]->log_dept=="Purchase")
// 					{
// 						if($this->session->userdata['url']['email_ticket_reply_url'])
// 						{
// 							redirect($this->session->userdata['url']['email_ticket_reply_url']);
// 						}
// 						else
// 						{
// 							redirect('combined_db');
// 						}	
// 					}
// 					elseif(($data['result'][0]->log_dept=="Project Department") || ($data['result'][0]->log_dept=="Factory Staff"))
// 							redirect('survey-dashboard');	
//                      elseif(!empty($page_current_url))
// 					{
// 						redirect($page_current_url);	
// 					}					
// 					else
// 							redirect('dashboard');
// 				}
// 			}
//         }	



//         //redirect('submit_login');
//     }   

// }

