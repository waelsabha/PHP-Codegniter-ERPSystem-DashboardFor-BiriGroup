<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Production_entry extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper('session');	
		$this->load->model('Third_db_model','tm');
		//$params = array();
 //   $this->load->library('I18N_Arabic', $params);
	}

function production_entry($id=null)
{
	if(logged_in())
	{
		 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		 $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {

         	if ((($page_cred[$i]=='production-entry')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
	           $excist=true;
               $i=$cred_count;
         	}	

           else
            	{$excist=false;}

        }
       if ($excist) {
	
			$cond1=array('cstatus'=>'1');
			$data['cat']=$this->tm->get_data('category',$cond1);

			$cond2=array('bsts'=>'1');
			$data['brands']=$this->tm->get_data('brand',$cond2);

			$cond3=array('usts'=>'1');
			$data['units']=$this->tm->get_data('units',$cond3);

			$cond4=array('vsts'=>'1');
			$data['variations']=$this->tm->get_data('variations',$cond4);

			$cond5=array('pv_sts'=>'1');
		    $data['final_val']=$this->tm->get_data('percentage_values',$cond5);

		    $cond6=array('status'=>'1');
			$data['country']=$this->tm->get_data('country_val',$cond6);	

		    $cond7=array('hse_sts'=>'1');
		    $data['hse_code']=$this->tm->get_data('hse_code',$cond7);

			if(!empty($id))
			{
				$data['result']=$this->tm->prd_data($id);
			}
			$this->load->view('admin/production/prd',$data);
	}
	 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  
	}
	
}

function list_prd()
{
if(logged_in())
		{
	$cond1=array('cstatus'=>'1');
	$data['cat']=$this->tm->get_data('category',$cond1);
	$data['result']=$this->tm->prd_data();
	$this->load->view('admin/production/list_prd',$data);
	}
}

function delete_prd($id)
{
if(logged_in())
		{
$data=array(
		'p_sts'=>'0',);
	$cond=array('pid'=>$id);
	$data['result']=$this->tm->update_data('products',$data,$cond);
$this->session->set_flashdata('success','Data deleted successfully'); 	
redirect('list-production','refresh');
	}
}

function credinals()
{
	$name=$this->input->post('name');
	$val=$this->input->post('val');
	$type=$this->input->post('type');

	if($type=="variation_form")
	{
		$data=array(
			'vname'=>$name,
			'v_val'=>$val,
			'vsts'=>'1',
		);
	$insert_id=$this->tm->insert_data('variations',$data);

	$cond=array('vid'=>$insert_id);
	$vars=$this->tm->get_data('variations',$cond);

	$v_name=$vars[0]->vname;
	$v_val=$vars[0]->v_val;
	$exploded_val=explode(',',$v_val);

	$list = array();
	$list[]=array('optgroup'=>$v_name);
    foreach ($exploded_val as $variation) {
        $list[] = array(
        	'id'   => $insert_id,
            'name' => $variation,
        );
    	}
    	 echo json_encode($list);

	//echo true;

	}
	elseif($type=="unit_form")
	{
		$data=array(
			'uname'=>$name,
			'ushort_name'=>$val,
			'usts'=>'1',
		);
		$insert_id=$this->tm->insert_data('units',$data);
	
		$list = array();
        $list[] = array(
            'id'   => $insert_id,
            'name' => $name,
        );
    	 echo json_encode($list);
	}
	elseif($type=="sub-cat")
	{

		$cond=array('cid'=>$name);
		$cat_result=$this->tm->get_data('category',$cond);
		$sub_cat_available=$cat_result[0]->csub_name;

		if(!empty($sub_cat_available))
		{
			
			$data=array(
			'csub_name'=>$sub_cat_available.','.$val,
			'cstatus'=>'1',
			);
			$this->tm->update_data('category',$data,$cond);
		}
		else
		{
			$data=array(
			'csub_name'=>$val,
			);
			$insert_id=$this->tm->update_data('category',$data,$cond);
		}

		$list = array();
        $list[] = array(
            'id'   => $val,
            'name' => $val,
        );
    echo json_encode($list);

		//print_r($cat_result);
		//echo $val;				
	}
	elseif($type=="main-cat")
	{
		$data=array(
			'cname'=>$name,
			'ccode'=>$val,
			'cstatus'=>'1',
		);
		$insert_id=$this->tm->insert_data('category',$data);

		$list = array();
        $list[] = array(
            'id'   => $insert_id,
            'name' => $name,
           	'code'=>$val,
        );
     echo json_encode($list);

		//echo true;
	}
	elseif($type=="brand")
	{
		$data=array(
			'bname'=>$name,
			'bdesc'=>$val,
			'bsts'=>'1',
		);
		$insert_id=$this->tm->insert_data('brand',$data);
		//echo true;

		$list = array();
        $list[] = array(
            'id'   => $insert_id,
            'name' => $name,
        );
    	 echo json_encode($list);
	}
	elseif($type=="hse_form")
	{
		$hse_name=explode(',',$name);
		$hse_val=explode(',',$val);
		$data=array(
		    'hse_name'=>implode('|~~|',$hse_name),
			'hse_code'=>$hse_val[0],
			'hse_notes'=>$hse_val[1],
			'hse_sts'=>'1',
		);
		$insert_id=$this->tm->insert_data('hse_code',$data);
		//echo true;

		$list = array();
        $list[] = array(
            'id'   => $insert_id,
            'name_en' => $hse_name[0],
            'name_ar'=>$hse_name[1],
            'code'=>$val,
        );
    
    	 echo json_encode($list);
	}
	else
	{
		echo false;
	}

}

function sub_cat_list()
{
	$cat_id=$this->input->post('cat_id');
	

	$cond=array('cid'=>$cat_id);
	$cat_result=$this->tm->get_data('category',$cond);
	$sub_cat_available=$cat_result[0]->csub_name;

	if(!empty($sub_cat_available))
	{
		$explode_sub_cat=explode(',',$sub_cat_available);
		$list = array();
    foreach ($explode_sub_cat as $sub_cat ) {
    	echo "<option value='".$sub_cat."'>".$sub_cat."</option>";
      }
	}
	else{
		echo "";
	}
	

}

function submit_cat()
{
if(logged_in())
		{
	$c_name=$this->input->post('add_cat_name');
	$c_code=$this->input->post('add_cat_code');
	$sc_name=$this->input->post('add_sub_cat[]');
	$data=array(
		'cname'=>$c_name,
		'csub_name'=>implode(',',$sc_name),
		'ccode'=>$c_code,
		'cstatus'=>"1"
	);
	$insert_id=$this->tm->insert_data('category',$data);
	$this->session->set_flashdata('success','Details added successfully');  	
	if($insert_id)
redirect('prd-category','refresh');
	}
}

function edit_cat()
{
if(logged_in())
		{
	$cat_id=$this->input->post('cat_id');
	$sub_cat=implode(',',$this->input->post('sub_cat'));
	$data=array(
		'cname'=>$this->input->post('cat_name'),
		'csub_name'=>$sub_cat,
		'ccode'=>$this->input->post('cat_code'),
	);
	$cond=array('cid'=>$cat_id);
	$data['result']=$this->tm->update_data('category',$data,$cond);
	$this->session->set_flashdata('success','Details updated successfully');  	
redirect('prd-category','refresh');
	}
}

function delete_category($id)
{
if(logged_in())
		{
	$data=array(
		'cstatus'=>'0',);
	$cond=array('cid'=>$id);
	$data['result']=$this->tm->update_data('category',$data,$cond);
$this->session->set_flashdata('success','Data deleted successfully'); 	
redirect('prd-category','refresh');
}
}

function submit_brand_data()
{
if(logged_in())
		{
	$data=array(
		'bname'=>$this->input->post('add_brand'),
		'bdesc'=>$this->input->post('add_desc'),
		'bsts'=>'1'
	);
	$insert_id=$this->tm->insert_data('brand',$data);
	$this->session->set_flashdata('success','Details added successfully');  	
	if($insert_id)
redirect('prd-brands','refresh');
}
}

function edit_brand()
{
if(logged_in())
		{
$brand_id=$this->input->post('brand_id');
	$data=array(
		'bname'=>$this->input->post('b_name'),
		'bdesc'=>$this->input->post('b_desc'),
	);
	$cond=array('bid'=>$brand_id);
	$data['result']=$this->tm->update_data('brand',$data,$cond);
	$this->session->set_flashdata('success','Details updated successfully');  	
redirect('prd-brands','refresh');
}
}

function delete_brand($id)
{
if(logged_in())
		{
$data=array(
		'bsts'=>'0',);
	$cond=array('bid'=>$id);
	$data['result']=$this->tm->update_data('brand',$data,$cond);
$this->session->set_flashdata('success','Data deleted successfully'); 	
redirect('prd-brands','refresh');
}
}

function submit_unit_data()
{
if(logged_in())
		{
	$data=array(
		'uname'=>$this->input->post('add_unit_name'),
		'ushort_name'=>$this->input->post('add_shrt_name'),
		'usts'=>'1',
	);
	$insert_id=$this->tm->insert_data('units',$data);
	$this->session->set_flashdata('success','Details added successfully');  	
	if($insert_id)
	redirect('prd-units','refresh');
	}
}

function edit_unit()
{
if(logged_in())
		{
	$unit_id=$this->input->post('unit_id');
	$data=array(
		'uname'=>$this->input->post('u_name'),
		'ushort_name'=>$this->input->post('u_sht_name'),
	);
	$cond=array('uid'=>$unit_id);
	$data['result']=$this->tm->update_data('units',$data,$cond);
	$this->session->set_flashdata('success','Details updated successfully');  	
redirect('prd-units','refresh');
	}
}

function delete_units($id)
{
if(logged_in())
		{
$data=array(
		'usts'=>'0',);
	$cond=array('uid'=>$id);
	$data['result']=$this->tm->update_data('units',$data,$cond);
$this->session->set_flashdata('success','Data deleted successfully'); 	
redirect('prd-units','refresh');
	}
}

function submit_variation()
{
if(logged_in())
		{
	$vlist=implode(',',$this->input->post('add_var_val[]'));
	$data=array(
		'vname'=>$this->input->post('add_var_name'),
		'v_val'=>$vlist,
		'vsts'=>'1',
	);
	$insert_id=$this->tm->insert_data('variations',$data);
	if($insert_id)
	$this->session->set_flashdata('success','Details entered successfully');  	
redirect('prd-variations','refresh');
	}
}

function edit_variation()
{
if(logged_in())
		{
	$var_id=$this->input->post('var_id');
	$vlist=implode(',',$this->input->post('v_val'));
	$data=array(
		'vname'=>$this->input->post('v_name'),
		'v_val'=>$vlist,
	);
	$cond=array('vid'=>$var_id);
	$data['result']=$this->tm->update_data('variations',$data,$cond);
	$this->session->set_flashdata('success','Details updated successfully');  	
redirect('prd-variations','refresh');
	}
}

function delete_variation($id)
{
if(logged_in())
		{
$data=array(
		'vsts'=>'0',);
	$cond=array('vid'=>$id);
	$data['result']=$this->tm->update_data('variations',$data,$cond);
$this->session->set_flashdata('success','Data deleted successfully'); 	
redirect('prd-variations','refresh');
	}
}

function prd_final_values()
{
if(logged_in())
		{


  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='prd-final-values')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {
    $cond=array('pv_sts'=>'1');
	$data['result']=$this->tm->get_data('percentage_values',$cond);
	$this->load->view('admin/production/final_val',$data);


     }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}

function edit_finals()
{
if(logged_in())
		{
	$final_id=$this->input->post('final_id');
	$data=array(
		'pv_uae1'=>$this->input->post('uae_l1'),
		'pv_uae2'=>$this->input->post('uae_l2'),
		'pv_ksa'=>$this->input->post('ksa_final'),
		'pv_ksa1'=>$this->input->post('ksa_l1'),
		'pv_ksa2'=>$this->input->post('ksa_l2'),
	);
	$cond=array('pvid'=>$final_id);
	$data['result']=$this->tm->update_data('percentage_values',$data,$cond);
	$this->session->set_flashdata('success','Details updated successfully');  	
redirect('prd-final-values','refresh');
	}
}

function prd_category()
{
		if(logged_in())
		{

	         $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='prd-category')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {
			$cond=array('cstatus'=>'1');
			$data['result']=$this->tm->get_data('category',$cond);
			$this->load->view('admin/production/category',$data);
            }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}

function prd_brands()
{
if(logged_in())
		{
              $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='prd-brands')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

							$cond=array('bsts'=>'1');
							$data['result']=$this->tm->get_data('brand',$cond);
							$this->load->view('admin/production/brands',$data);
                        }
		    else{
					//echo false;
					 $this->session->unset_userdata('user', null);
			        	redirect('login','refersh');
				}  

	    }
}

function prd_units()
{
if(logged_in())
		{
   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='prd-units')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

	$cond=array('usts'=>'1');
	$data['result']=$this->tm->get_data('units',$cond);
	$this->load->view('admin/production/units',$data);
}
 else{
					//echo false;
					 $this->session->unset_userdata('user', null);
			        	redirect('login','refersh');
				}  


	}
}
function prd_variations()
{
if(logged_in())
		{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='prd-variations')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

	$cond=array('vsts'=>'1');
	$data['result']=$this->tm->get_data('variations',$cond);
	$this->load->view('admin/production/variations',$data);
}
else{
					//echo false;
					 $this->session->unset_userdata('user', null);
			        	redirect('login','refersh');
				} 


	}

}

function prd_hse_codes()
{
if(logged_in())
		{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='prd-hse-codes')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

	$cond=array('hse_sts'=>'1');
	$data['result']=$this->tm->get_data('hse_code',$cond);
	$this->load->view('admin/production/hse_code',$data);
}
else{
					//echo false;
					 $this->session->unset_userdata('user', null);
			        	redirect('login','refersh');
				} 


	}
}

function submit_hs_codes()
{
if(logged_in())
		{
	$data=array(
		'hse_name'=>implode('|~~|',$this->input->post('add_name[]')),
		'hse_code'=>$this->input->post('add_code_val'),	
		'hse_notes'=>$this->input->post('add_hse_notes'),	
		'hse_sts'=>'1',
	);
	$insert_id=$this->tm->insert_data('hse_code',$data);
	$this->session->set_flashdata('success','Details added successfully');  	
	if($insert_id)
	redirect('prd-hse-codes','refresh');
	}
}

function edit_hse_code()
{
if(logged_in())
		{
	$hse_id=$this->input->post('hse_id');
	$data=array(
		'hse_name'=>implode('|~~|',$this->input->post('name[]')),
		'hse_code'=>$this->input->post('code_val'),	
		'hse_notes'=>$this->input->post('hse_notes'),	
	);
	$cond=array('hse_id'=>$hse_id);
	$data['result']=$this->tm->update_data('hse_code',$data,$cond);
	$this->session->set_flashdata('success','Details updated successfully');  	
redirect('prd-hse-codes','refresh');
}
}

function delete_hse_code($id)
{
if(logged_in())
		{
$data=array(
		'hse_sts'=>'0',);
	$cond=array('hse_id'=>$id);
	$data['result']=$this->tm->update_data('hse_code',$data,$cond);
$this->session->set_flashdata('success','Data deleted successfully'); 	redirect('prd-hse-codes','refresh');
}
}

function hse_code_val()
{
if(logged_in())
		{
	$hse_id=$this->input->post('hse_id');
	

	$cond=array('hse_id'=>$hse_id);
	$cat_result=$this->tm->get_data('hse_code',$cond);
	$code_value=$cat_result[0]->hse_code;

	if(!empty($code_value))
	{
	  	echo $code_value;
	}
	else{
		echo "";
	}
  }
}

function submit_prd()
{

	// print_r('sdasd');
	// exit(0);

if(logged_in())
		{	            
	$this->form_validation->set_rules('pname_en', 'Product Name -English', 'trim|required');
	$this->form_validation->set_rules('pname_ar', 'Product Name -Arabic', 'trim|required');
	// $this->form_validation->set_rules('prd_type', 'Product Type', 'trim|required');
	// $this->form_validation->set_rules('brand', 'Brand Name', 'trim|required');
	// $this->form_validation->set_rules('cat', 'Category', 'trim|required');
	// $this->form_validation->set_rules('sub_cat', 'Sub-Category', 'trim|required');
	$this->form_validation->set_rules('itm_code', 'Item Code', 'trim|required');

	$this->form_validation->set_rules('sku', 'SKU', 'trim|required');
	// $this->form_validation->set_rules('bin_amt', 'Bin Quantity', 'trim|required');
	// $this->form_validation->set_rules('alrt_amt', 'Alert Quantity', 'trim|required');
	// $this->form_validation->set_rules('prd_wgt', 'Product Weight', 'trim|required');

	// $this->form_validation->set_rules('pack_wdt', 'Packet Width', 'trim|required');
	// $this->form_validation->set_rules('pack_hgt', 'Packet Height', 'trim|required');
	// $this->form_validation->set_rules('pack_lgt', 'Packet length', 'trim|required');
	// $this->form_validation->set_rules('variation_status', 'Variation Status', 'required');
  
//   $this->form_validation->set_rules('variation_select', '', '');
// 	$this->form_validation->set_rules('selling_price', 'Selling Price', 'trim|required');
// $this->form_validation->set_rules('units', 'Units', 'trim|required');
// 	$this->form_validation->set_rules('vat', 'VAT', 'trim|required');

// $this->form_validation->set_rules('pur_price', 'Purchase Price', 'trim');
// 	$this->form_validation->set_rules('prd_desc', 'Description', 'trim|required');
	$this->form_validation->set_rules('country', 'Country', 'trim|required');
	$this->form_validation->set_rules('hse_code', 'HSE CODE', 'trim|required');
	

// if(empty($ImageCount))
//  $this->form_validation->set_rules('prd_img', 'Product Image', 'trim|required');

// if(empty($ImageCount2))
//  	$this->form_validation->set_rules('datasheets', 'Datasheet', 'trim|required');

	       
	 $this->form_validation->set_rules('uae_final', 'UAE Final', 'trim|required');
	 $this->form_validation->set_rules('ksa_final', 'KSA Final', 'trim|required');
	 $this->form_validation->set_rules('uae_final_l1', 'UAE Level 1', 'trim|required');
	 $this->form_validation->set_rules('ksa_final_l1', 'KSA Level 1', 'trim|required');  
	 $this->form_validation->set_rules('uae_final_l2', 'UAE Level 2', 'trim|required');
	 $this->form_validation->set_rules('ksa_final_l3', 'KSA Level 3', 'trim|required');

		if ($this->form_validation->run() == FALSE)
        {  
 $this->session->set_flashdata('pname_en', form_error('pname_en'));
 $this->session->set_flashdata('pname_ar', form_error('pname_ar'));
//  $this->session->set_flashdata('prd_type', form_error('prd_type'));
//  $this->session->set_flashdata('brand', form_error('brand'));

//   $this->session->set_flashdata('cat', form_error('cat'));
//   $this->session->set_flashdata('sub_cat', form_error('sub_cat'));
  $this->session->set_flashdata('itm_code', form_error('itm_code'));
  $this->session->set_flashdata('sku', form_error('sku'));

//  $this->session->set_flashdata('bin_amt', form_error('bin_amt'));
//  $this->session->set_flashdata('alrt_amt', form_error('alrt_amt'));
//  $this->session->set_flashdata('prd_wgt', form_error('prd_wgt'));
//  $this->session->set_flashdata('pack_wdt', form_error('pack_wdt'));
//  $this->session->set_flashdata('pack_hgt', form_error('pack_hgt'));
//  $this->session->set_flashdata('pack_lgt', form_error('pack_lgt'));
//  $this->session->set_flashdata('variation_status', form_error('variation_status'));
//  $this->session->set_flashdata('variation_select', form_error('variation_select'));
//  $this->session->set_flashdata('selling_price', form_error('selling_price'));

//  $this->session->set_flashdata('units', form_error('units'));
//  $this->session->set_flashdata('vat', form_error('vat'));
 $this->session->set_flashdata('pur_price', form_error('pur_price'));
 $this->session->set_flashdata('prd_desc', form_error('prd_desc'));
//  $this->session->set_flashdata('prd_img', form_error('prd_img'));
// $this->session->set_flashdata('datasheets', form_error('datasheets'));
 $this->session->set_flashdata('uae_final', form_error('uae_final'));
 $this->session->set_flashdata('ksa_final', form_error('ksa_final'));
 $this->session->set_flashdata('uae_final_l1', form_error('uae_final_l1'));
 $this->session->set_flashdata('ksa_final_l1', form_error('ksa_final_l1'));
 $this->session->set_flashdata('uae_final_l2', form_error('uae_final_l2'));
 $this->session->set_flashdata('ksa_final_l3', form_error('ksa_final_l3'));

 $this->session->set_flashdata('country', form_error('country'));
 $this->session->set_flashdata('hse_code', form_error('hse_code'));
//print_r(validation_errors());
 redirect('production-entry','refresh');
        }
else
{
	$prd_name=$this->input->post('pname_en').'|~~|'.$this->input->post('pname_ar');	

	$this->load->library('image_lib');
	$this->load->library('upload');
  $image = array();

	$ImageCount = count($_FILES['prd_img']['name']);
	//	echo $ImageCount;
$prd_img_data=array();
        for($io = 0; $io < $ImageCount; $io++){
            $_FILES['file']['name']       = $_FILES['prd_img']['name'][$io];
            $_FILES['file']['type']       = $_FILES['prd_img']['type'][$io];
            $_FILES['file']['tmp_name']   = $_FILES['prd_img']['tmp_name'][$io];
            $_FILES['file']['error']      = $_FILES['prd_img']['error'][$io];
            $_FILES['file']['size']       = $_FILES['prd_img']['size'][$io];

            // File upload configuration
            $uploadPath = 'uploads/production/prds/';
      $config['file_name'] = time() . $_FILES["prd_img"]["name"][$io];
            $config['upload_path'] = $uploadPath;
            $config['max_size'] = '1024000';////1mb
            $config['allowed_types'] = 'jpg|jpeg|png|gif';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'prd_image');
            $this->prd_image->initialize($config);
 
            // Upload file to server
            if($this->prd_image->do_upload('file')){
                // Uploaded file data
                $imageData = $this->prd_image->data();
                  $configer =  array(
              'image_library'   => 'gd2',
              'source_image'    =>  $imageData['full_path'],
              'maintain_ratio'  =>  TRUE,
              'width'           =>  250,
              'height'          =>  250,
            );
            $this->image_lib->clear();
            $this->image_lib->initialize($configer);
            $this->image_lib->resize();

            if(!empty($imageData['file_name']))
               { 
               	$prd_img_data[]=$imageData['file_name'];
             	} 
                else
               $this->session->set_flashdata('errors', $this->datasheet->display_errors());  
        }
    }

$datasheet_data=array();
    $ImageCount2 = count($_FILES['datasheets']['name']);
    //echo $ImageCount2;
//print_r($prd_img_data);
     for($i = 0; $i < $ImageCount2; $i++)
        {
            $_FILES['file']['name']       = $_FILES['datasheets']['name'][$i];
            $_FILES['file']['type']       = $_FILES['datasheets']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['datasheets']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['datasheets']['error'][$i];
            $_FILES['file']['size']       = $_FILES['datasheets']['size'][$i];

            // File upload configuration
            $uploadPath = 'uploads/production/datasheets/';
         $config['file_name'] = time() . $_FILES["datasheets"]["name"][$i];
            $config['upload_path'] = $uploadPath;
            //$config['max_size'] = '3000000';////3mb
            $config['allowed_types'] = 'jpg|jpeg|png|pdf';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'datasheet');
            $this->datasheet->initialize($config);

 //print_r($this->datasheet->display_errors());
            // Upload file to server
            if($this->datasheet->do_upload('file'))
            {
                // Uploaded file data
                $imageData2 = $this->datasheet->data();             
               
              if(!empty($imageData2['file_name']))
                $datasheet_data[]=$imageData2['file_name'];
                else
              $this->session->set_flashdata('errors', $this->datasheet->display_errors());  	
               //print_r($uploadImgData);

            }       
        }

        if(!empty($this->input->post('variation_select')))
       $var_type=implode(',',$this->input->post('variation_select'));
        else
        $var_type='';	

    $var_data=$this->input->post('variation_label_val');
    $var_data1=explode('|#|',$var_data);
    $var_name=array();
    foreach($var_data1 as $vd1)
    {    	
    	$var_data2=explode("::",$vd1);
    	foreach($var_data2 as $key=>$vd2)
    	{
    		if($key=='0')
    		{
    			// $var_name[]=$vd2;
    			if(!in_array($vd2,$var_name) && empty($var_name))
    			{
					$var_name[]=$vd2;
    				//$var_val[]="##";
    			}
    			elseif(!in_array($vd2,$var_name))
    			{
    				$var_name[]=$vd2;
    				$var_val[]="##";
    			}
    			else{}   		
    		}
    		else////values
    		{
    			$var_val[]=$vd2;
    		}    		
    	}
   }
 
 if(!empty($var_name))
 	$new_var_names=implode('##',$var_name);
 else
 	$new_var_names='';
 
 if(!empty($var_val))
 	$new_var_vals=implode(',',$var_val);
else
	$new_var_vals='';

	$data=array(
	'p_user_name'=>$this->session->userdata['user']['username'],
 	'pname'=>$prd_name,
 	'ptype'=>$this->input->post('prd_type'),
 	'pcode'=>$this->input->post('itm_code'),
 	'pbrand'=>$this->input->post('brand'),
 	'pcat'=>$this->input->post('cat'),
 	'pcat_sub'=>$this->input->post('sub_cat'),
 	'psku'=>$this->input->post('sku'), 
 	'punit'=>$this->input->post('units'), 
 	'pbin_capacity'=>$this->input->post('bin_amt'), 
 	'palert_qnty'=>$this->input->post('alrt_amt'), 
 	'p_wgt'=>$this->input->post('prd_wgt'), 
 	'p_pack_width'=>$this->input->post('pack_wdt'), 
 	'p_pack_hgt'=>$this->input->post('pack_hgt'), 
 	'p_pack_lgth'=>$this->input->post('pack_lgt'), 
 	'p_variation'=>$new_var_names, 
 	'p_variation_types'=>$new_var_vals, 
 	'p_selling_price'=>$this->input->post('selling_price'), 
 	'p_uae_final'=>$this->input->post('uae_final'),
 	'p_uae_l1'=>$this->input->post('uae_final_l1'), 
 	'p_uae_l2'=>$this->input->post('uae_final_l2'), 
 	'p_ksa'=>$this->input->post('ksa_final'), 
 	'p_ksa_reg_1'=>$this->input->post('ksa_final_l1'), 
 	'p_ksa_comp_2'=>$this->input->post('ksa_final_l2'), 
 	'p_ksa_retail_3'=>$this->input->post('ksa_final_l3'), 
 	'p_purchase_price'=>$this->input->post('pur_price'), 
 	'p_vat_perc'=>$this->input->post('vat'), 
 	'p_desc'=>$this->input->post('prd_desc'), 
 	'p_hse_id'=>$this->input->post('hse_code'), 
 	'p_country'=>$this->input->post('country'), 	 
	);

//$this->prd_image->display_errors();
	$prd_updt_id=$this->input->post('prd_id');
	if(empty($prd_updt_id))
	{
		$insert_id=$this->tm->insert_data('products',$data);
		if(!empty($insert_id))
		{
			$cond=array('pid'=>$insert_id);
			$data1=array(
			'p_prd_img'=>implode(',',$prd_img_data),
			'p_sts'=>'1',
			);
			$this->tm->update_data('products',$data1,$cond);
		
			if(!empty($ImageCount2))
			{
				$data2=array(
			 'p_datasheets'=>implode(',',$datasheet_data),
			 );
				$this->tm->update_data('products',$data2,$cond);
			}

			$this->session->set_flashdata('success', 'Data added successfully');
			redirect('production-entry','refersh');
			
		}
	}
	else
	{	
		$cond=array('pid'=>$prd_updt_id);
		$this->tm->update_data('products',$data,$cond);

			if(!empty($_FILES['prd_img']['name'][0]))
			{
				$data_img=array(
					'p_prd_img'=>implode(',',$prd_img_data), 
				);
			}
			else
			{
				$data_img=array(
					'p_prd_img'=>$this->input->post('prd_img'),
				);
			}
			$this->tm->update_data('products',$data_img,$cond);

			if(!empty($_FILES['datasheets']['name'][0]))
			{
				$data_sheet_img=array(
					'p_datasheets'=>implode(',',$datasheet_data), 
				);
			}
			else
			{
				$data_sheet_img=array(
					'p_datasheets'=>$this->input->post('prd_datasheet'),
				);
			}
		$this->tm->update_data('products',$data_sheet_img,$cond);
		
		$this->session->set_flashdata('success', 'Data updated successfully');
			redirect('list-production','refersh');
	}
}
}		 
}


function filter_type()
{
	$name=$this->input->post('type_name');
	$val=$this->input->post('type');

	if($val=="prd_type")
	{
		$cond1=array('ptype'=>$name);
		$data['result']=$this->tm->prd_data('',$cond1);
	}
	else
	{
		$cond1=array('pcat'=>$name);
		$data['result']=$this->tm->prd_data('',$cond1);
	}

	print_r('<table class="table table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
	<th ></th>
<th></th>
<th style="width: 50%;">Item - Name</th>	
<th>Item Code</th>
<th>Current Stock</th>
<th>Selling Price</th>
<th>SKU</th>
<th>Type</th>	
<th>Category</th>
<th>Sub-Category</th>


<th>Action</th>

</tr>
</thead>
<tbody>');

$i=1;
foreach($data['result'] as $t)
{
$pname=explode('|~~|',$t->pname);

$pimage=explode(',',$t->p_prd_img);
$pdatasheet=explode(',', $t->p_datasheets);
$hse_name=explode('|~~|',$t->hse_name);
print_r('
<tr class="gradeX">
			<td>').$i++;print_r('</td>
			<td>');
			print('<img src="'.base_url('uploads/production/prds/'.$pimage[0]).'" width="80" height="80"></td>
			<td>'); echo $pname[0];print_r('<br/>');echo $pname[1].
		print_r('</td>
			<td>'); echo $t->pcode;print_r('</td>
			<td>'); echo $t->p_stock_val;print('" "');echo $t->ushort_name;
			print_r('</td>
			<td>');echo $t->p_selling_price;print_r('</td>
			<td>'); echo $t->psku;print_r('</td>
			<td>'); echo $t->ptype;print_r('</td>
			<td>'); echo $t->cname;print_r('</td>
			<td>');echo $t->pcat_sub;print_r('</td>
			
			<td>	

<a href="#modalLG'); echo $t->pid;print_r('" class="mb-xs mt-xs mr-xs modal-sizes btn btn-default"><i class="fa fa-eye"></i></a>
				&nbsp; &nbsp;
<a href="edit_prd/'); echo $t->pid;print_r('" class="delete-row"><i class="fa fa-pencil"></i></a>							
				&nbsp;&nbsp;
<a href="delete_prd/'); echo $t->pid;print_r('" class="delete-row"><i class="fa fa-trash-o"></i></a>
	
			</td>
	</tr>

<div id="modalLG');echo $t->pid;print_r('" class="modal-block modal-block-lg modal-header-color modal-block-info mfp-hide" data-backdrop="static" data-keyboard="false">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">');echo $pname[0];print_r('<br/>');
echo $pname[1];print_r('</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
	<div class="col-md-12 col-sm-12">
		<div class="col-md-9 col-sm-9">
			<div class="col-md-4">
				<b>SKU:</b>');echo $t->psku;print_r('<br/>
				<b>Product Type:</b>');echo $t->ptype;print_r('<br/>
				<b>Brand:</b>');echo $t->bname;print_r('<br/>
				<b>Product Code:</b>');echo $t->pcode;print_r('<br/>
				<b>Selling Price:</b>');echo $t->p_selling_price;print_r('<br/>
				<b>Purchase price:</b>'); echo $t->p_purchase_price;print_r('<br/>
				<b>VAT Percentage:</b>');echo $t->p_vat_perc;print_r('<br/>
				
				<b>HS Name:</b>');echo $hse_name[0];print_r('<br/>');echo $hse_name[1];print_r('<br/>
				<b>HS Code:</b>'); echo $t->hse_code;print_r('<br/>
			</div>
			<div class="col-md-4">
				<b>Category:</b>');echo $t->cname;print_r('<br/>
				<b>Sub-Category:</b>');echo $t->pcat_sub;print_r('<br/>
				<b>Bin Capacity:</b>');echo $t->pbin_capacity;print_r('<br/>
				<b>Alert Quantity:</b>'); echo $t->palert_qnty;print_r('<br/>
				<b>Country of Orgin:</b>'); echo $t->name;print_r('<br/>
				<b>Stock:</b>'); echo $t->p_stock_val;print_r('<br/>
				
			</div>
			<div class="col-md-4">
				<b>Product Weight:</b>');echo $t->p_wgt;print_r('<br/>
				<b>Unit:</b>'); echo $t->uname;print_r('<br/>
				<b>Packing Sizes (w):</b>'); echo $t->p_pack_width;print_r('<br/>
				<b>Packing Sizes (h):</b>'); echo $t->p_pack_hgt;print_r('<br/>
				<b>Packing Sizes (l):</b>'); echo $t->p_pack_lgth;print_r('<br/>
				<b>Variation Available ?:</b>'); echo $t->p_variation;print_r('<br/>');
				
				if($t->p_variation="Yes")
				{
				print_r('
				<b>Variation values:</b>'); echo $t->p_variation_types;print_r('<br/>');
				
				}
				else
				{}
				print_r('	
			</div>
			<div class="col-md-12">
				<b>Description:</b>'); echo $t->p_desc;print_r('<br/>
			</div>
		</div>
		<div class="col-sm-3">
			<div class="thumbnail-gallery">
				<a class="img-thumbnail lightbox" href="'); echo base_url('uploads/production/prds/').$pimage[0];print_r('" data-plugin-options="{ &quot;type&quot;:&quot;image&quot; }">
				<img class="img-responsive" width="215" src="'); echo base_url('uploads/production/prds/').$pimage[0];print_r('">
				<!-- <span class="zoom">
				<i class="fa fa-search"></i>
				</span> -->
				</a>
				
				<!-- 	<a class="img-thumbnail lightbox" href="'); echo base_url('uploads/production/prds/').$img;print_r('" data-plugin-options="{ &quot;type&quot;:&quot;image&quot; }"> -->
					<div class="row">');
	
	foreach($pimage as $img)
	{
		
  print_r('<div class="column">
    <img class="img-responsive" src="'); echo base_url('uploads/production/prds/');echo $img;print_r('"width='."50".' height='."50".'>
  </div>');
	}
  print_r('
</div>
				
			
				
			</div>
			
		</div>
	</div>
	<div class="col-md-12 col-sm-12">
		<div class="col-md-4">
			<b>UAE Final:</b>'); echo $t->p_uae_final;print_r('<br/>
			<b>UAE Level-1:</b>');echo $t->p_uae_l1;print_r('<br/>
			<b>UAE Level-2:</b>'); echo $t->p_uae_l2;print_r('<br/>
		</div>
		<div class="col-md-4">
			<b>KSA Final:</b>'); echo $t->p_ksa;print_r('<br/>
			<b>KSA Level-1:</b>'); echo $t->p_ksa_l1;print_r('<br/>
			<b>KSA Level-2:</b>'); echo $t->p_ksa_l2;print_r('<br/>
		</div>
		<div class="col-md-4">
			<b>Additional Documents:</b><br/>
			');
	foreach($pdatasheet as $dsheet)
	{
$ext = pathinfo('uploads/production/datasheets/'.$dsheet, PATHINFO_EXTENSION); //$ext will be gif

if($ext=="jpg" || $ext=="jpeg")
{
	echo "<span>
	<a href=".base_url('uploads/production/datasheets/').$dsheet." download><i class='fa fa-image'></i></a>
	</span>";
}
elseif($ext=="pdf")
{
echo "<span>
<a href=".base_url('uploads/production/datasheets/').$dsheet." download><i class='fa fa-file-pdf-o'></i></a>
</span>";
}
else{
echo "<span><i class='fa fa-file'></i></span>";
}

// echo "<span><i class='fa fa-pdf'></i>
// <img src='".base_url('uploads/production/datasheets/').$dsheet."' width='150' height='150'></span><br/>";
	}
print_r('
		</div>
	</div>
	




</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-default modal-dismiss">Close</button>
</div>
</div>
</footer>
</section>
</div>

');
}
print_r('
</tbody>
</table>');
}

function edit_prd_width_heigth()
{
	$prd_id=$this->input->post('prd_id');
	$prd_width=$this->input->post('prd_width');
	$prd_height=$this->input->post('prd_height');
	$prd_area=$this->input->post('prd_area');
	$prd_al_thickness=$this->input->post('prd_al_thickness');
	$prd_al_type=$this->input->post('prd_al_type');
	$prd_clamps_required=$this->input->post('prd_clamps');
    $final_price=$this->input->post('prd_selling_price'); 
	$p_purchase_price=$this->input->post('p_purchase_price'); 

  //  $final_price=$this->input->post('add_prd_price_dashboard');
$uae1_percentage=$final_price*0.10;
$p_uae_l1=$final_price+$uae1_percentage;

$p_uae_l2_percentage=$final_price*0.25;
$p_uae_l2=$final_price+$p_uae_l2_percentage;

$p_uae_l3_percentage=$final_price*0.35;
$p_uae_l3=$final_price+$p_uae_l3_percentage;

$p_ksa_percentage=$final_price+12.5;
$p_ksa=$final_price+12.5;

$p_ksa_reg_1_percentage=$p_ksa*(0.10);
$p_ksa_reg_1=$p_ksa+$p_ksa_reg_1_percentage;

$p_ksa_comp_2_perc=$p_ksa*(0.20);
$p_ksa_comp_2=$p_ksa+$p_ksa_comp_2_perc;

$p_ksa_retail_3_per=$p_ksa*(0.50);
$p_ksa_retail_3=$p_ksa+$p_ksa_retail_3_per;




	$data=array(
		'prd_width'=>$prd_width,
		'prd_height'=>$prd_height,
		'p_area'=>$prd_area,
		'p_al_thickness'=>$prd_al_thickness,
		'p_al_type'=>$prd_al_type,
		'p_clamp'=>$prd_clamps_required,
		'p_selling_price'=> $final_price,
			'p_uae_final'=> $final_price,
			'p_uae_l1'=>$p_uae_l1,
		    'p_uae_l2'=>$p_uae_l2,
			'p_uae_l3'=>$p_uae_l3,
			'p_ksa'=>$p_ksa,
			'p_ksa_reg_1'=>$p_ksa_reg_1,
			'p_ksa_comp_2'=>$p_ksa_comp_2,
			'p_ksa_retail_3'=>$p_ksa_retail_3,
			'p_purchase_price'=>$p_purchase_price,
	);
	$this->tm->update_data('products',$data,array('pid'=>$prd_id));

     $data_focus=array(
	 'prd_id'=>$main_prd_id,
	 'prd_code'=>$main_code,
	 'prd_price_new'=>$this->input->post('add_prd_price_dashboard'),
	 'active_sts'=>'0',
	 'changed_by'=>$this->session->userdata['user']['username'],
	 'date_create'=>get_date(),
	 'date_update'=>get_date()

 );

$this->tm->insert_data('focus_price_statue',$data_focus);
$this->send_mail_checking($main_code,$final_price);


	$this->session->set_flashdata('success','Product details updated successfully'); 	
	redirect('list-production','refresh');
}


function excel_upload_prd_details()
{

     //this->load->view('admin/list_tree');
   $excist=false;
		if(logged_in())
		{
        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
       if ($page_cred[$i]=='prd_extra_details_excel')
        {
        	$excist=true;
        	 $i=$cred_count;
        }
           else
           	$excist=false;

         }
        if ($excist) {
         	// code...

		$this->load->view('admin/production/prd_extra_excel_details');

	}
	else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}

}

else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}


	
}


function submit_prd_extra_details()
{
	$this ->load-> library('excel');
		$this ->load-> library('image_lib');
		$path = 'uploads/excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this ->upload -> do_upload('userfile')) 
		{
			$error = array('error' => $this ->upload -> display_errors());
			$this ->session-> set_flashdata('errors', $error['error']);
			redirect("sample_excel_upload", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this ->upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			
			$prd_id = trim($allDataInSheet[$i]['A']);

			if(!empty($allDataInSheet[$i]['D']))
				$width=trim($allDataInSheet[$i]['D']);
			else
				$width='0';

			if(!empty($allDataInSheet[$i]['E']))
				$height=trim($allDataInSheet[$i]['E']);
			else
				$height='0';

			if(!empty($allDataInSheet[$i]['F']))
				$area=trim($allDataInSheet[$i]['F']);
			else
				$area='0';

			if(!empty($allDataInSheet[$i]['G']))
				$clamp=trim($allDataInSheet[$i]['G']);
			else
				$clamp='0';

			if(!empty($allDataInSheet[$i]['H']))
				$al_thickness=trim($allDataInSheet[$i]['H']);
			else
				$al_thickness='0';

			if(!empty($allDataInSheet[$i]['I']))
				$al_thickness_type=trim($allDataInSheet[$i]['I']);
			else
				$al_thickness_type='0';

				$data_update = array(
					'prd_width'=>$width,
				  	'prd_height'=>$height,
                   	'p_area'=>$area,
                   	'p_clamp'=>$clamp,
                   	'p_al_thickness'=>$al_thickness,
                   	'p_al_type'=>$al_thickness_type,
                    );

				 $update_id=$this->tm->update_data('products',$data_update,array('pid'=>$prd_id));

				 if($update_id)
				 $status = true;		
		}

		if ($status)
			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		redirect("prd_extra_details_excel", "refresh");
}







function send_mail_checking($main_code,$final_price)
{
	     $this->load->library('email');
        //  $config['protocol'] = "smtp";
         $config['mailpath']     = "/usr/bin/sendmail";
         $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
         $config['smtp_crypto'] = 'tls'; 
         $config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

$page_user= $this->session->userdata['user']['username'];

$page_email=$this->session->userdata['user']['user_email'];

$page_state=$this->session->userdata['user']['state'];

$date_time=get_date_time();


          $this->email->from('noreply@birigroup.com','Biri Group');
       $this->email->to("sales1@birigroup.com");
		  $CI->email->cc(array('support@birigroup.com','sales4@birigroup.com'));

          $this->email->subject('Checking Product New Pricing');
		 $msg="Dear Employee  , <br/> Management Made Change Price of Product ((  ".$main_code."  ))<br/><br/>";

		 
         $msg.="The New Price is :  "  .$final_price."  AED <br/><br/>";

	 $msg.="Changed By:  "  .$page_user."<br/><br/>";
		
		  $msg.="<br/><br/>";
 $msg.="Please Check The Same Price In Focus And Do The Necessary And Check New Price List to make Approve That You made the change <br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}












}