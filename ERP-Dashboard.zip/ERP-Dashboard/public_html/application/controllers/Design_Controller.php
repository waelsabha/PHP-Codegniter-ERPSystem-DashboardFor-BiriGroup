<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Design_Controller extends CI_Controller {

public function __construct() {
		parent::__construct();
	
		//$this->load->helper(array('session','email','img','gnrl','email_survey','text','email_po','mail_img_request'));	
		$this->load->helper(array('session','email','img','gnrl','mail_img_request'));	
		$this->load->model('Third_db_model','tm');

			$this->load->model(array('Second_db_model','Sales_book_model'));
		
		require 'vendor/autoload.php';
		require_once 'vendor/khaled.alshamaa/ar-php/src/Arabic.php';	
	}


function dashboard()
{
         
   $excist=false;
//$Approved_warehouse=strval(7);
//$Pending_warehouse=strval(7);
		if(logged_in())
		{ 
           $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);
  
        for($i=0;$i<$cred_count;$i++)
         {
             if ((($page_cred[$i]=='Designer-priviliges')||($this ->session->userdata['user']['main_dept'])=="Marketing"))
           {  


              	     $excist=true;

             
                 $i=$cred_count;

          }
          else
          {$excist=false;} 	

         }
        if ($excist) {


			
			 $this->send_mail_loguser();  

				$activitylogin_data=array(
				'page_user'=>$this->session->userdata['user']['username'],
				'user_activity'=>'User Logged',
				'page_userip'=>$this->session->userdata['user']['location_ip'],
				'page_pc'=>$this->session->userdata['user']['devicedetailsinfo'],
				'page_country'=>$this->session->userdata['user']['state'],
				'date_time_logged'=>get_date_time(),
			);
			   $this->Admin_model->insert_data('activitieslogin',$activitylogin_data);
         	// code...
////////////coding for sales return pending//////////////////////


///that for checking wich store should i redirect the user


    	$condmain=array('pr_sts'=>'1');

     $order_by=('pr_id');
		$order_type="DESC";
		//$limit='10';
		//$dept=$this->session->userdata['user']['main_dept'];
		
		$data['picture_reports']=$this->Admin_model->get_srproduct_details('picture_report',$condmain,'','',$order_by,$order_type);
	      if(!empty($data['picture_reports']))
     {
			foreach ($data['picture_reports'] as $index=>$val) 
			{
				$prd_id=$val->pr_prd_id;	

		 		//$data['prd_data1'][]=$this->tm->prd_list_var($prd_id);
				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
		$data['new_report']=count($data['picture_reports']);
}else{}



////////////coding for sales return Approving/////////////////////


$condmainapp=array('pr_sts'=>'2');


     $order_by=('pr_id');
		$order_type="DESC";

$data['return_report_approve']=$this->Admin_model->get_srproduct_details('picture_report',$condmainapp,'','',$order_by,$order_type);


if(!empty($data['return_report_approve']))
		{
			foreach ($data['return_report_approve'] as $val) 
			{
				//$prd_id=$val->srt_product;	
		 		//$data['prd_data2'][]=$this->tm->prd_list_var($prd_id);
				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
			// foreach ($data['result2'] as $val) 
			// {
			// 	$prd_id=explode('|#|',$val->po_prd_name);	
			// 	$data['prd_data2'][]=$this->tm->prd_var($prd_id);///getting product details	
			// }
			$data['new_approved_picture_fix']=count($data['return_report_approve']);
		}
		else{}


$this->load->view('admin/design/Design_dashboard',$data);

}
else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}


}
}






function approve_report()
	{
	if(logged_in())
		{
		$pr_id=$this->input->post('pr_id');

		$srt_details=$this->Admin_model->get_data('picture_report',array('pr_id'=>$pr_id));

		
		$dept_name=$this->session->userdata['user']['main_dept'];
		
	$date_fixed=get_date();
		$return_report_approve=array('pr_sts'=>'2','pr_fixed_date'=>$date_fixed);
		

		$mail_data=array(
			'srt_id'=>$srt_id,
		);
		$mail_info=send_po_approved_mail($mail_data);
		
		$mail_info=send_srt_sts_mail($srt_id,'Approved');
		
		print_r($mail_info);

		if($mail_info==1)
	{
			$cond2=array('pr_id'=>$pr_id);
		$this->Admin_model->update_data('picture_report',$return_report_approve,$cond2);

       $this->email->initialize($this->setting());

	    $this->email->from('noreply@birigroup.com','Biri Group');
   
    $picture_report_details=$this->Admin_model->get_data('picture_report',array('pr_id'=>$pr_id));
     $prd_details=$this->tm->get_data('products',array('pid'=> $picture_report_details[0]->pr_prd_id));

     $reported_user= $picture_report_details[0]->pr_user_created;
     $reported_user_details=$this->Admin_model->get_data('login_credentials',array('log_uname'=>$reported_user));
     $reported_user_email=strval($reported_user_details[0]->log_email);
      $this->email->to('support@birigroup.com');
        //$this->email->to($reported_user_email);
        $this->email->subject('fixed picture problem : report #'.$pr_id);
        $msg="Hi,<br/>";
       $msg.='we fixed a problem with product picture  :'.$prd_details[0]->pcode.'<br/>';
        $msg.='product name:<br/>';
     $msg.=$prd_details[0]->pname.'<br/>';
       $msg.='the main problem was :  <br/>';
     $msg.=$picture_report_details[0]->pr_exact_problem.'<br/>';

  $msg.='and other note you sen to us : <br/>';
     $msg.=$picture_report_details[0]->pr_another_note.'<br/>';
    // $msg.='<a href="http://ad.birigroup.ae/reply_ticket/'.$insert_id.'">Click here to reply to this ticket</a> <br/><br/>';
      //  $msg.="<b>NOTE:Please make sure that you will reply to this ticket within 24 hours, else this ticket will be send to Management for further proceedings. </b><br/><br/>";        
         $msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
        $this->email->message($msg);
        //hi_arya();
            // $this->email->message('test');
         if($this->email->send())
         {
			$this->session->set_flashdata('success', 'Mail send successfully to Designer.');
         }
          else
         {
         	$this->session->set_flashdata('errors', 'Failed to send mail to Designer. Please try again later.');
            echo $this->email->print_debugger();
         } 

         $data23['pending']=$this->Admin_model->get_data('picture_report',array('pr_sts'=>'1'));
         $data24['aproved']=$this->Admin_model->get_data('picture_report',array('pr_sts'=>'2'));
		  $this->load->view('admin/design/all_report_pending',$data23);

            $this->load->view('admin/design/all_report_approved',$data24);

		$data_activity=array(
		'act_function'=>'Picture report fixed Approved',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$prd_id,
		'act_status'=>'approved',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$all_done=$this->Admin_model->insert_data('activities',$data_activity);	
        
       $this->session->set_flashdata('success', 'picture send successfully to user.');
        $this->load->view('admin/design/Design_dashboard',$data);
       redirect('admin/design/Design_dashboard','refersh');
		echo true;
		}
		else{
			
			echo false;
		}
		
		}
	}








function change_img_req_sts($sts,$req_id)
{

$sub_dept=explode(',', $this->session->userdata['user']['sub_dept']);
$data_updt=array(
'pr_sts'=>$sts,
);

// print_r('scsdcsdc');
// exit(0);

	$this->Admin_model->update_data('picture_report',$data_updt,array('pr_id'=>$req_id));
$mail_data=mail_img_request($req_id);

$item_details_data=$this->Admin_model->get_data('item_request',array('ir_id'=>$req_id));
				foreach ($item_details_data as $key ) {

					$act_doc_num=$key->ir_req_no;
				}



$sts_value='';
switch($sts)
{
case 2:
$sts_value='Request Solved';
break;


default:
$sts_value='';
break;

}
$data_activity=array(
		'act_function'=>'ImageRequest Changed',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_item_req_id'=>$req_id,
		'act_status'=>$sts_value,
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1',
		
		'act_type_id'=>$req_id,
		'act_type'=>'Image Request'
		);
		$this->Admin_model->insert_data('activities',$data_activity);

if($mail_data==true)
$this->session->set_flashdata('success', 'Image status Successfully updated');
else
$this->session->set_flashdata('errors', 'Error found in sending mail.');

redirect('Designer-dashboard');
}






function send_mail_loguser()
{
	     $this->load->library('email');
         //  $config['protocol'] = "smtp";
         $config['mailpath']     = "/usr/bin/sendmail";
         $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
		 $config['smtp_crypto'] = 'tls'; 
		 $config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

$page_user= $this->session->userdata['user']['username'];
$page_userip=$this->session->userdata['user']['location_ip'];
$page_serverip= $this->session->userdata['user']['server_ip'];
$page_email=$this->session->userdata['user']['user_email'];
$page_pc=$this->session->userdata['user']['computername'];
$page_state=$this->session->userdata['user']['state'];
$page_country=$this->session->userdata['user']['country'];
$page_cityserverprovider=$this->session->userdata['user']['cityserverprovider'];
$page_hostname=$this->session->userdata['user']['hostname'];
$page_lat=$this->session->userdata['user']['user_lat'];
$user_long=$this->session->userdata['user']['user_long'];
  
$user_serverorg=$this->session->userdata['user']['user_serverorg'];
$browsername=$this->session->userdata['user']['browsername'];
$browserversion=$this->session->userdata['user']['browserversion'];
$operatingsystem=$this->session->userdata['user']['operatingsystem'];
$devicedetailsinfo=$this->session->userdata['user']['devicedetailsinfo'];
$date_time=get_date_time();

          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to("support@birigroup.com");
          $this->email->to($page_email);    

          $this->email->subject('Loggedin Activity Happend :');
		 $msg="Dear ".$page_user.", <br/> Your Account Loggedin From Device Below  <br/><br/>";

		 $msg.="You Loggedin From  :  "  .$page_country."<br/><br/>";
		  $msg.="State :  "  .$page_state."<br/><br/>";
		  $msg.="Using IP Adress :  "  .$page_userip."<br/><br/>";
		
		  $msg.="from Device :  "  .$devicedetailsinfo." <br/><br/>";
		    $msg.="Operating System:  "  .$operatingsystem.  "  <br/><br/>";
        $msg.="Browser:  ".$browsername." Version :  " .$browserversion. "  <br/><br/>";
         $msg.="Server Provider :  "  .$user_serverorg."<br/><br/>";

          $msg.="Host Name :  "  .$page_hostname."<br/><br/>";
           $msg.="Latitude :  "  .$page_lat. "<br/><br/>"; 
           $msg.="Longtude :  "  .$user_long. "<br/><br/>";        
        
		  $msg.="Login date  :  "  .$date_time."<br/><br/>";
		
		  $msg.="<br/><br/>";
 $msg.="Thank you!<br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}








}



  
 

