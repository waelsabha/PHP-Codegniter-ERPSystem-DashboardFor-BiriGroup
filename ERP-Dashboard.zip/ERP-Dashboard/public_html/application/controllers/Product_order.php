<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_order extends CI_Controller {

public function __construct() { 
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','email_po'));	
		$this->load->model('Third_db_model','tm');
		$this->load->model('Five_model','fth');
		//$params = array();
 //   $this->load->library('I18N_Arabic', $params);
	}

function prd_order($po_id=null)
{	

	if(logged_in())
	{
  

   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='product-order')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

	$this->lang->load('message', 'ar');
		//$this->lang->load('message', 'english');


$page_branch= $this->session->userdata['user']['sub_dept'];



     
     
		

		if ($page_branch=='ksa') {

			 $warehouseksa="mw_status='1' and mw_parent='8'";

		      $data['delivery_location']=$this->Admin_model->get_data('master_warehouse',$warehouseksa);
		}
		elseif  ($page_branch=='gcc'){
			 $warehouseuae="mw_status='1' and mw_parent='7'";
			$data['delivery_location']=$this->Admin_model->get_data('master_warehouse',$warehouseuae);

		}
		else {
			$warehousemanager="mw_status='1' and mw_parent!='0'";
			$data['delivery_location']=$this->Admin_model->get_data('master_warehouse',$warehousemanager);

		}
		
		$data['class_data']=$this->tm->get_data('category',array('cstatus'=>'1'));
		$data['products']=$this->tm->get_data('products',array('p_sts'=>'1'));

		$cond1=array('log_dept'=>'Sales','log_status'=>'1','log_role'=>'2');
		$data['sales']=$this->Admin_model->get_data('login_credentials',$cond1);
		if(empty($po_id))//////show page for insertion
		{
			$this->load->view('admin/production/production_order',$data);
		}
		else///show page for updation
		{
		$cond2=array('po_id'=>$po_id,'po_sts'=>'1');
		$data['result']=$this->tm->get_data('prd_order',$cond2);

//pre_list($data['result']);
		foreach ($data['result'] as $index=>$val) 
			{

				$prd_id=explode('|#|',$val->po_prd_name);
				foreach($prd_id as $pid)
				{
				$data['prd_data'][]=$this->tm->prd_var_data($pid);
				}
					
			}
			$this->load->view('admin/production/production_order',$data);
		}
}

else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 


 }


}



//////this is function it will be used to synchronize the data with birigroup.ae
/*function make_migrate()
{
    
	$cond1=array('p_sts'=>'1');
	$data=$this->tm->get_data('products',$cond1);
	foreach($data as $d)
	{
	
		$active_name=$d->pname;
		$active_sku=$d->pcode;
		$active_category_name=$d->pcat;
		$uae_lvl2_price=floatval($d->p_uae_l2);
		$Vat_value=floatval($uae_lvl2_price*0.5);
		$active_unit_price=floatval($uae_lvl2_price+$Vat_value);
  	$active_category_name=$d->pcat;
		//$active_category_name=
		$cond5=array('name' =>$active_category_name);
	  $active_category_detals=$this->fth->get_data5('categories',$cond5);
    $active_category_id=$active_category_detals[0]->id;
    // print_r($active_category_detals);
    // print_r($active_category_id);
    // exit(0);

$picturepath='["uploads\/products\/photos\/'.$d->p_prd_img.'"]'; 
//$picturepath = "["uploads\/products\/photos\/".$d->p_prd_img ."]"; 
//["uploads\/products\/photos\/1601721135CBG_8.jpg"]
	$img_path="https://birigroup.com/uploads/prd_images/".$data[0]->pcode.'.jpg';


$Picturethumbnail="uploads/products/photos/".$d->p_prd_img;

	



 
$prod_stock_code=array('ps_prd_code' =>$active_sku);
 $product_stock_details=$this->Admin_model->get_data('product_stock',$prod_stock_code); 


$product_active_qnty=$product_stock_details[0]->ps_dxb_qnty;


//$unit_active=
   
	$active_zone_data=array(
		'name'=>$active_name,
		'added_by'=>'admin',
		'user_id'=>'9',
		'sku'=>$active_sku,
		'category_id'=>$active_category_id,
		'subcategory_id'=>'[]',
		'subsubcategory_id'=>'[]',
		'photos'=>$picturepath,
	    'unit_price'=>$active_unit_price,
		'purchase_price'=>'0.00',
		'current_stock'=>$product_active_qnty,
		'thumbnail_img'=>$Picturethumbnail,
		'slug'=>$active_name,
		'unit'=>'1',

	);

$insert_id=$this->fth->insert_data5('products',$active_zone_data);	

		
	}



$this->load->view('admin/dashboard');

}



*/









function choose_category()
{
	$cat=$this->input->post('category_selected');
	$data_prd=$this->tm->get_data('products',array('pcat'=>$cat,'p_sts'=>'1'));
	echo json_encode($data_prd);
	
}


function search_product()
{
	$search_val=str_replace(' ','',$this->input->post('to_search'));
	$prd_cat=$this->input->post('category_selected');
	$cond1=array('p_sts'=>'1');
	$like=array('pname'=>$search_val);
	$or_like=array('pcode'=>$search_val);
	$data=$this->tm->get_search('products',$cond1,$like,$or_like);

	foreach($data as $d)
	{
		$prd_name=explode('|~~|',$d->pname);
		echo "
		<option value='".$d->pid."'>".$prd_name[0].' '.$prd_name[1].' ::  <br/><br/> '.$d->pcode."</option>";
	}
	
}

function search_product_id()
{
	$search_prd_id=$this->input->post('search_prd_id');
	
	$cond1=array('p_sts'=>'1','pid'=>$search_prd_id);
	$data=$this->tm->get_data('products',$cond1);
	foreach($data as $d)
	{
		//$prd_wgt=$d->po_wgt;
		$var_names=explode('##',$d->p_variation);
		$var_values=explode('##',$d->p_variation_types);
		$new_var_val=array();
			$new_var_names=array();
				foreach($var_names as $key1=>$vn)
				{
					$new_var_names[]=$vn;
					$new_var_val[$vn]=$var_values[$key1];
				}
	}
	$prd_name=explode('|~~|',$data[0]->pname);

	$script_data=array(
		'prd_name_en'=>$prd_name[0],
		'prd_name_ar'=>$prd_name[1],
			'names'=>$new_var_names,
			'values'=>$new_var_val,
			'wgt'=>$data[0]->p_wgt,
			'prd_code'=>$data[0]->pcode
		);
		echo json_encode($script_data);
}

function search_product_id_quot()
{
	$search_prd_id=$this->input->post('search_prd_id');
	
	$cond1=array('p_sts'=>'1','pid'=>$search_prd_id);
	$data=$this->tm->get_data('products',$cond1);
	foreach($data as $d)
	{
		//$prd_wgt=$d->po_wgt;
		$var_names=explode('##',$d->p_variation);
		$var_values=explode('##',$d->p_variation_types);
		$new_var_val=array();
			$new_var_names=array();
				foreach($var_names as $key1=>$vn)
				{
					$new_var_names[]=$vn;
					$new_var_val[$vn]=$var_values[$key1];
				}
	}
	$prd_name=explode('|~~|',$data[0]->pname);
	if(!empty($prd_name[1]))
	$prd_ar_name=$prd_name[1];
	else
	$prd_ar_name='';

	$script_data=array(
		'prd_name_en'=>$prd_name[0],
		'prd_name_ar'=>$prd_ar_name,
		'price'=>$data[0]->p_uae_final,
		'prd_code'=>$data[0]->pcode
			
		);
		echo json_encode($script_data);
}

function search_product_id_survey()
{
	$search_prd_id=$this->input->post('search_prd_id');

	$cond1=array('p_sts'=>'1','pid'=>$search_prd_id);
	$data=$this->tm->get_data('products',$cond1);

				if(empty($data[0]->p_prd_img))
				{
					$filename="https://birigroup.com/uploads/prd_images/".$data[0]->pcode.'.jpeg';
				 if (file_exists($filename)) {
				 	$img_path=$filename;
					} else {
					$img_path="https://birigroup.com/uploads/prd_images/".$data[0]->pcode.'.jpg';
				    }
				}
				 else
				 {
				 	$first_img_prd=explode(',',$data[0]->p_prd_img);
				 	if(!empty($first_img_prd[0]))
				 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
				 	else
				 	$img_path="https://birigroup.com/uploads/prd_images/".$data[0]->p_prd_img;
				 }
	
	$prd_name=explode('|~~|',$data[0]->pname);
	if(!empty($prd_name[1]))
	$prd_ar_name=$prd_name[1];
	else
	$prd_ar_name='';

	$script_data=array(
		'prd_ids'=>$data[0]->pid,
		'prd_name_en'=>$prd_name[0],
		'prd_name_ar'=>$prd_ar_name,
		'price'=>$data[0]->p_uae_final,
		'prd_code'=>$data[0]->pcode,
		'prd_img'=>$img_path,			
		);
		echo json_encode($script_data);
}

function submit_prd_order()
{
if(logged_in())
{
	$order_id=$this->input->post('ordr_id');//for update
	$dlvry_date=$this->input->post('date');

    if(!empty($this->input->post('dlvry_days_expct')))
    {
     // echo "in if";
       $days_remaining=$this->input->post('dlvry_days_expct');
       $date_got = strtotime("+".$days_remaining." day", strtotime($dlvry_date));
     $final_date=date('Y-m-d',$date_got);
    }
  else{
    //echo " in else";
    $final_date=date("Y-m-d", strtotime($dlvry_date));
  }

	$targetfolder='./uploads/production/prod_files/';
  if (isset($_FILES['label_upload']['name']) && $_FILES['label_upload']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'label_upload',
				'upload_path'=>$targetfolder,
			);
			$pic_names=img_upload($img_array1);

			if(!empty($pic_names))
			{
				if(!empty($pic_names[0][0]['file_name']))
				{
					foreach($pic_names[0] as $k1)
					{
						$pp_aray[]=$k1['file_name'];
						$value_pp_aray=implode(',',$pp_aray);
					}
				}
			}
			else
			{
				if(!empty($this->input->post('wp_images')))
				{
					$value_pp_aray=$this->input->post('wp_images');
				}
				else
				{
					$value_pp_aray='';
				}
			}	
		}	
	
		if($this ->session->userdata['user']['sub_dept']=="ksa")
		{
		$approve_ksa='1';
		$user_country='ksa';	
		}
		else
		{
		$approve_ksa='0';
		$user_country='uae';
		}
		
		$edited_user_details=$this->input->post('edit_user_created');
		if(!empty($edited_user_details))
		$user_sessin_name=$edited_user_details;
		else
		$user_sessin_name=$this->session->userdata['user']['username'];
		
	$converted_date_delivry = date("Y-m-d", strtotime($dlvry_date));
	$data=array(
		'po_user_id'=>$user_sessin_name,
		'po_sales_person'=>$user_sessin_name,
		'po_date_delivry'=>$converted_date_delivry,
		'po_final_delivery_date'=>$final_date,
	    	'po_dlvry_days'=>$this->input->post('dlvry_days_expct'),
		'po_delivery_loc'=>$this->input->post('dlvry_loc'),
		'po_dept'=>implode(',',$this->input->post('dept')),
		'po_prd_name'=>$this->input->post('prdids'),
		'po_qnty'=>$this->input->post('qntys'),
		'po_wgt'=>$this->input->post('wgts'),
		'po_pck_type'=>$this->input->post('pck_types'),
		'po_spcl_rq'=>$this->input->post('spcl_rqts'),
		'po_specl_customer_req'=>$this->input->post('specl_customer_req'),
		'po_rmks'=>$this->input->post('remark'),
		'po_variations'=>$this->input->post('variation_selected_val'),	
		'po_files'=>$value_pp_aray,	
		'po_approve_ksa'=>$approve_ksa,
		'po_user_country'=>$user_country,
	);
$department=$this->input->post('dept');

		if(in_array("Traffic Sign", $department))
		$sts_sign="1";
    	else
    	$sts_sign="";
    	
		if(in_array("Main factory", $department))
		$sts_fact="1";
    	else
    	$sts_fact="";

	if(empty($order_id))
	{
		$insert_id=$this->tm->insert_data('prd_order',$data);	
		
		$data_activity=array(
		'act_function'=>'order created',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$insert_id,
		'act_status'=>'ordered',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);	

		if($insert_id)
		{
			$data2=array
			(
			'po_order_status_adv'=>$sts_sign,
			'po_order_status_fact'=>$sts_fact,
			'po_sts'=>"1"
			);
			$cond2=array('po_id'=>$insert_id);
		$this->tm->update_data('prd_order',$data2,$cond2);

		$dept_selected=$this->input->post('dept');
		$for_mail_data=$this->tm->get_dept($dept_selected);
		
		if($approve_ksa=='0')
		{
		//echo "in iif 1";
			foreach($for_mail_data as $md)
			{
					$mail_data=array(
					'username'=>$md->log_uname,
					'user_mail'=>$md->log_email,
					'department'=>$md->log_dept,
					'order_number'=>$insert_id,
					'order_from'=>$this->input->post('sales_person'),
				);
					send_user_mail($mail_data);
			}
		}
		else
		{
		//echo "in else 1";
		send_approve_mail($insert_id);
		}
				
			$product_order['order_id']=array(
			'po_id'=>$insert_id,
			);
			$this->session->set_userdata($product_order);

			$this->session->set_flashdata('success','Details entered successfully');
			redirect('product_order_status','refresh');
		}
			
	}
	else
	{
		
		 $cond2=array('po_id'=>$order_id);
		$this->tm->update_data('prd_order',$data,$cond2);	
		
		$data_activity=array(
		'act_function'=>'order details edited',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$order_id,
		'act_status'=>'details edited',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);	
		
		if($order_id)
		{			
			$data2=array
			(
			'po_order_status_adv'=>$sts_sign,
			'po_order_status_fact'=>$sts_fact,
			'po_sts'=>"1"
			);
			$cond2=array('po_id'=>$order_id);
		$this->tm->update_data('prd_order',$data2,$cond2);

		$dept_selected=$this->input->post('dept');
		$for_mail_data=$this->tm->get_dept($dept_selected);
		
			if($this->input->post('approve_ksa')=='0')
			{
				foreach($for_mail_data as $md)
				{
						$mail_data=array(
						'username'=>$md->log_uname,
						'user_mail'=>$md->log_email,
						'department'=>$md->log_dept,
						'order_number'=>$order_id,
						'order_from'=>$this->input->post('sales_person'),
					);
						send_user_mail($mail_data,'edited');
				}
				//echo "in iif 2";
			}
			else
			{
			//echo "in else 2";
			send_approve_mail($order_id);
			}		
		
		}
		
		$this->session->set_flashdata('success','Details edited successfully');
		redirect('prd-order-list','refresh');	
	}
 }			
}

function approve_po_ksa($po_id)
{
$this->tm->update_data('prd_order',array('po_approve_ksa'=>'0'),array('po_id'=>$po_id));
$this->session->set_flashdata('success','PO approved and send for production.');
		redirect('prd-order-list','refresh');	
}

function prd_list()
{
if(logged_in())
		{
		if($this->session->userdata['user']['main_dept']=="Main" || $this->session->userdata['user']['user_desig']=="Team-lead" )
		{
			if($this->session->userdata['user']['user_desig']=="Team-lead")
			{
				if($this ->session->userdata['user']['sub_dept']=="ksa")
				{
				$cond1=array('po_sts'=>"1",'po_user_country'=>'ksa');
				}
				else
				{
				$cond1=array('po_sts'=>"1",'po_user_country'=>'uae');
				}
			}
			else
			{
			$cond1=array('po_sts'=>"1");
			}
		}
		
		else
		{
		////$cond1=array('po_sts'=>"1",'po_user_id'=>$this->session->userdata['user']['username'],'po_order_status_fact !='=>"5",'po_order_status_adv !='=>"5");
		$cond1=array('po_sts'=>"1",'po_user_id'=>$this->session->userdata['user']['username']);
		}
	

	$order_by=('po_id');
	$order_type="DESC";
$data['result']=$this->tm->get_po_details('prd_order',$cond1,'','',$order_by,$order_type);
	foreach ($data['result'] as $index1=>$val) 
	{
		 $prd_id=explode('|#|',$val->po_prd_name);	
		 $data['prd_data'][]=$this->tm->prd_list_var($prd_id);
		 //$data['prd_data'][]=$this->tm->prd_var_data($prd_id);///getting product details	
	}
$this->load->view('admin/production/prd_order_list',$data);
   }
}


function po_sts()
{
	if(logged_in())
		{
	if (!empty($this->session->userdata('order_id'))) 
	{
		$prd_id=$this->session->userdata['order_id']['po_id'];
		$cond=array('po_id'=>$prd_id);
		$data['result']=$this->tm->get_data('prd_order',$cond);
		foreach ($data['result'] as $val) 
		{
			$prd_id=explode('|#|',$val->po_prd_name);
			foreach($prd_id as $pid)
			{
			$data['prd_data'][]=$this->tm->prd_var_data($pid);
			}

			//$prd_id=explode('|#|',$val->po_prd_name);	
			// $data['prd_data'][]=$this->tm->prd_var($prd_id);///getting product details	
		}
		$this->load->view('admin/production/po_sts',$data);
	}
	else
	{
		$data['result']='';
$this->load->view('admin/production/po_sts',$data);
	}
  }
}

function delete_prd_ordr($id)
{
	if(logged_in())
		{
	$data2=array('po_sts'=>"0");
	 $cond2=array('po_id'=>$id);
	  
	 send_po_delete($id);
	 
		$this->tm->update_data('prd_order',$data2,$cond2);
		$this->session->set_flashdata('success','Details deleted successfully');
		redirect('prd-order-list','refresh');
	}	
}


function po_sts_sales()
{


	if(logged_in())
 {
 	$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='prd-order-sts')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


	$this->load->view('admin/production/po_sts_sales');
}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	  	} 
}

}


function submit_check_po_sts()
{
if(logged_in())
	{  print_r($this ->session->userdata['user']['main_dept']);exit(0);
		$dept_name=$this->input->post('type_name');
		
		// $cond1=array('po_sts'=>"1",'po_sales_person'=>$this->session->userdata['user']['username']);
		if( (($this ->session->userdata['user']['role'])=="2")  )
		{
			if((($this ->session->userdata['user']['main_dept'])=="Sales")|| (($this ->session->userdata['user']['main_dept'])=="Traffic Sign") ||  (($this ->session->userdata['user']['main_dept'])=="Main factory") )
			  
			  {
				
		    	$cond1=array('po_sts'=>"1",'po_sales_person'=>$this->session->userdata['user']['username']);	
			  }
		}
		else
		{
			$cond1=array('po_sts'=>"1");	
		}
		
		$order_by=('po_id');
		$order_type="DESC";
		$data['result']=$this->tm->get_po_details('prd_order',$cond1,'','',$order_by,$order_type,$dept_name);
		
		$this->load->view('admin/production/po_sts_sales',$data);
	}
}

function filter_type()
{
	if(logged_in())
	{
	$dept_name=$this->input->post('type_name');	
	// $cond1=array('po_sts'=>"1",'po_sales_person'=>$this->session->userdata['user']['username']);
	if( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Sales") )
	{ 
		if($this ->session->userdata['user']['sub_dept']=="ksa")
		{
		$cond1=array('po_sts'=>"1",'po_user_country'=>'ksa');
		}
		else
		{
		$cond1=array('po_sts'=>"1",'po_sales_person'=>$this->session->userdata['user']['username']);
		}	
	}
	elseif( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Project Department") )
	{
		
		         $cond1=array('po_sts'=>"1",'po_sales_person'=>$this->session->userdata['user']['username']);
		
	}
	// //for the futeure this for the factory department to see all the orders
	elseif( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Main factory") )
	{
		
		         $cond1=array('po_sts'=>"1",'po_dept'=>"Main factory");
		
	}
		elseif( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Traffic Sign") )
	{
		
		         $cond1=array('po_sts'=>"1",'po_dept'=>"Traffic Sign");
		
	}
	else
	{
		$cond1=array('po_sts'=>"1");	
	}
	
	$order_by=('po_id');
	$order_type="DESC";
	$data['result']=$this->tm->get_po_details('prd_order',$cond1,'','',$order_by,$order_type,$dept_name);
	
	//pre_list($data['result']);
	$html= "<table class='table table-bordered table-striped mb-none' id='datatable-default2'>
	 <thead>
        <tr>
         <th></th>
           <th>Order Number</th>
            <th>Sales Person</th>
			<th>Delivery date</th>
			<th>Date Extended till</th>
			<th>Delivery location</th>
			<th>Department</th>
			<th>Item Details </th>			
			<th>Order status</th>
			
        </tr>
    </thead>
    <tbody>";
		$ij=1;
	foreach($data['result'] as $index=>$val) 
		{
			$qnty=explode('|#|',$val->po_qnty);
			$wgt=explode('|#|',$val->po_wgt);
//pre_list($val);
			$html.="<tr>";
			if($dept_name=="Main factory")
			{
				if($val->po_order_partial_status_fact=='' || $val->po_order_partial_status_fact==null)
				{
					$prd_sts_dept=$val->po_order_status_fact;
				}
				else
				{
					if($val->po_order_partial_status_fact=='1')
					$prd_sts_dept='11';	
					elseif($val->po_order_partial_status_fact=='2')
					$prd_sts_dept='12';	
					elseif($val->po_order_partial_status_fact=='3')
					$prd_sts_dept='13';		
					elseif($val->po_order_partial_status_fact=='4')
					$prd_sts_dept='14';		
					else
					$prd_sts_dept='';	
				}
			}
			else
			{
				if($val->po_order_partial_status_adv=='' || $val->po_order_partial_status_adv==null)
				{
					$prd_sts_dept=$val->po_order_status_adv;
				}
				else
				{
					if($val->po_order_partial_status_adv=='1')
					$prd_sts_dept='11';	
					elseif($val->po_order_partial_status_adv=='2')
					$prd_sts_dept='12';	
					elseif($val->po_order_partial_status_adv=='3')
					$prd_sts_dept='13';		
					elseif($val->po_order_partial_status_adv=='4')
					$prd_sts_dept='14';		
					else
					$prd_sts_dept='';			
				}
			}

			$display_sts;
			switch($prd_sts_dept)
			{
				case 1:
				$display_sts="Pending";
				break;
				case 2:
				$display_sts="Accepted";
				break;
				case 3:
				$display_sts="On production";
				break;
				case 4:
				$display_sts="Ready for delivery";
				break;
				case 5:
				$display_sts="Delivered";
				break;
				case 11:
				$display_sts="Partially Pending";
				break;
				case 12:
				$display_sts="Partially Accepted";
				break;
				case 13:
				$display_sts="Partially On-production";
				break;
				case 14:
				$display_sts="Partially Ready for delivery";
				break;
				default:
				$display_sts="Rejected";
				break;
			}
		
			$html.="<td>".$ij++."</td>";
			$html.="<td>#".$val->po_id."</td>";
			$html.="<td>".$val->po_sales_person."</td>";
			
			$html.="<td>".$val->po_date_delivry."</td>";
			$html.="<td>";
			if(empty($val->po_dlvry_days))
				{
					$extnded_day="0";}
			else
				{
					$extnded_day=$val->po_dlvry_days;}
			$html.=$extnded_day." days</td>";

			
			$html.="<td>".$val->po_delivery_loc."</td>";
			$html.="<td>".$dept_name."</td>";

			$qnty=explode('|#|',$val->po_qnty);
			$wgt=explode('|#|',$val->po_wgt);

			if(!empty($val->approved_qnty))
				$approved_qnty=explode(',',$val->approved_qnty);

			if(!empty($val->remaining_qnty))	
				$remaining_qnty=explode(',',$val->remaining_qnty);

			$prd_id=explode('|#|',$val->po_prd_name);
			$data['prd_data']=$this->tm->prd_list_var($prd_id);
			$html.="<td>
				<table class='table'>
				<thead>
				<th>Product Code</th>
				<th>Quantity </th>
				<th> Approved Quantity</th>
				<th>Remaining Quantity</th>
				<th>Weight </th>
				</thead>
				<tbody>";
			foreach($data['prd_data'] as $prd_index=>$p)
			{
				$html.="<tr>";
				$prd_name_db=explode('|~~|',$p['pname']);
            	$prod_code=$p['pcode'];
            	$html.="<td>";

           if(empty($prod_code))
             $html.=$prd_name_db[0].'<br/>'.$prd_name_db[1];
              else
             $html.=$prod_code;	
				$html.="</td>";

				if(!empty($qnty[$prd_index]))	
				$html.="<td>".$qnty[$prd_index]."</td>";
				else
					$html.="<td>0</td>";

				if(!empty($val->approved_qnty))
				$html.="<td>".$approved_qnty[$prd_index]."</td>";
				else
					$html.="<td>0</td>";

				if(!empty($val->remaining_qnty))
				$html.="<td>".$remaining_qnty[$prd_index]."</td>";
				else
					$html.="<td>0</td>";

				if(!empty($wgt[$prd_index]))
				$html.="<td>".$wgt[$prd_index]."</td>";
				else
				$html.="<td>0</td>";

				$html.="</tr>";
			}
			$html.="	</tbody>
				</table>
			</td>";					

			$html.="<td>".$display_sts."</td>";
			///getting product details	
			$html.="</tr>";			
		}
		$html.="</tbody></table>";
		
		echo $html;
	}

}



function po_history($po_id)
{
$data['result']=$this->Admin_model->get_data('activities',array('act_po_id'=>$po_id));
//print_r($data['result']);
$this->load->view('admin/production/history',$data);
}



function generate_prd_order($po_id)
{

//$quot_id=$this->input->post('quotation_id');

 $quotation_data= $this->tm->get_data('prd_order',array('po_id'=>$po_id,'po_sts'=>'1'));  
         
$prd_details=explode('|#|',$quotation_data[0]->po_prd_name);
$po_qnty=explode('|#|',$quotation_data[0]-> po_qnty);
$po_wgt=explode('|#|',$quotation_data[0]-> po_wgt);
$pck_type=explode('|#|',$quotation_data[0]-> po_pck_type);
$spcl_rq=explode('|#|',$quotation_data[0]-> po_spcl_rq);
$remarks=explode('|#|',$quotation_data[0]-> po_rmks);

foreach($prd_details as $index=>$pd)
{
	//print_r($pd);
	
	$prd_table_data[]=$this->tm->get_data('products',array('pid'=>$pd));
	
}

$logged_users_details=$this->Admin_model->join_qry('login_credentials','employee_details','ed_login_id','log_id',array('log_uname'=>$this->session->userdata['user']['username']),('employee_details.*,login_credentials.*'));

//print_r($prd_table_data);
//print_r($logged_users_details);

$stylesheet = file_get_contents('style_mpdf.css');

	$html='<!doctype html>
<head>
          
</head>

    <body> ';
	  
	 
				$html.='
				<div class="content">
				<table border="0" width="100%">
				<tr >
					<td align="left" rowspan="3"><h1 style="text-align:left">Production Order</h1></td>
					
					<td style="text-align:right;" align="right">
						<div style="text-align:right;">
							<p align="right" style="text-align:justify;">Issued by: '.$quotation_data[0]->po_sales_person.'</p>
						
							
							<p align="right" style="text-align:justify;">Production Order No: #'.$quotation_data[0]-> po_id.'</p>
							
							
						</div>
					</td>
				</tr>
				
				
				</table>
				
				
				
				</div>';

			
				$html.='<table align="center" class="cusotmer_info"  width="80%" border="1">';
				
				$html.='
				<tr>
					<td>Expected Delivery Date: '.$quotation_data[0]->po_date_delivry.'</td>
					<td>Final Delivery Date: '.$quotation_data[0]->po_final_delivery_date.'</td>
				</tr>
				<tr>
					<td>Department: '.$quotation_data[0]-> po_dept.'</td>
					<td>Delivery Location: '.$quotation_data[0]-> po_delivery_loc.'</td>
				</tr>
				';
				$dept_delivery=explode(',',$quotation_data[0]-> po_dept);
				foreach($dept_delivery as $dd)
				{
				if($dd=="Main factory")
				{
					$value_status_fact;
					switch($quotation_data[0]->po_order_status_fact)
					{
						case '1':
						$value_status_fact="Order Pending";
						break;
						case '2':
						$value_status_fact="Order Approved";
						break;
						case '3':
						$value_status_fact="Order On-Production";
						break;
						case '4':
						$value_status_fact="Delivery Ready";
						break;
						case '5':
						$value_status_fact="Delivered";
						break;
						case '0':
						$value_status_fact="Order Rejected";
						break;
						default:
						$value_status_fact="";
						break;
					}
				$html.='<tr><td colspan="2">Current Status from Main factory: '.$value_status_fact.'</td></tr>
					';
				}
				elseif($dd=="Traffic Sign")
				{
				$value_status_adv;
					switch($quotation_data[0]->po_order_status_adv)
					{
						case '1':
						$value_status_adv="Order Pending";
						break;
						case '2':
						$value_status_adv="Order Approved";
						break;
						case '3':
						$value_status_adv="Order On-Production";
						break;
						case '4':
						$value_status_adv="Delivery Ready";
						break;
						case '5':
						$value_status_adv="Delivered";
						break;
						case '0':
						$value_status_adv="Order Rejected";
						break;
						default:
						$value_status_adv="";
						break;
					}
				$html.='<tr><td colspan="2">Current Status from Advertising: '.$value_status_adv.'</td></tr>
					';
				}
				else{}
					
				}
				
							
				
				$html.='</table>


				<table align="center" class="prd_info"  width="80%" border="1">
					<tr class="prd_head" >
					 <td align="center">No.#</td>
					 <td align="center">Picture</td>
					 <td align="center">Model No.</td>
					 <td align="center">Product Description</td>
					 <td align="center" width="10%">Qty</td>
					 <td align="center">Weight</td>
					 <td align="center">Package Type</td>
					  <td align="center">Special request</td>
					   <td align="center">Remarks</td>
					</tr>';
$i=1;

					foreach($prd_table_data as $index=>$pd3)
					{
						
						if(empty($pd3[0]->p_prd_img))
						{
							$filename="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpeg";
						 if (file_exists($filename)) {
						 	$img_path=$filename;
							} else {
							$img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpg";
						    }
						}
						else
						{
							$first_img_prd=explode(',',$pd3[0]->p_prd_img);
							if(!empty($first_img_prd[0]))
						 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
						 	
						 	else
						 	$img_path="https://birigroup.com/uploads/prd_images/".$pd3[0]->p_prd_img."";
						 	
						}
						
						//print_r($img_path);
						$pname=explode('|~~|',$pd3[0]->pname);
						if(!empty($pname[0]))
						{
							$prd_names=explode(',',$pname[0]);
							$product_name=$prd_names[0];
							//$product_name=$pname[0];
						}
						else
						{
						 	$pname=explode(',',$pd3[0]->pname);
						 	$product_name=$pname[0];
						}
						//$product_name=$pname;
						


					$html.='<tr style="text-align:center;">
					 <td align="center">'.$i++.'</td>';

					 if(!empty($img_path))
					 $html.='<td align="center"><img src="'.$img_path.'" width="100" height="100"></td>';
					else
						 $html.='<td align="center">'.$product_name.'</td>';

					 $html.='<td align="center">'.$pd3[0]->pcode.'</td>';
					 
					 $html.='<td>'.$product_name.'</td>';
					
						
					
					  $html.='<td align="center">'.$po_qnty[$index].'</td>
					 <td align="center">'.$po_wgt[$index].'</td>
					 <td align="center">'.$pck_type[$index].'</td>
					 <td align="center">'.$spcl_rq[$index].'</td>
					  <td align="center">'.$remarks[$index].'</td>
					</tr>';
				}
				
					
				$html.='</table>';

if(!empty($quotation_data[0]->po_specl_customer_req))
{
				$html.='
		
				<div style="padding-left:2%;">
<p>Special Customer Request :  '.$quotation_data[0]->po_specl_customer_req.' </p></div>';
}
//$files_attached=array();
if(!empty($quotation_data[0]-> po_files))
{
$files_attached=explode(',',$quotation_data[0]-> po_files);

foreach($files_attached as $fa)
{

$file_parts = pathinfo($fa);

if( ($file_parts['extension']=="jpg") || ($file_parts['extension']=="png") || ($file_parts['extension']=="jpeg"))
{
$html.='<div style="padding-left:2%;"><p>Attached files : <br/> ';
		$html.='<img src="'.base_url('uploads/production/prod_files/').$fa.'" width="250" height="100"><br/>';
		$html.='</p></div>';
	}

}

}

			$html.='</body>
					</html>';

					//echo $html;
//$header_image=base_url('admin_assets/header_pdf.png');
 $pdfFilePath = 'po-id'.$quotation_data[0]-> po_id.'.pdf';
	  
		 $this->load->library('m2_pdf');
		 $this->m2_pdf->pdf->SetHeader('<img src="'.base_url("berry_header.png").'">');
		  $this->m2_pdf->pdf->SetFooter('<img src="'.base_url("berry_footer.png").'">');
		  
		    	//$this->m2_pdf->autoScriptToLang = true;
			//$this->m2_pdf->autoLangToFont = true;
		 // $this->m2_pdf->pdf->autoArabic=true;
		  $this->m2_pdf->pdf->WriteHTML($stylesheet,1);
		  $this->m2_pdf->pdf->AddPage('', // L - landscape, P - portrait 
        '', '', '', '',
        5, // margin_left
        5, // margin right
       35, // margin top
       20, // margin bottom
        0, // margin header
        0); // margin footer
        
          //$this->m2_pdf->pdf->SetDirectionality('rtl');
         //    $this->m2_pdf->pdf->autoScriptToLang = true;
         // $this->m2_pdf->pdf->autoLangToFont   = true;
           //$this->m2_pdf->pdf->autoArabic=true;
            
            
	     $this->m2_pdf->pdf->WriteHTML($html,2);
	     
	     //save in folder
		$this->m2_pdf->pdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");

  		$this->m2_pdf->pdf->Output($pdfFilePath,'D');
  		
  		//echo $html;
}


function remove_prod_index()
{
	$po_id_update=$this->input->post('po_id_table');
	$prd_index=$this->input->post('prod_index');

	$po_values=$this->tm->get_data('prd_order',array('po_id'=>$po_id_update));

	print_r($po_values);

	$po_prd_ids=explode('|#|', $po_values[0]->po_prd_name);
	$po_prd_qnty=explode('|#|', $po_values[0]->po_qnty);
	$po_prd_wgt=explode('|#|', $po_values[0]->po_wgt);
	$po_prd_spcl_req=explode('|#|', $po_values[0]->po_spcl_rq);
	$po_prd_rmks=explode('|#|', $po_values[0]->po_rmks);
	$po_prd_pckg_type=explode('|#|', $po_values[0]->po_pck_type);
	$po_prd_new_qnty=explode('|#|', $po_values[0]->new_qnty);
	$po_prd_remaining_qnty=explode('|#|', $po_values[0]->remaining_qnty);
	$po_prd_approved_qnty=explode('|#|', $po_values[0]->approved_qnty);


	// unset($foo[0]); // remove item at index 0
	// $foo2 = array_values($foo); // 'reindex' array

		unset($po_prd_ids[$prd_index]); // remove item at index 0
		$new_prd_id_set = array_values($po_prd_ids); // 'reindex' array
		$to_update_prd_id_set=implode('|#|', $new_prd_id_set);

	if(!empty($po_prd_qnty))
	{
		unset($po_prd_qnty[$prd_index]); // remove item at index 0
		$new_prd_qnty_set = array_values($po_prd_qnty); // 'reindex' array
		$to_update_prd_qnty_set=implode('|#|', $new_prd_qnty_set);
	}
	else
	{
		$to_update_prd_qnty_set='';
	}	

	if(!empty($po_prd_wgt))
	{
		unset($po_prd_wgt[$prd_index]); // remove item at index 0
		$new_prd_wgt_set = array_values($po_prd_wgt); // 'reindex' array
		$to_update_prd_wgt_set=implode('|#|', $new_prd_wgt_set);
	}
	else
	{
		$to_update_prd_wgt_set='';
	}

	if(!empty($po_prd_spcl_req))
	{	
		unset($po_prd_spcl_req[$prd_index]); // remove item at index 0
		$new_prd_spcl_req_set = array_values($po_prd_spcl_req); // 'reindex' array
		$to_update_prd_spcl_req_set=implode('|#|', $new_prd_spcl_req_set);
	}
	else
	{
		$to_update_prd_spcl_req_set='';
	}

	if(!empty($po_prd_rmks))
	{
		unset($po_prd_rmks[$prd_index]); // remove item at index 0
		$new_prd_rmks_set = array_values($po_prd_rmks); // 'reindex' array
		$to_update_prd_rmks_set=implode('|#|', $new_prd_rmks_set);
	}
	else
	{
		$to_update_prd_rmks_set='';
	}

	if(!empty($po_prd_pckg_type))
	{
		unset($po_prd_pckg_type[$prd_index]); // remove item at index 0
		$new_prd_pck_type_set = array_values($po_prd_pckg_type); // 'reindex' array
		$to_update_prd_pckg_type_set=implode('|#|', $new_prd_pck_type_set);
	}
	else
	{
		$to_update_prd_pckg_type_set='';
	}

	if(!empty($po_prd_new_qnty))
	{
		unset($po_prd_new_qnty[$prd_index]); // remove item at index 0
		$new_prd_new_qnty_sets = array_values($po_prd_new_qnty); // 'reindex' array
		$to_update_prd_new_qnty_set=implode(',', $new_prd_new_qnty_sets);
	}
	else
	{
		$to_update_prd_new_qnty_set='';
	}


	if(!empty($po_prd_remaining_qnty))
	{
		unset($po_prd_remaining_qnty[$prd_index]); // remove item at index 0
		$new_prd_remaining_qnty_sets = array_values($po_prd_remaining_qnty); // 'reindex' array
		$to_update_prd_remaining_qnty_set=implode(',', $new_prd_remaining_qnty_sets);
	}
	else
	{
		$to_update_prd_remaining_qnty_set='';
	}

	
	if(!empty($po_prd_approved_qnty))
	{
		unset($po_prd_approved_qnty[$prd_index]); // remove item at index 0
		$new_prd_approved_qnty_sets= array_values($po_prd_approved_qnty); // 'reindex' array
		$to_update_prd_approved_qnty_set=implode(',', $new_prd_approved_qnty_sets);
	}
	else
	{
		$to_update_prd_approved_qnty_set='';
	}

	$data=array(
		'po_prd_name'=>$to_update_prd_id_set,
		'po_qnty'=>$to_update_prd_qnty_set,
		'po_wgt'=>$to_update_prd_wgt_set,
		'po_spcl_rq'=>$to_update_prd_spcl_req_set,
		'po_rmks'=>$to_update_prd_rmks_set,
		'po_pck_type'=>$to_update_prd_pckg_type_set,
		'new_qnty'=>$to_update_prd_new_qnty_set,
		'remaining_qnty'=>$to_update_prd_remaining_qnty_set,
		'approved_qnty'=>$to_update_prd_approved_qnty_set,		
	);
	$this->tm->update_data('prd_order',$data,array('po_id'=>$po_id_update));

	echo 1;
	

}














}