<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts_tree extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->model(array('Account_model'));
		$this->load->helper(array('session','gnrl'));	
	}
	
function accounts_head()
{
$data['result']=$this->Admin_model->get_data('account_tree_root',array('root_sts'=>'1'));
	$this->load->view('admin/accounts/accounts_head',$data);
}

function list_acc_head()
{
$data['result']=$this->Admin_model->get_data('account_tree_root',array('root_sts'=>'1'));
$this->load->view('admin/accounts/list_acc_head',$data);
}

function edit_head($table_name,$edit_id)
{
	$data['result']=$this->Admin_model->get_data('account_tree_root',array('root_sts'=>'1'));
	$data['edit_table']=$table_name;
	
	if($table_name=="root")
	{
		$data['edit_result']=$this->Admin_model->get_data('account_tree_root',array('root_id'=>$edit_id,'root_sts'=>'1'));	
	}
	elseif($table_name=="parent")	
	{
		$data['edit_result']=$this->Admin_model->get_data('account_tree_parent',array('par_id'=>$edit_id,'par_sts'=>'1'));
	}
	elseif($table_name=="child")
	{
		$data['edit_result']=$this->Admin_model->get_data('account_tree_child',array('ch_id'=>$edit_id,'ch_sts'=>'1'));
	}
	elseif($table_name=="sib")
	{
		$data['edit_result']=$this->Admin_model->get_data('account_tree_sibling',array('sib_id'=>$edit_id,'sib_sts'=>'1'));
	}
	elseif($table_name=="sib2")
	{
		$data['edit_result']=$this->Admin_model->get_data('account_tree_sibling2',array('sib_id'=>$edit_id,'sib_sts'=>'1'));
	}
	elseif($table_name=="sib3")
	{
		$data['edit_result']=$this->Admin_model->get_data('account_tree_sibling3',array('sib_id'=>$edit_id,'sib_sts'=>'1'));
	}
	elseif($table_name=="sib4")
	{
		$data['edit_result']=$this->Admin_model->get_data('account_tree_sibling4',array('sib_id'=>$edit_id,'sib_sts'=>'1'));
	}	
	else
	{
		$data['edit_result']=$this->Admin_model->get_data('account_tree_sibling5',array('sib_id'=>$edit_id,'sib_sts'=>'1'));
	}

	
	$this->load->view('admin/accounts/accounts_head',$data);
}

function submit_ac_head()
{
	$id_edit=$this->input->post('edit_id');

	if(empty($id_edit))
	$this->form_validation->set_rules('under_ac','Under A/C', 'trim|required');
	$this->form_validation->set_rules('opng_bal','Opening balance','trim|required');
	$this->form_validation->set_rules('ac_name','A/C Name','trim|required');
	$this->form_validation->set_rules('acc_code','A/C Code','trim|required');
	$this->form_validation->set_rules('memo','Memo','trim|required');
	if ($this->form_validation->run() == FALSE)
     {

	if(empty($id_edit))
     	$this->session->set_flashdata('under_ac', form_error('under_ac'));
     	$this->session->set_flashdata('opng_bal', form_error('opng_bal'));
     	$this->session->set_flashdata('ac_name', form_error('ac_name'));
     	 $this->session->set_flashdata('acc_code', form_error('acc_code'));
     	$this->session->set_flashdata('memo', form_error('memo'));
     redirect('accounts-head','refresh');
     }
    else
     {     	
     	if($this->input->post('under_ac')=="0")///root account
     	{
     	$data=array(
	     		'root_bal'=>$this->input->post('opng_bal'),
	     		'root_name'=>$this->input->post('ac_name'),
	     		'root_code'=>$this->input->post('acc_code'),
	     		'root_memo'=>$this->input->post('memo'),
	     		'root_sts'=>"1",
	     	);
	     	$insert_id=$this->Admin_model->insert_data('account_tree_root',$data);
		 $this->session->set_flashdata('success', 'Data successfully inserted');
	       redirect('accounts-head');
     	}
     	else
     	{  

     		
     	///for updation  	
	     	$root_val=$this->input->post('root_val');	
	     	$parent_val=$this->input->post('parent_val');
	     	$child_val=$this->input->post('child_val');
	     	$sib_1=$this->input->post('sib_1');
	     	$sib_2=$this->input->post('sib_2');
	     	$sib_3=$this->input->post('sib_3');
			$sib_4=$this->input->post('sib_4');
	     	$sib_5=$this->input->post('sib_5');
	     	
	     if(empty($id_edit))
	     {	
	     	if(!empty($root_val) && !empty($parent_val) && !empty($child_val) && !empty($sib_1) && !empty($sib_2) && !empty($sib_3) && !empty($sib_4))
	     	 {
	     		$explode_val1=explode(':',$root_val);
	     		if(!empty($parent_val))
	     		$explode_val2=explode(':',$parent_val);
	     		$explode_val3=explode(':',$child_val);
	     		$explode_val4=explode(':',$sib_1);///sib_1
	     		$explode_val5=explode(':',$sib_2);
	     		$explode_val6=explode(':',$sib_3);
	     		$explode_val7=explode(':',$sib_4);
	     		
	     		$data2=array(
	     		'sib_root'=>$explode_val1[1],
	     		'sib_parnt'=>$explode_val2[1],
	     		'sib_child'=>$explode_val3[1],
	     		'sib_1'=>$explode_val4[1],
	     		'sib_2'=>$explode_val5[1],
	     		'sib_3'=>$explode_val6[1],
	     		'sib_4'=>$explode_val7[1],
	     		'sib_5'=>$this->input->post('ac_name'),
	     		'sib_opening_bal'=>$this->input->post('opng_bal'),
	     		'sib_memo'=>$this->input->post('memo'),
	     		'sib_code'=>$this->input->post('acc_code'),
	     		'sib_sts'=>"1",   			
	     		);
// print_r($data2);
	     		$insert_id=$this->Admin_model->insert_data('account_tree_sibling',$data2);

	     		$this->session->set_flashdata('success', 'Data successfully inserted');
	      		redirect('accounts-head');
	     	}
	     	elseif(!empty($root_val) && !empty($parent_val) && !empty($child_val) && !empty($sib_1) && !empty($sib_2) && !empty($sib_3))
	     	{
	     		$explode_val1=explode(':',$root_val);
	     		if(!empty($parent_val))
	     		$explode_val2=explode(':',$parent_val);
	     		$explode_val3=explode(':',$child_val);
	     		$explode_val4=explode(':',$sib_1);///sib_1

	     		$explode_val5=explode(':',$sib_2);
	     		$explode_val6=explode(':',$sib_3);
	     		
	     		$data2=array(
	     			'sib_root'=>$explode_val1[1],
	     		'sib_parnt'=>$explode_val2[1],
	     		'sib_child'=>$explode_val3[1],
	     		'sib_1'=>$explode_val4[1],
	     		'sib_2'=>$explode_val5[1],
	     		'sib_3'=>$explode_val6[1],
	     		'sib_4'=>$this->input->post('ac_name'),
	     		'sib_opening_bal'=>$this->input->post('opng_bal'),
	     		'sib_memo'=>$this->input->post('memo'),
	     		'sib_code'=>$this->input->post('acc_code'),
	     		'sib_sts'=>"1",   			
	     		);
// print_r($data2);
	     		$insert_id=$this->Admin_model->insert_data('account_tree_sibling',$data2);

	     		$this->session->set_flashdata('success', 'Data successfully inserted');
	      		redirect('accounts-head');
	     	}
	     	elseif(!empty($root_val) && !empty($parent_val) && !empty($child_val) && !empty($sib_1) && !empty($sib_2) )
	     	{
	     		$explode_val1=explode(':',$root_val);
	     		if(!empty($parent_val))
	     		$explode_val2=explode(':',$parent_val);
	     		$explode_val3=explode(':',$child_val);
	     		$explode_val4=explode(':',$sib_1);///sib_1
	     		$explode_val5=explode(':',$sib_2);
	     		
	     		$data2=array(
	     			'sib_root'=>$explode_val1[1],
	     		'sib_parnt'=>$explode_val2[1],
	     		'sib_child'=>$explode_val3[1],
	     		'sib_1'=>$explode_val4[1],
	     		'sib_2'=>$explode_val5[1],
	     		'sib_3'=>$this->input->post('ac_name'),
	     			'sib_opening_bal'=>$this->input->post('opng_bal'),
	     		'sib_memo'=>$this->input->post('memo'),
	     		'sib_code'=>$this->input->post('acc_code'),
	     		'sib_sts'=>"1",   			
	     		);
// print_r($data2);
	     		$insert_id=$this->Admin_model->insert_data('account_tree_sibling3',$data2);

	     		$this->session->set_flashdata('success', 'Data successfully inserted');
	      		redirect('accounts-head');	
	     	}
	     	elseif(!empty($root_val) && !empty($parent_val) && !empty($child_val) && !empty($sib_1) )
	     	{
	     		$explode_val1=explode(':',$root_val);
	     		if(!empty($parent_val))
	     		$explode_val2=explode(':',$parent_val);
	     		$explode_val3=explode(':',$child_val);
	     		$explode_val4=explode(':',$sib_1);///sib_1
	     		
	     		$data2=array(
	     			'sib_root'=>$explode_val1[1],
	     		'sib_parnt'=>$explode_val2[1],
	     		'sib_child'=>$explode_val3[1],
	     		'sib_1'=>$explode_val4[1],
	     		'sib_2'=>$this->input->post('ac_name'),
	     		'sib_opening_bal'=>$this->input->post('opng_bal'),
	     		'sib_memo'=>$this->input->post('memo'),
	     		'sib_code'=>$this->input->post('acc_code'),
	     		'sib_sts'=>"1",   			
	     		);
 //print_r($data2);
	     		$insert_id=$this->Admin_model->insert_data('account_tree_sibling2',$data2);

	     		$this->session->set_flashdata('success', 'Data successfully inserted');
	      		redirect('accounts-head');
	     	}
	     	
	     	elseif(!empty($root_val) && !empty($parent_val) && !empty($child_val))
	     	{

	     		$explode_val1=explode(':',$root_val);
	     		if(!empty($parent_val))
	     		$explode_val2=explode(':',$parent_val);
	     		$explode_val3=explode(':',$child_val);

	     		$data2=array(
	     		'sib_root'=>$explode_val1[1],
	     		'sib_parnt'=>$explode_val2[1],
	     		'sib_child'=>$explode_val3[1],
	     		'sib_1'=>$this->input->post('ac_name'),
	     		'sib_opening_bal'=>$this->input->post('opng_bal'),
	     		'sib_code'=>$this->input->post('acc_code'),
	     		'sib_memo'=>$this->input->post('memo'),
	     		'sib_sts'=>"1",
	     		);
//print_r($data2);
	     		$insert_id=$this->Admin_model->insert_data('account_tree_sibling',$data2);

	     		$this->session->set_flashdata('success', 'Data successfully inserted');
	      		redirect('accounts-head');
	     	}
	     	elseif(!empty($root_val) && !empty($parent_val))
	     	{
	     		$explode_val1=explode(':',$root_val);
	     		if(!empty($parent_val))
	     		$explode_val2=explode(':',$parent_val);
	     		$data2=array(
	     		'ch_root'=>$explode_val1[1],
	     		'ch_imd_parnt'=>$explode_val2[1],
	     		'ch_name'=>$this->input->post('ac_name'),
	     		'ch_opening_bal'=>$this->input->post('opng_bal'),
	     		'ch_memo'=>$this->input->post('memo'),
	     		'ch_code'=>$this->input->post('acc_code'),
	     		'ch_sts'=>"1",
	     		);
	     		//print_r($data2);
	     		$insert_id=$this->Admin_model->insert_data('account_tree_child',$data2);

	     		$this->session->set_flashdata('success', 'Data successfully inserted');
	      		redirect('accounts-head');
	     	}
	     	else
	     	{
	     		$explode_val1=explode(':',$root_val);
	     		$data2=array(
	     		'par_root'=>$explode_val1[1],
	     		'par_name'=>$this->input->post('ac_name'),
	     		'par_opening_bal'=>$this->input->post('opng_bal'),
	     		'par_memo'=>$this->input->post('memo'),
	     	'par_ac_code'=>$this->input->post('acc_code'),
	     		'par_sts'=>"1",
	     		);
	     		//print_r($data2);
	     		$insert_id=$this->Admin_model->insert_data('account_tree_parent',$data2);

	     		$this->session->set_flashdata('success', 'Data successfully inserted');
	      		redirect('accounts-head');
	     	}

	     }
	     else////update here
	     {
	     	$table_name=$this->input->post('edit_table');
	     	
	     	if($table_name=="parent")	
			{
				$data_updt=array(
				'par_name'=>$this->input->post('ac_name'),
					'par_opening_bal'=>$this->input->post('opng_bal'),
					'par_ac_code'=>$this->input->post('acc_code'),
					'par_memo'=>$this->input->post('memo'),
				);
				$data['edit_result']=$this->Admin_model->update_data('account_tree_parent',$data_updt,array('par_id'=>$id_edit,'par_sts'=>'1'));
			}
			elseif($table_name=="child")
			{
				$data_updt=array(
					'ch_name'=>$this->input->post('ac_name'),
					'ch_opening_bal'=>$this->input->post('opng_bal'),
				'ch_code'=>$this->input->post('acc_code'),
					'ch_memo'=>$this->input->post('memo'),
				);
				$data['edit_result']=$this->Admin_model->update_data('account_tree_child',$data_updt,array('ch_id'=>$id_edit,'ch_sts'=>'1'));
			}
			elseif($table_name=="sib")
			{
				$data_updt=array(
					'sib_1'=>$this->input->post('ac_name'),
					'sib_opening_bal'=>$this->input->post('opng_bal'),
				'sib_code'=>$this->input->post('acc_code'),
					'sib_memo'=>$this->input->post('memo'),
				);
				$data['edit_result']=$this->Admin_model->update_data('account_tree_sibling',$data_updt,array('sib_id'=>$id_edit,'sib_sts'=>'1'));
			}
			elseif($table_name=="sib2")
			{
				$data_updt=array(
					'sib_2'=>$this->input->post('ac_name'),
					'sib_opening_bal'=>$this->input->post('opng_bal'),
				'sib_code'=>$this->input->post('acc_code'),
					'sib_memo'=>$this->input->post('memo'),
				);
				$data['edit_result']=$this->Admin_model->update_data('account_tree_sibling2',$data_updt,array('sib_id'=>$id_edit,'sib_sts'=>'1'));
			}
			elseif($table_name=="sib3")
			{
				$data_updt=array(
					'sib_3'=>$this->input->post('ac_name'),
					'sib_opening_bal'=>$this->input->post('opng_bal'),
				'sib_code'=>$this->input->post('acc_code'),
					'sib_memo'=>$this->input->post('memo'),
				);
				$data['edit_result']=$this->Admin_model->update_data('account_tree_sibling3',$data_updt,array('sib_id'=>$id_edit,'sib_sts'=>'1'));
			}
			elseif($table_name=="sib4")
			{
				$data_updt=array(
					'sib_4'=>$this->input->post('ac_name'),
					'sib_opening_bal'=>$this->input->post('opng_bal'),
				'sib_code'=>$this->input->post('acc_code'),
					'sib_memo'=>$this->input->post('memo'),
				);
				$data['edit_result']=$this->Admin_model->update_data('account_tree_sibling4',$data_updt,array('sib_id'=>$id_edit,'sib_sts'=>'1'));
			}	
			else
			{
				$data_updt=array(
					'sib_5'=>$this->input->post('ac_name'),
					'sib_opening_bal'=>$this->input->post('opng_bal'),
				'sib_code'=>$this->input->post('acc_code'),
					'sib_memo'=>$this->input->post('memo'),
				);
				$data['edit_result']=$this->Admin_model->update_data('account_tree_sibling5',$data_updt,array('sib_id'=>$id_edit,'sib_sts'=>'1'));
			}
				$this->session->set_flashdata('success', 'Data successfully updated');
	      		redirect('list-account-head');
	     }

	     	    		
     	}

     }
}
















}