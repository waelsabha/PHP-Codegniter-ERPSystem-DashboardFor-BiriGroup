<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gulf_trading extends CI_Controller {

  public function __construct() {
    parent::__construct();
    $this->load->helper(array('session','email','img','gnrl','email_survey'));  
    $this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
	
    $this->load->library('numbertowordconvertsconver');     
  }

function create_form($vid=null)
{
   // echo "inside the firk";
  if(logged_in())
  {



 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
      $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
          if ((($page_cred[$i]=='gulf-trading-visitors')||($this ->session->userdata['user']['main_dept'])=="Main"))
          {
            $excist=true;
               $i=$cred_count;
          } 

            else
              {$excist=false;}

         }
       if ($excist) {

    $data['country']=$this->Admin_model->get_data('country_val',array('status'=>'1')); 
    if(!empty($vid))
    {
      $data['result']=$this->Admin_model->get_data('gulf_trading_visitors',array('vi_id'=>$vid));
    $data['country_data']=$this->Admin_model->get_data('country_val',array('country_id'=>$data['result'][0]->vi_country));
    }
  $this->load->view('admin/gulf_trading_form',$data);

    }
else{
      //echo false;
       $this->session->unset_userdata('user', null);
            redirect('login','refersh');
            } 
  }
}


function list_form()
{
  if(logged_in())
  {


     $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
      $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
          if ((($page_cred[$i]=='gulf-trading-visitors-list')||($this ->session->userdata['user']['main_dept'])=="Main"))
          {
            $excist=true;
               $i=$cred_count;
          } 

            else
              {$excist=false;}

         }
       if ($excist) {
  $data['result']=$this->Admin_model->get_data('gulf_trading_visitors',array('vi_sts'=>'1'));
  $this->load->view('admin/gulf_trading_list',$data);

     }
else{
      //echo false;
       $this->session->unset_userdata('user', null);
            redirect('login','refersh');
            } 
  }
}

function submit_form()
{
  
  $edit_id=$this->input->post('edit_vi_id');
  $data=array(
    'vi_comp'=>$this->input->post('vi_comp'),
    'vi_cont_person'=>$this->input->post('vi_cont_person'),
    'vi_cont_num'=>$this->input->post('vi_cont_num'),
    'vi_cont_email'=>$this->input->post('vi_cont_email'),
    'vi_comp_type'=>$this->input->post('vi_comp_type'),
    'vi_adrs'=>$this->input->post('vi_adrs'),
    'vi_note'=>$this->input->post('vi_note'),
    'vi_country'=>$this->input->post('vi_country'),
    'vi_alt_cont'=>$this->input->post('vi_alt_cont'),  
    //'vi_country_code'=>$this->input->post('vi_country_code'),
    'vi_sts'=>'1',
    'vi_dt_updt'=>get_date_time(),
  );

 
  //pre_list($data);
  if(empty($edit_id))
   $insert_id=$this->Admin_model->insert_data('gulf_trading_visitors',$data);
  else
  {
    $this->Admin_model->update_data('gulf_trading_visitors',$data,array('vi_id'=>$edit_id));
      $this->session->set_flashdata('success', 'Data Successfully edited');
  }
   if($insert_id)
   {
     $this->Admin_model->update_data('gulf_trading_visitors',array('vi_dt_crtd'=>get_date_time()),array('vi_id'=>$insert_id)); 
     if(!empty($this->input->post('vi_cont_email')))
     $this->send_email($insert_id);
    // if(!empty($this->input->post('vi_cont_num')))
   // $this->send_sms($insert_id);
    $this->session->set_flashdata('success', 'Data Successfully inserted');
   }
   redirect('gulf-trading-visitors');
}

function send_sms($id)
{//print_r('x');exit();

// use SMSGlobal\Credentials;
// use SMSGlobal\Resource\Sms;
    $data=$this->Admin_model->get_data('gulf_trading_visitors',array('vi_id'=>$id));
  
  try{
        
      $to = $data[0]->vi_cont_num;
      $to = '971'.$to;
         

// $apikey='ca6a43d093ec4977a8877945e51a0a4e';

// $LocationArray []= json_decode( file_get_contents('https://api.smsglobal.com/v2/sms/'.$testip.'?key='.$apikey));

  

  
 











$textmessage = 'test';
$sender = 'Birigroup'; // Need to change
$to = '123456789'; // Replace with the actual recipient number
$smsGatewayUrl = 'https://api.smsglobal.com';
$apikey = '79c68028f9b2161f443ca809154a140e'; // Need to change

$textmessage = urlencode($textmessage);
$api_element = '/v2/sms/';
$api_params = $api_element . '?apikey=' . $apikey . '&sender=' . $sender . '&to=' . $to . '&message=' . $textmessage;
$smsgatewaydata = $smsGatewayUrl . $api_params;

$ch = curl_init();
curl_setopt($ch, CURLOPT_POST, false);
curl_setopt($ch, CURLOPT_URL, $smsgatewaydata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$output = curl_exec($ch);
curl_close($ch);

if (!$output) {
    $output = file_get_contents($smsgatewaydata);
}

if ($output) {
    echo "SMS sent successfully!";
    print_r('successfully');exit();
} else {
    echo "Failed to send SMS. Check logs for details.";
     print_r('faild');exit();
}

print_r($output);exit();






  


    //  \SMSGlobal\Credentials::set('0c63eac2729a0021aa65c67b2c358402', '4b7e80f420ff355a16b9fd8a13749366');
       \SMSGlobal\Credentials::set('79c68028f9b2161f443ca809154a140e', 'afab1c579d9468f79f8fa6ad68e07112');
  print_r($data);exit();

     //  Credentials::set('79c68028f9b2161f443ca809154a140e', 'afab1c579d9468f79f8fa6ad68e07112');
     // $send_message = new \SMSGlobal\Resource\Sms();

        


      
      $start_msg = 'Thank you for being a part of Biri Group at Big 5 Exhibition. Lets keep in touch in future. STOP 1672';
      $foot = '';
      
      $text = $start_msg;

        $sms = new Sms();
            $sms->setDestination($to)->setMessage($text)->send();
            return true;
         

    //   $send = $send_message->sendToOne($to,$text,'AD-BERRY');
    //   print_r($send);exit();
    //   return true;
  }
  catch (\Exception $e)
  {
      return 'false';
  }
}

function send_email($id)
{

  $data=$this->Admin_model->get_data('gulf_trading_visitors',array('vi_id'=>$id));
  $html='
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:v="urn:schemas-microsoft-com:vml"><head><!--[if gte mso 9]><xml><o:OfficeDocumentSettings><o:AllowPNG/><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml><![endif]-->
  <meta content="width=device-width" name="viewport">
  <style>
  /* #### Mobile Phones Portrait #### */
  /* #### iPhone 4+ Portrait or Landscape #### */
  @media only screen and (max-width: 480px){
    table[class=contentInner] {width:100% !important;padding:0px;margin:0px;}
    img[class=zpImage]{width:260px !important;max-width: 360px !important;text-align:center;margin:0px;padding:0px} 
    body, table, td, p, a, li,div,span, blockquote{-webkit-text-size-adjust:none !important;margin:0px auto;line-height:1.7}
    table[class=zpImageCaption]{text-align:left;}
    table[class=cols]{width:100% !important;max-width:100% !important;text-align:left;}
    table[class=zpcolumns] {text-align:left;margin:0px;} 
    table[class=zpcolumn] {text-align:left;margin:0px;} 
    table[class=zpAlignPos]{width:100%;text-align:left;margin:0px;} 
    td[class=txtsize]{font-size:18px !important;}
    td[class=paddingcomp]{padding-left:15px !important;padding-right: 15px !important;}
    td[class=bannerimgpad]{padding:0px !important;}
    span[class=txtsize]{font-size:18px !important;}
    img[size = "B"]{width: 100% !important;max-width:100% !important;margin: 0px !important;padding:0px !important;}
    img[size = "F"]{width: 100% !important;max-width:100% !important;margin: 0px !important;padding:0px !important;}
    img[size = "S"]{width:105px !important; height:auto; margin:0px auto !important;padding:0px !important;}
    img[size = "M"]{width:277.869px !important;height:auto;margin:0px auto !important;padding:0px !important;}
    h1{
      font-size:28px !important;
      line-height:100% !important;
    }
    h2{
      font-size:24px !important;
      line-height:100% !important;
    }
    h3{
      font-size:20px !important;
      line-height:100% !important;
    }
    h4{
      font-size:18px !important;
      line-height:100% !important;
    }
    }   
    @media only screen and (max-width: 480px){
    .zpImage{
      height:auto !important;
      width:100% !important;
    }}
    @media only screen and (max-width: 480px){
    .contentInner,.cols,.zpAlignPos{
      width:100% !important;
      max-width:100% !important;
    }}
    @media only screen and (max-width: 480px){
    .paddingcomp{
      padding-left:15px !important;
      padding-right:15px !important;
    }
    .bannerimgpad{
      padding:0px !important;
    }
  }
    @media screen and (max-width: 480px)
        {
                .tmplheader,.tmplfooter{width:100% !important;max-width:400px !important;margin:0px auto;text-align:center;}
        }
    a[x-apple-data-detectors] {
        color: inherit !important;
        text-decoration: none !important;
        font-size: inherit !important;
        font-family: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
    }
    
    </style>
<meta content="text/html;charset=UTF-8" http-equiv="Content-Type"></head><body bgcolor="#f2f2f2" style="margin:0; padding:0;font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000;"><center> 
<div class="zppage-container">                                                          
    <table bgcolor="#f2f2f2" border="0" cellpadding="0" cellspacing="0" class="contentOuter" id="contentOuter" style="background-color:#f0f0f0;background-color:#f2f2f2;font-size:12px;text-align:center;border:0px;padding:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" width="100%"> 
      <tbody><tr> 
        <td style="border:0px;padding:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">&nbsp;</td>
        <td align="center" style="border:0px;padding:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
          <table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="contentInner" id="contentInner" style="border-collapse:collapse; border:0px;font-size:12px;background-color:#ffffff;background-color:#ffffff;width:700px;margin:0px auto;border:0px;" width="700"> 
          <tbody><tr> 
          <td height="570" style="border:0px;padding:0px;" valign="top">
            <a name="Top" style="text-decoration:underline;"></a>
    <div baseposition="pos_YrobDQg7SAqnBt5RUo4dhQ" class="zpcontent-wrapper" id="page-container">
    <table border="0" cellpadding="0" cellspacing="0" id="page-container" style="font-size:12px;border:0px;padding:0px;border-collapse:collapse; mso-table-lspace:0pt;mso-table-rspace:0pt;text-decoration:none !important;" width="100%">
<tbody><tr><td class="txtsize" id="elm_1517302800753" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">


            <div class="zpelement-wrapper spacebar" id="elm_1517302800753" style=";word-wrap:break-word;overflow:hidden;background-color:transparent;">
          
           <table bgcolor="transparent" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt;font-size:5px; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;height:48px;" width="100%">

                          <tbody><tr><td style="padding:0px;border:0px;font-size:5px;height:48px;border-top:none none none;border-bottom:none none none;">

                          &nbsp;&nbsp;&nbsp;

                          </td></tr>

                  </tbody></table>

            </div>

</td></tr>
<tr><td class="txtsize" id="elm_1618571386407" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

        <table bgcolor="transparent" border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border:0px;padding:0px;width:100%;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;background-color:transparent;">
      <tbody><tr>
    <td class="txtsize" style="border:0px;padding:0px 0px;border-top:none none none ;border-bottom:none none none;">
              <div class="zpelement-wrapper image" coupcmp id="elm_1618571386407" prodcmp style=";word-wrap:break-word;overflow:hidden;padding:0px;background-color:transparent;">
      <div>
            <table align="center" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="font-size:12px;text-align:left;padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;width:100%;text-align:center;">
                <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;text-align:center;padding-top:7px;padding-bottom:7px;padding-right:15px;padding-left:15px;">
      <img align="center" alt="https://campaign-image.com/zohocampaigns/133052000002841333_zc_v51_1618572969361_logo_c.png" class="zpImage" height="auto" hspace="0" size="O" src="https://campaign-image.com/zohocampaigns/896644000000416006_zc_v1_1638794281069_biri_group_logo_01_(1).png" style="width:204px;height:autopx;max-width:204px !important;border:0px;text-align:center;" vspace="0" width="204">
      </td></tr>
      <tr><td class="txtsize" style="border:0px;padding:0px;text-align:left;margin:0px auto;" width="204">
                <div class="zpImageCaption" style="text-align:center;margin:0px auto;padding:0px;"></div>
      </td></tr></tbody></table>
    </div>
            </div>
            </td></tr></tbody></table>
</td></tr>
<tr><td class="txtsize" id="elm_1618571475966" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

            <div class="zpelement-wrapper spacebar" id="elm_1618571475966" style=";word-wrap:break-word;overflow:hidden;background-color:transparent;">
          
           <table bgcolor="transparent" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt;font-size:5px; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;height:7px;" width="100%">

                          <tbody><tr><td style="padding:0px;border:0px;font-size:5px;height:7px;border-top:none none none;border-bottom:none none none;">

                          &nbsp;&nbsp;&nbsp;

                          </td></tr>

                  </tbody></table>

            </div>

</td></tr>
<tr><td class="txtsize" id="elm_1511809019314" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

          <div class="zpelement-wrapper" id="elm_1511809019314" style=";word-wrap:break-word;overflow:hidden;padding-right:0px;background-color:;">
        <table border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="font-size:12px;padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;" width="100%">
      
            <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;line-height:19pt;border-top:0px none ;   border-bottom:0px none ;padding-top:11px;padding-bottom:1px;padding-right:7px;padding-left:7px;">
                      <div componentpaddingbottom="1px" componentpaddingleft="7px" componentpaddingright="7px" componentpaddingtop="11px" style><p align="center" style="line-height:1.7;font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;text-align: center; line-height: 35pt;"><b style><font color="#181818" face="Arial, Helvetica" style="line-height: 35pt; font-size: 35pt;">Thank You For Visiting!</font></b></p></div>
      </td></tr>
    </tbody></table>
          </div>
</td></tr>
<tr><td class="txtsize" id="elm_1566202288283" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

            <div class="zpelement-wrapper spacebar" id="elm_1566202288283" style=";word-wrap:break-word;overflow:hidden;background-color:transparent;">
          
           <table bgcolor="transparent" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt;font-size:5px; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;height:33px;" width="100%">

                          <tbody><tr><td style="padding:0px;border:0px;font-size:5px;height:33px;border-top:none none none;border-bottom:none none none;">

                          &nbsp;&nbsp;&nbsp;

                          </td></tr>

                  </tbody></table>

            </div>

</td></tr>
<tr><td class="txtsize" id="elm_1511809706440" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

          <div class="zpelement-wrapper" id="elm_1511809706440" style=";word-wrap:break-word;overflow:hidden;padding-right:0px;background-color:;">
        <table border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="font-size:12px;padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;" width="100%">
      
            <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;line-height:19pt;border-top:0px none ;   border-bottom:0px none ;padding-top:7px;padding-bottom:7px;padding-right:7px;padding-left:7px;">
                      <div componentpaddingbottom="7px" componentpaddingleft="7px" componentpaddingright="7px" componentpaddingtop="7px" style><p align="center" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: 9pt; text-align: center;"><span style="line-height: 9pt;"><font style="line-height: 9pt;"><font style="line-height: 9pt;"><font style="line-height: 9pt;">
                      <font color="#333333" face="Georgia, Times New Roman, Times, serif" style="line-height: 9pt; font-size: 12pt;">Dear <b>'.$data[0]->vi_cont_person.'</b></font></font></font></font></span><br></p></div>
      </td></tr>
    </tbody></table>
          </div>
</td></tr>
<tr><td class="txtsize" id="elm_1615280930788" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

            <div class="zpelement-wrapper spacebar" id="elm_1615280930788" style=";word-wrap:break-word;overflow:hidden;background-color:transparent;">
          
           <table bgcolor="transparent" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt;font-size:5px; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;height:5px;" width="100%">

                          <tbody><tr><td style="padding:0px;border:0px;font-size:5px;height:5px;border-top:none none none;border-bottom:none none none;">

                          &nbsp;&nbsp;&nbsp;

                          </td></tr>

                  </tbody></table>

            </div>

</td></tr>
<tr><td class="txtsize" id="elm_1517298016490" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

          <div class="zpelement-wrapper" id="elm_1517298016490" style=";word-wrap:break-word;overflow:hidden;padding-right:0px;background-color:;">
        <table border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="font-size:12px;padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;" width="100%">
      
            <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;line-height:19pt;border-top:0px none ;   border-bottom:0px none ;padding-top:11px;padding-bottom:21px;padding-right:111px;padding-left:111px;">
                      <div componentpaddingbottom="21px" componentpaddingleft="111px" componentpaddingright="111px" componentpaddingtop="11px" style><p align="center" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: 19pt; text-align: center;"><span style="line-height: 19pt;"><font style="line-height: 19pt;"><font style="line-height: 19pt;"><font style="line-height: 19pt;"><font color="#333333" face="Georgia, Times New Roman, Times, serif" style="line-height: 19pt;"><i style><font style="font-size: 15pt;"><span><span>Thank you for visiting us and spending time with us at Big 5 .</span>

</span></font>

</i></font></font></font></font></span><br></p></div>
      </td></tr>
    </tbody></table>
          </div>
</td></tr>
<tr><td class="txtsize" id="elm_1566202365031" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

        <table bgcolor="transparent" border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border:0px;padding:0px;width:100%;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;background-color:transparent;">
      <tbody><tr>
    <td class="txtsize" style="border:0px;padding:0px 0px;border-top:none none none ;border-bottom:none none none;">
              <div class="zpelement-wrapper image" coupcmp id="elm_1566202365031" prodcmp style=";word-wrap:break-word;overflow:hidden;padding:0px;background-color:transparent;">
      <div>
            <table align="left" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="font-size:12px;text-align:left;width:100%;padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;width:100%;text-align:left;">
                <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;text-align:center;padding-top:7px;padding-bottom:7px;padding-right:15px;padding-left:15px;">
      <img align="left" alt="https://campaign-image.com/zohocampaigns/133052000002019328_zc_v15_type2_simple_welcome_image.png" class="zpImage" height="auto" hspace="0" size="F" src="https://www.birigroup.com/temp_styles/assets/img/website_img/big_5.jpg" style="width:670px;height:autopx;max-width:670px !important;border:0px;text-align:left;" vspace="0" width="670">
      </td></tr>
      <tr><td class="txtsize" style="border:0px;padding:0px;text-align:left;margin:0px auto;" width="670">
                <div class="zpImageCaption" style="text-align:center;margin:0px auto;padding:0px;"></div>
      </td></tr></tbody></table>
    </div>
            </div>
            </td></tr></tbody></table>
</td></tr>
<tr><td class="txtsize" id="elm_1638794438655" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

          <div class="zpelement-wrapper" id="elm_1638794438655" style=";word-wrap:break-word;overflow:hidden;padding-right:0px;background-color:;">
        <table border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="font-size:12px;padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;" width="100%">
      
            <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;line-height:19pt;border-top:0px none ;   border-bottom:0px none ;padding-top:7px;padding-bottom:7px;padding-right:15px;padding-left:15px;">
                      <div style><p align="center" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: 25pt; text-align: center;"><font style="font-size: 15pt;">

Looking forward to hearing from you&nbsp;in the near future.</font></p></div>
      </td></tr>
    </tbody></table>
          </div>
</td></tr>
<tr><td class="txtsize" id="elm_1638794697475" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

          <div class="zpelement-wrapper" id="elm_1638794697475" style=";word-wrap:break-word;overflow:hidden;padding-right:0px;background-color:;">
        <table border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="font-size:12px;padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;" width="100%">
      
            <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;line-height:19pt;border-top:0px none ;   border-bottom:0px none ;padding-top:7px;padding-bottom:7px;padding-right:15px;padding-left:15px;">
                      <div style><p align="center" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: 19pt; text-align: center;"><font color="#333333" face="Arial, Helvetica" style="color:#333333;font-size: 12pt;"><span>

<span>You can download our products catalogue from below link.</span>

</span></font></p></div>
      </td></tr>
    </tbody></table>
          </div>
</td></tr>
<tr><td class="txtsize" id="elm_1638794509708" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

  <table bgcolor="transparent" cellpadding="0" cellspacing="0" height="48" style="font-size:12px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;border:none;" width="100%">
        <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;border-top:none none none;border-bottom:none none none;padding-top:7px;padding-bottom:7px;padding-right:15px;padding-left:15px;">
        <div class="zpelement-wrapper buttonElem" id="elm_1638794509708" style="overflow:hidden;word-wrap:break-word;">
      <div class="zpAlignPos" style="text-align:center;">
                <table align="center" cellpadding="0" cellspacing="0" style="font-size:12px;border:none;padding:0px;border:0px;margin:0px auto;border-collapse:separate; mso-table-lspace:0pt; mso-table-rspace:0pt;">
                <tbody><tr>
                   <td align="center" class="txtsize" style="border:0px;padding:0px;color:#ffffff;font-family:Arial;font-weight:bold;text-align:center;border-radius:10px;text-align:center;cursor:pointer;">
                         <!--[if mso]>
                    <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href=" https://www.birigroup.com/temp_styles/assets/img/biri_catalogue_2024_2025.pdf" style="border-radius:10px;height:50px;v-text-anchor:middle;width:129px" arcsize="10%" strokecolor="#ffffff" strokeweight ="0px" fillcolor="#fe0713">
                    <v:stroke dashstyle="solid" />
                      <w:anchorlock/>
                      <center style="color:#ffffff;font-family:Arial;font-size:12pt;font-weight:bold;">OUR Product Catalogue</center>
                    </v:roundrect>
                <![endif]-->
                        <a align="center" href="https://www.birigroup.com/temp_styles/assets/img/biri_catalogue_2024_2025.pdf" style="padding:0px 0px;background-color:#fe0713;width:129px;line-height:40px;font-size:12pt;font-family:Arial;color:#ffffff;cursor:pointer;text-decoration:none;border-radius:10px;border:0px solid #ffffff;display:inline-block;mso-hide:all;text-align:center;" target="_blank">
              <span style="color:#ffffff;line-height:40px">
                         OUR Product Catalogue
              </span>
                        </a>
                    </td>

                     <td align="center" class="txtsize" style="border:0px;padding:0px;color:#ffffff;font-family:Arial;font-weight:bold;text-align:center;border-radius:10px;text-align:center;cursor:pointer;">
                         <!--[if mso]>
                    <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href=" https://www.birigroup.com/temp_styles/assets/img/Biri_Hoses.pdf" style="border-radius:10px;height:50px;v-text-anchor:middle;width:129px" arcsize="10%" strokecolor="#ffffff" strokeweight ="0px" fillcolor="#38fe07">
                    <v:stroke dashstyle="solid" />
                      <w:anchorlock/>
                      <center style="color:#ffffff;font-family:Arial;font-size:12pt;font-weight:bold;">Hoses Catalouge</center>
                    </v:roundrect>
                <![endif]-->
                        <a align="center" href="https://www.birigroup.com/temp_styles/assets/img/Biri_Hoses.pdf" style="padding:0px 0px;background-color:#38fe07;width:129px;line-height:40px;font-size:12pt;font-family:Arial;color:#ffffff;cursor:pointer;text-decoration:none;border-radius:10px;border:0px solid #ffffff;display:inline-block;mso-hide:all;text-align:center;" target="_blank">
              <span style="color:#ffffff;line-height:40px">
                           Hoses Catalouge
              </span>
                        </a>
                    </td>





                </tr>
                </tbody></table>
            </div>
  </div>
  </td></tr></tbody></table>
</td></tr>
<tr><td class="txtsize" id="elm_1638796370268" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

          <div class="zpelement-wrapper" id="elm_1638796370268" style=";word-wrap:break-word;overflow:hidden;padding-right:0px;background-color:;">
        <table border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="font-size:12px;padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;" width="100%">
      
            <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;line-height:19pt;border-top:0px none ;   border-bottom:0px none ;padding-top:7px;padding-bottom:7px;padding-right:15px;padding-left:15px;">
                      <div style><p align="center" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: 25pt; text-align: center;"><span><b><font style="font-size: 15pt;">Contact Us&nbsp;</font></b></span></p><p align="center" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: 25pt; text-align: center;"><font style="font-size: 15pt;"><b>&nbsp;</b>Call us:   

+971-42281142</font><br></p><p align="center" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: 25pt; text-align: center;"><font style="font-size: 15pt;">Email: sales@birigroup.com</font></p></div>
      </td></tr>
    </tbody></table>
          </div>
</td></tr>
<tr><td class="txtsize" id="elm_1565961963645" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">


            <div class="zpelement-wrapper spacebar" id="elm_1565961963645" style=";word-wrap:break-word;overflow:hidden;background-color:transparent;">
          
           <table bgcolor="transparent" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt;font-size:5px; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;height:80px;" width="100%">

                          <tbody><tr><td style="padding:0px;border:0px;font-size:5px;height:80px;border-top:0px none #ffffff;border-bottom:0px none #ffffff;">

                          &nbsp;&nbsp;&nbsp;

                          </td></tr>

                  </tbody></table>

            </div>

</td></tr>
<tr><td class="txtsize" id="elm_1566195619518" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">


            <div class="zpelement-wrapper spacebar" id="elm_1566195619518" style=";word-wrap:break-word;overflow:hidden;background-color:#eff7f9;">
          
           <table bgcolor="#eff7f9" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt;font-size:5px; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;height:20px;" width="100%">

                          <tbody><tr><td style="padding:0px;border:0px;font-size:5px;height:20px;border-top:1px solid #cccccc;border-bottom:0px none #cccccc;">

                          &nbsp;&nbsp;&nbsp;

                          </td></tr>

                  </tbody></table>

            </div>

</td></tr>
<tr><td class="txtsize" id="elm_1568296862626" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">

  <div class="zpelement-wrapper zpcol-layout" id="elm_1568296862626" style="word-wrap:break-word;padding-bottom:0 !important;overflow:hidden;padding:0px;margin:0px;">
  <div class="zpcolumns" elm_wid_start="700" style="padding:0px;margin:0px;">
         <table bgcolor="#eff7f9" cellpadding="0" cellspacing="0" style="font-size:12px;border:0px;padding:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;width:100%;background-color:#eff7f9;" width="100%">
      <tbody><tr>
    <td class="txtsize" style="border:0px;padding:0px 0px;border-top:0px none #ffffff;border-bottom:0px none #ffffff;" valign="top">
              <!--[if (gte mso 9)|(IE)]>
                  <table cellpadding="0" cellspacing="0" style=" mso-table-lspace:0pt; mso-table-rspace:0pt;font-size:12px;border:0px;padding:0px;border-collapse:collapse; mso-table-lspace:0pt;width:100%; mso-table-rspace:0pt;" width="100%">
            <tbody><tr>
              <![endif]-->
      
            <!--[if (gte mso 9)|(IE)]>
          <td style="font-size:12px;font-family:Arial, Helvetica, sans-serif;border:0px;padding:0px 0px;" align="left" width=" 60.0%" valign="top">
              <![endif]-->         
          <table align="left" cellpadding="0" cellspacing="0" class="cols" style="font-size:12px;max-width:420.0px;width:100%;border:0px;padding:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;" width="100%">
        <tbody><tr>
                    <td class="txtsize" style="border:0px;padding:0px;" valign="top">
                                    <div class="zpwrapper col-space" id="pos_1568296862627" style="padding:0px;">

          <div class="zpelement-wrapper" id="elm_1614753912326" style=";word-wrap:break-word;overflow:hidden;padding-right:0px;background-color:#eff7f9;">
        <table bgcolor="#eff7f9" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="font-size:12px;padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;" width="100%">
      
            <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;line-height:19pt;border-top:0px none ;   border-bottom:0px none ;padding-top:7px;padding-bottom:7px;padding-right:15px;padding-left:110px;">
                      <div componentbgcolor="#eff7f9" componentpaddingbottom="7px" componentpaddingleft="110px" componentpaddingright="15px" componentpaddingtop="7px" style="background-color: rgb(239, 247, 249);"><span style="font-size: 9pt; color: rgb(101, 101, 101); font-family: Arial, Helvetica;">You are receiving this email as you visited our stand in Big 5 .</span><br><span style="color: rgb(101, 101, 101); font-size: 9pt; font-family: Arial, Helvetica;">Want to change how you receive these emails?</span><br><span style="font-size: 9pt; color: rgb(101, 101, 101); font-family: Arial, Helvetica;">You can </span><a alt="Unsubscribe" href="http://$[LI:UNSUBSCRIBE]$" rel="noopener noreferrer" style="text-decoration:underline;font-size: 9pt; font-family: Arial, Helvetica; color: rgb(101, 101, 101);" target="_blank" title="Unsubscribe"><font color="#5a5a5a">Unsubscribe</font></a><span style="font-size: 9pt; color: rgb(101, 101, 101); font-family: Arial, Helvetica;"> or </span><a alt="Update your preferences" href="http://$[LI:SUB_PREF]$" rel="noopener noreferrer" style="text-decoration:underline;font-size: 9pt; font-family: Arial, Helvetica; color: rgb(54, 54, 54);" target="_blank" title="Update your preferences"><font color="#363636" style="color:#363636;">Update your preferences</font></a></div>
      </td></tr>
    </tbody></table>
          </div>
                        </div> 
        </td></tr></tbody></table>
        <!--[if (gte mso 9)|(IE)]>
                      </td>
            <![endif]-->
      
            <!--[if (gte mso 9)|(IE)]>
          <td style="font-size:12px;font-family:Arial, Helvetica, sans-serif;border:0px;padding:0px 0px;" align="left" width=" 40.0%" valign="top">
              <![endif]-->         
          <table align="left" cellpadding="0" cellspacing="0" class="cols" style="font-size:12px;max-width:280.0px;width:100%;border:0px;padding:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;" width="100%">
        <tbody><tr>
                    <td class="txtsize" style="border:0px;padding:0px;" valign="top">
                                    <div class="zpwrapper col-space" id="pos_1568296862628" style="padding:0px;">

          <div class="zpelement-wrapper" id="elm_1568296862630" style=";word-wrap:break-word;overflow:hidden;padding-right:0px;background-color:;">
        <table border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="font-size:12px;padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;" width="100%">
      
            <tbody><tr><td class="paddingcomp" style="border:0px;padding:7px 15px;line-height:19pt;border-top:0px none ;   border-bottom:0px none ;padding-top:7px;padding-bottom:7px;padding-right:15px;padding-left:15px;">
                      <div style><p style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: 15pt; word-break: normal; overflow-wrap: normal;"><font color="#656565" style="line-height: 15pt; font-size: 9pt;">&nbsp; &nbsp;Follow Us On</font></p></div>
      </td></tr>
    </tbody></table>
          </div>

                  <div class="zpelement-wrapper wdgts" id="elm_1614753484509" style="overflow:hidden;word-wrap:break-word;">
            <table bgcolor border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt;font-size:5px; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;  background-color:;" width="100%">
              <tbody><tr><td style="padding:7px 15px;border:0px;font-size:5px;border-top:0px none ;border-bottom:0px none ;">
                <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:12px;min-width: 100%;border: none;" width="100%"><tbody><tr><td align="center" style="border: none;padding: 0px;margin: 0px;" valign="top"> <table align="left" border="0" cellpadding="0" cellspacing="0" icontext="true" index="5" name="zcsclwdgts_alnmnt" style="font-size:12px;border-collapse: collapse;border: none;margin:auto;"><tbody><tr><td align="left" style="border: none;padding: 0px;margin: 0px;" valign="top"> <table align="center" border="0" cellpadding="0" cellspacing="0" name="zcsclwdgtscontainer" style="border-collapse:collapse;font-size:12px;border: none;"><tbody><tr><td align="left" style="border:none;padding:0px;margin:0px;" valign="top"><table align="left" border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: collapse;border: none;"><tbody><tr><td style="padding-right: 9px;padding-bottom: 9px;border:none;padding: 0px;margin: 0px;" valign="top"> <table border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: separate;border: none;"><tbody><tr><td align="left" style="padding:7px;padding-top: 0px;padding-right: 9px;padding-bottom: 0px;padding-left: 9px;border:none;" valign="middle"> <table align="left" border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: collapse;border: none;" width><tbody><tr><td align="center" name="sclwdgtimges" style="border: none;padding: 0px;margin: 0px;padding-bottom: 6px;" valign="middle"> <a href="https://www.facebook.com/birigroup/" style="text-decoration:underline;display: block;font-size: 1px;" target="_blank"><img alt="Facebook" height="35" src="https://campaign-image.com/zohocampaigns/896644000000416006_1_1638795897529_zcsclwgtfb5.png" style="border: 0px; margin: 0px; outline: none; text-decoration: none; width: 25px; height: 25px;" vspace="10" width="35"></a> </td></tr><tr><td align="center" name="sclwdgtcaptns" style="border:none;padding: 0px;margin: 0px;" valign="middle"><a href="https://www.facebook.com/birigroup/" style="display: block;font-size: 1px;font-weight: normal;line-height: normal;text-align: center;text-decoration: none;" target="_blank"><p fntname="Arial" fntsze="8" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: normal; font-family: Arial, Helvetica, sans-serif; color: rgb(27, 107, 189); font-size: 8pt;">Facebook</p></a> </td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td><td align="left" style="border:none;padding:0px;margin:0px;" valign="top"><table align="left" border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: collapse;border: none;"><tbody><tr><td style="padding-right: 9px;padding-bottom: 9px;border:none;padding: 0px;margin: 0px;" valign="top"> <table border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: separate;border: none;"><tbody><tr><td align="left" style="padding:7px;padding-top: 0px;padding-right: 9px;padding-bottom: 0px;padding-left: 9px;border:none;" valign="middle"> <table align="left" border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: collapse;border: none;" width><tbody><tr><td align="center" name="sclwdgtimges" style="border: none;padding: 0px;margin: 0px;padding-bottom: 6px;" valign="middle"> <a href="https://ae.linkedin.com/company/birigroup" style="text-decoration:underline;display: block;font-size: 1px;" target="_blank"><img alt="LinkedIn" height="35" src="https://campaign-image.com/zohocampaigns/896644000000416006_2_1638795897575_zcsclwgtlin5.png" style="border: 0px; margin: 0px; outline: none; text-decoration: none; width: 25px; height: 25px;" vspace="10" width="35"></a> </td></tr><tr><td align="center" name="sclwdgtcaptns" style="border:none;padding: 0px;margin: 0px;" valign="middle"><a href="https://ae.linkedin.com/company/birigroup" style="display: block;font-size: 1px;font-weight: normal;line-height: normal;text-align: center;text-decoration: none;" target="_blank"><p fntname="Arial" fntsze="8" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: normal; font-family: Arial, Helvetica, sans-serif; color: rgb(27, 107, 189); font-size: 8pt;">LinkedIn</p></a> </td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td><td align="left" style="border:none;padding:0px;margin:0px;" valign="top"><table align="left" border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: collapse;border: none;"><tbody><tr><td style="padding-right: 9px;padding-bottom: 9px;border:none;padding: 0px;margin: 0px;" valign="top"> <table border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: separate;border: none;"><tbody><tr><td align="left" style="padding:7px;padding-top: 0px;padding-right: 9px;padding-bottom: 0px;padding-left: 9px;border:none;" valign="middle"> <table align="left" border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: collapse;border: none;" width><tbody><tr><td align="center" name="sclwdgtimges" style="border: none;padding: 0px;margin: 0px;padding-bottom: 6px;" valign="middle"> <a href="https://www.instagram.com/birigroup/" style="text-decoration:underline;display: block;font-size: 1px;" target="_blank"><img alt="Instagram" height="35" src="https://campaign-image.com/zohocampaigns/896644000000416006_3_1638795897621_zcsclwgtinsta5.png" style="border: 0px; margin: 0px; outline: none; text-decoration: none; width: 25px; height: 25px;" vspace="10" width="35"></a> </td></tr><tr><td align="center" name="sclwdgtcaptns" style="border:none;padding: 0px;margin: 0px;" valign="middle"><a href="https://www.instagram.com/birigroup/" style="display: block;font-size: 1px;font-weight: normal;line-height: normal;text-align: center;text-decoration: none;" target="_blank"><p fntname="Arial" fntsze="8" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: normal; font-family: Arial, Helvetica, sans-serif; color: rgb(27, 107, 189); font-size: 8pt;">Instagram</p></a> </td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td><td align="left" style="border:none;padding:0px;margin:0px;" valign="top"><table align="left" border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: collapse;border: none;"><tbody><tr><td style="padding-right: 9px;padding-bottom: 9px;border:none;padding: 0px;margin: 0px;" valign="top"> <table border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: separate;border: none;"><tbody><tr><td align="left" style="padding:7px;padding-top: 0px;padding-right: 9px;padding-bottom: 0px;padding-left: 9px;border:none;" valign="middle"> <table align="left" border="0" cellpadding="0" cellspacing="0" style="font-size:12px;border-collapse: collapse;border: none;" width><tbody><tr><td align="center" name="sclwdgtimges" style="border: none;padding: 0px;margin: 0px;padding-bottom: 6px;" valign="middle"> <a href="mailto:sales@birigroup.com" style="text-decoration:underline;display: block;font-size: 1px;" target="_blank"><img alt="Email" height="35" src="https://campaign-image.com/zohocampaigns/896644000000416006_4_1638795897667_zcsclwgtmail5.png" style="border: 0px; margin: 0px; outline: none; text-decoration: none; width: 25px; height: 25px;" vspace="10" width="35"></a> </td></tr><tr><td align="center" name="sclwdgtcaptns" style="border:none;padding: 0px;margin: 0px;" valign="middle"><a href="mailto:sales@birigroup.com" style="display: block;font-size: 1px;font-weight: normal;line-height: normal;text-align: center;text-decoration: none;" target="_blank"><p fntname="Arial" fntsze="8" style="font-family:Arial,verdana;font-size:12px; color:#000000;padding:0px;margin: 0;line-height: normal; font-family: Arial, Helvetica, sans-serif; color: rgb(27, 107, 189); font-size: 8pt;">Email</p></a> </td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table> 
              </td></tr>
                  </tbody></table>  
                </div>
                        </div> 
        </td></tr></tbody></table>
        <!--[if (gte mso 9)|(IE)]>
                      </td>
            <![endif]-->
     <!--[if (gte mso 9)|(IE)]>
                      </tr></tbody></table>
            <![endif]-->
    </td>
      </tr>
      </tbody></table>
            </div></div>
</td></tr>
<tr><td class="txtsize" id="elm_1517231241796" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">


            <div class="zpelement-wrapper spacebar" id="elm_1517231241796" style=";word-wrap:break-word;overflow:hidden;background-color:#eff7f9;">
          
           <table bgcolor="#eff7f9" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt;font-size:5px; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;height:5px;" width="100%">

                          <tbody><tr><td style="padding:0px;border:0px;font-size:5px;height:5px;border-top:none none none;border-bottom:none none none;">

                          &nbsp;&nbsp;&nbsp;

                          </td></tr>

                  </tbody></table>

            </div>

</td></tr>
<tr><td class="txtsize" id="elm_1517231248582" style="border:0px;padding:0px 0px;border-collapse:collapse;" valign="top">


            <div class="zpelement-wrapper spacebar" id="elm_1517231248582" style=";word-wrap:break-word;overflow:hidden;background-color:#eff7f9;">
          
           <table bgcolor="#eff7f9" border="0" cellpadding="0" cellspacing="0" class="zpAlignPos" style="padding:0px;border:0px;border-collapse:collapse; mso-table-lspace:0pt;font-size:5px; mso-table-rspace:0pt;word-break:break-word;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;height:15px;" width="100%">

                          <tbody><tr><td style="padding:0px;border:0px;font-size:5px;height:15px;border-top:none none none;border-bottom:none none none;">

                          &nbsp;&nbsp;&nbsp;

                          </td></tr>

                  </tbody></table>

            </div>

</td></tr>
    </tbody></table>
</div>

          </td> 
          </tr> 
          </tbody></table>
        </td> 
        <td style="border:0px;padding:0px;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">&nbsp;</td>
      </tr> 
    </tbody></table> 
</div>
</center> 
</body></html>';
//echo $html;
mail_visitors($html,$data[0]->vi_cont_email);
}









}