<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_PO extends CI_Controller {

public function __construct() {
		parent::__construct();
		
			$this->load->helper(array('session','email','img','gnrl','email_survey','text','email_po'));	
		$this->load->model('Third_db_model','tm');
	}


	function dashboard_po()
	{
         $excist=false;
		if(logged_in())
		{

			 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='po-dashboard')
         	{
				 $excist=true;
				 $i=$cred_count;
		   }
            else
            	$excist=false;

         }
         if ($excist) {

          

			 $this->send_mail_loguser();  

				$activitylogin_data=array(
				'page_user'=>$this->session->userdata['user']['username'],
				'user_activity'=>'User Logged',
				'page_userip'=>$this->session->userdata['user']['location_ip'],
				'page_pc'=>$this->session->userdata['user']['computername'],
				'page_country'=>$this->session->userdata['user']['state'],
				'date_time_logged'=>get_date_time(),
			);
			   $this->Admin_model->insert_data('activitieslogin',$activitylogin_data);



			 
         	// code...
		$dept_name=$this->session->userdata['user']['main_dept'];
		
		//////////pending order////////
        
		if($dept_name=="Main factory")
		{
			$cond1=array('po_sts'=>"1",'po_order_status_fact'=>'1');
		}
		else
		{
			$cond1=array('po_sts'=>"1",'po_order_status_adv'=>'1');	
		}
		$order_by=('po_id');
		$order_type="DESC";
		//$limit='10';
		$dept=$this->session->userdata['user']['main_dept'];
		
		$data['result']=$this->tm->get_po_details('prd_order',$cond1,'','',$order_by,$order_type,$dept);

		//pre_list($data['result']);

			foreach ($data['result'] as $index=>$val) 
			{
				$prd_id=explode('|#|',$val->po_prd_name);	

		 		$data['prd_data1'][]=$this->tm->prd_list_var($prd_id);
				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
		$data['new_order']=count($data['result']);

		//////approved order//////

		if($dept_name=="Main factory")
		{
			$cond1=array('po_sts'=>"1",'po_order_status_fact'=>'2');
			$cond1_or_where=array('po_order_partial_status_fact'=>'2');
		}
		else
		{
			$cond1=array('po_sts'=>"1",'po_order_status_adv'=>'2');	
			$cond1_or_where=array('po_order_partial_status_adv'=>'2');	
		}		
		$order_by=('po_id');
		$order_type="DESC";
		//$limit='10';
		$dept=$this->session->userdata['user']['main_dept'];
		
		$data['result2']=$this->tm->get_po_details('prd_order',$cond1,'','',$order_by,$order_type,$dept,$cond1_or_where);

		if(!empty($data['result2']))
		{
			foreach ($data['result2'] as $val) 
			{
				$prd_id=explode('|#|',$val->po_prd_name);	
		 		$data['prd_data2'][]=$this->tm->prd_list_var($prd_id);
				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
			// foreach ($data['result2'] as $val) 
			// {
			// 	$prd_id=explode('|#|',$val->po_prd_name);	
			// 	$data['prd_data2'][]=$this->tm->prd_var($prd_id);///getting product details	
			// }
			$data['approved_order']=count($data['result2']);
		}
		//////////on-production/////////

		if($dept_name=="Main factory")
		{
			$cond1=array('po_sts'=>"1",'po_order_status_fact'=>'3');
			$cond1_or_where=array('po_order_partial_status_fact'=>'3');
		}
		else
		{
			$cond1=array('po_sts'=>"1",'po_order_status_adv'=>'3');	
			$cond1_or_where=array('po_order_partial_status_adv'=>'3');
		}
		$order_by=('po_id');
		$order_type="DESC";
		//$limit='10';
		$dept=$this->session->userdata['user']['main_dept'];
		
		$data['result3']=$this->tm->get_po_details('prd_order',$cond1,'','',$order_by,$order_type,$dept,$cond1_or_where);
		
		//pre_list($data['result3']);
		
		//pre_list($data['result3']);
		if(!empty($data['result3']))
		{
			foreach ($data['result3'] as $val) 
			{
				$prd_id=explode('|#|',$val->po_prd_name);	
		 $data['prd_data3'][]=$this->tm->prd_list_var($prd_id);

				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
			// foreach ($data['result3'] as $val) 
			// {
			// 	$prd_id=explode('|#|',$val->po_prd_name);	
			// 	$data['prd_data3'][]=$this->tm->prd_var($prd_id);///getting product details	
			// }
			$data['on_production']=count($data['result3']);
		}

		//////////delivery_ready//////

		if($dept_name=="Main factory")
		{
			$cond1=array('po_sts'=>"1",'po_order_status_fact'=>'4');
			$cond1_or_where=array('po_order_partial_status_fact'=>'4');
		}
		else
		{
			$cond1=array('po_sts'=>"1",'po_order_status_adv'=>'4');
			$cond1_or_where=array('po_order_partial_status_adv'=>'4');	
		}
		
		$order_by=('po_id');
		$order_type="DESC";
		//$limit='10';
		$dept=$this->session->userdata['user']['main_dept'];
		
		$data['result4']=$this->tm->get_po_details('prd_order',$cond1,'','',$order_by,$order_type,$dept,$cond1_or_where);
		
		if(!empty($data['result4']))
		{
			foreach ($data['result4'] as $val) 
			{
				$prd_id=explode('|#|',$val->po_prd_name);	
		 $data['prd_data4'][]=$this->tm->prd_list_var($prd_id);

			}

			$data['delivery_ready']=count($data['result4']);
		}

		////////////delivered///////

		if($dept_name=="Main factory")
		$cond1=array('po_sts'=>"1",'po_order_status_fact'=>'5');
		else
		$cond1=array('po_sts'=>"1",'po_order_status_adv'=>'5');	
		$order_by=('po_id');
		$order_type="DESC";
		//$limit='10';
		$dept=$this->session->userdata['user']['main_dept'];
		
		$data['result5']=$this->tm->get_po_details('prd_order',$cond1,'','',$order_by,$order_type,$dept);
		
		if(!empty($data['result5']))
		{
			foreach ($data['result5'] as $val) 
			{
				$prd_id=explode('|#|',$val->po_prd_name);	
		 $data['prd_data5'][]=$this->tm->prd_list_var($prd_id);

				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
			// foreach ($data['result5'] as $val) 
			// {
			// 	$prd_id=explode('|#|',$val->po_prd_name);	
			// 	$data['prd_data5'][]=$this->tm->prd_var($prd_id);///getting product details	
			// }
			$data['delivered']=$this->tm->record_count2('prd_order',$cond1);//count($data['result5']);
		}


		////////rejected//////////////

		if($dept_name=="Main factory")
		$cond1=array('po_sts'=>"1",'po_order_status_fact'=>'0');
		else
		$cond1=array('po_sts'=>"1",'po_order_status_adv'=>'0');	
		$order_by=('po_id');
		$order_type="DESC";
		//$limit='10';
		$dept=$this->session->userdata['user']['main_dept'];
		
		$data['result6']=$this->tm->get_po_details('prd_order',$cond1,'','',$order_by,$order_type,$dept);
		
		if(!empty($data['result6']))
		{
			foreach ($data['result6'] as $val) 
			{
				$prd_id=explode('|#|',$val->po_prd_name);	
		 $data['prd_data6'][]=$this->tm->prd_list_var($prd_id);

				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
			// foreach ($data['result6'] as $val) 
			// {
			// 	$prd_id=explode('|#|',$val->po_prd_name);	
			// 	$data['prd_data6'][]=$this->tm->prd_var($prd_id);///getting product details	
			// }
			$data['rejected']=count($data['result6']);
		}
		$this->load->view('admin/production/prd_order/po_dashboard',$data);
		}
		else if(!$excist){
			    $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}
		}
		

	}
	
	function download_po_attachments($po_id)
	{
	$this->load->helper(array('download'));
	$this->load->library('zip');
	
	$cond=array('po_id'=>$po_id);
	$data_result=$this->tm->get_data('prd_order',$cond);
	
	$attachment_names=explode(',',$data_result[0]->po_files);
	
	foreach($attachment_names as $j)
		{
				$this->zip->read_file('./uploads/production/prod_files/'.$j);
		}	
		$this->zip->download('PO_NO_'.$data_result[0]->po_id.'.zip');
	}


	function approve_order()
	{
	if(logged_in())
		{
		$po_id=$this->input->post('po_id');

		$po_details=$this->tm->get_data('prd_order',array('po_id'=>$po_id));
		if(!empty($po_details[0]->po_survey_dept))
		{
			$survey_id=$po_details[0]->po_survey_dept;
			$this->Admin_model->update_data('survey_table',array('po_current_status'=>'2'),array('st_id'=>$survey_id));
		}
		$dept_name=$this->session->userdata['user']['main_dept'];
		
		if($dept_name=="Main factory")
		$data2=array('po_order_status_fact'=>'2');
		else
		$data2=array('po_order_status_adv'=>'2');

		$mail_data=array(
			'po_id'=>$po_id,
		);
		//$mail_info=send_po_approved_mail($mail_data);
		
		$mail_info=send_po_sts_mail($po_id,'Approved');
		
		//print_r($mail_info);

		if($mail_info==1)
		{
			$cond2=array('po_id'=>$po_id);
		$this->tm->update_data('prd_order',$data2,$cond2);
		$data_activity=array(
		'act_function'=>'order status change',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$po_id,
		'act_status'=>'approved',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);	

		echo true;
		}
		else{
			
			echo false;
		}
		
		}
	}

	function on_production()
	{
	if(logged_in())
		{
		$po_id=$this->input->post('po_id');
		$po_type=$this->input->post('po_type');
		$dept_name=$this->session->userdata['user']['main_dept'];
		$po_details=$this->tm->get_data('prd_order',array('po_id'=>$po_id));

		if($dept_name=="Main factory")
		{
			if($po_type=="fully")
			{
					$data2=array('po_order_status_fact'=>'3');
					$activity_sts="Fully On-Production";
			}
			else///partially
			{
				$data2=array('po_order_partial_status_fact'=>'3');
				$activity_sts="Partially On-Production";
			}
		}
		
		else
		{
			if($po_type=="fully")
			{
				$data2=array('po_order_status_adv'=>'3');
				$activity_sts="Fully On-Production";
			}
			else///partially
			{
				$data2=array('po_order_partial_status_adv'=>'3');
				$activity_sts="Partially On-Production";
			}
		}
		

		$cond2=array('po_id'=>$po_id);
		$this->tm->update_data('prd_order',$data2,$cond2);

		if(!empty($po_details[0]->po_survey_dept))
		{
			$survey_id=$po_details[0]->po_survey_dept;

			if(!empty($po_details[0]->remaining_qnty))
			{
				$qnty_remining=explode(',', $po_details[0]->remaining_qnty);
				if(empty(array_filter($qnty_remining)))
				{
					$this->Admin_model->update_data('survey_table',array('po_current_status'=>'3'),array('st_id'=>$survey_id));
				}
			}
			else
			$this->Admin_model->update_data('survey_table',array('po_current_status'=>'3'),array('st_id'=>$survey_id));
		}
		if($po_type=="fully")
		$mail_info=send_po_sts_mail($po_id,'On Production');
		else
		$mail_info=send_po_sts_mail($po_id,'PARTIALLY On-Production');	
		
		$data_activity=array(
		'act_function'=>'order status change',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$po_id,
		'act_status'=>$activity_sts,
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);	
		echo true;
		}
	}

	function dlvry_ready($edit_po_id=null)
	{
	if(logged_in())
		{
		if(empty($edit_po_id))
			$po_id=$this->input->post('po_id');
		else
			$po_id=$edit_po_id;

		$po_type=$this->input->post('po_type');

		$dept_name=$this->session->userdata['user']['main_dept'];
		$po_details=$this->tm->get_data('prd_order',array('po_id'=>$po_id));

		if($dept_name=="Main factory")
		{
			if($po_type=="fully")
			{
					$data2=array('po_order_status_fact'=>'4');
					$activity_sts="Fully Ready for Delivery";
			}
			else///partially
			{
				$data2=array('po_order_partial_status_fact'=>'4');
				$activity_sts="Partially Ready for Delivery";
			}
		}
		else
		{
			if($po_type=="fully")
			{
					$data2=array('po_order_status_adv'=>'4');
					$activity_sts="Fully Ready for Delivery";
			}
			else///partially
			{
				$data2=array('po_order_partial_status_adv'=>'4');
				$activity_sts="Partially Ready for Delivery";
			}
		}
		
		$cond2=array('po_id'=>$po_id);
		$this->tm->update_data('prd_order',$data2,$cond2);
		if(!empty($po_details[0]->po_survey_dept))
		{
			$survey_id=$po_details[0]->po_survey_dept;
			
			if($po_type=="fully")
			$this->Admin_model->update_data('survey_table',array('po_current_status'=>'4'),array('st_id'=>$survey_id));
			else
			{
				$partial_qnty_ready=$po_details[0]->new_qnty;
				$tot_partially_ready=$po_details[0]->approved_qnty;
				$this->Admin_model->update_data('survey_table',array('partial_po_status'=>'4','partial_po_qntys'=>$partial_qnty_ready,'partial_po_tot_qntys'=>$tot_partially_ready),array('st_id'=>$survey_id));
			}
		}
		if($po_type=="fully")
			{
		$mail_info=send_po_sts_mail($po_id,'Delivery Ready');
		}
		else
		{
			$mail_info=send_po_sts_mail($po_id,'PARTIALLY Delivery Ready');
		}
		
		$data_activity=array(
		'act_function'=>'order status change',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$po_id,
		'act_status'=>$activity_sts,
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);	
		echo true;
		}
	}

	
	function delivered()
	{
	if(logged_in())
		{
		$po_id=$this->input->post('po_id');
		$dept_name=$this->session->userdata['user']['main_dept'];
		$po_details=$this->tm->get_data('prd_order',array('po_id'=>$po_id));
		
		if($dept_name=="Main factory")
		$data2=array('po_order_status_fact'=>'5');
		else
		$data2=array('po_order_status_adv'=>'5');
		
		//send_mail_po_delivery($po_id);
		
		$mail_info=send_po_sts_mail($po_id,'Delivered');
	
		$cond2=array('po_id'=>$po_id);
		$this->tm->update_data('prd_order',$data2,$cond2);
		if(!empty($po_details[0]->po_survey_dept))
		{
			$survey_id=$po_details[0]->po_survey_dept;
			$this->Admin_model->update_data('survey_table',array('po_current_status'=>'5'),array('st_id'=>$survey_id));
		}
		$data_activity=array(
		'act_function'=>'order status change',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$po_id,
		'act_status'=>'delivered',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);
		echo true;
		}
	}

	function rejected()
	{
	if(logged_in())
		{
		$po_id=$this->input->post('po_id');
		$dept_name=$this->session->userdata['user']['main_dept'];
		$po_details=$this->tm->get_data('prd_order',array('po_id'=>$po_id));

		if($dept_name=="Main factory")
		$data2=array('po_order_status_fact'=>'0');
		else
		$data2=array('po_order_status_adv'=>'0');

		$cond2=array('po_id'=>$po_id);
		$this->tm->update_data('prd_order',$data2,$cond2);
		if(!empty($po_details[0]->po_survey_dept))
		{
			$survey_id=$po_details[0]->po_survey_dept;
			$this->Admin_model->update_data('survey_table',array('po_current_status'=>'0'),array('st_id'=>$survey_id));
		}
		
		$mail_info=send_po_sts_mail($po_id,'Rejected');
		
		$data_activity=array(
		'act_function'=>'order status change',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$po_id,
		'act_status'=>'rejected',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);
		echo true;
		}
	}


	function edit_dept_po()
	{
	if(logged_in())
		{
		$order_id=$this->input->post('ordr_id');//for update
		
		$cond=array('po_id'=>$order_id);
		$prd_details=$this->tm->get_data('prd_order',$cond);
		$dlvry_date=$this->input->post('delivery_date');

		$po_extednded_days=$prd_details[0]->po_dlvry_days;
		if(!empty($po_extednded_days))
	    {
	     // echo "in if";
	       $days_remaining=$po_extednded_days;
	       $date_got = strtotime("+".$days_remaining." day", strtotime($dlvry_date));
	     $final_date=date('Y-m-d',$date_got);
	    }
	  else
	  {
	    //echo " in else";
	    $final_date=date("Y-m-d", strtotime($dlvry_date));
	  }
		
	$converted_date_delivry = date("Y-m-d", strtotime($dlvry_date));

		
		$data=array(
			'po_date_delivry'=>$converted_date_delivry,
			'po_final_delivery_date'=>$final_date,
			'po_edited_dept'=>$this->session->userdata['user']['main_dept'],
		);

		  $cond2=array('po_id'=>$order_id);
		$this->tm->update_data('prd_order',$data,$cond2);
		
		$data_activity=array(
		'act_function'=>'order updated',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$order_id,
		'act_status'=>'edited delivery date',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);
		$this->session->set_flashdata('success','Details edited successfully');
		redirect('po-dashboard','refresh');
	    }	
	}

	function create_bom_po_adv($po_id)
	{	
		if(logged_in())
		{
			$prd_order=$this->tm->get_data('prd_order',array('po_id'=>$po_id));
			$po_prd_ids=explode('|#|',$prd_order[0]->po_prd_name);
			foreach($po_prd_ids as $pord_id)
			{
				$data['product_details'][]=$this->tm->get_data('products',array('pid'=>$pord_id));
			}
			$data['bom_data']=$this->tm->get_data('bom_data',array('bom_sts'=>'1','bom_prd_name !='=>''));
			$data['po_id']=$po_id;
			$this->load->view('admin/production/create_bom_adv',$data);
		}

	}

	function submit_bom_adv()
	{
		$edit_po_id=$this->input->post('edit_po_id');
		$bom_ids=implode(',',$this->input->post('get_bom_ids[]'));
		$this->tm->update_data('prd_order',array('po_bom_id'=>$bom_ids),array('po_id'=>$edit_po_id));

		//////////////////////////manage delivery////////////
		$dept_name=$this->session->userdata['user']['main_dept'];
		$po_details=$this->tm->get_data('prd_order',array('po_id'=>$edit_po_id));
		
		if($dept_name=="Main factory")
		$data2=array('po_order_status_fact'=>'4');
		else
		$data2=array('po_order_status_adv'=>'4');

		$cond2=array('po_id'=>$edit_po_id);
		$this->tm->update_data('prd_order',$data2,$cond2);
		if(!empty($po_details[0]->po_survey_dept))
		{
			$survey_id=$po_details[0]->po_survey_dept;
			$this->Admin_model->update_data('survey_table',array('po_current_status'=>'4'),array('st_id'=>$survey_id));
		}
		
	//	$mail_info=send_po_sts_mail($edit_po_id,'Delivery Ready');
		
		$data_activity=array(
		'act_function'=>'order status change',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$edit_po_id,
		'act_status'=>'delivery ready',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);
		//////////////////////////manage delivery////////////
		

		$this->session->set_flashdata('success','BOM created successfully');
		redirect('show-bom-adv/'.$edit_po_id,'refresh');
	}

	function show_bom_adv($po_id)
	{
		$prd_order=$this->tm->get_data('prd_order',array('po_id'=>$po_id));
		$bom_ids=explode(',',$prd_order[0]->po_bom_id);
		foreach($bom_ids as $bid)
		{
			$data['bom_data'][]=$this->tm->get_data('bom_data',array('bom_sts'=>'1','bom_prd_name !='=>'','bom_id'=>$bid));
		}
		
		foreach($data['bom_data'] as $index=>$bd)
		{
			$data['bom_extra'][$index][]=$this->tm->get_bom_prd_data(array('bom_sts'=>'1','bom_parent_id'=>$bd[0]->bom_id));
		}

		$data['po_id']=$po_id;

		//pre_list($data['bom_extra']);
		//pre_list($data['bom_data']);
		$this->load->view('admin/production/show_bom_sts_adv',$data);
	}

	function submit_po_delivery_note()
	{
		$po_id=$this->input->post('po_id');
		$delivery_note=$this->input->post('delivery_note');
		$dept_name=$this->session->userdata['user']['main_dept'];
		
		if($dept_name=="Main factory")
		{
		$this->tm->update_data('prd_order',array('fact_delivery_note'=>$delivery_note),array('po_id'=>$po_id));
		}
		else
		{
		$this->tm->update_data('prd_order',array('traffic_sign_delivery_note'=>$delivery_note),array('po_id'=>$po_id));
		}
		
		$this->session->set_flashdata('success','Delivery notes added successfully');
		redirect('po-dashboard','refresh');
	}
	


function send_mail_loguser()
{
	   $this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
		$config['smtp_crypto'] = 'tls'; 
		$config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

$page_user= $this->session->userdata['user']['username'];
$page_userip=$this->session->userdata['user']['location_ip'];
$page_serverip= $this->session->userdata['user']['server_ip'];
$page_email=$this->session->userdata['user']['user_email'];
$page_pc=$this->session->userdata['user']['computername'];
$page_state=$this->session->userdata['user']['state'];
$page_country=$this->session->userdata['user']['country'];
$page_cityserverprovider=$this->session->userdata['user']['cityserverprovider'];
$page_hostname=$this->session->userdata['user']['hostname'];
$page_lat=$this->session->userdata['user']['user_lat'];
$user_long=$this->session->userdata['user']['user_long'];
  
$user_serverorg=$this->session->userdata['user']['user_serverorg'];

$date_time=get_date_time();

          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to("support@birigroup.com");
          $this->email->to($page_email);    

          $this->email->subject('Loggedin Activity Happend :');
		 $msg="Dear ".$page_user.", <br/> Your Account Loggedin From Device Below  <br/><br/>";

		 $msg.="You Loggedin From  :  "  .$page_country."<br/><br/>";
		  $msg.="State :  "  .$page_state."<br/><br/>";
		  $msg.="Using IP Adress :  "  .$page_userip."<br/><br/>";
		  $msg.="ServerIP Adress :  "  .$page_serverip."<br/><br/>";
		  $msg.="from Device :  "  .$page_pc."<br/><br/>";
         $msg.="Server Provider :  "  .$user_serverorg."<br/><br/>";

          $msg.="Host Name :  "  .$page_hostname."<br/><br/>";
           $msg.="Latitude :  "  .$page_lat. "<br/><br/>"; 
           $msg.="Longtude :  "  .$user_long. "<br/><br/>";        
        
		  $msg.="Login date  :  "  .$date_time."<br/><br/>";
		
		  $msg.="<br/><br/>";
 $msg.="Thank you!<br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}















}