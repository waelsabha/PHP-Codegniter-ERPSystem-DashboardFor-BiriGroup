<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Survey_dashboard extends CI_Controller {

public function __construct() {
		parent::__construct();
			$this->load->helper(array('session','email','img','gnrl','email_survey','text'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
	}

function index()
{

    if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='survey-dashboard')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {
          
			 $this->send_mail_loguser();  

				$activitylogin_data=array(
				'page_user'=>$this->session->userdata['user']['username'],
				'user_activity'=>'User Logged',
				'page_userip'=>$this->session->userdata['user']['location_ip'],
				'page_pc'=>$this->session->userdata['user']['devicedetailsinfo'],
				'page_country'=>$this->session->userdata['user']['state'],
				'date_time_logged'=>get_date_time(),
			);
			   $this->Admin_model->insert_data('activitieslogin',$activitylogin_data);

      

	$data['total_survey']=$this->Admin_model->record_count2('survey_table',array('st_sts'=>'1'));
	
	$total_on_scheduled_projects=$this->srvm->survey_installation(array('ins_sts_installation'=>'scheduled'));
	$data['total_on_scheduled_projects']=count($total_on_scheduled_projects);

	$total_on_going_projects=$this->srvm->survey_installation(array('ins_sts_installation'=>'started'));
	$data['total_on_going_projects']=count($total_on_going_projects);

	$total_completed_survey=$this->srvm->survey_installation(array('ins_sts_installation'=>'completed'));
	$data['total_completed_survey']=count($total_completed_survey);

	$data['total_cancelled']=$this->Admin_model->record_count2('survey_table',array('st_sts'=>'0'));
	$data['total_waiting_for_production']=$this->Admin_model->record_count2('survey_table',array('po_current_status <'=>'4'));
	$data['total_product_sets']=$this->Admin_model->get_data_select_column('psd_prd_qty','product_set_data',array('psd_sts'=>'1'));


	$total_product_singles=$this->Admin_model->get_data('survey_table',array('st_sts'=>'1','st_single_prds !='=>''));
	foreach($total_product_singles as $tps)
	{
		$single_prd_qntys[]=explode(',',$tps->st_single_prd_qtys);
	}
	foreach($single_prd_qntys as $spq)
	{
		$aray_sum_single_prds[]=array_sum($spq);
	}

	$data['total_product_singles']=array_sum($aray_sum_single_prds);
	
	$total_installed_product_sets=$this->Admin_model->get_data('installation_details',array('insd_sts'=>'1','insd_prd_set_ids !='=>''));
	foreach($total_installed_product_sets as $tips)
	{
		if(!empty($tips->insd_prd_set_qty_installed))
		$prd_set_installed[]=array_sum(explode(',',$tips->insd_prd_set_qty_installed));
	}
	if(!empty($prd_set_installed))
	{
	$data['total_installed_product_sets']=array_sum($prd_set_installed);
	}
	else
	{
		$data['total_installed_product_sets']='0';
	}
	
	$total_installed_prd_singles=$this->Admin_model->get_data('installation_details',array('insd_sts'=>'1','insd_prd_single_ids !='=>''));
	foreach($total_installed_prd_singles as $tisp)
	{
		if(!empty($tisp->insd_prd_single_qty_installed))
		$prd_single_installed[]=array_sum(explode(',',$tisp->insd_prd_single_qty_installed));
	}
	if(!empty($prd_single_installed))
	{
	$data['total_installed_prd_singles']=array_sum($prd_single_installed);
	}
	else
	{
		$data['total_installed_prd_singles']='0';
	}


	$this->load->view('admin/production/survey_dashboard',$data);


 }

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
}



function send_mail_loguser()
{
	     $this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
$config['smtp_crypto'] = 'tls'; 
$config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

$page_user= $this->session->userdata['user']['username'];
//$page_userip=$this->session->userdata['user']['location_ip'];

$page_userip=$this->session->userdata['user']['ipsession'];
$page_serverip= $this->session->userdata['user']['server_ip'];
$page_email=$this->session->userdata['user']['user_email'];
$page_pc=$this->session->userdata['user']['computername'];
$page_state=$this->session->userdata['user']['state'];
$page_country=$this->session->userdata['user']['country'];
$page_cityserverprovider=$this->session->userdata['user']['cityserverprovider'];
$page_hostname=$this->session->userdata['user']['hostname'];
$page_lat=$this->session->userdata['user']['user_lat'];
$user_long=$this->session->userdata['user']['user_long'];
  
$user_serverorg=$this->session->userdata['user']['user_serverorg'];

$browsername=$this->session->userdata['user']['browsername'];
$browserversion=$this->session->userdata['user']['browserversion'];
$operatingsystem=$this->session->userdata['user']['operatingsystem'];


$devicedetailsinfo=$this->session->userdata['user']['devicedetailsinfo'];
$ipsession=$this->session->userdata['user']['ipsession'];
// $mobile=$this->session->userdata['user']['mobile'];
$date_time=get_date_time();

// print_r($page_email);
// exit(0);


     
          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to("support@birigroup.com");
          $this->email->to($page_email);    

          $this->email->subject('Loggedin Activity Happend :');
		 $msg="Dear ".$page_user.", <br/> Your Account Loggedin From Device Below  <br/><br/>";

		 $msg.="You Loggedin From  :  "  .$page_country."<br/><br/>";
		  $msg.="State :  "  .$page_state."<br/><br/>";
		  $msg.="Using IP Adress :  "  .$ipsession."<br/><br/>";
	
		  $msg.="from Device :  "  .$devicedetailsinfo." on server  " .   $page_pc  .     "<br/><br/>";
		  $msg.="Operating System:  "  .$operatingsystem.  "  <br/><br/>";
        $msg.="Browser:  ".$browsername." Version :  " .$browserversion. "  <br/><br/>";

         $msg.="Server Provider :  "  .$user_serverorg."<br/><br/>";

          $msg.="Host Name :  "  .$page_hostname."<br/><br/>";
           $msg.="Latitude :  "  .$page_lat. "<br/><br/>"; 
           $msg.="Longtude :  "  .$user_long. "<br/><br/>";        
                       
        
		  $msg.="Login date  :  "  .$date_time."<br/><br/>";
		
		  $msg.="<br/><br/>";
 $msg.="Thank you!<br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}




















}