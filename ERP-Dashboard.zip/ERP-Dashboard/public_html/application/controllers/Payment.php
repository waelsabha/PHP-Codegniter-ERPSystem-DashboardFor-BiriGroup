<?php
defined('BASEPATH') OR 
exit('No direct script access allowed');

class Payment extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->model(array('Account_model'));
		$this->load->helper(array('session','gnrl'));	
	}
	
function incoming_payment()
{
	$cond1=array('ac_sts'=>'1');
	$data['customer']=$this->Admin_model->get_data('acc_cusotmer',$cond1);

	$cond2=array('as_sts'=>'1');
	$data['suppliers']=$this->Admin_model->get_data('acc_suppliers',$cond2);	

	$data['accounts']=$this->Admin_model->get_data('account_tree_root',array('root_sts'=>'1'));

$this->load->view('admin/accounts/incoming_payment',$data);
}

function customer_code()
{
	$cust_id=$this->input->post('cust_id');
	$result=$this->Admin_model->get_data('acc_cusotmer',array('ac_id'=>$cust_id));
	echo 'C'.$result[0]->ac_code;
}

function supplier_code()
{
	$sup_id=$this->input->post('sup_id');
	$result=$this->Admin_model->get_data('acc_suppliers',array('as_id'=>$sup_id));
	echo 'S'.$result[0]->as_code;
}

function submit_ip()
{
	$chose_type=$this->input->post('chose_type');
	$customer_details=$this->input->post('customer_details');
	$supplier_details=$this->input->post('supplier_details');
	$accounts_details=$this->input->post('accounts_details');
	$due_date=$this->input->post('due_date');
	$posting_date=$this->input->post('posting_date');

	if($chose_type=='1')
	{
		$table_of=$customer_details;
		$table_name='';
	}
	elseif($chose_type=='3')
	{	
		$table_of=$supplier_details;
		$table_name='';
	}
	else
	{
		$accounts_data=explode('::',$accounts_details);
		$end_array=explode(':',end($accounts_data));
		$table_name=$end_array[0];
		$table_val=$end_array[1];
	//	$acc_data=$accounts_details;
		$table_of=$table_val;

	}
	
	$data=array(
		'ie_type'=>$chose_type,
		'ie_tabel_id'=>$table_of,
		'ie_acc_table'=>$table_name,
	'ie_posting_date'=>date('y-m-d',strtotime($due_date)),
	'ie_due_date'=>date('y-m-d',strtotime($posting_date)),
		'ie_amount'=>$this->input->post('amount'),
		'ie_tx_no'=>$this->input->post('trsctn_no'),
		'ie_sts'=>'1',
	);
	$this->Admin_model->insert_data('incoming_payment',$data);
	$this->session->set_flashdata('success', 'Data successfully inserted');
			redirect('incoming-payment');
}

function outgoing_payment()
{
	$cond1=array('ac_sts'=>'1');
	$data['customer']=$this->Admin_model->get_data('acc_cusotmer',$cond1);

	$cond2=array('as_sts'=>'1');
	$data['suppliers']=$this->Admin_model->get_data('acc_suppliers',$cond2);	

	$data['accounts']=$this->Admin_model->get_data('account_tree_root',array('root_sts'=>'1'));

$this->load->view('admin/accounts/outgoing_payment',$data);
}

function submit_outgoing_payment()
{
	$chose_type=$this->input->post('chose_type');
	$customer_details=$this->input->post('customer_details');
	$supplier_details=$this->input->post('supplier_details');
	$accounts_details=$this->input->post('accounts_details');
	$due_date=$this->input->post('due_date');
	$posting_date=$this->input->post('posting_date');

	if($chose_type=='1')
	{
		$table_of=$customer_details;
		$table_name='';
	}
	elseif($chose_type=='3')
	{	
		$table_of=$supplier_details;
		$table_name='';
	}
	else
	{
		$accounts_data=explode('::',$accounts_details);
		$end_array=explode(':',end($accounts_data));
		$table_name=$end_array[0];
		$table_val=$end_array[1];
	//	$acc_data=$accounts_details;
		$table_of=$table_val;
	}	
	$data=array(
		'og_type'=>$chose_type,
		'og_tabel_id'=>$table_of,
		'og_acc_table'=>$table_name,
	'og_posting_date'=>date('y-m-d',strtotime($due_date)),
	'og_due_date'=>date('y-m-d',strtotime($posting_date)),
		'og_amount'=>$this->input->post('amount'),
		'og_tx_no'=>$this->input->post('trsctn_no'),
		'og_sts'=>'1',
	);
	$this->Admin_model->insert_data('outgoing_payment',$data);
	$this->session->set_flashdata('success', 'Data successfully inserted');
			redirect('outgoing-payment');
}





























}