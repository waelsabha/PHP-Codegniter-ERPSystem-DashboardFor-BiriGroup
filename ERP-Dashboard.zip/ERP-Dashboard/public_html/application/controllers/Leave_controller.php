<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Leave_controller extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->model(array('Account_model'));
		$this->load->helper(array('session','gnrl','img','email'));	
	}


function add_leave($leave_id=null)
{
	if(logged_in())
	{

	$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='add-leave')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {
		//$data['emp_details']=$this->Admin_model->get_data('employee_details',array('ed_sts'=>'1'));
	       	$data['emp_details']=$this->Admin_model->get_data('tbl_emp_tree',array('et_sts'=>'1'));
		
		if(empty($leave_id))
	     $this->load->view('admin/hr/add_leave',$data);
		else
		{
		$data['result']=$this->Admin_model->get_data('add_leave',array('l_sts'=>'1','l_id'=>$leave_id));
		$this->load->view('admin/hr/add_leave',$data);
		}
}

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}

function list_leave()
{
	if(logged_in())
	{
       $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='list-leave')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

	           $data['result']=$this->Admin_model->get_data_leave(array('l_sts'=>'1'));
	             $this->load->view('admin/hr/list_leave',$data);
         }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}

function delete_leave($lv_id)
{
if(logged_in())
	{
	$this->Admin_model->update_data('add_leave',array('l_sts'=>'0'),array('l_id'=>$lv_id));
$this->session->set_flashdata('success', 'Data deleted successfully');
redirect('list-leave','refersh');
	}
}

function submit_leave()
{
	if(logged_in())
	{

		$targetfolder='./uploads/leave_managment/';
		
		if (isset($_FILES['l_supporting_files']['name']) && $_FILES['l_supporting_files']['name'] != "") 	
		{

			$img_array1=array(
				'img_name'=>'l_supporting_files',
				'upload_path'=>$targetfolder,
			);
			$emp_pic_names=img_upload($img_array1);
			
			if(!empty($emp_pic_names[0][0]['file_name']))
			{
				foreach($emp_pic_names[0] as $k1)
				{
					$pp_aray[]=$k1['file_name'];
					$value_pp_aray=implode(',',$pp_aray);
				}
			}
			
			else
			{
				$value_pp_aray='';
			}	
		}
		elseif(!empty($this->input->post('file_exist')))
		{
		$value_pp_aray=$this->input->post('file_exist');
		}
		else
		{
			$value_pp_aray='';
		}
		
$date_ref1=$this->input->post('l_date_from');
$date11=explode('/',$date_ref1);
			$month1=$date11[0];
			$date1=$date11[1];
			$year1=$date11[2];
$new_formated_date1=$year1.'-'.$month1.'-'.$date1;

$date_ref2=$this->input->post('l_date_to');
$date12=explode('/',$date_ref2);
			$month2=$date12[0];
			$date2=$date12[1];
			$year2=$date12[2];
$new_formated_date2=$year2.'-'.$month2.'-'.$date2;

	$data1=array(
			'l_user'=>$this->input->post('l_user'),
			'l_type'=>$this->input->post('l_type'),
			'amt_salary'=>$this->input->post('salary_amt'),
			'amt_ticket'=>$this->input->post('ticket_amt'),
			'checked_payment_type'=>$this->input->post('payment_type_leave'),
			'ticket_choice'=>$this->input->post('payment_type_ticket'),
			'l_subject'=>$this->input->post('l_subject'),
			'l_date_from'=>$new_formated_date1,
			'l_date_to'=>$new_formated_date2,
			'l_days'=>$this->input->post('l_days'),
			'l_desc'=>$this->input->post('l_desc'),
			'l_approval_sts'=>'1',
			'l_supporting_files'=>$value_pp_aray,
			'l_sts'=>'1',
			);
	$edit_lv_id=$this->input->post('edit_leave_id');		
	if(empty($edit_lv_id))		
	{
	$this->Admin_model->insert_data('add_leave',$data1);

	$this->send_mail_hr($data1);
	$this->session->set_flashdata('success', 'Data inserted successfully');
	redirect('add-leave','refersh');
	}
	else
	{
		$this->Admin_model->update_data('add_leave',$data1,array('l_id'=>$edit_lv_id));

	//$this->send_mail_hr($data1);
	$this->session->set_flashdata('success', 'Data updated successfully');
	redirect('list-leave','refersh');
	}
		
	}
}


function send_mail_hr($data1)
{
        $this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
        $config['smtp_crypto'] = 'tls'; 
         $config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;
         
          $this->email->initialize($config);

      $logged_users_details=$this->Admin_model->join_qry('login_credentials','tbl_emp_tree','ed_login_id','log_id',array('et_id'=>$data1['l_user']),('tbl_emp_tree.*,login_credentials.*'));
         
          $this->email->from('noreply@birigroup.com','Biri Group');
          //$this->email->to("support@birigroup.com");
         $this->email->to('hr@birigroup.com');
		 //$this->email->to('support@birigroup.com');
       
      

		  $this->email->subject('Leave Application from :'.$logged_users_details[0]->et_name);
		 
		  if(!empty($data1['l_supporting_files']))	
		  {
		    $this->email->attach("./uploads/leave_managment/".$data1['l_supporting_files']);
		   }	

$msg.="Dear HR, <br/> You got a new leave request from ".$logged_users_details[0]->ed_name." . <br/><br/>Below are the details. <br/><br/>";
		  $msg.="Subject :".$data1['l_subject']."<br/><br/>";
        
        $msg.="Leave Type :".$data1['l_type']."<br/><br/>";

         $msg.="Number of days :".$data1['l_days']."<br/><br/>";

          $msg.="Leave Date from :".$data1['l_date_from']."<br/><br/>";

           $msg.="Leave Date to :".$data1['l_date_to']."<br/><br/>";

           $msg.="Leave Description :".$data1['l_desc']."<br/><br/>";



		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  

}

function submit_leave_status()
{
	$leave_id=$this->input->post('leave_id');
	$leave_details=$this->Admin_model->get_data('add_leave',array('l_id'=>$leave_id));
	$date_ref1=$this->input->post('l_date_from');

if(!empty($date_ref1))
{
$date11=explode('/',$date_ref1);
			$month1=$date11[0];
			$date1=$date11[1];
			$year1=$date11[2];
$new_formated_date1=$year1.'-'.$month1.'-'.$date1;
}
else
{
	$new_formated_date1=$leave_details[0]->l_date_from;
}

$date_ref2=$this->input->post('l_date_to');

if(!empty($date_ref2))
{
$date12=explode('/',$date_ref2);
			$month2=$date12[0];
			$date2=$date12[1];
			$year2=$date12[2];
$new_formated_date2=$year2.'-'.$month2.'-'.$date2;
}
else
{
	$new_formated_date2=$leave_details[0]->l_date_to;
}

if(!empty($this->input->post('l_days')))
{
	$num_days=$this->input->post('l_days');
}
else
{
	$num_days=$leave_details[0]->l_days;
}

	$data1=array(

			'l_approval_sts'=>$this->input->post('l_approval_sts'),
			'l_date_from'=>$new_formated_date1,
			'l_date_to'=>$new_formated_date2,
			'l_days'=>$num_days,
			'l_reject_desc'=>$this->input->post('l_reject_desc')
		);
$this->Admin_model->update_data('add_leave',$data1,array('l_id'=>$leave_id));

$this->send_mail_user($data1,$leave_id);

$this->session->set_flashdata('success', 'Leave status changed successfully');
redirect('list-leave','refersh');
}

function send_mail_user($data,$lv_id)
{
	$this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
 $config['smtp_crypto'] = 'tls'; 
         $config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

      $leave_details=$this->Admin_model->get_data('add_leave',array('l_id'=>$lv_id));

      $logged_users_details=$this->Admin_model->join_qry('login_credentials','tbl_emp_tree','ed_login_id','log_id',array('et_id'=>$leave_details[0]->l_user),('tbl_emp_tree.*,login_credentials.*'));

      if($data['l_approval_sts']=="2")
      {
      	$leave_sts="Approved";
      	$leave_sts_reason='';
      }
      elseif($data['l_approval_sts']=="3")
      {
      	$leave_sts="Approved with Change in Date";
      	$leave_sts_reason='New Date is from '.$data['l_date_from'].' to '.$data['l_date_to'];
      }
      elseif($data['l_approval_sts']=="4")
      {
      	$leave_sts="Approved with change in days";
      	$leave_sts_reason='New Number of days is '.$data['l_days'];
      }
      elseif($data['l_approval_sts']=="5")
      {
      	$leave_sts="Rejected";
      	$leave_sts_reason='Reason for Rejection :'.$data['l_reject_desc'];
      }
      else
      {
      	$leave_sts="";
      	$leave_sts_reason='';
      }
         
          $this->email->from('noreply@birigroup.com','Biri Group');
          //$this->email->to("support@birigroup.com");
          $this->email->to($logged_users_details[0]->log_email);    

          $this->email->subject('Your Leave Application is :'.$leave_sts);
		 $msg="Dear ".$logged_users_details[0]->ed_name.", <br/> Your leave status is below  <br/><br/>";

		 $msg.="Subject of Leave :".$leave_details[0]->l_subject."<br/><br/>";
		  $msg.="Leave Status :".$leave_sts."<br/><br/>";
		  if(!empty($leave_sts_reason))
		  $msg.=$leave_sts_reason."<br/><br/>";
 $msg.="Thank you!<br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}








}