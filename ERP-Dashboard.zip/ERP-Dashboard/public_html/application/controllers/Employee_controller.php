<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee_controller extends CI_Controller {

	public function __construct() 
	{
			parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->library('numbertowordconvertsconver');			
		$this->load->model(array('Second_db_model','Sales_book_model'));
		$this->load->model('Third_db_model','tm');				
	}

function all_tickets()
{

  if(logged_in())
	{


      $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='all-tickets')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



	if(($this->session->userdata['user']['main_dept']=="Main") || ($this->session->userdata['user']['main_dept']=="Purchase"))
	{
		$data['result']=$this->Admin_model->get_data('ticket_stock',array('ts_sts'=>'1'));
	}
	else
	{
		$data['result']=$this->Admin_model->get_data('ticket_stock',array('ts_sts'=>'1','ts_user_id'=>$this->session->userdata['user']['username']));
	}
	
	foreach($data['result'] as $t)
	{
		$data['prd_details'][]=$this->tm->get_data('products',array('pid'=>$t->ts_prd_id));
	}
	$this->load->view('admin/employee/list_tickets',$data);
}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  
}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  







}



























}