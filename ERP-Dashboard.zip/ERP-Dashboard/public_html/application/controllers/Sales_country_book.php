<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_country_book extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','prd','gnrl'));
		$this->load->model('Sales_book_model');


	

	}

function sb_dashboard()
{
	
	if(logged_in())
	{

           $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='sales-book-country-dashboard')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

$sql7=$this->db->query("SELECT distinct sbr_city FROM sales_book_report  WHERE sbr_sts ='1'  ");

$data['country']=$sql7->result();


	$dept_logged_in=$this->session->userdata['user']['main_dept'];
	$log_sub_type=$this->session->userdata['user']['sub_dept'];



$choose_country=$this->input->post('choose_country');
		
$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
$current_month= $dt->format('m');
$current_year= $dt->format('Y');
$previous_year=$dt->format('Y')-1;
$last_previous_year=$dt->format('Y')-2;
$last_last_previous_year=$dt->format('Y')-3;
$last_last_previous_yearfourth=$dt->format('Y')-4;//for add online

$months=array('01','02','03','04','05','06','07','08','09','10','11','12');
foreach($months as $m)
{
	$datt['curnt_yr'][]=$this->Sales_book_model->bar_chart_data_curnt_year($current_year,$m,$choose_country);

	$datt['prev_yr'][]=$this->Sales_book_model->bar_chart_data_prev_year($previous_year,$m,$choose_country);	
	$datt['last_prev_yr'][]=$this->Sales_book_model->bar_chart_data_prev_year($last_previous_year,$m,$choose_country);
	$datt['last_last_prev_yr'][]=$this->Sales_book_model->bar_chart_data_prev_year($last_last_previous_year,$m,$choose_country);	
	$datt['last_last_last_prev_yr'][]=$this->Sales_book_model->bar_chart_data_prev_year($last_last_previous_yearfourth,$m,$choose_country);	//for add online
}




$datt['cat_curnt_yr'][]=$this->Sales_book_model->all_category($current_year,'','',$choose_country);
if(empty($datt['cat_curnt_yr'][0]))
{
$datt2['cat_curnt_yr'][]=$this->Sales_book_model->all_category($previous_year,'','',$choose_country);
}


if(!empty($datt['cat_curnt_yr'][0]))
{
$all_cat_names=array();$all_cat_sum1=array();
foreach($datt['cat_curnt_yr'][0] as $cat_c)
{
	if(!empty($all_cat_names))
	{
	if(!in_array($cat_c->sbp_ar_category, $all_cat_names))
	$all_cat_names[]=$cat_c->sbp_ar_category;
	}
	else
	{
	$all_cat_names[]=$cat_c->sbp_ar_category;
	}
$all_cat_sum1[$cat_c->sbp_ar_category][]=$cat_c->total_gross_amount;
}
foreach($all_cat_names as $c)
{
$datt['cat_prev_yr'][]=$this->Sales_book_model->all_category($previous_year,array('sbp_ar_category'=>$c),'',$choose_country);
$datt['cat_last_prev_yr'][]=$this->Sales_book_model->all_category($last_previous_year,array('sbp_ar_category'=>$c),'',$choose_country);
$datt['cat_last_last_prev_yr'][]=$this->Sales_book_model->all_category($last_last_previous_year,array('sbp_ar_category'=>$c),'',$choose_country);
$datt['cat_last_last_last_prev_yr'][]=$this->Sales_book_model->all_category($last_last_previous_yearfourth,array('sbp_ar_category'=>$c),'',$choose_country);//for add online
}
foreach($datt['cat_prev_yr'] as $indx=>$c2)
{
$all_cat_sum2[]=$c2;
}
	
foreach($datt['cat_last_prev_yr'] as $indx=>$c2)
{
$all_cat_sum3[]=$c2;
}

foreach($datt['cat_last_last_prev_yr'] as $indx=>$c3)
{
$all_cat_sum4[]=$c3;
}
foreach($datt['cat_last_last_last_prev_yr'] as $indx=>$c4)
{
$all_cat_sum5[]=$c4;
}
	
	$data['cat_amount_curnt']=$all_cat_sum1;
	$data['cat_amount_prev']=$all_cat_sum2;
	$data['cat_amount_last_prev']=$all_cat_sum3;
	$data['cat_amount_last_last_prev']=$all_cat_sum4;
	$data['cat_amount_last_last_last_prev']=$all_cat_sum5;//for add online
}
else
{
$all_cat_names=array();$all_cat_sum1=array();
	foreach($datt2['cat_curnt_yr'][0] as $cat_c)
	{
		if(!empty($all_cat_names))
		{
		if(!in_array($cat_c->sbp_ar_category, $all_cat_names))
		$all_cat_names[]=$cat_c->sbp_ar_category;
		}
		else
		{
		$all_cat_names[]=$cat_c->sbp_ar_category;
		}
	$all_cat_sum1[$cat_c->sbp_ar_category][]=$cat_c->total_gross_amount;
	}
	
	foreach($all_cat_names as $c)
	{
	$datt['cat_prev_yr'][]=$this->Sales_book_model->all_category($previous_year,array('sbp_ar_category'=>$c),'',$choose_country);
	
	$datt['cat_last_prev_yr'][]=$this->Sales_book_model->all_category($last_previous_year,array('sbp_ar_category'=>$c),'',$choose_country);
	
	$datt['cat_last_last_prev_yr'][]=$this->Sales_book_model->all_category($last_last_previous_year,array('sbp_ar_category'=>$c),'',$choose_country);
	  $datt['cat_last_last_last_prev_yr'][]=$this->Sales_book_model->all_category($last_last_previous_yearfourth,array('sbp_ar_category'=>$c),'',$city_list);//for add online
	}
	
    //add online
	foreach($datt['cat_last_last_last_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum5[]=$c2;
	}


	foreach($datt['cat_last_last_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum4[]=$c2;
	}
	
	foreach($datt['cat_last_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum3[]=$c2;
	}
	
	foreach($datt['cat_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum2[]=$c2;
	}
	
	
	$data['cat_amount_curnt']=array();
	$data['cat_amount_prev']=$all_cat_sum2;
	//$data['cat_amount_prev']=$all_cat_sum2;
	$data['cat_amount_last_prev']=$all_cat_sum3;
	$data['cat_amount_last_last_prev']=$all_cat_sum4;
	$data['cat_amount_last_last_last_prev']=$all_cat_sum5;//add online
}

$data['all_category_comparison']=$all_cat_names;
	
$data['current_year']=$current_year;
$data['previous_year']=$previous_year;
$data['last_previous_year']=$last_previous_year;
$data['last_last_prev_yr']=$last_last_previous_year;
$data['last_last_last_prev_yr']=$last_last_previous_yearfourth;//add online 

$strt_range=$this->input->post('start_date_rng');
$end_range=$this->input->post('end_date_rng');
$select_month=$this->input->post('month_selected');
//$choose_country=$this->input->post('choose_country');

if(!empty($strt_range) && !empty($end_range))
{
$cond_both_dates=array(
	'sbr_vou_date >='=>date("Y-m-d", strtotime($strt_range)),
	'sbr_vou_date <='=>date("Y-m-d", strtotime($end_range)),'sbr_city'=>$choose_country,
	);
	
	$current_year='';
}
else if(!empty($end_range))
{
$cond_both_dates=array(
	'sbr_vou_date <='=>date("Y-m-d", strtotime($end_range)),'sbr_city'=>$choose_country
	);
	$current_year='';
}
else if(!empty($strt_range))
{
$cond_both_dates=array(
	'sbr_vou_date >='=>date("Y-m-d", strtotime($strt_range)),'sbr_city'=>$choose_country
	);
	$current_year='';
}
else{
	$cond_both_dates=array(
	'sbr_city'=>$choose_country
	);
}

if(!empty($select_month))
{
	$cond_month=array(
	'sbr_voc_month'=>$select_month,'sbr_city'=>$choose_country,
	);
	
}	
else
{
$cond_month=array(
	'sbr_city'=>$choose_country,
	);
}

$data['start_date']=$strt_range;
$data['end_date']=$end_range;
$data['selected_month']=$select_month;
$data['choose_country']=$choose_country;







$data['productitem']=$this->Sales_book_model->all_sprd($current_year,$cond_both_dates,$cond_month,$choose_country);
$data['productitemprev']=$this->Sales_book_model->all_sprd($previous_year,$cond_both_dates,$cond_month,$choose_country);
$data['customerlist']=$this->Sales_book_model->all_customer($current_year,$cond_both_dates,$cond_month,$choose_country);
$data['customerlistprev']=$this->Sales_book_model->all_customer($previous_year,$cond_both_dates,$cond_month,$choose_country);
$data['all_category']=$this->Sales_book_model->all_category($current_year,$cond_both_dates,$cond_month,$choose_country);
foreach($data['all_category'] as $indx1=>$a_cat)
{	
$prd[]=$this->Sales_book_model->all_prd($a_cat->sbp_ar_category,'','',$current_year,$cond_both_dates,$cond_month,$choose_country);
}

$groups = [];
foreach ($prd as $key2 => $pd) 
{
	foreach($pd as $pd3)
	{
$groups[$pd3->sbp_ar_category][$pd3->sbp_prd_code]['sum'][]=$pd3->sbp_gross;   
$groups[$pd3->sbp_ar_category][$pd3->sbp_prd_code]['qnty'][]=$pd3->sbp_qty;   
	 }
}

 $sum_array=[];
foreach ($groups as $key4 => $value) {
	foreach($value as $key5=>$v1)
	{
	 $data['cat_prd'][$key4][]=array(
 'sum'=>array_sum(str_replace(',', '', $v1['sum'])),
		'prd_qnty'=>array_sum(str_replace(',', '', $v1['qnty'])) ,
		'prd_code'=>$key5,
		);
	}
}	
/////////////////////////////////////////////////////////////////////////////////
$data['all_category_last_year']=$this->Sales_book_model->all_category($previous_year,$cond_both_dates,$cond_month,$choose_country);
foreach($data['all_category_last_year'] as $indx1=>$a_cat)
{	
$prd_last_year[]=$this->Sales_book_model->all_prd($a_cat->sbp_ar_category,'','',$previous_year,$cond_both_dates,$cond_month,$choose_country);
}

$groups_last_year = [];
foreach ($prd_last_year as $key2 => $pd) 
{
	foreach($pd as $pd3)
	{
$groups_last_year[$pd3->sbp_ar_category][$pd3->sbp_prd_code]['sum'][]=$pd3->sbp_gross;   
$groups_last_year[$pd3->sbp_ar_category][$pd3->sbp_prd_code]['qnty'][]=$pd3->sbp_qty;   
	 }
}

 $sum_array_last_year=[];
foreach ($groups_last_year as $key4 => $value) {
	foreach($value as $key5=>$v1)
	{
	 $data['cat_prd_last_year'][$key4][]=array(
 		'sum'=>array_sum(str_replace(',', '', $v1['sum'])),
		'prd_qnty'=>array_sum(str_replace(',', '', $v1['qnty'])) ,
		'prd_code'=>$key5,
		);
	}
}	
 // echo "<pre>";
 // print_r($data['cat_prd']);
 // echo "</pre>";
 
 
 //print_r($data['2018_data']);
$this->load->view('admin/sales_book/sales_book_countrydashboard',$data);


 }
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}



	}
}

function aasort (&$array, $key) {
    $sorter=array();
    $ret=array();
    reset($array);
    foreach ($array as $ii => $va) {
        $sorter[$ii]=$va[$key];
    }
    asort($sorter);
    foreach ($sorter as $ii => $va) {
        $ret[$ii]=$array[$ii];
    }
    $array=$ret;
}

function sales_book_excel_upload() 
{
	if(logged_in())
	{

      $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='sales-book')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

	$this ->load-> view('admin/sales_book/sales_book');

}
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}


	}
}

function submit_sales_book_excel()
{
	$flag = 0;$voc_number='';
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/excel/sales_vouchers/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this->upload->do_upload('userfile')) 
		{
			$error = array('error' => $this->upload-> display_errors());
			$this->session ->set_flashdata('errors', $error['error']);
			redirect("sales-book", "refresh");
		} 
		else 
		{
		$data = array('userfile' => $this->upload->data());
		}
	
		if (!empty($data['userfile']['file_name'])) 
		{
		$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path.$import_xls_file;
		try 
		{
		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
		die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME).'": '.$e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{			
		$voc_number = trim($allDataInSheet[$i]['B']);
		$voc_date = trim($allDataInSheet[$i]['A']);
			$new_voc_date=explode('-', $voc_date);///in the format m-d-y , i need is y-m-d.
			if(!empty($new_voc_date[0]))
			$month_voc=$new_voc_date[0];
			else
				$month_voc='';

			if(!empty($new_voc_date[1]))
			$date_voc=$new_voc_date[1];	

			if(!empty($new_voc_date[2]))
			$year_voc=$new_voc_date[2];
		else
			$year_voc='';
			
		$cust_name = trim($allDataInSheet[$i]['C']);
		$narration = trim($allDataInSheet[$i]['D']);

			$branch = trim($allDataInSheet[$i]['L']);
			$country = trim($allDataInSheet[$i]['O']);
			$salesman=trim($allDataInSheet[$i]['P']);
			$acc_to = trim($allDataInSheet[$i]['Q']);
		$store_name = trim($allDataInSheet[$i]['R']);
		$paymnt_type=trim($allDataInSheet[$i]['S']);
			$due_date = trim($allDataInSheet[$i]['T']);
		$prd_name_en=trim($allDataInSheet[$i]['E']);
		$prd_name_ar=trim($allDataInSheet[$i]['M']);
			$prd_code=trim($allDataInSheet[$i]['F']);
			$qty=trim($allDataInSheet[$i]['G']);
			$rate=trim($allDataInSheet[$i]['H']);
			$gross_uae=trim($allDataInSheet[$i]['I']);
			
			$vat=trim($allDataInSheet[$i]['J']);
			$category=trim($allDataInSheet[$i]['N']);

		$total_amount=trim($allDataInSheet[$i]['K']);
		$gross=str_replace(',', '', trim($allDataInSheet[$i]['Y']));

			if(!empty($voc_number))
			{
			$data_voc_number=$this->Admin_model->record_count2('sales_book_report',array('sbr_vochuer_no'=>$voc_number,'sbr_voc_year'=>$year_voc));
			//echo "<pre>";
			//print_r($voc_number);
			//echo "<pre>";
				if(!empty($data_voc_number) || $data_voc_number!=0)
				{
			$flag=1;
			$error_string.="This vochure number already exist in table in this year mentioned in vochure.You have an error in Row $i of Cell B.Please remove those details and try again.<br/>";
				}
			}
		}
		if($flag==1)
		{
		
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/excel/sales_vouchers/".$import_xls_file);
			redirect('sales-book','refresh');
		}
		else
		{
			$dwnload_title=$this->input->post('dwnload_title');
			$data23=array(
			'excl_title'=>$dwnload_title,
			'excl_file'=>$inputFileName,
			'excl_status'=>"1",
			'excl_type' =>'result');
			$insert_id=$this->Admin_model->insert_data("excel_file_sales_book", $data23);
			 $this->insert_table($allDataInSheet,$insert_id);
		}
}


function insert_table($allDataInSheet,$insert_id) 
{
	$arrayCount = count($allDataInSheet);
	$flag = 0;
	$vocr_array=array();
	$data_empty_array=array();
	$insert_id_vochr='';
	for($i=2;$i<=$arrayCount;$i++) 
		{			
			$voc_number = trim($allDataInSheet[$i]['B']);
			$voc_date = trim($allDataInSheet[$i]['A']);

			$new_voc_date=explode('-', $voc_date);///in the format m-d-y , i need is y-m-d.
			if(!empty($new_voc_date[0]))
			$month_voc=$new_voc_date[0];
			else
				$month_voc='';

			if(!empty($new_voc_date[1]))
			$date_voc=$new_voc_date[1];	

			if(!empty($new_voc_date[2]))
			$year_voc=$new_voc_date[2];
		else
			$year_voc='';

			if(!empty($month_voc) && !empty($date_voc) && !empty($year_voc) )
			{
				$voc_date_2=$year_voc.'-'.$month_voc.'-'.$date_voc;
			}
			else
				$voc_date_2='0000-00-00';

		$cust_name = trim($allDataInSheet[$i]['C']);
		$narration = trim($allDataInSheet[$i]['D']);
			$branch = trim($allDataInSheet[$i]['L']);
			$country = trim($allDataInSheet[$i]['O']);
			$salesman=trim($allDataInSheet[$i]['P']);
			$acc_to = trim($allDataInSheet[$i]['Q']);
		$store_name = trim($allDataInSheet[$i]['R']);
		$paymnt_type=trim($allDataInSheet[$i]['S']);
			$due_date = trim($allDataInSheet[$i]['T']);

		$prd_name_en=trim($allDataInSheet[$i]['E']);
		$prd_name_ar=trim($allDataInSheet[$i]['M']);
			$prd_code=trim($allDataInSheet[$i]['F']);
			$qty=trim($allDataInSheet[$i]['G']);
			$rate=trim($allDataInSheet[$i]['H']);
			
			$vat=trim($allDataInSheet[$i]['J']);
			$category=trim($allDataInSheet[$i]['N']);

			$amount=trim($allDataInSheet[$i]['K']);
			$gross=str_replace(',', '', trim($allDataInSheet[$i]['I']));
			$gross_uae=str_replace(',', '', trim($allDataInSheet[$i]['Y']));/////the wrong gross

		if($voc_number!='Total' && !empty($voc_number))
		{	
			//$vocr_array[]=$voc_number;
			if(empty($vocr_array) || !(in_array($voc_number,$vocr_array)) )
			{
				$vocr_array[]=$voc_number;

			$new_amount=explode(' ',$amount);
			$currency=$new_amount[0];
			$total_amount=$new_amount[1];
				//
				$data_empty_array=array(
					'sbr_vochuer_no'=>$voc_number,
					'sbr_customer'=>$cust_name,
					'sbr_narration'=>$narration,
					'sbr_branch'=>$branch,
					'sbr_city'=>$country,
					'sbr_salesman'=>$salesman,
					'sbr_acc_to'=>$acc_to,
					'sbr_storename'=>$store_name,
					'sbr_paymnt_type'=>$paymnt_type,
					'sbr_due_date'=>date("Y-m-d", strtotime($due_date)),
					'sbr_vou_date'=>$voc_date_2,
					'sbr_excel_id'=>$insert_id,
					'sbr_sts'=>'1',
					'sbr_voc_month'=>$month_voc,
					'sbr_voc_year'=>$year_voc,
					'sbr_currency'=>$currency,
					'sbc_total_amount'=>$total_amount,
				);
//pre_list($data_empty_array);

			$insert_id_vochr=$this->Admin_model->insert_data2("sales_book_report", $data_empty_array);
			//pre_list($insert_id_vochr);
			if(!($insert_id_vochr))
			$status = false;
			else
				$status = true;
			
				$prd_data['prd_info'][]=array(
					'vochuer_id'=>$insert_id_vochr,
					'name_en'=>$prd_name_en,
					'name_ar'=>$prd_name_ar,
					'pcode'=>$prd_code,
					'qty'=>$qty,
					'rate'=>$rate,
					'gross'=>$gross,
					'grs_uae'=>$gross_uae,
					'vat'=>$vat,
					'cat'=>$category,
					);
				$this->session->set_userdata($prd_data);
			}
			else
			{				
				$prd_data['prd_info'][]=array(
				'vochuer_id'=>$insert_id_vochr,
				'name_en'=>$prd_name_en,
				'name_ar'=>$prd_name_ar,
				'pcode'=>$prd_code,
				'qty'=>$qty,
				'rate'=>$rate,
				'gross'=>$gross,
				'grs_uae'=>$gross_uae,
				'vat'=>$vat,
				'cat'=>$category,
				);		
				$this->session->set_userdata($prd_data);
			}			
		}
	}

	if ($status)
			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');

		redirect("sales-book", "refresh");	
}




function compare_sales()
{

if(logged_in())
	{


    $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='season-sales')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
$current_month= $dt->format('m');
$current_year= $dt->format('Y');
$five_yrs_back=$current_year-5;

	$data['all_data']=$this->Sales_book_model->get_total_all($current_year,$five_yrs_back);
	

	$base_value=$data['all_data'][0]->total_amount;
	$amount_to_divide=array();
	$ki=0;
	foreach($data['all_data'] as $key=>$ac)
	{
		$all_years[]=$ac->sbr_voc_year;
		if(($key-1)<0)
			$amount_to_divide[]='0';
		else	
		{
			$increase=$ac->total_amount-$data['all_data'][$key-1]->total_amount;
		$amount_to_divide[]=($increase)/($data['all_data'][$key-1]->total_amount)*100;
		}
	
		
	}
	$data['percentage_incerase']=$amount_to_divide;
	$data['all_years']=$all_years;

		foreach($data['all_data'] as $key=>$ac)
	{
$category_data_max[]=$this->Sales_book_model->get_seasons_total_category_max($ac->sbr_voc_year);
$category_data_min[]=$this->Sales_book_model->get_seasons_total_category_min($ac->sbr_voc_year);
}

	$data['fast_moving']=$category_data_max;
	$data['slow_moving']=$category_data_min;
$this->load->view('admin/sales_book/compare_sales',$data);
}
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}


}

}


function submit_season_comparison()
{
if(logged_in())
	{
	$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
$current_month= $dt->format('m');
$current_year= $dt->format('Y');
$five_yrs_back=$current_year-5;

	$season=$this->input->post('season_selected');
	if($season=="first_qurter")
	{
		$month_between_1='01';$month_between_2='03';
		
	}
	elseif($season=="sec_qurter")
	{
		$month_between_1='04';$month_between_2='06';
	}
	elseif($season=="third_qurter")
	{
		$month_between_1='07';$month_between_2='09';
	}
	elseif($season=="fourth_qurter")
	{
		$month_between_1='10';$month_between_2='12';
	}
	else
	{
		redirect('season-sales');
	}

	$strt_range=$this->input->post('start_date_rng');
$end_range=$this->input->post('end_date_rng');
$choose_country=$this->input->post('choose_country');
if(!empty($strt_range) && !empty($end_range))
{
$cond_both_dates=array(
	'sbr_vou_date >='=>date("Y-m-d", strtotime($strt_range)),
	'sbr_vou_date <='=>date("Y-m-d", strtotime($end_range)),
	);
	
	$season='';
}
else if(!empty($end_range))
{
$cond_both_dates=array(
	'sbr_vou_date <='=>date("Y-m-d", strtotime($end_range)),
	);
	$season='';
}	
else if(!empty($strt_range))
{
$cond_both_dates=array(
	'sbr_vou_date >='=>date("Y-m-d", strtotime($strt_range)),
	);
	$season='';
}
else{
	$cond_both_dates='';
}
$data['all_data']=$this->Sales_book_model->get_total_all($current_year,$five_yrs_back,$month_between_1,$month_between_2,$cond_both_dates);
	
		$base_value=$data['all_data'][0]->total_amount;
		$amount_to_divide=array();
		$ki=0;
		foreach($data['all_data'] as $key=>$ac)
		{
			$all_years[]=$ac->sbr_voc_year;
			if(($key-1)<0)
				$amount_to_divide[]='0';
			else	
			{
				$increase=$ac->total_amount-$data['all_data'][$key-1]->total_amount;
			$amount_to_divide[]=($increase)/($data['all_data'][$key-1]->total_amount)*100;
			}
		
			
		}
		$data['percentage_incerase']=$amount_to_divide;
		$data['all_years']=$all_years;

		foreach($data['all_data'] as $key=>$ac)
		{
		$category_data_max[]=$this->Sales_book_model->get_seasons_total_category_max($ac->sbr_voc_year,$month_between_1,$month_between_2,$cond_both_dates);
		$category_data_min[]=$this->Sales_book_model->get_seasons_total_category_min($ac->sbr_voc_year,$month_between_1,$month_between_2,$cond_both_dates);
		}

		$data['fast_moving']=$category_data_max;
		$data['slow_moving']=$category_data_min;
		$data['season_selected']=$season;
		$data['start_date']=$strt_range;
		$data['end_date']=$end_range;
$this->load->view('admin/sales_book/compare_sales',$data);
}
}














}