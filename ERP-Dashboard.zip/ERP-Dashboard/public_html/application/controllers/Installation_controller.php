<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Installation_controller extends CI_Controller {


public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));		
	}


function list_all_installations()
{
	if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='list-installations')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

	$data['result']=$this->srvm->survey_installation(array('st_sts'=>'1','st_dept_installation !='=>''));
	
	foreach($data['result'] as $index=>$t)
	{
		$data['instalation_detail'][$index][$index][]=$this->Admin_model->get_data('installation_details',array('insd_survey_id'=>$t->st_id,'insd_installation_id'=>$t->ins_id),'1','','insd_id','DESC');

		$prd_ids_explode=explode('|#|',$t->st_po_prd_ids);
		foreach($prd_ids_explode as $q)
				{
					$data['prd_ids'][$index][$index][]=$this->tm->get_data('products',array('pid'=>$q));
				}		
	}

	///pre_list($data['prd_ids']);

		if(!empty($data['instalation_detail']))
		{
			foreach($data['instalation_detail'] as $index2=>$ins_dt)
			{
				foreach($ins_dt as $index3=>$ins_dt2)
				{
				if(!empty($ins_dt2[0][0]->insd_tools))
				{	
				$tools_needed=explode(',',$ins_dt2[0][0]->insd_tools);
				
					foreach($tools_needed as $tn)
					{
						if(!empty($tn))
						$data['tools_details'][$index2][]=$this->Admin_model->get_data('assets_tools',array('tool_id'=>$tn));
					}
				}
				if(!empty($ins_dt2[0][0]->insd_vehicle))
				{
					$vehicle_needed=explode(',',$ins_dt2[0][0]->insd_vehicle);
					foreach($vehicle_needed as $vn)
					{
						if(!empty($vn))
						$data['veh_details'][$index2][]=$this->Admin_model->get_data('assets_vehicle',array('veh_id'=>$vn));
					}
				}
				if(!empty($ins_dt2[0][0]->insd_labours))
				{	
					$labour_needed=explode(',',$ins_dt2[0][0]->insd_labours);
					foreach($labour_needed as $ln)
					{
						if(!empty($ln))
							$data['emp_details'][$index2][]=$this->srvm->get_login_emp_details(array('ed_id'=>$ln));
					}
				}
				}
			}
		}
$this->load->view('admin/production/list_installation',$data);


  }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  




	}
}

function set_installation_date()
{
	$installation_id=$this->input->post('installation_id');
	$schedule_date=$this->input->post('set_date_installation');
	$date0=explode('/',$schedule_date);
				
				$date1=$date0[0];
				$month1=$date0[1];
				$year1=$date0[2];
				$new_formated_date1=$year1.'-'.$month1.'-'.$date1;
	$this->Admin_model->update_data('installation_dept',array('ins_date_set_installation'=>$new_formated_date1),array('ins_id'=>$installation_id));
	
	$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Installation date set',
			'act_status'=>'Installation schedule date set',
			'act_installation_id'=>$installation_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
				);
		$this->Admin_model->insert_data('activities',$activity_data);
		
	$this->session->set_flashdata('success', 'Installation date set successfully');
	redirect('list-installations');
}

function manage_installation($installation_id,$edit_data=null,$labour_list=null,$new_installation_date=null)
{
	if(!empty($edit_data) && $edit_data=='edit_instalaltion_data')
	{
		//echo "in edit present ";
	$data['installation_table_details']=$this->Admin_model->get_data('installation_details',array('insd_id'=>$installation_id));
//pre_list($data['installation_table_details']);
	$data['installation_id']=$data['installation_table_details'][0]->insd_installation_id;
	$data['survey_details']=$this->Admin_model->get_data('survey_table',array('st_id'=>$data['installation_table_details'][0]->insd_survey_id));
	//pre_list($data['survey_details']);
	}
	else
	{
		///echo "no edit present ";
	$data['installation_id']=$installation_id;
	$data['result']=$this->Admin_model->get_data('installation_dept',array('ins_id'=>$installation_id));
	$data['survey_details']=$this->Admin_model->get_data('survey_table',array('st_id'=>$data['result'][0]->ins_survey_id));	
//pre_list($data['survey_details']);
	$data['installation_table_details']=$this->Admin_model->get_data('installation_details',array('insd_survey_id'=>$data['survey_details'][0]->st_id,'insd_installation_id'=>$installation_id),'1','','insd_id','DESC');
	}
$data['prd_set_details']=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$data['survey_details'][0]->st_id));

	$remaining_qty_prd_set=explode(',',$data['installation_table_details'][0]->insd_prd_set_remaining_qnty);
	$remaining_qty_prd_singles=explode(',',$data['installation_table_details'][0]->insd_prd_single_remaining_qnty);
	
//pre_list($data['installation_table_details']);
	$data['single_prd_qty']=$data['survey_details'][0]->st_single_prd_qtys;
	$data['edit_survey_id']=$data['survey_details'][0]->st_id;

	foreach($data['prd_set_details'] as $index1=>$psr)
			{
				$prd_ids_explode=explode(',', $psr->psd_prd_id);
				$arrange_pos=explode(',', $psr->psd_arrange_position);
				foreach($prd_ids_explode as $index11=>$q)
				{
					$data['prd_ids_1'][$index1][$arrange_pos[$index11]]=$this->tm->get_data('products',array('pid'=>$q));
				}
			}
					
			$single_prd_ids=explode(',',$data['survey_details'][0]->st_single_prds);	

			if(!empty($single_prd_ids))
			{
			foreach($single_prd_ids as $q1)
						{
							$data['prd_ids_2'][]=$this->tm->get_data('products',array('pid'=>$q1));
						}
			}
			else
			{
				$data['prd_ids_2']='0';
			}		

			$prd_from_po=explode('|#|', $data['survey_details'][0]->st_po_prd_ids);	
			if(!empty($prd_from_po))
			{
			foreach($prd_from_po as $q11)
						{
							$data['prd_ids_po'][]=$this->tm->get_data('products',array('pid'=>$q11));
						}
			}
			else
			{
				$data['prd_ids_po']='0';
			}		

	if(!empty($labour_list))
	{
		$labour_ids=explode(',',$labour_list);
		foreach($labour_ids as $lid)
		{
			if($lid!='35')
			{
				$new_labours_list[]=$lid;	
			}
		}
	$sql=$this->db->query("SELECT * FROM `employee_details` WHERE `ed_branch`='6' AND `ed_sts`='1' AND `ed_id` NOT IN ( '" . implode( "', '" , $new_labours_list ) . "' )");
		$data['labour']=$sql->result_array();
	}
	else
	{
		$sql=$this->db->query("SELECT * FROM `employee_details` WHERE `ed_branch`='6' AND `ed_sts`='1' ");
		$data['labour']=$sql->result_array();
	//$data['labour']=$this->Admin_model->get_data('employee_details',array('ed_branch'=>'6','ed_sts'=>'1'));	
	}	
	$data['vehicle']=$this->Admin_model->get_data('assets_vehicle',array('veh_sts'=>'1'));
	$data['tools']=$this->Admin_model->get_data('assets_tools',array('tool_sts'=>'1'));

	if(!empty($new_installation_date))
	{
		$data['new_installation_date']=$new_installation_date;
	}

	if(!empty($edit_data) )
	{
		//echo'not empty edit_data';
		$data['edit_manage_installation']=true;
		$this->load->view('admin/production/manage_installation',$data);
	}
	else
	{	
		$data['edit_manage_installation']=false;
		//pre_list($data['new_installation_date']);
	//print_r($remaining_qty_prd_set);
if(!empty($data['installation_table_details'][0]->insd_prd_set_ids) && !empty($data['installation_table_details'][0]->insd_prd_single_ids))
	{
	//echo 'in if';
	//pre_list(array_filter($remaining_qty_prd_set));
	//pre_list(array_filter($remaining_qty_prd_singles));
	// print_r($edit_data);
		if(array_filter($remaining_qty_prd_set)==false && array_filter($remaining_qty_prd_singles)==false )
		{
			//echo "no more single and prd sets";
			$this->session->set_flashdata('errors', 'No more quantity left for installation');
			redirect('list-installations');
		}
		else
		{
			//echo " more single and prd sets";
			$this->load->view('admin/production/manage_installation',$data);
		}
	}
	elseif(!empty($data['installation_table_details'][0]->insd_prd_set_ids) && empty($data['installation_table_details'][0]->insd_prd_single_ids))
	{
	//echo 'in else if';
		if(array_filter($remaining_qty_prd_set)==false )
		{
	//	echo "no more prd set";
			$this->session->set_flashdata('errors', 'No more quantity left for installation');
			redirect('list-installations');
		}
		else
		{
			//echo " more prd set";
			$this->load->view('admin/production/manage_installation',$data);
		}
	}
	elseif(empty($data['installation_table_details'][0]->insd_prd_set_ids) && !empty($data['installation_table_details'][0]->insd_prd_single_ids))
	{
	//echo 'in else if 2';
		if(array_filter($remaining_qty_prd_singles)==false )
		{
			//echo "no more prd singles";
			$this->session->set_flashdata('errors', 'No more quantity left for installation');
			redirect('list-installations');
		}	
		else
		{
			//echo " more prd singles";
			$this->load->view('admin/production/manage_installation',$data);
		}
	}
	else
	{
		//echo "in the very elsse";
		$this->load->view('admin/production/manage_installation',$data);
	}
	///////////////////end here all cehcking, and no edit here//////////////
	}
}

function list_scheduled($installation_id)
{
	$data['result']=$this->srvm->survey_installation(array('ins_id'=>$installation_id));
			$data['instalation_details']=$this->Admin_model->get_data('installation_details',array('insd_installation_id'=>$installation_id));
	//pre_list($data['result']);
	if(!empty($data['instalation_details']))		
 	{			
		foreach($data['instalation_details'] as $indx=>$di)
		{
			$tools_needed=explode(',',$di->insd_tools);
			foreach($tools_needed as $tn)
			{
				$data['tools_details'][$indx][$indx][]=$this->Admin_model->get_data('assets_tools',array('tool_id'=>$tn));
			}

			$vehicle_needed=explode(',',$di->insd_vehicle);
			foreach($vehicle_needed as $vn)
			{
				$data['veh_details'][$indx][$indx][]=$this->Admin_model->get_data('assets_vehicle',array('veh_id'=>$vn));
			}

			$labour_needed=explode(',',$di->insd_labours);
			foreach($labour_needed as $ln)
			{
					$data['emp_details'][$indx][$indx][]=$this->srvm->get_login_emp_details(array('ed_id'=>$ln));
			}
		}	

			$prd_set_ids=explode(',',$data['instalation_details'][0]->insd_prd_set_ids);
				foreach ($prd_set_ids as $key => $psid) 
				{

					$data['prd_set_result'][]=$this->Admin_model->get_data('product_set_data',array('psd_id'=>$psid));
				}
//pre_list($data['prd_set_result']);
			if(!empty($data['prd_set_result']))
			{
				foreach($data['prd_set_result'] as $index1=>$psr)
				{
					$prd_ids_explode=explode(',',$psr[0]->psd_prd_id);
					$arrange_pos=explode(',', $psr[0]->psd_arrange_position);
					foreach($prd_ids_explode as $index11=>$q)
					{
						$data['prd_ids_1'][$index1][$arrange_pos[$index11]]=$this->tm->get_data('products',array('pid'=>$q));
					}
				}
			}
			
				$prd_singles=explode(',', $data['instalation_details'][0]->insd_prd_single_ids);
				if(!empty($prd_singles))
				{
				foreach($prd_singles as $q1)
					{
						$data['prd_ids_2'][]=$this->tm->get_data('products',array('pid'=>$q1));
					}
				}
				else
				{
					$data['prd_ids_2']='0';
				}
		$data['last_scheduled_data']=$this->Admin_model->get_data('installation_details',array('insd_survey_id'=>$data['instalation_details'][0]->insd_survey_id),'1','','insd_id','DESC');		
	//	pre_list($data);
	$this->load->view('admin/production/list_scheduled',$data);
	}
}

function edit_manage_installation($insd_details_id)
{
if(logged_in())
	{
		if(!empty($insd_details_id))
		{
			$this->manage_installation($insd_details_id,'edit_instalaltion_data');				
		}
		else
		{
			$this->session->set_flashdata('errors', 'Sorry, No details found.');
 				redirect('list-installations');
		}			
	}
}

function delete_manage_installation($insd_details_id)
{
	if(logged_in())
	{
		if(!empty($insd_details_id))
		{
			$instalation_data=$this->Admin_model->get_data('installation_details',array('insd_id'=>$insd_details_id));	
			
			$prd_set_qnty_to_install=explode(',',$instalation_data[0]->insd_prd_set_qty_set_for_installation);
			$prd_single_qnty_to_install=explode(',',$instalation_data[0]->insd_prd_single_qty_set_for_installation);

		$last_scheduled_data=$this->Admin_model->get_data('installation_details',array('insd_survey_id'=>$instalation_data[0]->insd_survey_id),'1','','insd_id','DESC');	
			$prd_set_original_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_set_org_qnty);
			$prd_set_reamining_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_set_remaining_qnty);

			$prd_single_original_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_single_org_qnty);
			$prd_single_reamining_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_single_remaining_qnty);

			foreach($prd_set_qnty_to_install as $i1=>$p1)
			{
				$new_prd_set_org_qnty[]=$prd_set_original_qnty_in_last_scheduled[$i1]+$p1;
				$new_prd_set_remainig_qnty[]=$prd_set_reamining_qnty_in_last_scheduled[$i1]+$p1;
			}

			foreach($prd_single_qnty_to_install as $i2=>$p2)
			{
				$new_prd_single_org_qnty[]=$prd_single_original_qnty_in_last_scheduled[$i2]+$p2;
				$new_prd_single_remainig_qnty[]=$prd_single_reamining_qnty_in_last_scheduled[$i2]+$p2;
			}

			$array_update_last_scheduled=array(
				'insd_prd_set_org_qnty'=>implode(',',$new_prd_set_org_qnty),
				'insd_prd_set_remaining_qnty'=>implode(',',$new_prd_set_remainig_qnty),
				'insd_prd_single_org_qnty'=>implode(',',$new_prd_single_org_qnty),
				'insd_prd_single_remaining_qnty'=>implode(',',$new_prd_single_remainig_qnty),
			);

			$this->Admin_model->update_data('installation_details',$array_update_last_scheduled,array('insd_id'=>$last_scheduled_data[0]->insd_id));

			$this->Admin_model->delete_data('installation_details',array('insd_id'=>$insd_details_id));

			 $this->session->set_flashdata('success', 'Data Deleted successfully');
 		 		redirect('list_scheduled/'.$instalation_data[0]->insd_installation_id);
		}
		else
		{
			 $this->session->set_flashdata('errors', 'Sorry, No details found.');
 		 		redirect('list-installations');
		}			
	}
}


function submit_manage_installation()
{
	$installation_id=$this->input->post('installation_id');
	$edit_survey_id=$this->input->post('survey_id');

	if(!empty($this->input->post('prd_set_ids[]')))
	{
		$prd_sets_id=$this->input->post('prd_set_ids[]');
		$imploded_prd_set_ids=implode(',', $prd_sets_id);
	}
else
{
$imploded_prd_set_ids='';
}

if(!empty($this->input->post('single_prd_ids')))
	{
		$single_prd_ids=$this->input->post('single_prd_ids');
		$imploded_prd_single_ids=$single_prd_ids;
	}
else
{
	$imploded_prd_single_ids='';
}

if(!empty($this->input->post('prd_set_org_qnty[]')))
{
	$prd_set_original_qnty=$this->input->post('prd_set_org_qnty[]');
	$imploded_prd_set_org_qnty=implode(',',$prd_set_original_qnty);
}
else
{
	$imploded_prd_set_org_qnty='';
}
	$new_quantity_prd_set=$this->input->post('new_quantity_prd_set[]');
	$remaining_quantity_prd_set=$this->input->post('prd_set_remaining_qty[]');
	$update_manage_installation=$this->input->post('update_manage_installation');

//////////////////////calculation goes hereee////////////////////
if(!empty($new_quantity_prd_set))
{
	foreach($new_quantity_prd_set as $index=>$nps)
	{
		if($nps=='0')
		{
			$set_new_qnty[]='0';
			$set_remaining_qnty[]=$prd_set_original_qnty[$index]-$nps;
			$set_new_org_prds_qnty[]=$prd_set_original_qnty[$index];
		}
		else
		{
			if($nps=='')
			{
				$set_new_qnty[]='0';
			}
			else
			{
				$set_new_qnty[]=$nps;
			}
			$set_remaining_qnty[]=$remaining_quantity_prd_set[$index];
			$set_new_org_prds_qnty[]=$remaining_quantity_prd_set[$index];
		}	
	}
	$imploded_org_prd_qntys=implode(',', $set_new_org_prds_qnty);	
	$imploded_set_new_qnty=implode(',',$set_new_qnty);
	$imploded_set_remaining_qnty=implode(',',$set_remaining_qnty);
}
else
{
	$imploded_org_prd_qntys='';
	$imploded_set_new_qnty='';
	$imploded_set_remaining_qnty='';
}
///////////////////////calculation ends//////////////////////////
if(!empty($this->input->post('prd_single_org_qnty[]')))
{
	$single_prd_original_qnty=$this->input->post('prd_single_org_qnty[]');
	$imploded_single_prd_qnty=implode(',',$single_prd_original_qnty);
}
else
{
	$imploded_single_prd_qnty='';
}
	$single_qty=$this->input->post('prd_single_quantity_new[]');
$single_remainig_qnty=$this->input->post('prd_remaining_qty_single[]');
	
///////////////////////////calculation heree//////////////////////////
if(!empty($single_qty))
{
foreach($single_qty as $index2=>$nps2)
	{
		if($nps2=='0')
		{
			$prd_single_new_qnty[]='0';
			$prd_single_remaining_qnty[]=$single_prd_original_qnty[$index2]-$nps2;
			$prd_single_org_new_qnty[]=$single_prd_original_qnty[$index2];
		}
		else
		{
			if($nps2=='')
			{
				$prd_single_new_qnty[]='0';
			}
			else
			{
				$prd_single_new_qnty[]=$nps2;
			}
			$prd_single_remaining_qnty[]=$single_remainig_qnty[$index2];
			$prd_single_org_new_qnty[]=$single_remainig_qnty[$index2];
		}	

		$imploded_prd_single_org_new_qnty=implode(',', $prd_single_org_new_qnty);
		$imploded_prd_single_new_qnty=implode(',',$prd_single_new_qnty);
		$imploded_prd_single_remaining_qnty=implode(',',$prd_single_remaining_qnty);
	}
}
else
{
	$imploded_prd_single_org_new_qnty='';
	$imploded_prd_single_new_qnty='';
	$imploded_prd_single_remaining_qnty='';
}
///////////////////////ends here//////////////////////////////////////////////////
if(!empty($this->input->post('schedule_date_installation')))
	{
	$date_scheduled=$this->input->post('schedule_date_installation');
		$date0=explode('/',$date_scheduled);
		$date1=$date0[0];
		$month1=$date0[1];
		$year1=$date0[2];
		$new_formated_date1=$year1.'-'.$month1.'-'.$date1;
	}
/////////////////////only on update of data use this/////////////////////////////////////////////////////
	if(!empty($update_manage_installation))
	{
		$old_qnty_prd_set_to_install=explode(',',$this->input->post('old_qnty_prd_set[]'));
		$old_qnty_prd_single_to_install=explode(',',$this->input->post('old_qnty_prd_single[]'));
	$last_scheduled_data=$this->Admin_model->get_data('installation_details',array('insd_installation_id'=>$installation_id),'1','','insd_id','DESC');
	//pre_list($last_scheduled_data[0]->insd_id);
		if(array_values($old_qnty_prd_set_to_install)!=array_values($new_quantity_prd_set))
		{
			$prd_set_original_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_set_org_qnty);
			$prd_set_reamining_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_set_remaining_qnty);

			foreach($old_qnty_prd_set_to_install as $in1=>$opi)
			{
				if($opi!=$new_quantity_prd_set[$in1])
				{
					$difference_prd_set=$opi-$new_quantity_prd_set[$in1];
					$new_prd_data_set_last_installation_org[]=$difference_prd_set+$prd_set_original_qnty_in_last_scheduled[$in1];
					$new_prd_data_set_last_installation_remaining[]=$difference_prd_set+$prd_set_reamining_qnty_in_last_scheduled[$in1];
				}
				else
				{
					$difference_prd_set=$opi-$new_quantity_prd_set[$in1];
					$new_prd_data_set_last_installation_org[]=$difference_prd_set+$prd_set_original_qnty_in_last_scheduled[$in1];
					$new_prd_data_set_last_installation_remaining[]=$difference_prd_set+$prd_set_reamining_qnty_in_last_scheduled[$in1];
				}
			}

			$imploded_set_org_prd_qntys_toupdatein_last_installation=implode(',', $new_prd_data_set_last_installation_org);
			$imploded_set_remaining_qnty_toupdatein_last_installation=implode(',', $new_prd_data_set_last_installation_remaining);

			$array_update_last_installation_1=array(
				'insd_prd_set_org_qnty'=>$imploded_set_org_prd_qntys_toupdatein_last_installation,
				'insd_prd_set_remaining_qnty'=>$imploded_set_remaining_qnty_toupdatein_last_installation,
			);
			$this->Admin_model->update_data('installation_details',$array_update_last_installation_1,array('insd_id'=>$last_scheduled_data[0]->insd_id));
		}	
		if(array_values($old_qnty_prd_single_to_install)!=array_values($single_qty))
		{
			$prd_single_original_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_single_org_qnty);
			$prd_single_reamining_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_single_remaining_qnty);

			foreach($old_qnty_prd_single_to_install as $in2=>$opi2)
			{
				if($opi2!=$single_qty[$in2])
				{
					$difference_prd_singles=$opi2-$single_qty[$in2];
					$new_prd_data_single_last_installation_org[]=$difference_prd_singles+$prd_single_original_qnty_in_last_scheduled[$in2];
				$new_prd_data_single_last_installation_remaining[]=$difference_prd_singles+$prd_single_reamining_qnty_in_last_scheduled[$in2];
				}
				else
				{
					$difference_prd_singles=$opi2-$single_qty[$in2];
					$new_prd_data_single_last_installation_org[]=$difference_prd_singles+$prd_single_original_qnty_in_last_scheduled[$in2];
				$new_prd_data_single_last_installation_remaining[]=$difference_prd_singles+$prd_single_reamining_qnty_in_last_scheduled[$in2];
				}
			}

			$imploded_single_org_prd_qntys_toupdatein_last_installation=implode(',', $new_prd_data_single_last_installation_org);
			$imploded_single_remaining_qnty_toupdatein_last_installation=implode(',', $new_prd_data_single_last_installation_remaining);

			$array_update_last_installation_2=array(
				'insd_prd_single_org_qnty'=>$imploded_single_org_prd_qntys_toupdatein_last_installation,
				'insd_prd_single_remaining_qnty'=>$imploded_single_remaining_qnty_toupdatein_last_installation,
			);
			$this->Admin_model->update_data('installation_details',$array_update_last_installation_2,array('insd_id'=>$last_scheduled_data[0]->insd_id));
		}
	}
///////////////////////////////only on update ends here///////////////////////////////////////////////////////	
	$data=array(
		'insd_date'=>$new_formated_date1,
		'insd_labours'=>implode(',',$this->input->post('choose_labour[]')),
		'insd_vehicle'=>implode(',',$this->input->post('vehicle_choosed[]')),
		'insd_tools'=>implode(',',$this->input->post('choose_tools[]')),
		'insd_user_session'=>$this->session->userdata['user']['username'], 
		'insd_survey_id'=>$edit_survey_id,
		'insd_installation_id'=>$installation_id,
		'insd_prd_set_ids'=>$imploded_prd_set_ids,
		'insd_prd_single_ids'=>$imploded_prd_single_ids,

		'insd_prd_set_org_qnty'=>$imploded_org_prd_qntys,
		'insd_prd_set_qty_set_for_installation'=>$imploded_set_new_qnty,
		'insd_prd_set_remaining_qnty'=>$imploded_set_remaining_qnty,
		'insd_prd_set_start_qty'=>$imploded_prd_set_org_qnty,

		'insd_prd_single_org_qnty'=>$imploded_prd_single_org_new_qnty,
		'insd_prd_single_qty_set_for_installation'=>$imploded_prd_single_new_qnty,
		'insd_prd_single_remaining_qnty'=>$imploded_prd_single_remaining_qnty,
		'insd_prd_single_start_qty'=>$imploded_single_prd_qnty,
	
		'insd_time'=>get_time(),
		'insd_sts'=>'1',
	);
//pre_list($data);
	if(!empty($update_manage_installation))
	{
		$this->Admin_model->update_data('installation_details',$data,array('insd_id'=>$update_manage_installation));	
		$this->session->set_flashdata('success', 'Manage Installation details edited successfully');
	}
	else
	{
		$this->Admin_model->insert_data('installation_details',$data);	
		$this->session->set_flashdata('success', 'Installation managed successfully');
	}
	
	$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Installation -edited',
			'act_status'=>'Manage Installation Details,added/edit labour /vehicle/tools/qntity installation data',
			'act_installation_id'=>$installation_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
				);
	  $this->Admin_model->insert_data('activities',$activity_data);		 
	  redirect('list-installations');
}

function submit_set_installation_date()
{




    if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='submit_set_installation_date')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

	$installation_date=$this->input->post('mange_installation_date');
	$date0=explode('/',$installation_date);
				
				$date1=$date0[0];
				$month1=$date0[1];
				$year1=$date0[2];
				$new_formated_date1=$year1.'-'.$month1.'-'.$date1;

	$installation_id=$this->input->post('installation_id');

	$installation_details=$this->Admin_model->get_data('installation_details',array('insd_installation_id'=>$installation_id,'insd_date'=>$new_formated_date1));
	if(empty($installation_details))
	{
		$this->manage_installation($installation_id,'','',$new_formated_date1);
	}
	else
	{
		foreach($installation_details as $id)
		{
			if(!empty($id->insd_prd_set_ids) && !empty($id->insd_prd_single_ids))
			{
				if(empty($id->prd_set_final_calc_qnty) && empty($id->prd_single_final_calc_qnty))
				{
					$labour_list[]=$id->insd_labours;
				}	
			}
			elseif(!empty($id->insd_prd_set_ids) && empty($id->insd_prd_single_ids))
			{
				if(empty($id->prd_set_final_calc_qnty) && empty($id->prd_single_final_calc_qnty))
				{
					$labour_list[]=$id->insd_labours;
				}	
			}
			elseif(empty($id->insd_prd_set_ids) && !empty($id->insd_prd_single_ids))
			{
				if(empty($id->prd_set_final_calc_qnty) && empty($id->prd_single_final_calc_qnty))
				{
					$labour_list[]=$id->insd_labours;
				}	
			}
			else{}			
		}

		$final_labour_list=implode(',',$labour_list);
	$this->manage_installation($installation_id,'',$final_labour_list,$new_formated_date1);	
	}
}

else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 







}

function submit_edit_qty_installation()
{
	$prd_sets_id=$this->input->post('prd_set_ids[]');
	$qnty_prd_sets=$this->input->post('new_quantity_prd_set[]');
	$remaining_qty_prd_set=$this->input->post('prd_set_remaining_qty[]');
	
	$edit_survey_id=$this->input->post('edit_survey_id');
	$qty_prd_single=implode(',',$this->input->post('prd_single_quantity_new[]'));
	$remaining_qty_prd_single=implode(',',$this->input->post('prd_remaining_qty_single[]'));
//print_r($remaining_qty_prd_single);
$this->Admin_model->update_data('survey_table',array('st_qty_installed'=>$qty_prd_single,'st_qty_remaining_installation'=>$remaining_qty_prd_single),array('st_id'=>$edit_survey_id));

		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Installation quantity details',
			'act_status'=>'Installed and remaining quantity details for single products',
			'act_survey_id'=>$edit_survey_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
				);
		$this->Admin_model->insert_data('activities',$activity_data);

	foreach($prd_sets_id as $index=>$psd)
	{
		if(empty($remaining_qty_prd_set[$index]) || $remaining_qty_prd_set[$index]=='0' || $remaining_qty_prd_set[$index]==0)
		{
			$remaining_set='0';
		}
		else
		{
			$remaining_set=$remaining_qty_prd_set[$index];
		}
	//pre_list($remaining_qty_prd_set[$index]);
	$this->Admin_model->update_data('product_set_data',array('psd_qty_installed'=>$qnty_prd_sets[$index],'psd_qty_remaining_installation'=>$remaining_set),array('psd_id'=>$psd));
	
		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Installation quantity details for product set',
			'act_status'=>'Installed and remaining quantity details for product set with id '.$psd,
			'act_survey_id'=>$edit_survey_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
				);
		$this->Admin_model->insert_data('activities',$activity_data);
	}

 $this->session->set_flashdata('success', 'Installed Quantity updated successfully ');
 		redirect('list-installations');
}


function view_set_installation($installation_detail_id=null)
{
	if(logged_in())
	{
		if(!empty($installation_detail_id))
		{
			$data['instalation_details']=$this->Admin_model->get_data('installation_details',array('insd_id'=>$installation_detail_id));
	if(!empty($data['instalation_details']))		
 	{			
			$data['edit_instalation_detail_id']=$data['instalation_details'][0]->insd_id;
			$tools_needed=explode(',',$data['instalation_details'][0]->insd_tools);
		foreach($tools_needed as $tn)
		{
			$data['tools_details'][]=$this->Admin_model->get_data('assets_tools',array('tool_id'=>$tn));
		}
		$vehicle_needed=explode(',',$data['instalation_details'][0]->insd_vehicle);
		foreach($vehicle_needed as $vn)
		{
			$data['veh_details'][]=$this->Admin_model->get_data('assets_vehicle',array('veh_id'=>$vn));
		}

		$labour_needed=explode(',',$data['instalation_details'][0]->insd_labours);
		foreach($labour_needed as $ln)
		{
				$data['emp_details'][]=$this->srvm->get_login_emp_details(array('ed_id'=>$ln));
		}

		$prd_set_ids=explode(',',$data['instalation_details'][0]->insd_prd_set_ids);
			foreach ($prd_set_ids as $key => $psid) 
			{
				$data['prd_set_result'][]=$this->Admin_model->get_data('product_set_data',array('psd_id'=>$psid));
			}

		if(!empty($data['prd_set_result'][0]))
		{
			foreach($data['prd_set_result'] as $index1=>$psr)
			{
				$prd_ids_explode=explode(',',$psr[0]->psd_prd_id);
				$arrange_pos=explode(',', $psr[0]->psd_arrange_position);
				foreach($prd_ids_explode as $index11=>$q)
				{
					$data['prd_ids_1'][$index1][$arrange_pos[$index11]]=$this->tm->get_data('products',array('pid'=>$q));
				}
			}
		}
				///pre_list($data['prd_ids_1']);

			$prd_singles=explode(',', $data['instalation_details'][0]->insd_prd_single_ids);
			if(!empty($prd_singles))
			{
			foreach($prd_singles as $q1)
				{
					$data['prd_ids_2'][]=$this->tm->get_data('products',array('pid'=>$q1));
				}
			}
			else
			{
				$data['prd_ids_2']='0';
			}
			$data_in_prd_set=$data['instalation_details'][0]->insd_prd_set_ids;
			$data_in_prd_single=$data['instalation_details'][0]->insd_prd_single_ids;
			$qnty_installed_data_prd_set=$data['instalation_details'][0]->insd_prd_set_qty_installed;
			$qnty_installed_data_prd_single=$data['instalation_details'][0]->insd_prd_single_qty_installed;
	
			if(!empty($data_in_prd_set) && !empty($data_in_prd_single))	
			{
				$this->load->view('admin/production/view_to_install',$data);
				//print_r($qnty_installed_data_prd_set);
				//print_r($qnty_installed_data_prd_single);
				//echo "in if";
					// if(empty($qnty_installed_data_prd_set) && empty($qnty_installed_data_prd_single))
					// {
					// 	$this->load->view('admin/production/view_to_install',$data);
					// }
					// else
					// {
					// 	$this->session->set_flashdata('errors', 'Please wait for the next set of installation from survey department.');
 					// 	redirect('list_scheduled/'.$data['instalation_details'][0]->insd_installation_id);
					// }
			}
			elseif(!empty($data_in_prd_set) && empty($data_in_prd_single))
			{
				$this->load->view('admin/production/view_to_install',$data);
				//echo "in else-if1";
				// if(empty($qnty_installed_data_prd_set))
				// {
				// 	$this->load->view('admin/production/view_to_install',$data);
				// }
				// else
				// {
				// 	$this->session->set_flashdata('errors', 'Please wait for the next set of installation from survey department.');
 				// redirect('list_scheduled/'.$data['instalation_details'][0]->insd_installation_id);
				// }
			}
			elseif(empty($data_in_prd_set) && !empty($data_in_prd_single))
			{
				$this->load->view('admin/production/view_to_install',$data);
				//echo "in else-if1 2";
				// if(empty($qnty_installed_data_prd_single))
				// {
				// 	$this->load->view('admin/production/view_to_install',$data);
				// }
				// else
				// {
				// 	$this->session->set_flashdata('errors', 'Please wait for the next set of installation from survey department.');
 				// 	redirect('list_scheduled/'.$data['instalation_details'][0]->insd_installation_id);
				// }
			}
			else
			{ 
				//echo "in else1";
				$this->session->set_flashdata('errors', 'Please wait for the next set of installation from survey department.');
 				redirect('list_scheduled/'.$data['instalation_details'][0]->insd_installation_id);
			}
		}
		else
		{
			$this->session->set_flashdata('errors', 'Please wait for set of installation from survey department.');
 				redirect('list_scheduled/'.$data['instalation_details'][0]->insd_installation_id);
		}	
		}
	}
}

function submit_installation_details()
{
 	$installation_details_id=$this->input->post('installation_details_id');
	$prd_set_ids=explode(',',$this->input->post('prd_set_prd_ids'));
	$prd_singles_id=explode(',',$this->input->post('single_prd_ids'));
	$prd_set_qty_installed=explode(',',$this->input->post('prd_set_installed_no'));
	$prd_single_qty_installed=explode(',',$this->input->post('single_prd_installed_no'));
	$prd_set_qty_remining=explode(',',$this->input->post('prd_set_remaining_no'));
	$prd_single_qty_remaining=explode(',',$this->input->post('single_prd_remaining_no'));
//pre_list($this->input->post('prd_single_qnty_installed[]'));
$installation_table_details=$this->Admin_model->get_data('installation_details',array('insd_id'=>$installation_details_id));

	$prd_set_remainig_from_survey=explode(',',$installation_table_details[0]->insd_prd_set_remaining_qnty);
	$prd_single_remaining_from_survey=explode(',',$installation_table_details[0]->insd_prd_single_remaining_qnty);
	//////qty_set_for_installation/////////
	$prd_set_for_installation_from_survey=explode(',',$installation_table_details[0]->insd_prd_set_qty_set_for_installation);
	$prd_single_set_for_installation_from_survey=explode(',',$installation_table_details[0]->insd_prd_single_qty_set_for_installation);

	$last_scheduled_data=$this->Admin_model->get_data('installation_details',array('insd_installation_id'=>$installation_table_details[0]->insd_installation_id),'1','','insd_id','DESC');

	$prd_set_original_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_set_org_qnty);
	$prd_set_reamining_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_set_remaining_qnty);
	$prd_single_original_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_single_org_qnty);
	$prd_single_reamining_qnty_in_last_scheduled=explode(',',$last_scheduled_data[0]->insd_prd_single_remaining_qnty);

if(!empty($prd_set_ids))
{
	foreach($prd_set_ids as $index1=>$psid1)
	{
		if($prd_set_qty_installed[$index1]=='0')
		{
			if($prd_set_for_installation_from_survey[$index1]=='0')
			{
//pre_list($prd_set_original_qnty_in_last_scheduled);
$set_new_qty_remaining_final_calc[]=
$prd_set_original_qnty_in_last_scheduled[$index1];
			}
			else{
		//		echo "in else of prd set";
		$set_new_qty_remaining_final_calc[]=$prd_set_for_installation_from_survey[$index1]+$prd_set_remainig_from_survey[$index1];
			}
		}
		else
		{
		//	echo "in else";
		$set_new_qty_remaining_final_calc[]=$prd_set_remainig_from_survey[$index1]+$prd_set_qty_remining[$index1];
		}
	}
}
	//pre_list($prd_set_qty_remining);
if(!empty($prd_singles_id))
{
	foreach($prd_singles_id as $index2=>$psid2)
	{
		if($prd_single_qty_installed[$index2]=='0')
		{
			if($prd_single_set_for_installation_from_survey[$index2]=='0')
			{
			//	echo "in if of single";
				$single_new_qty_remaining_final_calc[]=$prd_single_original_qnty_in_last_scheduled[$index2];
			}
			else
			{
				//echo "in else of single";
		$single_new_qty_remaining_final_calc[]=$prd_single_set_for_installation_from_survey[$index2]+$prd_single_remaining_from_survey[$index2];
			}
		}
		else
		{
			//echo "in main else of single";
		$single_new_qty_remaining_final_calc[]=$prd_single_remaining_from_survey[$index2]+$prd_single_qty_remaining[$index2];
		}
	}
}

if(!empty($prd_set_ids))
{
	foreach($prd_set_qty_remining as $ind=>$v)
	{
		$new_last_scheduled_prd_set_org[]=$prd_set_original_qnty_in_last_scheduled[$ind]+$v;
		$new_last_scheduled_prd_set_remaining[]=$prd_set_reamining_qnty_in_last_scheduled[$ind]+$v;
	}
}
else
{
	$new_last_scheduled_prd_set_org[]='';
	$new_last_scheduled_prd_set_remaining[]='';
}

if(!empty($prd_singles_id))
{
	foreach($prd_single_qty_remaining as $ind2=>$v2)
	{
		$new_last_scheduled_prd_single_org[]=$prd_single_original_qnty_in_last_scheduled[$ind2]+$v2;
		$new_last_scheduled_prd_single_remaining[]=$prd_single_reamining_qnty_in_last_scheduled[$ind2]+$v2;
	}
}
else
{
	$new_last_scheduled_prd_single_org[]='';
	$new_last_scheduled_prd_single_remaining[]='';
}
	$array_update_last_scheduled=array(
		'insd_prd_set_org_qnty'=>implode(',',$new_last_scheduled_prd_set_org),
		'insd_prd_set_remaining_qnty'=>implode(',',$new_last_scheduled_prd_set_remaining),
		'insd_prd_single_org_qnty'=>implode(',',$new_last_scheduled_prd_single_org),
		'insd_prd_single_remaining_qnty'=>implode(',',$new_last_scheduled_prd_single_remaining),
		);
	//	pre_list($array_update_last_scheduled);
	$update_id_last_scheduled=$this->Admin_model->update_data('installation_details',$array_update_last_scheduled,array('insd_id'=>$last_scheduled_data[0]->insd_id));

	$data=array(
		// 'insd_prd_set_org_qnty'=>implode(',',$set_new_qty_remaining_final_calc),
		'insd_prd_set_qty_installed'=>implode(',',$prd_set_qty_installed),
		'insd_prd_set_remaining_after_installation'=>implode(',',$prd_set_qty_remining),
		'prd_set_final_calc_qnty'=>implode(',',$set_new_qty_remaining_final_calc),
		// 'insd_prd_set_remaining_qnty'=>implode(',',$set_new_qty_remaining_final_calc),
		// 'insd_prd_single_org_qnty'=>implode(',',$single_new_qty_remaining_final_calc),
		'insd_prd_single_qty_installed'=>implode(',',$prd_single_qty_installed),
		'insd_prd_single_remaining_after_installation'=>implode(',',$prd_single_qty_remaining),
		'prd_single_final_calc_qnty'=>implode(',',$single_new_qty_remaining_final_calc),
		// 'insd_prd_single_remaining_qnty'=>implode(',',$single_new_qty_remaining_final_calc),
		);
		//pre_list($data);
	$update_id=$this->Admin_model->update_data('installation_details',$data,array('insd_id'=>$installation_details_id));

if($update_id)
		{
    $this->session->set_flashdata('success', 'Details entered successfully');
    redirect('complete_installation_details/'.$installation_details_id);
 		}	
 		else
 		{
 	$this->session->set_flashdata('errors', 'Something went wrong, Please update the installation details again.');
    redirect('view_set_installation/'.$installation_details_id);
 		}
}

function generate_installation($survey_id)
{
	if(logged_in())
	{
		if(!empty($survey_id))
		{
			$data['survey_result']=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));
			$data['prd_set_details']=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$survey_id));	
			
			foreach($data['prd_set_details'] as $index1=>$psr)
			{
				$prd_ids_explode=explode(',', $psr->psd_prd_id);
				$arrange_pos=explode(',', $psr->psd_arrange_position);
				foreach($prd_ids_explode as $index11=>$q)
						{
							$data['prd_ids_1'][$index1][$arrange_pos[$index11]]=$this->tm->get_data('products',array('pid'=>$q));
						}
			}
					
			$single_prd_ids=explode(',',$data['survey_result'][0]->st_single_prds);	
			if(!empty($single_prd_ids))
			{
			foreach($single_prd_ids as $q1)
						{
							$data['prd_ids_2'][]=$this->tm->get_data('products',array('pid'=>$q1));
						}
			}
			else
			{
				$data['prd_ids_2']='0';
			}				

			$data['edit_survey_id']=$survey_id;
			$data['single_prd_qty']=$data['survey_result'][0]->st_single_prd_qtys;

			$this->load->view('admin/production/generate_installation',$data);
		}
	}
}


function generate_pdf_installation($installation_id,$remaining=null)
{
$result=$this->Admin_model->get_data('installation_dept',array('ins_id'=>$installation_id));
$survey_details=$this->Admin_model->get_data('survey_table',array('st_id'=>$result[0]->ins_survey_id));
	$prd_set_details=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$survey_details[0]->st_id));
	
	foreach($prd_set_details as $index=>$ppp)
			{
				$prds_id_sets=explode(',',$ppp->psd_prd_id);
				$prod_position=explode(',',$ppp->psd_arrange_position);
				foreach($prds_id_sets as $index2=>$q)
				{
					$prd_ids[$index][$prod_position[$index2]]=$this->tm->get_data('products',array('pid'=>$q));
				}
			}
			$single_prd_sets=explode(',',$survey_details[0]->st_single_prds);
				foreach($single_prd_sets as $q)
				{
					$prd_ids2[]=$this->tm->get_data('products',array('pid'=>$q));
				}
$stylesheet = file_get_contents('style_mpdf.css');

	$html='<!doctype html>
<head>        
</head>
    <body> ';
				$html.='
				<div class="content">
				<table border="0" width="100%">
				<tr >
					<td align="left" rowspan="3"><h1 style="text-align:left">Complete Installation Report</h1></td>
					
					<td style="text-align:right;" align="right">
						<div style="text-align:right;">
							<p align="right" style="text-align:justify;">Create by: '.$survey_details[0]->st_user_created.'</p>
						
							
							<p align="right" style="text-align:justify;">Survey No. #: '.$survey_details[0]->st_survey_no.'</p>
							
							<p align="right" style="text-align:justify;">Date: '.date('Y-m-d').'</p>
						</div>
					</td>
				</tr>
				</table>
				</div>';

			
				$html.='<table align="center" class="cusotmer_info"  width="80%" border="1">';
				
				$html.='<tr>
					<td>Customer: '.$survey_details[0]->st_new_cust_name.'</td>
					<td>Company Name: '.$survey_details[0]->st_new_cust_comp.'</td>
				</tr>
				<tr>
					<td>Start Cordinates: '.$survey_details[0]->st_start_cordinate.'</td>
					<td>End Cordinates: '.$survey_details[0]->st_end_cordinate.'</td>
				</tr>
				<tr>
					<td>Project Engineer: '.$survey_details[0]->st_user_created.'</td>
					<td>Installation Start Date : '.$result[0]->ins_schedule_date.'<br/>Installation End Date : '.$result[0]->ins_date_set_installation.'</td>
					
				</tr>
				</table>
				<table align="center" class="prd_info"  width="80%" border="1">
					<tr class="prd_head" >
					<th>Items</th>
					<th>Items Description</th>';

					if(!empty($remaining))
					{
					$html.='<th>Quantites Installed</th>
					<th>Remaining Quantites</th>';
					}
					else
					{
					$html.='<th>Quantites(pcs)</th>';
					}
					$html.='<th>Sign Size(Sqm)</th>
					<th>Total 2mm Sign Qty(Sqm)</th>
					<th>Total 3mm Sign Qty(Sqm)</th>';
					$html.='<th >Pipe Height</th>
					<th>Pipe Quantity</th>
					<th>SS Clamps Qty(Nos.)</th>
					<th>PVC Cap Qty(Nos.)</th>
					</tr>
					<tbody>';
					//pre_list($prd_ids);
					foreach($prd_ids as $index_p=>$p1)
					{
						$alignment=$prd_set_details[$index_p]->psd_prd_alignment;
						$prod_position=explode(',',$prd_set_details[$index_p]->psd_arrange_position);
						 //pre_list($prod_position);
						// pre_list($prod_position);		 
						foreach($prod_position as $pd2)
						{
						//pre_list($p1[$pd2][0]->pname);
							if(empty($p1[$pd2][0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
								 }

								 $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
								 $prod_sets_name[$index_p][]=$p1[$pd2][0]->pname;
								 $prod_sets_size[$index_p][]=$p1[$pd2][0]->p_area;

								  $prod_sets_clamps_req[$index_p][]=$p1[$pd2][0]->p_clamp;

								  $prd_al_type[$index_p][]=$p1[$pd2][0]->p_al_type;
								 
								 $prod_sets_image[$index_p][]=$img_path;
								 $prod_sets_alignment[$index_p]=$alignment;
								 $prod_sets_position[$index_p]=$prod_position;
							 	$prd_set_qnty[$index_p]=$prd_set_details[$index_p]->psd_prd_qty;
								$prd_set_pipe_hgt[$index_p]=$prd_set_details[$index_p]->psd_pipe_hgt;
								$prd_set_pipe_qty[$index_p]=$prd_set_details[$index_p]->psd_pipe_qnty;

						}
					}
					foreach($prod_sets_alignment as $index=>$align)
					{
					//pre_list($prod_sets_position[$index]);
						//pre_list($prd_set_qnty[$index]);
						if($align=="vertical")
						{
							//pre_list(implode(',',$prod_sets_image[$index]));
							$html.="<tr>";
						$html.="<td>";
						asort($prod_sets_position[$index]);	$sum_prd_set_size=0;
						
							foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
							$prd_set_name[$index][]=str_replace('|~~|', '', $prod_sets_name[$index][$index22]).' ('.$prod_sets_size[$index][$index22]* 0.000001.' sqm) ';
								
							$prd_clamps_total[$index][]=$prod_sets_clamps_req[$index][$index22]*$prd_set_qnty[$index];
								// $sum_prd_set_size=$sum_prd_set_size+$prod_sets_size[$index][$index22]* 0.000001;
							$prd_set_sizes[$index][]=array_sum($prod_sets_size[$index]);

								if(!empty($prod_sets_image[$index][$index22]))
							$html.="<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
							else
							$html.="";
							}
	//pre_list($prd_clamps_total);

							$html.="Alignment : Vertical </td>";
							$html.='<td>'.implode('+<br/>',$prd_set_name[$index]).'</td>';////item description goes here
							if(!empty($remaining))
							{
									$html.="<td>".$prd_set_details[$index]->psd_qty_installed."</td>";
								$html.="<td>".$prd_set_details[$index]->psd_qty_remaining_installation."</td>";
							}
							else
							{
								$html.="<td>".$prd_set_qnty[$index]."</td>";
							}
							if(!empty($prd_al_type[$index]))
							{
								if(in_array('3mm',$prd_al_type[$index]))
								{
									$thickness_three_mm[$index]=$prd_set_qnty[$index]*$prd_set_sizes[$index][0]*0.000001;
								}
								else
								{
									$thickness_two_mm[$index]=$prd_set_qnty[$index]*$prd_set_sizes[$index][0]*0.000001;
								}
							}

							$html.='<td>'.number_format((float)$prd_set_sizes[$index][0]*0.000001, 2, '.', '').' sqm</td>';//////sign size sqm
							$html.='<td>';
							if(!empty($thickness_two_mm[$index])){
								$html.=number_format((float)$thickness_two_mm[$index], 2, '.', '');
							}
							$html.='</td>';///2mm sign qnty
							$html.='<td>';
							if(!empty($thickness_three_mm[$index])){
								$html.=number_format((float)$thickness_three_mm[$index], 2, '.', '');
							}
							$html.='</td>';///3mm sign qnty
							$html.="<td>".$prd_set_pipe_hgt[$index]." meter</td>";
							$html.="<td>".$prd_set_pipe_qty[$index]."</td>";
							$html.='<td>'.array_sum($prd_clamps_total[$index]).'</td>';/// sign clamp
							$html.='<td>'.$prd_set_pipe_qty[$index].'</td>';/// sign cap
							$html.="</tr>";
						}
						else
						{
							$html.="<tr>";
							$html.="<td>";
							asort($prod_sets_position[$index]);
							foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
								$prd_set_name[$index][]=str_replace('|~~|', '', $prod_sets_name[$index][$index22]).' ('.$prod_sets_size[$index][$index22]* 0.000001.' sqm) ';
								
							$prd_clamps_total[$index][]=$prod_sets_clamps_req[$index][$index22]*$prd_set_qnty[$index];
								// $sum_prd_set_size=$sum_prd_set_size+$prod_sets_size[$index][$index22]* 0.000001;
							$prd_set_sizes[$index][]=array_sum($prod_sets_size[$index]);
							//	pre_list([$ptt]);
									if(!empty($prod_sets_image[$index][$index22]))
							$html.="<img src='".$prod_sets_image[$index][$index22]."' width='80' height='100'>";
							else
							$html.="";
							}
							$html.="Alignment : Horizontal </td>";
							$html.='<td>'.implode('+<br/>',$prd_set_name[$index]).'</td>';////item description goes here
							if(!empty($remaining))
							{
								$html.="<td>".$prd_set_details[$index]->psd_qty_installed."</td>";
								$html.="<td>".$prd_set_details[$index]->psd_qty_remaining_installation."</td>";
							}
							else
							{
							$html.="<td>".$prd_set_details[$index]->psd_prd_qty."</td>";
							}
							if(!empty($prd_al_type[$index]))
							{
								if(in_array('3mm',$prd_al_type[$index]))
								{
									$thickness_three_mm[$index]=$prd_set_qnty[$index]*$prd_set_sizes[$index][0]*0.000001;
								}
								else
								{
									$thickness_two_mm[$index]=$prd_set_qnty[$index]*$prd_set_sizes[$index][0]*0.000001;
								}
							}
							$html.='<td>'.number_format((float)$prd_set_sizes[$index][0]*0.000001, 2, '.', '').' sqm</td>';//////sign size sqm
							$html.='<td>';
							if(!empty($thickness_two_mm[$index])){
								$html.=number_format((float)$thickness_two_mm[$index], 2, '.', '');
							}
							$html.='</td>';///2mm sign qnty
							$html.='<td>';
							if(!empty($thickness_three_mm[$index])){
								$html.=number_format((float)$thickness_three_mm[$index], 2, '.', '');
							}
							$html.='</td>';///3mm sign qnty
							$html.="<td>".$prd_set_details[$index]->psd_pipe_hgt." meter</td>";
							$html.="<td>".$prd_set_details[$index]->psd_pipe_qnty."</td>";
							$html.='<td>'.array_sum($prd_clamps_total[$index]).'</td>';/// sign clamp
							$html.='<td>'.$prd_set_pipe_qty[$index].'</td>';/// sign cap
							$html.="</tr>";
						}
					}
$single_prd_qtys=explode(',',$survey_details[0]->st_single_prd_qtys);
$single_pipe_hgt=explode(',',$survey_details[0]->st_single_pipe_hgt);
$single_pipe_qty=explode(',',$survey_details[0]->st_single_pipe_qty);

$single_prd_installed_qty=explode(',',$survey_details[0]->st_qty_installed);
$single_prd_remianing_qty=explode(',',$survey_details[0]->st_qty_remaining_installation);
if(!empty($survey_details[0]->st_single_prds))
{
	$sum_sign_size_single=0;
					foreach($prd_ids2 as $ind=>$pd22)
					{
						$sign_size=$pd22[0]->p_area*0.000001;
	//pre_list($pd22);
						if(empty($pd22[0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$pd22[0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$pd22[0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$pd22[0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$pd22[0]->p_prd_img;
								 }
						$html.="<tr>";
							$html.="<td>";
							if(!empty($img_path))
							$html.="<img src='".$img_path."' width='100' height='100'>";
						else
							$html.="";
							$html.="</td>";
							$html.='<td>'.$pd22[0]->pname.'('.number_format((float)$sign_size, 5, '.', '').' sqm)</td>';////item description goes here
							if(!empty($remaining))
							{
								$html.="<td>".$single_prd_installed_qty[$ind]."</td>";
								$html.="<td>".$single_prd_remianing_qty[$ind]."</td>";
							}
							else
							{
							$html.="<td>".$single_prd_qtys[$ind]."</td>";
							}
							$html.='<td>'.number_format((float)$sign_size, 2, '.', '').' sqm</td>';//////sign size sqm
							$html.='<td>';
							if(!empty($pd22[0]->p_al_type))
							{
								if($pd22[0]->p_al_type=='2mm')
								$html.=number_format((float)$single_prd_qtys[$ind]*$sign_size, 2, '.', '');
								else
									$html.='';
							}
							$html.='</td>';///2mm sign qnty
							$html.='<td>';
							if(!empty($pd22[0]->p_al_type))
							{
								if($pd22[0]->p_al_type=='3mm')
								$html.=number_format((float)$single_prd_qtys[$ind]*$sign_size, 2, '.', '');
								else
									$html.='';
							}
							$html.='</td>';///3mm sign qnty
							$html.="<td>".$single_pipe_hgt[$ind]." meter</td>";
							$html.="<td>".$single_pipe_qty[$ind]."</td>";
							$html.='<td>'.$pd22[0]->p_clamp*$single_prd_qtys[$ind].'</td>';/// sign clamp
							$html.='<td>'.$single_pipe_qty[$ind].'</td>';/// sign cap
							$html.="</tr>";
					}
				}
				$html.='<tr>
				<td>
				</tr>';
		$html.='</tbody></table>';
			$html.='</body>
					</html>';
				//	echo $html;
 $pdfFilePath = $survey_details[0]->st_survey_no.'_complete_survey.pdf';
	  
		 $this->load->library('m2_pdf');
		 $this->m2_pdf->pdf->SetHeader('<img src="'.base_url("berry_header.png").'">');
		  $this->m2_pdf->pdf->SetFooter('<img src="'.base_url("berry_footer.png").'">');
		  $this->m2_pdf->pdf->WriteHTML($stylesheet,1);
		  $this->m2_pdf->pdf->AddPage('', // L - landscape, P - portrait 
        '', '', '', '',
        5, // margin_left
        5, // margin right
       35, // margin top
       20, // margin bottom
        0, // margin header
        0); // margin footer              
	    $this->m2_pdf->pdf->WriteHTML($html,2);
	     
	     //save in folder
		$this->m2_pdf->pdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");
		ob_clean(); 
  		$this->m2_pdf->pdf->Output($pdfFilePath,'D');
  		
$this->session->set_flashdata('success', 'Installation PDF generated successfully');
  	redirect('list-installations');
}


function generate_installation_excel($installation_details_id=null)
{
  $this->load->library("excel");
  $object = new PHPExcel();

  $object->setActiveSheetIndex(0);
$installation_details=$this->Admin_model->get_data('installation_details',array('insd_id'=>$installation_details_id));
$survey_details=$this->Admin_model->get_data('survey_table',array('st_id'=>$installation_details[0]->insd_survey_id));
	$prd_set_details=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$survey_details[0]->st_id));
	
	if(!empty($installation_details[0]))
		{
				if(!empty($installation_details[0]->insd_tools))
				{	
				$tools_needed=explode(',',$installation_details[0]->insd_tools);
					foreach($tools_needed as $tn)
					{
						if(!empty($tn))
						$tools_details[]=$this->Admin_model->get_data('assets_tools',array('tool_id'=>$tn));
					}
				}
				if(!empty($installation_details[0]->insd_vehicle))
				{
					$vehicle_needed=explode(',',$installation_details[0]->insd_vehicle);
					foreach($vehicle_needed as $vn)
					{
						if(!empty($vn))
						$veh_details[]=$this->Admin_model->get_data('assets_vehicle',array('veh_id'=>$vn));
					}
				}
				if(!empty($installation_details[0]->insd_labours))
				{	
					$labour_needed=explode(',',$installation_details[0]->insd_labours);
					foreach($labour_needed as $ln)
					{
						if(!empty($ln))
							$emp_details[]=$this->srvm->get_login_emp_details(array('ed_id'=>$ln));
					}
				}

				$prd_qnty_set_for_installation=explode(',',$installation_details[0]->insd_prd_set_qty_set_for_installation);
				$prd_single_qnty_set_for_installation=explode(',',$installation_details[0]->insd_prd_single_qty_set_for_installation);
		}
	foreach($prd_set_details as $index=>$ppp)
			{
				$prds_id_sets=explode(',',$ppp->psd_prd_id);
				$prod_position=explode(',',$ppp->psd_arrange_position);
				foreach($prds_id_sets as $index2=>$q)
				{
					$prd_ids[$index][$prod_position[$index2]]=$this->tm->get_data('products',array('pid'=>$q));
				}
			}

			$single_prd_sets=explode(',',$survey_details[0]->st_single_prds);
				foreach($single_prd_sets as $q)
				{
					$prd_ids2[]=$this->tm->get_data('products',array('pid'=>$q));
				}
		
        foreach($prd_ids as $index_p=>$p1)
		{
			$alignment=$prd_set_details[$index_p]->psd_prd_alignment;
			$prod_position=explode(',',$prd_set_details[$index_p]->psd_arrange_position);
			foreach($prod_position as $pd2)
			{
			$pset_pcode[$index_p][]=$p1[$pd2][0]->pcode;
			$pset_org_qnty[$index_p][]=$prd_set_details[$index_p]->psd_prd_qty;
			$pset_qnty_set_for_installation[$index_p][]=$prd_qnty_set_for_installation[$index_p];
			$pset_prd_pipe_hgt[$index_p][]=$prd_set_details[$index_p]->psd_pipe_hgt;
			//$pset_to_install_qnty[]=$p1[$pd2][0]->psd_prd_qty;
			}
		}
 $object->getActiveSheet()->setCellValue('A1', 'Item Code');
         $object->getActiveSheet()->setCellValue('B1', 'Original Quantity');
         $object->getActiveSheet()->setCellValue('C1', 'Quantity To Install');
         $object->getActiveSheet()->setCellValue('D1', 'Pipe Height (in meter)');
        
 $ex_row=2;
		foreach($prd_ids as $index_p=>$p1)
		{
			$object->getActiveSheet()->setCellValue('A' . $ex_row, implode(',',$pset_pcode[$index_p]));						
		    $object->getActiveSheet()->setCellValue('B' . $ex_row, $pset_org_qnty[$index_p][0]);
	        $object->getActiveSheet()->setCellValue('C' . $ex_row, $pset_qnty_set_for_installation[$index_p][0]);
	        $object->getActiveSheet()->setCellValue('D' . $ex_row, $pset_prd_pipe_hgt[$index_p][0]);
	       $ex_row++;
		}	
					//pre_list($prod_sets_position);			
$single_prd_qtys=explode(',',$survey_details[0]->st_single_prd_qtys);
$single_pipe_hgt=explode(',',$survey_details[0]->st_single_pipe_hgt);
$single_pipe_qty=explode(',',$survey_details[0]->st_single_pipe_qty);

$single_prd_installed_qty=explode(',',$survey_details[0]->st_qty_installed);
$single_prd_remianing_qty=explode(',',$survey_details[0]->st_qty_remaining_installation);

 $object->getActiveSheet()->setCellValue('F1', 'Item Code');
         $object->getActiveSheet()->setCellValue('G1', 'Original Quantity');
         $object->getActiveSheet()->setCellValue('H1', 'Quantity To Install');
         $object->getActiveSheet()->setCellValue('I1', 'Pipe Height (in meter)');
  $ex_row1=2;
				if(!empty($survey_details[0]->st_single_prds))
				{
					foreach($prd_ids2 as $ind=>$pd22)
					{
						$object->getActiveSheet()->setCellValue('F' . $ex_row1, $pd22[0]->pcode);
						if(!empty($single_prd_qtys[$ind]))
							$object->getActiveSheet()->setCellValue('G' . $ex_row1, $single_prd_qtys[$ind]);
						else
							$object->getActiveSheet()->setCellValue('G' . $ex_row1, "0");
						if(!empty($prd_single_qnty_set_for_installation[$ind]))
				             $object->getActiveSheet()->setCellValue('H' . $ex_row1, $prd_single_qnty_set_for_installation[$ind]);
				         else
				         	 $object->getActiveSheet()->setCellValue('H' . $ex_row1, "0");
				        if(!empty($single_pipe_hgt[$ind])) 	
				             $object->getActiveSheet()->setCellValue('I' . $ex_row1, $single_pipe_hgt[$ind]);
				        else
				        	 $object->getActiveSheet()->setCellValue('I' . $ex_row1, "0");
				             $ex_row1++;
					}
				}
//echo $excel_rows;				 
//pre_list($object);
  $object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
  header('Content-Type: application/vnd.ms-excel');
  header('Content-Disposition: attachment;filename="Installation excel.xls"');
  $object_writer->save('php://output');
 }


function change_sts_installation($installation_id,$sts)
{
	if(!empty($installation_id))
	{
		$this->Admin_model->update_data('installation_dept',array('ins_sts_installation'=>$sts),array('ins_id'=>$installation_id));
		
		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Installation -status change',
			'act_status'=>'Status changed to '.$sts,
			'act_installation_id'=>$installation_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
				);
		$this->Admin_model->insert_data('activities',$activity_data);
		
 		$this->session->set_flashdata('success', 'Installation status changed successfully ');
 		redirect('list-installations');
	}
}

function submit_installation_img()
{
	$installation_id=$this->input->post('instlation_id_img');
	$targetfolder='./uploads/installation/';
  if (isset($_FILES['installation_img']['name']) && $_FILES['installation_img']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'installation_img',
				'upload_path'=>$targetfolder,
			);
			$pic_names=single_img_upload($img_array1);
			if(!empty($pic_names))
			{
				$value_pp_aray=$pic_names;
			}
			else
			{
				$value_pp_aray='';
			}	
		}
$this->Admin_model->update_data('installation_dept',array('ins_photo'=>$value_pp_aray),array('ins_id'=>$installation_id));
	
		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Installation -image added',
			'act_status'=>'Image added for installation ',
			'act_installation_id'=>$installation_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
				);
		$this->Admin_model->insert_data('activities',$activity_data);
		
 		$this->session->set_flashdata('success', 'Installation image uploaded successfully ');
 		redirect('list-installations');
}


function installation_history($installation_id=null)
{
	if(logged_in())
	{
		if(!empty($installation_id))
		{
			$data['result']=$this->Admin_model->get_data('activities',array('act_installation_id'=>$installation_id));
			$data['page']='installation';
			$this->load->view('admin/production/survey_history',$data);
		}
	}
}


function complete_installation_details($insd_id=null)
{
	if(logged_in())
	{
		if(!empty($insd_id))
		{
			$data['installation_detail_id']=$insd_id;
			$data['result']=$this->Admin_model->get_data('installation_details',array('insd_id'=>$insd_id));

			if(!empty($data['result'][0]->insd_prd_set_ids))
			{
				$prd_set_qntys_installed=$data['result'][0]->insd_prd_set_qty_installed;
			}
			
			if(!empty($data['result'][0]->insd_prd_single_ids))
			{
				$prd_single_qtys_installed=$data['result'][0]->insd_prd_single_qty_installed;
			}
$labour_assigned= explode(',',$data['result'][0]->insd_labours);
foreach($labour_assigned as $la)
{
	$data['labour_info'][]=$this->Admin_model->get_data( 'employee_details',array('ed_id'=>$la,'ed_pos !='=>'FOREMAN'));
				$new_labours_list[]=$la;	
}

$sql=$this->db->query("SELECT * FROM `employee_details` WHERE `ed_branch`='6' AND `ed_sts`='1' AND `ed_id` NOT IN ( '" . implode( "', '" , $new_labours_list ) . "' )");
		$data['labour']=$sql->result_array();

$tools_assigned= explode(',',$data['result'][0]->insd_tools);
foreach($tools_assigned as $ta)
{
	$data['tool_info'][]=$this->Admin_model->get_data('assets_tools',array('tool_id'=>$ta));
}

$veh_assigned= explode(',',$data['result'][0]->insd_vehicle);
foreach($veh_assigned as $vh)
{
	$data['veh_info'][]=$this->Admin_model->get_data('assets_vehicle',array('veh_id'=>$vh));
}
			$data['survey_details']=$this->Admin_model->get_data('survey_table',array('st_id'=>$data['result'][0]->insd_survey_id));
	$data['prd_set_details']=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$data['survey_details'][0]->st_id));

			foreach($data['prd_set_details'] as $index1=>$psr)
			{
				if(!empty($prd_set_qntys_installed))
				{
					$prd_set_installed=explode(',',$prd_set_qntys_installed);
				}

				if(!empty($prd_set_installed[$index1]))
				{
				$prd_ids_explode=explode(',', $psr->psd_prd_id);
				$arrange_pos=explode(',', $psr->psd_arrange_position);
				foreach($prd_ids_explode as $index11=>$q)
						{
							$data['prd_ids_1'][$index1][$arrange_pos[$index11]]=$this->tm->get_data('products',array('pid'=>$q));
						}
				}
			}
					
			$single_prd_ids=explode(',',$data['survey_details'][0]->st_single_prds);
			if(!empty($prd_single_qtys_installed))
				{
					$prd_singles_installed=explode(',',$prd_single_qtys_installed);
				}	
			if(!empty($single_prd_ids))
			{
			foreach($single_prd_ids as $index11=>$q1)
						{
							if(!empty($prd_singles_installed[$index11]))
							$data['prd_ids_2'][]=$this->tm->get_data('products',array('pid'=>$q1));
						}
			}
			else
			$data['prd_ids_2']='0';
		$this->load->view('admin/production/complete_installation_details',$data);
		}
	}
}

function single_prd_img_upload()
{
	
	$targetfolder='./uploads/installation/';
  if (isset($_FILES['instlation_img_single']['name']) && $_FILES['instlation_img_single']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'instlation_img_single',
				'upload_path'=>$targetfolder,
			);
			$pic_names=single_img_upload($img_array1);
			if(!empty($pic_names))
			{
				$value_pp_aray=$pic_names;
			}
			else
			{
				$value_pp_aray='';
			}	
		}
		echo $value_pp_aray;
}


function prd_set_img_upload()
{
	
	$targetfolder='./uploads/installation/';
  if (isset($_FILES['instlation_img_single']['name']) && $_FILES['instlation_img_single']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'instlation_img_single',
				'upload_path'=>$targetfolder,
			);
			$pic_names=single_img_upload($img_array1);
			if(!empty($pic_names))
			{
				$value_pp_aray=$pic_names;
			}
			else
			{
				$value_pp_aray='';
			}	
		}

		echo $value_pp_aray;
}


function submit_complete_installation()
{
	$insd_id=$this->input->post('installation_id');
	$survey_id=$this->input->post('edit_survey_id');

	$workers_id=$this->input->post('inst_workers_id[]');
	foreach($workers_id as $wd)
	{
		$workers_attendance[]=$this->input->post('attedance_'.$wd);
		$worker_attendance_is_no[]=$this->input->post('attedance_is_no_'.$wd);
		$work_quality[]=$this->input->post('work_quality_'.$wd);
		$pipe_installed_by_worker[]=$this->input->post('pipe_installed_'.$wd);
		$final_workers_list[]=$this->input->post('workers_final_id_'.$wd);
	}

	$tools_id_installation=$this->input->post('tools_id_installation[]');
	foreach($tools_id_installation as $td)
	{
		$tool_used[]=$this->input->post('tool_used_'.$td);
		$tool_used_is_no[]=$this->input->post('tool_used_is_no_'.$td);
	}

	$veh_id_installation=$this->input->post('veh_id_installation[]');
	foreach($veh_id_installation as $vh)
	{
		$veh_used[]=$this->input->post('veh_used_'.$vh);
		$veh_used_is_no[]=$this->input->post('veh_used_is_no_'.$vh);
	}

	$actual_start_date_installation=$this->input->post('actual_start_date_installation');
		$strt_date_actual=explode('/',$actual_start_date_installation);				
				$date2=$strt_date_actual[0];
				$month2=$strt_date_actual[1];
				$year2=$strt_date_actual[2];
				$new_formated_date1=$year2.'-'.$month2.'-'.$date2;

	$actual_end_date_installation=$this->input->post('actual_end_date_installation');$end_date_actual=explode('/',$actual_end_date_installation);				
				$date21=$end_date_actual[0];
				$month21=$end_date_actual[1];
				$year21=$end_date_actual[2];
				$new_formated_date2=$year21.'-'.$month21.'-'.$date21;

$prd_set_ids=explode(',',$this->input->post('prd_set_ids'));
$prd_set_id_with_data=$this->input->post('prd_set_id_with_data[]');
//pre_list($prd_set_id_with_data);
$prd_set_start_cordinate=$this->input->post('prd_set_start_cordinate[]');
$prd_set_image_array=$this->input->post('prd_set_img_uploaded[]');

//pre_list($prd_set_image_array);

$single_prd_id=explode(',',$this->input->post('single_prd_ids'));
$single_prd_id_with_data=$this->input->post('prd_single_id_with_data[]');
//pre_list($single_prd_id_with_data);
 $single_prd_start_cordinate=$this->input->post('single_prd_start_cordinate[]');
 $single_prd_image_array=$this->input->post('single_prd_img_uploaded[]');

$prd_set_installed_data=$this->input->post('prd_set_qnty_installed_with_data[]');
$single_prd_installed_data=$this->input->post('prd_single_qnty_installed_with_data[]');

////////////////////////////////here arranging array of img and codinates as per the data insatlled/////////////////////
foreach($prd_set_installed_data as $psid1)
{
	if(!empty($prd_set_start_cordinate || !empty($prd_set_image_array)))
	{
	 $prd_set_sample_cordinate[]=array_splice($prd_set_start_cordinate, 0, $psid1);
	  $prd_set_sample_img[]=array_splice($prd_set_image_array, 0, $psid1);
	}
	else
	{
		$prd_set_sample_cordinate[]='';
		 $prd_set_sample_img[]='';
	}
}

foreach($single_prd_installed_data as $psid2)
{
	if(!empty($single_prd_start_cordinate) || !empty($single_prd_image_array))
	{
	 $prd_single_sample_cordinate[]=array_splice($single_prd_start_cordinate, 0, $psid2);
	  $prd_single_sample_img[]=array_splice($single_prd_image_array, 0, $psid2);
	}
	else
	{
		$prd_single_sample_cordinate[]='';
		$prd_single_sample_img[]='';
	}
}
//////////////////////////////////end of arranging/////////////////////////////////////////////////////////////////////

//////////here creating array as per the product installed,empty the prd set which is not set for this isntallation/////////////////////////////////////
foreach($prd_set_id_with_data as $k1=>$p1)
{	
	if(in_array($p1,$prd_set_ids))
	{	
		$as_val=array_search($p1,$prd_set_ids);
		$prd_set_final_cordinate_array[$as_val][]=$prd_set_sample_cordinate[$k1];
		$prd_set_image_array_1[$as_val][]=$prd_set_sample_img[$k1];	
	}
	else
	{
		$prd_set_final_cordinate_array[$as_val][]='';
		$prd_set_image_array_1[$as_val][]='';
	}	
}	
///////////////////////////////////////end///////////////////////////////////////////////////////////////////////

///////////////creating new array as per the data from previous array////////////////////////////////////////////
	foreach($prd_set_ids as $k3=>$p3)
	{
		if(empty($prd_set_final_cordinate_array[$k3][0]))
		{
			$final_prd_cordinate_data[]='';
			$final_prd_set_image_data[]='';
		}
		else
		{
			$final_prd_cordinate_data[]=implode('|$$|',$prd_set_final_cordinate_array[$k3][0]);
			$final_prd_set_image_data[]=implode('|$$|',$prd_set_image_array_1[$k3][0]);
		}
	}
/////////////////////////////////// end //////////////////////////////////////////////////////////////////////////////
	foreach($single_prd_id_with_data as $k2=>$p2)
	{
		if(in_array($p2,$single_prd_id))
		{	
			$as_val_2=array_search($p2,$single_prd_id);
			$prd_single_final_cordinate_array[$as_val_2][]=$prd_single_sample_cordinate[$k2];
			$prd_single_image_array_1[$as_val_2][]=$prd_single_sample_img[$k2];
		}
		else
		{
			$prd_single_final_cordinate_array[$as_val_2][]='';
			$prd_single_image_array_1[$as_val_2][]='';
		}
	}

	foreach($single_prd_id as $k4=>$p4)
	{
		if(empty($prd_single_final_cordinate_array[$k4][0]))
		{
			$final_prd_single_cordinate_data[]='';
			$final_prd_single_image_data[]='';
		}
		else
		{
			$final_prd_single_cordinate_data[]=implode('|$$|',$prd_single_final_cordinate_array[$k4][0]);
			$final_prd_single_image_data[]=implode('|$$|',$prd_single_image_array_1[$k4][0]);
		}
	}
//////note : main seperation is with |##|, inside productt seperation is with $$//////
	$data=array(
		'prd_set_final_cordinate'=>implode('|##|', $final_prd_cordinate_data),
		'single_prd_final_cordinate'=>implode('|##|', $final_prd_single_cordinate_data),
		'prd_set_image'=>implode('|##|', $final_prd_set_image_data),
		'single_prd_img'=>implode('|##|', $final_prd_single_image_data),
		'installation_sts'=>'1',
		'insd_final_date'=>get_date(),
		'insd_final_time'=>get_time(),
		'labour_work_quality'=>implode('|#|',$work_quality),
		'labour_work_attendance'=>implode('|#|',$workers_attendance),
		'labour_pipe_installed'=>implode('|#|',$pipe_installed_by_worker),
		'labour_reason_for_no_attendance'=>implode('|#|',$worker_attendance_is_no),
		'vehicle_uage'=>implode('|#|',$veh_used),
		'vehicle_reason_for_no_usage'=>implode('|#|',$veh_used_is_no),
		'tools_usage'=>implode('|#|',$tool_used),
		'tools_reason_for_no_usage'=>implode('|#|',$tool_used_is_no),
		'actual_daily_installation_start_date'=>$new_formated_date1,
		'actual_daily_installation_end_date'=>$new_formated_date2,
		'actual_daily_installation_hours'=>$this->input->post('total_working_hours'),
		'additional_note_of_this_installation'=>$this->input->post('add_notes'),
		'labour_final_list'=>implode('|#|',$final_workers_list),
	);

//pre_list($data);
	 $this->Admin_model->update_data('installation_details',$data,array('insd_id'=>$insd_id));
	 $this->session->set_flashdata('success', 'Installation Final Details added successfully ');
  	redirect('list-installations');
}

function installation_report($ins_id=null,$page_type=null)
{
	if(logged_in())
	{
		if(!empty($ins_id))
		{
			$data['installation_id']=$ins_id;
			$data['result']=$this->Admin_model->get_data('installation_dept',array('ins_id'=>$ins_id));
			$data['survey_details']=$this->Admin_model->get_data('survey_table',array('st_id'=>$data['result'][0]->ins_survey_id));
			$data['prd_set_details']=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$data['survey_details'][0]->st_id));
			$data['installation_details']=$this->Admin_model->get_data('installation_details',array('insd_survey_id'=>$data['result'][0]->ins_survey_id,'insd_installation_id'=>$ins_id));
			foreach($data['prd_set_details'] as $index1=>$psr)
			{
				$prd_ids_explode=explode(',', $psr->psd_prd_id);
				$arrange_pos=explode(',', $psr->psd_arrange_position);
				foreach($prd_ids_explode as $index11=>$q)
						{
							$data['prd_ids_1'][$index1][$arrange_pos[$index11]]=$this->tm->get_data('products',array('pid'=>$q));
						}
			}
					
			$single_prd_ids=explode(',',$data['survey_details'][0]->st_single_prds);	
			if(!empty($single_prd_ids))
			{
			foreach($single_prd_ids as $q1)
						{
							$data['prd_ids_2'][]=$this->tm->get_data('products',array('pid'=>$q1));
						}
			}
			else
			$data['prd_ids_2']='0';

		if(!empty($data['installation_details']))
		{
			foreach($data['installation_details'] as $index2=>$ins_dt)
			{
			//pre_list($ins_dt->insd_tools);
				if(!empty($ins_dt->insd_tools))
				{	
				$tools_needed=explode(',',$ins_dt->insd_tools);
				
					foreach($tools_needed as $tn)
					{
						if(!empty($tn))
						$data['tools_details'][]=$this->Admin_model->get_data('assets_tools',array('tool_id'=>$tn));
					}
				}
				if(!empty($ins_dt->insd_vehicle))
				{
					$vehicle_needed=explode(',',$ins_dt->insd_vehicle);
					foreach($vehicle_needed as $vn)
					{
						if(!empty($vn))
						$data['veh_details'][]=$this->Admin_model->get_data('assets_vehicle',array('veh_id'=>$vn));
					}
				}
				if(!empty($ins_dt->insd_labours))
				{	
					$labour_needed=explode(',',$ins_dt->insd_labours);
					foreach($labour_needed as $ln)
					{
						if(!empty($ln))
							$data['emp_details'][]=$this->srvm->get_login_emp_details(array('ed_id'=>$ln));
					}
				}				
			}
		}
		if(empty($page_type))
$this->load->view('admin/production/installation_report',$data);
else
$this->load->view('admin/production/print_installation_report',$data);
		}
	}
}

function generate_pdf_current_installation($installation_details_id=null)
{
	if(logged_in())
	{
		if(!empty($installation_details_id))
		{
	$installation_details=$this->Admin_model->get_data('installation_details',array('insd_id'=>$installation_details_id));
	$survey_details=$this->Admin_model->get_data('survey_table',array('st_id'=>$installation_details[0]->insd_survey_id));
	$prd_set_details=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$survey_details[0]->st_id));
if(!empty($installation_details[0]))
		{
				if(!empty($installation_details[0]->insd_tools))
				{	
				$tools_needed=explode(',',$installation_details[0]->insd_tools);
					foreach($tools_needed as $tn)
					{
						if(!empty($tn))
						$tools_details[]=$this->Admin_model->get_data('assets_tools',array('tool_id'=>$tn));
					}
				}
				if(!empty($installation_details[0]->insd_vehicle))
				{
					$vehicle_needed=explode(',',$installation_details[0]->insd_vehicle);
					foreach($vehicle_needed as $vn)
					{
						if(!empty($vn))
						$veh_details[]=$this->Admin_model->get_data('assets_vehicle',array('veh_id'=>$vn));
					}
				}
				if(!empty($installation_details[0]->insd_labours))
				{	
					$labour_needed=explode(',',$installation_details[0]->insd_labours);
					foreach($labour_needed as $ln)
					{
						if(!empty($ln))
							$emp_details[]=$this->srvm->get_login_emp_details(array('ed_id'=>$ln));
					}
				}

				$prd_qnty_set_for_installation=explode(',',$installation_details[0]->insd_prd_set_qty_set_for_installation);
				$prd_single_qnty_set_for_installation=explode(',',$installation_details[0]->insd_prd_single_qty_set_for_installation);
		}

	 
$stylesheet = file_get_contents('style_mpdf.css');

	$html='<!doctype html>
<head>        
</head>
    <body> ';
				$html.='
				<div class="content">
				<table border="0" width="100%">
				<tr >
					<td align="left" rowspan="3"><h1 style="text-align:left">Survey Report</h1></td>
					
					<td style="text-align:right;" align="right">
						<div style="text-align:right;">
							<p align="right" style="text-align:justify;">Create by: '.$survey_details[0]->st_user_created.'</p>
						
							
							<p align="right" style="text-align:justify;">Survey No. #: '.$survey_details[0]->st_survey_no.'</p>
							
							<p align="right" style="text-align:justify;">Date: '.$installation_details[0]->insd_date.' , Time: '.$installation_details[0]->insd_time.'</p>
						</div>
					</td>
				</tr>
				</table>
				</div>';
$html.='<table align="center" class="prd_info"  width="80%" border="1">
			<tbody>
			<tr>
			<td>Company <br/> Customer Details : </td>
			<td>';
			$html.=$survey_details[0]->st_new_cust_comp.'<br/>'.$survey_details[0]->st_new_cust_name;
			
			$html.='</td></tr>
			<tr>
			<td>Assigned to : </td>
			<td>';
			foreach($emp_details as $ed)
			{ 
				$html.=$ed[0]->ed_name.',';
			}
			$html.='</td></tr>
			<tr>
			<td> Vehicle Assigned: </td>
			<td>';
			foreach($veh_details as $vd)
			{ 
				$html.='Plate No. - '.$vd[0]->veh_plate_no;
			}
			$html.='</td></tr>
			<tr>
			<td> Tools Assigned: </td>
			<td>';
			foreach($tools_details as $td)
			{ 
				$html.=$td[0]->tool_name.',';
			}
			$html.='</td>
			</tr>
			</tbody>
			</table>';

	$html.='<table align="center" class="prd_info"  width="80%" border="1">
					<tr class="prd_head" >
					<th >Items</th>
					<th >Item Description</th>';					
					$html.='
					<th>Quantites Set (for this Installation)</th>
					<th>Pipe Height (in meter)</th>';
					$html.='</tr>
					<tbody>';
					//pre_list($prd_ids);
					foreach($prd_ids as $index_p=>$p1)
					{
						$alignment=$prd_set_details[$index_p]->psd_prd_alignment;
						$prod_position=explode(',',$prd_set_details[$index_p]->psd_arrange_position);
						 //pre_list($prod_position);
						// pre_list($prod_position);
						 
						foreach($prod_position as $pd2)
						{
						//pre_list($p1[$pd2][0]->pname);
							if(empty($p1[$pd2][0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
								 }
								 
								  $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
								  $prod_sets_name[$index_p][]=$p1[$pd2][0]->pname;
								  $prod_sets_size[$index_p][]=$p1[$pd2][0]->p_area;
								  $prod_sets_clamps_req[$index_p][]=$p1[$pd2][0]->p_clamp;
								  $prd_al_type[$index_p][]=$p1[$pd2][0]->p_al_type;

								 $prod_sets_image[$index_p][]=$img_path;
								 $prod_sets_alignment[$index_p]=$alignment;
								 $prod_sets_position[$index_p]=$prod_position;
							 	$prd_set_qnty[$index_p]=$prd_set_details[$index_p]->psd_prd_qty;
								$prd_set_pipe_hgt[$index_p]=$prd_set_details[$index_p]->psd_pipe_hgt;
								$prd_set_pipe_qty[$index_p]=$prd_set_details[$index_p]->psd_pipe_qnty;
						}
					}
					//pre_list($prod_sets_position);
					foreach($prod_sets_alignment as $index=>$align)
					{
					//pre_list($prod_sets_position[$index]);
						//pre_list($prd_set_qnty[$index]);
						if($align=="vertical")
						{
							//pre_list(implode(',',$prod_sets_image[$index]));
							$html.="<tr>";
						$html.="<td>";
						asort($prod_sets_position[$index]);
							foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
								$prd_set_name[$index][]=str_replace('|~~|', '', $prod_sets_name[$index][$index22]).' ('.$prod_sets_size[$index][$index22]* 0.000001.' sqm) ';
								
							$prd_clamps_total[$index][]=$prod_sets_clamps_req[$index][$index22]*$prd_set_qnty[$index];
								// $sum_prd_set_size=$sum_prd_set_size+$prod_sets_size[$index][$index22]* 0.000001;
							$prd_set_sizes[$index][]=array_sum($prod_sets_size[$index]);

								if(!empty($prod_sets_image[$index][$index22]))
							$html.="<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
							else
							$html.="";
							}
							$html.="<p>Alignment: Verical</p></td>";

							$html.='<td>'.implode('+<br/>',$prd_set_name[$index]).'</td>';////item description goes here
							
							if(!empty($prd_qnty_set_for_installation[$index]))
							{
								$html.="<td>".$prd_qnty_set_for_installation[$index]."</td>";
							}
							else
							{
								$html.="<td>0</td>";
							}
							
							$html.="<td>".$prd_set_pipe_hgt[$index]."</td>";
							$html.="</tr>";
						}
						else
						{
							$html.="<tr>";
							$html.="<td>";
							asort($prod_sets_position[$index]);
							foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
								$prd_set_name[$index][]=str_replace('|~~|', '', $prod_sets_name[$index][$index22]).' ('.$prod_sets_size[$index][$index22]* 0.000001.' sqm) ';
								
							$prd_clamps_total[$index][]=$prod_sets_clamps_req[$index][$index22]*$prd_set_qnty[$index];
								// $sum_prd_set_size=$sum_prd_set_size+$prod_sets_size[$index][$index22]* 0.000001;
							$prd_set_sizes[$index][]=array_sum($prod_sets_size[$index]);

						//	pre_list([$ptt]);
									if(!empty($prod_sets_image[$index][$index22]))
							$html.="<img src='".$prod_sets_image[$index][$index22]."' width='80' height='100'>";
							else
							$html.="";
							}
							$html.="<p>Alignment: Horizontal</p></td>";

								$html.='<td>'.implode('+<br/>',$prd_set_name[$index]).'</td>';////item description goes here
						
							if(!empty($prd_qnty_set_for_installation[$index]))
							{
								$html.="<td>".$prd_qnty_set_for_installation[$index]."</td>";
							}
							else
							{
								$html.="<td>0</td>";
							}
							$html.="<td>".$prd_set_pipe_hgt[$index]."</td>";
							$html.="</tr>";
						}
					}
$single_prd_qtys=explode(',',$survey_details[0]->st_single_prd_qtys);
$single_pipe_hgt=explode(',',$survey_details[0]->st_single_pipe_hgt);
$single_pipe_qty=explode(',',$survey_details[0]->st_single_pipe_qty);

$single_prd_installed_qty=explode(',',$survey_details[0]->st_qty_installed);
$single_prd_remianing_qty=explode(',',$survey_details[0]->st_qty_remaining_installation);
				if(!empty($survey_details[0]->st_single_prds))
				{
					foreach($prd_ids2 as $ind=>$pd22)
					{
						//pre_list($pd22);
						if(empty($pd22[0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$pd22[0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$pd22[0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$pd22[0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$pd22[0]->p_prd_img;
								 }
						$html.="<tr>";
							$html.="<td>";
							if(!empty($img_path))
							$html.="<img src='".$img_path."' width='100' height='100'>";
						else
							$html.="";
							$html.="</td>";
							$html.="<td>".$pd22[0]->pname."(".$pd22[0]->p_area." sqm)</td>";
							
							if(!empty($prd_single_qnty_set_for_installation[$ind]))
							{
								$html.="<td>".$prd_single_qnty_set_for_installation[$ind]."</td>";
							}
						else
						{
							$html.="<td>0</td>";
						}	
							$html.="<td>".$single_pipe_hgt[$ind]."</td>";
							$html.="</tr>";
					}
				}
		$html.='</tbody></table>';
			$html.='</body>
					</html>';
				//echo $html;
 $pdfFilePath = $survey_details[0]->st_survey_no.'_installation_for_'.$installation_details[0]->insd_date.'.pdf';
	  
		 $this->load->library('m2_pdf');
		 $this->m2_pdf->pdf->SetHeader('<img src="'.base_url("berry_header.png").'">');
		  $this->m2_pdf->pdf->SetFooter('<img src="'.base_url("berry_footer.png").'">');
		  $this->m2_pdf->pdf->WriteHTML($stylesheet,1);
		  $this->m2_pdf->pdf->AddPage('', // L - landscape, P - portrait 
        '', '', '', '',
        5, // margin_left
        5, // margin right
       35, // margin top
       20, // margin bottom
        0, // margin header
        0); // margin footer              
	    $this->m2_pdf->pdf->WriteHTML($html,2);
	     
	     //save in folder
		$this->m2_pdf->pdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");
		ob_clean(); 
  		$this->m2_pdf->pdf->Output($pdfFilePath,'D');
  		
$this->session->set_flashdata('success', 'Installation PDF generated successfully');
  	redirect('list-installations');
		}
	}
}

function setting()
    {
     $this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';

         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;
         return $config;
        
    }

function send_installation_mail_customer($ins_id)
{
	$this->email->initialize($this->setting());
	    $this->email->from('noreply@birigroup.com','Biri Group');
   
    $installation_details=$this->Admin_model->get_data('installation_dept',array('ins_id'=>$ins_id));
     $survey_details=$this->Admin_model->get_data('survey_table',array('st_id'=>$installation_details[0]->ins_survey_id));
     $prd_set_details=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$survey_details[0]->st_id));
	
	foreach($prd_set_details as $index=>$ppp)
			{
				$prds_id_sets=explode(',',$ppp->psd_prd_id);
				$prod_position=explode(',',$ppp->psd_arrange_position);
				foreach($prds_id_sets as $index2=>$q)
				{
					$prd_ids[$index][$prod_position[$index2]]=$this->tm->get_data('products',array('pid'=>$q));
				}
			}
			$single_prd_sets=explode(',',$survey_details[0]->st_single_prds);
				foreach($single_prd_sets as $q)
				{
					$prd_ids2[]=$this->tm->get_data('products',array('pid'=>$q));
				}

        $this->email->to($survey_details[0]->st_new_cust_email);
		//$this->email->to('support@birigroup.com');
       $this->email->cc(array('bahjat@birigroup.com','projects@birigroup.com'));

        $this->email->subject('Survey No. #'.$survey_details[0]->st_survey_no ." Completed Successfully : Biri Group");
        $html="Dear ".$survey_details[0]->st_new_cust_name.",<br/>";
        $html.="Good day to you.<br/>";
       	$html.='Survey numbered '.$survey_details[0]->st_survey_no.' has completed successfully. Below are the details :<br/>';
 
 	$html='<!doctype html>
<head>        
</head><body> ';
				$html.='
				<div class="content">
				<table border="0" width="100%">
				<tr>
					<td align="left" rowspan="3"><h1 style="text-align:left">Survey Report</h1></td>
					
					<td style="text-align:right;" align="right">
						<div style="text-align:right;">
							<p align="right" style="text-align:justify;">Create by: '.$survey_details[0]->st_user_created.'</p>
						<p align="right" style="text-align:justify;">Survey No. #: '.$survey_details[0]->st_survey_no.'</p>
							<p align="right" style="text-align:justify;">Date: '.date('Y-m-d').'</p>
						</div>
					</td>
				</tr>
				</table>
				</div>';
				$html.='<table align="center" class="cusotmer_info"  width="80%" border="1">';
			$html.='<tr>
					<td>Customer: '.$survey_details[0]->st_new_cust_name.'</td>
					<td>Company Name: '.$survey_details[0]->st_new_cust_comp.'</td>
				</tr>
				<tr>
					<td>Start Cordinates: '.$survey_details[0]->st_start_cordinate.'</td>
					<td>End Cordinates: '.$survey_details[0]->st_end_cordinate.'</td>
				</tr>
				<tr>
					<td>Project Engineer: '.$survey_details[0]->st_user_created.'</td>
					<td>Installation Start Date : '.$installation_details[0]->ins_schedule_date.'<br/>Installation End Date : '.$installation_details[0]->ins_date_set_installation.'</td>
					
				</tr>
				</table>
				<table align="center" class="prd_info"  width="80%" border="1">
					<tr class="prd_head" >
					<th>Items</th>
					<th>Items Description</th>';
					$html.='<th>Quantites(pcs)</th>
					</tr>
					<tbody>';
					//pre_list($prd_ids);
					foreach($prd_ids as $index_p=>$p1)
					{
						$alignment=$prd_set_details[$index_p]->psd_prd_alignment;
						$prod_position=explode(',',$prd_set_details[$index_p]->psd_arrange_position);
						foreach($prod_position as $pd2)
						{
							if(empty($p1[$pd2][0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
								 }

								 $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
								 $prod_sets_name[$index_p][]=$p1[$pd2][0]->pname;
								 $prod_sets_size[$index_p][]=$p1[$pd2][0]->p_area;

								 $prod_sets_image[$index_p][]=$img_path;
								 $prod_sets_alignment[$index_p]=$alignment;
								 $prod_sets_position[$index_p]=$prod_position;
							 	$prd_set_qnty[$index_p]=$prd_set_details[$index_p]->psd_prd_qty;
							}
					}
					foreach($prod_sets_alignment as $index=>$align)
					{
						if($align=="vertical")
						{
							$html.="<tr>";
						$html.="<td>";
						asort($prod_sets_position[$index]);	$sum_prd_set_size=0;
						
							foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
							$prd_set_name[$index][]=str_replace('|~~|', '', $prod_sets_name[$index][$index22]).' ('.$prod_sets_size[$index][$index22]* 0.000001.' sqm) ';
							
								if(!empty($prod_sets_image[$index][$index22]))
							$html.="<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
							else
							$html.="";
							}
	//pre_list($prd_clamps_total);
							$html.="Alignment: Vertical </td>";
							$html.='<td>'.implode('+<br/>',$prd_set_name[$index]).'</td>';////item description goes here
							$html.="<td>".$prd_set_qnty[$index]."</td>";
							$html.="</tr>";
						}
						else
						{
							$html.="<tr>";
							$html.="<td>";
							asort($prod_sets_position[$index]);
							foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
								$prd_set_name[$index][]=str_replace('|~~|', '', $prod_sets_name[$index][$index22]).' ('.$prod_sets_size[$index][$index22]* 0.000001.' sqm) ';
							if(!empty($prod_sets_image[$index][$index22]))
							$html.="<img src='".$prod_sets_image[$index][$index22]."' width='80' height='100'>";
							else
							$html.="";
							}
							$html.="Alignment : Horizontal </td>";
							$html.='<td>'.implode('+<br/>',$prd_set_name[$index]).'</td>';////item description goes here
							$html.="<td>".$prd_set_details[$index]->psd_prd_qty."</td>";
							$html.="</tr>";
						}
					}
$single_prd_qtys=explode(',',$survey_details[0]->st_single_prd_qtys);
$single_pipe_hgt=explode(',',$survey_details[0]->st_single_pipe_hgt);
$single_pipe_qty=explode(',',$survey_details[0]->st_single_pipe_qty);

$single_prd_installed_qty=explode(',',$survey_details[0]->st_qty_installed);
$single_prd_remianing_qty=explode(',',$survey_details[0]->st_qty_remaining_installation);
if(!empty($survey_details[0]->st_single_prds))
{
	$sum_sign_size_single=0;
					foreach($prd_ids2 as $ind=>$pd22)
					{
						$sign_size=$pd22[0]->p_area*0.000001;
	//pre_list($pd22);
						if(empty($pd22[0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$pd22[0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$pd22[0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$pd22[0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$pd22[0]->p_prd_img;
								 }
						$html.="<tr>";
							$html.="<td>";
							if(!empty($img_path))
							$html.="<img src='".$img_path."' width='100' height='100'>";
						else
							$html.="";
							$html.="</td>";
							$html.='<td>'.$pd22[0]->pname.'('.number_format((float)$sign_size, 5, '.', '').' sqm)</td>';////item description goes here
							$html.="<td>".$single_prd_qtys[$ind]."</td>";
							$html.="</tr>";
					}
				}
				$html.='<tr>
				<td>
				</tr>';
		$html.='</tbody></table>';
			$html.='</body>
					</html>';
    	$html.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
        $this->email->message($html);
     if(!empty($survey_details[0]->st_new_cust_email))
      {   
         if($this->email->send())
         {
			$this->session->set_flashdata('success', 'Mail send successfully.');
         }
          else
         {
         	$this->session->set_flashdata('errors', 'Failed to send reply. Please try again later.');
         } 
         	redirect("list-installations", "refresh"); 
       }
       else
       {
       	$this->session->set_flashdata('errors', 'Failed to send reply. Please try again later.');
       	redirect("list-installations", "refresh"); 
       }
}


function generate_daily_report_pdf($installation_details_id=null)
{
	if(!empty($installation_details_id))
	{
		$installation_details=$this->Admin_model->get_data('installation_details',array('insd_id'=>$installation_details_id));

		$labour_assigned= explode(',',$installation_details[0]->insd_labours);
foreach($labour_assigned as $la)
{
	$labour_info[]=$this->Admin_model->get_data( 'employee_details',array('ed_id'=>$la,'ed_pos !='=>'FOREMAN'));			
}

$final_labour_assigned= explode('|#|',$installation_details[0]->labour_final_list);
foreach($final_labour_assigned as $fl)
{
	$final_labour_info[]=$this->Admin_model->get_data( 'employee_details',array('ed_id'=>$fl));			
}

	$tools_assigned= explode(',',$installation_details[0]->insd_tools);
foreach($tools_assigned as $ta)
{
	$tool_info[]=$this->Admin_model->get_data('assets_tools',array('tool_id'=>$ta));
}


$veh_assigned= explode(',',$installation_details[0]->insd_vehicle);
foreach($veh_assigned as $vh)
{
	$veh_info[]=$this->Admin_model->get_data('assets_vehicle',array('veh_id'=>$vh));
}
		if(!empty($installation_details[0]->insd_prd_set_ids))
			{
				$prd_set_qntys_installed=$installation_details[0]->insd_prd_set_qty_installed;
			}
			
			if(!empty($installation_details[0]->insd_prd_single_ids))
			{
				$prd_single_qtys_installed=$installation_details[0]->insd_prd_single_qty_installed;
			}

			$survey_details=$this->Admin_model->get_data('survey_table',array('st_id'=>$installation_details[0]->insd_survey_id));

			$prd_set_qty_set_for_installation=explode(',',$installation_details[0]->insd_prd_set_qty_set_for_installation);
			$prd_set_ids_in_installation=explode(',',$installation_details[0]->insd_prd_set_ids);
			$prd_set_ids_installed_today=explode(',',$installation_details[0]->insd_prd_set_qty_installed);

			if(array_filter($prd_set_qty_set_for_installation)!=false)
			{
				foreach($prd_set_qty_set_for_installation as $i1=>$p1)
				{
					if(!empty($p1))
					{
						$final_non_empty_prd_set_ids[]=$prd_set_ids_in_installation[$i1];
						$final_non_empty_prd_set_qnty[]=$p1;
						$final_non_empty_prd_set_qnty_installed[]=$prd_set_ids_installed_today[$i1];
					}
				}
				////////////////////get prd set data//////////////////
			
	foreach($final_non_empty_prd_set_ids as $fps1)
	{
$prd_set_details[]=$this->Admin_model->get_data('product_set_data',array('psd_id'=>$fps1));
	}
			////////////////////end prd set data//////////
			}

			$prd_single_qty_set_for_installation=explode(',',$installation_details[0]->insd_prd_single_qty_set_for_installation);

			$prd_single_ids_in_installation=explode(',',$installation_details[0]->insd_prd_single_ids);
			$prd_single_ids_installed_today=explode(',',$installation_details[0]->insd_prd_single_qty_installed);
			if(array_filter($prd_single_qty_set_for_installation)!=false)
			{
				foreach($prd_single_qty_set_for_installation as $i2=>$p2)
				{
					if(!empty($p2))
					{
						$final_non_empty_prd_single_ids[]=$prd_single_ids_in_installation[$i2];
						$final_non_empty_prd_single_qnty[]=$p2;
						$final_non_empty_prd_single_qnty_installed[]=$prd_single_ids_installed_today[$i2];
					}
				}
				////////////////////get prd single data//////////////////
foreach($final_non_empty_prd_single_ids as $fps2)
	{
$prd_single_details[]=$this->tm->get_data('products',array('pid'=>$fps2));
	}
			////////////////////end prd single data//////////
			}
$stylesheet = file_get_contents('style_mpdf.css');
		
	$html='<!doctype html>
<head>        </head>
    <body> ';
				$html.='
				<div class="content">
				<table border="0" width="100%">
				<tr >
					<td align="left" rowspan="3"><h1 style="text-align:left">Daily Installation Report</h1></td>
					
					<td style="text-align:right;" align="right">
						<div style="text-align:right;">
							<p align="right" style="text-align:justify;">Create by: '.$survey_details[0]->st_user_created.'</p>
						
							
							<p align="right" style="text-align:justify;">Survey No. #: '.$survey_details[0]->st_survey_no.'</p>
							</div>
					</td>
				</tr>
				</table>
				</div>';

$html.='<table width="100%" border="1">
<tbody>
<tr><td>Date</td><td> '.$installation_details[0]->insd_final_date.'</td></tr>
<tr><td> Actual Installation Start Date </td><td>'.$installation_details[0]->actual_daily_installation_start_date.'</td></tr>
<tr><td>Actual Installation End Date</td><td> '.$installation_details[0]->actual_daily_installation_end_date.'</td></tr>
<tr><td> Total Working Hours</td><td> '.$installation_details[0]->actual_daily_installation_hours.'</td></tr>
<tr><td> Any additional notes </td><td>'.$installation_details[0]->additional_note_of_this_installation.'</td></tr>
</tbody>
</table>';		

$html.='<h2 align="center">Labour Analysis</h2>
<table width="100%" border="1">
<tr>
<th>Labour </th>
<th>Attendance</th>
<th>Performance</th>
<th>Pipes installed</th>
</tr>
<tbody>';
$labour_work_attendance=explode('|#|',$installation_details[0]->labour_work_attendance);
$labour_reason_for_no_attendance=explode('|#|',$installation_details[0]->labour_reason_for_no_attendance);
$labour_work_quality=explode('|#|',$installation_details[0]->labour_work_quality);
$labour_pipe_installed=
explode('|#|',$installation_details[0]->labour_pipe_installed);
 //pre_list($labour_pipe_installed);
$labour_data_filtered=array_values(array_filter($labour_info));
 //pre_list($labour_data_filtered);
foreach($labour_data_filtered as $lab_index=>$lab)
{
if(!empty($lab))
{
 /// pre_list($lab_index);
$html.='<tr>
<td>';
if(!empty($lab[0]->ed_name))
$html.=$lab[0]->ed_name;
$html.='</td>
<td>';
if(!empty($labour_work_attendance[$lab_index]))
{
$html.=$labour_work_attendance[$lab_index];
if($labour_work_attendance[$lab_index]=="No")
{
$html.='<p>Reason for absence: ';
if(!empty($labour_reason_for_no_attendance[$lab_index]))
$html.=$labour_reason_for_no_attendance[$lab_index].'</p>';
$html.='<p>Replaced by: ';
if(!empty($final_labour_info[$lab_index][0]->ed_name))
$html.=$final_labour_info[$lab_index][0]->ed_name.'</p>';
}
}
$html.='</td>
<td><p> Work Performance of '.$final_labour_info[$lab_index][0]->ed_name.' :</p> <br/>'.$labour_work_quality[$lab_index].'</td>

<td><p> Pipe Installed by '.$final_labour_info[$lab_index][0]->ed_name.' :</p> <br/>'.$labour_pipe_installed[$lab_index].'</td>
</tr>';
}
}
$html.='</tbody>
</table>';		

$html.='<h2 align="center">Tools Analysis</h2>
<table width="100%" border="1">
<tr>
<th>Tools Name </th>
<th>Tool Availability</th>
</tr>
<tbody>';
$tools_usage=explode('|#|',$installation_details[0]->tools_usage);
$tools_reason_for_no_usage=explode('|#|',$installation_details[0]->tools_reason_for_no_usage);
foreach($tool_info as $index=>$ta)
{
$html.='<tr>
<td>'.$ta[0]->tool_name.'</td>
<td>'.$tools_usage[$index];
if($tools_usage[$index]=="No")
{
	$html.='<p>Reason for Not Used: '. $tools_reason_for_no_usage[$index].'</p>';
}
$html.='</td>
</tr>';
}
$html.='</tbody>
</table>';	

$html.='<h2 align="center">Vehicle Analysis</h2>
<table width="100%" border="1">
<tr>
<th>Vehicle Number </th>
<th>Vehicle Availability  </th>
</tr>
<tbody>';
$vehicle_uage=explode('|#|',$installation_details[0]->vehicle_uage);
$vehicle_reason_for_no_usage=explode('|#|',$installation_details[0]->vehicle_reason_for_no_usage);
foreach($veh_info as $index=>$vh)
{
$html.='<tr>
<td>'.$vh[0]->veh_plate_no.'</td>
<td>'.$vehicle_uage[$index];
if($vehicle_uage[$index]=="No")
{
	$html.='<p>Reason for Not Used: '. $vehicle_reason_for_no_usage[$index].'</p>';
}
$html.='</td>
</tr>';
}
$html.='</tbody>
</table>';		

$html.='<table align="center" class="prd_info"  width="80%" border="1">
					<tr class="prd_head" >
					<th >Items</th>
					<th >Item Description</th>';					
					$html.='
					<th>Quantites Set (for this Installation)</th>
					<th>Quantites Installed </th>';

					$html.='</tr>
					<tbody>';
					//pre_list($prd_set_details);
			foreach($prd_set_details as $index1=>$psr)
			{
				if(!empty($final_non_empty_prd_set_qnty_installed[$index1]))
				{
				$prd_ids_explode=explode(',', $psr[0]->psd_prd_id);
				$arrange_pos=explode(',', $psr[0]->psd_arrange_position);
				foreach($prd_ids_explode as $index11=>$q)
						{
							$prd_ids_1[$index1][$arrange_pos[$index11]]=$this->tm->get_data('products',array('pid'=>$q));
						}
				}
			}

		foreach($prd_ids_1 as $index_p=>$p1)
          {
            $alignment=$prd_set_details[$index_p][0]->psd_prd_alignment;
            $prod_position=explode(',',$prd_set_details[$index_p][0]->psd_arrange_position);

            // pre_list($prod_position);
            // pre_list($p1);
            foreach($prod_position as $pd2)
            {
            //pre_list($pd2);
            //pre_list($p1[$pd2][0]->pname);
              if(empty($p1[$pd2][0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
                 }

                 $prd_height[$index_p][]=$p1[$pd2][0]->prd_height;
                 $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
                 $prd_set_name[$index_p][]=$p1[$pd2][0]->pname;
                 $prod_sets_image[$index_p][]=$img_path;
                 $prod_sets_alignment[$index_p]=$alignment;
                 $prod_sets_position[$index_p]=$prod_position;
                 $prd_set_id[$index_p]=$prd_set_details[$index_p][0]->psd_id;

                $prod_sets_qty_orginal[$index_p]=$prd_set_details[$index_p][0]->psd_prd_qty;
                $qty_installed[$index_p]=$prd_set_details[$index_p][0]->psd_qty_installed;
                $qty_remaining[$index_p]=$prd_set_details[$index_p][0]->psd_qty_remaining_installation;
            }
          }
						//pre_list($prd_set_qnty[$index]);
		foreach($prod_sets_alignment as $index=>$align)
          {
			
                  // pre_list($prd_set_qnty_insatlled[$index]);
     if($align=="vertical")
            {
							//pre_list(implode(',',$prod_sets_image[$index]));
							$html.="<tr>";
						$html.="<td>";
						asort($prod_position);
							foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
								
								if(!empty($prod_sets_image[$index][$index22]))
							$html.="<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
							else
							$html.="";
							}
							$html.="<p>Alignment: Verical</p></td>";

							$html.='<td>'.implode('+<br/>',$prd_set_name[$index]).'</td>';////item description goes here
							if(!empty($final_non_empty_prd_set_qnty[$index]))
								$html.="<td>".$final_non_empty_prd_set_qnty[$index]."</td>";
							
							$html.="<td>".$final_non_empty_prd_set_qnty_installed[$index]."</td>";
							$html.="</tr>";
						}
						else
						{
							$html.="<tr>";
							$html.="<td>";
							asort($prod_sets_position[$index]);
							foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
								
						//	pre_list([$ptt]);
									if(!empty($prod_sets_image[$index][$index22]))
							$html.="<img src='".$prod_sets_image[$index][$index22]."' width='80' height='100'>";
							else
							$html.="";
							}
							$html.="<p>Alignment: Horizontal</p></td>";

								$html.='<td>'.implode('+<br/>',$prd_set_name[$index]).'</td>';////item description goes here
						if(!empty($final_non_empty_prd_set_qnty[$index]))
							$html.="<td>".$final_non_empty_prd_set_qnty[$index]."</td>";
							
							$html.="<td>".$final_non_empty_prd_set_qnty_installed[$index]."</td>";
							$html.="</tr>";
						}
					}
$single_prd_qtys=explode(',',$survey_details[0]->st_single_prd_qtys);

$single_prd_installed_qty=explode(',',$survey_details[0]->st_qty_installed);
$single_prd_remianing_qty=explode(',',$survey_details[0]->st_qty_remaining_installation);
				if(!empty($survey_details[0]->st_single_prds))
				{
					foreach($prd_single_details as $ind=>$pd22)
					{
						//pre_list($pd22);
						if(empty($pd22[0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$pd22[0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$pd22[0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$pd22[0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$pd22[0]->p_prd_img;
								 }
						$html.="<tr>";
							$html.="<td>";
							if(!empty($img_path))
							$html.="<img src='".$img_path."' width='100' height='100'>";
						else
							$html.="";
							$html.="</td>";
							$html.="<td>".$pd22[0]->pname."</td>";
							if(!empty($final_non_empty_prd_single_qnty[$ind]))
							$html.="<td>".$final_non_empty_prd_single_qnty[$ind]."</td>";
						
							$html.="<td>".$final_non_empty_prd_single_qnty_installed[$ind]."</td>";
							$html.="</tr>";
					}
				}
		$html.='</tbody></table>';
 

$html.='</body></html>';
//print_r($html);
 $pdfFilePath = $survey_details[0]->st_survey_no.'_daily_report.pdf';
	  
		 $this->load->library('m2_pdf');
		$this->m2_pdf->pdf->WriteHTML($html,2);
	     
	     //save in folder
		$this->m2_pdf->pdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");
		ob_clean(); 
  		$this->m2_pdf->pdf->Output($pdfFilePath,'D');
  		
$this->session->set_flashdata('success', 'Daily Report Installation PDF generated successfully');
  	redirect('list_scheduled/'.$installation_details[0]->insd_installation_id);

	}
}























}