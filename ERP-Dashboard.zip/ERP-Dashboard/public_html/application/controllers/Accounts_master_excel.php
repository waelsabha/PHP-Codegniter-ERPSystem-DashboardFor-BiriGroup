<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts_master_excel extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','prd'));
		$this->load->model('Sales_book_model');
	}

function account_masters_excel() 
{
	if(logged_in())
	{
        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='account_masters_excel')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

	  $this ->load-> view('admin/account_masters/account_masters_excel');

  }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  
	}
}

function account_masters_data()
{
	$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
$current_month= $dt->format('m');
$current_year= $dt->format('Y');
$previous_year=$dt->format('Y')-1;
$last_previous_year=$dt->format('Y')-2;
$five_yrs_back=$current_year-5;

$strt_range=$this->input->post('start_date_rng');
$end_range=$this->input->post('end_date_rng');

if(!empty($strt_range) && !empty($end_range))
{
$cond_both_dates=array(
	'acc_md_date >='=>date("Y-m-d", strtotime($strt_range)),
	'acc_md_date <='=>date("Y-m-d", strtotime($end_range)),
	);
	
	//$current_year='';
}
else if(!empty($end_range))
{
$cond_both_dates=array(
	'acc_md_date <='=>date("Y-m-d", strtotime($end_range)),
	);
	//$current_year='';
}
else if(!empty($strt_range))
{
$cond_both_dates=array(
	'acc_md_date >='=>date("Y-m-d", strtotime($strt_range)),
	);
	//$current_year='';
}
else{
	$cond_both_dates='';
}



	$account_master_cat=$this->Admin_model->get_data('account_master_category',array('acc_m_name !='=>"Salaries To Transfer"));

   print_r('What I See That Not Completed Yet');
   exit();
foreach($account_master_cat as $amc)
{
if(!empty($strt_range) || !empty($end_range))
{
$accounts_data['data'][]=$this->Admin_model->accounts_master_data($amc->acc_m_id,'',$cond_both_dates);
}


	$accounts_data['curnt_yr'][]=$this->Admin_model->accounts_master_data($amc->acc_m_id,$current_year,'');
	print_r($accounts_data);exit();
	$accounts_data['prev_yr'][]=$this->Admin_model->accounts_master_data($amc->acc_m_id,$previous_year,'');
	
	$accounts_data['last_prev_yr'][]=$this->Admin_model->accounts_master_data($amc->acc_m_id,$last_previous_year,'');
	
}
 
foreach($accounts_data as $index=>$t)
{
	if($index=="curnt_yr")
	{
		foreach($t as $inde2=>$x)
		{
			foreach($x as $a)
			{
			if(empty($a->acc_md_dr_amnt))
	            				{
	            					$number_sis[$a->acc_m_name]['amount'][]='0';
	            				}
            				else
            					{

	            				$number_sis[$a->acc_m_name][$a->year][]=str_replace(',', '', $a->acc_md_dr_amnt);
	            				//$number_sis[$a->acc_m_name]['year'][]=$a->year;
								}

			}			
		}
	}
	elseif($index=="prev_yr")
	{
		foreach($t as $y)
		{
			foreach($y as $b)
			{
			if(empty($b->acc_md_dr_amnt))
	            				{
	            					$number_sis[$b->acc_m_name]['amount'][]='0';
	            				}
            				else
            					{

	            				$number_sis[$b->acc_m_name][$b->year][]=str_replace(',', '', $b->acc_md_dr_amnt);
	            				//$number_sis[$b->acc_m_name]['acc_name'][]=$b->acc_m_name;
	            				//$number_sis[$b->acc_m_name]['year'][]=$b->year;
								}
			}
		}
	}
	elseif($index=="last_prev_yr")
	{
		foreach($t as $z)
		{
			foreach($z as $c)
			{
			if(empty($c->acc_md_dr_amnt))
	            				{
	            					$number_sis[$c->acc_m_name]['amount'][]='0';
	            				}
            				else
            					{

	            				$number_sis[$c->acc_m_name][$c->year][]=str_replace(',', '', $c->acc_md_dr_amnt);
	            				//$number_sis[$c->acc_m_name]['acc_name'][]=$c->acc_m_name;
	            				//$number_sis[$c->acc_m_name]['year'][]=$c->year;
								}
			}
		}
	}
	else
	{
	
		if(!empty($cond_both_dates))
		{
		foreach($t as $k)
		{
			foreach($k as $c)
			{
			if(empty($c->acc_md_dr_amnt))
	            				{
	            					$number_sis2[$c->acc_m_name]['amount'][]='0';
	            				}
            				else
            					{

	            				$number_sis2[$c->acc_m_name][$c->year][]=str_replace(',', '', $c->acc_md_dr_amnt);
	            				//$number_sis[$c->acc_m_name]['acc_name'][]=$c->acc_m_name;
	            				//$number_sis[$c->acc_m_name]['year'][]=$c->year;
								}
			}
		}
	  }
	  else
	  {
	  	$number_sis2='';
	  }
	}
}

$data['total_sum']=$number_sis;
$data['acc_names']=$account_master_cat;




if(!empty($number_sis2))
{
	foreach($number_sis2 as $index=>$t)
	{
		foreach($t as $index2=>$a)
		{
	$second_time[$index][]=array_sum($a);
		}	
	}
}
else
{
	foreach($number_sis as $index=>$t)
	{
		foreach($t as $index2=>$a)
		{
			if($index2==$current_year)
	$second_time[$index][]=array_sum($a);
		}	
	}
}


foreach($second_time as $key=>$val)
{
	if (strpos($key, 'K-') !== false)
	{
		$data['ksa_name'][]=$key;
		$data['ksa'][]=$val[0];
	}
	else
	{
		$data['uae_name'][]=$key;
		$data['uae'][]=$val[0];
	}
}

if(!empty($strt_range) || !empty($end_range))
{
$data['strt_date']=$strt_range;
$data['end_date']=$end_range;
}

//$data['current_year']=$current_year;

// echo "<pre>";
// print_r($number_sis2);
// echo "</pre>";
if(logged_in())
	{
$this ->load-> view('admin/account_masters/account_master_data',$data);
}
}

function submit_account_masters_excel()
{
	$flag = 0;
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/excel/account_masters/';

		$config['upload_path'] = './'.$path;
		$config['allowed_types'] = '*';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);
//print_r($this->upload->data());
//print_r($_FILES['userfile']);
		if (!$this->upload->do_upload('userfile')) 
		{
			$error = array('error' => $this->upload-> display_errors());
			//print_r($this->upload-> display_errors());
			$this->session ->set_flashdata('errors', $error['error']);
			//redirect("account_masters_excel", "refresh");
		} 
		else 
		{
		$data = array('userfile' => $this->upload->data());
		}
	
		if (!empty($data['userfile']['file_name'])) 
		{
		$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path.$import_xls_file;
		try 
		{
		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
		die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME).'": '.$e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{			
			$narration = trim($allDataInSheet[$i]['C']);
			if(empty($narration))
			{
				//$data_account_master_category[]=$allDataInSheet[$i];
				if(!empty($allDataInSheet[$i]['A']))
				{
					$data_in_table=$this->Admin_model->get_data('account_master_category',array('acc_m_name'=>$allDataInSheet[$i]['A']));
					if(!empty($data_in_table[0]->acc_m_name))
					{
					$insert_id_cat=$data_in_table[0]->acc_m_id;
					}
					else
					{
					$insert_id_cat=$this->Admin_model->insert_data("account_master_category", array('acc_m_name'=>$allDataInSheet[$i]['A']));
					}
				}
				//
			}
			else
			{
				$voc_date = trim($allDataInSheet[$i]['A']);
				//print_r($allDataInSheet[$i]['A']);
				$new_voc_date=explode('-', $voc_date);///in the format d-m-y , i need is y-m-d.
			

			if(!empty($new_voc_date[1]))
			$month_voc=$new_voc_date[1];
			else
				$month_voc='';

			if(!empty($new_voc_date[0]))
			$date_voc=$new_voc_date[0];	

			if(!empty($new_voc_date[2]))
			$year_voc=$new_voc_date[2];
		else
			$year_voc='';
			
			if(!empty($year_voc)&&!empty($month_voc)&&(!empty($date_voc)))
		$voc_date_2=$year_voc.'-'.$month_voc.'-'.$date_voc;
		else
		$voc_date_2='';
				//$voc_date_2=$date_in_excel[2].'-'.$date_in_excel[1].'-'.$date_in_excel[0];
// echo "<pre>";
// 			 	print_r($split_time[0]);
// 			 	echo "</pre>";
		
				$data_insert_array[]=array(
					'acc_md_date'=>$voc_date_2,
					'acc_md_voc_num'=>$allDataInSheet[$i]['B'],
					'acc_md_acc_name'=>$allDataInSheet[$i]['C'],
					'acc_md_narration'=>$allDataInSheet[$i]['E'],
					'acc_md_dr_amnt'=>$allDataInSheet[$i]['F'],
					'acc_md_bal'=>$allDataInSheet[$i]['H'],
					'acc_md_name'=>$allDataInSheet[$i]['I'],
					'acc_id_cat'=>$insert_id_cat,
					'acc_md_sts'=>'1',
				);

			
			}
			
		}
 
		$this->insert_data_accounts($data_insert_array);
			

		// if($flag==1)
		// {
		
		// 	$this->session->set_flashdata('errors',$error_string);	
		// 	unlink("uploads/excel/sales_vouchers/".$import_xls_file);
		// 	redirect('sales-book','refresh');
		// }
		// else
		// {
		// 	$dwnload_title=$this->input->post('dwnload_title');
		// 	$data23=array(
		// 	'excl_title'=>$dwnload_title,
		// 	'excl_file'=>$inputFileName,
		// 	'excl_status'=>"1",
		// 	'excl_type' =>'result');
		// 	$insert_id=$this->Admin_model->insert_data("excel_file_sales_book", $data23);
		// 	 $this->insert_table($allDataInSheet,$insert_id);
		// }
}

function insert_data_accounts($data_insert_array)
{

//echo "<pre>";
//print_r($data_insert_array);
//echo "</pre>";
	
	foreach($data_insert_array as $t)
	{
	
		if(!empty($t['acc_md_dr_amnt']))
		{
			$data_insert_array2=array(
					'acc_md_date'=>$t['acc_md_date'],
					'acc_md_voc_num'=>$t['acc_md_voc_num'],
					'acc_md_acc_name'=>$t['acc_md_acc_name'],
					'acc_md_narration'=>$t['acc_md_narration'],
					'acc_md_dr_amnt'=>$t['acc_md_dr_amnt'],
					'acc_md_bal'=>$t['acc_md_bal'],
					'acc_md_name'=>$t['acc_md_name'],
					'acc_id_cat'=>$t['acc_id_cat'],
					'acc_md_sts'=>'1',
				);

			$insert_id_data=$this->Admin_model->insert_data("account_master_data", $data_insert_array2);
			

		}
	}
	$this ->session-> set_flashdata('success', 'Imported Successfully');
redirect('account_masters_excel');
}











}