<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Excel_production extends CI_Controller {

	public function __construct() {
		parent::__construct();
		 $this ->load -> helper('session');
		 $this->load->model('Third_db_model','tm');
		
	}

		public function excel_upload() {
		if(logged_in())
		{
            $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='upload-production-excel')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

			$this ->load-> view('admin/production/upload_excel');

 }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


		}
	}

	// upload xlsx|xls file
	// public function index() {
	// $data=null;
	// $this->load->view('admin/pages/import_table', $data);
	// }
	// import excel data

	/*    the Old one before 31-12-2021
	public function submit_production_excel() 
	{
	if(logged_in())
		{
		$flag = 0;
		$er=array();
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/production/excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load -> library('upload', $config);
		$this ->upload -> initialize($config);

		if (!$this ->upload -> do_upload('userfile')) 
		{
			$error = array('error' => $this ->upload -> display_errors());
			$this ->session -> set_flashdata('errors', $error['error']);
			redirect("upload-production-excel", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this ->upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			
			$name_en = trim($allDataInSheet[$i]['A']);
			$name_ar = trim($allDataInSheet[$i]['B']);
			$prd_type = trim($allDataInSheet[$i]['C']);
			// $cat_name = trim($allDataInSheet[$i]['D']);
			// $sub_cat = trim($allDataInSheet[$i]['E']);
			$itm_code = trim($allDataInSheet[$i]['F']);
			$prd_wgt = trim($allDataInSheet[$i]['G']);
			$selling_price = trim($allDataInSheet[$i]['H']);
			$desc = trim($allDataInSheet[$i]['I']);
			
			
			if(empty($name_en))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell A. Product name in english cannot be empty.<br>";
			}
			if(empty($name_ar))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell B.Product name in arabic cannot be empty.<br>";
			}
			if(empty($prd_type))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell C.Product type cannot be empty.<br>";
			}
			if(empty($itm_code) )
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell F.Item Code cannot be empty .<br>";
			}
			if(empty($prd_wgt))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell G.Product Weight  cannot be empty.<br>";
			}
			if(empty($selling_price))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell H.Selling price cannot be empty.<br>";
			}
			if(empty($desc))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell I.Product Description cannot be empty.<br>";
			}		
		}
		if($flag==1)
		{
		
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/production/excel/".$import_xls_file);
			redirect('upload-production-excel','refresh');
		}
		else
		{
			$dwnload_title=$this->input->post('dwnload_title');
			$data23=array(
			'pef_name'=>$dwnload_title,
			'pef_file'=>$inputFileName,
			'pef_status'=>"1",
			);
			$insert_id=$this->tm->insert_data("prd_excel_file", $data23);
			 $this->insert_table($allDataInSheet,$insert_id);
		}
		}
	}

	function insert_table($allDataInSheet,$insert_id) 
	{
	if(logged_in())
		{
		$arrayCount = count($allDataInSheet);
		$flag = 0;
		$status = true;
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			$prd_en = trim($allDataInSheet[$i]['A']);	
			$prd_ar = trim($allDataInSheet[$i]['B']);		
			$type = trim($allDataInSheet[$i]['C']);
			$item_code = trim($allDataInSheet[$i]['F']);
			$prd_wgt = trim($allDataInSheet[$i]['G']);
			$selling_price = trim($allDataInSheet[$i]['H']);
			$desc = trim($allDataInSheet[$i]['I']);
			//$date = trim($allDataInSheet[$i]['I']);

			$cond5=array('pv_sts'=>'1');
	$final_price=$this->tm->get_data('percentage_values',$cond5);
$uae_price1=$selling_price*(int)($final_price[0]->pv_uae1)/100;
$uae_price2=$selling_price*(int)($final_price[0]->pv_uae2)/100;
$ksa_price=$selling_price*(int)($final_price[0]->pv_ksa)/100;

	$ksa_final=(int)($selling_price)+(int)($ksa_price);

	$ksa_price1=$ksa_final*(int)($final_price[0]->pv_ksa1)/100;
	$ksa_price2=$ksa_final*(int)($final_price[0]->pv_ksa2)/100;
	
	$uae_final=((int)($selling_price));
	$uae_final_l1=((int)($selling_price)+(int)($uae_price1) );
	$uae_final_l2=((int)($selling_price)+(int)($uae_price2) );
	$ksa_final=((int)($selling_price)+(int)($ksa_price) );
	$ksa_final_l1=((int)($ksa_final)+(int)($ksa_price1) );
	$ksa_final_l2=((int)($ksa_final)+(int)($ksa_price2) );
			 
	if (!empty($prd_en) && !empty($prd_ar) && !empty($type) && !empty($item_code) && !empty($prd_wgt) 
			&& !empty($selling_price) && !empty($desc) )//checking duplication of keys
			{
			$prd_name=$prd_en.'|~~|'.$prd_ar;	

				$fetchData = array(
					'pname'=>$prd_name,
                   	'ptype'=>$type,
                   	'pcode'=>$item_code,
                   	'p_wgt'=>$prd_wgt,
                   	'p_selling_price'=>$selling_price,
                   	'p_uae_final'=>$uae_final,
                   	'p_uae_l1'=>$uae_final_l1,
                   	'p_uae_l2'=>$uae_final_l2,
                   	'p_ksa'=>$ksa_final,
                   	'p_ksa_l1'=>$ksa_final_l1,
                   	'p_ksa_l2'=>$ksa_final_l2,
                   	'p_desc'=>$desc,
                   	'p_sts'=>'1',
                  	'p_excel_id'=>$insert_id,
				  	'p_user_name'=>$this->session->userdata['user']['username']
					);
// 				echo "<pre>";
// print_r($fetchData);
// 	echo "</pre>";
		if (!($this->tm-> insert_data("products", $fetchData)))
					$status = false;
			}
		}

		if ($status)
			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		redirect("upload-production-excel", "refresh");
		}
	}
    
*/
    function validateDate($date, $format = 'Y-m-d')
{
    $d = DateTime::createFromFormat($format, $date);
    // The Y ( 4 digits year ) returns TRUE for any integer with any number of digits so changing the comparison from == to === fixes the issue.
   if($d && $d->format($format) === $date)
   	return TRUE;
   else 
   	return false;
}


//my code working well 3-2-2022


	public function submit_production_excel_new() 
	{
	if(logged_in())
		{
		$flag = 0;
		$er=array();
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/production/excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load -> library('upload', $config);
		$this ->upload -> initialize($config);

		if (!$this ->upload -> do_upload('userfile')) 
		{
			$error = array('error' => $this ->upload -> display_errors());
			$this ->session -> set_flashdata('errors', $error['error']);
			redirect("upload-production-excel", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this ->upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			
			   $prd_focus_id=trim($allDataInSheet[$i]['A']);	
			$prd_en = trim($allDataInSheet[$i]['B']);	
			$prd_ar = trim($allDataInSheet[$i]['C']);		
			$type = trim($allDataInSheet[$i]['D']);
			$item_code = trim($allDataInSheet[$i]['E']);
			$prd_wgt = trim($allDataInSheet[$i]['F']);
			$selling_price = trim($allDataInSheet[$i]['G']);
			$desc = trim($allDataInSheet[$i]['H']);
			$category = trim($allDataInSheet[$i]['I']);
			$hsecode=trim($allDataInSheet[$i]['J']);
			



            if(empty($prd_focus_id))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell A. Product name in english cannot be empty.<br>";
			}


			
			if(empty($prd_en))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell B. Product name in english cannot be empty.<br>";
			}
			
			if(empty($type))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell D.Product type cannot be empty.<br>";
			}
			if(empty($item_code) )
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell E.Item Code cannot be empty .<br>";
			}
			
			if(empty($selling_price))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell G.Selling price cannot be empty.<br>";
			}
			/*if(empty($desc))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell I.Product Description cannot be empty.<br>";
			}	*/	
		}
		if($flag==1)
		{
		
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/production/excel/".$import_xls_file);
			redirect('upload-production-excel','refresh');
		}
		else
		{
			$dwnload_title=$this->input->post('dwnload_title');
			$data23=array(
			'pef_name'=>$dwnload_title,
			'pef_file'=>$inputFileName,
			'pef_status'=>"1",
			);



			$insert_idexcel=$this->tm->insert_data("prd_excel_file", $data23);

		
           //i found this way to get final pid from products to prevent frequently 3-2-2022
            //SELECT `pid` FROM `products` WHERE `pid`>'0' ORDER BY `pid` DESC LIMIT 1
			$insert_id= $this->tm->get_data('products','pid>0','1','0','pid','DESC','pid');
          //$insert_id= $this->tm->get_data_prdid();
			
			 $this->insert_table_data_new($allDataInSheet,$insert_id);
		}
		}
	}



// my code 3-2-2022 for insert new product 
function insert_table_data_new()
{
	$flag = 0;
		$er=array();
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/production/excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load -> library('upload', $config);
		$this ->upload -> initialize($config);

		if (!$this ->upload -> do_upload('userfile')) 
		{
			$error = array('error' => $this ->upload -> display_errors());
			$this ->session -> set_flashdata('errors', $error['error']);
			echo "file error";
		//	redirect("upload-production-excel", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this ->upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);

		
			$status = true;
		for ($i = 2; $i <= $arrayCount; $i++) 
		{   
		    $prd_focus_id=trim($allDataInSheet[$i]['A']);	
			$prd_en = trim($allDataInSheet[$i]['B']);	
			$prd_ar = trim($allDataInSheet[$i]['C']);		
			$type = trim($allDataInSheet[$i]['D']);
			$item_code = trim($allDataInSheet[$i]['E']);
			$prd_wgt = trim($allDataInSheet[$i]['F']);
			$selling_price = trim($allDataInSheet[$i]['G']);
			$desc = trim($allDataInSheet[$i]['H']);
			$category = trim($allDataInSheet[$i]['I']);
			$hsecode=trim($allDataInSheet[$i]['J']);
             $pstst=(int)(1);
			$cond5=array('pv_sts'=>'1');
			 $prd_focus_idint=(int)($prd_focus_id);
		  $final_price=$this->tm->get_data('percentage_values',$cond5);
	      $uae_price1=(float)($selling_price)*(float)($final_price[0]->pv_uae1)/100;
	      $uae_price2=(float)($selling_price)*(float)($final_price[0]->pv_uae2)/100;

	      $ksa_price=(float)($selling_price)*(float)($final_price[0]->pv_ksa)/100;
	        
		   $ksa_final=(float)($selling_price)+(float)($ksa_price);

			$ksa_price1=$ksa_final*(float)($final_price[0]->pv_ksa1)/100;
			$ksa_price2=$ksa_final*(float)($final_price[0]->pv_ksa2)/100;
			$ksa_price3=$ksa_final*(0.50);
			$uae_final=((float)($selling_price));
			$uae_final_l1=((float)($selling_price)+(float)($uae_price1) );
			$uae_final_l2=((float)($selling_price)+(float)($uae_price2) );
			$ksa_final=((float)($selling_price)+(float)($ksa_price) );
			$ksa_final_l1=((float)($ksa_final)+(float)($ksa_price1) );
			$ksa_final_l2=((float)($ksa_final)+(float)($ksa_price2) );
			$ksa_final_l3=((float)($ksa_final)+(float)($ksa_price3) );
	
		//	$prd_name=$prd_en.'|~~|'.$prd_ar;	

				$fetchData = array(
					'prod_id_focus'=>$prd_focus_idint,
					'pname'=>$prd_en,
				    'pname_ar'=>$prd_ar,
                   	'ptype'=>$type,
                   	'pcode'=>$item_code,
                   	'p_wgt'=>$prd_wgt,
                   	'p_selling_price'=>$selling_price,
                   	'p_uae_final'=>$uae_final,
                   	'p_uae_l1'=>$uae_final_l1,
                   	'p_uae_l2'=>$uae_final_l2,
                   	'p_ksa'=>$ksa_final,
                   	'p_ksa_reg_1'=>$ksa_final_l1,
                   	'p_ksa_comp_2'=>$ksa_final_l2,
                    'p_ksa_retail_3'=>$ksa_final_l3,
                   	'p_desc'=>$desc,
                   	'p_sts'=>$pstst,
                   	'pcat'=>$category,
                  	'pid'=>$insert_id,
                  	'p_hse_id'=>$hsecode,
				  	'p_user_name'=>$this->session->userdata['user']['username']
					);

            if (($this->tm-> insert_data("products", $fetchData)))
		 		{$status = true;}
				else 
				{$status = false;}
				/////write here the code for update to table , update as per master_id from focus////
			//	$this->Admin_model->update_data('');
			
		}


		if ($status)
		//echo "success";
		//else
		//echo"falseeee";

			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		redirect("upload-production-excel", "refresh");


}






//it working but i will used for update price of some products so i need to make interface for it
//my code 2-2-2022 working to update price value
function submit_prds_updatedata_new()
{
	$flag = 0;
		$er=array();
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/production/excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load -> library('upload', $config);
		$this ->upload -> initialize($config);

		if (!$this ->upload -> do_upload('userfile')) 
		{
			$error = array('error' => $this ->upload -> display_errors());
			$this ->session -> set_flashdata('errors', $error['error']);
			echo "file error";
		//	redirect("upload-production-excel", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this ->upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);

		
			$status = true;
		for ($i = 2; $i <= $arrayCount; $i++) 
		{ 
		    $prd_focus_id=trim($allDataInSheet[$i]['A']);	
			$prd_en = trim($allDataInSheet[$i]['B']);	
			$prd_ar = trim($allDataInSheet[$i]['C']);		
			$type = trim($allDataInSheet[$i]['D']);
		    $item_code = trim($allDataInSheet[$i]['E']);
			//$prd_wgt = trim($allDataInSheet[$i]['F']);
			$selling_price = trim($allDataInSheet[$i]['G']);
			//$desc = trim($allDataInSheet[$i]['H']);
			//$category = trim($allDataInSheet[$i]['I']);

			$cond5=array('pv_sts'=>'1');
		  $final_price=$this->tm->get_data('percentage_values',$cond5);
	      $uae_price1=(float)($selling_price)*(float)($final_price[0]->pv_uae1)/100;
	      $uae_price2=(float)($selling_price)*(float)($final_price[0]->pv_uae2)/100;

	      $ksa_price=(float)($selling_price)*(float)($final_price[0]->pv_ksa)/100;
	        
		   $ksa_final=(float)($selling_price)+(float)($ksa_price);

			$ksa_price1=$ksa_final*(float)($final_price[0]->pv_ksa1)/100;
			$ksa_price2=$ksa_final*(float)($final_price[0]->pv_ksa2)/100;
			$ksa_price3=$ksa_final*(0.50);
			$uae_final=((float)($selling_price));
			$uae_final_l1=((float)($selling_price)+(float)($uae_price1) );
			$uae_final_l2=((float)($selling_price)+(float)($uae_price2) );
			$ksa_final=((float)($selling_price)+(float)($ksa_price) );
			$ksa_final_l1=((float)($ksa_final)+(float)($ksa_price1) );
			$ksa_final_l2=((float)($ksa_final)+(float)($ksa_price2) );
			$ksa_final_l3=((float)($ksa_final)+(float)($ksa_price3) );
	
		//	$prd_name=$prd_en.'|~~|'.$prd_ar;	

				$fetchData = array(
					
					'pname'=>$prd_en,
				    'pname_ar'=>$prd_ar,
                   	'ptype'=>$type,
                   	'pcode'=>$item_code,
                   	//'p_wgt'=>$prd_wgt,
                   	'p_selling_price'=>$selling_price,
                   	'p_uae_final'=>$uae_final,
                   	'p_uae_l1'=>$uae_final_l1,
                   	'p_uae_l2'=>$uae_final_l2,
                   	'p_ksa'=>$ksa_final,
                   	'p_ksa_reg_1'=>$ksa_final_l1,
                   	'p_ksa_comp_2'=>$ksa_final_l2,
                    'p_ksa_retail_3'=>$ksa_final_l3,
                   	//'p_desc'=>$desc,
                   //	'pcat'=>$category,
                  //	'p_excel_id'=>$insert_id,
				  	'p_user_name'=>$this->session->userdata['user']['username']
					);

            if (($this->tm->update_data("products", $fetchData,array('prod_id_focus'=>$prd_focus_id))))
		 		{$status = true;}
				else 
				{$status = false;}
				/////write here the code for update to table , update as per master_id from focus////
			//	$this->Admin_model->update_data('');
			
		}


		if ($status)
		//echo "success";
		//else
		//echo"falseeee";

			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		redirect("upload-production-excel", "refresh");


}








//// old one before 2-2-2022
function submit_update_prds_data()
{
	$flag = 0;
		$er=array();
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/production/excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load -> library('upload', $config);
		$this ->upload -> initialize($config);

		if (!$this ->upload -> do_upload('userfile')) 
		{
			$error = array('error' => $this ->upload -> display_errors());
			$this ->session -> set_flashdata('errors', $error['error']);
			echo "file error";
		//	redirect("upload-production-excel", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this ->upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);

		
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			$fetchData = array(
					'pname'=>trim($allDataInSheet[$i]['C']),
                   	'pname_ar'=>trim($allDataInSheet[$i]['D']),
				   );
				$prd_focus_id=trim($allDataInSheet[$i]['A']);
			if (!($this->tm->update_data("products", $fetchData,array('prod_id_focus'=>$prd_focus_id))))
					$status = false;
				
		}

		if ($status)
		echo "success";
		else
		echo"falseeee";

		//	$this ->session-> set_flashdata('success', 'Imported Successfully');
	//	else
		//	$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		//redirect("upload-production-excel", "refresh");

}
   


}
