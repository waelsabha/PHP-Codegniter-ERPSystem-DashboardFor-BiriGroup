<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account_excel extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->model(array('Account_model'));
		$this->load->helper(array('session','gnrl'));	
	}

	function excel_upload($page_name) {
		if(logged_in())
		{
			$data['page_name']=$page_name;
			$this ->load-> view('admin/accounts/acc_excel_upload2',$data);
		}
	}

public function submit_excel_sheet() 
	{
		$page_name=$this->input->post('page_name');
		$flag = 0;
		$er=array();
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/excel/accounts/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load -> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this ->upload -> do_upload('userfile')) 
		{
			$error = array('error' => $this ->upload -> display_errors());
			$this ->session -> set_flashdata('errors', $error['error']);

			if($page_name=="suppliers")
		redirect("add-suppliers","refresh");
			else
		redirect("add-customers","refresh");	
		} 
		else 
		{
			$data = array('userfile' => $this -> upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
		$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			if($page_name=="suppliers")
			{
				$supplier = trim($allDataInSheet[$i]['A']);
				$landline = trim($allDataInSheet[$i]['B']);
			$contact_person = trim($allDataInSheet[$i]['C']);
			$contact_number = trim($allDataInSheet[$i]['D']);
			    $address = trim($allDataInSheet[$i]['E']);
				$notes = trim($allDataInSheet[$i]['F']);
			}
			else
			{
				$name = trim($allDataInSheet[$i]['A']);
				$email = trim($allDataInSheet[$i]['B']);
				$mobile = trim($allDataInSheet[$i]['C']);
				$address = trim($allDataInSheet[$i]['D']);
				$notes = trim($allDataInSheet[$i]['E']);
			}
		
		}
		if($flag==1)
		{		
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/excel/accounts/".$import_xls_file);
				if($page_name=="suppliers")
				redirect("add-suppliers","refresh");
				else
				redirect("add-customers","refresh");	
		}
		else
		{
			$dwnload_title=$this->input->post('dwnload_title');
			$data23=array(
			'excl_title'=>$dwnload_title,
			'excl_file'=>$inputFileName,
			'excl_status'=>"1",
			'excl_type' =>'result');
			$insert_id=$this ->Admin_model-> insert_data("excel_file", $data23);
			 $this -> insert_table($allDataInSheet,$insert_id,$page_name);
		}
	}


	function insert_table($allDataInSheet,$insert_id,$page_name) 
	{
		$arrayCount = count($allDataInSheet);
		$flag = 0;
		$status = true;
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			if($page_name=="suppliers")
			{
				$fetchData = array(
					'as_supplier_name'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['A']))),
                   	'as_landline'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['B']))),
                   	'as_contact_person'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['C']))),
                   	'as_mobile'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['D']))),

                    'as_address'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['E']))),
                   	'as_notes'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['F']))),
                 	'as_sts'=>'1',
                   'as_excel_id'=>$insert_id,
				   'as_staff'=>$this->session->userdata['user']['username']
					);
				//print_r($fetchData);
			$insert_id_table=$this->Admin_model->insert_data("acc_suppliers", $fetchData);

		$cutomer_code='1'.str_pad($insert_id_table, 4, '0', STR_PAD_LEFT);
        $data2=array('as_code'=>$cutomer_code);
        $cond1=array('as_id'=>$insert_id_table);

			if (!($this->Admin_model->update_data('acc_suppliers',$data2,$cond1)))
					$status = false;
			}
			else
			{
			$fetchData = array(
					'ac_name'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['A']))),
                   	'ac_email'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['B']))),
                   	'ac_mobile'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['C']))),
                    'ac_adrs'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['D']))),
                   	'ac_notes'=>$this ->security -> xss_clean(stripslashes(trim($allDataInSheet[$i]['E']))),
                 	'ac_sts'=>'1',
                   'ac_excel_id'=>$insert_id,
				   'ac_staff'=>$this->session->userdata['user']['username']
					);
				//print_r($fetchData);
			$insert_id_table=$this ->Admin_model-> insert_data("acc_cusotmer", $fetchData);

		$cutomer_code='1'.str_pad($insert_id_table, 4, '0', STR_PAD_LEFT);
        $data2=array('ac_code'=>$cutomer_code);
        $cond1=array('ac_id'=>$insert_id_table);

			if (!($this->Admin_model->update_data('acc_cusotmer',$data2,$cond1)))
					$status = false;	
			}		
		}

		if($page_name=="suppliers")
		{
		if ($status)
			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		redirect("add-suppliers", "refresh");
		}
		else
		{
		if ($status)
			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		redirect("add-customers", "refresh");	
		}
	}








}