<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_biri extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','gnrl'));	
	}
	
	function dashboard()
	{
		if(logged_in())
		{
		$this->load->view('admin/dashboard');
		}
	}

// tree
	
function list_tree()
	{

		//this->load->view('admin/list_tree');

        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
       if ($page_cred[$i]=='list_tree')
        {
			$excist=true;
			 $i=$cred_count;
		}
           else
           	{$excist=false;}

         }
        if ($excist) {
         	// code...

		$this->load->view('admin/list_tree');

	}
	else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}
	}

function list_positions()
	{

		

        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
       	if ((($page_cred[$i]=='list_positions')||($this ->session->userdata['user']['main_dept'])=="Main"))
        {
        	$excist=true;
        	 $i=$cred_count;

        }
           else
           	$excist=false;

         }
        if ($excist) {

        	$cond=array('position_sts'=>'1');
         $data['result']=$this->Admin_model->get_data('positions',$cond);

	    	$this->load->view('admin/list_positions',$data);

	}
	else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}
	}


function submit_positions()
{
if(logged_in())
		{
	$position_name=$this->input->post('Position_name');
	$position_name_ar=$this->input->post('Position_name_ar');
	$position_brief=$this->input->post('position_brief');
	$position_brief_ar=$this->input->post('position_brief_ar');
	$position_requirement=$this->input->post('position_requirement');
	$position_requirement_ar=$this->input->post('position_requirement_ar');
	$position_responsibilities=$this->input->post('position_responsibilities');
	$position_responsibilities_ar=$this->input->post('position_responsibilities_ar');
	$knowledge_skills_ability=$this->input->post('knowledge_skills_ability');
	$knowledge_skills_ability_ar=$this->input->post('knowledge_skills_ability_ar');
	$job_description=$this->input->post('job_description');
	$job_description_ar=$this->input->post('job_description_ar');
	$salary_min=$this->input->post('salary_min');
	$salary_max=$this->input->post('salary_max');
	$position_created=get_date_time();
	
	$data=array(
		'position_name'=>$position_name,
		'position_name_ar'=>$position_name_ar,
		'position_brief'=>$position_brief,
	    'position_breif_ar'=>$position_brief_ar,
		'position_requirement'=>$position_requirement,
		'position_requirement_ar'=>$position_requirement_ar,
		'position_responsibilities'=>$position_responsibilities,
		'position_responsibilities_ar'=>$position_responsibilities_ar,
		'job_description'=>$job_description,
		'job_description_ar'=>$job_description_ar,
		'knowledge_skills_ability'=>$knowledge_skills_ability,
		'knowledge_skills_ability_ar'=>$knowledge_skills_ability_ar,
		'salary_min'=>$salary_min,
		'salary_max'=>$salary_max,
		'position_sts'=>"1",
		'position_created'=>$position_created
	);
	$insert_id=$this->Admin_model->insert_data('positions',$data);
	$this->session->set_flashdata('success','Position added successfully');  	
	if($insert_id)
redirect('list_positions','refresh');
	}
}

function edit_position()
{
if(logged_in())
		{
	$pos_id=$this->input->post('pos_id');
	$position_name=$this->input->post('Position_name');
	$position_name_ar=$this->input->post('Position_name_ar');
	$position_brief=$this->input->post('position_brief');
	$position_brief_ar=$this->input->post('position_brief_ar');
	$position_requirement=$this->input->post('position_requirement');
	$position_requirement_ar=$this->input->post('position_requirement_ar');
	$position_responsibilities=$this->input->post('position_responsibilities');
	$position_responsibilities_ar=$this->input->post('position_responsibilities_ar');
	$job_description=$this->input->post('job_description');
	$job_description_ar=$this->input->post('job_description_ar');
			$knowledge_skills_ability=$this->input->post('knowledge_skills_ability');
	$knowledge_skills_ability_ar=$this->input->post('knowledge_skills_ability_ar');
	$salary_min=$this->input->post('salary_min');
	$salary_max=$this->input->post('salary_max');
	$position_update=get_date_time();

	$data=array(
	 'position_name'=>$position_name,
		'position_name_ar'=>$position_name_ar,
		'position_brief'=>$position_brief,
	    'position_breif_ar'=>$position_brief_ar,
		'position_requirement'=>$position_requirement,
		'position_requirement_ar'=>$position_requirement_ar,
		'position_responsibilities'=>$position_responsibilities,
		'position_responsibilities_ar'=>$position_responsibilities_ar,
		'job_description'=>$job_description,
		'job_description_ar'=>$job_description_ar,
		'knowledge_skills_ability'=>$knowledge_skills_ability,
		'knowledge_skills_ability_ar'=>$knowledge_skills_ability_ar,
		'salary_min'=>$salary_min,
		'salary_max'=>$salary_max,
		'position_update'=>$position_update
	);
	$cond=array('pos_id'=>$pos_id);
	$data['result']=$this->Admin_model->update_data('positions',$data,$cond);
	$this->session->set_flashdata('success','Position updated successfully');  	
redirect('list_positions','refresh');
	}
}





function delete_position($id)
{
    if(logged_in())
		{
	
	$data=array(
		'position_sts'=>'0',);
	$cond=array('pos_id'=>$id);
	$data['result']=$this->Admin_model->update_data('positions',$data,$cond);
$this->session->set_flashdata('success','Data deleted successfully'); 	
redirect('list_positions','refresh');
}
	
}


function list_terms()
	{

		

        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
       	if ((($page_cred[$i]=='list_terms')||($this ->session->userdata['user']['main_dept'])=="Main"))
        {
        	$excist=true;
        	 $i=$cred_count;

        }
           else
           	$excist=false;

         }
        if ($excist) {

        	$cond=array('term_sts'=>'1');
         $data['result']=$this->Admin_model->get_data('contract_term',$cond);

	    	$this->load->view('admin/list_terms',$data);

	}
	else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}
	}


	function submit_terms()
{
if(logged_in())
		{
	$term_name=$this->input->post('term_name');
	$term_name_ar=$this->input->post('term_name_ar');
	$term_contain=$this->input->post('term_contain');
	$term_contain_ar=$this->input->post('term_contain_ar');
	
	$term_created=get_date_time();
	
	$data=array(
		'term_name'=>$term_name,
		'term_name_ar'=>$term_name_ar,
		'term_contain'=>$term_contain,
		'term_contain_ar'=>$term_contain_ar,
	    
		'term_sts'=>"1",
		'term_created'=>$term_created
	);
	$insert_id=$this->Admin_model->insert_data('contract_term',$data);
	$this->session->set_flashdata('success','Terms added successfully');  	
	if($insert_id)
redirect('list_terms','refresh');
	}
}


function edit_terms()
{
if(logged_in())
		{
	$term_id=$this->input->post('term_id');
	$term_name=$this->input->post('term_name');
	$term_name_ar=$this->input->post('term_name_ar');
	$term_contain=$this->input->post('term_contain');
	$term_contain_ar=$this->input->post('term_contain_ar');
	
	$term_updated=get_date_time();
	
	$data=array(
		'term_name'=>$term_name,
		'term_name_ar'=>$term_name_ar,
		'term_contain'=>$term_contain,
		'term_contain_ar'=>$term_contain_ar,
	    
		'term_sts'=>"1",
		'term_updated'=>$term_updated
	);
	$cond=array('term_id'=>$term_id);
	$data['result']=$this->Admin_model->update_data('contract_term',$data,$cond);
	$this->session->set_flashdata('success','Terms updated successfully');  	
redirect('list_terms','refresh');
	}
}





function delete_terms($id)
{
    if(logged_in())
		{

		
	$data=array(
		'term_sts'=>'0',);
	$cond=array('term_id'=>$id);
	$data['result']=$this->Admin_model->update_data('contract_term',$data,$cond);
$this->session->set_flashdata('success','Data deleted successfully'); 	
redirect('list_terms','refresh');
}
	
}


function list_salary_structure()
	{

        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
       	if ((($page_cred[$i]=='list_salary_structure')||($this ->session->userdata['user']['main_dept'])=="Main"))
        {
        	$excist=true;
        	 $i=$cred_count;

        }
           else
           	$excist=false;

         }
        if ($excist) {

        	$cond=array('details_sts'=>'1','branch_company'=>'10');
         $data['result']=$this->Admin_model->get_data('emp_sal_structure',$cond);

	    	$this->load->view('admin/list_salary_structure',$data);

	}
	else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}
	}


	function submit_list_salary_structure()
{
if(logged_in())
		{
	$term_name=$this->input->post('term_name');
	$term_name_ar=$this->input->post('term_name_ar');
	$term_contain=$this->input->post('term_contain');
	$term_contain_ar=$this->input->post('term_contain_ar');
	
	$term_created=get_date_time();
	
	$data=array(
		'term_name'=>$term_name,
		'term_name_ar'=>$term_name_ar,
		'term_contain'=>$term_contain,
		'term_contain_ar'=>$term_contain_ar,
	    
		'term_sts'=>"1",
		'term_created'=>$term_created
	);
	$insert_id=$this->Admin_model->insert_data('contract_term',$data);
	$this->session->set_flashdata('success','Terms added successfully');  	
	if($insert_id)
redirect('list_terms','refresh');
	}
}







function job_offer_sts_list()
{
if(logged_in())
		{
  
		//$limit='10';
		//$dept=$this->session->userdata['user']['main_dept'];
		
		


$sql7=$this->db->query("SELECT jof.*,mc.mcomp_name,pot.position_name,nat.name FROM job_offer as jof join master_company as mc on mc.mcomp_id=jof.jo_branch join positions as pot on pot.pos_id=jof.jo_position_id join country_val as nat on nat.country_id=jof.jo_recipt_nationality WHERE jof.jo_status ='1' order by jof.job_id  DESC");



		$data['pending_offer_list']=$sql7->result();



	      if(!empty($data['pending_offer_list']))
     {
			foreach ($data['pending_offer_list'] as $index=>$val) 
			{
				$job_id=$val->job_id;	

		 		//$data['prd_data1'][]=$this->tm->prd_list_var($prd_id);
				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
		$data['new_offer_pending']=count($data['pending_offer_list']);
}else{}



////////////coding for Approving/////////////////////

$sql8=$this->db->query("SELECT jof.*,mc.mcomp_name,pot.position_name,nat.name FROM job_offer as jof join master_company as mc on mc.mcomp_id=jof.jo_branch join positions as pot on pot.pos_id=jof.jo_position_id join country_val as nat on nat.country_id=jof.jo_recipt_nationality WHERE jof.jo_status ='2' order by jof.job_id  DESC");



		$data['approved_offer_list']=$sql8->result();

if(!empty($data['approved_offer_list']))
		{
			foreach ($data['approved_offer_list'] as $val) 
			{
				//$prd_id=$val->srt_product;	
		 		//$data['prd_data2'][]=$this->tm->prd_list_var($prd_id);
				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
			// foreach ($data['result2'] as $val) 
			// {
			// 	$prd_id=explode('|#|',$val->po_prd_name);	
			// 	$data['prd_data2'][]=$this->tm->prd_var($prd_id);///getting product details	
			// }
			$data['new_offer_approved']=count($data['approved_offer_list']);
		}
		else{}


$this->load->view('admin/job_offer_sts_list',$data);
	}
}





function approve_job_offer()
{

if(logged_in())
		{

	
		$job_id=$this->input->post('job_id');
//$job_id=$id;
		//$srt_details=$this->Admin_model->get_data('picture_report',array('pr_id'=>$pr_id));

		
		//$dept_name=$this->session->userdata['user']['main_dept'];
		
	   // $date_approved=get_date();
		$return_report_approve=array('jo_status'=>'2');
		
		

		//$mail_data=array(
			//'srt_id'=>$srt_id,
		//);
		//$mail_info=send_po_approved_mail($mail_data);
		
		//$mail_info=send_srt_sts_mail($srt_id,'Approved');
		
		//print_r($mail_info);

		//if($mail_info==1)
	//{
			$cond2=array('job_id'=>$job_id);
		$this->Admin_model->update_data('job_offer',$return_report_approve,$cond2);


/*

$this->email->initialize($this->setting());


	    $this->email->from('noreply@birigroup.com','Biri Group');
   
    $picture_report_details=$this->Admin_model->get_data('picture_report',array('pr_id'=>$pr_id));
     $prd_details=$this->tm->get_data('products',array('pid'=> $picture_report_details[0]->pr_prd_id));

     $reported_user= $picture_report_details[0]->pr_user_created;
     $reported_user_details=$this->Admin_model->get_data('login_credentials',array('log_uname'=>$reported_user));
     $reported_user_email=strval($reported_user_details[0]->log_email);
      $this->email->to('waelibro555@gmail.com');
        //$this->email->to($reported_user_email);
        $this->email->subject('fixed picture problem : report #'.$pr_id);
        $msg="Hi,<br/>";
       $msg.='we fixed a problem with product picture  :'.$prd_details[0]->pcode.'<br/>';
        $msg.='product name:<br/>';
     $msg.=$prd_details[0]->pname.'<br/>';
       $msg.='the main problem was :  <br/>';
     $msg.=$picture_report_details[0]->pr_exact_problem.'<br/>';


  $msg.='and other note you sen to us : <br/>';
     $msg.=$picture_report_details[0]->pr_another_note.'<br/>';
    // $msg.='<a href="http://ad.birigroup.ae/reply_ticket/'.$insert_id.'">Click here to reply to this ticket</a> <br/><br/>';
      //  $msg.="<b>NOTE:Please make sure that you will reply to this ticket within 24 hours, else this ticket will be send to Management for further proceedings. </b><br/><br/>";        
         $msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
        $this->email->message($msg);
        //hi_arya();
            // $this->email->message('test');
         if($this->email->send())
         {
			$this->session->set_flashdata('success', 'Mail send successfully to Designer.');
         }
          else
         {
         	$this->session->set_flashdata('errors', 'Failed to send mail to Designer. Please try again later.');
            echo $this->email->print_debugger();
         } 

         $data23['pending']=$this->Admin_model->get_data('picture_report',array('pr_sts'=>'1'));
         $data24['aproved']=$this->Admin_model->get_data('picture_report',array('pr_sts'=>'2'));
		  $this->load->view('admin/design/all_report_pending',$data23);

            $this->load->view('admin/design/all_report_approved',$data24);


		$data_activity=array(
		'act_function'=>'Picture report fixed Approved',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$prd_id,
		'act_status'=>'approved',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$all_done=$this->Admin_model->insert_data('activities',$data_activity);	
        

*/


   //   $this->session->set_flashdata('success', ' successfully to user.');
//$this->load->view('admin/list_tree');





























 
        //$this->load->view('admin/design/Design_dashboard',$data);
      //  redirect('admin/design/Design_dashboard','refersh');
		//echo true;
		//}
		//else{
			
		//	echo false;
		//}
		
		}
	
}


















	function add_tree($id)
	{
		$data['id'] = $id;
		$this->load->view('admin/partials/model_lg');
	}
	function submit_add_subcategory()
	{
		if(!empty($this->input->post('folder_name')) )
		{
			$data = array(
				'label' => $this->input->post('folder_name'),
				'link' => '#',
				'parent' => $this->input->post('parent'),
				'sort' => '',
				'file' => $this->input->post('file'),
			);
			
			$insert_id = $this->Admin_model->insert_data('master_accounts_tree',$data);
			if(empty($insert_id))
			{
				$this->session->set_flashdata('error', 'Data is missing');
	        	redirect('list_tree');
			}
			else{
				$this->session->set_flashdata('success', 'Data successfully inserted');
	        	redirect('list_tree');
			}
			
		}
		else{
			

			$this->session->set_flashdata('error', 'Data is missing');
	        redirect('list_tree');	
		}
	}

	function submit_add_file()
	{
		if(!empty($this->input->post('file_name')) )
		{
			
			$data = array(
				'label' => $this->input->post('file_name'),
				'link' => '#',
				'parent' => $this->input->post('parent'),
				'sort' => '',
				'file' => '1',
			);
			
			$insert_id = $this->Admin_model->insert_data('master_accounts_tree',$data);
			if(empty($insert_id))
			{
				$this->session->set_flashdata('error', 'Data is missing');
	        	//redirect('list_tree');
			}
			else{
				// $data_update = array('file'=>'1');
				// $condition = array('id'=>$this->input->post('parent'));
				// $this->Admin_model->update_data('master_accounts_tree',$data_update,$condition);
				$data=array(
					"accounts_tree_id"=>$insert_id,
					
					'po_box'=>$this->input->post('po_box'),
					'email'=>$this->input->post('email'),
					'address'=>$this->input->post('address'),
					'phone'=>$this->input->post('phone'),
					'mobile_phone'=>$this->input->post('mobile_phone'),
					'fax'=>$this->input->post('fax'),
					'contact_person'=>$this->input->post('contact_person'),
					'account_no'=>$this->input->post('account_no'),
					'vat_no'=>$this->input->post('vat_no'),
					
					);
					$insert = $this->Admin_model->insert_data('master_accounts_tree_file_data',$data);
				$this->session->set_flashdata('success', 'Data successfully inserted');
	        	redirect('list_tree');
			}	
		}
		else{
		
			$this->session->set_flashdata('error', 'Data is missing');
	        redirect('list_tree');	
		}
	}


	function getItem()
    {
          $data = [];
          $parent_key = '0';
		  $row = $this->Admin_model->get_data('master_accounts_tree');
          //$row = $this->db->query('SELECT id, label, file from master_accounts_tree');
            
          if($row)
          {
              $data = $this->membersTree($parent_key);
          }else{
              $data=["id"=>"0","parent"=>"none","label"=>"No Members present in list","text"=>"No Members is presnt in list","tags"=>['balance:0.00','credit limit:0.00'],"nodes"=>[]];
          }
   
          echo json_encode(array_values($data));
    }
   
    /**
     * Get All Data from this method.
     *
     * @return Response
    */
    function membersTree($parent_key)
    {
        $row1 = [];
		$row = $this->Admin_model->get_data('master_accounts_tree',array('parent'=>$parent_key));

        // $row = $this->db->query('SELECT id, label, file from master_accounts_tree WHERE parent="'.$parent_key.'"')->result_array();
    
        foreach($row as $key => $value)
        {
			// if($value['file'] == 1)
			// {
			// 	$files = $this->db->query('SELECT id, name from master_accounts_tree_file_data WHERE accounts_tree_id="'.$value['id'].'"')->result_array();
			// 	foreach($files as $key2 => $value2)
			// 	{
			// 		$row1[$key2]['id'] = $value2['id'];
			// 		$row1[$key2]['name'] = $value2['name'];
			// 		$row1[$key2]['text'] = $value2['name'];
			// 	}	
			// }
			$leaf = $this->Admin_model->get_data('master_accounts_tree_file_data',array('accounts_tree_id'=>$value->id));
			if($value->file == 1)
			{
				$balance = 'balance:0.00';
				$credit = 'credit:0.00';
			}
			else
			{
				$balance = '';
				$credit = '';
			}

			if($value->file == 1)
			{
				$file = 'file';

			}
			else
			{
				$file = 'folder';
			}
           $id = $value->id;
           $row1[$key]['id'] = $value->id;
		   $row1[$key]['parent'] = $value->parent;
           $row1[$key]['file'] = $value->file;
           $row1[$key]['text'] = $value->label;
		   $row1[$key]['tags'] = [$balance,$credit];
		   $row1[$key]['icon'] = $file;

		   if($value->file == 1)
			{
				//$row1[$key]['nodes'] = array_values($this->membersTree($value->id));
				
			}
			else
			{
				$row1[$key]['nodes'] = array_values($this->membersTree($value->id));
			}
           
        }
  
        return $row1;
    }

		function accountsTreeView()
	{

		$row = $this->Admin_model->get_data('master_accounts_tree',array("id"=>$this->input->post('id')));

		$cond = array("accounts_tree_id"=>$this->input->post('id'));
		$result = $this->Admin_model->get_data('master_accounts_tree_file_data',$cond);
		$html = '<div class="row"><div class="col-md-3">Name</div>';
		$html .= '<div class="col-md-5"><input name="name" disabled value="'.$row[0]->label.'"></div>';
		$html .= '</div>';
		$html .= '<div class="row"><div class="col-md-3">P.O. Box</div>';
		$html .= '<div class="col-md-5"><input name="poBox" value="'.$result[0]->po_box.'"></div>';
		$html .= '</div>';
		$html .= '<div class="row"><div class="col-md-3">Address</div>';
		$html .= '<div class="col-md-5"><input name="address" value="'.$result[0]->address.'"></div>';
		$html .= '</div>';
		$html .= '<div class="row"><div class="col-md-3">Phone</div>';
		$html .= '<div class="col-md-5"><input name="phone" value="'.$result[0]->phone.'"></div>';
		$html .= '</div>';
		$html .= '<div class="row"><div class="col-md-3">Mobile Phone</div>';
		$html .= '<div class="col-md-5"><input name="mobile_phone" value="'.$result[0]->mobile_phone.'"></div>';
		$html .= '</div>';
		$html .= '<div class="row"><div class="col-md-3">Fax</div>';
		$html .= '<div class="col-md-5"><input name="fax" value="'.$result[0]->fax.'"></div>';
		$html .= '</div>';
		$html .= '<div class="row"><div class="col-md-3">Contact Person</div>';
		$html .= '<div class="col-md-5"><input name="contact" value="'.$result[0]->contact_person.'"></div>';
		$html .= '</div>';
		$html .= '<div class="row"><div class="col-md-3">Accounts Contact number</div>';
		$html .= '<div class="col-md-5"><input name="acc_number" value="'.$result[0]->acc_number.'"></div>';
		$html .= '</div>';
		$html .= '<div class="row"><div class="col-md-3">VAT</div>';
		$html .= '<div class="col-md-5"><input name="vat" value="'.$result[0]->vat_no.'"></div>';
		$html .= '</div>';
		print_r($html);
	}
	function editData($id)
	{
		$cond = array("accounts_tree_id"=>$id);
		$result = $this->Admin_model->get_data('master_accounts_tree_file_data',$cond);
		$cond2 = array("id"=>$id);
		$result2 = $this->Admin_model->get_data('master_accounts_tree',$cond2);
		$data['account_tree'] = $result2[0];
		$data['account_tree_data'] = $result;

        $salesman=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales', 'log_status !='=>'0'));
		foreach($salesman as $s)
		{
			$data['salesman'][]=$this->Admin_model->get_data('employee_details',array('ed_login_id'=>$s->log_id));
		}

		$data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
		$data['price_level']=$this->Admin_model->get_data('master_price_level',array('mpc_sts'=>'1'));
		$data['region']=$this->Admin_model->get_data('master_region',array('mr_sts'=>'1'));
		$data['payment_method']=$this->Admin_model->get_data('master_payment_method',array('mpm_sts'=>'1'));
		$data['place_supply']=$this->Admin_model->get_data('master_place_supply',array('mps_sts'=>'1'));
        $data['sales_accont']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'616'));

		$this->load->view('admin/account_masters/account_master_edit',$data);
	}
	function submit_update_account_tree_data()
	{
		$account_id = $this->input->post('account_id');
		$cond = array("accounts_tree_id"=>$account_id);
		$result = $this->Admin_model->get_data('master_accounts_tree_file_data',$cond);
		if(empty($result))
		{
			$data=array(
						'po_box'=>$this->input->post('po_box'),
						'email'=>$this->input->post('email'),
						'address'=>$this->input->post('address'),
						'phone'=>$this->input->post('phone'),
						'mobile_phone'=>$this->input->post('mobile_phone'),
						'fax'=>$this->input->post('fax'),
						'contact_person'=>$this->input->post('contact_person'),
						'vat_no'=>$this->input->post('vat_no'),
						
						'sm_number'=>$this->input->post('sm_number'),
						'sm_email'=>$this->input->post('sm_email'),
						'sm_name'=>$this->input->post('sm_name'),
						'own_email'=>$this->input->post('own_email'),
						'own_number'=>$this->input->post('own_number'),
						'own_name'=>$this->input->post('own_name'),
						'pur_email'=>$this->input->post('pur_email'),
						'pur_number'=>$this->input->post('pur_number'),
						'pur_name'=>$this->input->post('pur_name'),
						'acc_email'=>$this->input->post('acc_email'),
						'acc_number'=>$this->input->post('acc_number'),
						'acc_contact_name'=>$this->input->post('acc_contact_name'),
						'login_username'=>$this->input->post('login_username'),
						'login_password'=>$this->input->post('login_password'),

						'macd_company_id'=>$this->input->post('macd_company_id'),
						'macd_salesman_id'=>$this->input->post('macd_salesman_id'),
						'country'=>$this->input->post('country'),
						'macd_payment_type_id'=>$this->input->post('macd_payment_type_id'),
						'macd_price_level_id'=>$this->input->post('macd_price_level_id'),
						'macd_jurisdication_id'=>$this->input->post('macd_jurisdication_id'),
						'macd_place_supply_id'=>$this->input->post('macd_place_supply_id'),
						'macd_currency_value'=>$this->input->post('macd_currency_value'),
						'macd_sales_acc_id'=>$this->input->post('macd_sales_acc_id'),
						'credit_amount'=>$this->input->post('credit_amount'),
						'credit_days'=>$this->input->post('credit_days'),
			);
			$insert = $this->Admin_model->insert_data('master_accounts_tree_file_data',$data);
			if($insert)
			{
				$this->session->set_flashdata('error', 'Data Updated');
	        	redirect('editData/'.$account_id);
			}
		}
		else
		{
			$data=array(
				'po_box'=>$this->input->post('po_box'),
				'email'=>$this->input->post('email'),
				'address'=>$this->input->post('address'),
				'phone'=>$this->input->post('phone'),
				'mobile_phone'=>$this->input->post('mobile_phone'),
				'fax'=>$this->input->post('fax'),
				'contact_person'=>$this->input->post('contact_person'),
			
				'vat_no'=>$this->input->post('vat_no'),
				
						'sm_number'=>$this->input->post('sm_number'),
						'sm_email'=>$this->input->post('sm_email'),
						'sm_name'=>$this->input->post('sm_name'),
						'own_email'=>$this->input->post('own_email'),
						'own_number'=>$this->input->post('own_number'),
						'own_name'=>$this->input->post('own_name'),
						'pur_email'=>$this->input->post('pur_email'),
						'pur_number'=>$this->input->post('pur_number'),
						'pur_name'=>$this->input->post('pur_name'),
						'acc_email'=>$this->input->post('acc_email'),
						'acc_number'=>$this->input->post('acc_number'),
						'acc_contact_name'=>$this->input->post('acc_contact_name'),
						'login_username'=>$this->input->post('login_username'),
						'login_password'=>$this->input->post('login_password'),

						'macd_company_id'=>$this->input->post('macd_company_id'),
						'macd_salesman_id'=>$this->input->post('macd_salesman_id'),
						'country'=>$this->input->post('country'),
						'macd_payment_type_id'=>$this->input->post('macd_payment_type_id'),
						'macd_price_level_id'=>$this->input->post('macd_price_level_id'),
						'macd_jurisdication_id'=>$this->input->post('macd_jurisdication_id'),
						'macd_place_supply_id'=>$this->input->post('macd_place_supply_id'),
						'macd_currency_value'=>$this->input->post('macd_currency_value'),
						'macd_sales_acc_id'=>$this->input->post('macd_sales_acc_id'),
						'credit_amount'=>$this->input->post('credit_amount'),
						'credit_days'=>$this->input->post('credit_days'),
				
				);
			
			$update = $this->Admin_model->update_data('master_accounts_tree_file_data',$data,$cond);

			$this->session->set_flashdata('error', 'Data Updated');
			redirect('editData/'.$account_id);
		}
		$this->session->set_flashdata('error', 'Something went wrong');
		redirect('editData/'.$account_id);
	}
	function accountsMove()
	{
		$selected_to_move_id = $this->input->post('selected_id');
		$id_to_move = $this->input->post('move_id');
		$row = $this->Admin_model->get_data('master_accounts_tree',array("id"=>$selected_to_move_id));
		$data = array('parent' => $row[0]->parent);
		$update = $this->Admin_model->update_data('master_accounts_tree',$data,array("id"=>$id_to_move));
		echo 'true';
	}

function add_acc($id='',$page_type='')
	{
	if(logged_in())
	{
		if(empty($id) && empty($page_type))
		$this->load->view('admin/add_account_entry');
		else
		{
			
			if(empty($page_type))
			{				
				$cond=array('ae_id'=>$id);
			 $data['result']=$this->Admin_model->get_data('account_entry1',$cond);
			$this->load->view('admin/add_account_entry',$data);////need to sort as per the new data entered, so get has to modified
			}
			else
			{
				$cond=array('ae_id'=>$id);
			 $data['result']=$this->Admin_model->get_data('account_entry1',$cond);
			 $data['page_type']=$page_type;
			$this->load->view('admin/add_account_entry',$data);
			}
		}
	}

	}
	
	function before_submit()
	{
		$date_selected=$this->input->post('date_selected');
		$date_cond=date("Y-m-d", strtotime($date_selected));
		$cond=array('ae_desc !='=>'Opening Balances','ae_status'=>'1','ae_reconcile'=>'1');
		$order_by='ae_date';
		$order_type="ASC";
		$bank_result=$this->Admin_model->get_data('account_entry1',$cond,'','',$order_by,$order_type);
		$end_value=end($bank_result);
	if($end_value->ae_date >= $date_cond)
		{	
		 echo true;
		}//dont allow data entry,as the entry is reconcilled.
		else
		{
			echo false;
		}//allow data entry,as no reconcilled entry is found for this date.
	}

	function submit_account_entry()
	{				
		$acc_id=$this->security->xss_clean($this->input->post('acc_id'));////for update

		$this->form_validation->set_rules('cat', 'Category', 'trim|required');
		$this->form_validation->set_rules('bank', 'Bank Details', 'trim|required');
		$this->form_validation->set_rules('status', 'Status', 'trim|required');
		$this->form_validation->set_rules('date', 'Date', 'trim|required');
		$this->form_validation->set_rules('cash_type', 'Cash Type', 'trim|required');
		$this->form_validation->set_rules('desc', 'Description', 'trim|required');
		$this->form_validation->set_rules('amount', 'Amount', 'trim|required|numeric');

		  if ($this->form_validation->run() == FALSE)
                {
//                 	$myArr = array('value 1', 'value 1');
// //set it
// $this->session->set_flashdata('some_name', $myArr);

                	$this->session->set_flashdata('cat', form_error('cat'));
					$this->session->set_flashdata('bank', form_error('bank'));
					$this->session->set_flashdata('status', form_error('status'));
					$this->session->set_flashdata('date', form_error('date'));
				$this->session->set_flashdata('cash_type', form_error('cash_type'));
					$this->session->set_flashdata('desc', form_error('desc'));
					// $this->session->set_flashdata('amount', array(set_value('amount'),form_error('amount')));
						$this->session->set_flashdata('amount', form_error('amount'));
		
					//print_r(validation_errors());
                	redirect('add_account_entry','refersh');
                }
else
 {

    	if($this->input->post('cat')=="Others")
    	$other_cat=$this->input->post('others_cat');
    	else
    		$other_cat='';

    if($this->input->post('status')=="Others")
    	$others_status=$this->input->post('others_status');
    	else
		$others_status='';

    if($this->input->post('bank')=="Other Bank")
    	$other_bank=$this->input->post('other_bank');
    	else
    		$other_bank='';

    $s=$this->input->post('date');
  
 $dt = new DateTime($s);

$date_s = $dt->format('m/d/Y');
$time_s = $dt->format('g:i A');

//echo $date_s, ' | ', $time_s;

$convert_time=date("H:i:s", strtotime($time_s));
  $date = str_replace("/", "-", $date_s);             	

$date1=explode('-', $date);
			$month=$date1[0];
			$date=$date1[1];
			$year=$date1[2];
$new_formated_date=$year.'-'.$month.'-'.$date;

$limit='1';
		$order_by=('ae_date,ae_bal_amount');
			$order_type="DESC";

if(empty($acc_id))////only insertion
{
$bank_bal['bal_update']=
	array(
		'bank_name_updated'=>$this->input->post('bank'),
		);
	$this ->session->set_userdata($bank_bal);
}
else////for updation of record
{
	$bank_bal['bal_update']=
	array(
		'bank_name_updated'=>$this->input->post('bank'),
		);
	$this ->session->set_userdata($bank_bal);
}
	 $data=array(
	   	'ae_cat'=>$this->input->post('cat'),
	   	'ae_bank'=>$this->input->post('bank'),
	   	'ae_sts'=>$this->input->post('status'),
	   	'ae_date'=>$new_formated_date,
	   	'ae_time'=>$convert_time,
	   	'ae_month'=>$month,
	   	'ae_year'=>$year,
	   	'ae_cash_type'=>$this->input->post('cash_type'),
	   	'ae_desc'=>$this->input->post('desc'),
	   	'ae_cat_desc'=>$other_cat,
	   	'ae_sts_desc'=>$others_status,
	   	'ae_bank_desc'=>$other_bank,
	   	'ae_user'=>$this->session->userdata['user']['username'],
	   	'ae_amount'=>$this->input->post('amount'),
	   	//'ae_bal_amount'=>$new_bal_amount,
	   	'ae_status_data'=>'1',
	   );
           // print_r($data);
           // echo "<br/>";
	if(empty($acc_id))
           {
           	$insert_id=$this->Admin_model->insert_data('account_entry1',$data);

         	if(!empty($insert_id))
         	{
         	$data1=array('ae_status'=>'1');
         		$cond1=array('ae_id'=>$insert_id);
	       		$this->Admin_model->update_data('account_entry1',$data1,$cond1);
         	}
         	$bank_name=$this->input->post('bank');

           if($this->input->post('desc')!='Opening Balances')
			{
				$sts_update=update_bal_amount($insert_id);
				if($sts_update==1)
				{
				$this->session->set_flashdata('success', 'Data successfully inserted');
	           	redirect('add_account_entry');
				}
				else{
				redirect('add_account_entry');
				}
				
				
			}
			else
			{
			$this->session->set_flashdata('success', 'Data successfully inserted');
	           	redirect('add_account_entry');
			}
			
			$this->session->set_flashdata('success', 'Data successfully inserted');
	           	redirect('add_account_entry');
			
       }
   elseif(!empty($acc_id))
       {
       	$cond1=array('ae_id'=>$acc_id);
	   $this->Admin_model->update_data('account_entry1',$data,$cond1);

	  $status_data_entered= $this->input->post('status_data_entered');

	   $data2=array('ae_status_data'=>$status_data_entered);
	  $this->Admin_model->update_data('account_entry1',$data2,$cond1);

     	$page_type=$this->input->post('page_type');
     	$page_edit_dashboard=$this->input->post('page_edit');

         	if(!empty($page_type))
         	{
         		redirect('list_account_entry');
         	}
         	elseif(!empty($page_edit_dashboard))
         	{
         		redirect('dashboard');
         	}
         	else
         	{
         		redirect('list_account_entry');
         	}
       }
	    else
	    {
	    redirect('add_account_entry');
	    }
          
    }

}

		function list_account_entry()
	{
		if(logged_in())
		{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='list_account_entry')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



	if (!empty($this->session->userdata('selection_val'))) 
	{
	//echo "in if";
		$cash_type=$this->session->userdata['selection_val']['cash_type'];
		$bank_name=$this->session->userdata['selection_val']['bank_name'];
		$month_selected=$this->session->userdata['selection_val']['month'];
		$year_selected=$this->session->userdata['selection_val']['year'];

		$start_date_rng=$this->session->userdata['selection_val']['start_date'];
	$end_date_rng=$this->session->userdata['selection_val']['end_date'];
	$date_entred=$this->session->userdata['selection_val']['entry_date'];

		if(!empty($start_date_rng))
		$date_range_start= date("Y-m-d", strtotime($start_date_rng));
		else
			$date_range_start='';
		
		if(!empty($end_date_rng))
		$date_range_end= date("Y-m-d", strtotime($end_date_rng));
		else
			$date_range_end='';

		if(!empty($date_entred))
		$date_entred_val= date("Y-m-d", strtotime($date_entred));
		else
			$date_entred_val='';

		$order_by=('ae_date');
		$order_type="ASC";
		$data['result']=$this->Admin_model->get_data_list_account($cash_type,$bank_name,$month_selected,$year_selected,$date_range_start,$date_range_end,$date_entred_val,'','',$order_by,$order_type);

		$data['selection_val']=array(
		'cash_type'=>$cash_type,
		'bank_name'=>$bank_name,
		'month'=>$month_selected,
		'year'=>$year_selected,
		'start_date'=>$start_date_rng,
		'end_date'=>$end_date_rng,
		'entry_date'=>$date_entred,
		);
		
		$this->load->view('admin/list_accounts',$data);
		
	}
	else{
	//echo "in else";
	// $this->session->unset_userdata('selection_val',null)));
	$this->load->view('admin/list_accounts');
	}

		}
      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  // $cond=array('ae_status'=>'1');
		// $order_by='ae_id';
		// $order_type="DESC";
		// $data['result']=$this->Admin_model->get_data('account_entry1',$cond,'','',$order_by,$order_type);
		
		

		}
	}



function delete_account_entry($id,$page=null)
	{	
		if(logged_in())
		{
		$cond=array('ae_id'=>$id);
		$data_update=array('ae_status'=>'0');
		$data['result']=$this->Admin_model->update_data('account_entry1',$data_update,$cond);

$bal_amount=$this->Admin_model->get_data('account_entry1',array('ae_id'=>$id));
	$bank_name=$bal_amount[0]->ae_bank;

	$bank_bal['bal_update']=array(
		'bank_name_updated'=>$bank_name,
		);
	$this ->session->set_userdata($bank_bal);

		 $this->session->set_flashdata('success', 'Data successfully removed');
		 if(!empty($page))
		redirect('dashboard','refersh');
		 else
		 redirect('list_account_entry','refersh');
		}
	}
	


	function accounts_report()
	{
		if(logged_in())
		{

$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='accounts_report')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

		$this->load->view('admin/acc_report');

}
      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  // $cond=array('ae_status'=>'1');

		}
	}


	function cash_type_selected()
	{
		$cash_type=$this->input->post('cash_type');
		$bank_type=$this->input->post('bank_type');
		if(!empty($cash_type))
		{
			$cond=array('ae_status'=>'1','ae_cash_type'=>$cash_type);
			$order_by='ae_id';
			$order_type="DESC";
		}
		if(!empty($bank_type))
		{

			$cond_new=array('ae_bank'=>$bank_type);
			$opening_bal_bbms=$this->Admin_model->get_opening_bal($cond_new);
			$base_opening_amount=$opening_bal_bbms[0]->ae_amount;

			
		$cond=array('ae_status'=>'1','ae_bank'=>$bank_type,'ae_desc !='=>'Opening Balances');
			$order_by='ae_date';
			$order_type="ASC";
		}
		
		 $data['result']=$this->Admin_model->get_data('account_entry1',$cond,'','',$order_by,$order_type);

	$new_bal_amount='';
			$i=1;
			$j=1;
			print('
				<table class="table table-bordered table-striped mb-none" id="datatable-default">
				<thead>
<tr>
	<th></th>
<th>Category</th>
<th>Status</th>
<th>Bank</th>
<th>Date </th>
<th>Current Status</th> 
<th>Amount</th>
<th>Cash Mode </th>');
if(!empty($bank_type))
print('<th>Balance</th>');

print('<th>User Type</th>
<th>Description</th>
<th>Action</th>
</tr>
</thead>
<tbody>');
			foreach($data['result'] as $t)
			{

				if(!empty($base_opening_amount) && ($j==1))
				{
					if($t->ae_cash_type=="Spend")
						$new_bal_amount=$base_opening_amount-$t->ae_amount;
					else
						$new_bal_amount=$base_opening_amount+$t->ae_amount;
					
				}
			elseif(!empty($new_bal_amount) && ($j>1))
				{
				
					if($t->ae_cash_type=="Spend")
					$new_bal_amount=$new_bal_amount-$t->ae_amount;
						else
					$new_bal_amount=$new_bal_amount+$t->ae_amount;
				}
				else
				{
					$new_bal_amount='';
					$base_opening_amount='';
				}
			print('
				<tr class="gradeX">');
			print('<td>'.$i++.'</td>');
			print('<td>'.$t->ae_cat.'</td>');
			print('<td>'.$t->ae_sts.'</td>');
			print('<td>'.$t->ae_bank.'</td>');
			print('<td>'.$t->ae_date.'</td>');
			print('<td class="status_entry_'.$t->ae_id.'">');
				if($t->ae_status_data=="2"){
		print('<span class="pull-right label label-success">Success</span>');
		}
		else{
		print('<span class="pull-left label label-warning">Pending</span>');
		print('<button type="button" class="mb-xs mt-xs mr-xs btn btn-xs btn-primary" onclick="change_status('.$t->ae_id.')">Approve Now</button>');
		}
		// print('<br/>');
		// print('<button type="button" class="mb-xs mt-xs mr-xs btn btn-xs btn-primary" onclick="change_status('.$t->ae_id.')">Change</button>');
		print('</td>');
			
			print('<td>'.$t->ae_amount.'</td>');
			print('<td>'.$t->ae_cash_type.'</td>');
			
			if(!empty($bank_type))
			print('<td>'.$new_bal_amount.'</td>');
			
			print('<td>'.$t->ae_user.'</td>');
			print('<td>'.word_limiter($t->ae_desc,100).'</td>');
			print('<td>');
				
				print('<button class="mb-xs mt-xs mr-xs modal-sizes btn btn-default" onclick="view_modal('.$t->ae_id.')"><i class="fa fa-eye"></i></button>');	
				if($t->ae_status_data!="2")
				{	
					print('&nbsp; &nbsp;<a href="edit_account_entry/'. $t->ae_id.'/manager_edit"><i class="fa fa-pencil"></i></a>');
				}
						
		print('	</td>
			</tr>
			');
			$j++;
			}
			print('<tbody>
				</table>');
		
	}

	function modal_data()
	{
		$table_data=$this->input->post('table_id');
		$cond=array('ae_status'=>'1','ae_id'=>$table_data);
		$order_by='ae_id';
		$order_type="DESC";
		 $data['result']=$this->Admin_model->get_data('account_entry1',$cond,'','',$order_by,$order_type);
		 foreach($data['result'] as $r)
    			{
				if($r->ae_status_data=="2")
				{

					$data_show='<span class="label label-success">Success</span>';
				}
				else
				{
					$data_show='<span class="label label-warning">Pending</span>';
				}

    				$data=array(
    					"id"=>$r->ae_id,
			   				"cat"=> $r->ae_cat ,
					 		"cat_desc"=>$r->ae_cat_desc,
					 		"sts"=> $r->ae_sts,
					 		"sts_desc"=>$r->ae_sts_desc ,
					 		"bank"=> $r->ae_bank,
					 		"bank_desc"=>$r->ae_bank_desc,
					 		"cash_type"=>$r->ae_cash_type,
					 		"date"=>$r->ae_date,
					 		"desc"=>$r->ae_desc,
					 		"amount"=>$r->ae_amount,
					 		"show_data"=>$data_show,
					 	);
    			}
    			echo json_encode($data);

	}

	function approve_entry()
	{
	if(logged_in())
		{
		$table_id=$this->input->post('table_id');
		$data=array('ae_status_data'=>'2');
		$cond=array('ae_id'=>$table_id);
		$qry=$this->Admin_model->update_data('account_entry1',$data,$cond);
		if($qry)
			echo TRUE;
		}
	}

function accounts_report_graph()
	{
		
			 $excist=false;
		if(logged_in())
		{
           $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
      if ((($page_cred[$i]=='accounts_report_graph')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {
         	// code...


		     $this->load->view('admin/acc_grph_report');

		   }
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}


		}
	}

	function graph_data()
	{
	if(logged_in())
		{
		$years_selected=$this->input->post('years');
		$type_selected=$this->input->post('type');
		if($type_selected=='1' && !empty($years_selected))
		{
			$cond1=array('ae_status'=>'1','ae_cash_type'=>"Received",'ae_year'=>$years_selected);
			$data1=$this->Admin_model->get_data('account_entry1',$cond1);
			$count_rx=count($data1);
			
			$cond2=array('ae_status'=>'1','ae_cash_type'=>"Spend",'ae_year'=>$years_selected);
			$data2=$this->Admin_model->get_data('account_entry1',$cond2);
			$count_sx=count($data2);
			// print_r($data2);

			$data=array(
				'rx_count'=>$count_rx,
				'sx_count'=>$count_sx
			);

			echo json_encode($data);

		}
	else
		{
			$this->session->set_flashdata('errors', "Choose one type and date then submit");
			redirect('accounts_report_graph');
		}

		}


	}

	function graph_data2()
	{
	if(logged_in())
		{
		$years_selected=$this->input->post('years');
		$type_selected=$this->input->post('type');
		if($type_selected=='2' && !empty($years_selected))
		{
			$cond1=array('ae_status'=>'1','ae_bank'=>"ADIB-BBMS",'ae_year'=>$years_selected);
			$data1=$this->Admin_model->get_data('account_entry1',$cond1);
			$count1=count($data1);
			
			$cond2=array('ae_status'=>'1','ae_bank'=>"ADIB-Factory",'ae_year'=>$years_selected);
			$data2=$this->Admin_model->get_data('account_entry1',$cond2);
			$count2=count($data2);

			$cond3=array('ae_status'=>'1','ae_bank'=>"ENBD",'ae_year'=>$years_selected);
			$data3=$this->Admin_model->get_data('account_entry1',$cond3);
			$count3=count($data3);
			
			$cond4=array('ae_status'=>'1','ae_bank'=>"Cash Garhoud",'ae_year'=>$years_selected);
			$data4=$this->Admin_model->get_data('account_entry1',$cond4);
			$count4=count($data4);

			$cond5=array('ae_status'=>'1','ae_bank'=>"EI Bank",'ae_year'=>$years_selected);
			$data5=$this->Admin_model->get_data('account_entry1',$cond5);
			$count5=count($data5);
			
			$cond6=array('ae_status'=>'1','ae_bank'=>"Cash Mr. Bachir Book",'ae_year'=>$years_selected);
			$data6=$this->Admin_model->get_data('account_entry1',$cond6);
			$count6=count($data6);
			// print_r($data2);
			$cond7=array('ae_status'=>'1','ae_bank'=>"Other Bank",'ae_year'=>$years_selected);
			$data7=$this->Admin_model->get_data('account_entry1',$cond7);
			$count7=count($data7);

			$cond8=array('ae_status'=>'1','ae_bank'=>"Cash Factory",'ae_year'=>$years_selected);
			$data8=$this->Admin_model->get_data('account_entry1',$cond8);
			$count8=count($data8);
			

			$data=array(
				'count1'=>$count1,
				'count2'=>$count2,
				'count3'=>$count3,
				'count4'=>$count4,
				'count5'=>$count5,
				'count6'=>$count6,
				'count7'=>$count7,
				'count8'=>$count8,
			);

			echo json_encode($data);
			}
		}
	}


	





}