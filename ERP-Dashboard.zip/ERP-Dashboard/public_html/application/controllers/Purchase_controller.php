<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase_controller extends CI_Controller {
    public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','email_survey'));	
		$this->load->model(array('Second_db_model','Sales_book_model','Third_db_model'=>'tm','Survey_model'=>'srvm'));
        $this->db2 = $this->load->database('three', TRUE);	
		$this->load->library('numbertowordconvertsconver');		
	}
   function list_mrn()
    {


        if(logged_in())
        {

         $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
         $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {
            if ($page_cred[$i]=='list-purchase-mrn')
            {
               $excist=true;
               $i=$cred_count;
            }   

           else
                {$excist=false;}

        }
       if ($excist) {

            $data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'list-purchase-mrn'));
            $sql2=$this->db->query("SELECT mrn.*,mc.mcomp_name,mat.label as vendor_acc,mat2.label as purchase_acc
            FROM material_receipt_note as mrn join master_company as mc 
            on mc.mcomp_id=mrn.mrn_company join master_accounts_tree as mat on mat.id=mrn.mrn_vendor
            join master_accounts_tree as mat2 on mat2.id=mrn.mrn_purchase_account 
            WHERE mrn.mrn_sts = '1' order by mrn.mrn_id  DESC");
            $data['result']=$sql2->result_array();
            $this->load->view('admin/purchase/list_purchase_mrn',$data);

}
   else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
        } 


        }


    }

      function purchase_mrn_page($mrn=null)
    {
        if(logged_in())
        {
        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
          $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
            if ((($page_cred[$i]=='add-purchase-mrn')||($this ->session->userdata['user']['main_dept'])=="Main"))
            {
                $excist=true;
               $i=$cred_count;
            }   

            else
                {$excist=false;}

         }
       if ($excist) {


            $data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'add-purchase-mrn'));

            $vendors = array();
            $data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'245'));
            foreach($data['customers'] as $vendor_list)
            {
                $result = array();
                $child[] = $this->getChild($vendor_list->id);
                
                $result[]= array_merge($data['customers'], $child);
                
            }
           
            $vendors = $this->nestedToSingle($result[0]);
            // $customers_list =$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'638'));
            // $merge_customer_vendor = array_merge($vendors,$customers_list);
            // print_r($merge);
            // exit(0);
            $data['vendors']= $vendors;
           
            $data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
            $data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
             $data['purchase_accont']=$this->Admin_model->get_data('master_accounts_tree',array('id'=>'193'));
            $data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));
            $data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));
            $data['place_supply']=$this->Admin_model->get_data('master_place_supply',array('mps_sts'=>'1'));

            if(empty($mrn))
            {
                $val_recipt=$this->Admin_model->get_data('material_receipt_note',array('mrn_sts'=>'1'),'','','mrn_id','DESC');
                if(empty($val_recipt))
                $data['doc_num']='MRN 1200';
                    else
                    {
                    $bal_string1=str_replace("MRN ", "", $val_recipt[0]->mrn_doc_no);
                    //print_r($bal_string1);
                        $new_id_1=($bal_string1)+1;
                            $data['doc_num']="MRN ".$new_id_1;
                    }
            }
            else
            {
                $data['result']=$this->Admin_model->get_data('material_receipt_note',array('mrn_id'=>$mrn));
                $data['result_ac_tx']=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$mrn,'atx_type_tx'=>'MRN'));
            }	
            $this->load->view('admin/purchase/purchase_mrn',$data);

 }
else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
                } 




        }
    }
   function list_purchase_invoice()
    {
        if(logged_in())
        {
   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
         $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {
            if ((($page_cred[$i]=='list-purchase-invoice')||($this ->session->userdata['user']['main_dept'])=="Main"))
            {
               $excist=true;
               $i=$cred_count;
            }   

           else
                {$excist=false;}

        }
       if ($excist) {

            $data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'list-purchase-invoice'));
            $sql2=$this->db->query("SELECT pur.*,mc.mcomp_name,mat.label as cust_acc,mat2.label as sales_acc
            FROM purchase_invoice as pur join master_company as mc 
            on mc.mcomp_id=pur.pi_company join master_accounts_tree as mat on mat.id=pur.pi_vendor
            join master_accounts_tree as mat2 on mat2.id=pur.pi_purchase_account 
            WHERE pur.pi_sts = '1' order by pur.pi_id  DESC");
            $data['result']=$sql2->result_array();
            foreach($data['result'] as $t)
            {
                if($t['pi_current_sts']!="fully-paid")
                    {
                        $sql2=$this->db->query("SELECT atx_bal_amount,atx_paid_amount from account_all_tx where atx_type_tx='Purchase' and  atx_main_id='".$t['pi_id']."' ");
                        $qry_result=$sql2->result_array();

                        if($qry_result[0]['atx_bal_amount']=='0')
                        {
                            $update_sts='fully-paid';
                        }
                        elseif($qry_result[0]['atx_bal_amount']=='0.00')
                        {
                            $update_sts='fully-paid';
                        }
                        elseif(!empty($qry_result[0]['atx_paid_amount']))
                        {
                            $update_sts='partially-paid';
                        }
                        else
                        {
                            $update_sts='not-paid';
                        }
                        
                        $this->Admin_model->update_data('purchase_invoice',array('pi_current_sts'=>$update_sts),array('pi_id'=>$t['pi_id']));
                    }
            }

            $this->load->view('admin/purchase/list_purchase_invoice',$data);

            }
   else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
        } 

        }
    }
       function purchase_invoice($pur_id=null)
    {
        if(logged_in())
        {
           


        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
          $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
            if ((($page_cred[$i]=='add-purchase-invoice')||($this ->session->userdata['user']['main_dept'])=="Main"))
            {
                $excist=true;
               $i=$cred_count;
            }   

            else
                {$excist=false;}

         }
       if ($excist) {

            $data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'add-purchase-invoice'));
         
            $vendors = array();
            $data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'245'));
            foreach($data['customers'] as $vendor_list)
            {
                $result = array();
                $child[] = $this->getChild($vendor_list->id);
                $result[]= array_merge($data['customers'], $child);                
            }
           
            $vendors = $this->nestedToSingle($result[0]);
            // $customers_list =$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'638'));
            // $merge_customer_vendor = array_merge($vendors,$customers_list);
            // print_r($merge);
            // exit(0);
            $data['vendors']= $vendors;           
            $data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
            $data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
            $data['purchase_accont']=$this->Admin_model->get_data('master_accounts_tree',array('id'=>'484'));
            $data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));
            $data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));
            $data['place_supply']=$this->Admin_model->get_data('master_place_supply',array('mps_sts'=>'1'));

            if(empty($pur_id))
            {
                $val_recipt=$this->Admin_model->get_data('purchase_invoice',array('pi_sts'=>'1'),'','','pi_id','DESC');
                if(empty($val_recipt))
                $data['doc_num']='PUR 1200';
                    else
                    {
                    $bal_string1=str_replace("PUR ", "", $val_recipt[0]->pi_doc_no);
                    //print_r($bal_string1);
                        $new_id_1=($bal_string1)+1;
                        $data['doc_num']="PUR ".$new_id_1;
                    }
            }
            else
            {
                $data['result']=$this->Admin_model->get_data('purchase_invoice',array('pi_id'=>$pur_id));
                $data['result_ac_tx']=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$pur_id,'atx_type_tx'=>'Purchase'));
            }	
              $this->load->view('admin/purchase/purchase_invoice',$data);


    }
else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
                } 

              
        }
    }
    
    
    function get_vendor_mrn()
{
    $cust_id=$this->input->post('cust_id');
    $page_type=$this->input->post('page_type');
    $sql2=$this->db->query("SELECT material_receipt_note.*
            FROM material_receipt_note WHERE material_receipt_note.mrn_current_sts = 'not-paid' or  material_receipt_note.mrn_current_sts = 'partially-paid' and material_receipt_note.mrn_vendor='".$cust_id."' ");
        $dn_data=$sql2->result_array();
   
       foreach($dn_data as $index=>$ai)
        {
            //print_r($index);
            $doc_num[]=$ai['mrn_doc_no'];
            $date[]=$ai['mrn_date'];
            $inv_id[]=$ai['mrn_id'] ;
            $prds_ids[]=explode('|#|',$ai['mrn_product']);
            $qnty[]=explode('|#|',$ai['mrn_qty']);
             $value[]=explode('|#|',$ai['mrn_control']);          
        }
    $ij=1;  
        $html="<div class='row'>
        <div class='col-md-12'>";
$html.="<table class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
            $html.="<thead>";
            $html.="<th></th>";
            $html.="<th>Document No.</th>";
            $html.="<th>Date</th>";
            $html.="<th>Particulars</th>";
            $html.="<th>Quantity</th>";
             $html.="<th>Value</th>";
            // $html.="<th>Balance Amount</th>";
            $html.="</thead>";
            $html.="<tbody>";
            if(!empty($prds_ids))
            {
        foreach($prds_ids as $ind=>$k)
        {
            foreach($k as $v1=>$v)
            {
                //print_r($rates[$ind][$v1]);
                 $prd_data=$this->tm->get_data('products',array('pid'=>$v));
                 $html.="<tr>";
        $html.="<td><input type='checkbox' name='choose_inv' value='".$inv_id[$ind].",".$v1."'></td>";
        $html.="<td><p>".$doc_num[$ind]."</p></td>";
        $html.="<td><p>".$date[$ind]."</p></td>";
        $html.="<td><p>".$prd_data[0]->pname."</p></td>";
        $html.="<td><p>".$qnty[$ind][$v1]."</p></td>";
         $html.="<td><p>".$value[$ind][$v1]."</p></td>";
        $html.="</tr>"; 
            $ij++;
            }
        }       
    }
            $html.="</tbody>";
            $html.="</table>";
            $html.="</div>      
            </div>";
            echo $html;
}

function get_inv_details_checked()
    {
        $checked_vals=explode(',',$this->input->post('checked_inv'));
        $inv_id=$checked_vals[0];////here inv_id is from delivery_note
        $array_position=$checked_vals[1];

        $get_inv_details=$this->Admin_model->get_data('material_receipt_note',array('mrn_id '=>$inv_id));
        
        //print_r($total_gross);
        //print_r($warehouses[$array_position]);
        $data=array(
            'company'=>$get_inv_details[0]->mrn_company,
            'narration'=>$get_inv_details[0]->mrn_narration,
            'pls_sup'=>$get_inv_details[0]->mrn_place_of_supply,
            'jurisdiction'=>$get_inv_details[0]->mrn_jurisdiction,
            'currency'=>$get_inv_details[0]->mrn_currency,
            'currency_val'=>$get_inv_details[0]->mrn_conv_value,
            'tot_vat'=>$get_inv_details[0]->mrn_total_vat_amount,
            'tot_net'=>$get_inv_details[0]->mrn_total_amount,
            'mrn_id'=>$get_inv_details[0]->mrn_id ,
        );
        echo json_encode($data);
    }

function get_inv_table_checked()
    {
        $checked_vals=explode(',',$this->input->post('checked_inv'));
        $inv_id=$checked_vals[0];
        $array_position=$checked_vals[1];
//echo $page_type;
        $get_inv_details=$this->Admin_model->get_data('material_receipt_note',array('mrn_id'=>$inv_id));
         
    //  print_r($get_inv_details);
    //print_r($sales_inv_details);
        $prd_ids=explode('|#|',$get_inv_details[0]->mrn_product);
        $prd_desc=explode('|#|',$get_inv_details[0]->mrn_description);
        $prd_unit=explode('|#|',$get_inv_details[0]->mrn_unit);
        $qntys=explode('|#|',$get_inv_details[0]->mrn_qty);
        $rates=explode('|#|',$get_inv_details[0]->mrn_rate);
        $gross=explode('|#|',$get_inv_details[0]->mrn_gross);
        $add_charges=explode('|#|',$get_inv_details[0]->mrn_additional_charge);
        $dis_charges=explode('|#|',$get_inv_details[0]->mrn_discount_amount);
        $dis_per_charges=explode('|#|',$get_inv_details[0]->mrn_discount_percentage);
        $fnet=explode('|#|',$get_inv_details[0]->mrn_control);
        $vat=explode('|#|',$get_inv_details[0]->mrn_vat);
        $tax_code=explode('|#|',$get_inv_details[0]->mrn_tax_code);
     
        $ik=1;
        foreach($prd_ids as $ind=>$val)
        {
            if($ind==$array_position)
            {
            $gros_calc=$qntys[$ind]*$rates[$ind];

            if(!empty($add_charges[$ind]))
            $gross_add_charges=$add_charges[$ind];
            else
            $gross_add_charges=0;

            if(!empty($dis_per_charges[$ind]))
            $gross_desc_per=($gros_calc*($dis_per_charges[$ind]/100));
            else
            $gross_desc_per=0;

        if(!empty($dis_charges[$ind]))
            $gross_desc_charges=$dis_charges[$ind];
            else
            $gross_desc_charges=0;

        $total_gross_calc=$gros_calc+$gross_add_charges-$gross_desc_per-$gross_desc_charges;

                        $org_amount=$total_gross_calc/(($vat[$ind]+100)/100) ;/////works like 1.15 or 1.05 ie; 15+100/100 or 5+100/100
                        $vat_amount_calc=($org_amount*($vat[$ind]/100)  );///works like 0.15  or 0.05 ie; 15/100 or 0.5/100

                    
        $vat_val_calc=number_format((float)$vat_amount_calc, 2, '.', '');
        $total_final_net=$total_gross_calc-$vat_val_calc;////assuming this total value is already with vat , so reduce vat from it to see org total////

                $prd_details=$this->tm->get_data('products',array('pid'=>$val));
                $unit_details=$this->tm->get_data('prd_units',array('pu_pid_focus'=>$prd_details[0]->prod_id_focus));

        if(empty($prd_details[0]->p_prd_img))
        {
            $filename="https://birigroup.com/uploads/prd_images/".$prd_details[0]->pcode.'.jpeg';
         if (file_exists($filename)) {
            $img_path=$filename;
            } else {
            $img_path="https://birigroup.com/uploads/prd_images/".$prd_details[0]->pcode.'.jpg';
            }
        }
         else
         {
            $first_img_prd=explode(',',$prd_details[0]->p_prd_img);
            if(!empty($first_img_prd[0]))
            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
            else
            $img_path="https://birigroup.com/uploads/prd_images/".$prd_details[0]->p_prd_img;
         }

                $html='<tr>
                  <td><img src="'.$img_path.'" width="100" height="100"> </td>

            <td><input type="text" name="pi_product[]"  value="'.$prd_details[0]->pid.'"  step="any"  class="form-control "> <input type="hidden" name="each_prd[]" value="'.$prd_details[0]->pid.'"><input type="hidden" name="prd_index_position[]" value="'.$array_position.'"> </td>
            <td><input type="text" name="pi_description[]"  value="'.$prd_desc[$ind].'"  step="any"  class="form-control "> </td>';
            if(!empty($prd_unit[$ind]))
            {
             $html.= '<td><input type="text" name="pi_unit[]"  value="'.$prd_unit[$ind].'"  step="any"  class="form-control"> </td>';
            }
            elseif(!empty($unit_details[0]->pu_base_unit))
            {
             $html.= '<td><input type="text" name="pi_unit[]"  value="'.$unit_details[0]->pu_base_unit.'"  step="any"  class="form-control"> </td>';
            }
            else
            {
                $html.= '<td><input type="text" name="pi_unit[]"  value="Default"  step="any"  class="form-control"> </td>';
            }
                $html.=' <td><input type="number" name="pi_qty[]" onchange="get_new_qnty_val('.$ik.')"  value="'.$qntys[$ind].'"  step="any" 
                 class="form-control qnty'.$ik.'" readonly=""></td>
                <td><input type="text" readonly="" name="pi_link_1[]" value="'.$get_inv_details[0]->mrn_doc_no.'"  step="any"  class="form-control"> </td>
                <td><input type="number" name="pi_rate[]" value="'.$rates[$ind].'" step="any" readonly="" class="form-control rate'.$ik.'"> </td>
                <td><input type="number" name="pi_gross[]" value="'.$gross[$ind].'" step="any"  readonly="" class="form-control gross'.$ik.'"></td>

                <td><input type="number"  name="pi_discount_percentage[]" value="'.$dis_per_charges[$ind].'" readonly="" step="any"  class="form-control dis_per'.$ik.'"> <input type="hidden"  class="form-control dis_per_each_prd'.$ik.'" name="each_disc_per_amount[]" value="'.$gross_desc_per.'"></td>
                <td><input type="number"  name="pi_discount_amount[]" value="'.$dis_charges[$ind].'" readonly="" step="any"  class="form-control dis_amount'.$ik.'"> </td>

                <td><input type="number"  name="pi_additional_charge[]" value="'.$add_charges[$ind].'" readonly="" step="any"  class="form-control add_charges'.$ik.'">
                <input type="hidden" name="fnet_value[]" > 
                </td>
                  <td><input type="number"  name="pi_reverse_charge[]" value="0"  step="any"  class="form-control reverse_charge'.$ik.'"> </td>
                    <td><input type="number"  name="pi_adjustment[]" value="0" step="any"  class="form-control adjustment'.$ik.'"> </td>
                <td><input type="text"  name="pi_vat[]" class="form-control vat'.$ik.'" value="'.$vat[$ind].'" readonly="" ></td> 
                <td><input type="text" name="pi_tax_code[]"  value="'.$tax_code[$ind].'"  step="any"  readonly="" class="form-control fnet'.$ik.'" >
                <input type="hidden" name="each_vat_total[]" class="form-control vat_each_prd_val'.$ik.'" value="'.$vat_val_calc.'">
                <input type="hidden" name="each_fnet_total[]" value="'.$total_final_net.'">
               </td> 
                </tr>';
               $data['html_result']=$html;
                echo json_encode($data);
            }
            $ik++;
        }
    }

        function list_purchase_return()
    {
        if(logged_in())
        {
         $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
          $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
            if ((($page_cred[$i]=='list-purchase-return')||($this ->session->userdata['user']['main_dept'])=="Main"))
            {
                $excist=true;
               $i=$cred_count;
            }   

            else
                {$excist=false;}

         }
       if ($excist) {

            $data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'list-sales-invoice'));
            $sql2=$this->db->query("SELECT siv.*,mc.mcomp_name,mat.label as cust_acc,mat2.label as sales_acc
            FROM sales_invoice as siv join master_company as mc 
            on mc.mcomp_id=siv.si_company join master_accounts_tree as mat on mat.id=siv.si_customer_acc_id
            join master_accounts_tree as mat2 on mat2.id=siv.si_sales_acc_id 
            WHERE siv.si_sts = '1' order by siv.si_id DESC");
            $data['result']=[];
            $this->load->view('admin/purchase/list_purchase_return',$data);
    }
else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
                } 

        }
    }

     function purchase_return($siv=null)
    {
        if(logged_in())
        {
            $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
          $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
            if ((($page_cred[$i]=='add-purchase-return')||($this ->session->userdata['user']['main_dept'])=="Main"))
            {
                $excist=true;
               $i=$cred_count;
            }   

            else
                {$excist=false;}

         }
       if ($excist) {

            $data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'sales-invoice'));

            $salesman=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales', 'log_status !='=>'0'));
            foreach($salesman as $s)
            {
                $data['salesman'][]=$this->Admin_model->get_data('employee_details',array('ed_login_id'=>$s->log_id));
            }
            $vendors = array();
            $data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'245'));
            foreach($data['customers'] as $vendor_list)
            {
                $result = array();
                $child[] = $this->getChild($vendor_list->id);
                
                $result[]= array_merge($data['customers'], $child);
                
            }
           
            $vendors = $this->nestedToSingle($result[0]);
            // $customers_list =$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'638'));
            // $merge_customer_vendor = array_merge($vendors,$customers_list);
            // print_r($merge);
            // exit(0);
            $data['vendors']= $vendors;
           
            $data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
            $data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
            $data['price_level']=$this->Admin_model->get_data('master_price_level',array('mpc_sts'=>'1'));
            $data['region']=$this->Admin_model->get_data('master_region',array('mr_sts'=>'1'));
            $data['payment_method']=$this->Admin_model->get_data('master_payment_method',array('mpm_sts'=>'1'));
            $data['purchase_accont']=$this->Admin_model->get_data('master_accounts_tree',array('id'=>'193'));

            $data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));
            $data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));
            $data['place_supply']=$this->Admin_model->get_data('master_place_supply',array('mps_sts'=>'1'));

            if(empty($siv))
            {
                $val_recipt=$this->Admin_model->get_data('sales_invoice',array('si_sts'=>'1'),'','','si_id','DESC');
                if(empty($val_recipt))
                $data['doc_num']='INV 1200';
                    else
                    {
                    $bal_string1=str_replace("INV ", "", $val_recipt[0]->si_doc_no);
                    //print_r($bal_string1);
                        $new_id_1=($bal_string1)+1;
                            $data['doc_num']="INV ".$new_id_1;
                    }
            }
            else
            {
                $data['result']=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$siv));
                $data['result_ac_tx']=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$siv,'atx_type_tx'=>'Sales_Invoice'));
            }	
            $this->load->view('admin/purchase/purchase_return',$data);


          }
else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
                } 

        }

    }

    function get_details_prd()
    {
        $table_id=$this->input->post('table_id');
    $prd_data=$this->tm->get_data('products',array('p_sts'=>'1'));
$html='<select data-plugin-selectTwo  class="form-control populate product_'.$table_id.'" name="mrn_product[]" onchange="get_product_details('.$table_id.');"><option >Choose</option>';
    foreach($prd_data as $pd)
    {
    $html.="<option value=".$pd->pid.">".$pd->pname.":: <br/>".$pd->pcode."</option>";
    }
  $html.="</select>";
  echo $html;
    }

    function get_details_prd_unit()
    {
        $prd_selected=$this->input->post('prd_selected');
          $table_id=$this->input->post('table_id');
             $prd_data=$this->tm->get_data('products',array('p_sts'=>'1','pid'=>$prd_selected));
             print_r($prd_data);
             if(!empty($prd_data[0]->prod_id_focus))
             {
            $unit_details=$this->tm->get_data('prd_units',array('pu_pid_focus'=>$prd_data[0]->prod_id_focus));
                if(!empty($unit_details[0]->pu_base_unit))
                {
                 $html.= '<input type="text" name="mrn_unit[]"  value="'.$unit_details[0]->pu_base_unit.'"  step="any"  class="form-control">';
                }
                else
                {
                    $html.= '<input type="text" name="mrn_unit[]"  value="Default"  step="any"  class="form-control">';
                }
            }
            else
            {
              $html.= '<input type="text" name="mrn_unit[]"  value="Default"  step="any"  class="form-control">';
            }
            echo $html;
    }
    

    function get_product_extras()
    {
        $prd_id=$this->input->post('prd_id');
        $table_id=$this->input->post('table_id');
        $sql2=$this->db2->query("SELECT products.pid,prd_units.* FROM products join prd_units on prd_units.pu_pid_focus=products.prod_id_focus where products.pid='".$prd_id."' ");
        $data_result_set1=$sql2->result_array();
        // $html = "<option value=''>Choose</option>";
        if(!empty($data_result_set1))
        {
            $units=explode('|##|',$data_result_set1[0]['pu_units']);
            $base_unit=$data_result_set1[0]['pu_base_unit'];
            $html ="<option value='".$base_unit."'>".$base_unit."</option>";
            foreach($units as $u)
            {
                $html.="<option value='".$u."'>".$u."</option>";
            }
        }
        else
        {
            $html ="<option value='Default'>Default</option>";
        }
        echo $html;
    }

    function getChild($id)
    {
        $child = $this->Admin_model->get_data('master_accounts_tree',array('parent'=>$id));
        
        return $child;
    }

    function nestedToSingle(array $array)
    {
        $singleDimArray = [];

        foreach ($array as $item) {

            if (is_array($item)) {
                $singleDimArray = array_merge($singleDimArray, $this->nestedToSingle($item));

            } else {
                $singleDimArray[] = $item;
            }
        }

        return $singleDimArray;
    }

 function submit_mrn()
    {

    if(logged_in())
    {
        $page_type=$this->input->post('page_type');
        $edit_mrn=$this->input->post('mrn_id');
 
         $main_date1=explode('/',$this->input->post('mrn_date'));
            $month2=$main_date1[0];
            $date2=$main_date1[1];
            $year2=$main_date1[2];
               $new_formated_date1=$year2.'-'.$month2.'-'.$date2;
    /////for upload files//////
            $image = array();
            $uploadImgData = array();
            $ImageCount = count($_FILES['files']['name']);
         
        for($i = 0; $i < $ImageCount; $i++)
        {     
            $_FILES['file']['name']       = $_FILES['files']['name'][$i];
            $_FILES['file']['type']       = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['files']['error'][$i];
            $_FILES['file']['size']       = $_FILES['files']['size'][$i];

            // File upload configuration
            $uploadPath = 'uploads/sales_invoice/';
            $config['file_name'] = time() .preg_replace("/[^a-z0-9\_\-\.]/i", '', basename($_FILES["files"]["name"][$i]));
            $config['upload_path'] = $uploadPath;
            //$config['max_size'] = '3000000';////3mb
            $config['allowed_types'] = '*';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'business_card');
            $this->business_card->initialize($config);

            // Upload file to server
            if($this->business_card->do_upload('file'))
            {
              // Uploaded file data
                $imageData = $this->business_card->data();
              
                $uploadImgData[]=$imageData['file_name'];
              
                if(!empty($uploadImgData))
                {
                    $data_image=implode(',',$uploadImgData);
                }
                else
                {
                     $data_image='';
                }   
                //print_r($uploadImgData);
            } 
            else
            {
             if(!empty($this->input->post('files_added')))
                {
                $data_image=$this->input->post('files_added');
                }
                else
                {
                    $data_image='';
                }
            }      
        }
////end of for upload files//////////
    
            $data['mrn_doc_no']=$this->input->post('mrn_doc_no');
            
            $data['mrn_vendor']=$this->input->post('mrn_vendor');
            $data['mrn_purchase_account']=$this->input->post('mrn_purchase_account');
            $data['mrn_company']=$this->input->post('mrn_company');
            $data['mrn_narration']=$this->input->post('mrn_narration');
            $data['mrn_date']=$new_formated_date1;
            $data['mrn_delivery_reference_no']=$this->input->post('mrn_delivery_reference_no');
            $data['mrn_place_of_supply']=$this->input->post('mrn_place_of_supply');
            $data['mrn_jurisdiction']=$this->input->post('mrn_jurisdiction');
            $data['mrn_currency']=$this->input->post('mrn_currency');
            $data['mrn_conv_value']=$this->input->post('mrn_conv_value');
            $data['mrn_attachments']=$data_image;
            $data['mrn_warehouse']=$this->input->post('mrn_warehouse');

            $data['mrn_product']=$this->input->post('hi_prd_id');
            $data['mrn_description']=$this->input->post('hi_description');
            $data['mrn_unit']=$this->input->post('hi_unit');
            $data['mrn_qty']=$this->input->post('hi_quantity');
            $data['mrn_link']=$this->input->post('hi_link_1');
            $data['mrn_rate']=$this->input->post('hi_rate');
            $data['mrn_gross']=$this->input->post('hi_gross');
            $data['mrn_discount_percentage']=$this->input->post('hi_discount_percentage');
            $data['mrn_discount_amount']=$this->input->post('hi_discount_amount');
            $data['mrn_additional_charge']=$this->input->post('hi_additional_charge');
              $data['mrn_sts']='1';  

            $data['mrn_freight']=$this->input->post('hi_freight');
            $data['mrn_clearing']=$this->input->post('hi_clearing');
            $data['mrn_load_unload']=$this->input->post('hi_load_unload');
            $data['mrn_other']=$this->input->post('hi_other');
            $data['mrn_customs']=$this->input->post('hi_customs');
            $data['mrn_control']=$this->input->post('hi_control');
            
            $data['mrn_vat']=$this->input->post('hi_vat');
            $data['mrn_tax_code']=$this->input->post('hi_tax_code');
            $data['mrn_total_amount']=$this->input->post('mrn_total_amount');
            $data['mrn_total_vat_amount']=$this->input->post('mrn_total_vat_amount');
          
             if(empty($edit_inv_id))////willl insert
            {
             $document_bal_number=str_replace("MRN ", "", $this->input->post('mrn_doc_no'));
             $data['mrn_doc_number']=$document_bal_number;
            }
            if(empty($edit_mrn))
            {
             $insert_id=$this->Admin_model->insert_data('material_receipt_note',$data);
             if($insert_id)
             {
                $this->Admin_model->update_data('material_receipt_note',array('mrn_current_sts'=>'not-paid', 'mrn_user_created'=>$this->session->userdata['user']['username']),array('mrn_id'=>$insert_id));
             }
            }
            else
            {
                 $this->Admin_model->update_data('material_receipt_note',$data,array('mrn_id'=>$edit_mrn));
            }
           // pre_list($data);

             $prd_ids=explode('|#|',$this->input->post('hi_prd_id'));
             $prd_qnty=explode('|#|',$this->input->post('hi_quantity'));
             $prd_unit=explode('|#|', $this->input->post('hi_unit'));
             $prd_rate=explode('|#|',$this->input->post('hi_rate'));
             $prd_gross=explode('|#|', $this->input->post('hi_gross'));
             $prd_desc=explode('|#|',$this->input->post('hi_description'));

         foreach($prd_ids as $in=>$prd)
        {  
                                    $prd_stock_details=array(
                                    'psd_type'=>'MRN',
                                    'psd_ps_id'=>$insert_id,////GIVING MRN ID 
                                    'psd_warhouse'=>$this->input->post('mrn_warehouse'),
                                    'psd_product'=>$prd,
                                    'psd_unit'=>$prd_unit[$in],
                                    'psd_qnty'=>$prd_qnty[$in],
                                    'psd_rate'=>$prd_rate[$in],
                                    'psd_gross'=>$prd_gross[$in],
                                    'psd_desc'=>$prd_desc[$in],
                                );
                               //   pre_list($prd_stock_details);
                                   if(empty($edit_mrn))
                                   {
                                        $this->tm->insert_data('prd_stock_details',$prd_stock_details);
                                         $current_prd_stock_details=$this->tm->get_data('stock_details',array('sd_prd_id'=>$prd,'sd_warehouse_id'=>$this->input->post('mrn_warehouse')));


                                            $new_prd_qnty_edit=$current_prd_stock_details[0]->sd_stock_qnty+$prd_qnty[$in];
                                            if(empty($current_prd_stock_details))
                                            {
                                                $this->tm->insert_data('stock_details',array('sd_prd_id'=>$prd,'sd_warehouse_id'=>$this->input->post('mrn_warehouse'),'sd_stock_qnty'=>$prd_qnty[$in]) );
                                            }
                                            else
                                            {
                                                $this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_prd_qnty_edit),array('sd_prd_id'=>$prd,'sd_warehouse_id'=>$current_prd_stock_details[0]->sd_warehouse_id));
                                            }

                                

                                   }
                                   else
                                   {
                                    $prd_stock_details=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$edit_mrn,'psd_type'=>'MRN','psd_product'=>$prd));
                                        if(empty($prd_stock_details))
                                        {
                                             $this->tm->insert_data('prd_stock_details',$prd_stock_details);
                                            $current_prd_stock_details=$this->tm->get_data('stock_details',array('sd_prd_id'=>$prd,'sd_warehouse_id'=>$this->input->post('mrn_warehouse')));
                                            $new_prd_qnty_edit=$current_prd_stock_details[0]->sd_stock_qnty+$prd_qnty[$in];
                                            if(empty($current_prd_stock_details))
                                            {
                                                $this->tm->insert_data('stock_details',array('sd_prd_id'=>$prd,'sd_warehouse_id'=>$this->input->post('mrn_warehouse'),'sd_stock_qnty'=>$prd_qnty[$in]) );
                                            }
                                            else
                                            {
                                                $this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_prd_qnty_edit),array('sd_prd_id'=>$prd,'sd_warehouse_id'=>$current_prd_stock_details[0]->sd_warehouse_id));
                                            }
                                        }
                                        else
                                        {
                                            if($prd_stock_details[0]->psd_qnty!=$prd_qnty[$in])
                                            {
                                                $difference_qnty=$prd_qnty[$in]-$prd_stock_details[0]->psd_qnty;
                                                $this->tm->update_data('prd_stock_details',array('psd_qnty'=>$prd_stock_details[0]->psd_qnty+$difference_qnty,'psd_gross'=>$prd_gross[$in]),array('psd_ps_id'=>$edit_mrn,'psd_type'=>'MRN','psd_product'=>$prd) );

                                                $current_prd_stock_details=$this->tm->get_data('stock_details',array('sd_prd_id'=>$prd,'sd_warehouse_id'=>$this->input->post('mrn_warehouse')));

                                                 $new_prd_qnty_edit=$current_prd_stock_details[0]->sd_stock_qnty+$difference_qnty;


                                                   if(empty($current_prd_stock_details))
                                            {
                                                $this->tm->insert_data('stock_details',array('sd_prd_id'=>$prd,'sd_warehouse_id'=>$this->input->post('mrn_warehouse'),'sd_stock_qnty'=>$prd_qnty[$in]) );
                                            }
                                            else
                                            {
                                                $this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_prd_qnty_edit),array('sd_prd_id'=>$prd,'sd_warehouse_id'=>$current_prd_stock_details[0]->sd_warehouse_id));
                                            }

                                            }
                                        }
                                        
                                   }
     
        }

             ////end foreache 



                /////////////adding transaction for inventory a/c ////////////////   
                    $data_tx['atx_user_created']=$this->session->userdata['user']['username'];
                    $data_tx['atx_type_tx']='MRN';
                    $data_tx['atx_date']=$new_formated_date1;
                    $data_tx['atx_doc_no']=$this->input->post('mrn_doc_no');
                    if(empty($edit_mrn))
                    $data_tx['atx_main_id']=$insert_id;
                    else
                     $data_tx['atx_main_id']=$edit_mrn;
                    $data_tx['atx_acc_id']=$this->input->post('mrn_purchase_account');/////////////inventory a/c 
                    $data_tx['atx_cust_id']=$this->input->post('mrn_vendor');
                    $data_tx['atx_tot_amount']=$this->input->post('mrn_total_amount');
                    $data_tx['atx_vat_amount']=$this->input->post('mrn_total_vat_amount');
                    $data_tx['atx_narration']=$this->input->post('mrn_narration');
                    $data_tx['atx_quantity']=array_sum($prd_qnty);
                    $data_tx['atx_currency_value']=$this->input->post('mrn_conv_value');
                    $data_tx['atx_currency_type']=$this->input->post('mrn_currency');
                    //  pre_list($data_tx);
                    $data_tx['atx_bal_amount']=$this->input->post('mrn_total_amount');
                    $data_tx['atx_paid_amount']='0';
                    $data_tx['atx_dt_updt']=get_date_time();
                    $data_tx['atx_sts']='1';
                    $data_tx['atx_amount_type']='Expense';
                    if(empty($edit_mrn))
                    $insert_id_acc_vat_tx=$this->Admin_model->insert_data('account_all_tx',$data_tx);
                    else
                     $insert_id_acc_vat_tx=$this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_main_id'=>$edit_mrn,'atx_type_tx'=>'MRN','atx_acc_id'=>$this->input->post('mrn_purchase_account'),'atx_cust_id'=>$this->input->post('mrn_vendor') ));

                 /////////////adding transaction for unbilled supplier a/c ////////////////   
                    $data_tx2['atx_user_created']=$this->session->userdata['user']['username'];
                    $data_tx2['atx_type_tx']='MRN';
                    $data_tx2['atx_date']=$new_formated_date1;
                    $data_tx2['atx_doc_no']=$this->input->post('mrn_doc_no');
                     if(empty($edit_mrn))
                    $data_tx2['atx_main_id']=$insert_id;
                    else
                    $data_tx2['atx_main_id']=$edit_mrn;

                    $data_tx2['atx_acc_id']='484';//////unbilled supplier a/c
                    $data_tx2['atx_cust_id']=$this->input->post('mrn_vendor');
                    $data_tx2['atx_tot_amount']=$this->input->post('mrn_total_amount');
                    $data_tx2['atx_vat_amount']=$this->input->post('mrn_total_vat_amount');
                    $data_tx2['atx_narration']=$this->input->post('mrn_narration');
                    $data_tx2['atx_quantity']=array_sum($prd_qnty);
                    $data_tx2['atx_currency_value']=$this->input->post('mrn_conv_value');
                    $data_tx2['atx_currency_type']=$this->input->post('mrn_currency');
                    //  pre_list($data_tx);
                    $data_tx2['atx_bal_amount']=$this->input->post('mrn_total_amount');
                    $data_tx2['atx_paid_amount']='0';                           
                    $data_tx2['atx_dt_updt']=get_date_time();
                    $data_tx2['atx_sts']='1';
                    $data_tx2['atx_amount_type']='Income';
           
              if(empty($edit_mrn))
                     $insert_id_acc_vat_tx2=$this->Admin_model->insert_data('account_all_tx',$data_tx2);
                else
                    $insert_id_acc_vat_tx2=$this->Admin_model->update_data('account_all_tx',$data_tx2,array('atx_main_id'=>$edit_mrn,'atx_type_tx'=>'MRN','atx_acc_id'=>'484','atx_cust_id'=>$this->input->post('mrn_vendor') ));

               /////////////////vat o/p account data //////////////////             
                    $data_tx_vat['atx_user_created']=$this->session->userdata['user']['username'];
                    $data_tx_vat['atx_type_tx']='Vat_IP';
                    $data_tx_vat['atx_date']=$new_formated_date1;
                    $data_tx_vat['atx_doc_no']=$this->input->post('mrn_doc_no');
                    if(empty($edit_mrn))
                    $data_tx_vat['atx_main_id']=$insert_id;
                else
                    $data_tx_vat['atx_main_id']=$edit_mrn;

                    $data_tx_vat['atx_acc_id']='1013';
                    $data_tx_vat['atx_cust_id']=$this->input->post('mrn_vendor');
                    $data_tx_vat['atx_tot_amount']=$this->input->post('mrn_total_vat_amount');
                    $data_tx_vat['atx_paid_amount']='0';
                    $data_tx_vat['atx_bal_amount']=$this->input->post('mrn_total_vat_amount');
                    $data_tx_vat['atx_dt_updt']=get_date_time();
                    $data_tx_vat['atx_sts']='1';
                    $data_tx_vat['atx_amount_type']='Expense';
                    $data_tx_vat['atx_tranfer_type']='MRN';
                    $data_tx_vat['atx_narration']=$this->input->post('mrn_narration');
                    $data_tx_vat['atx_quantity']=array_sum($prd_qnty);
                    $data_tx_vat['atx_currency_value']=$this->input->post('mrn_conv_value');
                    $data_tx_vat['atx_currency_type']=$this->input->post('mrn_currency');

              if(empty($edit_mrn))
                     $insert_id_acc_vat_tx3=$this->Admin_model->insert_data('account_all_tx',$data_tx_vat);
                else
                    $insert_id_acc_vat_tx3=$this->Admin_model->update_data('account_all_tx',$data_tx_vat,array('atx_main_id'=>$edit_mrn,'atx_type_tx'=>'MRN','atx_acc_id'=>'1013','atx_cust_id'=>$this->input->post('mrn_vendor'),'atx_doc_no'=>$this->input->post('mrn_doc_no') ));

                  if(empty($edit_mrn))
             $this->session->set_flashdata('success', 'Data inserted successfully');
         else
            $this->session->set_flashdata('success', 'Data inserted edited');
             redirect('list-purchase-mrn');
      ////////////////end of the form submit function//////////////////////////           
    }
       
    }

function submit_purchase_voc()
{
    if(logged_in())
{
        $page_type=$this->input->post('page_type');
        $edit_inv_id=$this->input->post('pi_inv_id');
         $main_date=$this->input->post('hid_date');
          $due_date=$this->input->post('pi_due_date');
        $array_index_pos=explode('|#|',$this->input->post('hi_aray_index_pos'));
        $mrn_id=$this->input->post('mrn_id');

        $main_date1=explode('/',$main_date);
            $month2=$main_date1[0];
            $date2=$main_date1[1];
            $year2=$main_date1[2];
$new_formated_date1=$year2.'-'.$month2.'-'.$date2;

$due_date1=explode('/',$due_date);
            $month21=$due_date1[0];
            $date21=$due_date1[1];
            $year21=$due_date1[2];
$new_formated_date21=$year21.'-'.$month21.'-'.$date21;
    /////for upload files//////
    $image = array();
    $uploadImgData = array();
    $ImageCount = count($_FILES['files']['name']);
 
        for($i = 0; $i < $ImageCount; $i++)
        {     
            $_FILES['file']['name']       = $_FILES['files']['name'][$i];
            $_FILES['file']['type']       = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['files']['error'][$i];
            $_FILES['file']['size']       = $_FILES['files']['size'][$i];

            // File upload configuration
            $uploadPath = 'uploads/sales_invoice/';
            $config['file_name'] = time() .preg_replace("/[^a-z0-9\_\-\.]/i", '', basename($_FILES["files"]["name"][$i]));
            $config['upload_path'] = $uploadPath;
            //$config['max_size'] = '3000000';////3mb
            $config['allowed_types'] = '*';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'business_card');
            $this->business_card->initialize($config);

            // Upload file to server
            if($this->business_card->do_upload('file'))
            {
              // Uploaded file data
                $imageData = $this->business_card->data();
              
                $uploadImgData[]=$imageData['file_name'];
              
                if(!empty($uploadImgData))
                {
                    $data_image=implode(',',$uploadImgData);
                }
                else
                {
                     $data_image='';
                }   
                //print_r($uploadImgData);
            } 
            else
            {
             if(!empty($this->input->post('files_added')))
                {
                $data_image=$this->input->post('files_added');
                }
                else
                {
                    $data_image='';
                }
            }      
        }
////end of for upload files//////////

            $data['pi_doc_no']=$this->input->post('pi_doc_no');///////unbilled supplier a/c
            $data['pi_vendor']=$this->input->post('pi_vendor');
            $data['pi_purchase_account']=$this->input->post('pi_purchase_account');
            $data['pi_company']=$this->input->post('pi_company');
            $data['pi_narration']=$this->input->post('pi_narration');
            $data['pi_date']=$new_formated_date1;
            $data['pi_due_date']=$new_formated_date21;
            $data['pi_place_of_supply']=$this->input->post('pi_place_of_supply');
            $data['pi_jurisdiction']=$this->input->post('pi_jurisdiction');
            $data['pi_currency']=$this->input->post('pi_currency');
            $data['pi_conv_value']=$this->input->post('pi_conv_value');
            $data['pi_bill_no']=$this->input->post('pi_bill_no');
            $data['pi_import_permit']=$this->input->post('pi_import_permit');
            $data['pi_attachments']=$data_image;
            $data['pi_product']=$this->input->post('hi_prd_id');
            $data['pi_description']=$this->input->post('hi_description');
            $data['pi_unit']=$this->input->post('hi_unit');
            $data['pi_qty']=$this->input->post('hi_quantity');
            $data['pi_link_1']=$this->input->post('hi_link_1');
            $data['pi_rate']=$this->input->post('hi_rate');
            $data['pi_gross']=$this->input->post('hi_gross');
            $data['pi_discount_percentage']=$this->input->post('hi_discount_perentage');
            $data['pi_discount_amount']=$this->input->post('hi_discount_amount');
            $data['pi_additional_charge']=$this->input->post('hi_additional_charge');
            $data['pi_reverse_charge']=$this->input->post('hi_reverse_charge');
            $data['pi_adjustment']=$this->input->post('hi_adj');
            $data['pi_vat']=$this->input->post('hi_vat');
            $data['pi_fnet']=$this->input->post('hi_fnet');
            $data['pi_tax_code']=$this->input->post('hi_tax_code');
            $data['pi_total_amount']=$this->input->post('pi_total_amount');
            $data['pi_total_vat_amount']=$this->input->post('pi_total_vat_amount');
            $data['pi_sts']='1'; 
             $data['mrn_id']=$mrn_id;  

             if(empty($edit_inv_id))////willl insert
            {
             $document_bal_number=str_replace("PUR ", "", $this->input->post('pi_doc_no'));
             $data['pi_doc_number']=$document_bal_number;
            }
           // pre_list($data);
            if(empty($edit_inv_id))
            {
                $insert_id=$this->Admin_model->insert_data('purchase_invoice',$data);
                 if($insert_id)
                 {
                    $this->Admin_model->update_data('purchase_invoice',array('pi_current_sts'=>'not-paid', 'pi_user_created'=>$this->session->userdata['user']['username']),array('pi_id'=>$insert_id));
                 }
             }
             else
             {
                 $this->Admin_model->update_data('purchase_invoice',$data,array('pi_id'=>$edit_inv_id));
                 $insert_id=$edit_inv_id;
             }
            $qnty_details=explode('|#|',$this->input->post('hi_quantity'));
            
             $mrn_account_details=$this->Admin_model->get_data('account_all_tx',array('atx_type_tx'=>'MRN','atx_main_id'=>$mrn_id,'atx_acc_id'=>'484','atx_cust_id'=>$this->input->post('pi_vendor') ));
            $mrn_paid_amount= $mrn_account_details[0]->atx_paid_amount;
            $mrn_bal_amount= $mrn_account_details[0]->atx_bal_amount;

            if(empty($edit_inv_id))
            {
             $balance_amount_after_payment=$mrn_bal_amount-$this->input->post('pi_total_amount');
            $new_paid_amount= $mrn_paid_amount+$this->input->post('pi_total_amount');/////adding the newly paid to already existing, in purchase only mrn can be paid, so pur invoice amount paid will be zero(which is paid later in payments ), but mrn can get paid in purchase ////
            }
            else
            {
                $pur_details=$this->Admin_model->get_data('account_all_tx',array('atx_type_tx'=>'Purchase','atx_main_id'=>$edit_inv_id));
                if($pur_details[0]->atx_tot_amount!=$this->input->post('pi_total_amount'))
                {
                    $old_pur_total=$pur_details[0]->atx_tot_amount;
                    $diff_new_tot=$this->input->post('pi_total_amount')-$old_pur_total;

                    $balance_amount_after_payment=$mrn_bal_amount-$diff_new_tot;
                    $new_paid_amount= $mrn_paid_amount+$diff_new_tot;
                }
            }

            // echo $balance_amount_after_payment;
            // echo "<br/>";
            // echo $mrn_bal_amount;
            // echo "<br/>";
            // echo $this->input->post('pi_total_amount');

            $mrn_accounts=array(
                'atx_paid_amount'=>$new_paid_amount,
                'atx_bal_amount'=>$balance_amount_after_payment,
            );
            $this->Admin_model->update_data('account_all_tx',$mrn_accounts,array('atx_type_tx'=>'MRN','atx_main_id'=>$mrn_id,'atx_acc_id'=>'484','atx_cust_id'=>$this->input->post('pi_vendor') ) );

            if($balance_amount_after_payment=='0' || $balance_amount_after_payment=='0.00')
            {
               // echo "fully-paid";
                 $this->Admin_model->update_data('material_receipt_note',array('mrn_current_sts'=>'fully-paid'),array('mrn_id'=>$mrn_id));
            }
            else
            {
               // echo "partially-paid";
                 $this->Admin_model->update_data('material_receipt_note',array('mrn_current_sts'=>'partially-paid'),array('mrn_id'=>$mrn_id));
            }

            /////////////alll opr related to addding to acc_all_tx or acc_bal_tx table //////////////// 
            $data_tx['atx_user_created']=$this->session->userdata['user']['username'];
            $data_tx['atx_type_tx']='Purchase';
            $data_tx['atx_date']=$new_formated_date1;
            $data_tx['atx_doc_no']=$this->input->post('pi_doc_no');
            $data_tx['atx_main_id']=$insert_id;
            $data_tx['atx_acc_id']=$this->input->post('pi_purchase_account');
            $data_tx['atx_cust_id']=$this->input->post('pi_vendor');
            
            $data_tx['atx_tot_amount']=$this->input->post('pi_total_amount');
            $data_tx['atx_vat_amount']=$this->input->post('pi_total_vat_amount');
            $data_tx['atx_paid_amount']='0';
            $data_tx['atx_bal_amount']=$this->input->post('pi_total_amount');///assuming the total amount is vat reduced, so add back the vat amount to the total////////

            $data_tx['atx_dt_updt']=get_date_time();
            $data_tx['atx_sts']='1';
            $data_tx['atx_amount_type']='Expense';
            $data_tx['atx_narration']=$this->input->post('pi_narration');
            $data_tx['atx_quantity']=array_sum($qnty_details);
            $data_tx['atx_currency_value']=$this->input->post('pi_conv_value');
            $data_tx['atx_currency_type']=$this->input->post('pi_currency');
//pre_list($data_tx);
        if(empty($edit_inv_id))
          {
              $insert_id_acc_tx=$this->Admin_model->insert_data('account_all_tx',$data_tx);
          }
          else
          {
            $this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_type_tx'=>'Purchase','atx_main_id'=>$edit_inv_id));
            $acc_tx_id_data=$this->Admin_model->get_data('account_all_tx',array('atx_type_tx'=>'Purchase','atx_main_id'=>$edit_inv_id));
            $insert_id_acc_tx=$acc_tx_id_data[0]->atx_id;
          }

              /////////////////vat o/p account data //////////////////             
                    $data_tx_vat['atx_user_created']=$this->session->userdata['user']['username'];
                    $data_tx_vat['atx_type_tx']='Vat_IP';
                    $data_tx_vat['atx_date']=$new_formated_date1;
                    $data_tx_vat['atx_doc_no']=$this->input->post('pi_doc_no');
                    $data_tx_vat['atx_main_id']=$insert_id;
                    $data_tx_vat['atx_acc_id']='1013';
                    $data_tx_vat['atx_cust_id']=$this->input->post('pi_vendor');
                    $data_tx_vat['atx_tot_amount']=$this->input->post('pi_total_vat_amount');
                    $data_tx_vat['atx_paid_amount']='0';
                    $data_tx_vat['atx_bal_amount']=$this->input->post('pi_total_vat_amount');
                    $data_tx_vat['atx_dt_updt']=get_date_time();
                    $data_tx_vat['atx_sts']='1';
                    $data_tx_vat['atx_amount_type']='Expense';
                    $data_tx_vat['atx_tranfer_type']='purchase';
                    $data_tx_vat['atx_narration']=$this->input->post('pi_narration');
                    $data_tx_vat['atx_quantity']=array_sum($qnty_details);
                    $data_tx_vat['atx_currency_value']=$this->input->post('pi_conv_value');
                    $data_tx_vat['atx_currency_type']=$this->input->post('pi_currency');
///pre_list($data_tx_vat);
         if(empty($edit_inv_id))
          {
             $insert_id_acc_vat_tx3=$this->Admin_model->insert_data('account_all_tx',$data_tx_vat);
          }
          else
          {
            $this->Admin_model->update_data('account_all_tx',$data_tx_vat,array('atx_type_tx'=>'Vat_IP','atx_main_id'=>$edit_inv_id,'atx_doc_no'=>$this->input->post('pi_doc_no'),'atx_tranfer_type'=>'purchase','atx_cust_id'=>$this->input->post('pi_vendor') ));
          }

                $data_tx_bal=array(
                    'actb_tx_id'=>$insert_id_acc_tx,
                    'actb_to_type'=>$mrn_account_details[0]->atx_doc_no,
                    'actb_paid_amount'=>$this->input->post('pi_total_amount')+$this->input->post('pi_total_vat_amount'),
                    'actb_to_id'=>$mrn_account_details[0]->atx_id,
                    'actd_sts'=>'1',
                    'actb_user_created'=>$this->session->userdata['user']['username'],
                );  
                 // print_r($data_tx_bal);
            if(empty($edit_inv_id))
           {
                $this->Admin_model->insert_data('account_tx_bal_data',$data_tx_bal);
            }
            else
            {
                $this->Admin_model->update_data('account_tx_bal_data',$data_tx_bal,array('actb_tx_id'=>$insert_id_acc_tx,'actb_to_id'=>$mrn_account_details[0]->atx_id));
            }
          if(empty($edit_inv_id))
             {
          $this->session->set_flashdata('success', 'Data inserted successfully');
             }
             else
             {
    $this->session->set_flashdata('success', 'Data updated successfully');
             }
             redirect('list-purchase-invoice');
          
    }
}

function get_doc_details()
{
    $cbr_id=$this->input->post('main_id');
   $dataa=$this->Admin_model->get_data('material_receipt_note',array('mrn_id'=>$cbr_id));
        if($dataa)
            {
            $currency_convt=$this->Admin_model->get_data('master_currency_conv',array('currency_name'=>$dataa[0]->mrn_currency));
            $company_masters=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->mrn_company));
            $purchase_accont=$this->Admin_model->get_data('master_accounts_tree',array('id'=>'193'));
            $warehouse_data=$this->Admin_model->get_data('master_warehouse',array('mw_id'=>$dataa[0]->mrn_warehouse));
            $place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->mrn_place_of_supply));
            $jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->mrn_jurisdiction));
            $customers=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->mrn_vendor));

                $account_tx_data=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_type_tx'=>'MRN'));
                if(!empty($account_tx_data))
                {
                    $account_bal_data_1=$this->Admin_model->get_data('account_tx_bal_data',array('actb_to_id'=>$account_tx_data[0]->atx_id));
                    if(!empty($account_bal_data_1))
                    {
                        foreach($account_bal_data_1 as $abd)
                        {
                            $tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_tx_id));
                        }
                    }
                    else
                    {
                        $account_bal_data_2=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_data[0]->atx_id));
                        if(!empty($account_bal_data_2))
                        {
                            foreach($account_bal_data_2 as $abd)
                            {
                                $tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_to_id));
                            }   
                        }
                    }
                }
                      
                $prd_list=explode('|#|',$dataa[0]->mrn_product);
                foreach($prd_list as $pl)
                {
                    $data_pl[]=$this->tm->get_data('products',array('pid'=>$pl));
                }

                $desc=explode('|#|',$dataa[0]->mrn_description);
                $unit=explode('|#|',$dataa[0]->mrn_unit);
                $link=explode('|#|',$dataa[0]->mrn_link);

                $qnty_list=explode('|#|',$dataa[0]->mrn_qty);
                $rate_list=explode('|#|',$dataa[0]->mrn_rate);
                $gross_list=explode('|#|',$dataa[0]->mrn_gross);
                $disc_per_list=explode('|#|',$dataa[0]->mrn_discount_percentage);
                $disc_amount_list=explode('|#|',$dataa[0]->mrn_discount_amount);
                $add_charges_list=explode('|#|',$dataa[0]->mrn_additional_charge);

                $freigh=explode('|#|',$dataa[0]->mrn_freight);
                $clearing=explode('|#|',$dataa[0]->mrn_clearing);
                $load_unload=explode('|#|',$dataa[0]->mrn_load_unload);
                $other=explode('|#|',$dataa[0]->mrn_other);
                $customs=explode('|#|',$dataa[0]->mrn_customs);
                $control=explode('|#|',$dataa[0]->mrn_control);

               $vat_list=explode('|#|',$dataa[0]->mrn_vat);
                    $tax_list=explode('|#|',$dataa[0]->mrn_tax_code);
                    
                    $html="<div class='row'>";
                    $html.="<div class='col-md-12'><h4>MRN Data</h4>";

                    $html.="<div class='col-md-4'>";
                    $html.="<p>Doc no: ".$dataa[0]->mrn_doc_no."</p>";
                    $html.="<p>User Created: ".$dataa[0]->mrn_user_created."</p>";
                    $html.="<p>Date: ".$dataa[0]->mrn_date."</p>";
                    $html.="<p>Currency: ".$dataa[0]->mrn_currency."</p>";
                    $html.="<p>Currency Value: ".$dataa[0]->mrn_conv_value."</p>";
                    $html.="</p>";

                    $html.="<p style='color:blue'><b>Linked to :</b></p>";
                    if(!empty($tx_data_related))
                    {
                        foreach($tx_data_related as $tx)
                        {
                            $html.="<p style='color:blue'>".$tx[0]->atx_doc_no."</p>";
                        }
                    }   
                    $html.="</div>";

                    $html.="<div class='col-md-4'>";
                
                    $html.="<p>Purchase Account: ".$purchase_accont[0]->label."</p>";
                    $html.="<p>Company: ".$company_masters[0]->mcomp_name."</p>";
                     $html.="<p>Warehouse: ".$warehouse_data[0]->mw_name."</p>";
                 
                
                    $html.="<p>Place of Supply: ".$place_supply[0]->mps_name."</p>";
                    $html.="<p>Jurisdiction: ".$jurisdaction[0]->mps_name."</p>";
                    $html.="<p>Narration: ".$dataa[0]->mrn_narration."</p>";
                    
                $html.="</div>";

                    $html.="<div class='col-md-4'>";
                    $html.="<p>Customer : ".$customers[0]->label."</p>";
                  
                $html.="<p>Current Status: ".$dataa[0]->mrn_current_sts."</p>";
                    $html.="<p>Attachements: <a href='".base_url('uploads/sales_invoice/'.$dataa[0]->mrn_attachments)."' target='_blank'> ".$dataa[0]->mrn_attachments."</a></p>";
                    $html.="</div>";
                    /*** end of col-md-12 and row ***/
                    $html.="</div>";
                    $html.="</div>";
                    /*** start of table  ***/
                        $html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
                    $html.="<thead><th></th>
                    <th>Product</th>
                     <th>Description</th> <th>Unit</th>
                        <th>Link</th>
                    <th>Quantity</th><th>Rate</th>
                    <th>Gross</th><th>Discount(%)</th>
                    <th>Discount Amount</th><th>Add.Charges</th>
                    <th>Freight</th><th>Clearing</th>
                    <th>Load/Unload</th><th>Others</th>
                    <th>Customs</th><th>Control</th>
                    <th>Vat(%)</th>
                   <th>Tax Code</th></thead>";
                    $html.="<tbody>";
                    foreach($data_pl as $key=>$d)
                    {
                        $qnty_tot[]=$qnty_list[$key];
                        $rate_tot[]=$rate_list[$key];
                        $gross_tot[]=$gross_list[$key];
                        
                        $dis_amnt_tot[]=$disc_amount_list[$key];
                        $adchrg_tot[]=$add_charges_list[$key];
                        $fent_tot[]=$control[$key];
                    
                        $html.="<tr>";
                        $html.="<td></td>";
                       
                        $html.="<td>".$d[0]->pname."</td>";
                        $html.="<td>".$desc[$key]."</td>";
                        $html.="<td>".$unit[$key]."</td>";
                        $html.="<td>".$link[$key]."</td>";
                            
                        $html.="<td>".$qnty_list[$key]."</td>";
                        $html.="<td>".$rate_list[$key]."</td>";
                        $html.="<td>".$gross_list[$key]."</td>";

                        $html.="<td>".$gross_list[$key]*($disc_per_list[$key]/100);
                        $dis_per_tot[]=$gross_list[$key]*($disc_per_list[$key]/100);
                        $html.="</td>";
                        $disc_per_list[$key]."</td>";
                        $html.="<td>".$disc_amount_list[$key]."</td>";
                        $html.="<td>".$add_charges_list[$key]."</td>";

                        $html.="<td>".$freigh[$key]."</td>";
                        $html.="<td>".$clearing[$key]."</td>";
                        $html.="<td>".$load_unload[$key]."</td>";
                        $html.="<td>".$other[$key]."</td>";  
                        $html.="<td>".$customs[$key]."</td>";

                        $html.="<td>".$control[$key]."</td>";
             
                           
                        $org_amount=$control[$key]/(($vat_list[$key]+100)/100) ;
                        $vat_amount_calc=($org_amount*($vat_list[$key]/100)  );

                        $html.="<td>".number_format((float)$vat_amount_calc, 2, '.', '');
                        $vat_amount_tot[]=number_format((float)$vat_amount_calc, 2, '.', '');

                        $html.="</td>";

                        $html.="<td>".$tax_list[$key]."</td>";
                    
                        $html.="</tr>";
                    }
                    $html.="</tbody>";
                    $html.="</table>";
                    $html.="<div class='row'>";
                    $html.="<div class='col-md-12'><div class='col-md-4'>";
                    $html.="<p>Total Quantity : ".array_sum($qnty_tot)."</p>";
                    $html.="<p>Total Rate  : ".array_sum($rate_tot)."</p>";
                    $html.="<p>Total Gross : ".array_sum($gross_tot)."</p>";
                    $html.="</div>";
                    $html.="<div class='col-md-4'>";
                    $html.="<p>Total Discount(%) : ".array_sum($dis_per_tot)."</p>";
                    $html.="<p>Total Discount Amount : ".array_sum($dis_amnt_tot)."</p>";
                    $html.="<p>Total Additional Charges : ".array_sum($adchrg_tot)."</p>";
                    $html.="</div>";
                    $html.="<div class='col-md-4'>";
                    $html.="<p>Total Fnet : ".array_sum($fent_tot)."</p>";
                    $html.="<p>Total VAT Amount : ".array_sum($vat_amount_tot)."</p>";
                    $html.="<p>Final Amount : ".(array_sum($fent_tot)-array_sum($vat_amount_tot))."</p>";
                    $html.="</div>";$html.="</div>";
                    $html.="</div>";
                    /*** start of table  ***/
                    echo $html;
            }
}


function generate_mrn($mrn_id)
{
if(logged_in())
{
    if(!empty($mrn_id))
    {
         $dataa=$this->Admin_model->get_data('material_receipt_note',array('mrn_id '=>$mrn_id));
        if($dataa)
        {
            $warehouse_data=$this->Admin_model->get_data('master_warehouse',array('mw_id'=>$dataa[0]->mrn_warehouse));
           
            $prd_list=explode('|#|',$dataa[0]->mrn_product);
            $qnty_list=explode('|#|',$dataa[0]->mrn_qty);
            $stylesheet = file_get_contents('style_mpdf.css');

                $html='<!doctype html>
                <head></head><body>';

                $html.='<div class="content" style="padding-top:2%;">
                <table class="cusotmer_info" align="center"  width="80%" border="1"><tbody>';
                                                
                $html.='<tr>';
                $html.='<td colspan="2" align="center"><b>Material Receipt Note</b></td>';
                $html.='</tr>';
                $html.='<tr>';
                 $html.='<td align="center" ><b>Document No. </b></td>';
                $html.='<td align="center"  ><b>'.$dataa[0]->mrn_doc_no.'</b></td>';
                $html.='</tr>';
                $html.='<tr>';
                 $html.='<td align="center" ><b>Warehouse Name</b></td>';
                $html.='<td align="center" ><b>'.$warehouse_data[0]->mw_name.'</b></td>';
                $html.='</tr>';
                $html.='<tr>';
                 $html.='<td align="center" ><b>Date</b></td>';
                 $html.='<td align="center"><b>'.$dataa[0]->mrn_date.'</b></td>';
                $html.='</tr>';
                 $html.='</tbody>';
                $html.='</table><br/><br/>';


                $html.='<table  width="100%">';
                $html.='<tbody>';
                 foreach($prd_list as $pl)
                {
                    $data_pl[]=$this->tm->get_data('products',array('pid'=>$pl));
                }

                $html.='<tr>';
                 $html.='<td align="center" class="prd_info_2"><b>S No.</b></td>';
                 $html.='<td align="center" class="prd_info_2"><b>Product Code</b></td>';
                 $html.='<td align="center" class="prd_info_2"><b>Description</b></td>';
                 $html.='<td align="center" class="prd_info_2"><b>Quantity</b></td>';
                 $html.='<td align="center" class="prd_info_2"><b>Image</b></td>';
                $html.='</tr>';
            $i=1;
                foreach($data_pl as $indx=>$val)
                {
                    $pname=explode('|~~|',$val[0]->pname);
                        if(!empty($pname[0]))
                        {
                            $prd_names=explode(',',$pname[0]);
                            $product_name=$prd_names[0];
                        }
                        else
                        {
                            $pname=explode(',',$val[0]->pname);
                            $product_name=$pname[0];
                        }

                        ////imagee/////////
                        if(empty($val[0]->p_prd_img))
                        {
                            $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($val[0]->pcode).".jpeg";
                         if (file_exists($filename)) {
                            $img_path=$filename;
                            } else {
                            $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($val[0]->pcode).".jpg";
                            }
                        }
                        else
                        {
                            $first_img_prd=explode(',',$val[0]->p_prd_img);
                            if(!empty($first_img_prd[0]))
                            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
                            else
                            $img_path="https://birigroup.com/uploads/prd_images/".$val[0]->p_prd_img."";
                            
                        }

                     $html.='<tr>';
                    $html.='<td align="center">'.$i++.'</td>';
                     $html.='<td align="center">'.$val[0]->pcode.'</td>';
                     $html.='<td align="center">'.$product_name.'</td>';
                     $html.='<td align="center">'.$qnty_list[$indx].'</td>';
                     $html.='<td align="center"><img src="'.$img_path.'" width="100" height="100"></td>';
                      $html.='</tr>';
                }
              
                $html.='</tbody>';
                $html.='</table>';

                  $html.='</div></body></html>';
                  $pdfFilePath = $dataa[0]->mrn_doc_no.'.pdf';

        $mpdf = new \Mpdf\Mpdf();
       $mpdf->autoScriptToLang = true;
        $mpdf->autoLangToFont = true;
    $mpdf->autoArabic=true;
       $mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">');
        $mpdf->SetFooter('<img src="'.base_url("berry_footer.png").'">');
         $mpdf->WriteHTML($stylesheet,1);
          $mpdf->AddPage('', // L - landscape, P - portrait 
        '', '', '', '',
        5, // margin_left
        5, // margin right
       35, // margin top
       20, // margin bottom
        0, // margin header
        0); // margin footer
   
        $mpdf->WriteHTML($html,2);         
         //save in folder
        $mpdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");
        $mpdf->Output($pdfFilePath,'D');
            //    echo $html;

            }
        }
    }
}

function get_doc_details_purchase()
{
    $cbr_id=$this->input->post('main_id');
    $dataa=$this->Admin_model->get_data('purchase_invoice',array('pi_id'=>$cbr_id));
        if($dataa)
            {
            $currency_convt=$this->Admin_model->get_data('master_currency_conv',array('currency_name'=>$dataa[0]->pi_currency));
            $company_masters=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->pi_company));
            $purchase_accont=$this->Admin_model->get_data('master_accounts_tree',array('id'=>'484'));
            $place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->pi_place_of_supply));
            $jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->pi_jurisdiction));
            $customers=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->pi_vendor));

                $account_tx_data=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_type_tx'=>'Purchase'));
                if(!empty($account_tx_data))
                {
                    $account_bal_data_1=$this->Admin_model->get_data('account_tx_bal_data',array('actb_to_id'=>$account_tx_data[0]->atx_id));
                    if(!empty($account_bal_data_1))
                    {
                        foreach($account_bal_data_1 as $abd)
                        {
                            $tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_tx_id));
                        }
                    }
                    else
                    {
                        $account_bal_data_2=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_data[0]->atx_id));
                        if(!empty($account_bal_data_2))
                        {
                            foreach($account_bal_data_2 as $abd)
                            {
                                $tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_to_id));
                            }   
                        }
                    }
                }
                      
                $prd_list=explode('|#|',$dataa[0]->pi_product);
                foreach($prd_list as $pl)
                {
                    $data_pl[]=$this->tm->get_data('products',array('pid'=>$pl));
                }

                $desc=explode('|#|',$dataa[0]->pi_description);
                $unit=explode('|#|',$dataa[0]->pi_unit);
                $link=explode('|#|',$dataa[0]->pi_link_1);

                $qnty_list=explode('|#|',$dataa[0]->pi_qty);
                $rate_list=explode('|#|',$dataa[0]->pi_rate);
                $gross_list=explode('|#|',$dataa[0]->pi_gross);
                $disc_per_list=explode('|#|',$dataa[0]->pi_discount_percentage);
                $disc_amount_list=explode('|#|',$dataa[0]->pi_discount_amount);
                $add_charges_list=explode('|#|',$dataa[0]->pi_additional_charge);

                $reverse_charge=explode('|#|',$dataa[0]->pi_reverse_charge);
                $adjustment=explode('|#|',$dataa[0]->pi_adjustment);

                    $vat_list=explode('|#|',$dataa[0]->pi_vat);
                    $tax_list=explode('|#|',$dataa[0]->pi_tax_code);
                    
                    $html="<div class='row'>";
                    $html.="<div class='col-md-12'><h4>Purchase Invoice Data</h4>";

                    $html.="<div class='col-md-4'>";
                    $html.="<p>Doc no: ".$dataa[0]->pi_doc_no."</p>";
                    $html.="<p>User Created: ".$dataa[0]->pi_user_created."</p>";
                    $html.="<p>Date: ".$dataa[0]->pi_date."</p>";
                     $html.="<p>Due Date: ".$dataa[0]->pi_due_date."</p>";
                    $html.="<p>Currency: ".$dataa[0]->pi_currency."</p>";
                    $html.="<p>Currency Value: ".$dataa[0]->pi_conv_value."</p>";
                    $html.="</p>";

                    $html.="<p style='color:blue'><b>Linked to :</b></p>";
                    if(!empty($tx_data_related))
                    {
                        foreach($tx_data_related as $tx)
                        {
                            $html.="<p style='color:blue'>".$tx[0]->atx_doc_no."</p>";
                        }
                    }   
                    $html.="</div>";

                    $html.="<div class='col-md-4'>";
                
                    $html.="<p>Purchase Account: ".$purchase_accont[0]->label."</p>";
                    $html.="<p>Company: ".$company_masters[0]->mcomp_name."</p>";
                 
                    $html.="<p>Place of Supply: ".$place_supply[0]->mps_name."</p>";
                    $html.="<p>Jurisdiction: ".$jurisdaction[0]->mps_name."</p>";
                    $html.="<p>Narration: ".$dataa[0]->pi_narration."</p>";
                    
                $html.="</div>";

                    $html.="<div class='col-md-4'>";
                    $html.="<p>Customer : ".$customers[0]->label."</p>";
                  
                $html.="<p>Current Status: ".$dataa[0]->pi_current_sts."</p>";
                    $html.="<p>Attachements: <a href='".base_url('uploads/sales_invoice/'.$dataa[0]->pi_attachments)."' target='_blank'> ".$dataa[0]->pi_attachments."</a></p>";
                    $html.="</div>";
                    /*** end of col-md-12 and row ***/
                    $html.="</div>";
                    $html.="</div>";
                    /*** start of table  ***/
                        $html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
                    $html.="<thead><th></th>
                    <th>Product</th>
                     <th>Description</th> <th>Unit</th>
                        <th>Link</th>
                    <th>Quantity</th><th>Rate</th>
                    <th>Gross</th><th>Discount(%)</th>
                    <th>Discount Amount</th><th>Add.Charges</th>
                    <th>Reverse Charges</th><th>Adjustments</th>
                    
                    <th>Vat(%)</th>
                   <th>Tax Code</th></thead>";
                    $html.="<tbody>";
                    foreach($data_pl as $key=>$d)
                    {
                        $qnty_tot[]=$qnty_list[$key];
                        $rate_tot[]=$rate_list[$key];
                        $gross_tot[]=$gross_list[$key];
                        
                        $dis_amnt_tot[]=$disc_amount_list[$key];
                        $adchrg_tot[]=$add_charges_list[$key];
                        
                        $html.="<tr>";
                        $html.="<td></td>";
                       
                        $html.="<td>".$d[0]->pname."</td>";
                        $html.="<td>".$desc[$key]."</td>";
                        $html.="<td>".$unit[$key]."</td>";
                        $html.="<td>".$link[$key]."</td>";
                            
                        $html.="<td>".$qnty_list[$key]."</td>";
                        $html.="<td>".$rate_list[$key]."</td>";
                        $html.="<td>".$gross_list[$key]."</td>";

                        $html.="<td>".$gross_list[$key]*($disc_per_list[$key]/100);
                        $dis_per_tot[]=$gross_list[$key]*($disc_per_list[$key]/100);
                        $html.="</td>";
                        $disc_per_list[$key]."</td>";
                        $html.="<td>".$disc_amount_list[$key]."</td>";
                        $html.="<td>".$add_charges_list[$key]."</td>";

                        $html.="<td>".$reverse_charge[$key]."</td>";
                        $html.="<td>".$adjustment[$key]."</td>";

                        $tot_dis_per_amont = $gross_list[$key]*($disc_per_list[$key] / 100) ;  
                $total_gross_calc=$gross_list[$key]+$add_charges_list[$key]-$tot_dis_per_amont-$disc_amount_list[$key];      
                  
                    $org_amount=$total_gross_calc/(($vat_list[$key]+100)/100);
                    $fent_tot[]= $org_amount;
                    $vat_amount_calc=$org_amount*($vat_list[$key]/100) ;
                    $tot_fnet_vat=$total_gross_calc-$vat_amount_calc;
                      
                        $html.="<td>".$vat_list[$key];
                        $vat_amount_tot[]=number_format((float)$vat_amount_calc, 2, '.', '');

                        $html.="</td>";

                        $html.="<td>".$tax_list[$key]."</td>";
                    
                        $html.="</tr>";
                    }
                    $html.="</tbody>";
                    $html.="</table>";
                    $html.="<div class='row'>";
                    $html.="<div class='col-md-12'><div class='col-md-4'>";
                    $html.="<p>Total Quantity : ".array_sum($qnty_tot)."</p>";
                    $html.="<p>Total Rate  : ".array_sum($rate_tot)."</p>";
                    $html.="<p>Total Gross : ".array_sum($gross_tot)."</p>";
                    $html.="</div>";
                    $html.="<div class='col-md-4'>";
                    $html.="<p>Total Discount(%) : ".array_sum($dis_per_tot)."</p>";
                    $html.="<p>Total Discount Amount : ".array_sum($dis_amnt_tot)."</p>";
                    $html.="<p>Total Additional Charges : ".array_sum($adchrg_tot)."</p>";
                    $html.="</div>";
                    $html.="<div class='col-md-4'>";
                    $sum_fnet=array_sum($fent_tot);
                    $html.="<p>Total Fnet : ".number_format((float)$sum_fnet, 2, '.', '') ."</p>";
                    $sum_vat=array_sum($vat_amount_tot);
                    $html.="<p>Total VAT Amount : ".number_format((float)$sum_vat, 2, '.', '')."</p>";
                    $diff_fent_vat=array_sum($fent_tot)+array_sum($vat_amount_tot);
                    $html.="<p>Final Amount : ".number_format((float)$diff_fent_vat, 2, '.', '')."</p>";
                    $html.="</div>";$html.="</div>";
                    $html.="</div>";
                    /*** start of table  ***/
                    echo $html;
            }
}


function delete_pur($pur_id)
{
    if(logged_in())
    {
        $account_tx_id=$this->Admin_model->get_data('account_all_tx',array('atx_type_tx'=>"Purchase",'atx_main_id'=>$pur_id));
         $check_id_linked_to=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_id[0]->atx_id,'actd_sts'=>'1'));
        if(!empty($check_id_linked_to))////considering the account tx_id is attached someother account tx_id, so first delete the other one to delete this//
        {
           // echo "in if";
           // pre_list($check_id_linked_to);
            foreach($check_id_linked_to as $cil)
            {
                 $data['account_table_data'][]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$cil->actb_to_id));///getting data from account tx table for the 'transfer to' ////
            }
           // pre_list($data);
            /////go back to view page, show message to first delete the linked data before deleting this ///
            $this->load->view('admin/purchase/list_purchase_invoice',$data);
        }
        else
        {
          //  echo "in else";
              $check_id_linked_to=$this->Admin_model->get_data('account_tx_bal_data',array('actb_to_id'=>$account_tx_id[0]->atx_id,'actd_sts'=>'1'));/////taken this as a reference//////
            // pre_list($check_id_linked_to);
            if(!empty($check_id_linked_to))////considering the account tx_id is attached to someother account tx_id, so first delete the other one to delete this//
            {
                foreach($check_id_linked_to as $cil)
                {
                     $account_table_data=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$cil->actb_tx_id));
                     $paid_amount_to_ref=$cil->actb_paid_amount;

                     $current_paid_amount_of_ref=$account_table_data[0]->atx_paid_amount;
                     $current_bal_amount_of_ref=$account_table_data[0]->atx_bal_amount;

                     $new_amount_datas=array(
                        'atx_paid_amount'=>$current_paid_amount_of_ref-$paid_amount_to_ref,
                        'atx_bal_amount'=>$current_bal_amount_of_ref+$paid_amount_to_ref,
                     );
                     $this->Admin_model->update_data('account_all_tx',$new_amount_datas,array('atx_id'=>$cil->actb_tx_id));
                       $this->Admin_model->delete_data('account_tx_bal_data',array('actb_ib'=>$cil->actb_ib));//deleted
                }
                 $this->Admin_model->update_data('purchase_invoice',array('pi_sts'=>'0'),array('pi_id'=>$pur_id));///deleted
                 $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_type_tx'=>"Purchase",'atx_main_id'=>$pur_id,'atx_doc_no'=>$account_tx_id[0]->atx_doc_no));//deleted
                $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_type_tx'=>"Vat_IP",'atx_main_id'=>$pur_id,'atx_doc_no'=>$account_tx_id[0]->atx_doc_no));//deleted
            }
            else////else means this is a new_reference without any link attached to another account transaction, so this can be easily deleted
            {
               $this->Admin_model->update_data('purchase_invoice',array('pi_sts'=>'0'),array('pi_id'=>$pur_id));
                 $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_type_tx'=>"Purchase",'atx_main_id'=>$pur_id,'atx_doc_no'=>$account_tx_id[0]->atx_doc_no));//deleted
                $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_type_tx'=>"Vat_IP",'atx_main_id'=>$pur_id,'atx_doc_no'=>$account_tx_id[0]->atx_doc_no));//deleted
            }
            $this->session->set_flashdata('success', 'Data Successfully removed');
            redirect('list-purchase-invoice');
        }
       
    }
}

function delete_mrn($mrn_id)
{
    if(logged_in())
    {
        $account_tx_id=$this->Admin_model->get_data('account_all_tx',array('atx_type_tx'=>"MRN",'atx_main_id'=>$mrn_id,'atx_acc_id'=>'484'));
         $check_id_linked_to=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_id[0]->atx_id,'actd_sts'=>'1'));
        // echo $account_tx_id[0]->atx_id;
        if(!empty($check_id_linked_to))////considering the account tx_id is attached someother account tx_id, so first delete the other one to delete this//
        {
           // echo "in if";
           // pre_list($check_id_linked_to);
            foreach($check_id_linked_to as $cil)
            {
                 $data['account_table_data'][]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$cil->actb_to_id));///getting data from account tx table for the 'transfer to' ////
            }
           // pre_list($data);
            /////go back to view page, show message to first delete the linked data before deleting this ///
            $this->load->view('admin/purchase/list_purchase_mrn',$data);
        }
        else
        {
            //echo "in else";
              $check_id_linked_to=$this->Admin_model->get_data('account_tx_bal_data',array('actb_to_id'=>$account_tx_id[0]->atx_id,'actd_sts'=>'1'));/////taken this as a reference//////
            // pre_list($check_id_linked_to);
            if(!empty($check_id_linked_to))////considering the account tx_id is attached to someother account tx_id, so first delete the other one to delete this//
            {
               // echo "in if 2";echo "<br/>";
                foreach($check_id_linked_to as $cil)
                {
                     $account_table_data=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$cil->actb_tx_id));
                    // pre_list($account_table_data);
                     $paid_amount_to_ref=$cil->actb_paid_amount;
                     $current_paid_amount_of_ref=$account_table_data[0]->atx_paid_amount;
                     $current_bal_amount_of_ref=$account_table_data[0]->atx_bal_amount;

// echo $current_paid_amount_of_ref;
// echo "<br/>";
// echo $current_bal_amount_of_ref;
// echo "<br/>";
// echo $paid_amount_to_ref;
// echo "<br/>";
                     $new_amount_datas=array(
                        'atx_paid_amount'=>$current_paid_amount_of_ref-$paid_amount_to_ref,
                        'atx_bal_amount'=>$current_bal_amount_of_ref+$paid_amount_to_ref,
                     );
                    // pre_list( $new_amount_datas);
                     $this->Admin_model->update_data('account_all_tx',$new_amount_datas,array('atx_id'=>$cil->actb_tx_id));
                      $this->Admin_model->delete_data('account_tx_bal_data',array('actb_ib'=>$cil->actb_ib));//deleted
                }
                 $this->Admin_model->update_data('material_receipt_note',array('mrn_sts'=>'0'),array('mrn_id'=>$mrn_id));///deleted
                  $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_type_tx'=>"MRN",'atx_main_id'=>$mrn_id,'atx_doc_no'=>$account_tx_id[0]->atx_doc_no));//deleted
                $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_type_tx'=>"Vat_IP",'atx_main_id'=>$mrn_id,'atx_doc_no'=>$account_tx_id[0]->atx_doc_no));//deleted
            }
            else////else means this is a new_reference without any link attached to another account transaction, so this can be easily deleted
            {
               // echo "in else 2";
               $this->Admin_model->update_data('material_receipt_note',array('mrn_sts'=>'0'),array('mrn_id'=>$mrn_id));
                $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_type_tx'=>"MRN",'atx_main_id'=>$mrn_id,'atx_doc_no'=>$account_tx_id[0]->atx_doc_no));//deleted
                $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_type_tx'=>"Vat_IP",'atx_main_id'=>$mrn_id,'atx_doc_no'=>$account_tx_id[0]->atx_doc_no));//deleted
            }
            $this->session->set_flashdata('success', 'Data Successfully removed');
            redirect('list-purchase-mrn');
        }
       
    }
}



























































































































}