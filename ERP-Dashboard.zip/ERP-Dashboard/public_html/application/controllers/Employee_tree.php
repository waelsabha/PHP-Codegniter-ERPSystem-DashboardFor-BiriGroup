<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee_tree extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->model(array('Account_model'));
		$this->load->helper(array('session','gnrl','img','email','email_survey'));	


		$this->load->library('numbertowordconvertsconver');	
        $this->load->library('numbertowordconvertsconverksa');	
		$this->load->library('numbertoworduk');	
		require 'vendor/autoload.php';
		require_once 'vendor/khaled.alshamaa/ar-php/src/Arabic.php';	


	}

	public function create_employee_tree($emp_id='')
	{
		if(logged_in())
		{

          
          $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='employee-tree')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {


			$cond=array('status'=>'1');
			$data['country']=$this->Admin_model->get_data('country_val',$cond);	
			$data['branch_company']=$this->Admin_model->get_data('master_company',$mp_sts);	
			$data['login_emp']=$this->Admin_model->get_data('login_credentials',array('log_status'=>'1'));	
			if(!empty($emp_id))
			{
				$data['emp_details']=$this->Admin_model->get_data('tbl_emp_tree',array('et_id'=>$emp_id));
				$data['emp_id']=$emp_id;
			}
			$this->load->view('admin/hr/employee_tree',$data);

        }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  




		}
	}

	function list_emp_tree()
	{
		if(logged_in())
		{

            $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='list-employee-tree')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {
      
      for($k=0;$k<$cred_count;$k++)
	        {


	        	if ($page_cred[$k]=='list-employee-tree-dubai')
	         	{
		           $excistdubai=true;
		           
	               $k=$cred_count;
	         	}	
	         	else if ($page_cred[$k]=='list-employee-tree-Rak')
	         	{
		           $excistrak=true;
		           
	               $k=$cred_count;
	         	}	

	           else if($page_cred[$k]=='list-employee-tree-ksa')
                {
		           $excistksa=true;
		           $data['emp_details']=$this->Admin_model->get_data('tbl_emp_tree',array('et_sts'=>'1'));
	               $k=$cred_count;
	         	}	

	            
   
	        }

			if($excistrak==true)
			{
				$data['emp_details']=$this->Admin_model->get_data('tbl_emp_tree',array('et_sts'=>'1','et_branch'=>'8'));

			}
			else {
				$data['emp_details']=$this->Admin_model->get_data('tbl_emp_tree',array('et_sts'=>'1'));

			}





	//$data['emp_details']=$this->Admin_model->get_data('tbl_emp_tree',array('et_sts'=>'1'));
	 $this->load->view('admin/hr/list_emp_tree',$data);

	 }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}
	}
}


	function delete_employee_tree($emp_id)
	{
		$update_id=$this->Admin_model->update_data('tbl_emp_tree',array('et_sts'=>'0'),array('et_id'=>$emp_id));
		$this->session->set_flashdata('success', 'Employee deleted successfully');
	redirect('list-employee-tree','refresh');
	}

function download_emp_files($emp_id)
{
$this->load->helper(array('download'));
$this->load->library('zip');

$cond=array('et_id'=>$emp_id);
$data_result=$this->Admin_model->get_data('tbl_emp_tree',$cond);

$emp_info=explode('$#$',$data_result[0]->et_emp_info);
$emp_name=explode(':',$emp_info[0]);

$emp_file_info=explode('$#$',$data_result[0]->et_emp_files);
$emp_pic=explode(':',$emp_file_info[0]);
$job_offer=explode(':',$emp_file_info[1]);
$passport_copy=explode(':',$emp_file_info[2]);
$visa_copy=explode(':',$emp_file_info[3]);
$employemnt_letter=explode(':',$emp_file_info[4]);
$emirates_id=explode(':',$emp_file_info[5]);
$driving_licence=explode(':',$emp_file_info[6]);


$folder_name=strtolower(preg_replace('/\s+/', '_', $emp_name[1]));

$pic=explode(',',$emp_pic[1]);
$jol=explode(',',$job_offer[1]);
$emp_ltr=explode(',',$employemnt_letter[1]);
$visa_copy=explode(',',$visa_copy[1]);
$passport_copy=explode(',',$passport_copy[1]);
$emirates_id=explode(',',$emirates_id[1]);
$driving_license=explode(',',$driving_licence[1]);

$main_array = array_merge($pic,$jol,$emp_ltr,$visa_copy,$passport_copy,$emirates_id,$driving_license);
 
	foreach($main_array as $j)
	{
			$this->zip->read_file('./uploads/employee_data/'.$folder_name.'/'.$j);
	}	
	$this->zip->download(''.$folder_name.'.zip');
	}



function download_emp_custody($emp_id)
{











if(logged_in())
	{
		


         	
		
	

		$invoice_pdf_type=1;

		///for english - arabic number in words//////
 		$Arabic = new \ArPHP\I18N\Arabic();
 		 $Arabic->setNumberFeminine(1);
    	$Arabic->setNumberFormat(1);
    	///////end en-ar words/////////
 



// $ksaamazonen='0';
// if($invoice_pdf_type='3')
// {
// $ksaamazonen='1';
// }

		if(!empty($emp_id))
		{



							//to get the employee info
				     $cond=array('et_id'=>$emp_id);
					$data_emp=$this->Admin_model->get_data('tbl_emp_tree',$cond);

					//this to get the details for the custody list for the particular employee 
					$emp_id_cond=array('al_emp_custody'=>$emp_id);
					$data_custody=$this->Admin_model->get_data('assets_list',$emp_id_cond);

		

              $employee_id=$data_emp[0]->et_id;
			$employee_name=$data_emp[0]->et_name;
			$employee_alias=$data_emp[0]->et_emp_info;
            $emp_code=$data_emp[0]->et_code_branch;

             	$emp_info=explode('$#$',$employee_alias);
			$branch=explode(':',$emp_info[19]);
			$emp_name=explode(':',$emp_info[0]);
			$position=explode(':',$emp_info[8]);
			$comp_mobile=explode(':',$emp_info[23]);
			$comp_email=explode(':',$emp_info[24]);
	
                $Branch_number=$branch[1];
	$master_company_cond=array('mcomp_id'=>$Branch_number);
					$data_custody_company=$this->Admin_model->get_data('master_company',$master_company_cond);
			//   $employee_id=$data_emp[0]->et_id;
          $Branch_name=$data_custody_company[0]->mcomp_name;
		
$Branch_name_ar='';
switch($Branch_name)
{
	case 'UAE - Diera':
	$Branch_name_ar='الامارات-فرع الديرة';
	break;
	case 'UAE-BANIYAS BRANCH':
	$Branch_name_ar='الامارات-فرع بانياس';
	break;
	case 'UAE - Garhoud':
	$Branch_name_ar='الامارات-فرع القرهود';
	break;
	case 'KSA - Riyadh':
	$Branch_name_ar='السعودية-فرع الرياض';
	break;
	case 'KSA - Jeddah':
	$Branch_name_ar='السعودية-فرع جدة';
	break;
	case 'FACTORY':
	$Branch_name_ar='رأس الخيمة -المصنع';
	break;
	case 'Dubai Store':
	$Branch_name_ar='مستودع دبي';
	break;
	
}
				
// foreach($data_custody as $key5=>$dc)
// {

// 	$prd_table_data[]=$this->tm->get_data('products',array('pid'=>$pd));

	
// }




$stylesheet = file_get_contents('style_mpdf.css');
////////////////for qr code////////////////////////////
$this->load->library('ciqrcode');
//header("Content-Type: image/png");
$params['data'] = base_url('load_invoice_data/'.$emp_id);
$params['level'] = 'H';
$params['size'] = 10;
//$params['savename'] = './uploads/qr_code/'.$siv_data[0]->si_doc_no.'.png';
// $this->ciqrcode->generate($params);
//echo '<img src="'.base_url().'/uploads/inv_pdf/tes.png" />';
///////////qr code ends//////////////////////////////////////////

$html='<!doctype html>';
if($invoice_pdf_type!='1'||$invoice_pdf_type!='3')
{
$html.='<br/><br/><br/><br/>';
}

$html.='<head></head><body>';
if ($invoice_pdf_type == '1'||$invoice_pdf_type=='3') {
					$html .= '<div style="position: absolute; visibility: visible; left: 680; top: 120px; z-index: 200;"><img align="bottom"  src="' . base_url() . '/uploads/qr_code/' . $siv_data[0]->si_doc_no . '.png" width="70" height="70"/></div>';
				}
				else{
					$html .= '<div style="position: absolute; visibility: visible; left: 680; top: 230px; z-index: 200;"><img align="bottom"  src="' . base_url() . '/uploads/qr_code/' . $siv_data[0]->si_doc_no . '.png" width="70" height="70"/></div>';

				}
$html.='<div class="content" ><br/>';
	$head_all = '';
				$head_all.= '<table border="0" width="100%">';
		
				$head_all.= '<tr><td style="text-align:left;">';
				$head_all.= '<table border="0" width="100%" >';
				$head_all.= '<tbody>';

		
					$head_all.= '<tr>';
					$head_all.= '<td ></td>';
					$head_all.= '</tr><br/>';
				
			
				$head_all.= '<tr>';
				$head_all.= '<td ><b> Employee Custudy  </b></td><td><b>عهدة الموظف  </b></td>';
				
				$head_all.= '</tr>';
				
                 $head_all.= '<tr>';	$head_all.= '</tr>';
				//$head_all.= '<tr>';

					$head_all.= '<tr>';
					$head_all.= '<td>Employee ID. : ' .$employee_id. ' </td><td>' .$employee_id. '  :الرقم الوظيفي </td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Employee Name : ' . $employee_name . '</td><td>' . $employee_name . '  : اسم الموظف</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Position  :' . $position[1]. ' </td><td>' . $position[1]. ' : المنصب الوظيفي</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Branch :' . $Branch_name . '</td><td>   الفرع : ' . $Branch_name_ar . '</td>';
					$head_all.= '</tr>';
			
			
				$head_all.= '</tbody>';
				$head_all.= '</table>';
				$head_all.= '</td>';

				$head_all.= '<td style="text-align:right;">';
				$head_all.= '<table border="0" width="100%" >';
				$head_all.= '<tbody>';
				$head_all.= '<tr>';
			
				
				
					//$head_all.= '<td align="right"><b align="right"> Commerical invoice </b></td>';
			
				$head_all.= '<td align="right"><b align="right">' . $subject_name . '</b></td>';
				
				$head_all.= '</tr>';
		
					$head_all.= '<tr>';
					$head_all.= '<td align="right"><b align="right"></b></td>';
					$head_all.= '</tr><br/><br/>';
			
				
				
			
				
			
				
				


				$head_all.= '</tbody>';
				$head_all.= '</table>';
				$head_all.= '</td>';
				$head_all.= '</tr>';

				$head_all.= '</table>';
				$head_all.= '</div>';
$html.='</div>';

$html.='<div class="content">
<table  align="center"  width="100%">';
$html.='<tbody>';


	$html.='<tr >';
$html.='<td align="center" class="prd_info_2">Item Name<br/>اسم العنصر</td>';
$html.='<td align="center" class="prd_info_2">Model<br/>الموديل</td>';
$html.='<td align="center" class="prd_info_2">Main Category<br/>الصنف الرئيسي</td>';
$html.='<td align="center" class="prd_info_2">Serial Number<br/>الرقم التسلسلي</td>';
$html.='<td align="center" class="prd_info_2">condition<br/>الحالة الفنية</td>';
$html.='<td align="center" class="prd_info_2">custody date<br/>تاريخ العهدة</td>'; 			
$html.='</tr>';

$i=1;
$total_sum_prd='';
$total_vat_sum_prd='';
$total_discount_sum_prd='';




		foreach($data_custody as $key5=>$dc)
				{

				//when there is so many rows of custody then foreach row you must put the next 
				//this to get the name of the item like mobile or laptop
					$item_id[$key5]=$dc->al_name_of_asset;
						$asset_name[$key5]=array('item_id'=>$item_id[$key5]);
						$data_asset_name[$key5]=$this->Admin_model->get_data('items_assets',$asset_name[$key5]);

						//this to get the catgeory of the item like computer and it staff
						$item_type_id[$key5]=$dc->al_asset_type;
						$asset_type[$key5]=array('id'=>$item_type_id[$key5]);
						$data_asset_category[$key5]=$this->Admin_model->get_data('master_accounts_tree',$asset_type[$key5]);
			
	

                       switch($dc->al_condition_asset) 
					  { case 0:
					   $Asset_con='New';
					   break;
					   case 1:
					   $Asset_con='excellent';
					   break;
					   case 2:
					   $Asset_con='used but good';
					   break;
					   case 3:
					   $Asset_con='Low Quality';
					   break;
					   case 4:
					   $Asset_con='Old';
					   break;
					   default:
					    $Asset_con='Unknown';
						break;
                      break;

					     }  

						if($key5 % 10 == 0 && $key5 != 0){
									

						$html .= '<table align="center"  width="100%">';
						$html .= '<tbody>';
						
						
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr >';
							$html .= '<td align="center" class="prd_info_2">Item Name</td>';
							$html .= '<td align="center" class="prd_info_2">Model </td>';
							$html .= '<td align="center" class="prd_info_2">Main Category</td>';
							$html .= '<td align="center" class="prd_info_2">Serial Number  </td>';
							$html .= '<td align="center" class="prd_info_2">condition</td>';
							$html .= '<td align="center" class="prd_info_2">custody date</td>';

						}
	
					
$html.='<tr>';

$html.='<td align="center" width="15%">'.$data_asset_name[$key5][0]->item_name.'</td>';
$html .= '<td align="center" width="15%">'.$dc->al_description.'</td>';
$html.='<td align="center" width="29%">'.$data_asset_category[$key5][0]->label.'</td>';

$html.='<td align="center" width="7%">'.$dc->al_serial_number.'</td>';
$html.='<td align="center" width="11%">'. $Asset_con.'</td>';
$html.='<td align="center" width="11%">'.$dc->al_update_custody_date.'</td>';
$html.='</tr>';

					if($key5 % 9 == 0 && $key5 != 0)
					{
						
						$html .= '</tbody>';
						$html .= '</table>';
						
						$html .= "<pagebreak />";
					}
					}

// print_r($html);exit();

$html.='</tbody>';
$html.='</table>';
$html.='</div>';



$html.='<div class="content_2">';
//$html.='<img align="bottom"  src="'.base_url().'/uploads/qr_code/'.$siv_data[0]->si_doc_no.'.png" width="100" height="100"/>';

$html.='<table class="prd_info_2" align="right" width="100%">';
$html.='<tr>';
 

		 $html.='<td align="right" text-align="right">Please check from Your Custody That Match What Mention Above before signature</td>';
         $html.='</tr>';
	
    $html.='<tr>';
 

		 $html.='<td align="right" text-align="right">الرجاء التحقق من أن بنود العهدة مطابقة لما تم استلامه قبل التوقيع</td>';
         $html.='</tr>';

	 
  
$html.='</tr>';

$html.='</table>';
//print_r($html);exit();

$html.='<table width="100%">';
$html.='<tr>';

$html.='<td>';
$html.='<table width="70%">';
$html.='<tbody>';




$html.='<tr>';
$html.='<td>Receiver`s Signature:<br/> توقيع المستلم</td>';
$html.='<td></td>';
$html.='<td>Authorised By:<br/> مصدقة من قسم </td>';

$html.='</tr>';




	
	$html.='<tr>';
$html.='<td></td>';
$html.='<td></td>';
$html.='<td style="margin-bottom:100px;">HR Dept.<br/>الموارد البشرية</td>';

$html.='</tr>';




$html.='</tbody>';
$html.='</table>';
$html.='</td>';

$html.='<td>';
$html.='<table width="80%">';
$html.='<tbody>';





$html.='</tbody>';
$html.='</table>';
$html.='</td>';

$html.='</tr>';




$html.='</table ><br/><br/>';

$html.='</div>';


$html.='</body>';
$html.='</html>';

//echo $html;
$pdfFilePath = emp_id.'.pdf';

	 $mpdf = new \Mpdf\Mpdf();
	 $mpdf->autoScriptToLang = true;
	$mpdf->autoLangToFont = true;
    $mpdf->autoArabic=true;
	$mpdf->defaultfooterline = 0;

 	$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$siv_data[0]->si_company));
if($invoice_pdf_type=='1'||$invoice_pdf_type=='3')
{


// if($page_type=="UK"||$page_type=="ukamazon")
// {
		
//   $mpdf->SetHeader('<img src="'.base_url("UK Header2.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("UK footer2.png").'">');

// }
// elseif($page_type=="UAEAmazon")
// {
//     $mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');

// }

// elseif ( strpos($company_details[0]->mcomp_name, 'UAE ') !== false) {

 	$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');
// }
// elseif ( strpos($company_details[0]->mcomp_name, 'UAE') !== false) {

//  	$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');
// }
// elseif(strpos($company_details[0]->mcomp_name, 'Dubai ') !== false)
// {
//  $mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');

// }
// elseif(strpos($company_details[0]->mcomp_name, 'FACTORY') !== false)
// {
//  	$mpdf->SetHeader('<img src="'.base_url("biri_industries_header.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("biri_industries_footer.png").'">');
// }
// elseif($page_type=="ksa"||$page_type=="KSAamazon")
// {
//  $mpdf->SetHeader('<img src="'.base_url("ksa-header-new.png").'">'.$head_all);
// $mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("ksa-footer-new.png").'">');

// }
// else
// {}

}
else
{
	$mpdf->SetHeader($head_all);
	$mpdf->SetFooter('<div style="margin-bottom:100px;">Page {PAGENO} of {nb}</div>');
}
//echo $html;
//print_r($fnet_details);
		 $mpdf->WriteHTML($stylesheet,1);
		 if ($invoice_pdf_type == '1'||$invoice_pdf_type == '3') {
					$mpdf->AddPage(
						'', // L - landscape, P - portrait 
						'',
						'',
						'',
						'',
						0, // margin_left
						0, // margin right
						97, // margin top
						20, // margin bottom
						0, // margin header
						0
					); // margin footer
				}
				else{
					$mpdf->AddPage(
						'', // L - landscape, P - portrait 
						'',
						'',
						'',
						'',
						5, // margin_left
						5, // margin right
						97, // margin top
						20, // margin bottom
						60, // margin header
						30
					); // margin footer
				}
   
	     $mpdf->WriteHTML($html,2);	     
	     //save in folder

		$mpdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");
  		$mpdf->Output($pdfFilePath,'D');
				

  		}
	}



}





function submit_emp_tree()
{
	$edit_emp_id=$this->input->post('emp_id_edit');
	$emp_name=$this->input->post('emp_name');
	$emp_name_separate=$this->input->post('emp_name');

$folder_name=strtolower(preg_replace('/\s+/', '_', $emp_name));

		$targetfolder='./uploads/employee_data/'.$folder_name;
		if (!is_dir($targetfolder)) 
            {
            	mkdir('./'.$targetfolder, 0777, TRUE);
			}

		if (isset($_FILES['emp_pic']['name']) && $_FILES['emp_pic']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'emp_pic',
				'upload_path'=>$targetfolder,
			);
			$emp_pic_names=img_upload($img_array1);
			if(!empty($emp_pic_names[0][0]['file_name']))
			{
				foreach($emp_pic_names[0] as $k1)
				{
					$pp_aray[]=$k1['file_name'];
					$value_emp_pic_aray=implode(',',$pp_aray);
				}
			}
			else
			{
				if(!empty($this->input->post('edit_picture')))
					$value_emp_pic_aray=$this->input->post('edit_picture');
					else
				$value_emp_pic_aray='';
			}	
		}

		if (isset($_FILES['jol']['name']) && $_FILES['jol']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'jol',
				'upload_path'=>$targetfolder,
			);
			$job_offer=img_upload($img_array1);
			if(!empty($job_offer[0][0]['file_name']))
			{
				foreach($job_offer[0] as $k2)
				{
					$jo_aray[]=$k2['file_name'];
					$value_jol_aray=implode(',',$jo_aray);
				}
			}
			else
			{
				if(!empty($this->input->post('edit_job_offer')))
					$value_jol_aray=$this->input->post('edit_job_offer');
					else
				$value_jol_aray='';
			}
		}

		if (isset($_FILES['emp_ltr']['name']) && $_FILES['emp_ltr']['name'] != "") 	
		{
			$img_array1=array(
			'img_name'=>'emp_ltr',
				'upload_path'=>$targetfolder,
			);
			$emply_ltr=img_upload($img_array1);
			if(!empty($emply_ltr[0][0]['file_name']))
			{
				foreach($emply_ltr[0] as $k3)
				{
					$el_aray[]=$k3['file_name'];
					$value_emp_contract_aray=implode(',',$el_aray);
				}
			}
			else
			{
				if(!empty($this->input->post('edit_emplymnt_contract')))
					$value_emp_contract_aray=$this->input->post('edit_emplymnt_contract');
					else
				$value_emp_contract_aray='';
			}
		}

		
		if (isset($_FILES['visa_copy']['name']) && $_FILES['visa_copy']['name'] != "") 		
		{
			$img_array1=array(
				'img_name'=>'visa_copy',
				'upload_path'=>$targetfolder,
			);
			$visa=img_upload($img_array1);
			if(!empty($visa[0][0]['file_name']))
			{
				foreach($visa[0] as $k4)
				{
					$vsa_aray[]=$k4['file_name'];
					$value_visa_aray=implode(',',$vsa_aray);
				}
			}
			else
			{
				if(!empty($this->input->post('edit_visa')))
					$value_visa_aray=$this->input->post('edit_visa');
					else
				$value_visa_aray='';
			}
		}

		
		if (isset($_FILES['psprt']['name']) && $_FILES['psprt']['name'] != "") 	
		{
			$img_array1=array(
			'img_name'=>'psprt',
				'upload_path'=>$targetfolder,
			);
			$passprt=img_upload($img_array1);
			if(!empty($passprt[0][0]['file_name']))
			{
				foreach($passprt[0] as $k5)
				{
					$psport_aray[]=$k5['file_name'];
					$val_psport_aray=implode(',',$psport_aray);
				}
			}
			else
			{
				if(!empty($this->input->post('edit_passport')))
					$val_psport_aray=$this->input->post('edit_passport');
					else
				$val_psport_aray='';
			}
		}

		if (isset($_FILES['emirts_copy']['name']) && $_FILES['emirts_copy']['name'] != "") 
		{
			$img_array1=array(
			'img_name'=>'emirts_copy',
				'upload_path'=>$targetfolder,
			);
			$emirates_copy=img_upload($img_array1);
			if(!empty($emirates_copy[0][0]['file_name']))
			{
				foreach($emirates_copy[0] as $k6)
				{
					$ec_aray[]=$k6['file_name'];
					$val_emrt_id_aray=implode(',',$ec_aray);
				}
			}
			else
			{
				if(!empty($this->input->post('edit_emirtaes_id')))
					$val_emrt_id_aray=$this->input->post('edit_emirtaes_id');
					else
				$val_emrt_id_aray='';
			}
		} 

		if (isset($_FILES['driving_licence']['name']) && $_FILES['driving_licence']['name'] != "") 
		{
			$img_array1=array(
			'img_name'=>'driving_licence',
				'upload_path'=>$targetfolder,
			);
			$dvl_copy=img_upload($img_array1);
			if(!empty($dvl_copy[0][0]['file_name']))
			{
				foreach($dvl_copy[0] as $k7)
				{
					$driving_lice_aray[]=$k7['file_name'];
					$val_driving_lice_aray=implode(',',$driving_lice_aray);
				}
			}
			else
			{
				if(!empty($this->input->post('edit_driving_lic')))
					$val_driving_lice_aray=$this->input->post('edit_driving_lic');
					else
				$val_driving_lice_aray='';
			}
		} 

	$et_emp_info=array(
		'emp_name'=>$this->input->post('emp_name'),
		'alias'=>$this->input->post('alias'),
		'code'=>$this->input->post('emp_code'),
		'basic_salary'=>$this->input->post('basic_salary'),
		'currency'=>$this->input->post('currency'),
		'doj'=>$this->input->post('doj'),
		'next_appraisal_date'=>$this->input->post('next_appraisal_date'),
		'holiday1'=>$this->input->post('holiday1'),
		'designation'=>$this->input->post('designation'),
		'half_day'=>$this->input->post('half_day'),
		'holiday2'=>$this->input->post('holiday2'),
		'salary_acc'=>$this->input->post('salary_acc'),
		'payable_account'=>$this->input->post('payable_account'),
		'dor'=>$this->input->post('dor'),
		'date_applicable'=>$this->input->post('date_applicable'),
		'emp_sts'=>$this->input->post('emp_sts'),
		'resg_date'=>$this->input->post('resg_date'),
		'bank_name'=>$this->input->post('bank_name'),
		'bank_branch_name'=>$this->input->post('bank_branch_name'),
		'branch'=>$this->input->post('branch'),
		'acc_name'=>$this->input->post('acc_name'),
		'vdo'=>$this->input->post('vdo'),
		'resign_payment_type'=>$this->input->post('resign_payment_type'),
       'company_mobile_no'=>$this->input->post('company_mobile_number'),
        'company_email'=>$this->input->post('company_email'),
	);

	$et_emp_uploaded_files=array(
		'pic_name'=>$value_emp_pic_aray,
		'job_offer_letter'=>$value_jol_aray,
		'passport_copy'=>$val_psport_aray,
		'visa_copy'=>$value_visa_aray,
		'employee_contract'=>$value_emp_contract_aray,
		'emirates_id_copy'=>$val_emrt_id_aray,
		'driving_license_copy'=>$val_driving_lice_aray,
	);
//print_r($this->input->post('name[0]'));
if(!empty($this->input->post('name[0]')))
{
$education_name_array=implode('##',$this->input->post('name[]'));
}
else
{
	$education_name_array='';
}

	if(!empty($this->input->post('yop[0]')))
	$year_of_passing=implode('##',$this->input->post('yop[]'));
else
	$year_of_passing='';

if(!empty($this->input->post('specialization[0]')))
	$specilization_in=implode('##',$this->input->post('specialization[]'));
else
	$specilization_in='';

if(!empty($this->input->post('college_university[0]')))
	$college_university=implode('##',$this->input->post('college_university[]'));
else
	$college_university='';


	$et_personal_info=array(
		'gender'=>$this->input->post('gender'),
		'nationality'=>$this->input->post('nationality'),
		'insurance_currency'=>$this->input->post('insurance_currency'),
		'blood_grp'=>$this->input->post('blood_grp'),
		'marital_status'=>$this->input->post('marital_status'),
		'dom'=>$this->input->post('dom'),
		'spouse_emp_type'=>$this->input->post('spouse_emp_type'),
		'spouse_name'=>$this->input->post('spouse_name'),
		'cont_adrs'=>$this->input->post('cont_adrs'),
		'cont_city'=>$this->input->post('cont_city'),
		'cont_pin'=>$this->input->post('cont_pin'),
		'cont_phone'=>$this->input->post('cont_phone'),
		'cont_mobile'=>$this->input->post('cont_mobile'),
		'cont_email'=>$this->input->post('cont_email'),
		'cont_fax'=>$this->input->post('cont_fax'),
		'permnt_adrs'=>$this->input->post('permnt_adrs'),
		'permnt_city'=>$this->input->post('permnt_city'),
		'permnt_country'=>$this->input->post('permnt_country'),
		'permnt_pin'=>$this->input->post('permnt_pin'),
		'permnt_phone'=>$this->input->post('permnt_phone'),
		'permnt_fax'=>$this->input->post('permnt_fax'),
		'sec_username'=>$this->input->post('sec_username'),
		'sec_password'=>$this->input->post('sec_password'),
		'pr_ic_no'=>$this->input->post('pr_ic_no'),
		'pr_issue_date'=>$this->input->post('pr_issue_date'),
		'pr_expiry'=>$this->input->post('pr_expiry'),
		'last_air_ticket'=>$this->input->post('last_air_ticket'),
		'airticket_entitlment_period'=>$this->input->post('airticket_entitlment_period'),
		'passport_no'=>$this->input->post('passport_no'),
		'passport_issue_date'=>$this->input->post('passport_issue_date'),
		'passport_issue_place'=>$this->input->post('passport_issue_place'),
		'passport_expiry'=>$this->input->post('passport_expiry'),
		'visa_no'=>$this->input->post('visa_no'),
		'visa_type'=>$this->input->post('visa_type'),
		'visa_strt_date'=>$this->input->post('visa_strt_date'),
		'visa_expiry_date'=>$this->input->post('visa_expiry_date'),
		'visa_issue_place'=>$this->input->post('visa_issue_place'),
		'visa_company'=>$this->input->post('visa_company'),
		'visa_proof'=>$this->input->post('visa_proof'),
		'driving_lic'=>$this->input->post('driving_lic'),
		'driving_issue_date'=>$this->input->post('driving_issue_date'),
		'driving_lic_exp'=>$this->input->post('driving_lic_exp'),
		'prob_period'=>$this->input->post('prob_period'),
		'confirmation_date'=>$this->input->post('confirmation_date'),
		'temp_emp'=>$this->input->post('temp_emp'),
		'contract_expiry'=>$this->input->post('contract_expiry'),
		'contract_type'=>$this->input->post('contract_type'),
		'health_card'=>$this->input->post('health_card'),
		'issue_date_health_card'=>$this->input->post('issue_date_health_card'),
		'expiry_date_health_card'=>$this->input->post('expiry_date_health_card'),
		'name'=>$education_name_array,
		'yop'=>$year_of_passing,
		'specialization'=>$specilization_in,
		'college_university'=>$college_university,		
		'insurance_type'=>$this->input->post('insurance_type'),
	);

	$et_leave_details=array(
		'offshore_basic'=>$this->input->post('offshore_basic'),
		'offshore_currency'=>$this->input->post('offshore_currency'),
		'vacation_calc_date'=>$this->input->post('vacation_calc_date'),
		'gratuity_calc_date'=>$this->input->post('gratuity_calc_date'),
		'amount'=>$this->input->post('amount'),
		'air_ticket_self'=>$this->input->post('air_ticket_self'),
		'air_ticket_dependant'=>$this->input->post('air_ticket_dependant'),
		'per_days_worked'=>$this->input->post('per_days_worked'),
		'air_ticket_off_shore'=>$this->input->post('air_ticket_off_shore'),
		'per_days_work_off_shore'=>$this->input->post('per_days_work_off_shore'),
		'leaves'=>$this->input->post('leaves'),
		'per_days_worked'=>$this->input->post('per_days_worked'),
		'travel_days'=>$this->input->post('travel_days'),
		'leaves_off_shore'=>$this->input->post('leaves_off_shore'),
		'per_days_worked_off_shore'=>$this->input->post('per_days_worked_off_shore'),
		'total_days_worked_bf'=>$this->input->post('total_days_worked_bf'),
		'total_days_worked_bf_off_shore'=>$this->input->post('total_days_worked_bf_off_shore'),
		'leave_bf'=>$this->input->post('leave_bf'),
		'paid_days_bf'=>$this->input->post('paid_days_bf'),
		'leaves_bf'=>$this->input->post('leaves_bf'),
		'air_ticket_bf_self'=>$this->input->post('air_ticket_bf_self'),
		'air_ticket_bf_dependant'=>$this->input->post('air_ticket_bf_dependant'),
		'total_lop'=>$this->input->post('total_lop'),
		'last_vacation_date'=>$this->input->post('last_vacation_date'),
	);

	$et_earnings=array(
		'hra_value'=>$this->input->post('hra_value'),
		'hra_account'=>$this->input->post('hra_account'),
		'oa_value'=>$this->input->post('oa_value'),
		'oa_account'=>$this->input->post('oa_account'),
		'fa_value'=>$this->input->post('fa_value'),
		'fa_account'=>$this->input->post('fa_account'),
		'transp_value'=>$this->input->post('transp_value'),
		'transp_account'=>$this->input->post('transp_account'),
		'incentive_value'=>$this->input->post('incentive_value'),
		'incentive_account'=>$this->input->post('incentive_account'),
		'allowance_value'=>$this->input->post('allowance_value'),
		'allowance_account'=>$this->input->post('allowance_account'),
		'veh_allowance_value'=>$this->input->post('veh_allowance_value'),
		'veh_allowance_account'=>$this->input->post('veh_allowance_account'),
		'food_allowance_value'=>$this->input->post('food_allowance_value'),
		'food_allowance_account'=>$this->input->post('food_allowance_account'),
		'fixed_ot_value'=>$this->input->post('fixed_ot_value'),
		'fixed_ot_account'=>$this->input->post('fixed_ot_account'),
	);

	// $et_deductions=array(
	// 	'fines_value'=>$this->input->post('fines_value'),
	// 	'fines_account'=>$this->input->post('fines_account'),
	// 	'other_deduction_value'=>$this->input->post('other_deduction_value'),
	// 	'other_deduction_account'=>$this->input->post('other_deduction_account'),
	// 	);

	// $et_loan=array(
	// 	'loan_adv'=>$this->input->post('loan_adv'),
	// 	'loan_car_loan'=>$this->input->post('loan_car_loan'),
	// );

	foreach($et_emp_info as $key=>$eei)
	{
		if(!empty($eei))
		$final_emp_info[]=$key.':'.$eei;
	else
			$final_emp_info[]=$key.':'.'';
	}

	foreach($et_personal_info as $key=>$epi)
	{
		if(!empty($epi))
		$final_emp_personal_info[]=$key.':'.$epi;
	else
			$final_emp_personal_info[]=$key.':'.'';
	}

	foreach($et_leave_details as $key=>$el)
	{
		if(!empty($el))
		$final_leave_info[]=$key.':'.$el;
	else
			$final_leave_info[]=$key.':'.'';
	}

	foreach($et_earnings as $key=>$er)
	{
		if(!empty($er))
		$final_earning_info[]=$key.':'.$er;
	else
			$final_earning_info[]=$key.':'.'';
	}

	// foreach($et_deductions as $key=>$ed)
	// {
	// 	if(!empty($ed))
	// 	$final_deduction_info[]=$key.':'.$ed;
	// else
	// 	$final_deduction_info[]=$key.':'.'';
	// }

	// foreach($et_loan as $key=>$eloan)
	// {
	// 	if(!empty($eloan))
	// 	$final_loan_info[]=$key.':'.$eloan;
	// else
	// 	$final_loan_info[]=$key.':'.'';
	// }

	foreach($et_emp_uploaded_files as $key=>$efiles)
	{
		if(!empty($efiles))
		$final_emp_files[]=$key.':'.$efiles;
	else
		$final_emp_files[]=$key.':'.'';
	}
	
$data=array(
	'ed_login_id'=>$this->input->post('login_username'),
'et_emp_info'=>implode('$#$',$final_emp_info),
'et_personal_info'=>implode('$#$', $final_emp_personal_info),
'et_leave_details'=>implode('$#$',$final_leave_info),
'et_earnings'=>implode('$#$', $final_earning_info),
'et_code_branch'=>$this->input->post('emp_code'),
'et_evaluation'=>$this->input->post('evaluation_emp'),
'et_branch'=>$this->input->post('branch'),
'et_sts'=>'1',
'et_name'=>$emp_name_separate,
'et_user_session'=>$this->session->userdata['user']['username'], 
'et_emp_files'=>implode('$#$',$final_emp_files),
);
if(!empty($edit_emp_id))
$update_id=$this->Admin_model->update_data('tbl_emp_tree',$data,array('et_id'=>$edit_emp_id));
else
$insert_data_id=$this->Admin_model->insert_data('tbl_emp_tree',$data);
//print_r($insert_data_id);

if($insert_data_id)
{
	$this->session->set_flashdata('success', 'Employee created successfully');
	redirect('list-employee-tree','refresh');
}
elseif(!empty($edit_emp_id))
{
$this->session->set_flashdata('success', 'Employee details updated successfully');
redirect('list-employee-tree','refresh');
}
else
{
	$this->session->set_flashdata('errors', 'Failed to create Employee data. Please try again later. ');
		redirect('employee-tree','refresh');
}
}


function ajax_load_view()
{
	$emp_id=$this->input->post('emp_id');
	$emp_details=$this->Admin_model->get_data('tbl_emp_tree',array('et_id'=>$emp_id));
	$html='<div class="tabs">';
$html.='<ul class="nav nav-tabs nav-justified">
<li class="active">
<a href="#tab1" data-toggle="tab" class="text-center"><i class="fa fa-star"></i> Employee Information </a>
</li>
<li>
<a href="#tab2" data-toggle="tab" class="text-center">Personal Information</a>
</li>
<li>
<a href="#tab3" data-toggle="tab" class="text-center">Leave Details</a>
</li>
<li>
<a href="#tab4" data-toggle="tab" class="text-center">Earnings</a>
</li>
<li>
<a href="#tab5" data-toggle="tab" class="text-center">Files Upload</a>
</li>

</ul>';
$html.='<div class="tab-content">';
$html.='<div id="tab1" class="tab-pane active">
<h4>Basic Details</h4>';
$emp_info=explode('$#$',$emp_details[0]->et_emp_info);

	$emp_name=explode(':',$emp_info[0]);
	$alias=explode(':',$emp_info[1]);
		$code=explode(':',$emp_info[2]);
		$basic_salary=explode(':',$emp_info[3]);
		$currency=explode(':',$emp_info[4]);
		$doj=explode(':',$emp_info[5]);
		$next_appraisal_date=explode(':',$emp_info[6]);
		$holiday1=explode(':',$emp_info[7]);
		$designation=explode(':',$emp_info[8]);
		$half_day=explode(':',$emp_info[9]);
		$holiday2=explode(':',$emp_info[10]);
		$salary_acc=explode(':',$emp_info[11]);
		$payable_account=explode(':',$emp_info[12]);
		$dor=explode(':',$emp_info[13]);
		$date_applicable=explode(':',$emp_info[14]);
		$emp_sts=explode(':',$emp_info[15]);
		$resg_date=explode(':',$emp_info[16]);
		$bank_name=explode(':',$emp_info[17]);
		$bank_branch_name=explode(':',$emp_info[18]);
		$branch=explode(':',$emp_info[19]);
		$acc_name=explode(':',$emp_info[20]);
		$vdo=explode(':',$emp_info[21]);
		$resign_payment_type=explode(':',$emp_info[22]);
		$company_mobile_no=explode(':',$emp_info[23]);
		$company_email=explode(':',$emp_info[24]);

$html.='<p>Employee Name: '.$emp_name[1].'</p>';
$html.='<p>Employee Alias: '.$alias[1].'</p>';
$html.='<p>Employee Code: '.$code[1].'</p>';
$html.='<p>Basic Salary: '.$basic_salary[1].'</p>';
$html.='<p>Salary Currency : '.$currency[1].'</p>';
$html.='<p>Date of Joining: '.$doj[1].'</p>';
$html.='<p>Next Appraisal Date : '.$next_appraisal_date[1].'</p>';
$html.='<p>Holiday 1: '.$holiday1[1].'</p>';
$html.='<p>Designation : '.$designation[1].'</p>';
$html.='<p>Half Day : '.$half_day[1].'</p>';
$html.='<p>Holiday 2: '.$holiday2[1].'</p>';
$html.='<p>Salary A/c: '.$salary_acc[1].'</p>';
$html.='<p>Payable A/c: '.$payable_account[1].'</p>';
$html.='<p>Date of Revision: '.$dor[1].'</p>';
$html.='<p>Date Applicable: '.$date_applicable[1].'</p>';
$html.='<p>Employee Status: '.$emp_sts[1].'</p>';

$html.='<p>Resignation Date: '.$resg_date[1].'</p>';
$html.='<p>Bank Name: '.$bank_name[1].'</p>';
$html.='<p>Bank Branch Name: '.$bank_branch_name[1].'</p>';
$html.='<p>Account Name: '.$acc_name[1].'</p>';
$branch_name='';
switch($branch[1])
{
	case 1:
	$branch_name="Garhoud-HO";
	break;

	case 2:
	$branch_name="Baniyas Shop";
	break;

	case 3:
	$branch_name="Deira Shop";
	break;

	case 4:
	$branch_name="Ras Al khoor Store";
	break;

	case 5:
	$branch_name="Dragon Shop";
	break;

	case 6:
	$branch_name="RAK Factory";
	break;
}
$html.='<p>Working Branch Name: '.$branch_name.'</p>';
$html.='<p>Vacation Due on: '.$vdo[1].'</p>';
$html.='<p>Resignation Payment Type: '.$resign_payment_type[1].'</p>';

$html.='<p>Company Mail: '.$company_email[1].'</p>';
$html.='<p>Company Mobile: '.$company_mobile_no[1].'</p>';

$html.='</div>';

$html.='<div id="tab2" class="tab-pane">
<h4>Personal Details</h4>';
$personal_info=explode('$#$',$emp_details[0]->et_personal_info);
$gender=explode(':',$personal_info[0]);
    $nationality=explode(':',$personal_info[1]);
        $insurance_currency=explode(':',$personal_info[2]);
        $blood_grp=explode(':',$personal_info[3]);
        $marital_status=explode(':',$personal_info[4]);
        $dom=explode(':',$personal_info[5]);
        $spouse_emp_type=explode(':',$personal_info[6]);
        $spouse_name=explode(':',$personal_info[7]);
        $cont_adrs=explode(':',$personal_info[8]);
        $cont_city=explode(':',$personal_info[9]);
        $cont_pin=explode(':',$personal_info[10]);
        $cont_phone=explode(':',$personal_info[11]);
        $cont_mobile=explode(':',$personal_info[12]);
        $cont_email=explode(':',$personal_info[13]);
        $cont_fax=explode(':',$personal_info[14]);
        $permnt_adrs=explode(':',$personal_info[15]);
        $permnt_city=explode(':',$personal_info[16]);
        $permnt_country=explode(':',$personal_info[17]);
        $permnt_pin=explode(':',$personal_info[18]);
        $permnt_phone=explode(':',$personal_info[19]);
        $permnt_fax=explode(':',$personal_info[20]);
        $sec_username=explode(':',$personal_info[21]);
        $sec_password=explode(':',$personal_info[22]);
        $pr_ic_no=explode(':',$personal_info[23]);
        $pr_issue_date=explode(':',$personal_info[24]);

        $pr_expiry=explode(':',$personal_info[25]);
         $last_air_ticket=explode(':',$personal_info[26]);
          $airticket_entitlment_period=explode(':',$personal_info[27]);
           $passport_no=explode(':',$personal_info[28]);
            $passport_issue_date=explode(':',$personal_info[29]);
             $passport_issue_place=explode(':',$personal_info[30]);
              $passport_expiry=explode(':',$personal_info[31]);
               $visa_no=explode(':',$personal_info[32]);
         $visa_type=explode(':',$personal_info[33]);
          $visa_strt_date=explode(':',$personal_info[34]);
           $visa_expiry_date=explode(':',$personal_info[35]);
            $visa_issue_place=explode(':',$personal_info[36]);
             $visa_company=explode(':',$personal_info[37]);
              $visa_proof=explode(':',$personal_info[38]);
               $driving_lic=explode(':',$personal_info[39]);
                $driving_issue_date=explode(':',$personal_info[40]);
                 $driving_lic_exp=explode(':',$personal_info[41]);
                  $prob_period=explode(':',$personal_info[42]);

        $confirmation_date=explode(':',$personal_info[43]);
        $temp_emp=explode(':',$personal_info[44]);
        $contract_expiry=explode(':',$personal_info[45]);
        $contract_type=explode(':',$personal_info[46]);          
        $health_card=explode(':',$personal_info[47]);
        $issue_date_health_card=explode(':',$personal_info[48]);
        $expiry_date_health_card=explode(':',$personal_info[49]);

        $clg_name=explode(':',$personal_info[50]);
        $clg_yop=explode(':',$personal_info[51]);
        $clg_specialization=explode(':',$personal_info[52]);          
        $clg_college_university=explode(':',$personal_info[53]);

        $insurance_type=explode(':',$personal_info[54]);
$html.='<p>Gender : '.$gender[1].'</p>';
$html.='<p>Nationality: '.$nationality[1].'</p>';
$html.='<p>Insurance Type : '.$insurance_type[1].'</p>';
$html.='<p>Insurance Currency : '.$insurance_currency[1].'</p>';
$html.='<p>Blood Group : '.$blood_grp[1].'</p>';
$html.='<p>Marital Status : '.$marital_status[1].'</p>';
$html.='<p>Date of Marriage : '.$dom[1].'</p>';
$html.='<p>Spouse Employment Type : '.$spouse_emp_type[1].'</p>';
$html.='<p>Spouse Name : '.$spouse_name[1].'</p>';
$html.='<p>Contact Address : '.$cont_adrs[1].'</p>';
$html.='<p>Contact City: '.$cont_city[1].'</p>';
$html.='<p>Contact Pin: '.$cont_pin[1].'</p>';
$html.='<p>Contact Mobile: '.$cont_mobile[1].'</p>';
$html.='<p>Contact Phone: '.$cont_phone[1].'</p>';
$html.='<p>Company Email: '.$cont_email[1].'</p>';
$html.='<p>Company Fax: '.$cont_fax[1].'</p>';

$html.='<p>Permanent Address: '.$permnt_adrs[1].'</p>';
$html.='<p>Permanent City: '.$permnt_city[1].'</p>';
$html.='<p>Permanent Country: '.$permnt_country[1].'</p>';
$html.='<p>Permanent Pin: '.$permnt_pin[1].'</p>';
$html.='<p>Permanent Phone: '.$permnt_phone[1].'</p>';
$html.='<p>Permanent Fax: '.$permnt_fax[1].'</p>';


$html.='<p>Permanent Residance IC No : '.$pr_ic_no[1].'</p>';
$html.='<p>Permanent Residance PR Issue Date : '.$pr_issue_date[1].'</p>';
$html.='<p>Permanent Residance PR Expiry : '.$pr_expiry[1].'</p>';

$html.='<p>Last Air Ticket : '.$last_air_ticket[1].'</p>';
$html.='<p>Airticket Entitlement Period : '.$airticket_entitlment_period[1].'</p>';
$html.='<p>Passport No. : '.$passport_no[1].'</p>';
$html.='<p>Passport Issue Date : '.$passport_issue_date[1].'</p>';
$html.='<p>Passport Issue Place : '.$passport_issue_place[1].'</p>';
$html.='<p>Passport Expiry : '.$passport_expiry[1].'</p>';

$html.='<p>Visa No. : '.$visa_no[1].'</p>';
$html.='<p>Visa Type : '.$visa_type[1].'</p>';
$html.='<p>Visa Starting Date : '.$visa_strt_date[1].'</p>';
$html.='<p>Visa Expiry Date : '.$visa_expiry_date[1].'</p>';
$html.='<p>Visa Issue Place : '.$visa_issue_place[1].'</p>';
$html.='<p>Visa Company : '.$visa_company[1].'</p>';
$html.='<p>Visa Proof : '.$visa_proof[1].'</p>';
$html.='<p>Driving License : '.$driving_lic[1].'</p>';
$html.='<p>Driving License Issue Date : '.$driving_issue_date[1].'</p>';
$html.='<p>Driving License Expiry : '.$driving_lic_exp[1].'</p>';
$html.='<p>Probation Period (Months) : '.$prob_period[1].'</p>';
$html.='<p>Confirmation Date : '.$confirmation_date[1].'</p>';
$html.='<p>Contract  (If Temporary Employee) : '.$temp_emp[1].'</p>';
$html.='<p>Contract expiry : '.$contract_expiry[1].'</p>';
$html.='<p>Contract type : '.$contract_type[1].'</p>';
$html.='<p>Health Card / Food Handler Certificate  : '.$health_card[1].'</p>';
$html.='<p>Card Issue Date : '.$issue_date_health_card[1].'</p>';
$html.='<p>Card Expiry Date : '.$expiry_date_health_card[1].'</p>';

 if(!empty($clg_name[1])){
           $colg_name= explode('##',$clg_name[1]);
          }

          if(!empty($clg_yop[1])){
            $colg_yop=explode('##',$clg_yop[1]);
          }

          if(!empty($clg_specialization[1])){
            $colg_spec=explode('##',$clg_specialization[1]);
          }

          if(!empty($clg_college_university[1])){
            $colg_univ=explode('##',$clg_college_university[1]);
          }

if(!empty($colg_name))
{
foreach($colg_name as $i1=>$k1)
{
$html.='<p>College Name  : '.$k1.'</p>';
$html.='<p>Year of Passing  : '.$colg_yop[$i1].'</p>';
$html.='<p>Specialization  : '.$colg_spec[$i1].'</p>';
$html.='<p>College/University Name  : '.$colg_univ[$i1].'</p>';
}
}

$html.='</div>';

if(!empty($emp_details))
    {
    $leave_details=explode('$#$',$emp_details[0]->et_leave_details);
   // pre_list($leave_details);
     $offshore_basic=explode(':',$leave_details[0]);
        $offshore_currency=explode(':',$leave_details[1]);
        $vacation_calc_date=explode(':',$leave_details[2]);
        $gratuity_calc_date=explode(':',$leave_details[3]);
        $amount=explode(':',$leave_details[4]);
        $air_ticket_self=explode(':',$leave_details[5]);
        $air_ticket_dependant=explode(':',$leave_details[6]);
        $per_days_worked=explode(':',$leave_details[7]);
        $air_ticket_off_shore=explode(':',$leave_details[8]);
        $per_days_work_off_shore=explode(':',$leave_details[9]);
        $leaves=explode(':',$leave_details[10]);
         $travel_days=explode(':',$leave_details[11]);
          $leaves_off_shore=explode(':',$leave_details[12]); 
       
        $per_days_worked_off_shore=explode(':',$leave_details[13]);
        $total_days_worked_bf=explode(':',$leave_details[14]);
        $total_days_worked_bf_off_shore=explode(':',$leave_details[15]);
        $leave_bf=explode(':',$leave_details[16]);
        $paid_days_bf=explode(':',$leave_details[17]);
        $leaves_bf_ofs=explode(':',$leave_details[18]);
        $air_ticket_bf_self=explode(':',$leave_details[19]);
        $air_ticket_bf_dependant=explode(':',$leave_details[20]);
        $total_lop=explode(':',$leave_details[21]);
        $last_vacation_date=explode(':',$leave_details[22]);
}

$html.='<div id="tab3" class="tab-pane">
<h4>Leave Details</h4>';
$html.='<p>Offshore Basic : '.$offshore_basic[1].'</p>';
$html.='<p>Offshore Currency: '.$offshore_currency[1].'</p>';
$html.='<p>Vacation Calculated Date : '.$vacation_calc_date[1].'</p>';
$html.='<p>Gratuity Calculated Date : '.$gratuity_calc_date[1].'</p>';
$html.='<p>Amount : '.$amount[1].'</p>';
$html.='<p>Air Ticket for Self : '.$air_ticket_self[1].'</p>';
$html.='<p>Air Ticket for Dependants : '.$air_ticket_dependant[1].'</p>';
$html.='<p>Per Days Worked : '.$per_days_worked[1].'</p>';
$html.='<p>Air Ticket(Off Shore) : '.$air_ticket_off_shore[1].'</p>';
$html.='<p>Per Days Worked(Off Shore) : '.$per_days_work_off_shore[1].'</p>';
$html.='<p>Leaves (Slabs for Vacation) : '.$leaves[1].'</p>';
$html.='<p>Travel Days : '.$travel_days[1].'</p>';
$html.='<p>Leaves(Off Shore) : '.$leaves_off_shore[1].'</p>';
$html.='<p>Per Days Worked(Off Shore) : '.$per_days_worked_off_shore[1].'</p>';
$html.='<p>Total Days Worked B/f from last vacation : '.$total_days_worked_bf[1].'</p>';

$html.='<p>Total Days Worked B/f from last vacation(Off Shore) : '.$total_days_worked_bf_off_shore[1].'</p>';
$html.='<p>Leaves B/f: '.$leave_bf[1].'</p>';
$html.='<p>Paid Days B/f : '.$paid_days_bf[1].'</p>';
$html.='<p>Leaves B/f(Off Shore) : '.$leaves_bf_ofs[1].'</p>';
$html.='<p>Air Tickets B/f self : '.$air_ticket_bf_self[1].'</p>';
$html.='<p>Air Tickets B/f Dependants : '.$air_ticket_bf_dependant[1].'</p>';

$html.='<p>Total LOP: '.$total_lop[1].'</p>';
$html.='<p>Last Vacation Date : '.$last_vacation_date[1].'</p>';

$html.='</div>';

$html.='<div id="tab4" class="tab-pane">
<h4>Earnings </h4>';
if(!empty($emp_details))
    {
    $earning_details=explode('$#$',$emp_details[0]->et_earnings);
    
     $hra_value=explode(':',$earning_details[0]);
        $hra_account=explode(':',$earning_details[1]);
        $oa_value=explode(':',$earning_details[2]);
        $oa_account=explode(':',$earning_details[3]);
        $fa_value=explode(':',$earning_details[4]);
        $fa_account=explode(':',$earning_details[5]);
        $transp_value=explode(':',$earning_details[6]);
        $transp_account=explode(':',$earning_details[7]);
        $incentive_value=explode(':',$earning_details[8]);
        $incentive_account=explode(':',$earning_details[9]);
        $allowance_value=explode(':',$earning_details[10]);
        $allowance_account=explode(':',$earning_details[11]);
        $veh_allowance_value=explode(':',$earning_details[12]);
        $veh_allowance_account=explode(':',$earning_details[13]);
        $food_allowance_value=explode(':',$earning_details[14]);
        $food_allowance_account=explode(':',$earning_details[15]);
        $fixed_ot_value=explode(':',$earning_details[16]);
        $fixed_ot_account=explode(':',$earning_details[17]);
     }
$html.='<p>HRA Value: '.$hra_value[1].'</p>';
$html.='<p>HRA A/c: '.$hra_account[1].'</p>';
$html.='<p>Other Allowance value: '.$oa_value[1].'</p>';
$html.='<p>Other Allowance A/c: '.$oa_account[1].'</p>';
$html.='<p>Family Allowance value: '.$fa_value[1].'</p>';
$html.='<p>Family Allowance A/c: '.$fa_account[1].'</p>';
$html.='<p>Transportation value: '.$transp_value[1].'</p>';
$html.='<p>Transportation A/c: '.$transp_account[1].'</p>';
$html.='<p>Incentive(M) value: '.$incentive_value[1].'</p>';
$html.='<p>Incentive(M) A/c: '.$incentive_account[1].'</p>';
$html.='<p>Allowance(M) value: '.$allowance_value[1].'</p>';
$html.='<p>Allowance(M) A/c: '.$allowance_account[1].'</p>';
$html.='<p>Vehicle Allowance value: '.$veh_allowance_value[1].'</p>';
$html.='<p>Vehicle Allowance A/c: '.$veh_allowance_account[1].'</p>';
$html.='<p>Food Allowance value: '.$food_allowance_value[1].'</p>';
$html.='<p>Food Allowance A/c: '.$food_allowance_account[1].'</p>';
$html.='<p>Fixed OT value: '.$fixed_ot_value[1].'</p>';
$html.='<p>Fixed OT A/c: '.$fixed_ot_account[1].'</p>';

$html.='</div>';

if(!empty($emp_details)){
   $file_info=explode('$#$',$emp_details[0]->et_emp_files);

$pic_name=explode(':',$file_info[0]);
$job_offer_letter=explode(':',$file_info[1]);
$passport_copy=explode(':',$file_info[2]);
$visa_copy=explode(':',$file_info[3]);
$employee_contract=explode(':',$file_info[4]);
$emirates_id_copy=explode(':',$file_info[5]);
$driving_license_copy=explode(':',$file_info[6]);
  $folder_name=strtolower(preg_replace('/\s+/', '_', $emp_name[1]));
}
$html.='<div id="tab5" class="tab-pane">
<h4> Files Upload</h4>';

if(!empty($pic_name[1]))
		{
         $html.='<p>Picture : <br/></p>';  
   $html.=' <p><a href="'.base_url("uploads/employee_data/".$folder_name."/".$pic_name[1]).'" target="_blank">
                <i class="fa fa-file-image-o fa-3x" style="color:red;"></i></a></p>';
		}

		if(!empty($job_offer_letter[1]))
		{
         $html.='<p>Job Offer Letter : <br/></p>';  
   $html.=' <p><a href="'.base_url("uploads/employee_data/".$folder_name."/".$job_offer_letter[1]).'"  target="_blank">
                <i class="fa fa-file-pdf-o fa-3x" style="color:red;"></i></a></p>';
		}

		if(!empty($employee_contract[1]))
		{
         $html.='<p>Employment Contract letter : <br/></p>';  
   $html.='<p> <a href="'.base_url("uploads/employee_data/".$folder_name."/".$employee_contract[1]).'" target="_blank">
                <i class="fa fa-file-image-o fa-3x" style="color:red;"></i></a></p>';
		}

		if(!empty($visa_copy[1]))
		{
         $html.='<p>Visa Copy : <br/></p>';  
   $html.='<p> <a href="'.base_url("uploads/employee_data/".$folder_name."/".$visa_copy[1]).'" target="_blank">
                <i class="fa fa-file-image-o fa-3x" style="color:red;"></i></a></p>';
		}

		if(!empty($passport_copy[1]))
		{
         $html.='<p>Passport Copy : <br/></p>';  
   $html.='<p> <a href="'.base_url("uploads/employee_data/".$folder_name."/".$passport_copy[1]).'" target="_blank">
                <i class="fa fa-file-image-o fa-3x" style="color:red;"></i></a></p>';
		}

		if(!empty($emirates_id_copy[1]))
		{
         $html.='<p>Emirates ID Copy : <br/></p>';  
   $html.=' <p><a href="'.base_url("uploads/employee_data/".$folder_name."/".$emirates_id_copy[1]).'" target="_blank">
                <i class="fa fa-file-image-o fa-3x" style="color:red;"></i></a></p>';
		}

		if(!empty($driving_license_copy[1]))
		{
         $html.='<p>Driving License Copy : <br/></p>';  
   $html.=' <p><a href="'.base_url("uploads/employee_data/".$folder_name."/".$driving_license_copy[1]).'" target="_blank">
                <i class="fa fa-file-image-o fa-3x" style="color:red;"></i></a></p>';
		}
$html.='</div>';

$html.='</div>
</div>';

	echo $html;
}





	function hr_excel_upload()
	{
		// print_r('expression');
	 //    exit(0);
	    
		if (logged_in()) {
			$this->load->view('admin/hr/hr_excel');
		}
	}

	function submit_hr_excel()
	{
		$flag = 0;
		$voc_number = '';
		$error_string = "";

		$this->load->library('excel');
		$this->load->library('image_lib');
		$path = 'uploads/excel/sales_vouchers/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this->load->library('upload', $config);
		$this->upload->initialize($config);

		if (!$this->upload->do_upload('userfile')) {
			$error = array('error' => $this->upload->display_errors());
			$this->session->set_flashdata('errors', $error['error']);
			redirect("employee-upload", "refresh");
		} else {
			$data = array('userfile' => $this->upload->data());
		}

		if (!empty($data['userfile']['file_name'])) {
			$import_xls_file = $data['userfile']['file_name'];
		} else {
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try {
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader->load($inputFileName);
		} catch (Exception $e) {
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
		}
		$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);

		for ($i = 2; $i <= $arrayCount; $i++) {
			$ed_name = trim($allDataInSheet[$i]['A']);
			$ed_branch = trim($allDataInSheet[$i]['B']);

			$ed_martial_sts = trim($allDataInSheet[$i]['C']);
			$ed_gender = trim($allDataInSheet[$i]['D']);
			$ed_mob = trim($allDataInSheet[$i]['E']);
			$ed_nationality = trim($allDataInSheet[$i]['F']);
			$ed_doj = trim($allDataInSheet[$i]['G']);
			$ed_pos = trim($allDataInSheet[$i]['H']);
			$ed_sick_leave_pay = trim($allDataInSheet[$i]['I']);
			$ed_tkt_sts = trim($allDataInSheet[$i]['J']);
			
			$ed_vacation_date = trim($allDataInSheet[$i]['K']);
			$ed_code_branch = trim($allDataInSheet[$i]['L']);
		
		

			if (!empty($ed_name)) {
				$data_name = $this->Admin_model->record_count2('employee_details', array('ed_name' => $ed_name));
				//echo "<pre>";
				//print_r($voc_number);
				//echo "<pre>";
				if (!empty($data_name) || $data_name != 0) {
					$flag = 1;
					$error_string .= "This excel file  employee name   already exist in table in  mentioned in .You have an error in Row $i of Cell B.Please remove those details and try again.<br/>";
				}
			}
		
		if ($flag == 1) {

			$this->session->set_flashdata('errors', $error_string);
			unlink("uploads/excel/sales_vouchers/" . $import_xls_file);
			redirect('employee-upload', 'refresh');
		} else {


			print_r($ed_name);
			//exit(0);
			$dwnload_title = $this->input->post('dwnload_title');
			$data23 = array(
				'ed_name' => $ed_name,
				'ed_branch' => $ed_branch,
				'ed_code_branch'=>$ed_code_branch,
				'ed_martial_sts' => $ed_martial_sts,
				'ed_gender' => $ed_gender,
				'ed_mob' => $ed_mob,
				'ed_nationality' => $ed_nationality,
				
				'ed_doj' => date("Y-m-d", strtotime($ed_doj)),
				'ed_pos' => $ed_pos,
				'ed_sick_leave_pay' => $ed_sick_leave_pay,
				'ed_tkt_sts' => $ed_tkt_sts,
				'ed_vacation_date' => date("Y-m-d", strtotime($ed_vacation_date)),
				
			);
			$insert_id = $this->Admin_model->insert_data("employee_details", $data23);

}
}
				if ($insert_id)
			$this->session->set_flashdata('success', 'Imported Successfully');
		else
			$this->session->set_flashdata('errors', 'Error found. Try again!');

		redirect("employee-upload", "refresh");

			$this->insert_table($allDataInSheet, $insert_id);
		
	
}
	//function insert_table($allDataInSheet, $insert_id)
	// {
	// 	$arrayCount = count($allDataInSheet);
	// 	$flag = 0;
	// 	$vocr_array = array();
	// 	$data_empty_array = array();
	// 	$insert_id_vochr = '';
	// 	for ($i = 2; $i <= $arrayCount; $i++) {
	// 		$voc_number = trim($allDataInSheet[$i]['B']);
	// 		$voc_date = trim($allDataInSheet[$i]['A']);

	// 		$new_voc_date = explode('-', $voc_date); ///in the format m-d-y , i need is y-m-d.
	// 		if (!empty($new_voc_date[0]))
	// 			$month_voc = $new_voc_date[0];
	// 		else
	// 			$month_voc = '';

	// 		if (!empty($new_voc_date[1]))
	// 			$date_voc = $new_voc_date[1];

	// 		if (!empty($new_voc_date[2]))
	// 			$year_voc = $new_voc_date[2];
	// 		else
	// 			$year_voc = '';

	// 		if (!empty($month_voc) && !empty($date_voc) && !empty($year_voc)) {
	// 			$voc_date_2 = $year_voc . '-' . $month_voc . '-' . $date_voc;
	// 		} else
	// 			$voc_date_2 = '0000-00-00';

	// 		$cust_name = trim($allDataInSheet[$i]['C']);
	// 		$narration = trim($allDataInSheet[$i]['D']);
	// 		$branch = trim($allDataInSheet[$i]['L']);
	// 		$country = trim($allDataInSheet[$i]['O']);
	// 		$salesman = trim($allDataInSheet[$i]['P']);
	// 		$acc_to = trim($allDataInSheet[$i]['Q']);
	// 		$store_name = trim($allDataInSheet[$i]['R']);
	// 		$paymnt_type = trim($allDataInSheet[$i]['S']);
	// 		$due_date = trim($allDataInSheet[$i]['T']);

	// 		$prd_name_en = trim($allDataInSheet[$i]['E']);
	// 		$prd_name_ar = trim($allDataInSheet[$i]['M']);
	// 		$prd_code = trim($allDataInSheet[$i]['F']);
	// 		$qty = trim($allDataInSheet[$i]['G']);
	// 		$rate = trim($allDataInSheet[$i]['H']);

	// 		$vat = trim($allDataInSheet[$i]['J']);
	// 		$category = trim($allDataInSheet[$i]['N']);

	// 		$amount = trim($allDataInSheet[$i]['K']);
	// 		$gross = str_replace(',', '', trim($allDataInSheet[$i]['I']));
	// 		$gross_uae = str_replace(',', '', trim($allDataInSheet[$i]['Y'])); /////the wrong gross

	// 		if ($voc_number != 'Total' && !empty($voc_number)) {
	// 			//$vocr_array[]=$voc_number;
	// 			if (empty($vocr_array) || !(in_array($voc_number, $vocr_array))) {
	// 				$vocr_array[] = $voc_number;

	// 				$new_amount = explode(' ', $amount);
	// 				$currency = $new_amount[0];
	// 				$total_amount = $new_amount[1];

	// 				$data_empty_array = array(
	// 					'sbr_vochuer_no' => $voc_number,
	// 					'sbr_customer' => $cust_name,
	// 					'sbr_narration' => $narration,
	// 					'sbr_branch' => $branch,
	// 					'sbr_city' => $country,
	// 					'sbr_salesman' => $salesman,
	// 					'sbr_acc_to' => $acc_to,
	// 					'sbr_storename' => $store_name,
	// 					'sbr_paymnt_type' => $paymnt_type,
	// 					'sbr_due_date' => date("Y-m-d", strtotime($due_date)),
	// 					'sbr_vou_date' => $voc_date_2,
	// 					'sbr_excel_id' => $insert_id,
	// 					'sbr_sts' => '1',
	// 					'sbr_voc_month' => $month_voc,
	// 					'sbr_voc_year' => $year_voc,
	// 					'sbr_currency' => $currency,
	// 					'sbc_total_amount' => $total_amount,
	// 				);
	// 				//pre_list($data_empty_array);

	// 				$insert_id_vochr = $this->Admin_model->insert_data2("sales_book_report", $data_empty_array);
	// 				//pre_list($insert_id_vochr);
	// 				if (!($insert_id_vochr))
	// 					$status = false;
	// 				else
	// 					$status = true;

	// 				$prd_data['prd_info'][] = array(
	// 					'vochuer_id' => $insert_id_vochr,
	// 					'name_en' => $prd_name_en,
	// 					'name_ar' => $prd_name_ar,
	// 					'pcode' => $prd_code,
	// 					'qty' => $qty,
	// 					'rate' => $rate,
	// 					'gross' => $gross,
	// 					'grs_uae' => $gross_uae,
	// 					'vat' => $vat,
	// 					'cat' => $category,
	// 				);
	// 				$this->session->set_userdata($prd_data);
	// 			} else {
	// 				$prd_data['prd_info'][] = array(
	// 					'vochuer_id' => $insert_id_vochr,
	// 					'name_en' => $prd_name_en,
	// 					'name_ar' => $prd_name_ar,
	// 					'pcode' => $prd_code,
	// 					'qty' => $qty,
	// 					'rate' => $rate,
	// 					'gross' => $gross,
	// 					'grs_uae' => $gross_uae,
	// 					'vat' => $vat,
	// 					'cat' => $category,
	// 				);
	// 				$this->session->set_userdata($prd_data);
	// 			}
	// 		}
	// 	}

	// 	if ($status)
	// 		$this->session->set_flashdata('success', 'Imported Successfully');
	// 	else
	// 		$this->session->set_flashdata('errors', 'Error found. Try again!');

	// 	redirect("sales-book", "refresh");
	// }























}