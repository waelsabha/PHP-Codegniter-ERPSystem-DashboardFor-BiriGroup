<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Single_installation extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));		
	}

	function single_installation($id=null)
	{
		if(logged_in())
		{
         $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
         $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {//for issue oroforma for sales team
           	if ((($page_cred[$i]=='single-installation')||($this ->session->userdata['user']['main_dept'])=="Main"))
            {
               $excist=true;
               $i=$cred_count;
            }   

           else
                {$excist=false;}

        }
       if ($excist) {


			$data['products']=$this->tm->get_data('products',array('p_sts'=>'1'));
	     	$sql="SELECT * FROM sales_customer_entry WHERE sca_status = '1'";
			$qry=$this->db->query($sql);
			$data['customers']=$qry->result();
			$sql=$this->db->query("SELECT * FROM `employee_details` WHERE `ed_branch`='6' AND `ed_sts`='1' AND `ed_pos`!='FOREMAN'");
			$data['labour']=$sql->result_array();
			$data['vehicle']=$this->Admin_model->get_data('assets_vehicle',array('veh_sts'=>'1'));
			$data['tools']=$this->Admin_model->get_data('assets_tools',array('tool_sts'=>'1'));
			if(!empty($id))
			{
				$data['result']=$this->Admin_model->get_data('single_installation',array('si_id'=>$id));
				if($data['result'][0]->si_ins_type=='1')
				{
					$data['main_result']=$this->tm->get_data('prd_order',array('po_sts'=>'1','po_order_status_fact !='=>'0','po_order_status_adv !='=>'0'));
					$data['po_data']=$this->tm->get_data('prd_order',array('po_id'=>$data['result'][0]->si_item_choosed));
				}
				elseif($data['result'][0]->si_ins_type=='2')
				{
					$data['main_result']=$this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1','q_current_status !='=>'Lost'));
					$data['quot_data']=$this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$data['result'][0]->si_item_choosed));
				}
				else
				{}
			}
			$this->load->view('admin/production/single_installation',$data);

            }

    else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
        } 

		}
	}


	function get_installation_type()
	{
		$instal_type=$this->input->post('instal_type');
		if($instal_type=='1')
		{
			$po_result=$this->tm->get_data('prd_order',array('po_sts'=>'1','po_order_status_fact !='=>'0','po_order_status_adv !='=>'0'));
			echo json_encode($po_result);
		}
		elseif($instal_type=='2')
		{

			$quot_result=$this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1','q_current_status !='=>'Lost'));
			echo json_encode($quot_result);
		}
		else
		{
			echo "";
		}
	}

 function get_items_details()
{
	$result_type_id=$this->input->post('result_type_id');
	$value_type=$this->input->post('value_type');
	$html='<table class="table table-bordered mb-none">
 <thead>
  <tr>
   <!--  <th>#</th>  -->
   <th width="5%"></th>
   <th width="5%">Product Name</th>
   <th width="5%">Quantity</th>
 <th width="5%">Extra Details</th>
  </tr>
 </thead>
 <tbody class="new_rows">';
	if($value_type==1)
	{
		$po_data=$this->tm->get_data('prd_order',array('po_id'=>$result_type_id));
		$po_ids=explode('|#|',$po_data[0]->po_prd_name);
		$po_qnty=explode('|#|',$po_data[0]->po_qnty);
		$po_extras=explode('|#|',$po_data[0]->po_spcl_rq);
		$ij=0;
foreach($po_ids as $item_id)
{
	$po_details[]=$this->tm->get_data('products',array('pid'=>$item_id));
}
foreach($po_details as $index=>$pod)
{
	$html.='<tr>
	<td>'.$ij++.'</td>
	 <td><p class="item_name">'.$pod[0]->pname.'</p></td>
	<td><p class="item_qnty">'.$po_qnty[$index].'</p></td>
	<td><p class="item_details_from_order">'.$po_extras[$index].'</p></td>
	</tr>';
}
	
	}
	elseif($value_type==2)
	{
		$quot_data=$this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$result_type_id));
		$po_quot_ids=explode('|#|',$quot_data[0]->q_prd_id);
		$po_quot_qnty=explode('|#|',$quot_data[0]->q_prd_qnty);
		$po_quot_extra_details=explode('|#|',$quot_data[0]->q_remarks);
$ik=0;
		foreach($po_quot_ids as $item_id)
		{
			$quot_details[]=$this->tm->get_data('products',array('pid'=>$item_id));
		}
		foreach($quot_details as $index=>$qod)
		{
			$html.='<tr>
			<td>'.$ik++.'</td>
			 <td><p class="item_name">'.$qod[0]->pname.'</p></td>
			<td><p class="item_qnty">'.$po_quot_qnty[$index].'</p></td>
			<td><p class="item_details_from_order">'.$po_quot_extra_details[$index].'</p></td>
			</tr>';
		}
	}
	else
	{

	}

	 $html.='</tbody>
</table>';

echo $html;

}

function submit_single_inst()
{
	if(!empty($this->input->post('inst_id')))
	{
		$edit_inst_id=$this->input->post('inst_id');
	}

	if(!empty($this->input->post('schedule_date_installation')))
			{
			$date_set_for_po=$this->input->post('schedule_date_installation');
				$date0=explode('/',$date_set_for_po);
				
				$date1=$date0[0];
				$month1=$date0[1];
				$year1=$date0[2];
				$new_formated_date1=$year1.'-'.$month1.'-'.$date1;
			}
			else
			{
				$new_formated_date1='';
			}

$targetfolder='./uploads/single_installation/';
if (!is_dir($targetfolder)) 
            {
            	mkdir('./'.$targetfolder, 0777, TRUE);
	   }
  if (isset($_FILES['label_upload']['name']) && 
  	$_FILES['label_upload']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'label_upload',
				'upload_path'=>$targetfolder,
			);
			$pic_names=img_upload($img_array1);

			if(!empty($pic_names))
			{
				if(!empty($pic_names[0][0]['file_name']))
				{
					foreach($pic_names[0] as $k1)
					{
						$pp_aray[]=$k1['file_name'];
						$value_pp_aray=implode(',',$pp_aray);
					}
				}
			}
			else
			{
				if(!empty($this->input->post('edit_img')))
				{
					$value_pp_aray=$this->input->post('edit_img');
				}
				else
				{
					$value_pp_aray='';
				}
			}	
		}	
	$data=array(
		'si_user_name'=>$this->session->userdata['user']['username'],
		'si_prj_name'=>$this->input->post('prj_name'),
		'si_ins_type'=>$this->input->post('inst_type'),
		'si_ins_loc'=>$this->input->post('inst_loc'),
		'si_ins_date'=>$new_formated_date1,
		'si_cust_id'=>$this->input->post('choose_customer'),
		'si_cust_name'=>$this->input->post('st_new_cust_name'),
		'si_cust_comp'=>$this->input->post('st_new_cust_comp'),
		'si_cust_mob'=>$this->input->post('st_new_cust_mobile'),
		'si_cust_email'=>$this->input->post('st_new_cust_email'),
		'si_cust_landline'=>$this->input->post('st_new_cust_land'),
		'si_labour'=>implode(',',$this->input->post('choose_labour')),
		'si_vehicle'=>implode(',',$this->input->post('vehicle_choosed')),
		'si_tools'=>implode(',',$this->input->post('choose_tools')),
		'si_notes'=>$this->input->post('st_additional_desc'),
		'si_attachments'=>$value_pp_aray,
		'si_item_choosed'=>$this->input->post('search_type_result'),
		'si_sts'=>'1',
	);
	if(empty($edit_inst_id))
	{
		$insert_id=$this->Admin_model->insert_data('single_installation',$data);
		if($insert_id)
		{
			$this->session->set_flashdata('success', 'Data Successfully inserted');
			redirect('single-installation');
		}
	}
	else
	{
		$this->Admin_model->insert_data('single_installation',$data,array('si_id'=>$edit_inst_id));
			$this->session->set_flashdata('success', 'Data Successfully updated');
			redirect('list-single-installation');
	}
	
}



function list_single_installation()
{
	if(logged_in())
		{


		 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		 $cred_count=count($page_cred);


			        for($i=0;$i<$cred_count;$i++)
			        {
			         	if ((($page_cred[$i]=='list-single-installation')||($this ->session->userdata['user']['main_dept'])=="Main"))
			         	{
				           $excist=true;
			               $i=$cred_count;
			         	}	

			           else
			            	{$excist=false;}
		   
			        }
			       if ($excist) {


									$data['result']=$this->Admin_model->get_data('single_installation',array('si_sts'=>'1'));
									$sql="SELECT * FROM sales_customer_entry WHERE sca_status = '1'";
									$qry=$this->db->query($sql);
									$data['customers']=$qry->result();
							
									$sql=$this->db->query("SELECT * FROM `employee_details` WHERE `ed_branch`='6' AND `ed_sts`='1' AND `ed_pos`!='FOREMAN'");
									$data['labour']=$sql->result_array();
									$data['vehicle']=$this->Admin_model->get_data('assets_vehicle',array('veh_sts'=>'1'));
									$data['tools']=$this->Admin_model->get_data('assets_tools',array('tool_sts'=>'1'));
									$data['po_details']=$this->tm->get_data('prd_order',array('po_sts'=>'1','po_order_status_fact !='=>'0','po_order_status_adv !='=>'0'));
									$data['quot_details']=$this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1','q_current_status !='=>'Lost'));


									$this->load->view('admin/production/list_single_installation',$data);
		}

				           else{
							//echo false;
							 $this->session->unset_userdata('user', null);
					       	redirect('login','refersh');
		}  
		 }
          
    
	


		
}
function get_type_details()
{
	$instal_id=$this->input->post('inst_id');
	$instal_type=$this->input->post('instal_type');

	$inst_details=$this->Admin_model->get_data('single_installation',array('si_id'=>$instal_id));
	$html='<table class="table table-bordered mb-none">
 <thead>
  <tr>
   <th width="5%">Product Name</th>
   <th width="5%">Quantity</th>
 <th width="5%">Extra Details</th>
  </tr>
 </thead>
 <tbody class="new_rows">';
	if($instal_type=='1')
	{
		$po_data=$this->tm->get_data('prd_order',array('po_id'=>$inst_details[0]->si_item_choosed));
		$po_ids=explode('|#|',$po_data[0]->po_prd_name);
		$po_qnty=explode('|#|',$po_data[0]->po_qnty);
		$po_extras=explode('|#|',$po_data[0]->po_spcl_rq);
		$ij=0;
		foreach($po_ids as $item_id)
		{
			$po_details[]=$this->tm->get_data('products',array('pid'=>$item_id));
		}
		foreach($po_details as $index=>$pod)
		{
			$html.='<tr>
			 <td><p class="item_name">'.$pod[0]->pname.'</p></td>
			<td><p class="item_qnty">'.$po_qnty[$index].'</p></td>
			<td><p class="item_details_from_order">'.$po_extras[$index].'</p></td>
			</tr>';
		}
	}
	else
	{
		$quot_data=$this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$inst_details[0]->si_item_choosed));
		$po_quot_ids=explode('|#|',$quot_data[0]->q_prd_id);
		$po_quot_qnty=explode('|#|',$quot_data[0]->q_prd_qnty);
		$po_quot_extra_details=explode('|#|',$quot_data[0]->q_remarks);
$ik=0;
		foreach($po_quot_ids as $item_id)
		{
			$quot_details[]=$this->tm->get_data('products',array('pid'=>$item_id));
		}
		foreach($quot_details as $index=>$qod)
		{
			$html.='<tr>
			 <td><p class="item_name">'.$qod[0]->pname.'</p></td>
			<td><p class="item_qnty">'.$po_quot_qnty[$index].'</p></td>
			<td><p class="item_details_from_order">'.$po_quot_extra_details[$index].'</p></td>
			</tr>';
		}
	}
			 $html.='</tbody>
		</table>';

		echo $html;
}



function delete_single_installation($id)
{
	if(logged_in())
	{
		$this->Admin_model->update_data('single_installation',array('si_sts'=>'0'),array('si_id'=>$id));
			$this->session->set_flashdata('success', 'Data Successfully deleted');
	 	redirect('list-single-installation');	
	}
}














}