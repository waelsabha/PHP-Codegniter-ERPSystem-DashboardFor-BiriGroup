<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts_customer extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->model(array('Account_model'));
		$this->load->helper(array('session','gnrl'));	
	}

		function add_customers()
	{
		if(logged_in())
		{
         

             $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='add-customers')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

		$cond=array('status'=>'1');
		$data['country']=$this->Admin_model->get_data('country_val',$cond);
	    $this->load->view('admin/accounts/add_customers',$data);
        }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


		}
	}

	
	function list_acc_customers()
	{
		if(logged_in())
		{
 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='list-account-customers')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

		$cond=array('status'=>'1');
		$data['country']=$this->Admin_model->get_data('country_val',$cond);
	    $data['result']=$this->Account_model->acc_cust_country();
	    $this->load->view('admin/accounts/list_acc_customers',$data);
       }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


		}
	}
	function delete_customer($id)
	{
		if(logged_in())
		{
			$data=array('ac_sts'=>'0');
			$cond1=array('ac_id'=>$id);
			$this->Admin_model->update_data('acc_cusotmer',$data,$cond1);
		$this->session->set_flashdata('success', 'Data successfully updated');
			redirect('list-account-customers');
		}

	}

	function submit_acc_customer()
	{
		$this->form_validation->set_rules('cust_name', 'Customer Name', 'trim|required');
		$this->form_validation->set_rules('country', 'Country', 'trim|required');
	   	$this->form_validation->set_rules('email[]', 'Email', 'trim|valid_email');
	   
		$this->form_validation->set_rules('mobile_num', 'Mobile Number', 'trim|required');
		$this->form_validation->set_rules('address', 'Address', 'trim');
		$this->form_validation->set_rules('notes', 'Notes', 'trim');	

		if ($this->form_validation->run() == FALSE)
        {          
        $this->session->set_flashdata('cust_name', form_error('cust_name'));
		$this->session->set_flashdata('country',form_error('country'));
		$this->session->set_flashdata('email', form_error('email'));
		$this->session->set_flashdata('mobile_num', form_error('mobile_num'));
		$this->session->set_flashdata('address', form_error('address'));
		$this->session->set_flashdata('notes', form_error('notes'));
		redirect('add-customers','refersh');
        }
        else
        {
        	$cust_id=$this->input->post('cust_id');

        	$data=array(
           	'ac_name'=>$this->input->post('cust_name'),
            'ac_country'=>$this->input->post('country'),
           'ac_email'=>implode(',',$this->input->post('email')),
           	'ac_adrs'=>$this->input->post('address'),
           	'ac_notes'=>$this->input->post('notes'),
           	'ac_mobile'=>$this->input->post('mobile_num'),   
           	'ac_staff_id'=>$this->session->userdata['user']['username'], 
           	'ac_sts'=>'1'
           );
	       if(empty($cust_id)) 	
	       {
	        $insert_id=$this->Admin_model->insert_data('acc_cusotmer',$data);

	        $cutomer_code='1'.str_pad($insert_id, 4, '0', STR_PAD_LEFT);
	        $data2=array('ac_code'=>$cutomer_code);
	        $cond1=array('ac_id'=>$insert_id);

			$this->Admin_model->update_data('acc_cusotmer',$data2,$cond1);

			$this->session->set_flashdata('success', 'Data successfully inserted');
			}
			else
			{
				 $cond1=array('ac_id'=>$cust_id);
			 $this->Admin_model->update_data('acc_cusotmer',$data,$cond1);
			 $this->session->set_flashdata('success', 'Data successfully updated');
			}
		
			redirect('add-customers');

        }
     
	}


































}