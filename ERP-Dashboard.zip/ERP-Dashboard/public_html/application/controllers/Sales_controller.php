<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_controller extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper('session');	
		$this->load->model(array('Second_db_model','Sales_book_model'));
	}

function add_custmrs($id=null)
{
	if(logged_in())
	{
     
    $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='add-customer-details')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

		$cond=array('status'=>'1');
		$data['country']=$this->Admin_model->get_data('country_val',$cond);	
		if(empty($id))
		$this->load->view('admin/sales/add_custmrs',$data);
		else
		{

			$cond=array('sca_id'=>$id);
		$data['result']=$this->Admin_model->get_data('sales_customer_entry',$cond);	
		$country_data=$data['result'][0]->sca_cust_country;
		
		$cond2=array('country_id'=>$country_data);
		$data['country_data']=$this->Admin_model->get_data('country_val',$cond2);
		$this->load->view('admin/sales/add_custmrs',$data);	


		}
	}
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}

		}	
}


function list_custmrs()
{
	if(logged_in())
	{
		// $cond=array('sca_status'=>'1');
		// $order_by='sca_id';
		// $order_type="DESC";


		$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      //if ((($page_cred[$i]=='list-customer-details')||($this ->session->userdata['user']['main_dept'])=="Main"))
	  //now we prevent all from access this page
	  //if ($page_cred[$i]=='Not Allowed for any one till now')
	  //now just manager
	  if ($this ->session->userdata['user']['main_dept']=="Main")
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {
		if($this->session->userdata['user']['main_dept']=="Sales")
		{
		
			$sub_dept=$this->session->userdata['user']['sub_dept'];
			if($this ->session->userdata['user']['sub_dept']=="gcc")
			{
				$user_list=$this->Admin_model->get_data('login_credentials',array('log_sub_type'=>$sub_dept));
				foreach($user_list as $indx=>$ul)
				{
					$cond_username[]=$ul->log_uname;
				}
			}
			elseif($this->session->userdata['user']['sub_dept']=="african")
			{
			$user_list=$this->Admin_model->get_data('login_credentials',array('log_sub_type'=>$sub_dept));
				foreach($user_list as $indx=>$ul)
				{
					$cond_username[]=$ul->log_uname;
				}
			}
			else{$cond_username='';}
		}
		else{
			$cond_username='';
		}
		$data['result']=$this->Admin_model->sales_cust_country('',$cond_username);
	
        $this->load->view('admin/sales/list_custmrs',$data);

        }
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}
	}
}

function submit_new_cusomter()
{
	$cust_id=$this->input->post('sales_cust_id');  

		$this->form_validation->set_rules('cust_name', 'Customer Name', 'trim|required');
		$this->form_validation->set_rules('country', 'Country', 'trim|required');

		if(empty($cust_id))///// for edit 
		{
		$this->form_validation->set_rules('email[]', 'Email', 'trim');
		$this->form_validation->set_rules('comp_name', 'Company Name', 'trim');
	   }
	   else
	   {
	   	$this->form_validation->set_rules('email[]', 'Email', 'trim|valid_email');
	   	$this->form_validation->set_rules('comp_name', 'Company Name', 'trim|required');
	   }
	   $this->form_validation->set_rules('desig', 'Designation', 'trim');
		$this->form_validation->set_rules('landline', 'Landline', 'trim');
		$this->form_validation->set_rules('mobile_num', 'Mobile Number', 'trim|required');
		 $this->form_validation->set_rules('cust_interest[]', 'Customer Interest', 'trim|required');
		$this->form_validation->set_rules('wtsapp_interest', 'Whatsapp notification Interest', 'trim|required');
		//$this->form_validation->set_rules('sms_interest', 'SMS notification Interest', 'trim|required');
	
	$cust_emails=$this->input->post('email[]');  
	foreach($cust_emails as $ce)
	{
	$check_email[]=$this->Admin_model->get_data('sales_customer_entry',array('sca_cust_email'=>$ce),'','','','','');
	}
	
	if(!empty($check_email))
	{ 
		if(empty($cust_id))///// for edit 
		{
			foreach($check_email as $cek)
			{
				foreach($cek as $ce)
				{
				
				  	$check_email2[]=$ce->sca_cust_email;
				}	
			}
		}
		 else
		  {
		  $check_email2='';
		  }					
	}		
	if ($this->form_validation->run() == FALSE)
        {          
        	$this->session->set_flashdata('cust_name', form_error('cust_name'));
		$this->session->set_flashdata('country',form_error('country'));
		$this->session->set_flashdata('comp_name',form_error('comp_name'));
		$this->session->set_flashdata('email[]', form_error('email[]'));
		$this->session->set_flashdata('comp_name', form_error('comp_name'));
		$this->session->set_flashdata('landline', form_error('landline'));
		$this->session->set_flashdata('mobile_num', form_error('mobile_num'));
		 $this->session->set_flashdata('cust_interest[]', form_error('cust_interest'));
		$this->session->set_flashdata('wtsapp_interest',form_error('wtsapp_interest'));
		$this->session->set_flashdata('desig', form_error('desig'));
		//$this->session->set_flashdata('sms_interest', form_error('sms_interest'));
		
		//print_r(validation_errors());
		redirect('add-customer-details','refersh');
        }
        elseif(!empty($check_email2))
        {
        $this->session->set_flashdata('errors','ERROR.........Cannot input duplicate email(s).');
        	redirect('add-customer-details','refersh');
        }
        else
        {
     
        $cust_interest_array=$this->input->post('cust_interest[]');	
		$new_interest=implode(',',$cust_interest_array);


		$this->load->library('image_lib');
		$ImageCount = count($_FILES['files']['name']);
        for($i = 0; $i < $ImageCount; $i++){
            $_FILES['file']['name']       = $_FILES['files']['name'][$i];
            $_FILES['file']['type']       = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['files']['error'][$i];
            $_FILES['file']['size']       = $_FILES['files']['size'][$i];

            // File upload configuration
            $uploadPath = 'uploads/business_cards/';
         $config['file_name'] = time() . $_FILES["files"]["name"][$i];
            $config['upload_path'] = $uploadPath;
            $config['max_size'] = '1024000';////1mb
            $config['allowed_types'] = 'jpg|jpeg|png|gif';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'business_card');
            $this->business_card->initialize($config);

            // Upload file to server
            if($this->business_card->do_upload('file')){
                // Uploaded file data
                $imageData = $this->business_card->data();
                  $configer =  array(
              'image_library'   => 'gd2',
              'source_image'    =>  $imageData['full_path'],
              'maintain_ratio'  =>  TRUE,
              //'width'           =>  250,
              //'height'          =>  250,
            );
            $this->image_lib->clear();
            $this->image_lib->initialize($configer);
            $this->image_lib->resize();

                $uploadImgData[]=$imageData['file_name'];     
        }
    }

    	  if(!empty($uploadImgData))
    	  {
    	  	$data=array(
           	'sca_cust_name'=>$this->input->post('cust_name'),
            'sca_cust_country'=>$this->input->post('country'),
             'sca_cust_email'=>implode(',',$this->input->post('email')),
           	'sca_cust_company'=>$this->input->post('comp_name'),
           	'sca_cust_landline'=>$this->input->post('landline'),
           	'sca_cust_mobile'=>$this->input->post('mobile_num'),
           	'sca_cust_interest'=>$new_interest,
           	'sca_cust_wtsapp_notf'=>$this->input->post('wtsapp_interest'),
           	//'sca_cust_sms_notf'=>$this->input->post('sms_interest'),
           	'sca_staff_id'=>$this->session->userdata['user']['username'], 
           	'sca_cust_designation'=>$this->input->post('desig'),
           	'sca_business_cards'=>implode(',',$uploadImgData),
           );
    	  	
    	  }

    	  else
    	  {
    	  
		 $data=array(
           	'sca_cust_name'=>$this->input->post('cust_name'),
            'sca_cust_country'=>$this->input->post('country'),
             'sca_cust_email'=>implode(',',$this->input->post('email')),
           	'sca_cust_company'=>$this->input->post('comp_name'),
           	'sca_cust_landline'=>$this->input->post('landline'),
           	'sca_cust_mobile'=>$this->input->post('mobile_num'),
           	'sca_cust_designation'=>$this->input->post('desig'),
           	'sca_cust_interest'=>$new_interest,
           	'sca_cust_wtsapp_notf'=>$this->input->post('wtsapp_interest'),
           	//'sca_cust_sms_notf'=>$this->input->post('sms_interest'),
           	'sca_staff_id'=>$this->session->userdata['user']['username'], 
           );
		}
		

		 if(empty($cust_id))
		 {
		 	$insert_id=$this->Admin_model->insert_data('sales_customer_entry',$data);
		 	if(!empty($insert_id))
	     	{
	     		$cust_id="CUST_".str_pad($insert_id, 2, '0', STR_PAD_LEFT);;
	     		$data1=array('sca_status'=>'1',
	     			'sca_cust_id'=>$cust_id);
	     		$cond1=array('sca_id'=>$insert_id);
	       		$this->Admin_model->update_data('sales_customer_entry',$data1,$cond1);
	     	}
	     	$this->session->set_flashdata('success', 'Data successfully inserted');
	     	redirect('add-customer-details');
		}
		else
		{
			$cond1=array('sca_id'=>$cust_id);
			$this->Admin_model->update_data('sales_customer_entry',$data,$cond1);
			$this->session->set_flashdata('success', 'Data successfully updated');
			redirect('list-customer-details');
		}
	     	
	 
        }
}


function code_flag()
{
	$country_id=$this->input->post('country_id');
	$cond=array('country_id'=>$country_id);
	$data_result=$this->Admin_model->get_data('country_val',$cond);
	$flag=base_url('admin_assets/flags/').$data_result[0]->flag;
	$dial_code=$data_result[0]->dial_code;
	
	$data=array(
		'flag'=>$flag,
		'code'=>$dial_code
	);
	echo json_encode($data);
}

function delete_custmrs($id)
{
if(logged_in())
		{
	$data1=array('sca_status'=>'0');
	$cond1=array('sca_id'=>$id);
	$this->Admin_model->update_data('sales_customer_entry',$data1,$cond1);
	$this->session->set_flashdata('success', 'Data successfully deleted');
		redirect('list-customer-details');
		}

}

function add_bus_cards()
{
if(logged_in())
		{
			$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='add-files')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

	$cond=array('bc_status'=>'1','bc_staff'=>$this->session->userdata['user']['username']);
	$data['result']=$this->Second_db_model->get_data('file_manager',$cond);

	$this->load->view('admin/sales/upload_bus_card',$data);

}
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}


	}


}


function submit_bus_card()
{
if(logged_in())
		{
$image_name=$this->input->post('file_name');
	$image = array();
	$uploadImgData = array();

  $ImageCount = count($_FILES['files']['name']);
        for($i = 0; $i < $ImageCount; $i++)
        {
            $_FILES['file']['name']       = $_FILES['files']['name'][$i];
            $_FILES['file']['type']       = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['files']['error'][$i];
            $_FILES['file']['size']       = $_FILES['files']['size'][$i];

            // File upload configuration
            $uploadPath = 'uploads/file_manager/';
         $config['file_name'] = time() . $_FILES["files"]["name"][$i];
            $config['upload_path'] = $uploadPath;
            //$config['max_size'] = '3000000';////3mb
            $config['allowed_types'] = '*';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'business_card');
            $this->business_card->initialize($config);

            // Upload file to server
            if($this->business_card->do_upload('file'))
            {
                // Uploaded file data
                $imageData = $this->business_card->data();
              
                $uploadImgData[]=$imageData['file_name'];
              
                //print_r($uploadImgData);
            }       
        }

        //print_r($this->business_card->display_errors());

         if(!empty($uploadImgData))
            {         	
         	$data=array('bc_name'=>$image_name,
         				'bc_img'=>implode(',',$uploadImgData),
         				'bc_staff'=>$this->session->userdata['user']['username'],
         				'bc_status'=>"1",
         			);        	
         	$insert_id=$this->Second_db_model->insert_data('file_manager',$data);
         	$this->session->set_flashdata('success', 'Files successfully uploaded');
	     		redirect('add-files');
        	}
        else{
            	$this->session->set_flashdata('errors', $this->business_card->display_errors());
	     		redirect('add-files');
            }	
            }	
}


function delete_bus_card($id)
{
if(logged_in())
		{
	$cond=array('bc_id'=>$id);
	$data_result=$this->Second_db_model->get_data('file_manager',$cond);

	$pages=$data_result[0]->bc_img;
	$images=explode(',',$pages);
	foreach($images as $i)
	{
		unlink('./uploads/file_manager/'.$i);
	}

	$data1=array('bc_status'=>"0");
	$this->Second_db_model->update_data('file_manager',$data1,$cond);
	$this->session->set_flashdata('success', 'Files removed successfully');
	
	if($this->session->userdata['user']['main_dept']=="Main")
	{
		redirect('list-user-files');
	}
	else
	{
		redirect('add-files');
	}
	 // correct
	 }

}


function download_files($id)
{
$this->load->helper(array('download'));
$this->load->library('zip');

	$cond=array('bc_id'=>$id);
$data_result=$this->Second_db_model->get_data('file_manager',$cond);

$files=$data_result[0]->bc_img;
$images=explode(',',$files);
$count_files=count($images);

	foreach($images as $j)
	{
		//$data = file_get_contents('path/file.xls');
		//force_download('file.xls', $data);
		  $this->zip->read_file('./uploads/file_manager/'.$j);
	}	
	$this->zip->download('files_backup.zip');
}



function download_bus_cards($id)
{
$this->load->helper(array('download'));
$this->load->library('zip');

	$cond=array('sca_id'=>$id);
$data_result=$this->Admin_model->get_data('sales_customer_entry',$cond);
$comp_name=$data_result[0]->sca_cust_company;
$files=$data_result[0]->sca_business_cards;
$images=explode(',',$files);
$count_files=count($images);

	foreach($images as $j)
	{
		//$data = file_get_contents('path/file.xls');
		//force_download('file.xls', $data);
		  $this->zip->read_file('./uploads/business_cards/'.$j);
	}	
	$this->zip->download(''.$comp_name.'.zip');
}


function customer_excel_upload()
{  
	$excist=false;
	if(logged_in())
	{

         $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='customer-excel-upload')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {
         	// code...
	
            $this->load->view('admin/sales/sales_excel_upload');
        }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  
}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  
}

function submit_cutomer_visitor_excel()
{
	$flag = 0;
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/excel/customer_visitor_report/';

		$config['upload_path'] = './' . $path;
		$config['file_name'] = time().$_FILES['userfile']["name"];
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this->upload->do_upload('userfile')) 
		{
			$error = array('error' => $this->upload-> display_errors());
			$this->session ->set_flashdata('errors', $error['error']);
			redirect("sales-book", "refresh");
		} 
		else 
		{
		$data = array('userfile' => $this->upload->data());
		}
	
		if (!empty($data['userfile']['file_name'])) 
		{
		$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path.$import_xls_file;
		try 
		{
		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
		die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME).'": '.$e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		$email_array=[];
		for ($i=2; $i <= $arrayCount; $i++) 
		{		
		$excel_id = trim($allDataInSheet[$i]['A']);
		$visitor_excel_date = trim($allDataInSheet[$i]['B']);
		$comp_name = trim($allDataInSheet[$i]['C']);
		$contact_person = trim($allDataInSheet[$i]['D']);

			$mobile_num = trim($allDataInSheet[$i]['E']);
			$position = trim($allDataInSheet[$i]['F']);
			$email=trim($allDataInSheet[$i]['G']);
			$location = trim($allDataInSheet[$i]['H']);
			if(!empty($allDataInSheet[$i]['J']))
		$customer_interest = trim($allDataInSheet[$i]['J']);
		
		$check_email=$this->Admin_model->get_data('sales_customer_entry',array('sca_cust_email !='=>'NA','sca_cust_email'=>$email),'','','','','','');
		
		foreach($check_email as $ce)
		{
		//echo $ce->sca_cust_email;		
			if($ce->sca_cust_email==$email)
			{
			$email_array[]=$email;
			}			
		}

			if(empty($customer_interest))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell J.Customer interest cannot be null.Please add the value of customer interest as in the format.<br>";
			}
			//if( (!empty($check_email)))
			//{
			//	$flag=1;
			//$error_string.="You have an error in Row $i of Cell G.Duplicate email .<br>";
			//}
			
		}
				
		if($flag==1)
		{
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/excel/customer_visitor_report/".$import_xls_file);
			redirect('customer-excel-upload','refresh');
		}
		else
		{
		$dwnload_title=$this->input->post('dwnload_title');
		
			$data23=array(
			'excl_title'=>$dwnload_title,
			'excl_file'=>$inputFileName,
			'excl_status'=>"1",
			'excl_type' =>'result');
			$insert_id=$this->Admin_model->insert_data("excel_file_sales_book", $data23);
			 $this->insert_table($allDataInSheet,$insert_id,$email_array);
		}
}


function insert_table($allDataInSheet,$insert_id,$email_array) 
{

	$arrayCount = count($allDataInSheet);
	$flag = 0;
	$vocr_array=array();
	$data_empty_array=array();
	$insert_id_vochr='';
	for($i=2;$i<=$arrayCount;$i++) 
		{			
			$excel_date = trim($allDataInSheet[$i]['B']);

			$new_voc_date=explode('/', $excel_date);///in the format d/m/y , i need is y-m-d.
			if(!empty($new_voc_date[1]))
			$month_voc=str_pad((int) $new_voc_date[1],'2',"0",STR_PAD_LEFT);
			else
				$month_voc='';

			if(!empty($new_voc_date[0]))
			$date_voc=str_pad((int) $new_voc_date[0],'2',"0",STR_PAD_LEFT);


			if(!empty($new_voc_date[2]))
			$year_voc=$new_voc_date[2];
		else
			$year_voc='';

			if(!empty($month_voc) && !empty($date_voc) && !empty($year_voc) )
			{
				$voc_date_2=$year_voc.'-'.$month_voc.'-'.$date_voc;
			}
			else
				$voc_date_2='0000-00-00';

		$comp_name = trim($allDataInSheet[$i]['C']);
		$contact_person = trim($allDataInSheet[$i]['D']);
		$mobile_num = trim($allDataInSheet[$i]['E']);
		$position = trim($allDataInSheet[$i]['F']);
		$email=trim($allDataInSheet[$i]['G']);
		$location = trim($allDataInSheet[$i]['H']);
		$customer_interest = trim($allDataInSheet[$i]['J']);
		$excel_id = trim($allDataInSheet[$i]['A']);

		if(!empty($excel_id) && is_numeric($excel_id) && !empty($email))
		{	
			 $table_data=$this->Sales_book_model->date_time($this->session->userdata['user']['username'],$voc_date_2);

$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first
$time_set=$dt->setTimestamp($timestamp);
$formated_time=$dt->format('H:i:s');


		if(empty($table_data) && !in_array($email,$email_array) )
		{
			$data_array[]=array(
				'sca_staff_id'=>$this->session->userdata['user']['username'],
				'sca_cust_interest'=>$customer_interest,
				'sca_cust_mobile'=>$mobile_num,
				'sca_cust_landline'=>$mobile_num,
				'sca_cust_company'=>$comp_name,
				'sca_cust_email'=>$email,
				'sca_cust_country'=>'228',
				'sca_cust_name'=>$contact_person,
				'sca_cust_designation'=>$position,
				'sca_cust_location'=>$location,
				'sca_dt_created'=>$voc_date_2.' '.$formated_time,
				'sca_dt_updated'=>$voc_date_2.' '.$formated_time,
				'sca_status'=>'1',
				);
			
		}
		// else
		// {
		// 	$this ->session-> set_flashdata('errors', 'Data related to the date already found.Please check the entries you are trying to insert');
		// redirect("customer-excel-upload", "refresh");
		// 	}
		 }
	}
	
$insert_id_vochr=$this->Admin_model->insert_batch_data("sales_customer_entry", $data_array);
			if(!($insert_id_vochr))
			$status = false;
			else
				$status = true;

		if ($status)
			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		redirect("customer-excel-upload", "refresh");	
}

























}