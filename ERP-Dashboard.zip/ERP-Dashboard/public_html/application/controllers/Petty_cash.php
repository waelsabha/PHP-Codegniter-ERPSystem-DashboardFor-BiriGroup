<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Petty_cash extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
		$this->load->library('numbertowordconvertsconver');	
	}

	function create_petty_cash($cbr_id=null)
	{
		if(logged_in())
	{


          $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='create-petty-cash')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'create-petty-cash'));
		$salesman=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales', 'log_status !='=>'0'));
		foreach($salesman as $s)
		{
			$data['salesman'][]=$this->Admin_model->get_data('employee_details',array('ed_login_id'=>$s->log_id));
		}

			$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent IN  (638,620,630,492,596,786,639,640,641,852,1143,245)");////TO GET OPERATING EXPENSE A/C NAMES AND CUSTOMER A/C NAMES COMBINED
			$data['customers']=$sql_cust->result_array();
		
		$data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
		$data['place_supply']=$this->Admin_model->get_data('master_place_supply',array('mps_sts'=>'1'));
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
		$sql2=$this->db->query("SELECT *
FROM master_accounts_tree
WHERE parent = 700
UNION
SELECT * 
FROM master_accounts_tree
WHERE parent IN 
    (SELECT id FROM master_accounts_tree WHERE parent = 700)");
		$data_result_set1=$sql2->result_array();
	//	pre_list($dtt); 

		 	foreach($data_result_set1 as $ds2)
		 	{
		 		//pre_list($ds2['id']);
		 		$data['cash_bank'][]=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>$ds2['id']));
			}
			//unset($data['cash_bank'][0]);
		//	pre_list($data['cash_bank']);
		if(empty($cbr_id))
		{
			$val_recipt=$this->Admin_model->get_data('cash_bank_petty_cash',array('cbr_sts'=>'1'),'','','cbr_id','DESC');
			if(empty($val_recipt))
			$data['doc_num']='PTC 1200';
			else
			{
			$bal_string1=str_replace("PTC ", "", $val_recipt[0]->cbr_doc_no);
			//print_r($bal_string1);
		           $new_id_1=($bal_string1)+1;
		            $data['doc_num']="PTC ".$new_id_1;
			}
			
		}
		else
		{
			$data['result']=$this->Admin_model->get_data('cash_bank_petty_cash',array('cbr_id'=>$cbr_id));
		}
	//	print_r($data['doc_num']);
        $this->load->view('admin/cash_bank/create_petty_cash',$data);

        }
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 

	}

	}

	function get_details_customer_acc()
	{
		$table_id=$this->input->post('table_id');
		$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent IN  (638,620,630,492,596,786,639,640,641,852,1143,245)");////TO GET OPERATING EXPENSE A/C NAMES AND CUSTOMER A/C NAMES COMBINED
			$customers=$sql_cust->result_array();
			$html='<select data-plugin-selectTwo  class="form-control populate custmoer_accounts cust_acc_'.$table_id.' cust'.$table_id.'" name="cbr_customer_acc[]" onchange="get_cust_details('.$table_id.')">
			<option value="">Choose</option>';
		foreach($customers as $cu)
		{
		$html.="<option value=".$cu['id'].">".strtolower($cu['label'])."</option>";
		}
		$html.='</select>';
	echo $html; 	
	}

	function get_details_customer_acc_expense()
	{
		$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent IN  (620,630)");////TO GET OPERATING EXPENSE A/C NAMES AND CUSTOMER A/C NAMES COMBINED
			$customers=$sql_cust->result_array();
		echo json_encode($customers);
	}

	function list_petty_cash()
	{
		if(logged_in())
		{


		  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-petty-cash')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


						$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'list-petty-cash'));
						$sql2=$this->db->query("SELECT cbr.*,mc.mcomp_name,mat.label FROM cash_bank_petty_cash as cbr join master_company as mc on mc.mcomp_id=cbr.cbr_company join master_accounts_tree as mat on mat.id=cbr.cbr_acc WHERE cbr.cbr_sts = '1' order by cbr.cbr_id DESC");
						$data['result']=$sql2->result_array();
						
					   $this->load->view('admin/cash_bank/list_petty_cash',$data);	

        }
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 



		}


	}

	function delete_petty_cash($cbr_id)
	{
		if(logged_in())
		{

		$cash_bank_details=$this->Admin_model->get_data('cash_bank_petty_cash',array('cbr_id'=>$cbr_id));
		$acc_tx_details=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_doc_no'=>$cash_bank_details[0]->cbr_doc_no,'atx_sts'=>'1'));
		if(!empty($acc_tx_details))
		{
			foreach($acc_tx_details as $actx)
			{
				$acc_bal_tx[]=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$actx->atx_id,'actd_sts'=>'1'));
			}
	
			if(!empty($acc_bal_tx))
			{
				foreach($acc_bal_tx as $index=>$acb)
				{
					if(!empty($acb))
					{
					$acc_tx_details_2=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$acb->actb_to_id));
					$current_paid_amount=$acc_tx_details_2[0]->atx_paid_amount;
					$current_bal_amount=$acc_tx_details_2[0]->atx_bal_amount;
					$new_paid_amount=$current_paid_amount-$acb->actb_paid_amount;
					$new_bal_amount=$current_bal_amount+$acb->actb_paid_amount;
					$array_new_data=array(
						'atx_paid_amount'=>$new_paid_amount,
						'atx_bal_amount'=>$new_bal_amount,
					);
					$this->Admin_model->update_data('account_all_tx',$array_new_data,array('atx_id'=>$acb->actb_to_id));
					$this->Admin_model->update_data('account_tx_bal_data',array('actd_sts'=>'0'),array('actb_to_id'=>$acb->actb_to_id));
					$this->Admin_model->update_data('account_tx_bal_data',array('actd_sts'=>'0'),array('actb_tx_id'=>$acb->actb_tx_id));
					}
				}
			}
		}
	 $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_main_id'=>$cbr_id,'atx_doc_no'=>$cash_bank_details[0]->cbr_doc_no));
	 	$this->Admin_model->update_data('cash_bank_petty_cash',array('cbr_sts'=>'0'),array('cbr_id'=>$cbr_id));
	
			$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'petty cash deleted',
				'act_status'=>'petty cash id '.$cbr_id.' deleted',
				'act_petty_cash_id'=>$cbr_id
			);
			  $this->Admin_model->insert_data('activities',$activity_data);

			  $this->session->set_flashdata('success', 'Data Successfully deleted');
		redirect('list-petty-cash');
		}
	}
	

	function submit_petty_cash()
	{
		$page_type=$this->input->post('page_type');
		$edited_id=$this->input->post('added_cbr_id');
	/////for upload files//////
$image = array();
	$uploadImgData = array();

  $ImageCount = count($_FILES['files']['name']);
 
        for($i = 0; $i < $ImageCount; $i++)
        {     
            $_FILES['file']['name']       = $_FILES['files']['name'][$i];
            $_FILES['file']['type']       = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['files']['error'][$i];
            $_FILES['file']['size']       = $_FILES['files']['size'][$i];

            // File upload configuration
            $uploadPath = 'uploads/payments_files/';
         $config['file_name'] = time().preg_replace("/[^a-z0-9\_\-\.]/i", '', basename($_FILES["files"]["name"][$i]));
            $config['upload_path'] = $uploadPath;
            //$config['max_size'] = '3000000';////3mb
            $config['allowed_types'] = '*';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'business_card');
            $this->business_card->initialize($config);

            // Upload file to server
            if($this->business_card->do_upload('file'))
            {
              // Uploaded file data
                $imageData = $this->business_card->data();
              
                $uploadImgData[]=$imageData['file_name'];
              
                if(!empty($uploadImgData))
                {
              		$data_image=implode(',',$uploadImgData);
              	}
              	else
              	{
              		 $data_image='';
    			}	
                //print_r($uploadImgData);
            } 
            else
            {
           	 if(!empty($this->input->post('files_added')))
            		{
            		$data_image=$this->input->post('files_added');
    				}
            		else
           		{
            		$data_image='';
    			}
            }      
        } 
////end of for upload files//////////
 $main_date=$this->input->post('cbr_date');
$main_date1=explode('/',$main_date);
			$month1=$main_date1[0];
			$date1=$main_date1[1];
			$year1=$main_date1[2];
$new_formated_date1=$year1.'-'.$month1.'-'.$date1;

$cash_bank_acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$this->input->post('cbr_acc')));

		$data['cbr_doc_no']=$this->input->post('cbr_doc_no');
		
		$data['cbr_acc']=$this->input->post('cbr_acc');
		$data['cbr_company']=$this->input->post('cbr_company');
		$data['cbr_currency']=$this->input->post('cbr_currency');
		$data['cbr_rate_currency']=$this->input->post('cbr_rate_currency');
		$data['cbr_bill_no']=$this->input->post('cbr_bill_no');
		$data['cbr_place_supply_id']=$this->input->post('cbr_place_supply_id');
		$data['cbr_jurisdication']=$this->input->post('cbr_jurisdication');

		$data['cbr_attachments']=$data_image;
		$data['cbr_salesman']=$this->input->post('hid_salesman');
		$data['cbr_customer_acc']=$this->input->post('hid_customer');
		$data['cbr_amount']=$this->input->post('hid_amounts');
		$data['cbr_ref']=$this->input->post('hid_ref');
		$data['cbr_remark']=$this->input->post('hid_remark');
		$data['cbr_tax_code']=$this->input->post('hid_tax_code');
		$data['cbr_vat']=$this->input->post('hid_vat');
		$data['cbr_tot_amount']=$this->input->post('cbr_tot_amount');
		$data['cbr_sts']='1';	
		$data['cbr_dt_updt']=get_date_time();
		$data['cbr_narration']=$this->input->post('cbr_narration');
	$data['cbr_tot_vat_amount']=$this->input->post('cbr_tot_vat_amount');
	//pre_list($data);
	if(empty($edited_id))////willl insert
	{
		$document_bal_number=str_replace("PTC ", "", $this->input->post('cbr_doc_no'));
		$data['cbr_doc_number']=$document_bal_number;
	}

$salesman_vlues=explode('|#|', $this->input->post('hid_salesman'));
	$customer_account=explode('|#|',$this->input->post('hid_customer'));
	$customer_amounts=explode('|#|',$this->input->post('hid_amounts'));
	$customer_remark=explode('|#|',$this->input->post('hid_remark'));
	$customer_refs=array_filter(explode('|#|',$this->input->post('hid_ref')));
	$vat_amounts=explode('|#|',$this->input->post('hid_vat'));
	$sales_inv_id=array_filter(explode('|#|',$this->input->post('sales_inv_id')));
	$sales_inv_amount=array_filter(explode('|#|',$this->input->post('sales_inv_amount')));
	$sales_inv_amount_paid=array_filter(explode('|#|',$this->input->post('sales_inv_amount_paid')));
	$sales_doc_num=array_filter(explode('|#|',$this->input->post('sales_doc_num')));
	$tot_inv_amount_paid_from_ref=array_sum($sales_inv_amount_paid);

	if(empty($edited_id))////willl insert
	{
	$insert_id=$this->Admin_model->insert_data('cash_bank_petty_cash',$data);
	//$insert_id='12';
		if(!empty($insert_id))
		{
		$this->Admin_model->update_data('cash_bank_petty_cash',array('cbr_insert_date'=>date('Y-m-d'),'cbr_dt_crtd'=>get_date_time(),'cbr_date'=>$new_formated_date1,'cbr_current_status'=>'approved','cbr_created_by'=>$this->session->userdata['user']['username']),array('cbr_id'=>$insert_id) );

			$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'Petty cash created',
				'act_status'=>'Petty cash id '.$insert_id.' created,also added to account_master_trasaction table',
				'act_petty_cash_id'=>$insert_id
			);
			  $this->Admin_model->insert_data('activities',$activity_data);

		$this->session->set_flashdata('success', 'Data Successfully inserted');
		}
	}
	else////will updATE
	{
		$this->Admin_model->update_data('cash_bank_petty_cash',$data,array('cbr_id'=>$edited_id) );

		$current_recpt_amount=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$edited_id,'atx_doc_no'=>$this->input->post('cbr_doc_no'),'atx_type_tx'=>'Petty_Cash'));
		if(!empty($current_recpt_amount))
			{
				foreach($current_recpt_amount as $index=>$cra)
				{
					$cust_id_array[]=$cra->atx_cust_id;
					$tx_id_array[]=$cra->atx_id;
					$cust_tx_amount_array[]=$cra->atx_tot_amount;
					$cust_tx_bal_amount_array[]=$cra->atx_bal_amount;
					$current_sales_bal_amount[$index][]=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$cra->atx_id));
					
					if(!empty($current_sales_bal_amount))
					{
						foreach($current_sales_bal_amount[$index] as $index2=>$csb)
						{
							$acc_tx_details_2=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$csb->actb_to_id));
							$current_paid_amount=$acc_tx_details_2[0]->atx_paid_amount;
							$current_bal_amount=$acc_tx_details_2[0]->atx_bal_amount;
							$new_paid_amount=$current_paid_amount-$csb->actb_paid_amount;
							$new_bal_amount=$current_bal_amount+$csb->actb_paid_amount;
							$array_new_data=array(
						'atx_paid_amount'=>$new_paid_amount,
						'atx_bal_amount'=>$new_bal_amount,
					);
					$this->Admin_model->update_data('account_all_tx',$array_new_data,array('atx_id'=>$csb->actb_to_id));
					$this->Admin_model->delete_data('account_tx_bal_data',array('actb_tx_id'=>$csb->actb_tx_id));

						}	
					}
				}
 			}

			$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'petty cash edited details',
				'act_status'=>'petty cash id '.$edited_id.' edited details',
				'act_petty_cash_id'=>$edited_id
			);
			  $this->Admin_model->insert_data('activities',$activity_data);

		$this->session->set_flashdata('success', 'Data Successfully updated');	
	}

/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////	
if(!empty($insert_id) || !empty($edited_id) )
		{
			if(!empty($insert_id))
			{
				$pdr_rcpt_id=$insert_id;
			}
			elseif (!empty($edited_id)) 
			{
				$pdr_rcpt_id=$edited_id;
			}
			else
			{
				$pdr_rcpt_id='';
			}
	if(!empty($pdr_rcpt_id))
	{	
	foreach($customer_account as $index=>$c_acc)
			{
				if($page_type=="ksa")
					{
						$tot_amount=($customer_amounts[$index]/1.15);
						$vat_amount_tot=$tot_amount*0.15;
					}
					elseif($page_type=="uae")
					{
						$tot_amount=($customer_amounts[$index]/1.05);
						$vat_amount_tot=$tot_amount*0.05;
					}
					elseif($page_type=="dragon")
					{
						$tot_amount=($customer_amounts[$index]/1.05);
						$vat_amount_tot=$tot_amount*0.05;
					}		
					else
					{
						$tot_amount=$customer_amounts[$index];
						$vat_amount_tot=0.00;
					}

				$cusotmer_acc_id=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$c_acc));
				//print_r($cusotmer_acc_id);
					$data_tx['atx_user_created']=$this->session->userdata['user']['username'];
					$data_tx['atx_type_tx']='Petty_cash';
					$data_tx['atx_date']=$new_formated_date1;
					$data_tx['atx_doc_no']=$this->input->post('cbr_doc_no');
					$data_tx['atx_main_id']=$pdr_rcpt_id;
					$data_tx['atx_cust_id']=$c_acc;
					$data_tx['atx_acc_id']=$this->input->post('cbr_acc');
					$data_tx['atx_tot_amount']=number_format((float)$tot_amount, 2, '.', '');
					if(empty($edited_id))	
					$data_tx['atx_paid_amount']='0';
					// $data_tx['atx_bal_amount']=$customer_amounts[$index];
					$data_tx['atx_dt_updt']=get_date_time();
					$data_tx['atx_sts']='1';
					$data_tx['atx_vat_amount']=number_format((float)$vat_amount_tot, 2, '.', '');
					$data_tx['atx_amount_type']='Income';

					$data_tx['atx_region']=$page_type;
					$data_tx['atx_narration']=$this->input->post('cbr_narration');
					$data_tx['atx_salesman']=$salesman_vlues[$index];
					$data_tx['atx_bill_no']=$this->input->post('cbr_bill_no');
					$data_tx['atx_currency_value']=$this->input->post('cbr_rate_currency');
					$data_tx['atx_currency_type']=$this->input->post('cbr_currency');


	///////////////here logic to update the same table, for recipt, with the amount paid for referecnes(not include any new-ref here)//  
					if(!empty($sales_inv_amount_paid[$index]))
							{
							$sales_inv_amount_total=explode('|$$|',$sales_inv_amount_paid[$index]);
							if(!empty(array_sum($sales_inv_amount_total)))
								{
									$data_final_bal_amount=$customer_amounts[$index]-array_sum($sales_inv_amount_total);
									$data_tx['atx_bal_amount']=number_format((float)$data_final_bal_amount, 2, '.', '');
									$data_tx['atx_paid_amount']=array_sum($sales_inv_amount_total);
								}
								else
								{
									$data_tx['atx_bal_amount']=number_format((float)$customer_amounts[$index], 2, '.', '');
									$data_tx['atx_paid_amount']='0';
								}
							}
							else
							{
								if($cusotmer_acc_id[0]->parent=='620')////MEANS THIS IS UAE OPERATING EXPENSE
								{
									$data_tx['atx_bal_amount']='0';
									$data_tx['atx_paid_amount']=number_format((float)$customer_amounts[$index], 2, '.', '');
									$this->Admin_model->update_data('cash_bank_petty_cash',array('cbr_current_status'=>'approved'),array('cbr_id'=>$pdr_rcpt_id));
								}
								elseif($cusotmer_acc_id[0]->parent=='630')///THIS IS KSA OPERATING EXPENSE
								{
									$data_tx['atx_bal_amount']='0';
									$data_tx['atx_paid_amount']=number_format((float)$customer_amounts[$index], 2, '.', '');
									$this->Admin_model->update_data('cash_bank_petty_cash',array('cbr_current_status'=>'approved'),array('cbr_id'=>$pdr_rcpt_id));
								}
								else
								{
								$data_tx['atx_bal_amount']=number_format((float)$customer_amounts[$index], 2, '.', '');
								$data_tx['atx_paid_amount']='0';
								}
							}
					
				if(!empty($edited_id))	
				{
					if(in_array($c_acc, $cust_id_array))
					{
						$insert_id_acc_tx[]=$current_recpt_amount[$index]->atx_id;	
						$this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_id'=>$current_recpt_amount[$index]->atx_id));
					}
					else
					{
						$insert_id_acc_tx[]=$this->Admin_model->insert_data('account_all_tx',$data_tx);
					}
				}
				else
				{
					$insert_id_acc_tx[]=$this->Admin_model->insert_data('account_all_tx',$data_tx);
				}
					//pre_list($data_tx);
			}	
	
		 /////////////////vat i/p account data //////////////////
			foreach($customer_account as $index=>$c_acc)
			{	 
				
				$data_tx=array(
					'atx_user_created'=>$this->session->userdata['user']['username'],
					'atx_type_tx'=>'Vat_IP',
					'atx_date'=>$new_formated_date1,
					'atx_doc_no'=>$this->input->post('cbr_doc_no'),
					'atx_main_id'=>$pdr_rcpt_id,
					'atx_acc_id'=>'1013',
					'atx_cust_id'=>$c_acc,
					'atx_tot_amount'=>number_format((float)$vat_amount_tot, 2, '.', ''),
					'atx_paid_amount'=>'0',
					'atx_bal_amount'=>number_format((float)$vat_amount_tot, 2, '.', ''),
					'atx_dt_updt'=>get_date_time(),
					'atx_sts'=>'1',
					'atx_amount_type'=>'Expense',
					'atx_tranfer_type'=>'petty_cash',
					'atx_region'=>$page_type,
					'atx_narration'=>$this->input->post('cbr_narration'),
					'atx_salesman'=>$salesman_vlues[$index],
					'atx_bill_no'=>$this->input->post('cbr_bill_no'),
					'atx_currency_value'=>$this->input->post('cbr_rate_currency'),
					'atx_currency_type'=>$this->input->post('cbr_currency'),
				);	
				// echo "vat data";
				// 	pre_list($data_tx);
					if(!empty($edited_id))
					{	
						if(in_array($c_acc, $cust_id_array))
						{
							$this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_main_id'=>$edited_id,'atx_doc_no'=>$this->input->post('cbr_doc_no'),'atx_type_tx'=>'Vat_IP' ));
						}
						else
						{
							$insert_id_acc_tx_vat[]=$this->Admin_model->insert_data('account_all_tx',$data_tx);
						}
					}
					else
					{
					$insert_id_acc_tx_vat[]=$this->Admin_model->insert_data('account_all_tx',$data_tx);		
					}

				}
			
			foreach($sales_inv_id as $index=>$si)
			{		
		//	print_r($insert_id_acc_tx[$index]);	
			$sales_inv_id_extra=explode('|$$|',$si);
			$sales_inv_amount_extra=explode('|$$|',$sales_inv_amount[$index]);
			$sales_inv_amount_paid_extra=explode('|$$|',$sales_inv_amount_paid[$index]);
			$sales_inv_doc_num_extra=explode('|$$|',$sales_doc_num[$index]);

		if(!empty($sales_inv_amount_paid[$index]))
			{
			foreach($sales_inv_id_extra as $index2=>$si2)
				{
					if(!empty($sales_inv_amount_paid_extra[$index2]))
					{
						$amount_paid_till_now=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$si2));
							$total_paid_amount_from_another_ref[]=$sales_inv_amount_paid_extra[$index2];
			  		$bal_amount_sales_inv=$sales_inv_amount_extra[$index2]-$sales_inv_amount_paid_extra[$index2];
			  		
			  		$data_si_array=array(
			  			'atx_paid_amount'=>$amount_paid_till_now[0]->atx_paid_amount+$sales_inv_amount_paid_extra[$index2],
			  			'atx_bal_amount'=>$bal_amount_sales_inv,
			  		);
		  	$this->Admin_model->update_data('account_all_tx',$data_si_array,array('atx_id'=>$si2));

				$data_tx_bal=array(
					'actb_tx_id'=>$insert_id_acc_tx[$index],
					'actb_to_type'=>$sales_inv_doc_num_extra[$index2],
					'actb_paid_amount'=>$sales_inv_amount_paid_extra[$index2],
					'actb_to_id'=>$si2,
					'actd_sts'=>'1',
					'actb_user_created'=>$this->session->userdata['user']['username'],
				);	
				//pre_list($data_tx_bal);
			$this->Admin_model->insert_data('account_tx_bal_data',$data_tx_bal);
			  		}
			  	}
			}
		}
/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////	
		redirect('list-petty-cash');
		}
		else
		{
		 $this->session->set_flashdata('errors', 'Error on data found. Please try again.');
		redirect('list-petty-cash');
		}
	}  

}

function get_doc_details()
{
	$cbr_id=$this->input->post('main_id');

$dataa=$this->Admin_model->get_data('cash_bank_petty_cash',array('cbr_id'=>$cbr_id));
	if($dataa)
			{
				$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->cbr_company));
				$acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->cbr_acc));
				$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->cbr_currency));
				$place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->cbr_place_supply_id));
				$jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->cbr_jurisdication));

				$customer_list=explode('|#|',$dataa[0]->cbr_customer_acc);
				foreach($customer_list as $cs)
				{
					$data_cl[]=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$cs));
				}
				
				$salesman_list=explode('|#|',$dataa[0]->cbr_salesman);
				foreach($salesman_list as $sl)
				{
					$data_sl[]=$this->Admin_model->get_data('employee_details',array('ed_id'=>$sl));
				}

				$account_tx_data=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_type_tx'=>'Petty_Cash'));
				if(!empty($account_tx_data))
				{
					$account_bal_data_1=$this->Admin_model->get_data('account_tx_bal_data',array('actb_to_id'=>$account_tx_data[0]->atx_id));
					if(!empty($account_bal_data_1))
					{
						foreach($account_bal_data_1 as $abd)
						{
							$tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_tx_id));
						}
					}
					else
					{
						$account_bal_data_2=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_data[0]->atx_id));
						if(!empty($account_bal_data_2))
						{
							foreach($account_bal_data_2 as $abd)
							{
								$tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_to_id));
							}	
						}
					}
				}
					
				$cust_amount_list=explode('|#|',$dataa[0]->cbr_amount);
					$ref_list=explode('|#|',$dataa[0]->cbr_ref);
					$rmk_list=explode('|#|',$dataa[0]->cbr_remark);
					$tax_list=explode('|#|',$dataa[0]->cbr_tax_code);
					$vat_per_list=explode('|#|',$dataa[0]->cbr_vat);

					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Petty Cash Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->cbr_doc_no."</p>";
					$html.="<p>User Created: ".$dataa[0]->cbr_created_by."</p>";
					$html.="<p>Date: ".$dataa[0]->cbr_date."</p>";
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					
					$html.="<p style='color:blue'><b>Linked to :</b></p>";
					if(!empty($tx_data_related))
					{
						foreach($tx_data_related as $tx)
						{
							$html.="<p style='color:blue'>".$tx[0]->atx_doc_no."</p>";
						}
					}	
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Cash &amp; Bank : ".$acc_details[0]->label."</p>";
					$html.="<p>Company: ".$company_details[0]->mcomp_name."</p>";
					$html.="<p>Bill No.: ".$dataa[0]->cbr_bill_no."</p>";
					$html.="<p>Narration: ".$dataa[0]->cbr_narration."</p>";
					$html.="<p>Place of Supply: ".$place_supply[0]->mps_name."</p>";
					$html.="<p>Jurisdiction: ".$jurisdaction[0]->mps_name."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Total Amount : ".number_format((float)$dataa[0]->cbr_tot_amount+$dataa[0]->cbr_tot_vat_amount, 2, '.', '')."</p>";
				
				$html.="<p>Current Status: ".$dataa[0]->cbr_current_status."</p>";
					$html.="<p>Attachements: <a href='".base_url('uploads/payments_files/'.$dataa[0]->cbr_attachments)."' target='_blank'> ".$dataa[0]->cbr_attachments."</a></p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

					$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th><th>Salesman</th><th>Account</th><th>Amounts</th><th>Reference</th><th>Remark</th><th>Tax Code</th><th>Vat%</th>
					<th>Amount Total</th></thead>";
					$html.="<tbody>";
					foreach($data_cl as $key=>$d)
					{
						if($vat_per_list[$key]=='15')
						{
						$new_tot_value=$cust_amount_list[$key]/1.15;
						$vat_amount_tot[]=$new_tot_value*0.15;
						$amount_tot[]=$cust_amount_list[$key]/1.15;
						$new_vat_value=$new_tot_value*0.15;
						$final_tot_amount[]=$cust_amount_list[$key];
						}
						elseif($vat_per_list[$key]=='5')
						{
						$new_tot_value=$cust_amount_list[$key]/1.05;
						$vat_amount_tot[]=$new_tot_value*0.05;
						$amount_tot[]=$cust_amount_list[$key]/1.05;
						$new_vat_value=$new_tot_value*0.05;
						$final_tot_amount[]=$cust_amount_list[$key];
						}
						else
						{
							if(empty($vat_per_list[$key]))
							{
							$new_tot_value=$cust_amount_list[$key];
							$vat_amount_tot[]=0;
							$amount_tot[]=$cust_amount_list[$key];
							$new_vat_value=0;
							$final_tot_amount[]=$cust_amount_list[$key];
							}
						}
						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$data_sl[$key][0]->ed_name."</td>";
						$html.="<td>".$d[0]->label."</td>";
						$html.="<td>".number_format((float)$new_tot_value, 2, '.', '')."</td>";
						$html.="<td>".$ref_list[$key]."</td>";
						$html.="<td>".$rmk_list[$key]."</td>";
						$html.="<td>".$tax_list[$key]."</td>";
						$html.="<td>".number_format((float)$new_vat_value, 2, '.', '')."</td>";
						$html.="<td>".number_format((float)$cust_amount_list[$key], 2, '.', '')."</td>";
						$html.="</tr>";
					}

					$vat_sum=array_sum($vat_amount_tot);
					$html.="</tbody>";
					$html.="<tfoot>";
					$html.="<tr>";
					
					$html.="<td colspan='3'>Totals:</td>";
					
					$html.="<td>".number_format((float)array_sum($amount_tot), 2, '.', '')."</td>";
					$html.="<td></td>";
					$html.="<td></td>";
					$html.="<td></td>";
					$html.="<td>".number_format((float)array_sum($vat_amount_tot), 2, '.', '')."</td>";
					$html.="<td>".number_format((float)array_sum($final_tot_amount), 2, '.', '')."</td>";
					
					$html.="</tr>";
					$html.="</tfoot>";
					$html.="</table>";
					
					/*** start of table  ***/
					echo $html;
			}	
}















}