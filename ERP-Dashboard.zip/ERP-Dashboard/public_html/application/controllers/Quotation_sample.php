<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quotation_sample extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','datatable'));	
		$this->load->library('numbertowordconvertsconver');			
		$this->load->model(array('Second_db_model','Sales_book_model','Datatables'));
		$this->load->model('Third_db_model','tm');		
	}


   public function quotationList()
    {
    	$page_type=$this->input->post('page_type');
            $this->load->model('datatables');
            $this->datatables->table = 'qoutattion_entry';
            $this->datatables->column_order = array('q_ref_no', 'q_user_id', 'q_date', 'q_cust_comp', 'q_cust_name','q_id','q_sub',);
            $this->datatables->column_search = array('q_ref_no', 'q_user_id', 'q_date', 'q_cust_comp', 'q_cust_name','q_id','q_sub','q_current_status','q_tendor_no');
            $this->datatables->order = array('q_id' => 'desc');
		
		if(empty($page_type))
		{
		if($this->session->userdata['user']['main_dept']=="Sales")
		{
			if($this->session->userdata['user']['user_desig']!="Team-lead")
				$where=array('q_sts'=>'1','q_user_id'=>$this->session->userdata['user']['username'],'q_project'=>'1');
			else
				$where=array('q_sts'=>'1','q_project'=>'1'); 			
 		}
 		elseif( ($this->session->userdata['user']['main_dept']=="Main") ||  ($this->session->userdata['user']['main_dept']=="Accounts") )
		 {
		  $where=array('q_sts'=>'1','q_project'=>'1');
		 }
		 else
		 {
		 $where=array('q_sts'=>'1','q_user_id'=>$this->session->userdata['user']['username'],'q_project'=>'1');
		 }
		}
		else
		{
			if($page_type=="rta")
			{
				if($this->session->userdata['user']['main_dept']=="Sales")
				{
					if($this->session->userdata['user']['user_desig']!="Team-lead")
						$where=array('q_sts'=>'1','q_user_id'=>$this->session->userdata['user']['username'],'q_project'=>'2');
					else
						$where=array('q_sts'=>'1','q_project'=>'2'); 			
		 		}
		 		elseif( ($this->session->userdata['user']['main_dept']=="Main") ||  ($this->session->userdata['user']['main_dept']=="Accounts") )
				 {
				  $where=array('q_sts'=>'1','q_project'=>'2');
				 }
				 elseif( ($this->session->userdata['user']['main_dept']=="Project Department"))
				 {
				 	if($this->session->userdata['user']['user_desig']=="RTA")
				  	$where=array('q_sts'=>'1','q_project'=>'2');
				 }
				 else
				 {
				 $where=array('q_sts'=>'1','q_user_id'=>$this->session->userdata['user']['username'],'q_project'=>'2');
				 }
			}
			else
			{
				if($this->session->userdata['user']['main_dept']=="Sales")
				{
					if($this->session->userdata['user']['user_desig']!="Team-lead")
						$where=array('q_sts'=>'1','q_user_id'=>$this->session->userdata['user']['username'],'q_project'=>'3');
					else
						$where=array('q_sts'=>'1','q_project'=>'3'); 			
		 		}
		 		elseif( ($this->session->userdata['user']['main_dept']=="Main") ||  ($this->session->userdata['user']['main_dept']=="Accounts") )
				 {
				  $where=array('q_sts'=>'1','q_project'=>'3');
				 }
				 elseif( ($this->session->userdata['user']['main_dept']=="Project Department"))
				 {
				 	if($this->session->userdata['user']['user_desig']=="PWR")
				  	$where=array('q_sts'=>'1','q_project'=>'3');
				 }
				 else
				 {
				 $where=array('q_sts'=>'1','q_user_id'=>$this->session->userdata['user']['username'],'q_project'=>'3');
				 }
			}
		}
            // get all get_kb_info
            $fetch_data = make_datatables($where);

            $data = array();

$total_vat_sum_prd='';
$total_discount_sum_prd='';
$total_sum_prd='';
            foreach ($fetch_data as $_key => $v_kb_category) {
                $action = null;
                $html=null;

$qnty=explode('|#|',$v_kb_category->q_prd_qnty);
$unit_price=explode('|#|',$v_kb_category->q_prd_price);
$vat=explode('|#|',$v_kb_category->q_prd_vat);  
$total=explode('|#|',$v_kb_category->q_prd_tot);
$dicount_per=$v_kb_category->q_discount_per;

$color='';
			switch($v_kb_category->q_current_status)
			{
			case 'Inquiry':
			$color='#1567a0';
			break;
			
			case 'Quotation Issued':
			$color='#f50057';
			break;
			case 'Sent to Customer':
			$color='#ffc107';
			break;
			case '1st follow up':
			$color='#ffc107';
			break;
			case '2nd follow up':
			$color='#ffc107';
			break;
			case '3rd follow up':
			$color='#ffc107';
			break;
			
			case 'Converted to PI':
			$color='#00cc00';
			break;
			
			case 'On hold Till':
			$color='#c1c1b9';
			break;
			
			case 'Lost':
			$color='#ff3200';
			break;
			
			default:
			$color='#f50057';
			break;
			
			}

                $sub_array = array();

                $ref_details = $v_kb_category->q_ref_no;
                if(!empty($v_kb_category->q_tendor_no))
                	$ref_details.='<br><p><b>Tender No.'.$v_kb_category->q_tendor_no.'</b></p>';
                $sub_array[]=$ref_details;
                $sub_array[] = $v_kb_category->q_user_id;
                  $sub_array[] = $v_kb_category->q_date;
                  $sub_array[] = $v_kb_category->q_cust_comp.'<br/> <b> Sub:</b>'.$v_kb_category->q_sub;
                  $sub_array[] = $v_kb_category->q_cust_name;
    if(empty($v_kb_category->q_current_status))
	{
				$html='<div class="btn-group">
  <button type="button" class="btn btn-sm" style="background-color:'.$color.';color:white;">Quotation Issued</button>
  <button type="button" class="btn btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color:'.$color.';color:white;">
    <span class="fa fa-caret-down"></span>
  </button>
   <div class="dropdown-menu">
    <a class="dropdown-item" onclick="add_note_sts('."'".$v_kb_category->q_id.",Sent to Customer'".');">Sent to Customer</a><div class="dropdown-divider"></div>
    <a class="dropdown-item" onclick="add_note_sts('."'".$v_kb_category->q_id.",1st follow up'".');">1st follow up</a><div class="dropdown-divider"></div>
    <a class="dropdown-item" onclick="add_note_sts('."'".$v_kb_category->q_id.",2nd follow up'".');">2nd follow up</a><div class="dropdown-divider"></div>
    <a class="dropdown-item" onclick="add_note_sts('."'".$v_kb_category->q_id.",3rd follow up'".');">3rd follow up</a><div class="dropdown-divider"></div>
    <a class="dropdown-item" href="'.base_url("quotation_sts/5/".$v_kb_category->q_id).'">Converted to PI</a><div class="dropdown-divider"></div>
    <a class="dropdown-item" onclick="due_till_date('."'".$v_kb_category->q_id."'".')">On hold Till</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " onclick="lost_reason('."'".$v_kb_category->q_id."'".')">Lost</a>
  </div>
</div>';
}
elseif($v_kb_category->q_current_status=="Inquiry")
{
	$html='<div class="btn-group">
  <button type="button" class="btn btn-sm" style="background-color:'.$color.';color:white;">'.$v_kb_category->q_current_status.'</button>
  <button type="button" class="btn btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color:'.$color.';color:white;">
    <span class="fa fa-caret-down"></span>
  </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="'.base_url("edit_quotation/".$v_kb_category->q_id).'">Convert to quotation</a><div class="dropdown-divider"></div>
 </div>';
}
else
{
	$html='<div class="btn-group">
  <button type="button" class="btn btn-sm" style="background-color:'.$color.';color:white;">'.$v_kb_category->q_current_status.'</button>
  <button type="button" class="btn btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color:'.$color.';color:white;">
    <span class="fa fa-caret-down"></span>
  </button>
  <div class="dropdown-menu">';
  if($v_kb_category->q_current_status=="Quotation Issued")
  {
    $html.='<a class="dropdown-item " onclick="add_note_sts('."'".$v_kb_category->q_id.",Sent to Customer'".');">Sent to Customer</a><div class="dropdown-divider"></div>';

	}
	else if($v_kb_category->q_current_status=="Sent to Customer")
  {
   $html.=' <a class="dropdown-item " onclick="add_note_sts('."'".$v_kb_category->q_id.",1st follow up'".');">1st follow up</a><div class="dropdown-divider"></div>';
   $html.='<a class="dropdown-item " href="'.base_url("quotation_sts/5/".$v_kb_category->q_id).'">Converted to PI</a><div class="dropdown-divider"></div>';
    $html.=' <a class="dropdown-item" onclick="due_till_date('."'".$v_kb_category->q_id."'".')">On hold Till</a>
    <div class="dropdown-divider"></div>';
	}
		else if($v_kb_category->q_current_status=="1st follow up")
  {
    $html.='<a class="dropdown-item " onclick="add_note_sts('."'".$v_kb_category->q_id.",2nd follow up'".');">2nd follow up</a><div class="dropdown-divider"></div>';
    $html.='<a class="dropdown-item " href="'.base_url("quotation_sts/5/".$v_kb_category->q_id).'">Converted to PI</a><div class="dropdown-divider"></div>';

    $html.=' <a class="dropdown-item" onclick="due_till_date('."'".$v_kb_category->q_id."'".')">On hold Till</a>
    <div class="dropdown-divider"></div>';
}
else if($v_kb_category->q_current_status=="2nd follow up")
  {
   $html.=' <a class="dropdown-item " onclick="add_note_sts('."'".$v_kb_category->q_id.",3rd follow up'".');">3rd follow up</a><div class="dropdown-divider"></div>';
   $html.='<a class="dropdown-item " href="'.base_url("quotation_sts/5/".$v_kb_category->q_id).'">Converted to PI</a><div class="dropdown-divider"></div>';

    $html.=' <a class="dropdown-item" onclick="due_till_date('."'".$v_kb_category->q_id."'".')">On hold Till</a>
    <div class="dropdown-divider"></div>';
}
else if($v_kb_category->q_current_status=="3rd follow up")
  {
  	 $html.='<a class="dropdown-item " href="'.base_url("quotation_sts/5/".$v_kb_category->q_id).'">Converted to PI</a><div class="dropdown-divider"></div>';

    $html.=' <a class="dropdown-item" onclick="due_till_date('."'".$v_kb_category->q_id."'".')">On hold Till</a>
    <div class="dropdown-divider"></div>';
  }
  else if($v_kb_category->q_current_status=="On hold Till")
  {
  	 $html.='<a class="dropdown-item " onclick="add_note_sts('."'".$v_kb_category->q_id.",Sent to Customer'".');">Sent to Customer</a><div class="dropdown-divider"></div>';
  	  $html.='<a class="dropdown-item " href="'.base_url("quotation_sts/5/".$v_kb_category->q_id).'">Converted to PI</a><div class="dropdown-divider"></div>';
  }
else{}
    $html.='<a class="dropdown-item " onclick="lost_reason('."'".$v_kb_category->q_id."'".')">Lost</a>';
  $html.=' </div>
</div>';
}

		if($v_kb_category->q_current_status=="On hold Till")
		{
		$html.='<br/>Hold till:'.$v_kb_category->sts_hold_date;
		}
		elseif($v_kb_category->q_current_status=="Lost")
		{
		$html.='<br/>Reason:'.$v_kb_category->lost_note;
		}
		elseif(!empty($v_kb_category->q_current_sts_note)  )
		{
			if(($v_kb_category->q_current_status !='Lost') && ($v_kb_category->q_current_status !='Converted to PI'))
			{
			$sts_note=$v_kb_category->q_current_sts_note;

			if(!empty($sts_note) )
			{
				//print_r($sts_note);	
				$notes_exploded=explode('$#$',$sts_note);
				if(!empty($notes_exploded[3]))
				{
					$next_follow_up_date=explode(':', $notes_exploded[3]);
					if(!empty($next_follow_up_date[1]))
					{
						$current_date=date('m/d/Y');

			 		$date_diff=strtotime($current_date)-strtotime($next_follow_up_date[1]);
			        $final_date_diff=round($date_diff / (60 * 60 * 24));
					    if($final_date_diff>=1)
					     {
						$glow_val='style="background-color: #47a447;
					  color: white;
					  -webkit-animation: glowing 1500ms infinite;
					  -moz-animation: glowing 1500ms infinite;
					  -o-animation: glowing 1500ms infinite;
					  animation: glowing 1500ms infinite;"';
						}
						else
						{
							$glow_val='';
						}
					}
					else
					{
						$glow_val='';
					}
					$html.='<br/><b> Next follow-up Date: '.$next_follow_up_date[1].' <b><br/><button type="button" class="label label-lg label-success " '.$glow_val.'  onclick="get_more_note_info('."'".$v_kb_category->q_id."'".')">Click for more info </button>';	
				}
				else
				{
					$glow_val='';
					$html.='<br/> Follow up info:<button type="button" class="label label-lg label-success " '.$glow_val.'  onclick="get_more_note_info('."'".$v_kb_category->q_id."'".')">Click for more info </button>';		
				}
	
			}
			else
			{}
		   }
		}			
		else{}


    



				$sub_array[] = $html;




               $action.='<div class="dropdown-primary dropdown">
<button class="btn btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >Action</button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">

<a class="dropdown-item waves-light" onclick="view_quotation_data('."'".$v_kb_category->q_id."'".')"><i class="fa fa-eye"></i>View</a>

<div class="dropdown-divider"></div>




<a class="dropdown-item waves-light waves-effect " href="'.base_url("edit_quotation/".$v_kb_category->q_id).'"><i class="fa fa-pencil"></i>Edit Details</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect " href="'.base_url("copy_quotation/".$v_kb_category->q_id."/copy").'"><i class="fa fa-copy"></i>Copy Quotation </a>

<div class="dropdown-divider"></div>';

if($v_kb_category->q_current_status!="Inquiry")
{
$action.='<a class="dropdown-item waves-light waves-effect " href="'.base_url('generate_quotation/').$v_kb_category->q_id.'">Generate PDF</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect " href="'.base_url('send_mail_quotation/').$v_kb_category->q_id.'">Send as email</a>';

}
$action.='
<div class="dropdown-divider"></div>
<a class="dropdown-item " onclick="issue_performa('."'".$v_kb_category->q_id."'".')" ><i class="fa fa-file-invoice"></i>Issue Proforma Invoice</a>';


$action.='<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect " href="'.base_url('quot_history/').$v_kb_category->q_id.'" >See Activity </a>

</div>
</div>';
if($v_kb_category->show_stamp=='1')
{
	if($v_kb_category->q_approval_stamp_sign=='1')
	{
		if($this->session->userdata['user']['main_dept']=="Main")
		{
$action.='<button type="button" class="label label-lg label-danger quot_req_id_'.$v_kb_category->q_id.'" style="background-color: #da0606;
  color: white;
  -webkit-animation: glowing 1500ms infinite;
  -moz-animation: glowing 1500ms infinite;
  -o-animation: glowing 1500ms infinite;
  animation: glowing 1500ms infinite;" onclick="approve_stamp('."'".$v_kb_category->q_id."'".')" >Requesting approval for Stamp and sign</button>';
		}
	
	}
}
 // $action .= ajax_anchor(base_url("admin/knowledgebase/delete_categories/$v_kb_category->q_id"), "<i class='btn btn-xs btn-danger fa fa-trash-o'></i>", array("class" => "", "title" => lang('delete'), "data-fade-out-on-success" => "#table_" . $_key)) . ' ';



                $sub_array[] = $action;
                
 if(!empty($v_kb_category->q_id))
	 {
	 		$survey_data=$this->Admin_model->get_data('quotation_survey',array('query_id'=>$v_kb_category->q_id));

      if(!empty($survey_data))

     {  


				       	$html2='<div class="dropdown-succsses dropdown">
				<button class="btn btn-success dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >Survey</button>
				<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">

				<a class="dropdown-item waves-light" onclick="view_survey_data('."'".$v_kb_category->q_id."'".')"><i class="fa fa-eye"></i>View Survey</a>

				<div class="dropdown-divider"></div>

			
				<a class="dropdown-item waves-light waves-effect " onclick="create_quotation_survey('."'".$v_kb_category->q_id."'".')"><i class="fa fa-pencil"></i>Edit Survey</a>
				<div class="dropdown-divider"></div>

				<div class="dropdown-divider"></div>';





      }else {



                     	$html2='<div class="dropdown-danger dropdown">
				<button class="btn btn-info dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >new Survey</button>
				<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">

				

				<div class="dropdown-divider"></div>

				<a class="dropdown-item waves-light" onclick="create_quotation_survey('."'".$v_kb_category->q_id."'".')"><i class="fa fa-pencil"></i>Create Survey </a>
				<div class="dropdown-divider"></div>
			

				<div class="dropdown-divider"></div>';



      }




			
 }
 else {
	$html2='<div class="dropdown-primary dropdown">
<button class="btn btn-info dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >Survey</button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">

<a class="dropdown-item waves-light" onclick="view_survey_data('."'".$v_kb_category->q_id."'".')"><i class="fa fa-eye"></i>View Survey</a>

<div class="dropdown-divider"></div>

<a class="dropdown-item waves-light" onclick="create_quotation_survey('."'".$v_kb_category->q_id."'".')"><i class="fa fa-eye"></i>Create Survey </a>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect " href=""><i class="fa fa-pencil"></i>Edit Survey</a>
<div class="dropdown-divider"></div>

<div class="dropdown-divider"></div>';


 }

  


                $sub_array[] = $html2;
               // $data[] = $sub_array;

$data[] = $sub_array;





            }
 render_table($data);

      
    }

function ajax_load_view()
{
	$qout_id=$this->input->post('quot_id');
	$total_vat_sum_prd='';
$total_discount_sum_prd='';
$total_sum_prd='';
//print_r('dgfdfd');	
	$quot_data=$this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$qout_id));
	$prd_ids=explode('|#|', $quot_data[0]->q_prd_id);	
	
$qnty=explode('|#|',$quot_data[0]->q_prd_qnty);
$unit_price=explode('|#|',$quot_data[0]->q_prd_price);
$vat=explode('|#|',$quot_data[0]->q_prd_vat);  
$total=explode('|#|',$quot_data[0]->q_prd_tot);
$dicount_per=$quot_data[0]->q_discount_per;

	$html='<div class="col-md-12 col-sm-12">
		<div class="col-md-12" style="margin-bottom: 2%;">
			<div class="col-md-4">
				<b>Sales Person:</b><br/> '.$quot_data[0]->q_user_id.'<br/>
				<b>Date:</b><br/> '.$quot_data[0]->q_date.'<br/>
				
			</div>
		<div class="col-md-4">
				<p>'.$quot_data[0]->q_cust_comp.'</p>
			<p>'.$quot_data[0]->q_cust_name.'</p>
			
			<p>'.$quot_data[0]->q_cust_email.'</p>
			<p>'.$quot_data[0]->q_cust_mob.'</p>
			<p>'.$quot_data[0]->q_cust_landline.'</p>
			</div>	
			<div class="col-md-4">
					
					<b>Delivery time:</b> '.$quot_data[0]->q_delivery_time.'<br/>
					<b>payment type:</b> '.$quot_data[0]->q_payment_type.'<br/>
					<b>Advance payment amount(for advance payment type):</b> '.$quot_data[0]->q_adv_pay_amount.'<br/>
					<b>payment days:</b> '.$quot_data[0]->q_payment_days.'<br/>
				<b>offer validity days:</b> '.$quot_data[0]->q_offer_validity.'<br/>
			</div>				
		</div>';
		
if($quot_data[0]->q_current_status=="Inquiry")
{
if(!empty($quot_data[0]->q_files))
{
	$files_data=explode(',',$quot_data[0]->q_files);
	foreach($files_data as $fd)
	{	
	$html.='<a target="_blank" href="./uploads/file_manager/'.$fd.'">'.$fd.'</a><br/>';	
	}
}
}
else
{
$html.='<div class="col-md-12 col-sm-12"> 
<p>Total Price : '.array_sum($total).' '.$quot_data[0]->q_currency_type.'</p>';
		
		if(!empty($quot_data[0]->q_discount_per))	
		{
		$dic_price=$quot_data[0]->q_discount_per;		
			$html.='<p>Discount Price: '.$quot_data[0]->q_discount_per.'</p>';
		}
		else
		{
		$dic_price=0;
		}
		if(!empty($quot_data[0]->q_additional_charge))	
		{
		$additional_price=$quot_data[0]->q_additional_charge;
				
			$html.='<p>Additional charges: '.$quot_data[0]->q_additional_charge.' '.$quot_data[0]->q_currency_type.'</p>';
		}
		else
		{
		$additional_price=0;
		}
		$net_tot=((array_sum($total)+$additional_price)-$dic_price);
		
			$html.='<p>NET Total: '.$net_tot.' '.$quot_data[0]->q_currency_type.' </p>
			<p>Total VAT (%): '.$quot_data[0]->q_total_vat.' '.$quot_data[0]->q_currency_type.' </p>
			
			<p>Grand Total : '.$quot_data[0]->q_grand_total.' '.$quot_data[0]->q_currency_type.' </p>
		</div>

		<div class="col-md-12" >
		<div class="col-md-12 col-sm-12"> 
		<table class="table table-responsive table-bordered table-striped">
		
		<thead>
			<th></th>
			<th>Image</th>
			<th>Product Name</th>
			<th>Quantity</th>
			<th>Unit Price</th>
			<th>VAT %</th>
			<th>Total</th>
		</thead><tbody>';
		$i=1;
		foreach($prd_ids as $index=>$p)
		{
		

			$prd_info=$this->tm->get_data('products',array('pid'=>$p));

		if(empty($prd_info[0]->p_prd_img))
		{
			$filename="https://birigroup.com/uploads/prd_images/".$prd_info[0]->pcode.'.jpeg';
		 if (file_exists($filename)) {
		 	$img_path=$filename;
			} else {
			$img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->pcode.'.jpg';
		    }
		}
		 else
		 {
		 	$first_img_prd=explode(',',$prd_info[0]->p_prd_img);
		 	if(!empty($first_img_prd[0]))
		 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
		 	else
		 	$img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img;
		 }

				$prd_name_db=explode('|~~|',$prd_info[0]->pname);
		$html.='
		<tr>
		<td>'.$i++.'</td>
		<td><img src="'.$img_path.'" width="100" height="100"></td>
		<td>';	
			if(!empty($prd_name_db[1]))
						$html.= $prd_name_db[0].'<br/>'.$prd_name_db[1];
					else
						$html.= $prd_info[0]->pname;
			$html.='</td>
			<td>'.$qnty[$index].'</td>
			<td>'.$unit_price[$index].'</td>
			<td>'.$vat[$index].'</td>
			<td>'.$total[$index].'</td>
			
		</tr>';
		}
		$html.='	</tbody>
		</table>	
			
		</div>
		</div>';
		
	if(!empty($t->q_files))
	{
	$html.='<div class="col-md-12 col-sm-12"> 
	<p>Files submitted for inquiry:<br/></p>';
	$files_data=explode(',',$quot_data[0]->q_files);
	foreach($files_data as $fd)
	{
	$html.='<a target="_blank" href="'.base_url("uploads/file_manager/".$fd).'">'.$fd.'</a><br/>';
	}	
	$html.='</div>';
	}
		}///closing else///
	$html.='</div>';
echo $html;	
}












function survey_load_view()
{
	$qout_id=$this->input->post('quot_id');
	$total_vat_sum_prd='';
$total_discount_sum_prd='';
$total_sum_prd='';
//print_r('dgfdfd');	
	$survey_data=$this->Admin_model->get_data('quotation_survey',array('query_id'=>$qout_id));



	$inquiry_matching=$survey_data[0]->inquiry_matching;	
	
$inquiry_note=$survey_data[0]->inquiry_note;

	$new_customer=$survey_data[0]->new_customer;	
	
$how_find_us=$survey_data[0]->how_find_us;

	$s_respons=$survey_data[0]->s_respons;	
	
$s_explaininig=$survey_data[0]->s_explaininig;

	$s_comunication_skills=$survey_data[0]->s_comunication_skills;	
	
$addi_note_emp=$survey_data[0]->addi_note_emp;

$sts_uregent=$survey_data[0]->sts_uregent;	
	
$dat_urgent=$survey_data[0]->dat_urgent;

$addi_note_no_survey=$survey_data[0]->addi_note_no_survey;


$html='';

	$html.='<div class="col-md-12 col-sm-12">
		<div class="col-md-12" style="margin-bottom: 2%;">
			

   
	<tr>
		<td>This Quotaition ';
		if($inquiry_matching=='1')
{
  $html.=' Matching With Customer Requerments </td>
		';
}else{
	$html.=' Dosent Matching With Customer Requerments </td>
		';

}

$html.='</tr> <br>';




$html.='
	<tr>
		<td> Query Note :';
		if($inquiry_note!='')
{
  $html.=   $inquiry_note.' </td>
		';
}else{
	$html.=' None </td>
		';

}

$html.='</tr> <br>';

$html.='
	<tr>
		<td> And This Customer is :';
		if($new_customer=='1')
{
  $html.=' New Customer </td>
		';
}else{
	$html.=' Previous Customer </td>
		';

}

$html.='</tr> <br>';


$html.='
	<tr>
		<td> How Find Us : ';
		if($how_find_us!='')
{
  $html.= $how_find_us.' </td>
		';
}else{
	$html.=' Not Mentioned </td>
		';

}

$html.='</tr> <br>';
				

$html.='
	<tr>
		<td>Customer Rate Sales Response as : ';
		if($s_respons=='0')
{
  $html.=' Poor Resopnse  </td>
		';
}else if($s_respons=='1') {
	$html.='  Good Resopnse </td>
		';

}else if($s_respons=='2') {
	$html.='  Fast Resopnse </td>
		';

}

$html.='</tr> <br>';


$html.='
	<tr>
		<td>With Communication Skills : ';
		if($s_comunication_skills=='0')
{
  $html.=' Poor And Less Than Excpected  </td>
		';
}else if($s_comunication_skills=='1') {
	$html.='  normal  </td>
		';

}else if($s_comunication_skills=='2') {
	$html.='  Professional </td>
		';

}

$html.='</tr> <br>';


$html.='
	<tr>
		<td>Explaining All details for Customer : ';
		if($s_explaininig=='0')
{
  $html.=' No... there is Somthing missing </td>
		';
}else if($s_explaininig=='1') {
	$html.='  Yes Every Thing Clear  </td>
		';

}else if($s_explaininig=='2') {
	$html.=' Not Sure </td>
		';

}

$html.='</tr> <br>';


$html.='
	<tr>
		<td>Additional Note For Employee : ';
	if($addi_note_emp!='')
{
  $html.= $addi_note_emp. '</td>
		';
}else {
	$html.='  No Note </td>
		';

}

$html.='</tr> <br>';





$html.='
	<tr>
		<td> Order Statu Was : ';
	if($sts_uregent=='0')
{
  $html.= ' urgent  </td>
		';
}else if($sts_uregent=='1') {
	$html.='  job in hand </td>
		';

}
else if($sts_uregent=='2') {
	$html.='  evaluationof project </td>
		';

}
else if($sts_uregent=='3') {
	$html.='  pricing for future deal </td>
		';

}


$html.='</tr> <br>';


$html.='
	<tr>';
		
	if($sts_uregent=='0')
{
  $html.='<td> Order Date because the urgent : ' 
   .$dat_urgent. ' </td>
		';
}else{
	$html.=' </td>
		';

}



$html.='</tr> <br>';

$html.='
	<tr>';
		
	if($addi_note_no_survey!='')
{
	$html.= 'Additional Note if customer not response :   '.$addi_note_no_survey.' </td>
		';
  
}else{

	$html.='<td>  
    </td> 
 
		';
	

}



$html.='</tr> <br>';


								



	$html.='</div>';
echo $html;
}













function filter_excel_download()
{
	$selected_year=$this->input->post('filter_year');
	$selected_month=$this->input->post('filter_month');
	$data=$this->Admin_model->get_data('qoutattion_entry',array( 'MONTH(`q_date`)'=>$selected_month,'YEAR(`q_date`)'=>$selected_year ));

 $this->load->library("excel");
  $object = new PHPExcel();

 		 $object->getActiveSheet()->setCellValue('A1', 'Doc. Number');
 		 $object->getActiveSheet()->setCellValue('B1', 'User Created');
   		 $object->getActiveSheet()->setCellValue('C1', 'Subject');
         $object->getActiveSheet()->setCellValue('D1', 'Customer Name');
         $object->getActiveSheet()->setCellValue('E1', 'Company');
         $object->getActiveSheet()->setCellValue('F1', 'Quotation Date');
         $object->getActiveSheet()->setCellValue('G1', 'Current Status');

         $object->getActiveSheet()->getStyle('A1:G1')->getAlignment()->setWrapText(true); 


          $ex_row=2;
		foreach($data as $index_p=>$p1)
		{
			$object->getActiveSheet()->setCellValue('A' . $ex_row, $p1->q_ref_no);	
			$object->getActiveSheet()->setCellValue('B' . $ex_row, $p1->q_user_id);					
		    $object->getActiveSheet()->setCellValue('C' . $ex_row, $p1->q_sub);
	        $object->getActiveSheet()->setCellValue('D' . $ex_row, $p1->q_cust_name);
	        $object->getActiveSheet()->setCellValue('E' . $ex_row, $p1->q_cust_comp);
	        $object->getActiveSheet()->setCellValue('F' . $ex_row, $p1->q_date);
	        $object->getActiveSheet()->setCellValue('G' . $ex_row, $p1->q_current_status);
	        $object->getActiveSheet()->getStyle('A'.$ex_row.':G'.$ex_row)->getAlignment()->setWrapText(true); 
	       $ex_row++;
		}	

 $object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
  header('Content-Type: application/vnd.ms-excel');
  header('Content-Disposition: attachment;filename="Quotation_data_'.$selected_month.'_'.$selected_year.'.xls"');
  $object_writer->save('php://output');

  redirect('list-quotation');
}


function submit_quotation_note()
{
	$quot_id=$this->input->post('qtn_sts_id');
	$quot_sts_type=$this->input->post('qtn_sts_type');

	$date_follow_up=$this->input->post('date_follow_up');
	$follow_up_way=implode(',',$this->input->post('follow_up_way'));
	$name_person=$this->input->post('name_follow_up_person');
	$next_follow_up_date=$this->input->post('next_follow_up_date');
	$notes_follow_up=$this->input->post('notes_follow_up');

	$data_info['follow_up_date']=$date_follow_up;
	$data_info['follow_up_way']=$follow_up_way;
	$data_info['follow_up_person']=$name_person;
	$data_info['follow_up_next_date']=$next_follow_up_date;
	$data_info['follow_up_notes']=$notes_follow_up;

	foreach($data_info as $key=>$eei)
	{
		if(!empty($eei))
		$sts_note[]=$key.':'.$eei;
		else
			$sts_note[]=$key.':'.'';
	}

	$data=array(
		'q_current_sts_note'=>implode('$#$', $sts_note),
		'q_current_status'=>$quot_sts_type,
	);
	 $this->Admin_model->update_data('qoutattion_entry',$data,array('q_id'=>$quot_id));

	 $quot_details_array=array(
	 	'qmd_current_sts'=>$quot_sts_type,
	 	'qmd_quot_id'=>$quot_id,
	 	'qmd_note'=>implode('$#$', $sts_note),
	 );
 $this->Admin_model->insert_data('quotation_more_details',$quot_details_array);

$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'Quotation follow-up ',
				'act_status'=>'Follow up status:'.$quot_sts_type,
				'act_type'=>'Follow up date created: '.$this->input->post('date_follow_up'),
				'act_quot_id'=>$quot_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
				'act_notification_sts'=>'1',
				'act_notification_sts_mngmnt'=>'1'
			);

	$this->Admin_model->insert_data('activities',$activity_data);	
	 $this->session->set_flashdata('success', 'Status Successfully changed');
	 redirect('list-quotation');
}









function submit_quotation_Survey()
{

	$quot_id=$this->input->post('qtn_survey_id');
	$inquiry_matching=$this->input->post('inquiry_matching');
	$inquiry_note=$this->input->post('inquiry_note');

	$new_customer=$this->input->post('new_customer');
	$how_find_us=$this->input->post('how_find_us');

	$s_respons=$this->input->post('s_respons');

	$s_explaininig=$this->input->post('s_explaininig');
	$s_comunication_skills=$this->input->post('s_comunication_skills');

		$addi_note_emp=$this->input->post('addi_note_emp');

	$sts_uregent=$this->input->post('sts_uregent');
  $dat_urgent=$this->input->post('dat_urgent');
$addi_note_no_survey=$this->input->post('addi_note_no_survey');


	// $data_info['follow_up_date']=$date_follow_up;
	// $data_info['follow_up_way']=$follow_up_way;
	// $data_info['follow_up_person']=$name_person;
	// $data_info['follow_up_next_date']=$next_follow_up_date;
	// $data_info['follow_up_notes']=$notes_follow_up;

	// foreach($data_info as $key=>$eei)
	// {
	// 	if(!empty($eei))
	// 	$sts_note[]=$key.':'.$eei;
	// 	else
	// 		$sts_note[]=$key.':'.'';
	// }

	// $data=array(
	// 	'q_current_sts_note'=>implode('$#$', $sts_note),
	// 	'q_current_status'=>$quot_sts_type,
	// );
	//  $this->Admin_model->update_data('qoutattion_entry',$data,array('q_id'=>$quot_id));

 $survey_details_array=array(
 	'query_id'=>$quot_id,
	 	'inquiry_matching'=>$inquiry_matching,
	 	'inquiry_note'=>$inquiry_note,
 	'new_customer'=>$new_customer,
 	'how_find_us'=>$how_find_us,
 	's_respons'=>$s_respons,
 	's_explaininig'=>$s_explaininig,
 	's_comunication_skills'=>$s_comunication_skills,
 	'addi_note_emp'=>$addi_note_emp,
 	'addi_note_no_survey'=>$addi_note_no_survey,
 	'sts_uregent'=>$sts_uregent,
 	'dat_urgent'=>$dat_urgent
  );




 $this->Admin_model->insert_data('quotation_survey',$survey_details_array);

$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'Quotation follow-up_survey',
				'act_status'=>'Follow up status: survey',
				'act_type'=>'Follow up date created: '.$this->input->post('date_follow_up'),
				'act_quot_id'=>$quot_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
				'act_notification_sts'=>'1',
				'act_notification_sts_mngmnt'=>'1'
			);

	$this->Admin_model->insert_data('activities',$activity_data);	
	 $this->session->set_flashdata('success', 'Survey Successfully Added');
	 redirect('list-quotation');
}







function sts_notes()
{
	$quot_id=$this->input->post('quot_id');
	$quot_data=$this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$quot_id));
	$sts_note=explode('$#$',$quot_data[0]->q_current_sts_note);
	if(!empty($sts_note[3]))
	{
		$follow_up_date=explode(':',$sts_note[0]);
		$follow_up_way=explode(':',$sts_note[1]);
		$follow_up_person=explode(':',$sts_note[2]);
		$follow_up_next_date=explode(':',$sts_note[3]);
		$follow_up_notes=explode(':',$sts_note[4]);

		$html='<p> Follow up Date : '. $follow_up_date[1].'</p>';
		$html.='<p> Follow up way : '.$follow_up_way[1] .'</p>';
		$html.='<p> Follow up Person : '.$follow_up_person[1] .'</p>';
		$html.='<p> <b>Next Follow up Date : '.$follow_up_next_date[1] .'</b></p>';
		$html.='<p> Follow up Notes : '.$follow_up_notes[1] .'</p>';

		echo $html;
	}
	elseif(!empty($quot_data[0]->q_current_sts_note))
	{
		$html='<p> Follow up Notes : '.$quot_data[0]->q_current_sts_note .'</p>';
		echo $html;
	}
	else{}
}




















}