<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manage_assets extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
	}

function manage_assets($asset_type)
{
	if(logged_in())
	{

   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='manage_assets')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



		if($asset_type=='tools')
		{
			$data['tool_result']=$this->Admin_model->get_data('assets_tools',array('tool_sts'=>'1'));
			$this->load->view('admin/production/manage_tools_assets',$data);
		}
		else
		{
			$data['veh_result']=$this->Admin_model->get_data('assets_vehicle',array('veh_sts'=>'1'));
			$this->load->view('admin/production/manage_veh_assets',$data);
		}

	}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
	}


	}
	





function manage_assets_lists()
{
	if(logged_in())
	{

   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='manage_assets_list'||($this ->session->userdata['user']['main_dept'])=="Main" ||($this ->session->userdata['user']['main_dept'])=="Accounts")
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


	$sql2=$this->db->query("SELECT al.*,its.item_name,mat.label as label,item_name
	FROM assets_list as al   join items_assets as its 
	on its.item_id=al.al_name_of_asset join master_accounts_tree as mat on mat.id=al.al_asset_type
	WHERE al.al_availabilaty = '1' order by al.al_id DESC");
	
	//echo $this->db->last_query();
	$datas['result']=$sql2->result_array();
// print_r($datas);
// exit();

//$data['items_assets']=$this->Admin_model->get_data('items_assets',array('item_sts'=>'1'));

//$data['asset_list']=$this->Admin_model->get_data('assets_list',array('al_availabilaty'=>'1'));

	$this->load->view('admin/list_assets_management',$datas);


//print_r($data['asset_list']);exit();

	
	}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
	}


	}





function add_assets($aid=null)
{
	if(logged_in())
	{

   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='manage_assets_list'||($this ->session->userdata['user']['main_dept'])=="Main" ||($this ->session->userdata['user']['main_dept'])=="Accounts")
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {






	$condition='parent IN (636,958,959,963,964,965)';
				
						$data['customers']=$this->Admin_model->get_data('master_accounts_tree',$condition);

if(empty($aid))
{
  	$val_recipt=$this->Admin_model->get_data('assets_list','','','','al_id','DESC');      

}else{

$data['result']=$this->Admin_model->get_data('assets_list',array('al_id'=>$aid));

}

      

$this->load->view('admin/new_assets',$data);

	
	}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
	}


	}


 public function get_assets_child() {
       
  $parent_asset_id = $this->input->post('parent_asset_id');
    
    // Query the database to fetch all child assets for the selected parent asset
    $child_assets = $this->Admin_model->get_child_assets($parent_asset_id);
    
    // Send the child assets as JSON response
    echo json_encode($child_assets);





    }


function submit_assets_item()
{
	if(logged_in())
	{

   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='manage_assets_list'||($this ->session->userdata['user']['main_dept'])=="Main" ||($this ->session->userdata['user']['main_dept'])=="Accounts")
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {
$data['al_description']=$this->input->post('asset_desc');
$data['al_asset_type']=$this->input->post('parent_asset_id');
$data['al_name_of_asset']=$this->input->post('child_asset_name');
$data['al_serial_number']=$this->input->post('asset_serial');
$data['al_condition_asset']=$this->input->post('al_condition_asset');
$data['al_price']=$this->input->post('asset_price');


$data['al_availabilaty']='1';
$data['al_emp_custody']='0';
$data['al_previous_emp']='0';

$data['al_update_custody_date']=get_date_time();
$data['al_create_date']=get_date_time();
$data['al_update_date']=get_date_time();



$insert_id=$this->Admin_model->insert_data('assets_list',$data);

//print_r($insert_id);exit(0);
if($insert_id!='0'){

	   $this->session->set_flashdata('success', 'Data Successfully inserted');
redirect('manage-assets/'.$page_type);

}
else{

	 	$this->session->set_flashdata('errors', 'There is messing value please be sure for all entry.    /    الرجاء التأكد من جميع المدخلات   ');
 
redirect('manage-assets/'.$page_type);
}
// print_r($data);exit(0);
      



	
	}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
	}


	}


    
function emp_custody_page()
{
   
	if(logged_in())
	{

   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='emp-custody-create'||($this ->session->userdata['user']['main_dept'])=="Main" ||($this ->session->userdata['user']['main_dept'])=="HR")
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

                    $condition='et_sts=1';     
                   $available_cond='al_availabilaty=1';
               	$data['employee']=$this->Admin_model->get_data('tbl_emp_tree',$condition);
					$data['assets_list']=$this->Admin_model->get_data('assets_list',$available_cond);   



					$this->load->view('admin/employee_custody',$data);
      
//print_r($data);exit();


	
	}


  else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
	}


	}





	
function get_assets_details()
{
	$aid=$this->input->post('asset_id');


	$asset_data=$this->Admin_model->get_data('assets_list',array('al_id'=>$aid));
$cparent=$asset_data[0]->al_asset_type;

 $asset_parent_name=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$cparent));

 	$ctype=$asset_data[0]->al_name_of_asset;
 $asset_ctype_name=$this->Admin_model->get_data('items_assets',array('item_id'=>$ctype));

 $cparent_name= $asset_parent_name[0]->label;
$ctype_name=$asset_ctype_name[0]->item_name;

  $ccon=$asset_data[0]->al_condition_asset;
  $cprevcus=$asset_data[0]->al_previous_emp;

  switch($ccon)
  {
      case 0:
       $ccon_name='New';
        break;

        case 1:
        $ccon_name='Used But new';
        break;

        case 2:
        $ccon_name='Good';
        break;

        case 3:
        $ccon_name='Low Average';
        break;

        case 4:
         $ccon_name='OLD';
        break;

        	default:
		$ccon_name='None';
		break;

  }
 $cprevcus_emp_asset=$this->Admin_model->get_data('tbl_emp_tree',array('et_id'=>$cprevcus));
$cprevcus_name= $cprevcus_emp_asset[0]->et_name;
  if(empty($cprevcus))
  {
    $cprevcus_name="None";

  }

		 $prd_array=array(
       'cparent'=>$cparent_name,
		 	'ctype'=>$ctype_name,
       'ccon'=>$ccon_name,
		 	'cprevcus'=>$cprevcus_name,
		 );
		 echo json_encode($prd_array);
}


       
function submit_custody()
{
	if(logged_in())
	{

   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='manage_assets_list'||($this ->session->userdata['user']['main_dept'])=="Main" ||($this ->session->userdata['user']['main_dept'])=="Accounts")
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


$emp_id=$this->input->post('si_customer_acc_id');

$product_array=$this->input->post('si_product');

//print_r($emp_id);


 
// print_r('||');
// print_r($test_prod0);
// exit();
foreach($product_array as $key=>$pi)
{

      
//$test_prod[$key]=$pi;


$this->Admin_model->update_data('assets_list',array('al_emp_custody'=>$emp_id,'al_availabilaty'=>'0','al_create_date'=>get_date_time(),'al_update_date'=>get_date_time()),array('al_id'=>$pi));

}






//$insert_id=$this->Admin_model->insert_data('assets_list',$data);

//print_r($insert_id);exit(0);
// if($insert_id!='0'){

   $this->session->set_flashdata('success', 'Data Successfully inserted');
// redirect('manage-assets/'.$page_type);

// }
// else{

// 	 	$this->session->set_flashdata('errors', 'There is messing value please be sure for all entry.    /    الرجاء التأكد من جميع المدخلات   ');
 
// redirect('manage-assets/'.$page_type);
// }
// print_r($data);exit(0);
      

redirect('emp-custody-create');

	
	}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
	}


	}

  function get_details_prd()
{
		$table_id=$this->input->post('table_id');
	//$prd_data=$this->tm->get_data('products',array('p_sts'=>'1'));

	$asset_data=$this->Admin_model->get_data('assets_list',array('al_availabilaty'=>'1'));
$html='<select data-plugin-selectTwo  class="form-control populate product_'.$table_id.'" name="si_product[]" onchange="get_product_details('.$table_id.');"><option >Choose</option>';
	foreach($asset_data as $sd)
	{
	$html.="<option value=".$sd->al_id.">".$sd->al_description.":: <br/>".$sd->al_serial_number."</option>";
	}
  $html.="</select>";
  echo $html;
}





}