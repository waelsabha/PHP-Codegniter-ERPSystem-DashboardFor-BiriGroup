<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_invoice extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','email_survey'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
		$this->load->library('numbertowordconvertsconver');	
        $this->load->library('numbertowordconvertsconverksa');	
		$this->load->library('numbertoworduk');	
		require 'vendor/autoload.php';
		require_once 'vendor/khaled.alshamaa/ar-php/src/Arabic.php';		
	}

function sales_invoice_page($page_type=null,$siv=null)
{
	if(logged_in())
	{
		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'sales-invoice'));

		$salesman=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales', 'log_status !='=>'0'));
		foreach($salesman as $s)
		{
		 	$data['salesman'][]=$this->Admin_model->get_data('employee_details',array('ed_login_id'=>$s->log_id,'ed_sts'=>'1'));
		}
	  $logged_person=$this->session->userdata['user']['username'];
		$data['logged_person_id']=$this->Admin_model->get_data('login_credentials',array('log_uname'=>$logged_person));
    
		$data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
		$data['price_level']=$this->Admin_model->get_data('master_price_level',array('mpc_sts'=>'1'));
		$data['region']=$this->Admin_model->get_data('master_region',array('mr_sts'=>'1'));
		$data['payment_method']=$this->Admin_model->get_data('master_payment_method',array('mpm_sts'=>'1'));

		$data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));
		$data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));
		$data['place_supply']=$this->Admin_model->get_data('master_place_supply',array('mps_sts'=>'1'));
		$data['project']=$this->Admin_model->get_data('master_project',array('mpj_sts'=>'1'));
		if($page_type=='uae')
				{
					$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'638'));
					$data['sales_accont']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'616'));
				}
				elseif($page_type=='ksa')
				{
						$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'490'));
						$data['sales_accont']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'619'));
				}	
				elseif($page_type=='dragon')
				{
						$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'638'));
						$data['sales_accont']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'616'));
				}
				elseif($page_type=='export')
				{   	$condition='parent IN (638,490)';
					$conditionacc='parent IN (616,619)';
						$data['customers']=$this->Admin_model->get_data('master_accounts_tree',$condition);
						$data['sales_accont']=$this->Admin_model->get_data('master_accounts_tree',$conditionacc);
				}	
					elseif($page_type=='UK')
				{
						$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'1157'));
						$data['sales_accont']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'1161'));
				}
						elseif($page_type=='UAEAmazon')
				{ 
						$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'638'));
						$data['sales_accont']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'616'));
				}
						elseif($page_type=='KSAamazon')
				{ 
						$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'490'));
						$data['sales_accont']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'619'));
				}

						elseif($page_type=='ukamazon')
				{ 
						$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'1157'));
						$data['sales_accont']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'1161'));
				}
				elseif($page_type=='uae-online')
				{
					$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'236'));
					$data['sales_accont']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'260'));
				}


				
				else{}
		if(empty($siv))
		{
			if(!empty($page_type))
			{
				if($page_type=='uae')
				{
				$val_recipt=$this->Admin_model->get_data('sales_invoice','','','','si_id','DESC');
				}
				elseif($page_type=='ksa')
				{
				$val_recipt=$this->Admin_model->get_data('sales_invoice_ksa','','','','si_id','DESC');
				}	
				elseif($page_type=='dragon')
				{
				$val_recipt=$this->Admin_model->get_data('sales_invoice_dragon','','','','si_id','DESC');	
				}
				elseif($page_type=='export')
				{
				$val_recipt=$this->Admin_model->get_data('sales_invoice_export','','','','si_id','DESC');	
				}	
					elseif($page_type=='UK')
				{
				$val_recipt=$this->Admin_model->get_data('sales_invoice_uk','','','','si_id','DESC');	
				}	
					elseif($page_type=='UAEAmazon')
				{
				$val_recipt=$this->Admin_model->get_data('sales_invoice_uae_amazon','','','','si_id','DESC');	
				}	
					elseif($page_type=='KSAamazon')
				{
				$val_recipt=$this->Admin_model->get_data('sales_invoice_ksa_amazon','','','','si_id','DESC');	
				}	

					elseif($page_type=='ukamazon')
				{
				$val_recipt=$this->Admin_model->get_data('sales_invoice_uk_amazon','','','','si_id','DESC');	
				}
						elseif($page_type=='uae-online')
				{
				$val_recipt=$this->Admin_model->get_data('sales_invoice_online_uae','','','','si_id','DESC');	
				}
				else{}

			if(empty($val_recipt))
			{
				if($page_type=='uae')
					$data['doc_num']='INV 1200';
				elseif($page_type=='ksa')
					$data['doc_num']='INV-KSA 8230';
				elseif($page_type=='dragon')
			     	$data['doc_num']='SID 6316';
				elseif($page_type=='export')
					$data['doc_num']='ESI 1200';

				elseif($page_type=='UK')
					$data['doc_num']='INV-UK 1200';
					
				elseif($page_type=='UAEAmazon')
					$data['doc_num']='INV-UA 1200';
					elseif($page_type=='KSAamazon')
					$data['doc_num']='INV-KA 1200';
				else{}

			}
				else
				{
					if($page_type=='uae')
					{
				$bal_string1=str_replace("INV ", "", $val_recipt[0]->si_doc_no);
				//print_r($bal_string1);
			           $new_id_1=($bal_string1)+1;
			            $data['doc_num']="INV ".$new_id_1;
			        }
			        elseif($page_type=='ksa')
			        {
			        	$bal_string1=str_replace("INV-KSA ", "", $val_recipt[0]->si_doc_no);
				//print_r($bal_string1);
			           $new_id_1=($bal_string1)+1;
			            $data['doc_num']="INV-KSA ".$new_id_1;
			        }
			        elseif($page_type=='dragon')
			        {
			        	$bal_string1=str_replace("SID ", "", $val_recipt[0]->si_doc_no);
				//print_r($bal_string1);
			           $new_id_1=($bal_string1)+1;
			            $data['doc_num']="SID ".$new_id_1;
			        }
			        elseif($page_type=="export")
					{
						$bal_string1=str_replace("ESI ", "", $val_recipt[0]->si_doc_no);
				//print_r($bal_string1);
			           $new_id_1=($bal_string1)+1;
			            $data['doc_num']="ESI ".$new_id_1;
					}
				  elseif($page_type=="UK")
					{
						$bal_string1=str_replace("INV-UK ", "", $val_recipt[0]->si_doc_no);
				//print_r($bal_string1);
			           $new_id_1=($bal_string1)+1;
			            $data['doc_num']="INV-UK ".$new_id_1;
					}

					 elseif($page_type=="UAEAmazon")
					{
						$bal_string1=str_replace("INV-UA ", "", $val_recipt[0]->si_doc_no);
				//print_r($bal_string1);
			           $new_id_1=($bal_string1)+1;
			            $data['doc_num']="INV-UA ".$new_id_1;
					}
						 elseif($page_type=="KSAamazon")
					{
						$bal_string1=str_replace("INV-KA ", "", $val_recipt[0]->si_doc_no);
				//print_r($bal_string1);
			           $new_id_1=($bal_string1)+1;
			            $data['doc_num']="INV-KA ".$new_id_1;
					}

						 elseif($page_type=="ukamazon")
					{
					
				//print_r($bal_string1);
			         //  $new_id_1=($bal_string1);
			            $data['doc_num']=$val_recipt[0]->si_doc_no;
					}
							 elseif($page_type=="uae-online")
					{

			            $data['doc_num']=$val_recipt[0]->si_doc_no;
					}
			        else
			        {}

				}
			}
		}
		else
		{
			if($page_type=='uae')
			{
			$data['result']=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$siv));
			}
			elseif($page_type=='ksa')
			{
				$data['result']=$this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$siv));
			}
			elseif($page_type=='dragon')
			{
				$data['result']=$this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$siv));
			}	
			elseif($page_type=="export")
			{
				$data['result']=$this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$siv));
			}
				elseif($page_type=="UK")
			{
				$data['result']=$this->Admin_model->get_data('sales_invoice_uk',array('si_id'=>$siv));
			}
					elseif($page_type=="UAEAmazon")
			{
				$data['result']=$this->Admin_model->get_data('sales_invoice_uae_amazon',array('si_id'=>$siv));
			}
					elseif($page_type=="KSAamazon")
			{
				$data['result']=$this->Admin_model->get_data('sales_invoice_ksa_amazon',array('si_id'=>$siv));
			}
						elseif($page_type=="ukamazon")
			{
				$data['result']=$this->Admin_model->get_data('sales_invoice_uk_amazon',array('si_id'=>$siv));
			}
						elseif($page_type=="uae-online")
			{
				$data['result']=$this->Admin_model->get_data('sales_invoice_online_uae',array('si_id'=>$siv));
			}
			else{}
				$data['result_ac_tx']=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$siv,'atx_region'=>$page_type));
		}	
	$data['page_type']=$page_type;
	//	pre_list($data['result']);
		$this->load->view('admin/transactions/sales_invoice',$data);
	}
}

function get_details_warehouse()
{
		$table_id=$this->input->post('table_id');
	$warehouse=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));

$html= '<select data-plugin-selectTwo  class="form-control populate warehouse_'.$table_id.'" name="si_warehouse[]" ><option >Choose</option>';
foreach($warehouse as $w)
{
$html.="<option value=".$w->mw_id.">".$w->mw_name."</option>";
}
  $html.="</select>";
	  echo $html;
	
}

function get_details_prd()
{
		$table_id=$this->input->post('table_id');
	$prd_data=$this->tm->get_data('products',array('p_sts'=>'1'));
$html='<select data-plugin-selectTwo  class="form-control populate product_'.$table_id.'" name="si_product[]" onchange="get_product_details('.$table_id.');"><option >Choose</option>';
	foreach($prd_data as $pd)
	{
	$html.="<option value=".$pd->pid.">".$pd->pname.":: <br/>".$pd->pcode."</option>";
	}
  $html.="</select>";
  echo $html;
}

function get_cust_full_details()
{
	$cust_id=$this->input->post('cust_id');
	$data=$this->Admin_model->get_data('master_accounts_tree_file_data',array('accounts_tree_id'=>$cust_id));
	$sql2=$this->db->query("SELECT mactd.*,mc.mcomp_id,mas.ed_id,reg.mr_id,pm.mpm_id,pl.mpc_id,ccv.c_id,psl1.mw_id,psl2.mw_id,ccv.currency_val
FROM master_accounts_tree_file_data as mactd join master_company as mc on mc.mcomp_id=mactd.macd_company_id join employee_details as mas on mas.ed_id=mactd.macd_salesman_id  join master_region as reg on reg.mr_id=mactd.country  join master_payment_method as pm on pm.mpm_id=mactd.macd_payment_type_id  join master_price_level as pl on pl.mpc_id=mactd.macd_price_level_id  join master_currency_conv as ccv on ccv.c_id=mactd.macd_currency_value  join master_place_supply as psl1 on psl1.mw_id=mactd.macd_place_supply_id  join master_place_supply as psl2 on psl2.mw_id=mactd.macd_jurisdication_id  ");
	echo json_encode($data);
}

function get_product_details()
{
	$pid=$this->input->post('prd_id');
	$price_level_selected=$this->input->post('price_level_selected');
	$rate_to_choose='';

	$prd_data=$this->tm->get_data('products',array('pid'=>$pid));

	switch($price_level_selected)
	{
		case 1:
		$rate_to_choose=$prd_data[0]->p_ksa_retail_3;
		break;

		case 2:
		$rate_to_choose=$prd_data[0]->p_ksa_comp_2;
		break;

		case 3:
		$rate_to_choose=$prd_data[0]->p_ksa_reg_1;
		break;

		case 4:
		$rate_to_choose=$prd_data[0]->p_ksa;
		break;

		case 5:
		$rate_to_choose=$prd_data[0]->p_uae_l2;
		break;

		case 6:
		$rate_to_choose=$prd_data[0]->p_uae_l1;
		break;

		case 7:
		$rate_to_choose=$prd_data[0]->p_uae_final;
		break;

		default:
		$rate_to_choose=$prd_data[0]->p_uae_final;
		break;
	}
	if(empty($prd_data[0]->p_prd_img))
		{
			$filename="https://birigroup.com/uploads/prd_images/".$prd_data[0]->pcode.'.jpeg';
		 if (file_exists($filename)) {
		 	$img_path=$filename;
			} else {
			$img_path="https://birigroup.com/uploads/prd_images/".$prd_data[0]->pcode.'.jpg';
		    }
		}
		 else
		 {
		 	$first_img_prd=explode(',',$prd_data[0]->p_prd_img);
		 	if(!empty($first_img_prd[0]))
		 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
		 	else
		 	$img_path="https://birigroup.com/uploads/prd_images/".$prd_data[0]->p_prd_img;
		 }

		 	if(!empty($rate_to_choose))
		 		$prd_rate=$rate_to_choose;
		 		else
				$prd_rate=$prd_data[0]->p_uae_final;
		 $prd_array=array(
		 	'pimage'=>$img_path,
		 	'prd_price'=>$prd_rate
		 );
		 echo json_encode($prd_array);
}

function submit_sales_invoice()
{
	if(logged_in())
	{
		$page_type=$this->input->post('page_type');
		$edit_inv_id=$this->input->post('inv_id');

		 $main_date=$this->input->post('hid_date');
		$main_date1=explode('/',$main_date);
			$month2=$main_date1[0];
			$date2=$main_date1[1];
			$year2=$main_date1[2];
$new_formated_date1=$year2.'-'.$month2.'-'.$date2;

	/////for upload files//////
	$image = array();
	$uploadImgData = array();
  	$ImageCount = count($_FILES['files']['name']);
 
        for($i = 0; $i < $ImageCount; $i++)
        {     
            $_FILES['file']['name']       = $_FILES['files']['name'][$i];
            $_FILES['file']['type']       = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['files']['error'][$i];
            $_FILES['file']['size']       = $_FILES['files']['size'][$i];

            // File upload configuration
            $uploadPath = 'uploads/sales_invoice/';
         	$config['file_name'] = time() .preg_replace("/[^a-z0-9\_\-\.]/i", '', basename($_FILES["files"]["name"][$i]));
            $config['upload_path'] = $uploadPath;
            //$config['max_size'] = '3000000';////3mb
            $config['allowed_types'] = '*';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'business_card');
            $this->business_card->initialize($config);

            // Upload file to server
            if($this->business_card->do_upload('file'))
            {
              // Uploaded file data
                $imageData = $this->business_card->data();
              
                $uploadImgData[]=$imageData['file_name'];
              
                if(!empty($uploadImgData))
                {
              		$data_image=implode(',',$uploadImgData);
              	}
              	else
              	{
              		 $data_image='';
    			}	
                //print_r($uploadImgData);
            } 
            else
            {
           	 if(!empty($this->input->post('files_added')))
        		{
        		$data_image=$this->input->post('files_added');
				}
            	else
           		{
            		$data_image='';
    			}
            }      
        }
////end of for upload files//////////
			   


			  
 /* if(!empty($edit_inv_id))
  {    

     

   }  
    else{}     

*/

//we need to define this variable for any change

$whatwas='';
 $whatnow='';
 $customer_ac_old='';
 $sales_acc_old='';
 $lpo_no_old ='';
 $company_old='';
 $pc_level_old='';
 $salesman_old='';
 $contact_old='';
 $payment_type_old='';
 $country_old='';
 $narration_old='';
 $mark_old='';
 $shipping_contact_old='';
 $delivery_address_old='';
 $plc_supply_old='';
 $jurisdiction_old='';
 $currency_old='';
 $conv_value_old='';
 $attachments_old='';
 $warehouse_old='';
 $product_old='';
 $qnty_old='';
 $rate_old='';
 $gross_old='';
 $dis_per_old='';
 $dis_amount_old='';
 $add_charges_old='';
 $fnet_old='';
 $vat_old='';
 $delivery_date_old='';
 $remrk_old='';
 $tax_code_old='';
 $tot_vat_amount_old='';
 $tot_amount_old='';
 $vat_type_old=''; 
 $delivery_date_old='';
 $customer_ac_new='';
$sales_acc_new='';
$lpo_no_new='';
$company_new='';
$pc_level_new='';
$salesman_new='';
$contact_new='';
$payment_type_new='';
$country_new='';
$narration_new='';
$mark_new='';
$shipping_contact_new='';
$delivery_address_new='';
$plc_supply_new='';
 $jurisdiction_new='';

  $currency_new='';
   $conv_value_nes ='';
   $attachments_new ='';
   $warehouse_new ='';
   $product_new ='';
   $qnty_new ='';
   $rate_new='';
   $gross_new ='';
   $dis_per_new='';
   $dis_amount_new='';
   $add_charges_new ='';
   $fnet_new=''; 
   $vat_new='';
   $delivery_date_new=''; 
   $remrk_new=''; 
   $tax_code_new=''; 
   $tot_vat_amount_new=''; 
   $tot_amount_new=''; 
   $vat_type_new='';
   $delivery_date_new='';




			$data['si_doc_no']=$this->input->post('si_doc_no');
			
			$data['si_customer_acc_id']=$this->input->post('si_customer_acc_id');
			$data['si_sales_acc_id']=$this->input->post('si_sales_acc_id');
			$data['si_lpo_no']=$this->input->post('si_lpo_no');
			$data['si_company']=$this->input->post('si_company');
			$data['si_pc_level']=$this->input->post('si_pc_level');
			$data['si_salesman']=$this->input->post('si_salesman');
			$data['si_contact']=$this->input->post('si_contact');
			$data['si_payment_type']=$this->input->post('si_payment_type');
			$data['si_country']=$this->input->post('si_country');
			$data['si_narration']=$this->input->post('si_narration');
			$data['si_mark']=$this->input->post('si_mark');
			$data['si_shipping_contact']=$this->input->post('si_shipping_contact');
			$data['si_delivery_address']=$this->input->post('si_delivery_address');
			$data['si_plc_supply']=$this->input->post('si_plc_supply');
			$data['si_jurisdiction']=$this->input->post('si_jurisdiction');
			$data['si_currency']=$this->input->post('si_currency');
			$data['si_conv_value']=$this->input->post('si_conv_value');
			$data['si_attachments']=$data_image;
			$data['si_warehouse']=$this->input->post('hi_warehouse');
			$data['si_product']=$this->input->post('hi_prd_id');
			$data['si_qnty']=$this->input->post('hi_qnty');
			$data['si_rate']=$this->input->post('hi_rate');
			$data['si_gross']=$this->input->post('hi_gross');
			$data['si_dis_per']=$this->input->post('hi_dis_per');
			$data['si_dis_amount']=$this->input->post('hi_dis_amount');
			$data['si_add_charges']=$this->input->post('hi_add_charges');
			$data['si_fnet']=$this->input->post('hi_fnet');
			
			$data['si_vat']=$this->input->post('hi_vat');
			$data['si_delivery_date']=$this->input->post('hi_delivery_date');
			$data['si_remrk']=$this->input->post('hi_remrk');
			$data['si_tax_code']=$this->input->post('hi_tax_code');
			$data['si_tot_vat_amount']=$this->input->post('si_tot_vat');
			$data['si_tot_amount']=$this->input->post('si_tot_amount');
			$data['si_vat_type']=$this->input->post('si_vat_type');
			$data['si_sts']='1';
			$data['si_project']=$this->input->post('si_project');
			$data['si_cust_vat_number']=$this->input->post('si_cust_vat_number');
			$data['si_dt_updt']=get_date_time();

       $data['si_qnt_to_deliver']=$this->input->post('hi_qnty');
       $data['si_qnty_dlevered']=$this->input->post('hi_deliverd');
    
       
 
//print_r($data);
 



			
			//pre_list($data);
	if(empty($edit_inv_id))////willl insert
	{

		if($page_type=="uae")
			$document_bal_number=str_replace("INV ", "", $this->input->post('si_doc_no'));
		elseif($page_type=="ksa")
			$document_bal_number=str_replace("INV-KSA ", "", $this->input->post('si_doc_no'));
		elseif($page_type=="dragon")
			$document_bal_number=str_replace("SID ", "", $this->input->post('si_doc_no'));
		elseif($page_type=="export")
			$document_bal_number=str_replace("ESI ", "", $this->input->post('si_doc_no'));
				elseif($page_type=="UK")
			$document_bal_number=str_replace("INV-UK ", "", $this->input->post('si_doc_no'));
					elseif($page_type=="UAEAmazon")
			$document_bal_number=str_replace("INV-UA ", "", $this->input->post('si_doc_no'));
				elseif($page_type=="KSAamazon")
			$document_bal_number=str_replace("INV-KA ", "", $this->input->post('si_doc_no'));

		elseif($page_type=="ukamazon")
			$document_bal_number=str_replace("INV-AMZ ", "", $this->input->post('si_doc_no'));
		elseif($page_type=="uae-online")
			$document_bal_number=str_replace("INV-UAE ", "", $this->input->post('si_doc_no'));
			

			else{}	
		$data['si_doc_number']=$document_bal_number;
	}

	$sales_inv_id=array_filter(explode('|#|',$this->input->post('sales_inv_id')));
	$sales_inv_amount=array_filter(explode('|#|',$this->input->post('sales_inv_amount')));
	$sales_inv_amount_paid=array_filter(explode('|#|',$this->input->post('sales_inv_amount_paid')));
	$sales_doc_num=array_filter(explode('|#|',$this->input->post('sales_doc_num')));
	$tot_inv_amount_paid_from_ref=array_sum($sales_inv_amount_paid);

	$qnty_details=explode('|#|',$this->input->post('hi_qnty'));
	// pre_list($sales_inv_id);
	// pre_list($sales_inv_amount);
	// pre_list($sales_inv_amount_paid);
	// pre_list($sales_doc_num);

		if($this->input->post('si_vat_type')=="1")////taxable invoice
			{
				$amount_for_acc=$this->input->post('si_tot_amount')-$this->input->post('si_tot_vat');
			}
			else
			{
				$amount_for_acc=$this->input->post('si_tot_amount');
			}

	if(empty($edit_inv_id))
	{
		if($page_type=="uae")
		$insert_id=$this->Admin_model->insert_data('sales_invoice',$data);
		elseif($page_type=="ksa")
		$insert_id=$this->Admin_model->insert_data('sales_invoice_ksa',$data);
		elseif($page_type=="dragon")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_dragon',$data);
		elseif($page_type=="export")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_export',$data);
			elseif($page_type=="UK")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_uk',$data);
				elseif($page_type=="UAEAmazon")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_uae_amazon',$data);
			elseif($page_type=="KSAamazon")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_ksa_amazon',$data);

				elseif($page_type=="ukamazon")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_uk_amazon',$data);
				elseif($page_type=="uae-online")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_online_uae',$data);
			else{}




	if($insert_id=='0')
			{
          	$this->session->set_flashdata('errors', 'There is messing value please be sure for all entry.    /    الرجاء التأكد من جميع المدخلات   ');
				
          redirect('sales-invoice/'.$page_type);
            
			}
		/////$insert_id=12;
		else if(!empty($insert_id))
		{
			if($page_type=="uae")
		$this->Admin_model->update_data('sales_invoice',array('si_current_sts'=>'not-paid','si_delivery_sts'=>'not_delivered','si_fullreturn_sts'=>'0' ,'si_date'=>$new_formated_date1,'si_user_created'=>$this->session->userdata['user']['username'],'si_dt_crtd'=>get_date_time()),array('si_id'=>$insert_id));
		elseif($page_type=="ksa")
		$this->Admin_model->update_data('sales_invoice_ksa',array('si_current_sts'=>'not-paid','si_delivery_sts'=>'not_delivered','si_fullreturn_sts'=>'0' ,'si_date'=>$new_formated_date1,'si_user_created'=>$this->session->userdata['user']['username'],'si_dt_crtd'=>get_date_time()),array('si_id'=>$insert_id));
		elseif($page_type=="dragon")
		$this->Admin_model->update_data('sales_invoice_dragon',array('si_current_sts'=>'not-paid','si_delivery_sts'=>'not_delivered','si_fullreturn_sts'=>'0','si_date'=>$new_formated_date1,'si_user_created'=>$this->session->userdata['user']['username'],'si_dt_crtd'=>get_date_time()),array('si_id'=>$insert_id));	
		elseif($page_type=="export")
		$this->Admin_model->update_data('sales_invoice_export',array('si_current_sts'=>'not-paid','si_delivery_sts'=>'not_delivered','si_fullreturn_sts'=>'0','si_date'=>$new_formated_date1,'si_user_created'=>$this->session->userdata['user']['username'],'si_dt_crtd'=>get_date_time()),array('si_id'=>$insert_id));	
		elseif($page_type=="UK")
		$this->Admin_model->update_data('sales_invoice_uk',array('si_current_sts'=>'not-paid','si_delivery_sts'=>'not_delivered','si_fullreturn_sts'=>'0','si_date'=>$new_formated_date1,'si_user_created'=>$this->session->userdata['user']['username'],'si_dt_crtd'=>get_date_time()),array('si_id'=>$insert_id));
		elseif($page_type=="UAEAmazon")
		$this->Admin_model->update_data('sales_invoice_uae_amazon',array('si_current_sts'=>'not-paid','si_delivery_sts'=>'not_delivered','si_fullreturn_sts'=>'0','si_date'=>$new_formated_date1,'si_user_created'=>$this->session->userdata['user']['username'],'si_dt_crtd'=>get_date_time()),array('si_id'=>$insert_id));	
		elseif($page_type=="KSAamazon")
		$this->Admin_model->update_data('sales_invoice_ksa_amazon',array('si_current_sts'=>'not-paid','si_delivery_sts'=>'not_delivered','si_fullreturn_sts'=>'0','si_date'=>$new_formated_date1,'si_user_created'=>$this->session->userdata['user']['username'],'si_dt_crtd'=>get_date_time()),array('si_id'=>$insert_id));	

		elseif($page_type=="ukamazon")
		$this->Admin_model->update_data('sales_invoice_uk_amazon',array('si_current_sts'=>'not-paid','si_delivery_sts'=>'not_delivered','si_fullreturn_sts'=>'0','si_date'=>$new_formated_date1,'si_user_created'=>$this->session->userdata['user']['username'],'si_dt_crtd'=>get_date_time()),array('si_id'=>$insert_id));		

		elseif($page_type=="uae-online")
		$this->Admin_model->update_data('sales_invoice_online_uae',array('si_current_sts'=>'not-paid','si_delivery_sts'=>'not_delivered','si_fullreturn_sts'=>'0','si_date'=>$new_formated_date1,'si_user_created'=>$this->session->userdata['user']['username'],'si_dt_crtd'=>get_date_time()),array('si_id'=>$insert_id));		
			else{}
           $act_doc_num=$this->input->post('si_doc_no');
		$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'sales invoice created',
				'act_status'=>'sales invoice id '.$insert_id.' created,also added to account_master_trasaction table- inv amount - '.$this->input->post('si_tot_amount').' ',
				'act_sales_inv_id'=>$insert_id,
				'act_sales_inv_page_type'=>$page_type,
			        'act_doc_num'=>$act_doc_num,
				'act_type'=>'Sales Invoice -'  .$page_type.' ',
				'act_type_id'=>$insert_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()
			);
			   $this->Admin_model->insert_data('activities',$activity_data);
			  $this->session->set_flashdata('success', 'Data Successfully inserted');
		}
	}
		else/////updating here/////
		{

///////we must put code here 
 ///wael try to follow user edit 6-2-2022

	  if($page_type=='uae')
			{
			 $invoce_befor_edit=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$edit_inv_id));
			}	
			elseif($page_type=='ksa')
			{
			 $invoce_befor_edit=$this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$edit_inv_id));
			}
			elseif($page_type=='dragon')
			{
			 $invoce_befor_edit=$this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$edit_inv_id));
			}	
			elseif($page_type=="export")
			{
			 $invoce_befor_edit=$this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$edit_inv_id));
			}
				elseif($page_type=="UK")
			{
     
			 $invoce_befor_edit=$this->Admin_model->get_data('sales_invoice_uk',array('si_id'=>$edit_inv_id));
         // print_r( $invoce_befor_edit);exit();
			}
				elseif($page_type=="UAEAmazon")
			{
			 $invoce_befor_edit=$this->Admin_model->get_data('sales_invoice_uae_amazon',array('si_id'=>$edit_inv_id));
			}
				elseif($page_type=="KSAamazon")
			{
			 $invoce_befor_edit=$this->Admin_model->get_data('sales_invoice_ksa_amazon',array('si_id'=>$edit_inv_id));
			}
      
      	elseif($page_type=="ukamazon")
			{
			 $invoce_befor_edit=$this->Admin_model->get_data('sales_invoice_uk_amazon',array('si_id'=>$edit_inv_id));
			}
	elseif($page_type=="uae-online")
			{
			 $invoce_befor_edit=$this->Admin_model->get_data('sales_invoice_online_uae',array('si_id'=>$edit_inv_id));
			}
			else{}

     if(!empty($invoce_befor_edit)){
 //i will used for comparing between the old and new value an to develop the website with newtable 
     	$databefore['si_doc_no']= $invoce_befor_edit[0]->si_doc_no;
			$databefore['si_customer_acc_id']=$invoce_befor_edit[0]->si_customer_acc_id;
			$databefore['si_sales_acc_id']=$invoce_befor_edit[0]->si_sales_acc_id;
			$databefore['si_lpo_no']=$invoce_befor_edit[0]->si_lpo_no;
			$databefore['si_company']=$invoce_befor_edit[0]->si_company;
			$databefore['si_pc_level']=$invoce_befor_edit[0]->si_pc_level;
			$databefore['si_salesman']=$invoce_befor_edit[0]->si_salesman;
			$databefore['si_contact']=$invoce_befor_edit[0]->si_contact;
			$databefore['si_payment_type']=$invoce_befor_edit[0]->si_payment_type;
			$databefore['si_country']=$invoce_befor_edit[0]->si_country;
			$databefore['si_narration']=$invoce_befor_edit[0]->si_narration;
			$databefore['si_mark']=$invoce_befor_edit[0]->si_mark;
			$databefore['si_shipping_contact']=$invoce_befor_edit[0]->si_shipping_contact;
			$databefore['si_delivery_address']=$invoce_befor_edit[0]->si_delivery_address;
			$databefore['si_plc_supply']=$invoce_befor_edit[0]->si_plc_supply;
		    $databefore['si_jurisdiction']=$invoce_befor_edit[0]->si_jurisdiction;
			$databefore['si_currency']=$invoce_befor_edit[0]->si_currency;
			$databefore['si_conv_value']=$invoce_befor_edit[0]->si_conv_value;
			$databefore['si_attachments']=$data_image;//i will used i ineed to save the old value of edited invoice
			$databefore['si_warehouse']=$invoce_befor_edit[0]->si_warehouse;
			$databefore['si_product']=$invoce_befor_edit[0]->si_product;
			$databefore['si_qnty']=$invoce_befor_edit[0]->si_qnty;
			$databefore['si_rate']=$invoce_befor_edit[0]->si_rate;
			$databefore['si_gross']=$invoce_befor_edit[0]->si_gross;
			$databefore['si_dis_per']=$invoce_befor_edit[0]->si_dis_per;
			$databefore['si_dis_amount']=$invoce_befor_edit[0]->si_dis_amount;
			$databefore['si_add_charges']=$invoce_befor_edit[0]->si_add_charges;
			$databefore['si_fnet']=$invoce_befor_edit[0]->si_fnet;
			
			$databefore['si_vat']=$invoce_befor_edit[0]->si_vat;
			$databefore['si_delivery_date']=$invoce_befor_edit[0]->si_delivery_date;
			$databefore['si_remrk']=$invoce_befor_edit[0]->si_remrk;
			$databefore['si_tax_code']=$invoce_befor_edit[0]->si_tax_code;
			$databefore['si_tot_vat_amount']=$invoce_befor_edit[0]->si_tot_vat_amount;
			$databefore['si_tot_amount']=$invoce_befor_edit[0]->si_tot_amount;
			$databefore['si_vat_type']=$invoce_befor_edit[0]->si_vat_type;
			$data['si_sts']='1';  //i will used i ineed to save the old value of edited invoice
			$databefore['si_project']=$invoce_befor_edit[0]->si_project;
			$databefore['si_cust_vat_number']=$invoce_befor_edit[0]->si_cust_vat_number;      
                    
      
     }

     else {}
				
	 //i needd to compare between  the values befor and exict value to get the changed value then report that in the activities table

        if($databefore['si_customer_acc_id']!=$data['si_customer_acc_id'])
         {
           
         	 $datatorecord['si_customer_acc_id']=$data['si_customer_acc_id'];
         	 $customer_ac_old='customer_acc='.$databefore['si_customer_acc_id'].',';
           $customer_ac_new='customer_acc='.$data['si_customer_acc_id'].',';

          } 
       else {$datatorecord['si_customer_acc_id']=null;}

        if($databefore['si_sales_acc_id']!=$data['si_sales_acc_id'])
         { 
	         	$datatorecord['si_sales_acc_id']=$data['si_sales_acc_id'];
	          $sales_acc_old='sales_acc_id='.$databefore['si_sales_acc_id'].',';
	          $sales_acc_new='sales_acc_id='.$data['si_sales_acc_id'].',';
         }	
        else {$datatorecord['si_sales_acc_id']=null;}

        if($databefore['si_lpo_no']!=$data['si_lpo_no'])
        {
        	$datatorecord['si_lpo_no']=$data['si_lpo_no'];
          $lpo_no_old='lpo_no='.$databefore['si_lpo_no'].',';
	        $lpo_no_new='lpo_no='.$data['si_lpo_no'].',';
        }
        else {$datatorecord['si_lpo_no']=null;}

       if($databefore['si_company']!=$data['si_company'])
       {
       	$datatorecord['si_company']=$data['si_company'];
       	$company_old='company_no='.$databefore['si_company'].',';
	      $company_new='company_no='.$data['si_company'].',';

       }
       else {$datatorecord['si_company']=null;}
       

       if($databefore['si_pc_level']!=$data['si_pc_level'])
       {
          $datatorecord['si_pc_level']=$data['si_pc_level'];
          $pc_level_old='pc_level='.$databefore['si_pc_level'].',';
	       $pc_level_new='pc_level='.$data['si_pc_level'].',';

       }
      else {$datatorecord['si_pc_level']=null;}

     
     if($databefore['si_salesman']!=$data['si_salesman'])
     {
          $datatorecord['si_salesman']=$data['si_salesman'];
          $salesman_old='salesman='.$databefore['si_salesman'].',';
	       $salesman_new='salesman='.$data['si_salesman'].',';

     }
    
    else {$datatorecord['si_salesman']=null;}

     if($databefore['si_contact']!=$data['si_contact'])
     {
         $datatorecord['si_contact']=$data['si_contact'];
          $contact_old='contact='.$databefore['si_contact'].',';
	       $contact_new='contact='.$data['si_contact'].',';

     }
     else {$datatorecord['si_contact']=null;}
     
      if($databefore['si_payment_type']!=$data['si_payment_type'])
       {
	        $datatorecord['si_payment_type']=$data['si_payment_type'];
	        $payment_type_old='payment_type='.$databefore['si_payment_type'].',';
		      $payment_type_new='payment_type='.$data['si_payment_type'].',';

       }    
       else {$datatorecord['si_payment_type']=null;}

      if($databefore['si_country']!=$data['si_country'])
       {
          $datatorecord['si_country']=$data['si_country'];
           $country_old='country='.$databefore['si_country'].',';
		      $country_new='country='.$data['si_country'].',';

       } 
       else {$datatorecord['si_country']=null;}

       if($databefore['si_narration']!=$data['si_narration'])
        {
             	 $datatorecord['si_narration']=$data['si_narration'];
             	// $data_narriation_new=$datatorecord['si_narration'];
               $narration_old='si_narration='.$databefore['si_narration'].',';
              $narration_new='si_narration='.$data['si_narration'].',';
        }	

       else {$datatorecord['si_narration']=null;}

       if($databefore['si_mark']!=$data['si_mark'])
         {
          	$datatorecord['si_mark']=$data['si_mark'];  
            $mark_old='mark='.$databefore['si_mark'].',';
            $mark_new='mark='. $data['si_mark'].',';
         }  
          else {$datatorecord['si_mark']=null;}
          
       if($databefore['si_shipping_contact']!=$data['si_shipping_contact'])
        {
           $datatorecord['si_shipping_contact']=$data['si_shipping_contact'];
            $shipping_contact_old='shipping_contact='.$databefore['si_shipping_contact'].',';
            $shipping_contact_new='shipping_contact='.$data['si_shipping_contact'].',';

         }
         else {$datatorecord['si_shipping_contact']=null;}  
           

       if($databefore['si_delivery_address']!=$data['si_delivery_address'])
        {
           $datatorecord['si_delivery_address']=$data['si_delivery_address'];

           $delivery_address_old='delivery_address='.$databefore['si_delivery_address'].',';
            $delivery_address_new='delivery_address='.$data['si_delivery_address'].',';

        } 
         else {$datatorecord['si_delivery_address']=null;}  

      if($databefore['si_plc_supply']!=$data['si_plc_supply'])
       {
          $datatorecord['si_plc_supply']=$data['si_plc_supply'];
            $plc_supply_old='delivery_address='.$databefore['si_plc_supply'].',';
            $plc_supply_new='delivery_address='.$data['si_plc_supply'].',';
    
       }
        else {$datatorecord['si_plc_supply']=null;}  

       if($databefore['si_jurisdiction']!=$data['si_jurisdiction'])
        { 
           
          $datatorecord['si_jurisdiction']=$data['si_jurisdiction'];
          // $data_jurisdiction_new=$datatorecord['si_jurisdiction'];
          $jurisdiction_old='jurisdiction='.$databefore['si_jurisdiction'].' ,';
          $jurisdiction_new='jurisdiction='.$data['si_jurisdiction'].',';

        }	
       else {$datatorecord['si_jurisdiction']=null;}
        
         if($databefore['si_currency']!=$data['si_currency'])
          {
		          $datatorecord['si_currency']=$data['si_currency'];
		          $currency_old='currency='.$databefore['si_currency'].' ,';
		          $currency_new='currency='.$data['si_currency'].',';

          } 
          else {$datatorecord['si_currency']=null;}

       if($databefore['si_conv_value']!=$data['si_conv_value'])
         {
             $datatorecord['si_conv_value']=$data['si_conv_value'];   
              $conv_value_old='conv_value='.$databefore['si_conv_value'].' ,';
		          $conv_value_new='conv_value='.$data['si_conv_value'].','; 

         } 
         else {$datatorecord['si_conv_value']=null;}

       /* if($databefore['si_attachments']!=$data['si_attachments'])
          {
            $datatorecord['si_attachments']=$data['si_attachments'];
            $attachments_old='attachments  ='.$databefore['si_attachments'].' ,';
		        $attachments_new='attachments  ='. $data['si_attachments'].','; 

          } 
           else {$datatorecord['si_attachments']=null;}
        */
       if($databefore['si_warehouse']!=$data['si_warehouse'])
         {
         	 $datatorecord['si_warehouse']=$data['si_warehouse'];
         	 $warehouse_old='warehouse='.$databefore['si_warehouse'].' ,';
		        $warehouse_new='warehouse='. $data['si_warehouse'].','; 
         }  
           else {$datatorecord['si_warehouse']=null;}

         if($databefore['si_product']!=$data['si_product'])
         {
           $datatorecord['si_product']=$data['si_product'];
           $product_old='product='.$databefore['si_product'].' ,';
		        $product_new='product='.$data['si_product'].','; 
         }
         else {$datatorecord['si_product']=null;}

         if($databefore['si_qnty']!=$data['si_qnty'])
         {
           $datatorecord['si_qnty']=$data['si_qnty'];
           $qnty_old='qnty='.$databefore['si_qnty'].' ,';
		       $qnty_new='qnty='.$data['si_qnty'].','; 
         }
         else {$datatorecord['si_qnty']=null;}

         if($databefore['si_rate']!=$data['si_rate'])
           {
           	 $datatorecord['si_rate']=$data['si_rate'];
           	 $rate_old='rate_old='.$databefore['si_rate'].' ,';
		         $rate_new='rate_old='.$data['si_rate'].',';

           }
           else {$datatorecord['si_rate']=null;}

         if($databefore['si_gross']!=$data['si_gross'])
         {
           $datatorecord['si_gross']=$data['si_gross'];
            $gross_old='gross='.$databefore['si_gross'].' ,';
		         $gross_new='gross='.$data['si_gross'].',';
         }
          else {$datatorecord['si_gross']=null;}

          if($databefore['si_dis_per']!=$data['si_dis_per'])
          {
          	 $datatorecord['si_dis_per']=$data['si_dis_per'];
          	 $dis_per_old='dis_per='.$databefore['si_dis_per'].' ,';
		         $dis_per_new='dis_per='.$data['si_dis_per'].',';
          }
         else {$datatorecord['si_dis_per']=null;}
        
         if($databefore['si_dis_amount']!=$data['si_dis_amount'])
         {

           $datatorecord['si_dis_amount']=$data['si_dis_amount'];
            $dis_amount_old='dis_amount='.$databefore['si_dis_amount'].' ,';
		         $dis_amount_new='dis_amount='.$data['si_dis_amount'].',';
         }
         else {$datatorecord['si_dis_amount']=null;}

        if($databefore['si_add_charges']!=$data['si_add_charges'])
        {
           $datatorecord['si_add_charges']=$data['si_add_charges'];  
           $add_charges_old='add_charges='.$databefore['si_add_charges'].',';
		       $add_charges_new='add_charges='.$data['si_add_charges'].',';
        }
        else {$datatorecord['si_add_charges']=null;}
       
       if($databefore['si_fnet']!=$data['si_fnet'])
         {
         	   $datatorecord['si_fnet']=$data['si_fnet'];    
         	   $fnet_old='fnet='.$databefore['si_fnet'].',';
		         $fnet_new='fnet='.$data['si_fnet'].',';
         }
         else {$datatorecord['si_fnet']=null;}

        if($databefore['si_vat']!=$data['si_vat'])
        {
           $datatorecord['si_vat']=$data['si_vat'];
           $vat_old='vat='.$databefore['si_vat'].',';
		       $vat_new='vat='.$data['si_vat'].',';
        }
         else {$datatorecord['si_vat']=null;}

       if($databefore['si_delivery_date']!=$data['si_delivery_date'])
       {
       	 $datatorecord['si_delivery_date']=$data['si_delivery_date'];
       	 $delivery_date_old='vat='.$databefore['si_delivery_date'].',';
		       $delivery_date_new='vat='. $data['si_delivery_date'].',';
       }
        else {$datatorecord['si_delivery_date']=null;} 
       
       if($databefore['si_remrk']!=$data['si_remrk'])
          {
          	$datatorecord['si_remrk']=$data['si_remrk'];
          	$remrk_old='remrk='.$databefore['si_remrk'].',';
		       $remrk_new='remrk='.$data['si_remrk'].',';
          } 
          else {$datatorecord['si_remrk']=null;} 


           if($databefore['si_tax_code']!=$data['si_tax_code'])
           {
           	  $datatorecord['si_tax_code']=$data['si_tax_code'];
           	  $tax_code_old='tax_code='.$databefore['si_tax_code'].',';
		          $tax_code_new='tax_code='.$data['si_tax_code'].',';

           }
           else {$datatorecord['si_tax_code']=null;} 

          if($databefore['si_tot_vat_amount']!=$data['si_tot_vat_amount'])
          {
            $datatorecord['si_tot_vat_amount']=$data['si_tot_vat_amount'];
            $tot_vat_amount_old='tot_vat_amount='.$databefore['si_tot_vat_amount'].',';
		        $tot_vat_amount_new='tot_vat_amount='.$data['si_tot_vat_amount'].',';
          }
          else {$datatorecord['si_tot_vat_amount']=null;}


          if($databefore['si_tot_amount']!=$data['si_tot_amount'])

          {
          	$datatorecord['si_tot_amount']=$data['si_tot_amount'];
            $tot_amount_old='tot_amount='.$databefore['si_tot_amount'].',';
		        $tot_amount_new='tot_amount='. $data['si_tot_amount'].',';
          }
           else {$datatorecord['si_tot_amount']=null;}
       

          if($databefore['si_vat_type']!=$data['si_vat_type'])
           {
           	$datatorecord['si_vat_type']=$data['si_vat_type'];
            $vat_type_old='vat_type='.$databefore['si_vat_type'].',';
		        $vat_type_new='vat_type='.$data['si_vat_type'].',';
           }
           else {$datatorecord['si_vat_type']=null;}
      
        

         //else{}


           $whatwas=$customer_ac_old . $sales_acc_old . $lpo_no_old . $company_old. $pc_level_old. $salesman_old. $contact_old. $payment_type_old. $country_old. $narration_old. $mark_old. $shipping_contact_old. $delivery_address_old. $plc_supply_old. $jurisdiction_old. $currency_old. $conv_value_old .$attachments_old .$warehouse_old .$product_old .$qnty_old .$rate_old .$gross_old .$dis_per_old   .$dis_amount_old  .$add_charges_old .$fnet_old .$vat_old .$delivery_date_old .$remrk_old .$tax_code_old .$tot_vat_amount_old .$tot_amount_old .$vat_type_old ;

           $whatnow=$customer_ac_new . $sales_acc_new . $lpo_no_new . $company_new. $pc_level_new. $salesman_new. $contact_new. $payment_type_new. $country_new. $narration_new. $mark_new. $shipping_contact_new. $delivery_address_new. $plc_supply_new. $jurisdiction_new. $currency_new. $conv_value_nes .$attachments_new .$warehouse_new .$product_new .$qnty_new .$rate_new .$gross_new .$dis_per_new   .$dis_amount_new  .$add_charges_new .$fnet_new .$vat_new .$delivery_date_new .$remrk_new .$tax_code_new .$tot_vat_amount_new .$tot_amount_new .$vat_type_new ;


////// to here my code for checking the change
				if($page_type=="uae")
					$this->Admin_model->update_data('sales_invoice',$data,array('si_id'=>$edit_inv_id));
				elseif($page_type=="ksa")
					$this->Admin_model->update_data('sales_invoice_ksa',$data,array('si_id'=>$edit_inv_id));
				elseif($page_type=="dragon")
					$this->Admin_model->update_data('sales_invoice_dragon',$data,array('si_id'=>$edit_inv_id));
				elseif($page_type=="export")
					$this->Admin_model->update_data('sales_invoice_export',$data,array('si_id'=>$edit_inv_id));
						elseif($page_type=="UK")
					$this->Admin_model->update_data('sales_invoice_uk',$data,array('si_id'=>$edit_inv_id));
						elseif($page_type=="UAEAmazon")
					$this->Admin_model->update_data('sales_invoice_uae_amazon',$data,array('si_id'=>$edit_inv_id));
					elseif($page_type=="KSAamazon")
					$this->Admin_model->update_data('sales_invoice_ksa_amazon',$data,array('si_id'=>$edit_inv_id));
							elseif($page_type=="ukamazon")
					$this->Admin_model->update_data('sales_invoice_uk_amazon',$data,array('si_id'=>$edit_inv_id));

	           elseif($page_type=="uae-online")
					$this->Admin_model->update_data('sales_invoice_online_uae',$data,array('si_id'=>$edit_inv_id));

				else{}
			
			$current_sales_inv_amount=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$edit_inv_id,'atx_doc_no'=>$this->input->post('si_doc_no'),'atx_type_tx'=>'Sales_Invoice','atx_region'=>$page_type));
			
			if(!empty($current_sales_inv_amount))
			{
				$current_sales_bal_amount=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$current_sales_inv_amount[0]->atx_id));
					if(!empty($current_sales_bal_amount))
					{
						foreach($current_sales_bal_amount as $index=>$csb)
						{
							$acc_tx_details_2=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$csb->actb_to_id));
							
							$current_paid_amount=$acc_tx_details_2[0]->atx_paid_amount;
							$current_bal_amount=$acc_tx_details_2[0]->atx_bal_amount;
							$new_paid_amount=$current_paid_amount-$csb->actb_paid_amount;
							$new_bal_amount=$current_bal_amount+$csb->actb_paid_amount;
							$array_new_data=array(
						'atx_paid_amount'=>$new_paid_amount,
						'atx_bal_amount'=>$new_bal_amount,
						);
					  $this->Admin_model->update_data('account_all_tx',$array_new_data,array('atx_id'=>$csb->actb_to_id));
					  $this->Admin_model->delete_data('account_tx_bal_data',array('actb_tx_id'=>$csb->actb_tx_id));
						}	
					}
 			}
			 $act_doc_num=$this->input->post('si_doc_no');
		$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'sales invoice updated',
				'act_status'=>'sales invoice id '.$edit_inv_id.' with doc_number '.$data['si_doc_no'].' updated for the values : '.$whatwas.' and they changed to: '.$whatnow.',also updated in account_master_trasaction table-inv amount-'.$this->input->post('si_tot_amount').' ', 
				'act_sales_inv_id'=>$edit_inv_id,
				'act_sales_inv_page_type'=>$page_type,
			  'act_doc_num'=>$act_doc_num,
				'act_type'=>'Sales Invoice -'. $page_type.' ',
				'act_type_id'=>$edit_inv_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()
			);
		  $this->Admin_model->insert_data('activities',$activity_data);

	$this->session->set_flashdata('success', 'Data Successfully updated');
		}
		if(!empty($insert_id) || !empty($edit_inv_id) )
		{
			if(!empty($insert_id))
			{
				$sales_id_inv_id=$insert_id;
			}
			elseif (!empty($edit_inv_id)) 
			{
				$sales_id_inv_id=$edit_inv_id;
			}
			else
			{
				$sales_id_inv_id='';
			}
			if(!empty($sales_id_inv_id))
			{
		/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////	
					$data_tx['atx_user_created']=$this->session->userdata['user']['username'];
					$data_tx['atx_type_tx']='Sales_Invoice';
					$data_tx['atx_date']=$new_formated_date1;
					$data_tx['atx_doc_no']=$this->input->post('si_doc_no');
					$data_tx['atx_main_id']=$sales_id_inv_id;
					$data_tx['atx_acc_id']=$this->input->post('si_sales_acc_id');
					$data_tx['atx_cust_id']=$this->input->post('si_customer_acc_id');
					$data_tx['atx_tot_amount']=$this->input->post('si_tot_amount');
					$data_tx['atx_vat_amount']=$this->input->post('si_tot_vat');
					$data_tx['atx_region']=$page_type;
					$data_tx['atx_narration']=$this->input->post('si_narration');
					$data_tx['atx_quantity']=array_sum($qnty_details);
					$data_tx['atx_salesman']=$this->input->post('si_salesman');
					$data_tx['atx_currency_value']=$this->input->post('si_conv_value');
					$data_tx['atx_currency_type']=$this->input->post('si_currency');
					//	pre_list($data_tx);
				
				if(!empty(array_sum($sales_inv_amount_paid)))
							{
								// echo "inside the sales inv paid";echo "<br/>";
								// print_r($sales_inv_amount_paid);
							//echo "inside last if";echo "<br/>";
								$data_final_bal_amount=$this->input->post('si_tot_amount')-array_sum($sales_inv_amount_paid);
								//print_r($data_final_bal_amount);echo "<br/>";print_r(array_sum($sales_inv_amount_total));									
								$data_tx['atx_bal_amount']=$data_final_bal_amount;
								$data_tx['atx_paid_amount']=array_sum($sales_inv_amount_paid);
							}
							else
							{
								$data_tx['atx_bal_amount']=$this->input->post('si_tot_amount');
								$data_tx['atx_paid_amount']='0';
							}	

					$data_tx['atx_dt_updt']=get_date_time();
					$data_tx['atx_sts']='1';
					$data_tx['atx_amount_type']='Income';

		if(!empty($edit_inv_id))////if edit selected, then update the tx table details 
			{
				// echo "in if - with edit id";
			$this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_main_id'=>$edit_inv_id,'atx_doc_no'=>$this->input->post('si_doc_no'),'atx_type_tx'=>'Sales_Invoice','atx_region'=>$page_type));
						
				// pre_list($data_tx);
				/// print_r($current_sales_inv_amount[0]->atx_id);
				$insert_id_acc_tx=$current_sales_inv_amount[0]->atx_id;
			}
			else
			{
				// echo "in else - no edit id";
				// pre_list($data_tx);
				$insert_id_acc_tx=$this->Admin_model->insert_data('account_all_tx',$data_tx);
			}
		
			foreach($sales_inv_id as $index=>$si)
			{		
			if(!empty($sales_inv_amount_paid[$index]))
				{
					if(!empty($sales_inv_amount_paid[$index]))
					{
						$amount_paid_till_now=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$si));
				  		$bal_amount_sales_inv=$sales_inv_amount[$index]-$sales_inv_amount_paid[$index];
				  		
				  		$data_si_array=array(
				  			'atx_paid_amount'=>$amount_paid_till_now[0]->atx_paid_amount+$sales_inv_amount_paid[$index],
				  			'atx_bal_amount'=>$bal_amount_sales_inv,
				  		);
				 // print_r($data_si_array);
				 // print_r($si);
			  	$this->Admin_model->update_data('account_all_tx',$data_si_array,array('atx_id'=>$si));  ///updating the already found invoices///

				$data_tx_bal=array(
					'actb_tx_id'=>$insert_id_acc_tx,
					'actb_to_type'=>$sales_doc_num[$index],
					'actb_paid_amount'=>$sales_inv_amount_paid[$index],
					'actb_to_id'=>$si,
					'actd_sts'=>'1',
					'actb_user_created'=>$this->session->userdata['user']['username'],
				);	
				 // print_r($data_tx_bal);
				$this->Admin_model->insert_data('account_tx_bal_data',$data_tx_bal);
					}
				}
			}  
		
		if($this->input->post('si_vat_type')=="1")////taxable invoice
		{
						if($page_type=="uae")
						{
							$vat_acc_id_to_use='1014';/////if vat os other customers, normal vat output a/c is affected///////
						}
						elseif($page_type=="ksa")
						{
							$vat_acc_id_to_use='759';/////if vat os other customers, normal vat output a/c is affected///////
						}
						elseif($page_type=="dragon")
						{
							$vat_acc_id_to_use='1016';////if customer is dragon-sales cust, need to affect the vat of dragon sales/////
						}
						else{}

			  /////////////////vat o/p account data //////////////////			 	
					$data_tx['atx_user_created']=$this->session->userdata['user']['username'];
					$data_tx['atx_type_tx']='Vat_OP';
					$data_tx['atx_date']=$new_formated_date1;
					$data_tx['atx_doc_no']=$this->input->post('si_doc_no');
					$data_tx['atx_main_id']=$sales_id_inv_id;
					$data_tx['atx_acc_id']=$vat_acc_id_to_use;
					$data_tx['atx_cust_id']=$this->input->post('si_customer_acc_id');
					$data_tx['atx_tot_amount']=$this->input->post('si_tot_vat');
					$data_tx['atx_paid_amount']='0';
					$data_tx['atx_bal_amount']=$this->input->post('si_tot_vat');
					$data_tx['atx_dt_updt']=get_date_time();
					$data_tx['atx_sts']='1';
					$data_tx['atx_amount_type']='Income';
					$data_tx['atx_tranfer_type']='sales_invoice';
					$data_tx['atx_region']=$page_type;
					$data_tx['atx_narration']=$this->input->post('si_narration');
					$data_tx['atx_quantity']=array_sum($qnty_details);
					$data_tx['atx_salesman']=$this->input->post('si_salesman');
					$data_tx['atx_currency_value']=$this->input->post('si_conv_value');
					$data_tx['atx_currency_type']=$this->input->post('si_currency');
					//pre_list($data_tx);
				if(!empty($edit_inv_id))
				{	
					// echo "inside if - vat";
					// pre_list($data_tx);
				$this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_main_id'=>$edit_inv_id,'atx_doc_no'=>$this->input->post('si_doc_no'),'atx_type_tx'=>'Vat_OP','atx_region'=>$page_type ));
				}
				else
				{
					// echo "inside else - vat";
					// pre_list($data_tx);
			$insert_id_acc_vat_tx=$this->Admin_model->insert_data('account_all_tx',$data_tx);
				}
		}
			redirect('list-sales-invoice/'.$page_type);////if customer is dragon-sales cust, need to affect the vat of dragon sales/////
			
		/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////
		}
		else
		{
			 $this->session->set_flashdata('errors', 'Error on data found. Please try again.');
		 		redirect('list-sales-invoice/'.$page_type);////if customer is dragon-sales cust, need to affect the vat of dragon sales/////		
		}
	}
////////////ending if for checking insert_id exist here////////////////////////////////////////////////
	}	
}

function list_sales_invoice($page_name=null)
{
	if(logged_in())
	{
		$another_condition = '';
			$sort_by = '';
			if(!empty($this->input->post('sortBy')))
			{
				$sort_by = $this->input->post('sortBy');
				if($sort_by == 'paid')
				{
					$another_condition = "and siv.si_current_sts='" . 'fully-paid' . "' ";
				}
				elseif($sort_by == 'partially_paid')
				{
					$another_condition = "and siv.si_current_sts='" . 'partially-paid' . "' ";
				}
				else{
					$another_condition = "and siv.si_current_sts='" . 'not-paid' . "' ";
				}
				
			}
		if(!empty($page_name))
		{

		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'list-sales-invoice'));
		if($page_name=="uae")
		{
			$from_table="sales_invoice";
		}
		elseif($page_name=="ksa")
		{
			$from_table="sales_invoice_ksa";
		}
		elseif($page_name=="dragon")
		{
			$from_table="sales_invoice_dragon";
		}
		elseif($page_name=="export")
		{
			$from_table="sales_invoice_export";
		}

			elseif($page_name=="UK")
		{
			$from_table="sales_invoice_uk";
		}
			elseif($page_name=="UAEAmazon")
		{
			$from_table="sales_invoice_uae_amazon";
		}
			elseif($page_name=="KSAamazon")
		{
			$from_table="sales_invoice_ksa_amazon";
		}
			elseif($page_name=="ukamazon")
		{
			
			$from_table="sales_invoice_uk_amazon";
		}
			elseif($page_name=="uae-online")
		{
			
			$from_table="sales_invoice_online_uae";
			
		}
		
      
		else{}

		if($this->session->userdata['user']['main_dept']=="Sales")
			{
				if($page_name=="ksa" )
				{
					if($this->session->userdata['user']['user_desig']!="Team-lead")////FOR STAFF USERS////
					{
						//$cond_user_session = "and siv.si_user_created='" . $this->session->userdata['user']['username'] . "' ";
							$cond_user_session = "";
					}
					else
					{
						$cond_user_session="";
					}
				}
				else
				{
					$cond_user_session="and siv.si_user_created='".$this->session->userdata['user']['username']."' ";
				}
			}
			else
			{
				$cond_user_session="";
			}

		$sql2=$this->db->query("SELECT siv.*,mc.mcomp_name,mat.label as cust_acc,atx_bal_amount
	FROM ".$from_table." as siv join master_company as mc 
	on mc.mcomp_id=siv.si_company join master_accounts_tree as mat on mat.id=siv.si_customer_acc_id
	join  account_all_tx  on account_all_tx.atx_main_id=siv.si_id 
	WHERE siv.si_sts = '1' AND siv.si_date>'2022-12-31'   AND account_all_tx.atx_type_tx='Sales_Invoice' and account_all_tx.atx_region='".$page_name."' ".$cond_user_session .$another_condition." order by siv.si_id DESC");
	//echo $this->db->last_query();
		$data['result']=$sql2->result_array();
	
		foreach($data['result'] as $t)
		{
			// if($t['si_current_sts']!="fully-paid")
			// 	{
					$sql2=$this->db->query("SELECT atx_bal_amount,atx_paid_amount from account_all_tx where atx_type_tx='Sales_Invoice' and account_all_tx.atx_region='".$page_name."' and  atx_main_id='".$t['si_id']."' ");
					$qry_result=$sql2->result_array();
					//echo $this->db->last_query();
	//pre_list($qry_result[0]['atx_bal_amount']);
					if($qry_result[0]['atx_bal_amount']=='0')
					{
						$update_sts='fully-paid';
					}
					elseif($qry_result[0]['atx_bal_amount']=='0.00')
					{
						$update_sts='fully-paid';
					}
					elseif(!empty($qry_result[0]['atx_paid_amount']))
					{
						$update_sts='partially-paid';
					}
					else
					{
						$update_sts='not-paid';
					}
					
					$this->Admin_model->update_data($from_table,array('si_current_sts'=>$update_sts),array('si_id'=>$t['si_id']));
				// }
		}
		$data['page_type']=$page_name;
		$data['sort_by'] = $sort_by;
		//pre_list($data['result']);
		$this->load->view('admin/transactions/list_sales_invoice',$data);
		}
	}
}

/////////new step for import invoices from other websites  /////////


function upload_amazon_order_uk() 
{
	if(logged_in())
	{
     	$this ->load-> view('admin/sales_book/amazon_order');
	}
}
function upload_amazon_payment() 
{
	if(logged_in())
	{
     	$this ->load-> view('admin/sales_book/amazon_payment');
	}
}


function upload_amazon_order_uae() 
{
	if(logged_in())
	{
     	$this ->load-> view('admin/sales_book/amazon_order_uae');
	}
}


function submit_amazon_order_excel()
{
	$flag = 0;$voc_number='';
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/excel/amazon_orders/';
		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this->upload->do_upload('userfile')) 
		{
			$error = array('error' => $this->upload-> display_errors());
			$this->session ->set_flashdata('errors', $error['error']);
			redirect("list-amazon-upload", "refresh");
		} 
		else 
		{
		$data = array('userfile' => $this->upload->data());
		}
	
		if (!empty($data['userfile']['file_name'])) 
		{
		$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path.$import_xls_file;
		try 
		{
		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
		die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME).'": '.$e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		$grouped_data = array();
        // foreach($allDataInSheet as $rowws)
		// {
		// 	print_r($rowws['A']);

		// }exit();
		for ($i = 2; $i <= $arrayCount;$i++) 
		{	
		
			//$merchant_order_id = trim($allDataInSheet[$i]['B']); 
		//we need that as order_id
		$amazon_order_id = trim($allDataInSheet[$i]['A']);
		$order_number=trim($allDataInSheet[$i]['A']);
		$shop_name_prim=trim($allDataInSheet[$i]['G']);
		if($shop_name_prim=='Amazon.fr' ||$shop_name_prim=='Amazon.co.uk' ||$shop_name_prim=='Amazon.com.be'||$shop_name_prim=='Amazon.com.de')
           {
			$shop_name='Amazon.uk';
           }
		$shop_website=trim($allDataInSheet[$i]['G']);
		$inv_sts='1';
		$order_date=date("Y-m-d", strtotime(trim($allDataInSheet[$i]['D'])));
		$Item_statu=trim($allDataInSheet[$i]['N']);
        $company_name='Amazon Customer';
		$customer_name='Amazon Customer';
		$due_amount=doubleval(trim($allDataInSheet[$i]['Q']))+doubleval(trim($allDataInSheet[$i]['S']));
		$Total_amount=doubleval(trim($allDataInSheet[$i]['Q']))+doubleval(trim($allDataInSheet[$i]['S']));
		$sub_total=doubleval(trim($allDataInSheet[$i]['Q']))-doubleval(trim($allDataInSheet[$i]['R']));
		$total_tax=doubleval(trim($allDataInSheet[$i]['R']));
        $shipping_charge=doubleval(trim($allDataInSheet[$i]['S']));
         $Delivery_status=trim($allDataInSheet[$i]['E']);
		 if($Item_statu=='Shipped')
		 {
            $payment_status='paid';
		 }
		 else{
			$payment_status='unpaid';
		 }
          $currency_type=trim($allDataInSheet[$i]['P']);
		  $payment_type=trim($allDataInSheet[$i]['F']);
		  $country=trim($allDataInSheet[$i]['AB']);
		  $product_sku=trim($allDataInSheet[$i]['L']);
		  $phone='';
		  $address1=trim($allDataInSheet[$i]['Y']);
		 $Product_name_arr=trim($allDataInSheet[$i]['K']);
		  $Product_quantity_arr=trim($allDataInSheet[$i]['O']);
		  $Product_price_arr=$sub_total/ doubleval(trim($allDataInSheet[$i]['O']));
		 
		  if (isset($grouped_data[$amazon_order_id])) {
			// If the ID already exists in the array, add the quantity, price, and SKU to the existing values
			$grouped_data[$amazon_order_id]['Product_quantity_arr'].= '|#|' .$Product_quantity_arr;
			$grouped_data[$amazon_order_id]['Product_price_arr'].= '|#|' .$Product_price_arr;
			$grouped_data[$amazon_order_id]['product_sku'] .= '|#|' .$product_sku;
			$grouped_data[$amazon_order_id]['order_number'] =$order_number;
			$grouped_data[$amazon_order_id]['shop_name']=$shop_name;
			$grouped_data[$amazon_order_id]['shop_website']=$shop_website;
			$grouped_data[$amazon_order_id]['inv_sts']=$inv_sts;
			$grouped_data[$amazon_order_id]['order_date']=$order_date;
			$grouped_data[$amazon_order_id]['Item_statu']=$Item_statu;
			$grouped_data[$amazon_order_id]['company_name']=$company_name;
			$grouped_data[$amazon_order_id]['customer_name']=$customer_name;
			$grouped_data[$amazon_order_id]['due_amount']+=$due_amount;
			$grouped_data[$amazon_order_id]['Total_amount']+=$Total_amount;
			$grouped_data[$amazon_order_id]['sub_total']+=$sub_total;
			$grouped_data[$amazon_order_id]['total_tax']+=$total_tax;
			$grouped_data[$amazon_order_id]['shipping_charge']+=$shipping_charge;
			$grouped_data[$amazon_order_id]['Delivery_status']=$Delivery_status;
			$grouped_data[$amazon_order_id]['payment_status']=$payment_status;
			$grouped_data[$amazon_order_id]['currency_type']=$currency_type;
			$grouped_data[$amazon_order_id]['payment_type']=$payment_type;
			$grouped_data[$amazon_order_id]['country']=$country;
			$grouped_data[$amazon_order_id]['phone']=$phone;
			$grouped_data[$amazon_order_id]['address1']=$address1;
			$grouped_data[$amazon_order_id]['Product_name_arr'].= '|#|' .$Product_name_arr;

		} else {
			// If the ID doesn't exist in the array, create a new array element with the ID, quantity, price, and SKU
			$grouped_data[$amazon_order_id] = array(
				'id' => $amazon_order_id,
				'Product_quantity_arr' => $Product_quantity_arr,
				'Product_price_arr' => $Product_price_arr,
				'product_sku' => $product_sku,
				'order_number'=>$order_number,
				'shop_name'=>$shop_name,
				'shop_website'=>$shop_website,
				'inv_sts'=>$inv_sts,
			    'order_date'=>$order_date,
			    'Item_statu'=>$Item_statu,
				'company_name'=>$company_name,
			    'customer_name'=>$customer_name,
				'due_amount'=>$due_amount,
				'Total_amount'=>$Total_amount,
				'sub_total'=>$sub_total,
				'total_tax'=>$total_tax,
				'shipping_charge'=>$shipping_charge,
				'Delivery_status'=>$Delivery_status,
				'payment_status'=>$payment_status,
				'currency_type'=>$currency_type,
				'payment_type'=>$payment_type,
				'country'=>$country,
				'phone'=>$phone,
				'address1'=>$address1,
				'Product_name_arr'=>$Product_name_arr,

			);
		}

			if(!empty($amazon_order_id))
			{
			$data_voc_number=$this->Admin_model->record_count2('incoming_invoice_online',array('order_id'=>$amazon_order_id,'order_date'=>$order_date));

				if(!empty($data_voc_number) || $data_voc_number!=0)
				{
			$flag=1;
			$error_string.="This Order number already exist in table in this year mentioned in vochure.You have an error in Row $i of Cell B.Please remove those details and try again.<br/>";
				}
			}
		}





		/////end if uk  

		//if uae and ksa /////////




		if($flag==1)
		{
		
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/excel/amazon_orders/".$import_xls_file);
			redirect('list-incoming-invoice-online/amazon','refresh');
		}
		else
		{
			$dwnload_title=$this->input->post('dwnload_title');
			$data23=array(
			'excl_title'=>$dwnload_title,
			'excl_file'=>$inputFileName,
			'excl_status'=>"1",
			'excl_type' =>'result');

				foreach ($grouped_data as $row) {
				           // print_r($row['id']);
							$datainsert['order_id']=$row['id'];
							$datainsert['order_number']=$row['order_number'];
							$datainsert['shop_name']=$row['shop_name'];
							$datainsert['shop_website']=$row['shop_name'];
							$datainsert['inv_sts']='1';
							$datainsert['order_date']=$row['order_date'];
							$datainsert['company_name']=$row['company_name'];
							$datainsert['customer_name']=$row['customer_name'];
							$datainsert['due_amount']=$row['due_amount'];
							$datainsert['Total_amount']=$row['Total_amount'];
							$datainsert['sub_total']=$row['sub_total'];
							$datainsert['total_tax']=$row['total_tax'];
							$datainsert['shipping_charge']=$row['shipping_charge'];
							$datainsert['Delivery_status']=$row['Delivery_status'];
							$datainsert['payment_status']=$row['payment_status'];
							$datainsert['currency_type']=$row['currency_type'];
							$datainsert['payment_type']=$row['payment_type'];
							$datainsert['country']=$row['country'];
							$datainsert['product_sku']=$row['product_sku'];
							$datainsert['phone']=$row['phone'];
							$datainsert['address1']=$row['address1'];
							$datainsert['Product_name_arr']=$row['Product_name_arr'];
							$datainsert['Product_price_arr']=$row['Product_price_arr'];
							$datainsert['Product_quantity_arr']=$row['Product_quantity_arr'];

							$insert_id_vochr=$this->Admin_model->insert_data('incoming_invoice_online',$datainsert);

		             }
					 if(!($insert_id_vochr))
					 $status = false;
					 else
						 $status = true;
						 if ($status==true)
						 $this ->session-> set_flashdata('success', 'Imported Successfully');
					 else
						 $this ->session-> set_flashdata('errors', 'Error found. Try again!');
			 ////when amazon order list be ready we must make redirect to the list instead of this route
					 redirect("list-incoming-invoice-online/amazonuk", "refresh");
		}
}





//this because uae and ksa amazon order report is different from uae 


//to the uae and ksa amazon for future changes   for AllnewOrders



function submit_amazon_order_uae_excel()
{
	$flag = 0;$voc_number='';
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/excel/amazon_orders/';
		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this->upload->do_upload('userfile')) 
		{
			$error = array('error' => $this->upload-> display_errors());
			$this->session ->set_flashdata('errors', $error['error']);
			redirect("list-amazon-upload", "refresh");
		} 
		else 
		{
		$data = array('userfile' => $this->upload->data());
		}
	
		if (!empty($data['userfile']['file_name'])) 
		{
		$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path.$import_xls_file;
		try 
		{
		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
		die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME).'": '.$e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		$grouped_data = array();
        // foreach($allDataInSheet as $rowws)
		// {
		// 	print_r($rowws['A']);

		// }exit();
		for ($i = 2; $i <= $arrayCount;$i++) 
		{	
		
			//$merchant_order_id = trim($allDataInSheet[$i]['B']); 
		//we need that as order_id
		$amazon_order_id = trim($allDataInSheet[$i]['A']);
		$order_number=trim($allDataInSheet[$i]['A']);
		$shop_name_prim=trim($allDataInSheet[$i]['G']);
		if($shop_name_prim=='Amazon.ae' ||$shop_name_prim=='Amazon.sa')
           {
			$shop_name='Amazon';
           }
		$shop_website=trim($allDataInSheet[$i]['G']);
		$inv_sts='1';
		$order_date=date("Y-m-d", strtotime(trim($allDataInSheet[$i]['D'])));
		$Item_statu=trim($allDataInSheet[$i]['N']);
        $company_name='Amazon Customer';
		$customer_name='Amazon Customer';
		$due_amount=doubleval(trim($allDataInSheet[$i]['Q']))+doubleval(trim($allDataInSheet[$i]['S']));
		$Total_amount=doubleval(trim($allDataInSheet[$i]['Q']))+doubleval(trim($allDataInSheet[$i]['S']));
		$sub_total=doubleval(trim($allDataInSheet[$i]['Q']))-doubleval(trim($allDataInSheet[$i]['R']));
		$total_tax=doubleval(trim($allDataInSheet[$i]['R']));
        $shipping_charge=doubleval(trim($allDataInSheet[$i]['S']));
         $Delivery_status=trim($allDataInSheet[$i]['E']);
		 if($Item_statu=='Shipped')
		 {
            $payment_status='paid';
		 }
		 else{
			$payment_status='unpaid';
		 }
          $currency_type=trim($allDataInSheet[$i]['P']);
		  $payment_type=trim($allDataInSheet[$i]['F']);
		  $country=trim($allDataInSheet[$i]['AB']);
		  $product_sku=trim($allDataInSheet[$i]['L']);
		  $phone='';
		  $address1=trim($allDataInSheet[$i]['Y']);
		 $Product_name_arr=trim($allDataInSheet[$i]['K']);
		  $Product_quantity_arr=trim($allDataInSheet[$i]['O']);
		  $Product_price_arr=$sub_total/ doubleval(trim($allDataInSheet[$i]['O']));
		 
		  if (isset($grouped_data[$amazon_order_id])) {
			// If the ID already exists in the array, add the quantity, price, and SKU to the existing values
			$grouped_data[$amazon_order_id]['Product_quantity_arr'].= '|#|' .$Product_quantity_arr;
			$grouped_data[$amazon_order_id]['Product_price_arr'].= '|#|' .$Product_price_arr;
			$grouped_data[$amazon_order_id]['product_sku'] .= '|#|' .$product_sku;
			$grouped_data[$amazon_order_id]['order_number'] =$order_number;
			$grouped_data[$amazon_order_id]['shop_name']=$shop_name;
			$grouped_data[$amazon_order_id]['shop_website']=$shop_website;
			$grouped_data[$amazon_order_id]['inv_sts']=$inv_sts;
			$grouped_data[$amazon_order_id]['order_date']=$order_date;
			$grouped_data[$amazon_order_id]['Item_statu']=$Item_statu;
			$grouped_data[$amazon_order_id]['company_name']=$company_name;
			$grouped_data[$amazon_order_id]['customer_name']=$customer_name;
			$grouped_data[$amazon_order_id]['due_amount']+=$due_amount;
			$grouped_data[$amazon_order_id]['Total_amount']+=$Total_amount;
			$grouped_data[$amazon_order_id]['sub_total']+=$sub_total;
			$grouped_data[$amazon_order_id]['total_tax']+=$total_tax;
			$grouped_data[$amazon_order_id]['shipping_charge']+=$shipping_charge;
			$grouped_data[$amazon_order_id]['Delivery_status']=$Delivery_status;
			$grouped_data[$amazon_order_id]['payment_status']=$payment_status;
			$grouped_data[$amazon_order_id]['currency_type']=$currency_type;
			$grouped_data[$amazon_order_id]['payment_type']=$payment_type;
			$grouped_data[$amazon_order_id]['country']=$country;
			$grouped_data[$amazon_order_id]['phone']=$phone;
			$grouped_data[$amazon_order_id]['address1']=$address1;
			$grouped_data[$amazon_order_id]['Product_name_arr'].= '|#|' .$Product_name_arr;

		} else {
			// If the ID doesn't exist in the array, create a new array element with the ID, quantity, price, and SKU
			$grouped_data[$amazon_order_id] = array(
				'id' => $amazon_order_id,
				'Product_quantity_arr' => $Product_quantity_arr,
				'Product_price_arr' => $Product_price_arr,
				'product_sku' => $product_sku,
				'order_number'=>$order_number,
				'shop_name'=>$shop_name,
				'shop_website'=>$shop_website,
				'inv_sts'=>$inv_sts,
			    'order_date'=>$order_date,
			    'Item_statu'=>$Item_statu,
				'company_name'=>$company_name,
			    'customer_name'=>$customer_name,
				'due_amount'=>$due_amount,
				'Total_amount'=>$Total_amount,
				'sub_total'=>$sub_total,
				'total_tax'=>$total_tax,
				'shipping_charge'=>$shipping_charge,
				'Delivery_status'=>$Delivery_status,
				'payment_status'=>$payment_status,
				'currency_type'=>$currency_type,
				'payment_type'=>$payment_type,
				'country'=>$country,
				'phone'=>$phone,
				'address1'=>$address1,
				'Product_name_arr'=>$Product_name_arr,

			);
		}

			if(!empty($amazon_order_id))
			{
			$data_voc_number=$this->Admin_model->record_count2('incoming_invoice_online',array('order_id'=>$amazon_order_id,'order_date'=>$order_date));

				if(!empty($data_voc_number) || $data_voc_number!=0)
				{
			$flag=1;
			$error_string.="This Order number already exist in table in this year mentioned in vochure.You have an error in Row $i of Cell B.Please remove those details and try again.<br/>";
				}
			}
		}


		if($flag==1)
		{
		
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/excel/amazon_orders/".$import_xls_file);
			redirect('list-incoming-invoice-online/amazon','refresh');
		}
		else
		{
			$dwnload_title=$this->input->post('dwnload_title');
			$data23=array(
			'excl_title'=>$dwnload_title,
			'excl_file'=>$inputFileName,
			'excl_status'=>"1",
			'excl_type' =>'result');

				foreach ($grouped_data as $row) {
				           // print_r($row['id']);
							$datainsert['order_id']=$row['id'];
							$datainsert['order_number']=$row['order_number'];
							$datainsert['shop_name']=$row['shop_name'];
							$datainsert['shop_website']=$row['shop_name'];
							$datainsert['inv_sts']='1';
							$datainsert['order_date']=$row['order_date'];
							$datainsert['company_name']=$row['company_name'];
							$datainsert['customer_name']=$row['customer_name'];
							$datainsert['due_amount']=$row['due_amount'];
							$datainsert['Total_amount']=$row['Total_amount'];
							$datainsert['sub_total']=$row['sub_total'];
							$datainsert['total_tax']=$row['total_tax'];
							$datainsert['shipping_charge']=$row['shipping_charge'];
							$datainsert['Delivery_status']=$row['Delivery_status'];
							$datainsert['payment_status']=$row['payment_status'];
							$datainsert['currency_type']=$row['currency_type'];
							$datainsert['payment_type']=$row['payment_type'];
							$datainsert['country']=$row['country'];
							$datainsert['product_sku']=$row['product_sku'];
							$datainsert['phone']=$row['phone'];
							$datainsert['address1']=$row['address1'];
							$datainsert['Product_name_arr']=$row['Product_name_arr'];
							$datainsert['Product_price_arr']=$row['Product_price_arr'];
							$datainsert['Product_quantity_arr']=$row['Product_quantity_arr'];

							$insert_id_vochr=$this->Admin_model->insert_data('incoming_invoice_online',$datainsert);

		             }
					 if(!($insert_id_vochr))
					 $status = false;
					 else
						 $status = true;
						 if ($status==true)
						 $this ->session-> set_flashdata('success', 'Imported Successfully');
					 else
						 $this ->session-> set_flashdata('errors', 'Error found. Try again!');
			 ////when amazon order list be ready we must make redirect to the list instead of this route
				
					  redirect("list-incoming-invoice-online/amazonuae", "refresh");
		}
}









function submit_amazon_payment_excel()
{
	$flag = 0;$voc_number='';
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/excel/amazon_orders/';
		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this->upload->do_upload('userfile')) 
		{
			$error = array('error' => $this->upload-> display_errors());
			$this->session ->set_flashdata('errors', $error['error']);
			redirect("update_amazon_payment", "refresh");
		} 
		else 
		{
		$data = array('userfile' => $this->upload->data());
		}
	
		if (!empty($data['userfile']['file_name'])) 
		{
		$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path.$import_xls_file;
		try 
		{
		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
		die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME).'": '.$e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		$grouped_data = array();
        // foreach($allDataInSheet as $rowws)
		// {
		// 	print_r($rowws['A']);

		// }exit();
		for ($i = 2; $i <= $arrayCount;$i++) 
		{	
		
			//$merchant_order_id = trim($allDataInSheet[$i]['B']); 
	    	//we need that as order_id
		  $amazon_order_id = trim($allDataInSheet[$i]['C']);

          $total_promotional= trim($allDataInSheet[$i]['F']);
          $amzon_fee= trim($allDataInSheet[$i]['G']);
          $other= trim($allDataInSheet[$i]['H']);
          $total_to_account= trim($allDataInSheet[$i]['I']);
           


          	$dataupdate['total_promotional']=$total_promotional;
							$datainsert['amzon_fee']=$amzon_fee;
							$datainsert['other']=$other;
							$datainsert['total_to_account']=$total_to_account;

                        $this->Admin_model->update_data('incoming_invoice_online',array('total_promotional'=>$total_promotional,'amzon_fee'=>$amzon_fee,'other'=>$other,'total_to_account'=>$total_to_account),array('order_id'=>$amazon_order_id));    
     
           	  
					
		}
        	 $this ->session-> set_flashdata('success', 'Imported Successfully');
        redirect("update_amazon_payment", "refresh");
}















// function submit_amazon_order_uae_excel()
// {
// 	$flag = 0;$voc_number='';
// 		$error_string=""; 
		
// 		$this ->load -> library('excel');
// 		$this ->load -> library('image_lib');
// 		$path = 'uploads/excel/amazon_orders/';
// 		$config['upload_path'] = './' . $path;
// 		$config['allowed_types'] = 'xlsx|xls';
// 		$config['remove_spaces'] = TRUE;
// 		$config['overwrite'] = TRUE;
// 		$this ->load-> library('upload', $config);
// 		$this ->upload-> initialize($config);

// 		if (!$this->upload->do_upload('userfile')) 
// 		{
// 			$error = array('error' => $this->upload-> display_errors());
// 			$this->session ->set_flashdata('errors', $error['error']);
// 			redirect("list-amazon-upload", "refresh");
// 		} 
// 		else 
// 		{
// 		$data = array('userfile' => $this->upload->data());
// 		}
	
// 		if (!empty($data['userfile']['file_name'])) 
// 		{
// 		$import_xls_file = $data['userfile']['file_name'];
// 		} 
// 		else 
// 		{
// 			$import_xls_file = 0;
// 		}
// 		$inputFileName = $path.$import_xls_file;
// 		try 
// 		{
// 		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
// 		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
// 		$objPHPExcel = $objReader -> load($inputFileName);
// 		} 
// 		catch (Exception $e) 
// 		{
// 		die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME).'": '.$e -> getMessage());
// 		}
// 		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
// 		$arrayCount = count($allDataInSheet);
// 		$grouped_data = array();
//         // foreach($allDataInSheet as $rowws)
// 		// {
// 		// 	print_r($rowws['A']);

// 		// }exit();
// 		for ($i = 2; $i <= $arrayCount;$i++) 
// 		{	
		
// 			//$merchant_order_id = trim($allDataInSheet[$i]['B']); 
// 		//we need that as order_id
// 		$amazon_order_id = trim($allDataInSheet[$i]['A']);
// 		$order_number=trim($allDataInSheet[$i]['A']);
// 		$shop_name_prim='Amazon';
		
// 			$shop_name='Amazon';
           
// 		$shop_website='Amazon';
// 		$inv_sts='1';
// 		$order_date=date("Y-m-d", strtotime(trim($allDataInSheet[$i]['C'])));
// 		$Item_statu=trim($allDataInSheet[$i]['AM']);
//         $company_name='Amazon Customer';
// 		$customer_name=trim($allDataInSheet[$i]['F']);
// 		$due_amount=doubleval(trim($allDataInSheet[$i]['L']))+doubleval(trim($allDataInSheet[$i]['N']));
// 		$Total_amount=doubleval(trim($allDataInSheet[$i]['L']))+doubleval(trim($allDataInSheet[$i]['N']));
// 		$sub_total=doubleval(trim($allDataInSheet[$i]['L']))-doubleval(trim($allDataInSheet[$i]['M']));
// 		$total_tax=doubleval(trim($allDataInSheet[$i]['M']));
//         $shipping_charge=doubleval(trim($allDataInSheet[$i]['N']));
//          $Delivery_status=trim($allDataInSheet[$i]['AM']);
// 		 if($Item_statu=='Delivered to Buyer')
// 		 {
//             $payment_status='paid';
// 		 }
// 		 elseif($Item_statu=='Returned to Seller')
// 		 {
//             $payment_status='returned';
// 		 }
		 
// 		 else{
// 			$payment_status='unpaid';
// 		 }
//           $currency_type=trim($allDataInSheet[$i]['K']);
// 		  $payment_type=trim($allDataInSheet[$i]['AE']);
// 		  $country=trim($allDataInSheet[$i]['Y']);
// 		  $product_sku=trim($allDataInSheet[$i]['H']);
// 		  $phone='';
// 		  $address1=trim($allDataInSheet[$i]['R']);
// 		 $Product_name_arr=trim($allDataInSheet[$i]['I']);
// 		  $Product_quantity_arr=trim($allDataInSheet[$i]['J']);
// 		  $Product_price_arr=$sub_total/ doubleval(trim($allDataInSheet[$i]['J']));
		 
// 		  if (isset($grouped_data[$amazon_order_id])) {
// 			// If the ID already exists in the array, add the quantity, price, and SKU to the existing values
// 			$grouped_data[$amazon_order_id]['Product_quantity_arr'].= '|#|' .$Product_quantity_arr;
// 			$grouped_data[$amazon_order_id]['Product_price_arr'].= '|#|' .$Product_price_arr;
// 			$grouped_data[$amazon_order_id]['product_sku'] .= '|#|' .$product_sku;
// 			$grouped_data[$amazon_order_id]['order_number'] =$order_number;
// 			$grouped_data[$amazon_order_id]['shop_name']=$shop_name;
// 			$grouped_data[$amazon_order_id]['shop_website']=$shop_website;
// 			$grouped_data[$amazon_order_id]['inv_sts']=$inv_sts;
// 			$grouped_data[$amazon_order_id]['order_date']=$order_date;
// 			$grouped_data[$amazon_order_id]['Item_statu']=$Item_statu;
// 			$grouped_data[$amazon_order_id]['company_name']=$company_name;
// 			$grouped_data[$amazon_order_id]['customer_name']=$customer_name;
// 			$grouped_data[$amazon_order_id]['due_amount']+=$due_amount;
// 			$grouped_data[$amazon_order_id]['Total_amount']+=$Total_amount;
// 			$grouped_data[$amazon_order_id]['sub_total']+=$sub_total;
// 			$grouped_data[$amazon_order_id]['total_tax']+=$total_tax;
// 			$grouped_data[$amazon_order_id]['shipping_charge']+=$shipping_charge;
// 			$grouped_data[$amazon_order_id]['Delivery_status']=$Delivery_status;
// 			$grouped_data[$amazon_order_id]['payment_status']=$payment_status;
// 			$grouped_data[$amazon_order_id]['currency_type']=$currency_type;
// 			$grouped_data[$amazon_order_id]['payment_type']=$payment_type;
// 			$grouped_data[$amazon_order_id]['country']=$country;
// 			$grouped_data[$amazon_order_id]['phone']=$phone;
// 			$grouped_data[$amazon_order_id]['address1']=$address1;
// 			$grouped_data[$amazon_order_id]['Product_name_arr'].= '|#|' .$Product_name_arr;

// 		} else {
// 			// If the ID doesn't exist in the array, create a new array element with the ID, quantity, price, and SKU
// 			$grouped_data[$amazon_order_id] = array(
// 				'id' => $amazon_order_id,
// 				'Product_quantity_arr' => $Product_quantity_arr,
// 				'Product_price_arr' => $Product_price_arr,
// 				'product_sku' => $product_sku,
// 				'order_number'=>$order_number,
// 				'shop_name'=>$shop_name,
// 				'shop_website'=>$shop_website,
// 				'inv_sts'=>$inv_sts,
// 			    'order_date'=>$order_date,
// 			    'Item_statu'=>$Item_statu,
// 				'company_name'=>$company_name,
// 			    'customer_name'=>$customer_name,
// 				'due_amount'=>$due_amount,
// 				'Total_amount'=>$Total_amount,
// 				'sub_total'=>$sub_total,
// 				'total_tax'=>$total_tax,
// 				'shipping_charge'=>$shipping_charge,
// 				'Delivery_status'=>$Delivery_status,
// 				'payment_status'=>$payment_status,
// 				'currency_type'=>$currency_type,
// 				'payment_type'=>$payment_type,
// 				'country'=>$country,
// 				'phone'=>$phone,
// 				'address1'=>$address1,
// 				'Product_name_arr'=>$Product_name_arr,

// 			);
// 		}

// 			if(!empty($amazon_order_id))
// 			{
// 			$data_voc_number=$this->Admin_model->record_count2('incoming_invoice_online',array('order_id'=>$amazon_order_id,'order_date'=>$order_date));

// 				if(!empty($data_voc_number) || $data_voc_number!=0)
// 				{
// 			$flag=1;
// 			$error_string.="This Order number already exist in table in this year mentioned in vochure.You have an error in Row $i of Cell B.Please remove those details and try again.<br/>";
// 				}
// 			}
// 		}





// 		/////end if uk  

// 		//if uae and ksa /////////




// 		if($flag==1)
// 		{
		
// 			$this->session->set_flashdata('errors',$error_string);	
// 			unlink("uploads/excel/amazon_orders/".$import_xls_file);
// 			redirect('list-incoming-invoice-online/amazon','refresh');
// 		}
// 		else
// 		{
// 			$dwnload_title=$this->input->post('dwnload_title');
// 			$data23=array(
// 			'excl_title'=>$dwnload_title,
// 			'excl_file'=>$inputFileName,
// 			'excl_status'=>"1",
// 			'excl_type' =>'result');

// 				foreach ($grouped_data as $row) {
// 				           // print_r($row['id']);
// 							$datainsert['order_id']=$row['id'];
// 							$datainsert['order_number']=$row['order_number'];
// 							$datainsert['shop_name']=$row['shop_name'];
// 							$datainsert['shop_website']=$row['shop_name'];
// 							$datainsert['inv_sts']='1';
// 							$datainsert['order_date']=$row['order_date'];
// 							$datainsert['company_name']=$row['company_name'];
// 							$datainsert['customer_name']=$row['customer_name'];
// 							$datainsert['due_amount']=$row['due_amount'];
// 							$datainsert['Total_amount']=$row['Total_amount'];
// 							$datainsert['sub_total']=$row['sub_total'];
// 							$datainsert['total_tax']=$row['total_tax'];
// 							$datainsert['shipping_charge']=$row['shipping_charge'];
// 							$datainsert['Delivery_status']=$row['Delivery_status'];
// 							$datainsert['payment_status']=$row['payment_status'];
// 							$datainsert['currency_type']=$row['currency_type'];
// 							$datainsert['payment_type']=$row['payment_type'];
// 							$datainsert['country']=$row['country'];
// 							$datainsert['product_sku']=$row['product_sku'];
// 							$datainsert['phone']=$row['phone'];
// 							$datainsert['address1']=$row['address1'];
// 							$datainsert['Product_name_arr']=$row['Product_name_arr'];
// 							$datainsert['Product_price_arr']=$row['Product_price_arr'];
// 							$datainsert['Product_quantity_arr']=$row['Product_quantity_arr'];

// 							$insert_id_vochr=$this->Admin_model->insert_data('incoming_invoice_online',$datainsert);

// 		             }
// 					 if(!($insert_id_vochr))
// 					 $status = false;
// 					 else
// 						 $status = true;
// 						 if ($status==true)
// 						 $this ->session-> set_flashdata('success', 'Imported Successfully');
// 					 else
// 						 $this ->session-> set_flashdata('errors', 'Error found. Try again!');
// 			 ////when amazon order list be ready we must make redirect to the list instead of this route
// 					 redirect("list-incoming-invoice-online/amazonuae", "refresh");
// 		}
// }




















function list_sales_invoice_online($page_name=null)
{
	if(logged_in())
	{

  /////////////////////shopify invoices////////////////////////////////////////////////////////////////////////////////////

        if($page_name=="uae")
		{
		$shopify_orders = json_decode(file_get_contents('https://25f726c982e1d77aca5861cf7e0482b7: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@biri-group.myshopify.com/admin/api/2023-10/orders.json?status=any&fulfillment_status=any'));
				//$cbr_id='36911196045632';

				 //$shopify_orders = json_decode( file_get_contents('https://25f726c982e1d77aca5861cf7e0482b7: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@biri-group.myshopify.com/admin/api/2022-10/orders/'.$cbr_id.'.json'));
				
				$shop_name='dubai-store';
				$shop_website='birigroup.ae';
				$currency_type='AED';
				$incoming_invoice_online=$this->Admin_model->get_data('incoming_invoice_online',array('shop_name'=>'dubai-store'));
				
				
		}
		else{ 
			
		}

		
foreach($incoming_invoice_online as $keyincom =>$incoming_invoice_onlinea)
                    {
                        $incoming_invoice_online_db[] = $incoming_invoice_online[$keyincom]->order_id;
					}

					foreach($shopify_orders->orders as $key1 => $shopify_order1)
					{
						$shopify_orders_id[] = $shopify_order1->id;

					}
              

					$NewShopifyArray = array_diff($shopify_orders_id, $incoming_invoice_online_db);
					
					
				//	print_r($NewShopifyArray);
					//print_r($shopify_orders->orders);exit();
                 
        foreach ($NewShopifyArray as $value) {
			   foreach($shopify_orders->orders as $key2 => $shopify_order)
				  {
                        
					if($value==$shopify_order->id)
					{
						print_r('must to add our new record');

                     	foreach($shopify_order->line_items as $key_psku => $skuprod)
								{
									$product_sku_name[$key_psku]= $skuprod->name;
									$product_sku_price[$key_psku]= $skuprod->price;
									$product_sku_quantity[$key_psku]= $skuprod->quantity;
									$product_sku_sku[$key_psku]= $skuprod->sku;
									
							
								}
 
	                            $Product_sku_array=implode('|#|',$product_sku_sku);
							  $Product_price_array=implode('|#|',$product_sku_price);
                               $Product_name_array=implode('|#|',$product_sku_name);
								$Product_quantity_array=implode('|#|',$product_sku_quantity);

									 $datainsert['order_id']=$shopify_order->id;
									  $datainsert['order_number']=$shopify_order->name;
									  $datainsert['shop_name']=$shop_name;
									  $datainsert['shop_website']=$shop_website;
									  $datainsert['inv_sts']='1';
									  $datainsert['order_date']=$shopify_order->created_at;
									  $datainsert['company_name']=$shopify_order->billing_address->company;
									  $datainsert['customer_name']=$shopify_order->billing_address->name;
									  $datainsert['due_amount']=$shopify_order->current_total_price;
									  $datainsert['Total_amount']=$shopify_order->current_total_price;
									  $datainsert['sub_total']=$shopify_order->current_subtotal_price;
									  $datainsert['total_tax']=$shopify_order->current_total_tax;
									  $datainsert['shipping_charge']=$shopify_order->total_shipping_price_set->shop_money->amount;
									  $datainsert['Delivery_status']=$shopify_order->fulfillment_status;
									  $datainsert['payment_status']=$shopify_order->financial_status;
									  $datainsert['currency_type']=$shopify_order->currency;
									  $datainsert['payment_type']=$shopify_order->gateway;
									  $datainsert['country']=$shopify_order->billing_address->country_code;
									  $datainsert['product_sku']=$Product_sku_array;
									  $datainsert['phone']=$shopify_order->phone;
									  $datainsert['address1']=$shopify_order->billing_address->address1;
									  $datainsert['Product_name_arr']=$Product_name_array;
									  $datainsert['Product_price_arr']=$Product_price_array;
									  $datainsert['Product_quantity_arr']=$Product_quantity_array;
                                      //print_r($datainsert);exit();
									 $this->Admin_model->insert_data('incoming_invoice_online',$datainsert);
                             

					}
					else{
						print_r('no need to do any thing');
					}
									
	                                  //print_r('////');  print_r($product_sku_test);  
				  }
				}
         if($page_name=="uae"){
				 $incoming_invoice_online1=$this->Admin_model->get_data('incoming_invoice_online',array('inv_sts'=>'1','shop_name'=>'dubai-store'));
				 }else if($page_name=="amazonuk")
				 {
					  $incoming_invoice_online1=$this->Admin_model->get_data('incoming_invoice_online',array('inv_sts'=>'1','shop_name'=>'Amazon.uk'));
				 }

         else if($page_name=="amazonuae")
				 {
					  $incoming_invoice_online1=$this->Admin_model->get_data('incoming_invoice_online',array('inv_sts'=>'1','shop_name'=>'Amazon'));
				 }
				foreach($incoming_invoice_online1 as $keyincom1 =>$incoming_invoice_onlinea)
				  {
					    $data['id'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->id;
				     	$data['order_id'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->order_id;
						$data['doc_number'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->order_number;
						$data['order_date'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->order_date;
						$data['company_name'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->company_name;
						$data['customer_name'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->customer_name;
						$data['due_amount'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->due_amount;
						$data['Total_amount'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->Total_amount;
						$data['sub_total'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->sub_total;
						$data['total_tax'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->total_tax;
						$data['shipping_charge'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->shipping_charge;
						$data['Delivery_status'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->Delivery_status;
						$data['payment_status'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->payment_status;
						$data['payment_type'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->payment_type;
						$data['country'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->country;
						$data['Product_name_arr'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->Product_name_arr;
						$data['Product_price_arr'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->Product_price_arr;
						$data['Product_quantity_arr'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->Product_quantity_arr;
						$data['Product_sku_arr'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->product_sku;
						$data['shop_name'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->shop_name;
						$data['shop_website'][$keyincom1]=$incoming_invoice_online1[$keyincom1]->shop_website;
					//	print_r($data['order_id'][$keyincom1]);exit();
				 }


				 $data['sort_by']="";
				 $data['page_type']=$page_name;
				 $data['shop_website_main']=$shop_website;

		$this->load->view('admin/transactions/list_sales_invoice_online',$data);
		}
	}











function delete_invoice($page_name,$siv)
{
	if(logged_in())
	{
		if($page_name=="uae")
		$sales_inv_details=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$siv));
	elseif($page_name=="ksa")
		$sales_inv_details=$this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$siv));
		elseif($page_name=="dragon")
			$sales_inv_details=$this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$siv));
			elseif($page_name=="export")
				$sales_inv_details=$this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$siv));
						elseif($page_name=="UK")
				$sales_inv_details=$this->Admin_model->get_data('sales_invoice_uk',array('si_id'=>$siv));
					elseif($page_name=="UAEAmazon")
				$sales_inv_details=$this->Admin_model->get_data('sales_invoice_uae_amazon',array('si_id'=>$siv));
					elseif($page_name=="KSAamazon")
				$sales_inv_details=$this->Admin_model->get_data('sales_invoice_ksa_amazon',array('si_id'=>$siv));
				else{}

            foreach ($sales_inv_details as $key ) {

   	 $act_doc_num=$key->si_doc_no;
   	// code...
   }

     
		$acc_tx_details=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$siv,'atx_doc_no'=>$act_doc_num,'atx_sts'=>'1'));
		if(!empty($acc_tx_details))
		{
			foreach($acc_tx_details as $actx)
			{
				$acc_bal_tx1[]=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$actx->atx_id,'actd_sts'=>'1'));
			}
	
			if(!empty($acc_bal_tx1))
			{
				foreach($acc_bal_tx1 as $index=>$acb)
				{
					if(!empty($acb))
					{
					$acc_tx_details_2=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$acb->actb_to_id));
					$current_paid_amount=$acc_tx_details_2[0]->atx_paid_amount;
					$current_bal_amount=$acc_tx_details_2[0]->atx_bal_amount;
					$new_paid_amount=$current_paid_amount-$acb->actb_paid_amount;
					$new_bal_amount=$current_bal_amount+$acb->actb_paid_amount;
					$array_new_data=array(
						'atx_paid_amount'=>$new_paid_amount,
						'atx_bal_amount'=>$new_bal_amount,
					);
					$this->Admin_model->update_data('account_all_tx',$array_new_data,array('atx_id'=>$acb->actb_to_id));
					$this->Admin_model->update_data('account_tx_bal_data',array('actd_sts'=>'0'),array('actb_to_id'=>$acb->actb_to_id));
					$this->Admin_model->update_data('account_tx_bal_data',array('actd_sts'=>'0'),array('actb_tx_id'=>$acb->actb_tx_id));
					}
				}
			}
		}
	 $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_main_id'=>$siv,'atx_doc_no'=>$act_doc_num));
	 	if($page_name=="uae")
		$this->Admin_model->update_data('sales_invoice',array('si_sts'=>'0'),array('si_id'=>$siv));
	elseif($page_name=="ksa")
		$this->Admin_model->update_data('sales_invoice_ksa',array('si_sts'=>'0'),array('si_id'=>$siv));
		elseif($page_name=="dragon")
			$this->Admin_model->update_data('sales_invoice_dragon',array('si_sts'=>'0'),array('si_id'=>$siv));
			elseif($page_name=="export")
			$this->Admin_model->update_data('sales_invoice_export',array('si_sts'=>'0'),array('si_id'=>$siv));
				elseif($page_name=="UK")
			$this->Admin_model->update_data('sales_invoice_uk',array('si_sts'=>'0'),array('si_id'=>$siv));
			elseif($page_name=="UAEAmazon")
			$this->Admin_model->update_data('sales_invoice_uae_amazon',array('si_sts'=>'0'),array('si_id'=>$siv));
				elseif($page_name=="KSAamazon")
			$this->Admin_model->update_data('sales_invoice_ksa_amazon',array('si_sts'=>'0'),array('si_id'=>$siv));
				else{}

	// 	$this->Admin_model->update_data('sales_invoice_payments',array('sip_sts'=>'0'),array('sip_inv_id'=>$siv));
	// 	$this->Admin_model->update_data('master_acc_transfers',array('mact_sts'=>'0'),array('mact_sales_inv_id'=>$siv));

		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'sales invoice deleted',
			'act_status'=>'sales invoice id '.$siv.' deleted',
			'act_receipt_id'=>$siv,
			  'act_doc_num'=>$act_doc_num,
				'act_type'=>'Sales Invoice'. $page_type.' ',
				'act_type_id'=>$siv,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()

		);
		  $this->Admin_model->insert_data('activities',$activity_data);

		  $this->session->set_flashdata('success', 'Data Successfully deleted');
	redirect('list-sales-invoice/'.$page_name);
	}
}


function get_cust_sales_inv()
{
	$cust_id=$this->input->post('cust_id');
	$cust_paid_amount=$this->input->post('cust_amount_paid');
	$account_id=$this->input->post('ac_tx_id');/////////used or will get at the time of edit function///////////// 
	//pre_list($account_id);
	if(!empty($account_id))
	{	
	$account_tx_details=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$account_id,'atx_sts'=>'1'));
	$acc_tx_bal_data=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_details[0]->atx_id,'actd_sts'=>'1'));
//pre_list($acc_tx_bal_data);
		foreach($acc_tx_bal_data as $to_id)
		{
			$to_id_details[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$to_id->actb_to_id,'atx_sts'=>'1'));
		}
	$cust_id=$account_tx_details[0]->atx_cust_id;
	}
	$sql2=$this->db->query("SELECT * FROM account_all_tx where atx_cust_id=".$cust_id." and atx_type_tx IN ('Receipt','PDR','JRN_Credit','Sales_Return','Purchase') and atx_bal_amount!='0' and atx_sts='1' ");
		$cust_sales=$sql2->result_array();

		$ij=1;$kl=551;
		$html="
		<div class='row'>
		<div class='col-md-12'>
		<div class='col-md-10'>
		<span class='pull-left'>";
		if(!empty($account_id))
		{	
		if(empty($acc_tx_bal_data))
			{
				$tot_amount_ref=$account_tx_details[0]->atx_tot_amount;
			}
			else
			{
				$tot_amount_ref='0';
			}
		}
		else
		{
			$tot_amount_ref='0';
		}
$html.="<input type='text'  class='refrence_amount' value='".$tot_amount_ref."' name='refrence'><br/><p>".$this->lang->line('Add as new reference')."  </p></span><br/>
		
		<table class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
			$html.="<thead>";
			$html.="<th></th>";
			$html.="<th>".$this->lang->line('Reference')."</th>";
			$html.="<th>".$this->lang->line('Bill Amount')."</th>";
			$html.="<th>".$this->lang->line('Amount Adjusted')."</th>";
			// $html.="<th>Balance Amount</th>";
			$html.="</thead>";
			$html.="<tbody>";
	if(!empty($to_id_details))
	{
		foreach($to_id_details as $tid)
		{
			//pre_list($tid);
			$array_atx_id[]=$tid[0]->atx_id;
		$html.="<tr>";
		$html.="<td><input name='cust_id_modal' type='hidden' value='".$tid[0]->atx_cust_id."'>
		<input type='checkbox' class='class_checkbox inv_selected_".$kl."' onclick='pass_param();' value='".$kl."' name='inv_selected[]'>
		</td>";
			$html.="<td><input name='inv_id_modal[]' type='hidden' value='".$tid[0]->atx_id."'><input name='inv_doc_numbers_modal[]' class='ref_doc_numbers_".$kl."' type='hidden' value='".$tid[0]->atx_doc_no."'>".$tid[0]->atx_doc_no."</td>";

			if(empty($account_id))
			{
				if(empty($tid[0]->atx_paid_amount))
				{
					if($tid[0]->atx_type_tx=="JRN_Credit" )
					{
						if(!empty($tid[0]->atx_vat_amount))
						$tot_amount_to_show=$tid[0]->atx_tot_amount+$tid[0]->atx_vat_amount;
						else
							$tot_amount_to_show=$tid[0]->atx_tot_amount+0;
					}
					elseif($tid[0]->atx_type_tx=="Purchase" )
					{
						if(!empty($tid[0]->atx_vat_amount))
						$tot_amount_to_show=$tid[0]->atx_tot_amount+$tid[0]->atx_vat_amount;
						else
							$tot_amount_to_show=$tid[0]->atx_tot_amount+0;
					}
					else
					{
					$tot_amount_to_show=$tid[0]->atx_tot_amount;
					}
				}
				else
				{
					$tot_amount_to_show=$tid[0]->atx_bal_amount;
				}
			}
			else
			{
				if(empty($acc_tx_bal_data[0]->atx_bal_amount))
				{
					if($account_tx_details[0]->atx_type_tx=="JRN_Credit" )
					{
						if(!empty($account_tx_details[0]->atx_vat_amount))
						$tot_amount_to_show=$account_tx_details[0]->atx_tot_amount+$account_tx_details[0]->atx_vat_amount;
						else
							$tot_amount_to_show=$account_tx_details[0]->atx_tot_amount+0;
					}
					elseif($account_tx_details[0]->atx_type_tx=="Purchase" )
					{
						if(!empty($account_tx_details[0]->atx_vat_amount))
						$tot_amount_to_show=$account_tx_details[0]->atx_tot_amount+$account_tx_details[0]->atx_vat_amount;
						else
							$tot_amount_to_show=$account_tx_details[0]->atx_tot_amount+0;
					}
					else
					{
					$tot_amount_to_show=$account_tx_details[0]->atx_tot_amount;
					}
				}
				else
				{
					$tot_amount_to_show=$acc_tx_bal_data[0]->atx_bal_amount;
				}
			}

			$html.="<td><input name='sales_inv_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_amount_".$kl." org_amounts'><br/>
			<p> ".$this->lang->line('Total_Amount')." :".$tid[0]->atx_tot_amount."</p>
			</td>";
			if(empty($account_id))
			{
			$html.="<td><input name='paid_amount_modal[]' type='number' step='any' value='0' min='0' max='".$tot_amount_to_show."' onchange='check_val_less_than_amount(".$kl.");' class='tot_sales_amount_paid_".$kl."'><br/>";
			}
			else
			{
			$html.="<td><input name='paid_amount_modal[]' type='number' step='any' value='".$account_tx_details[0]->atx_paid_amount."' min='0' max='".$account_tx_details[0]->atx_paid_amount."' onchange='check_val_less_than_amount(".$kl.");' class='tot_sales_amount_paid_".$kl."'><br/>";	
			}
		
			$html.="<br/><small class='amount_overdue_".$kl." text_data_issue' style='color:red;'></small>
			</td>";
			// $html.="<td>
			// <input name='sales_inv_bal_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_bal_amount_".$ij."'>
			// </td>";
			$html.="</tr>"; 
			$kl++;
		}
		}	
	if(!empty($cust_sales))
	{
		foreach($cust_sales as $civ)
		{
			$html.="<tr>";
		$html.="<td><input name='cust_id_modal' type='hidden' value='".$cust_id."'>
		<input type='checkbox' class='class_checkbox inv_selected_".$ij."' onclick='pass_param();' value='".$ij."' name='inv_selected[]'>
		</td>";
			$html.="<td><input name='inv_id_modal[]' type='hidden' value='".$civ['atx_id']."'><input name='inv_doc_numbers_modal[]' class='ref_doc_numbers_".$ij."' type='hidden' value='".$civ['atx_doc_no']."'>".$civ['atx_doc_no']."</td>";

			if(empty($civ['atx_paid_amount']))
			{
				if($civ['atx_type_tx']=="JRN_Credit" )
					{
						if(!empty($civ['atx_vat_amount']))
						$tot_amount_to_show=$civ['atx_tot_amount']+$civ['atx_vat_amount'];
						else
							$tot_amount_to_show=$civ['atx_tot_amount']+0;
					}
					elseif($civ['atx_type_tx']=="Purchase" )
					{
						if(!empty($civ['atx_vat_amount']))
						$tot_amount_to_show=$civ['atx_tot_amount']+$civ['atx_vat_amount'];
						else
							$tot_amount_to_show=$civ['atx_tot_amount']+0;
					}
					else
					{
					$tot_amount_to_show=$civ['atx_tot_amount'];
					}
			}
			else
			{
				$tot_amount_to_show=$civ['atx_bal_amount'];
			}

			$html.="<td><input name='sales_inv_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_amount_".$ij." org_amounts'><br/>
			<p>".$this->lang->line('Total_Amount').":".$civ['atx_tot_amount']."</p>
			</td>";
			
			$html.="<td><input name='paid_amount_modal[]' type='number' step='any' value='0' min='0' max='".$tot_amount_to_show."' onchange='check_val_less_than_amount(".$ij.");' class='tot_sales_amount_paid_".$ij."'><br/>
		
			<br/><small class='amount_overdue_".$ij." text_data_issue' style='color:red;'></small>
			</td>";
			// $html.="<td>
			// <input name='sales_inv_bal_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_bal_amount_".$ij."'>
			// </td>";
			$html.="</tr>"; 
			$ij++;
		}
		}	
		$html.="</tbody>";
			$html.="</table>";
			$html.="</div>		
<div class='col-md-2'>
<button class='btn btn-primary pull-right get_pick_amount' onclick='get_pick_amount();'>".$this->lang->line('Pick Amount')."</button>
</div>
</div>
<div class='col-md-12'>
	<div class='col-md-4'>";
	if(!empty($cust_paid_amount))
	$html.="<p>".$this->lang->line('Amount to adjust')." :<span class='amount_to_adj'>".$cust_paid_amount."</span></p>";
	else
	$html.="<p>".$this->lang->line('Amount to adjust')." :<span class='amount_to_adj'>0</span></p>";
	$html.="</div>
	<div class='col-md-4'>
	<p>".$this->lang->line('Amount adjusted')." :<span class='amount_adjusted'>0</span></p>
	</div>
	<div class='col-md-4'>
	<p> ".$this->lang->line('To be adjusted').":<span class='to_be_adjust'>0</span></p>
	</div>";

	$html.="<div class='col-md-12'>
	<p><button class='btn btn-danger' type='button' onclick='reset_fields()'>".$this->lang->line('Reset Fields')."</button></p>
	</div>";

$html.="</div>
		</div>	";

			echo $html;	
}
function generate_invoice_pdf($page_type)
{ 
	if(logged_in())
	{
		$sale_id=$this->input->post('sales_inv_id');

		$invoice_pdf_type=$this->input->post('pdf-print-option');

		///for english - arabic number in words//////
 		$Arabic = new \ArPHP\I18N\Arabic();
 		 $Arabic->setNumberFeminine(1);
    	$Arabic->setNumberFormat(1);
    	///////end en-ar words/////////
 



// $ksaamazonen='0';
// if($invoice_pdf_type='3')
// {
// $ksaamazonen='1';
// }

		if(!empty($sale_id))
		{
if($page_type=="uae")
 $siv_data= $this->Admin_model->get_data('sales_invoice',array('si_id'=>$sale_id));  
elseif($page_type=="ksa")
 $siv_data= $this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$sale_id));  
	elseif($page_type=="dragon")
 $siv_data= $this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$sale_id));  
		elseif($page_type=="export")
          $siv_data= $this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$sale_id));  
		  	elseif($page_type=="UK")
			  {   
				   $siv_data= $this->Admin_model->get_data('sales_invoice_uk',array('si_id'=>$sale_id));

			  }
         
 
		    	elseif($page_type=="UAEAmazon")
          $siv_data= $this->Admin_model->get_data('sales_invoice_uae_amazon',array('si_id'=>$sale_id));
		  elseif($page_type=="KSAamazon")
          $siv_data= $this->Admin_model->get_data('sales_invoice_ksa_amazon',array('si_id'=>$sale_id)); 
		    elseif($page_type=="ukamazon")
          $siv_data= $this->Admin_model->get_data('sales_invoice_uk_amazon',array('si_id'=>$sale_id)); 
		      elseif($page_type=="uae-online")
          $siv_data= $this->Admin_model->get_data('sales_invoice_online_uae',array('si_id'=>$sale_id)); 
      else{}

$prd_details=explode('|#|',$siv_data[0]->si_product);
$qty_details=explode('|#|',$siv_data[0]->si_qnty);
$unt_price_details=explode('|#|',$siv_data[0]->si_rate);
$gross_details=explode('|#|',$siv_data[0]->si_gross);
$discount_per_details=explode('|#|',$siv_data[0]->si_dis_per);
$disc_amount_details=explode('|#|',$siv_data[0]->si_dis_amount);
$add_charge_details=explode('|#|',$siv_data[0]->si_add_charges);
$fnet_details=explode('|#|',$siv_data[0]->si_fnet);
$vat_pre_details=explode('|#|',$siv_data[0]->si_vat);
$delivery_date_details=explode('|#|',$siv_data[0]->si_delivery_date);
$remark_details=explode('|#|',$siv_data[0]->si_remrk);
$tax_code_details=explode('|#|',$siv_data[0]->si_tax_code);



foreach($prd_details as $index=>$pd)
{
	$prd_table_data[]=$this->tm->get_data('products',array('pid'=>$pd));

	
}

$salesman=$this->Admin_model->get_data('employee_details',array('ed_id'=>$siv_data[0]->si_salesman));

$customer_extra_data=$this->Admin_model->get_data('master_accounts_tree_file_data',array('accounts_tree_id'=>$siv_data[0]->si_customer_acc_id));

 $acc_customer_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$siv_data[0]->si_customer_acc_id));	
	
$currency=$this->Admin_model->get_data('master_currency_conv',array('currency_name'=>$siv_data[0]->si_currency));

$stylesheet = file_get_contents('style_mpdf.css');
////////////////for qr code////////////////////////////
$this->load->library('ciqrcode');
//header("Content-Type: image/png");
$params['data'] = base_url('load_invoice_data/'.$siv_data[0]->si_doc_no);
$params['level'] = 'H';
$params['size'] = 10;
$params['savename'] = './uploads/qr_code/'.$siv_data[0]->si_doc_no.'.png';
 $this->ciqrcode->generate($params);
//echo '<img src="'.base_url().'/uploads/inv_pdf/tes.png" />';
///////////qr code ends//////////////////////////////////////////

$html='<!doctype html>';
if($invoice_pdf_type!='1'||$invoice_pdf_type!='3')
{
$html.='<br/><br/><br/><br/>';
}

$html.='<head></head><body>';
if ($invoice_pdf_type == '1'||$invoice_pdf_type=='3') {
					$html .= '<div style="position: absolute; visibility: visible; left: 680; top: 120px; z-index: 200;"><img align="bottom"  src="' . base_url() . '/uploads/qr_code/' . $siv_data[0]->si_doc_no . '.png" width="70" height="70"/></div>';
				}
				else{
					$html .= '<div style="position: absolute; visibility: visible; left: 680; top: 230px; z-index: 200;"><img align="bottom"  src="' . base_url() . '/uploads/qr_code/' . $siv_data[0]->si_doc_no . '.png" width="70" height="70"/></div>';

				}
$html.='<div class="content" ><br/>';
	$head_all = '';
				$head_all.= '<table border="0" width="100%">';
		
				$head_all.= '<tr><td style="text-align:left;">';
				$head_all.= '<table border="0" width="100%" >';
				$head_all.= '<tbody>';

				if ($page_type == "ksa"||$page_type == "KSAamazon") {
						
					$head_all.= '<tr> <td>  </td></tr>';
				$head_all.= '<tr> <td>  </td></tr>';
			$head_all.= '<tr> <td> <br> </td></tr>';
				
					$head_all.= '<tr>';
					$head_all.= '<td >' . $siv_data[0]->si_narration . '</td>';
					$head_all.= '</tr><br/>';
				} else if($page_type=="uae"){
					$head_all.= '<tr>';
					$head_all.= '<td >TRN#100567461700003</td>';
					$head_all.= '</tr><br/>';
				}
				else{
					$head_all.= '<tr>';
					//$head_all.= '<td >TRN#100567461700003</td>';
					$head_all.= '</tr><br/>';
				}
				$head_all.= '<tr>';
				$head_all.= '<td ><b>' . $acc_customer_details[0]->label . '</b></td>';
				$head_all.= '</tr>';
				if ($page_type == "ksa"||$page_type == "KSAamazon") {
					
                    if($invoice_pdf_type=='3')
					  {
						 $head_all.= '<tr>';
					      $head_all.= '<td> TRN : </td><td>' . $siv_data[0]->si_cust_vat_number . '</td>';
					      $head_all.= '</tr>';
				    	}
						  
						
                       else { 
						     $head_all.= '<tr>';
				     	$head_all.= '<td> الرقم الضريبي </td><td>' . $siv_data[0]->si_cust_vat_number . '</td>';
					    $head_all.= '</tr>';
						 
	                 	
			             	}




					  }
					 
				
					
			
				
				
				
				
				 else if ($page_type == "uae"||$page_type == "uae-online"||$page_type == "UAEAmazon") {
					$head_all.= '<tr>';
					 $head_all.= '<td> TRN : </td><td>' . $siv_data[0]->si_cust_vat_number . '</td>';
					$head_all.= '</tr>';
				}
				else{
                         $head_all.= '<tr>';	$head_all.= '</tr>';
				}
				$head_all.= '<tr>';

				if ($page_type == "ksa"||$page_type == "KSAamazon") {

                        if($invoice_pdf_type=='3')
					  {
                        $head_all.= '<td>Tel No.:' . $customer_extra_data[0]->phone . '</td>';
				    	$head_all.= '<td>Fax No :' . $customer_extra_data[0]->fax . '</td>';
					  }
					  else {

                             	$head_all.= '<td>رقم الهاتف   :' . $customer_extra_data[0]->phone . '</td>';
					             $head_all.= '<td>فاكس رقم  :' . $customer_extra_data[0]->fax . '</td>';

					  }

				
				}
				
				 else if($page_type=="uae"){
					$head_all.= '<td>Tel No.:' . $customer_extra_data[0]->phone . '</td>';
					$head_all.= '<td>Fax No :' . $customer_extra_data[0]->fax . '</td>';
				}
					 else {
					$head_all.= '<td>Tel No.:' . $customer_extra_data[0]->phone . '</td>';
					$head_all.= '<td>Fax No :' . $customer_extra_data[0]->fax . '</td>';
				}


				$head_all.= '</tr><br/><br/>';
				if ($page_type == "ksa"||$page_type == "KSAamazon") {
                 if($invoice_pdf_type=='3')
					  {
							$head_all.= '<tr>';
							$head_all.= '<td>Shipping Address : </td><td> ' . character_limiter($siv_data[0]->si_delivery_address, 30) . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td>Shipping Contact : </td><td>' . $siv_data[0]->si_shipping_contact . '</td>';
							$head_all.= '</tr>';
					  }
					  else{

							$head_all.= '<tr>';
							$head_all.= '<td> عنوان الشحن   </td><td> ' . character_limiter($siv_data[0]->si_delivery_address, 16) . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td> جهة اتصال الشحن   </td><td>' . $siv_data[0]->si_shipping_contact . '</td>';
							$head_all.= '</tr>';
					  }

				


				}
				
				 else if($page_type=="uae") {
					$head_all.= '<tr>';
					$head_all.= '<td>Shipping Address : </td><td> ' . character_limiter($siv_data[0]->si_delivery_address, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Shipping Contact : </td><td>' . $siv_data[0]->si_shipping_contact . '</td>';
					$head_all.= '</tr>';
				}
				else {
                     	$head_all.= '<tr>';
					$head_all.= '<td>Shipping Address : </td><td> ' . character_limiter($siv_data[0]->si_delivery_address, 200) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Shipping Contact : </td><td>' . $siv_data[0]->si_shipping_contact . '</td>';
				$head_all.= '</tr>';

				}
				$head_all.= '</tbody>';
				$head_all.= '</table>';
				$head_all.= '</td>';

				$head_all.= '<td style="text-align:right;">';
				$head_all.= '<table border="0" width="100%" >';
				$head_all.= '<tbody>';
				$head_all.= '<tr>';
				if ($page_type == "ksa"||$page_type == "KSAamazon") {
                  if($invoice_pdf_type=='3')
					  {
						  if ($siv_data[0]->si_vat_type == '1') {
						$subject_name = 'Taxable Invoice';
					} else {
						$subject_name = 'Non-Taxable Invoice';
					}
					  }


					  else{
                     	if ($siv_data[0]->si_vat_type == '1') {
						$subject_name = 'الفاتورة الخاضعة للضريبة  ';
						} else {
						$subject_name = 'فاتورة غير خاضعة للضريبة ';
						}


					  }

				



				}
				 else {
					if ($siv_data[0]->si_vat_type == '1') {
						$subject_name = 'Taxable Invoice';
					} else {
						$subject_name = 'Non-Taxable Invoice';
					}
				}
				if ($page_type == "UK")
				{

					  if ($siv_data[0]->si_vat_type == '1') {
						$subject_name = 'Taxable Invoice';
					} else {
						$subject_name = 'Non-Taxable Invoice';
					}
				
					//$head_all.= '<td align="right"><b align="right"> Commerical invoice </b></td>';
			
				}
				else{$head_all.= '<td align="right"><b align="right">' . $subject_name . '</b></td>';}
				
				$head_all.= '</tr>';
				if ($page_type == "ksa"||$page_type =="KSAamazon") {
                     if($invoice_pdf_type=='3')
					  {

						$head_all.= '<tr>';
						$head_all.= '<td align="right"><b align="right">Our TRN:100301351100003</b></td>';
						$head_all.= '</tr><br/><br/>';         

					  }

					  else{

							$head_all.= '<tr>';
							$head_all.= '<td align="right"><b align="right">الرقم الضريبي  :310159338600003</b></td>';
							$head_all.= '</tr><br/><br/>';
                      }


				} else if ($page_type == "uae"||$page_type =="UAEAmazon"||$page_type == "uae-online") {
					$head_all.= '<tr>';
					$head_all.= '<td align="right"><b align="right">Our TRN:100301351100003</b></td>';
					$head_all.= '</tr><br/><br/>';
				}

				else if ($page_type == "UK"||$page_type == "ukamazon") {
					$head_all.= '<tr>';
					$head_all.= '<td align="right"><b align="right">Our VRN:422394704</b></td>';
					$head_all.= '</tr><br/><br/>';
				}
				else{
					$head_all.= '<tr>';
					$head_all.= '<td align="right"><b align="right"></b></td>';
					$head_all.= '</tr><br/><br/>';
				}
				if ($page_type == "ksa"||$page_type == "KSAamazon") {
                   if($invoice_pdf_type=='3')
					  {

						    $head_all.= '<tr>';
							$head_all.= '<td>Sales Person :</td><td> ' . character_limiter($salesman[0]->ed_name, 16) . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td>Invoice No. :</td><td> ' . $siv_data[0]->si_doc_no . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td>Date  : </td><td>' . $siv_data[0]->si_date . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td>Mark :</td><td> ' . character_limiter($siv_data[0]->si_mark, 16) . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td>Customer Contact :</td><td> ' . $siv_data[0]->si_contact . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td>L.P.O No :</td><td> ' . $siv_data[0]->si_lpo_no . '</td>';
							$head_all.= '</tr>';




					  }
					  else{

							$head_all.= '<tr>';
							$head_all.= '<td>مندوب مبيعات   :</td><td> ' . character_limiter($salesman[0]->ed_name, 16) . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td> رقم الفاتورة. :</td><td> ' . $siv_data[0]->si_doc_no . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td> تاريخ  : </td><td>' . $siv_data[0]->si_date . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td> علامة الشحن  :</td><td> ' . character_limiter($siv_data[0]->si_mark, 16) . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td> جهة اتصال العميل  :</td><td> ' . $siv_data[0]->si_contact . '</td>';
							$head_all.= '</tr>';
							$head_all.= '<tr>';
							$head_all.= '<td>رقم طلب الشراء :</td><td> ' . $siv_data[0]->si_lpo_no . '</td>';
							$head_all.= '</tr>';
					  }

		




				}
				
				 else if($page_type == "uae"){
					$head_all.= '<tr>';
					$head_all.= '<td>Sales Person :</td><td> ' . character_limiter($salesman[0]->ed_name, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Invoice No. :</td><td> ' . $siv_data[0]->si_doc_no . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Date  : </td><td>' . $siv_data[0]->si_date . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Mark :</td><td> ' . character_limiter($siv_data[0]->si_mark, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Customer Contact :</td><td> ' . $siv_data[0]->si_contact . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>L.P.O No :</td><td> ' . $siv_data[0]->si_lpo_no . '</td>';
					$head_all.= '</tr>';
				}
				
				else{
					$head_all.= '<tr>';
					//$head_all.= '<td>  </td><td> Baian Biri</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Invoice No. :</td><td> ' . $siv_data[0]->si_doc_no . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Date  : </td><td>' . $siv_data[0]->si_date . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Mark :</td><td> ' . character_limiter($siv_data[0]->si_mark, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Customer Contact :</td><td> ' . $siv_data[0]->si_contact . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
				//	$head_all.= '<td>L.P.O No :</td><td> ' . $siv_data[0]->si_lpo_no . '</td>';
					$head_all.= '</tr>';
				}


				$head_all.= '</tbody>';
				$head_all.= '</table>';
				$head_all.= '</td>';
				$head_all.= '</tr>';

				$head_all.= '</table>';
				$head_all.= '</div>';
$html.='</div>';

$html.='<div class="content">
<table  align="center"  width="100%">';
$html.='<tbody>';
if($page_type=="ksa"||$page_type=="KSAamazon")
{
if($invoice_pdf_type=='3')
  {
	$html.='<tr >';
$html.='<td align="center" class="prd_info_2">Item Code</td>';
$html.='<td align="center" class="prd_info_2">Class </td>';
$html.='<td align="center" class="prd_info_2">Description</td>';
$html.='<td align="center" class="prd_info_2">Qty  </td>';
$html.='<td align="center" class="prd_info_2">Rate</td>';
$html.='<td align="center" class="prd_info_2">Amount</td>';

	  }
else{
$html.='<tr >';
$html.='<td align="center" class="prd_info_2">رمز الصنف  </td>';
$html.='<td align="center" class="prd_info_2">الصنف   </td>';
$html.='<td align="center" class="prd_info_2">وصف  </td>';
$html.='<td align="center" class="prd_info_2">الكمية  </td>';
$html.='<td align="center" class="prd_info_2">السعر  </td>';
$html.='<td align="center" class="prd_info_2">الاجمالي  </td>';
	  }


}
else
{
	$html.='<tr >';
$html.='<td align="center" class="prd_info_2">Item Code</td>';
$html.='<td align="center" class="prd_info_2">Class </td>';
$html.='<td align="center" class="prd_info_2">Description</td>';
$html.='<td align="center" class="prd_info_2">Qty  </td>';
$html.='<td align="center" class="prd_info_2">Rate</td>';
$html.='<td align="center" class="prd_info_2">Amount</td>';
}
	if($page_type=="uae"||$page_type=="UAEAmazon"||$page_type == "uae-online")
	$html.='<td align="center" class="prd_info_2">VAT @5%</td>';
	elseif($page_type=="ksa"||$page_type=="KSAamazon")
		{
			
			if($invoice_pdf_type=='3')
  {    $html.='<td align="center" class="prd_info_2"> VAT  </td>';    }
  else {
			$html.='<td align="center" class="prd_info_2"> الضريبة  </td>';
        }

			
			
		}



	elseif($page_type=="dragon")
	$html.='<td align="center" class="prd_info_2">VAT @5%</td>';
	elseif($page_type=="export")
	$html.='';
	elseif($page_type=="UK"||$page_type=="ukamazon")
	$html.='<td align="center" class="prd_info_2">VAT @20% </td>';
    			
$html.='</tr>';

$i=1;
$total_sum_prd='';
$total_vat_sum_prd='';
$total_discount_sum_prd='';
					foreach($prd_table_data as $index=>$pd3)
					{		

					       

						if($index % 10 == 0 && $index != 0){
						
						$html .= '<table align="center"  width="100%">';
						$html .= '<tbody>';
						if ($invoice_pdf_type == '1'||$invoice_pdf_type == '3') {
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
						}
						else{
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
						}
						
						
						if ($page_type == "ksa"||$page_type == "KSAamazon") {
                            	if($invoice_pdf_type=='3'){

                                         	$html .= '<tr >';
							$html .= '<td align="center" class="prd_info_2">Item Code</td>';
							$html .= '<td align="center" class="prd_info_2">Class </td>';
							$html .= '<td align="center" class="prd_info_2">Description</td>';
							$html .= '<td align="center" class="prd_info_2">Qty  </td>';
							$html .= '<td align="center" class="prd_info_2">Rate</td>';
							$html .= '<td align="center" class="prd_info_2">Amount</td>';


								}else{
                                     	$html .= '<tr >';
							$html .= '<td align="center" class="prd_info_2">رمز الصنف  </td>';
							$html .= '<td align="center" class="prd_info_2">الصنف   </td>';
							$html .= '<td align="center" class="prd_info_2">وصف  </td>';
							$html .= '<td align="center" class="prd_info_2">الكمية  </td>';
							$html .= '<td align="center" class="prd_info_2">السعر  </td>';
							$html .= '<td align="center" class="prd_info_2">الاجمالي  </td>';


								}
						



						} else {
							$html .= '<tr >';
							$html .= '<td align="center" class="prd_info_2">Item Code</td>';
							$html .= '<td align="center" class="prd_info_2">Class </td>';
							$html .= '<td align="center" class="prd_info_2">Description</td>';
							$html .= '<td align="center" class="prd_info_2">Qty  </td>';
							$html .= '<td align="center" class="prd_info_2">Rate</td>';
							$html .= '<td align="center" class="prd_info_2">Amount</td>';
						}
						if ($page_type == "uae"||$page_type == "UAEAmazon"||$page_type == "uae-online")
							$html .= '<td align="center" class="prd_info_2">VAT @5%</td>';
						elseif ($page_type == "ksa"||$page_type == "KSAamazon"){
                              if($invoice_pdf_type=='3'){

								   $html .= '<td align="center" class="prd_info_2"> VAT  </td>';
							  }
							  else{

								   $html .= '<td align="center" class="prd_info_2"> الضريبة  </td>';
							  }

                            


						}
							
						elseif ($page_type == "dragon")
							$html .= '<td align="center" class="prd_info_2">VAT @5%</td>';
						elseif ($page_type == "export"||$page_type=="UK")
							$html.='<td align="center" class="prd_info_2">VAT @20% </td>';
					  
			$html.='</tr>';
			
					}
				
$html.='<tr>';

$html.='<td align="center" width="15%">'.$pd3[0]->pcode.'</td>';
$html .= '<td align="center" width="15%"><p style="font-size:12px;">' . $pd3[0]->pcat . '</p></td>';

if($page_type!="ksa")
$html.='<td align="center" width="29%">'.$pd3[0]->pname;
else
{
	if(!empty($pd3[0]->pname_ar))
	{
		$html .= '<td align="center" style="height:20px !important;overflow: hidden !important;" width="29%"><p style="font-size:11px;">' . $pd3[0]->pname_ar .'<br>'.$pd3[0]->pname .'</p>';
	
	}
	else
	{
		$html.='<td align="center" width="29%">'.$pd3[0]->pname;

	}
}
$html.='</td>';
$html.='<td align="center" width="7%">'.$qty_details[$index].'</td>';
$html.='<td align="center" width="11%">'.number_format((float)$unt_price_details[$index], 2, '.', '').'</td>';
$html.='<td align="center" width="11%">'.number_format((float)$gross_details[$index], 2, '.', '').'</td>';
$vat_perce=$fnet_details[$index]*($vat_pre_details[$index]/100);

$vat_amount_tot[]=$fnet_details[$index]*($vat_pre_details[$index]/100);

$dis_per_tot[]=$gross_details[$index]*($discount_per_details[$index]/100);

if($page_type!="export")
{
$html.='<td align="center" width="11%">'.number_format((float)$vat_perce, 2, '.', '').'</td>';
}
$html.='</tr>';

					if($index % 9 == 0 && $index != 0)
					{
						$html.='</tr>';
						$html .= '</tbody>';
						$html .= '</table>';
						$html .= "<pagebreak />";
						
					}
			
					}
$html.='</tbody>';
$html.='</table>';
$html.='</div>';












$html.='<div class="content_2">';
//$html.='<img align="bottom"  src="'.base_url().'/uploads/qr_code/'.$siv_data[0]->si_doc_no.'.png" width="100" height="100"/>';

$html.='<table class="prd_info_2" align="right" width="100%">';
$html.='<tr>';
 if($page_type=="ksa")
    { $html.='<td align="right" text-align="right">	.يقبل الاسترجاع خلال 24 ساعة فقط من تاريخ الفاتورة ويجب ان يكون المنتج بحالته الأصلية عند الشراء مع وجود الفاتورة الأصل  •</td>';
      $html.='</tr>';
      $html.='<tr>';
      $html.='<td align="right" text-align="right">.يقبل الاستبدال خلال 3 أيام فقط من تاريخ الفاتورة ويجب أن يكون المنتج بحالته الاصلية عند الشراء مع وجود الفاتورة الأصل  •</td>';
     }
	 else if($page_type=="KSAamazon") {
    if($invoice_pdf_type=='3'){
         $html.='<td align="left" text-align="left">We are very confident with our product quality and durability. If you’re not satisfied with our product you can return the product with free of cost(return during 15 day).</td>';
         $html.='</tr>';
	}
	else {

		 $html.='<td align="right" text-align="right">	(الارجاع خلال 15 يوما من تاريخ الفاتورة)نحن واثقون جدًا من جودة منتجاتنا ومتانتها. إذا لم تكن راضيًا عن منتجنا ، يمكنك إرجاع المنتج مجانًا.•</td>';
         $html.='</tr>';
	}
    

	 }
     else
$html.='</tr>';

$html.='</table>';


$html.='<table width="100%">';
$html.='<tr>';

$html.='<td>';
$html.='<table width="70%">';
$html.='<tbody>';
$html.='<tr>';
if($page_type=="ksa"||$page_type=="KSAamazon")
{ if($invoice_pdf_type=='3')
{

$html.='<td><u class="underline_space"> Amount in words : </u></td>';


}else {

$html.='<td><u class="underline_space">  المبلغ بالكلمات   : </u></td>';
}



}

else
$html.='<td><u class="underline_space"> Amount in words : </u></td>';
$html.='</tr>';
$html.='<tr>';
//$html.='<td>'.$currency[0]->currency_name.'</td>';
if($page_type=="UK")
{ 
//    print_r($this->numbertowordconvertsconver->convert_number($siv_data[0]->si_tot_amount));
// exit(0);
$html.='<td colspan="2">'  .$this->numbertoworduk->convert_number($siv_data[0]->si_tot_amount).'</td>';
  
 }
 elseif($page_type=="uae"||$page_type=="dargon"||$page_type=="export"||$page_type=="UAEAmazon"||$page_type == "uae-online")
         {
	$html.='<td colspan="2">'  .$this->numbertowordconvertsconver->convert_number($siv_data[0]->si_tot_amount).'</td>';
	
 }
elseif($page_type=="ksa"||$page_type=="KSAamazon")
{
  if($invoice_pdf_type=='3')
{

	$html.='<td colspan="2">'  .$this->numbertowordconvertsconverksa->convert_number($siv_data[0]->si_tot_amount).'</td>';

}

else{
    $ar_number_word = number_format((float)$siv_data[0]->si_tot_amount, 2, '.', '');
    $text   = $Arabic->money2str($ar_number_word, 'SAR', 'ar');
    
    // echo "<p align=center>$number<br />$text</p>";////not to use////
$html.='<td colspan="2">'.$text.'</td>';

}




}
else
$html.='<td colspan="2">'.$currency[0]->currency_name.'</td>';

$html.='</tr>';

if($page_type=="ksa"||$page_type=="KSAamazon")
{
 if($invoice_pdf_type=='3')
{
$html.='<tr>';
$html.='<td>Receiver`s Signature:</td>';
$html.='<td></td>';
$html.='<td>Authorised</td>';

$html.='</tr>';


}else
{
$html.='<tr>';
$html.='<td> توقيع المستلم   :</td>';
$html.='<td></td>';
$html.='<td>  توقيع البائع   </td>';
$html.='</tr>';


}

}
else
{
	if($page_type=="UK"||$page_type=="ukamazon")
	{	
	$html.='<tr>';
$html.='<td>Receiver`s Signature:</td>';
$html.='<td></td>';
$html.='<td>Authorised</td>';

$html.='</tr>';
	$html.='<tr>';
$html.='<td></td>';
$html.='<td></td>';
$html.='<td style="margin-bottom:100px;">Bayan Biri</td>';

$html.='</tr>';

}

else {

	$html.='<tr>';
$html.='<td>Receiver`s Signature:</td>';
$html.='<td></td>';
$html.='<td>Authorised</td>';


}
}

$html.='</tbody>';
$html.='</table>';
$html.='</td>';

$html.='<td>';
$html.='<table width="80%">';
$html.='<tbody>';
if($page_type=="ksa"||$page_type=="KSAamazon")
{


	if($invoice_pdf_type=='3')
{


$html.='<tr>';
$html.='<td>Add Others  </td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td><b>Discount </b></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td>Discount%</td>';
$html.='<td>'.array_sum($dis_per_tot).'</td>';
$html.='</tr>';


$html.='<tr>';
$html.='<td>Final Vat  </td>';

$html.='<td>'.number_format((float)$siv_data[0]->si_tot_vat_amount, 2, '.', '').'  '.$currency[0]->currency_name.'</td>';
$html.='</tr>';


$html.='<tr>';
$html.='<td>Final Net  </td>';
$html.='<td>'.array_sum($fnet_details).'   '. $currency[0]->currency_name.'</td>';
$html.='</tr>';
$html.='<tr>';


}

else {
$html.='<tr>';
$html.='<td>  إضافات </td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td><b> خصم  </b></td>';
$html.='<td>'.array_sum($disc_amount_details).'</td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td>خصم  % </td>';
$html.='<td>'.array_sum($dis_per_tot).'</td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td>  المجموع النهائي  </td>';
$html.='<td>'.array_sum($fnet_details).'</td>';
$html.='</tr>';
$html.='<tr>';

}


}
else
{
	$html.='<tr>';
$html.='<td>Add Others  </td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td><b>Discount </b></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td>Discount%</td>';
$html.='<td>'.array_sum($dis_per_tot).'</td>';
$html.='</tr>';




$html.='<tr>';
$html.='<td>Shipping Charge  </td>';
$html.='<td>'.array_sum($add_charge_details).'   '. $currency[0]->currency_name.'</td>';
$html.='</tr>';



$html.='<tr>';
$html.='<td>Net total  </td>';
$html.='<td>'.(array_sum($fnet_details)-array_sum($add_charge_details)).'   '. $currency[0]->currency_name.'</td>';
$html.='</tr>';




$html.='<tr>';
$html.='<td>total exc.vat  </td>';
$html.='<td>'.array_sum($fnet_details).'   '. $currency[0]->currency_name.'</td>';
$html.='</tr>';
$html.='<tr>';


$html.='<tr>';
$html.='<td>Total Vat  </td>';

$html.='<td>'.number_format((float)$siv_data[0]->si_tot_vat_amount, 2, '.', '').'  '.$currency[0]->currency_name.'</td>';
$html.='</tr>';
}

if($page_type=="uae"||$page_type=="UAEAmazon"||$page_type == "uae-online")
{
	$html.='<td>VAT @5%</td>';
$html.='<td>'.array_sum($vat_amount_tot).'</td>';
}
elseif($page_type=="ksa"||$page_type=="KSAamazon")
{
	if($invoice_pdf_type=='3')
{
	$html.='<td>VAT </td>';
$html.='<td>'.array_sum($vat_amount_tot).'</td>';


}else {

	$html.='<td>(15 %) مجموع الضريبة </td>';
$html.='<td>'.array_sum($vat_amount_tot).'</td>';

}

}
elseif($page_type=="dragon")
{
$html.='<td>VAT @5%</td>';
$html.='<td>'.array_sum($vat_amount_tot).'</td>';
}
elseif($page_type=="export")
$html.='';
elseif($page_type=="UK")
$html.='';





$html.='</tr>';
$html.='<tr>';
if($page_type=="ksa"||$page_type=="KSAamazon")
{
	if($invoice_pdf_type=='3')
{
  $html.='<td>Grand Total :</td>';

}


else{

$html.='<td> االاجمالي مع الضريبة :</td>';
}



}

else
$html.='<td>Grand Total :</td>';

$html.='<td>'.number_format((float)$siv_data[0]->si_tot_amount, 2, '.', '').'  '.$currency[0]->currency_name.'</td>';	
$html.='</tr>';




$html.='</tbody>';
$html.='</table>';
$html.='</td>';

$html.='</tr>';




$html.='</table ><br/><br/>';

$html.='</div>';


$html.='</body>';
$html.='</html>';

//echo $html;
$pdfFilePath = $siv_data[0]->si_doc_no.'.pdf';

	 $mpdf = new \Mpdf\Mpdf();
	 $mpdf->autoScriptToLang = true;
	$mpdf->autoLangToFont = true;
    $mpdf->autoArabic=true;
	$mpdf->defaultfooterline = 0;

 	$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$siv_data[0]->si_company));
if($invoice_pdf_type=='1'||$invoice_pdf_type=='3')
{


if($page_type=="UK"||$page_type=="ukamazon")
{
		
  $mpdf->SetHeader('<img src="'.base_url("UK Header2.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("UK footer2.png").'">');

}
elseif($page_type=="UAEAmazon")
{
    $mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');

}

elseif ( strpos($company_details[0]->mcomp_name, 'UAE ') !== false) {

 	$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');
}
elseif ( strpos($company_details[0]->mcomp_name, 'UAE') !== false) {

 	$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');
}
elseif(strpos($company_details[0]->mcomp_name, 'Dubai ') !== false)
{
 $mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');

}
elseif(strpos($company_details[0]->mcomp_name, 'FACTORY') !== false)
{
 	$mpdf->SetHeader('<img src="'.base_url("biri_industries_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("biri_industries_footer.png").'">');
}
elseif($page_type=="ksa"||$page_type=="KSAamazon")
{
 $mpdf->SetHeader('<img src="'.base_url("ksa-header-new.png").'">'.$head_all);
$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("ksa-footer-new.png").'">');

}
else
{}

}
else
{
	$mpdf->SetHeader($head_all);
	$mpdf->SetFooter('<div style="margin-bottom:100px;">Page {PAGENO} of {nb}</div>');
}
//echo $html;
//print_r($fnet_details);
		 $mpdf->WriteHTML($stylesheet,1);
		 if ($invoice_pdf_type == '1'||$invoice_pdf_type == '3') {
					$mpdf->AddPage(
						'', // L - landscape, P - portrait 
						'',
						'',
						'',
						'',
						0, // margin_left
						0, // margin right
						97, // margin top
						20, // margin bottom
						0, // margin header
						0
					); // margin footer
				}
				else{
					$mpdf->AddPage(
						'', // L - landscape, P - portrait 
						'',
						'',
						'',
						'',
						5, // margin_left
						5, // margin right
						97, // margin top
						20, // margin bottom
						60, // margin header
						30
					); // margin footer
				}
   
	     $mpdf->WriteHTML($html,2);	     
	     //save in folder

		$mpdf->Output("./uploads/inv_pdf/".$pdfFilePath, "F");
  		$mpdf->Output($pdfFilePath,'D');
				
 		}
	}
}
function load_invoice_data($doc_num=null)
{
	//echo str_replace('_', ' ', $doc_num);
	if(!empty($doc_num))
	{
		//header('Content-Type: application/pdf');
//   echo '<iframe src="'.base_url().'uploads/inv_pdf/'.str_replace('_', ' ', $doc_num).'.pdf" width="90%" height="500px">
// </iframe>';
//$filename = "".base_url()."/uploads/inv_pdf/".str_replace('_', ' ', $doc_num);
//echo "<iframe src=\"".base_url()."uploads/inv_pdf/".str_replace('_', ' ', $doc_num)."\" width=\"100%\" style=\"height:100%\"></iframe>";
		// $file = file_get_contents("".base_url()."uploads/inv_pdf/".str_replace('_', ' ', $doc_num).".pdf", true);
		// echo $file;
		// $myfile = fopen("".base_url()."uploads/inv_pdf/".str_replace('_', ' ', $doc_num).".pdf", "r") or die("Unable to open file!");
		// echo fread($myfile,filesize("".base_url('uploads/inv_pdf/')."".str_replace('_', ' ', $doc_num).".pdf"));
		// fclose($myfile);

		//echo "<a href='".base_url()."uploads/inv_pdf/".$doc_num.".pdf'>ghffffffffffffffffffffffffffff open</a>";
		//$filename= base_url("uploads/inv_pdf/").$doc_num.".pdf";
  
// // // Header content type
// header("Content-type: application/pdf");
  
// header("Content-Length: " . filesize($filename));
  
// // Send the file to the browser.
// echo $filename;
		$filePath=base_url("uploads/inv_pdf/").$doc_num.".pdf";
$filename=base_url("uploads/inv_pdf/").$doc_num.".pdf";
header('Content-type:application/pdf');
header('Content-disposition: inline; filename="'.$filename.'"');
header('content-Transfer-Encoding:binary');
header('Accept-Ranges:bytes');
@ readfile($filePath);
	}
}

function get_doc_details()
{
	$cbr_id=$this->input->post('main_id');
	$page_name=$this->input->post('page_name');
	if($page_name=="uae")
$dataa=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$cbr_id));
elseif($page_name=="ksa")
$dataa=$this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$cbr_id));
elseif($page_name=="dragon")
$dataa=$this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$cbr_id));
elseif($page_name=="export")
$dataa=$this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$cbr_id));
elseif($page_name=="UK")
$dataa=$this->Admin_model->get_data('sales_invoice_uk',array('si_id'=>$cbr_id));
elseif($page_name=="UAEAmzon")
$dataa=$this->Admin_model->get_data('sales_invoice_uae_amazon',array('si_id'=>$cbr_id));
elseif($page_name=="KSAamazon")
$dataa=$this->Admin_model->get_data('sales_invoice_ksa_amazon',array('si_id'=>$cbr_id));
else{}
	
		if($dataa)
			{
				$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->si_company));
				$sales_acc=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->si_sales_acc_id));
				$cust_acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->si_customer_acc_id));
				$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->si_currency));
				$price_level=$this->Admin_model->get_data('master_price_level',array('mpc_id'=>$dataa[0]->si_pc_level));
				$salesman=$this->Admin_model->get_data('employee_details',array('ed_id'=>$dataa[0]->si_salesman));
				$payment_type=$this->Admin_model->get_data('master_payment_method',array('mpm_id'=>$dataa[0]->si_payment_type));
				$country=$this->Admin_model->get_data('master_region',array('mr_id'=>$dataa[0]->si_country));
				$place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->si_plc_supply));
				$jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->si_jurisdiction));

				$account_tx_data=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_type_tx'=>'Sales_Invoice'));
				if(!empty($account_tx_data))
				{
					$account_bal_data_1=$this->Admin_model->get_data('account_tx_bal_data',array('actb_to_id'=>$account_tx_data[0]->atx_id));
					if(!empty($account_bal_data_1))
					{
						foreach($account_bal_data_1 as $abd)
						{
							$tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_tx_id,'atx_sts'=>'1'));
						}
					}
					else
					{
						$account_bal_data_2=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_data[0]->atx_id));
						if(!empty($account_bal_data_2))
						{
							foreach($account_bal_data_2 as $abd)
							{
								$tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_to_id));
							}	
						}
					}
				}
					
				$warehouse_list=explode('|#|',$dataa[0]->si_warehouse);
				foreach($warehouse_list as $wl)
				{
					$data_wl[]=$this->Admin_model->get_data('master_warehouse',array('mw_id'=>$wl));
				}
				
				$prd_list=explode('|#|',$dataa[0]->si_product);
				foreach($prd_list as $pl)
				{
					$data_pl[]=$this->tm->get_data('products',array('pid'=>$pl));
				}

				$qnty_list=explode('|#|',$dataa[0]->si_qnty);
				$rate_list=explode('|#|',$dataa[0]->si_rate);
				$gross_list=explode('|#|',$dataa[0]->si_gross);
				$disc_per_list=explode('|#|',$dataa[0]->si_dis_per);
				$disc_amount_list=explode('|#|',$dataa[0]->si_dis_amount);
				$add_charges_list=explode('|#|',$dataa[0]->si_add_charges);
				$fnet_list=explode('|#|',$dataa[0]->si_fnet);
				$vat_list=explode('|#|',$dataa[0]->si_vat);
					$rmk_list=explode('|#|',$dataa[0]->si_remrk);
					$tax_list=explode('|#|',$dataa[0]->si_tax_code);
					$delivery_date_list=explode('|#|',$dataa[0]->si_delivery_date);

					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>".$this->lang->line('Sales Invoice Data')."</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>  ".$this->lang->line('Doc no')." : ".$dataa[0]->si_doc_no." </p>";
					$html.="<p>  ".$this->lang->line('User Created')." :".$dataa[0]->si_user_created."  </p>";
					$html.="<p> ".$this->lang->line('Date')." : ".$dataa[0]->si_date."</p>";
					$html.="<p> ".$this->lang->line('Currency')." : ".$currency[0]->currency_name."</p>";
					$html.="<p> ".$this->lang->line('Vat Type')." : ";
					if($dataa[0]->si_vat_type=='1')
					{
						$vat_tyype=$this->lang->line('Taxable');
					}
					else
					{
						$vat_tyype=$this->lang->line('Non-Taxable');
					}
					$html.=$vat_tyype;
					$html.="</p>";

					$html.="<p style='color:blue'><b>".$this->lang->line('Linked to')." :</b></p>";
					if(!empty($tx_data_related))
					{
						foreach($tx_data_related as $tx)
						{
							$html.="<p style='color:blue'>".$tx[0]->atx_doc_no."</p>";
						}
					}	
					$html.="</div>";

					$html.="<div class='col-md-4'>";
				
					$html.="<p> ".$this->lang->line('Sales Account')." : ".$sales_acc[0]->label."</p>";
					$html.="<p> ".$this->lang->line('LPO No').". : ".$dataa[0]->si_lpo_no."</p>";
					$html.="<p> ".$this->lang->line('Company')." : ".$company_details[0]->mcomp_name."</p>";
					$html.="<p> ".$this->lang->line('Price Level')." : ";
					if(!empty($price_level[0]->mpc_name))
						$html.=$price_level[0]->mpc_name;
					$html.="</p>";
					$html.="<p> ".$this->lang->line('Salesman').": ".$salesman[0]->ed_name."</p>";
				$html.="<p> ".$this->lang->line('Payment Type')." : ".$payment_type[0]->mpm_name."</p>";
				
					$html.="<p> ".$this->lang->line('Place of Supply')." : ".$place_supply[0]->mps_name."</p>";
					$html.="<p> ".$this->lang->line('Jurisdiction')." : ".$jurisdaction[0]->mps_name."</p>";
					$html.="<p> ".$this->lang->line('Narration').": ".$dataa[0]->si_narration."</p>";
					
				$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>".$this->lang->line('Customer')."  : ".$cust_acc_details[0]->label."</p>";
					$html.="<p> ".$this->lang->line('Contact')." : ".$dataa[0]->si_contact."</p>";
					$html.="<p> ".$this->lang->line('Delivery Address')." : ".$dataa[0]->si_delivery_address."</p>";
					$html.="<p> ".$this->lang->line('Mark')." : ".$dataa[0]->si_mark."</p>";
				$html.="<p> ".$this->lang->line('Ship Contact')." : ".$dataa[0]->si_shipping_contact."</p>";
					$html.="<p> ".$this->lang->line('Country')."  : ".$country[0]->mr_name."</p>";
						
				$html.="<p> ".$this->lang->line('Current Status')." : ".$dataa[0]->si_current_sts."</p>";
					$html.="<p>".$this->lang->line('Attachements')." : <a href='".base_url('uploads/sales_invoice/'.$dataa[0]->si_attachments)."' target='_blank'> ".$dataa[0]->si_attachments."</a></p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

						$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th>
					<th>".$this->lang->line('Warehouse')."</th><th>".$this->lang->line('Product')."</th>
					<th> ".$this->lang->line('Quantity')."</th><th> ".$this->lang->line('Rate')."</th>
					<th>".$this->lang->line('Gross')." </th><th> ".$this->lang->line('Discount')."(%)</th>
					<th> ".$this->lang->line('Discount Amount')." </th><th> ".$this->lang->line('Add.Charges')."</th>
					<th>".$this->lang->line('Fnet')."</th><th>".$this->lang->line('Vat')."(%)</th>
					<th>".$this->lang->line('Delivery Date')."</th>
					<th>".$this->lang->line('Remark')." </th><th>".$this->lang->line('Tax Code')."</th></thead>";
					$html.="<tbody>";
					foreach($data_pl as $key=>$d)
					{
						$qnty_tot[]=$qnty_list[$key];
						$rate_tot[]=$rate_list[$key];
						$gross_tot[]=$gross_list[$key];
						
						$dis_amnt_tot[]=$disc_amount_list[$key];
						$adchrg_tot[]=$add_charges_list[$key];
						$fent_tot[]=$fnet_list[$key];
					
						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$data_wl[$key][0]->mw_name."</td>";
						$html.="<td>".$d[0]->pname."</td>";
						
						$html.="<td>".$qnty_list[$key]."</td>";
						$html.="<td>".$rate_list[$key]."</td>";
						$html.="<td>".$gross_list[$key]."</td>";

						$html.="<td>".$gross_list[$key]*($disc_per_list[$key]/100);
						$dis_per_tot[]=$gross_list[$key]*($disc_per_list[$key]/100);
						$html.="</td>";
						$disc_per_list[$key]."</td>";
						$html.="<td>".$disc_amount_list[$key]."</td>";
						$html.="<td>".$add_charges_list[$key]."</td>";

						$html.="<td>".$fnet_list[$key]."</td>";
						$html.="<td>".$fnet_list[$key]*($vat_list[$key]/100);
						$vat_amount_tot[]=$fnet_list[$key]*($vat_list[$key]/100);
						$html.="</td>";

						$html.="<td>".$delivery_date_list[$key]."</td>";
						$html.="<td>".$rmk_list[$key]."</td>";
						$html.="<td>".$tax_list[$key]."</td>";
					
						$html.="</tr>";
					}
					$html.="</tbody>";
					$html.="</table>";
						$html.="<div class='row'>";
					$html.="<div class='col-md-12'><div class='col-md-4'>";
						$html.="<p>".$this->lang->line('Total Quantity')."  : ".array_sum($qnty_tot)."</p>";
					$html.="<p> ".$this->lang->line('Total Rate')."   : ".array_sum($rate_tot)."</p>";
					$html.="<p> ".$this->lang->line('Total Gross')." : ".array_sum($gross_tot)."</p>";
					$html.="</div>";
					$html.="<div class='col-md-4'>";
					$html.="<p>".$this->lang->line('Total Discount')." (%) : ".array_sum($dis_per_tot)."</p>";
					$html.="<p>".$this->lang->line('Total Discount Amount')."  : ".array_sum($dis_amnt_tot)."</p>";
					$html.="<p>".$this->lang->line('Total Additional Charges')."  : ".array_sum($adchrg_tot)."</p>";
						$html.="</div>";
					$html.="<div class='col-md-4'>";
					$html.="<p>".$this->lang->line('Total Fnet')."  : ".array_sum($fent_tot)."</p>";
					$html.="<p>".$this->lang->line('Total VAT Amount')."  : ".array_sum($vat_amount_tot)."</p>";
					$html.="<p>".$this->lang->line('Final Amount')."  : ".$dataa[0]->si_tot_amount."</p>";
					$html.="</div>";$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/
					echo $html;
			}
}





function get_doc_online_details()
{
	$cbr_id=$this->input->post('main_id');
	$page_name=$this->input->post('page_name');

	if($page_name=="uae")
//$dataa=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$cbr_id));
{ 
	$shopify_orders = json_decode( file_get_contents('https://25f726c982e1d77aca5861cf7e0482b7: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@biri-group.myshopify.com/admin/api/2022-10/orders/'.$cbr_id.'.json'));
		//$amazon_orders_uk=json_decode( file_get_contents('https://25f726c982e1d77aca5861cf7e0482b7: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@biri-group.myshopify.com/admin/api/2022-10/orders/'.$cbr_id.'.json'));
	
	
}

else if($page_name=="amazonuk"||$page_name=="amazonuae"){
 
      $dataa=$this->Admin_model->get_data('incoming_invoice_online',array('order_id'=>$cbr_id));
       //print_r($dataa[0]);exit();

          	$Product_sku_arr=explode('|#|',$dataa[0]->product_sku);
			    
				$Product_name_arr=explode('|#|',$dataa[0]->Product_name_arr);
				$Product_price_arr=explode('|#|',$dataa[0]->Product_price_arr);
				$Product_quantity_arr=explode('|#|',$dataa[0]->Product_quantity_arr);
				$company_details=$dataa[0]->company_name;
				$shipping_charge=$dataa[0]->shipping_charge;
                 
                $total_promotional=$dataa[0]->total_promotional;
                $amzon_fee=$dataa[0]->amzon_fee;
				$other=$dataa[0]->other;
				$total_to_account=$dataa[0]->total_to_account;
				//$sales_acc=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->si_sales_acc_id));
				$Total_amount=$dataa[0]->Total_amount;
				$address1=$dataa[0]->address1;
				$currency=$dataa[0]->currency_type;

				$payment_type=$dataa[0]->payment_type;
				$country=$dataa[0]->country;
		
				$doc_number=$dataa[0]->order_number;
				$customer_name=$dataa[0]->customer_name;
				$order_date=$dataa[0]->order_date;
				$total_tax=$dataa[0]->total_tax;
				$phone=$dataa[0]->phone;
			
				if($country=="GB"){
					$warehouse_list='Amazon.uk';
					$online_Sales='Online Amazon.uk';
				}
				else if($country=="AED")

                  {
					$warehouse_list='Amazon.ae';
					$online_Sales='Online Amazon.ae';
				}
				
				elseif($country=="SAR")

                  {
					$warehouse_list='Amazon.kas';
					$online_Sales='Online Amazon.ksa';
				}




}
	

		if($shopify_orders)
			{

				foreach($shopify_orders as $key => $shopify_order)
				{
						  $order_id[$key]=$shopify_order->id;
						  $doc_number[$key]=$shopify_order->name;
						  $order_date[$key]=$shopify_order->created_at;
						  $company_name[$key]=$shopify_order->billing_address->company;
						  $customer_name[$key]=$shopify_order->billing_address->name;
						  $due_amount[$key]=$shopify_order->current_total_price;
						  $Total_amount[$key]=$shopify_order->current_total_price;
						  $sub_total[$key]=$shopify_order->current_subtotal_price;
						  $total_tax[$key]=$shopify_order->current_total_tax;
						  $shipping_charge[$key]=$shopify_order->total_shipping_price_set->shop_money->amount;
						  $Delivery_status[$key]=$shopify_order->fulfillment_status;
						  $payment_status[$key]=$shopify_order->financial_status;
						  $currency_type[$key]=$shopify_order->currency;
						  $payment_type[$key]=$shopify_order->gateway;
						  $country[$key]=$shopify_order->billing_address->country_code;
						  $product_sku[$key]=$shopify_order->line_items;
						  $phone[$key]=$shopify_order->phone;
						  $address1[$key]=$shopify_order->billing_address->address1;
						foreach($product_sku[$key] as $key_psku => $skuprod)
					   {
						  $product_sku_name[$key_psku]= $skuprod->name;
						  $product_sku_price[$key_psku]= $skuprod->price;
						  $product_sku_quantity[$key_psku]= $skuprod->quantity;
						  $product_sku_sku[$key_psku]= $skuprod->sku;
					  }
						$Product_name_arr[$key]=$product_sku_name;
						$Product_price_arr[$key]=$product_sku_price;
						$Product_quantity_arr[$key]=$product_sku_quantity;
						$Product_sku_arr[$key]=$product_sku_sku;
					  //print_r('////');  print_r($product_sku_test);  
				}

				$Product_sku_arr=$Product_sku_arr['order'];
				$Product_name_arr=$Product_name_arr['order'];
				$Product_price_arr=$Product_price_arr['order'];
				$Product_quantity_arr=$Product_quantity_arr['order'];
				$company_details=$company_name['order'];
				$shipping_charge=$shipping_charge['order'];
				  $total_promotional=0;
                $amzon_fee=0;
				$other=0;
				$total_to_account=0;
				//$sales_acc=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->si_sales_acc_id));
				$Total_amount=$Total_amount['order'];
				$address1=$address1['order'];
				$currency=$currency_type['order'];

				$payment_type=$payment_type['order'];
				$country=$country['order'];
		
				$doc_number=$doc_number['order'];
				$customer_name=$customer_name['order'];
				$order_date=$order_date['order'];
				$total_tax=$total_tax['order'];
				$phone=$phone['order'];
			
				if($country=="AE"){
					$warehouse_list='Dubai-store';
					$online_Sales='Online birigroup.ae';
				}
				
		}









					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Sales Invoice Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$doc_number."</p>";
					$html.="<p>customer Created: ".$customer_name."</p>";
					$html.="<p>Date: ".$order_date."</p>";
					$html.="<p>Currency: ".$currency."</p>";
					$html.="<p>Vat Type: ";
					if($total_tax!='0')
					{
						$vat_tyype='Taxable';
					}
					else
					{
						$vat_tyype='Non-Taxable';
					}
					$html.=$vat_tyype;
					$html.="</p>";

			
					$html.="</div>";

					$html.="<div class='col-md-4'>";
				
				
					$html.="<p>Company: ".$company_details."</p>";
				
					$html.="<p>Salesman: ".$online_Sales."</p>";
				$html.="<p>Payment Type: ".$payment_type."</p>";
				
					$html.="<p>Place of Supply: ".$warehouse_list."</p>";
					$html.="<p>Jurisdiction: ".$country."</p>";
					
					
				$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Customer : ".$customer_name."</p>";
					$html.="<p>Contact : ".$phone."</p>";
					$html.="<p>Delivery Address: ".$address1."</p>";
				
					$html.="<p>Country : ".$country."</p>";
						
				    //$html.="<p>Current Status: ".$dataa[0]->si_current_sts."</p>";
					//$html.="<p>Attachements: <a href='".base_url('uploads/sales_invoice/'.$dataa[0]->si_attachments)."' target='_blank'> ".$dataa[0]->si_attachments."</a></p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/
					$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th>
					<th>Warehouse</th><th>Product</th>
					<th>SKU</th>
					<th>Quantity</th><th>Rate</th>
					<th>Gross</th>
					</thead>";
					$html.="<tbody>";
					foreach($Product_sku_arr as $key=>$d)
					{
						
						$Gross[$key]=($Product_quantity_arr[$key]*$Product_price_arr[$key]);
						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$warehouse_list."</td>";
						$html.="<td>".$Product_name_arr[$key]."</td>";
						$html.="<td>".$Product_sku_arr[$key]."</td>";
						
						$html.="<td>".$Product_quantity_arr[$key]."</td>";
						$html.="<td>".$Product_price_arr[$key]."</td>";
						$html.="<td>".number_format((float)$Gross[$key], 2, '.', '')."</td>";
						$html.="</tr>";
					}
					$totaltax=($shipping_charge+array_sum($Gross))*0.05;
					$html.="</tbody>";
					$html.="</table>";
						$html.="<div class='row'>";
					$html.="<div class='col-md-12'><div class='col-md-4'>";
					$html.="<p>Total Quantity : ".array_sum($Product_quantity_arr)."</p>";
					$html.="<p>fnet  :".array_sum($Gross)."</p>";
					$html.="<p>shipping charge  :" .$shipping_charge."</p>";
					$html.="<p>Total Tax  :".$totaltax."</p>";
					
					$html.="<p>Total Gross : ".$Total_amount."</p>";
                     if($amzon_fee!=0||$amzon_fee!='0'||$amzon_fee!=null){
					$html.="<p>Amazon Fee : ".$amzon_fee."</p>";
					$html.="<p>seller account balance: ".$total_to_account."</p>";
					}
					$html.="</div>";
					//$html.="<div class='col-md-4'>";
					//$html.="<p>Total Discount(%) : ".array_sum($dis_per_tot)."</p>";
				//	$html.="<p>Total Discount Amount : ".array_sum($dis_amnt_tot)."</p>";
				////	$html.="<p>Total Additional Charges : ".array_sum($adchrg_tot)."</p>";
					//	$html.="</div>";
					//$html.="<div class='col-md-4'>";
					//$html.="<p>Total Fnet : ".array_sum($fent_tot)."</p>";
					//$html.="<p>Total VAT Amount : ".array_sum($vat_amount_tot)."</p>";
				//	$html.="<p>Final Amount : ".$dataa[0]->si_tot_amount."</p>";
					$html.="</div>";$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/
					echo $html;
			
}







function convert_to_sales_invoice($id)
{
	if(logged_in())
	{

		$incoming_invoice_online1=$this->Admin_model->get_data('incoming_invoice_online',array('id'=>$id));
		//print($incoming_invoice_online1[0]->shop_name);

		  $website_type=$incoming_invoice_online1[0]->shop_website;
   
	
	$customer_name=$incoming_invoice_online1[0]->customer_name;


	   if(empty($edit_inv_id))////willl insert
   {
   
	   if($website_type=="birigroup.ae")
	  


			 { $page_type='amazonuae';
			
				$doc_numberar=explode('#',$incoming_invoice_online1[0]->order_number);
				$doc_number=$doc_numberar[1];//$document_bal_number=str_replace("INV-UAE-w", "",$doc_number);
				$currency_convert=$this->Admin_model->get_data('master_currency_conv',array('currency_name'=>'AED'));

				
			   $document_bal_number="INV-UAE-W".$doc_number;

                  $atx_region='uae-online';
			
			  
			   //online 9 amazon 8 
			   $price_online='9';
			  // for online
			   $customer_acc_id='1169';
			  $sales_acc_id='1171';
			  $company_id='19';
			  //form employee_details table now will put arunima as default
			  $salesman_id='58';
			  //from payment db bank transfer for all online invoice
			  $payment_type='2';
			  //for uae 81 is the code for ksa is 82 this in sales country_table
			  $payment_country='81';
			  $currency_type='AED';
			  $conv_value=$currency_convert[0]->currency_val;
			  $conv_value_name=$currency_convert[0]->currency_name;
			  $wharehouse_id='23';
			  $vatpercentage_country='5';

			} 
	   elseif($website_type=="Amazon.uk"||$website_type=="Amazon.fr"||$website_type=="Amazon.be"||$website_type=="Amazon.de")
		  { 
			  $page_type='amazonuk';
			   $atx_region='ukamazon';
                
			$doc_number=$incoming_invoice_online1[0]->order_number;
			$currency_convert=$this->Admin_model->get_data('master_currency_conv',array('currency_name'=>'GBP'));
		   $document_bal_number="INV-Amz-UK".$doc_number;
		   //for local 
		   $customer_acc_id='1159';
		   //for local 
		   $sales_acc_id='1163';
		   $company_id='14';
		   //online 9 amazon 8 
		   $price_online='8';
		  //form employee_details table now will put arunima as default
		  $salesman_id='58';
		  //from payment db bank transfer for all online invoice
		  $payment_type='2';
		  //for uae 81 is the code for ksa is 82 this in sales country_table
		  $payment_country='83';
		  $currency_type='GBP';
		  $conv_value=$currency_convert[0]->currency_val;
		  $conv_value_name=$currency_convert[0]->currency_name;
		  $wharehouse_id='23';
		  $vatpercentage_country='20';
		  }
	   elseif($website_type=="Amazon")
		   {

			  $page_type='amazonuae';
                
			$doc_number=$incoming_invoice_online1[0]->order_number;

			$currency_type=$incoming_invoice_online1[0]->currency_type;

			if($currency_type=="AED"){
			$currency_convert=$this->Admin_model->get_data('master_currency_conv',array('currency_name'=>'AED'));
			 $document_bal_number="INV-Amz-UAE".$doc_number;

			    //for local 
		   $customer_acc_id='638';
		   //for local 
		   $sales_acc_id='616';
                $payment_country='81';
                   $currency_type='AED';
                   $atx_region='uaeamazon';
                $vatpercentage_country='5';

			}else{
				$page_type='amazonuae';
				$currency_convert=$this->Admin_model->get_data('master_currency_conv',array('currency_name'=>'SAR'));
				 $document_bal_number="INV-Amz-KSA".$doc_number;


				    //for local 
		   $customer_acc_id='490';
		   //for local 
		   $sales_acc_id='619';
		    $payment_country='82';
			 $currency_type='SAR';
			 $atx_region='ksaamazon';
			   $vatpercentage_country='15';
			}
		  
		  ///14 for amazon fba
		   $company_id='14';
		   //online 9 amazon 8 
		   $price_online='8';
		  //form employee_details table now will put arunima as default
		  $salesman_id='58';
		  //from payment db bank transfer for all online invoice
		  $payment_type='2';
		  //for uae 81 is the code for ksa is 82 this in sales country_table
		 
		 
		  $conv_value=$currency_convert[0]->currency_val;
		  $conv_value_name=$currency_convert[0]->currency_name;
		  $wharehouse_id='23';
		
			   
		   }
	   elseif($website_type=="export.ae")
		   $document_bal_number=str_replace("ESI ", "", $this->input->post('si_doc_no'));
		   elseif($website_type=="ksa.sar")
		   $document_bal_number=str_replace("ESI ", "", $this->input->post('si_doc_no'));
		   else{}  

        $new_formated_date1=$incoming_invoice_online1[0]->order_date;
		$phone_contact=$incoming_invoice_online1[0]->phone;
		$delivery_address=$incoming_invoice_online1[0]->address1;
		$delivery_statuscond=$incoming_invoice_online1[0]->Delivery_status;
		if($delivery_statuscond=="fulfilled"||$delivery_statuscond=="Shipped")
		{$delivery_status='delivered';
		}
		else {
			$delivery_status='not_delivered';
		}

		$product_sku=$incoming_invoice_online1[0]->product_sku;
		$product_qnty=$incoming_invoice_online1[0]->Product_quantity_arr;
		$product_price=$incoming_invoice_online1[0]->Product_price_arr;
		$add_shipping_charge=$incoming_invoice_online1[0]->shipping_charge;
		$total_tax=$incoming_invoice_online1[0]->total_tax;
		$total_amount=$incoming_invoice_online1[0]->Total_amount;
		//this value for transaction what we will recive after amazon fee

        $seller_account_balance=$incoming_invoice_online1[0]->total_to_account;


		$product_sku_list=explode('|#|',$product_sku);
		//print_r($product_sku_list);exit();
		$product_qnty_list=explode('|#|',$product_qnty);
		$product_price_list=explode('|#|',$product_price);
		foreach($product_sku_list as $wl=>$jj)
		{
			
			$data_sku_list[$wl]=$this->tm->get_data('products',array('pcode'=>$product_sku_list[$wl]));
             $gross_list[$wl]=$product_qnty_list[$wl]*$product_price_list[$wl];
			 $vatpercentage_list[$wl]=$vatpercentage_country;
			$order_date_list[$wl]=$new_formated_date1;
			$product_qnty_todeliver_list[$wl]='0';
		}
		
	     if(empty($data_sku_list))
		 {
			$data_prd_id[]=0;
		 }
		 else{

			foreach($data_sku_list as $key=>$d)
		           {
		 	$data_prd_id[$key]=$data_sku_list[$key][0]->pid;
	          	}

		 }
		
	
		$Product_id_array=implode('|#|',$data_prd_id);
		$gross_array=implode('|#|',$gross_list);
		$vatpercentage=implode('|#|',$vatpercentage_list);
		$delivery_date=implode('|#|',$order_date_list);
		$product_qnty_todeliver= implode('|#|',$product_qnty_todeliver_list);

	   $data['si_doc_no']=$document_bal_number;
	   $data['si_customer_acc_id']=$customer_acc_id;
	   $data['si_sales_acc_id']=$sales_acc_id;
	   $data['si_company']=$company_id;
	   //online price
	   $data['si_pc_level']=$price_online;
	   $data['si_salesman']=$salesman_id;
	   $data['si_payment_type']=$payment_type;
	   $data['si_country']=$payment_country;
   }
  


            
			if(!empty($phone_contact))
			{
				$data['si_shipping_contact']=$phone_contact;
			}
			else{
				$data['si_shipping_contact']='0';
			}
			
			//make it allow null from db 
			//$data['si_lpo_no']=$this->input->post('si_lpo_no');
			//$data['si_contact']=$this->input->post('si_contact');
			$data['si_narration']=$customer_name;
			//$data['si_mark']=$this->input->post('si_mark');

			$data['si_delivery_address']=$delivery_address;
                /// inter company 4 
			$data['si_plc_supply']='4';
           /// inter company 4 
			$data['si_jurisdiction']='4';
			$data['si_currency']=$currency_type;
			$data['si_conv_value']=$conv_value;
			//$data['si_attachments']=$data_image;
			$data['si_warehouse']=$wharehouse_id;

			$data['si_product']=$Product_id_array;
			$data['si_qnty']=$product_qnty;
			$data['si_rate']=$product_price;
			$data['si_gross']=$gross_array;
			//$data['si_dis_per']=$this->input->post('hi_dis_per');
			//$data['si_dis_amount']=$this->input->post('hi_dis_amount');
			$data['si_add_charges']=$add_shipping_charge;
			$data['si_fnet']=$gross_array;
			
			$data['si_vat']=$vatpercentage;
			$data['si_delivery_date']=$delivery_date;
			//$data['si_remrk']=$this->input->post('hi_remrk');
			//$data['si_tax_code']=$this->input->post('hi_tax_code');
			$data['si_tot_vat_amount']=$total_tax;
			$data['si_tot_amount']=$total_amount;
			$data['si_vat_type']='1';
			$data['si_sts']='1';
			$data['si_project']='1';
		//	$data['si_cust_vat_number']=$this->input->post('si_cust_vat_number');
		//$data['si_dt_updt']=get_date_time();
		$data['si_date']=get_date_time();
			
       $data['si_qnt_to_deliver']=$product_qnty_todeliver;
       $data['si_qnty_dlevered']=$product_qnty;
       $data['si_current_sts']='not-paid';
	   $data['si_delivery_sts']=$delivery_status;
	   $data['si_fullreturn_sts']='0';
	   //$data['si_fullreturn_sts']=$new_formated_date1;
	   $data['si_user_created']=$this->session->userdata['user']['username'];
	   $data['si_dt_crtd']=get_date_time();
	   
	   


     // print_r($data);exit();
	


	$qnty_details=explode('|#|',$product_qnty);
	
	if(empty($edit_inv_id))
	{
		if($website_type=="birigroup.ae")
		$insert_id=$this->Admin_model->insert_data('sales_invoice_online_uae',$data);
		elseif($website_type=="ksa")
		$insert_id=$this->Admin_model->insert_data('sales_invoice_ksa',$data);
		elseif($website_type=="dragon")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_dragon',$data);
		elseif($website_type=="export")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_export',$data);
			elseif($website_type=="UK")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_uk',$data);
				elseif($website_type=="UAEAmazon")
			$insert_id=$this->Admin_model->insert_data('sales_invoice_uae_amazon',$data);
			///this for testing but we should make sales_invoice_uk_amazon
			elseif($website_type=="Amazon.uk"||$website_type=="Amazon.fr"||$website_type=="Amazon.be"||$website_type=="Amazon.de"){
              
				
			$insert_id=$this->Admin_model->insert_data('sales_invoice_uk_amazon',$data);
			
			}

				elseif($website_type=="Amazon"){
                
				  if($atx_region=="ksaamazon") {
			$insert_id=$this->Admin_model->insert_data('sales_invoice_ksa_amazon',$data);
			} 
			else{
				$insert_id=$this->Admin_model->insert_data('sales_invoice_uae_amazon',$data);
			}
			
			}




	if($insert_id=='0')
			{
          	$this->session->set_flashdata('errors', 'There is messing value please be sure for all entry.    /    الرجاء التأكد من جميع المدخلات   ');
				
          redirect('sales-invoice/'.$page_type);
            
			}
		/////$insert_id=12;
		else if(!empty($insert_id))
		{
		
           $act_doc_num=$document_bal_number;
		$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'Online sales invoice created',
				'act_status'=>'sales invoice id '.$insert_id.' created,also added to account_master_trasaction table- inv amount - '.$total_amount.' ',
				'act_sales_inv_id'=>$insert_id,
				'act_sales_inv_page_type'=>$website_type,
			    'act_doc_num'=>$act_doc_num,
				'act_type'=>'Sales Invoice -'  .$website_type.' ',
				'act_type_id'=>$insert_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()
			);
			   $this->Admin_model->insert_data('activities',$activity_data);
			  $this->session->set_flashdata('success', 'Data Successfully inserted');
		}
	}



		if(!empty($insert_id) || !empty($edit_inv_id) )
		{
			if(!empty($insert_id))
			{
				$sales_id_inv_id=$insert_id;
			}
			elseif (!empty($edit_inv_id)) 
			{
				$sales_id_inv_id=$edit_inv_id;
			}
			else
			{
				$sales_id_inv_id='';
			}
			if(!empty($sales_id_inv_id))
			{
		/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////	
					$data_tx['atx_user_created']=$this->session->userdata['user']['username'];
					$data_tx['atx_type_tx']='Sales_Invoice';
					$data_tx['atx_date']=$new_formated_date1;
					$data_tx['atx_doc_no']=$act_doc_num;
					$data_tx['atx_main_id']=$sales_id_inv_id;
					$data_tx['atx_acc_id']=$sales_acc_id;
					$data_tx['atx_cust_id']=$customer_acc_id;
                   //if shopify no need for this or if amazon so wee need the value after detuct the amazon fee
				   if($website_type=="Amazon.uk"||$website_type=="Amazon.fr"||$website_type=="Amazon.be"||$website_type=="Amazon.de"||$website_type=="Amazon")
					{
						$data_tx['atx_tot_amount']=$total_amount;
					}
					
					else{$data_tx['atx_tot_amount']=$total_amount;}


					$data_tx['atx_vat_amount']=$total_tax;
					$data_tx['atx_region']=$atx_region;
					$data_tx['atx_narration']='Online Transaction';
					$data_tx['atx_quantity']=array_sum($qnty_details);
					$data_tx['atx_salesman']=$salesman_id;
					$data_tx['atx_currency_value']=$conv_value;
					$data_tx['atx_currency_type']=$conv_value_name;
					//	pre_list($data_tx);
				
				if(!empty($total_amount)||!empty($seller_account_balance))
							{
								// echo "inside the sales inv paid";echo "<br/>";
								// print_r($sales_inv_amount_paid);
							//echo "inside last if";echo "<br/>";
							   if($website_type=="Amazon.uk"||$website_type=="Amazon.fr"||$website_type=="Amazon.be"||$website_type=="Amazon.de"||$website_type=="Amazon")
					            {
									///seller_account_balance because we will not take the amazon fees 
						            $data_final_bal_amount=$seller_account_balance;
				             	}
								else{$data_final_bal_amount=$total_amount;}
								//print_r($data_final_bal_amount);echo "<br/>";print_r(array_sum($sales_inv_amount_total));									
								$data_tx['atx_bal_amount']=$data_final_bal_amount;
								
								$data_tx['atx_paid_amount']='0';
							}
							else
							{//seller_account_balance

								$data_tx['atx_bal_amount']=$this->input->post('si_tot_amount');
								$data_tx['atx_paid_amount']='0';
							}	

					$data_tx['atx_dt_updt']=get_date_time();
					$data_tx['atx_sts']='1';
					$data_tx['atx_amount_type']='Income';

	
				// echo "in else - no edit id";
				// pre_list($data_tx);
				$insert_id_acc_tx=$this->Admin_model->insert_data('account_all_tx',$data_tx);
					
		
		
		
						if($website_type=="birigroup.ae")
						{
							$vat_acc_id_to_use='1014';/////if vat os other customers, normal vat output a/c is affected///////
						}
						elseif($website_type=="ksa")
						{
							$vat_acc_id_to_use='759';/////if vat os other customers, normal vat output a/c is affected///////
						}
						elseif($website_type=="dragon")
						{
							$vat_acc_id_to_use='1016';////if customer is dragon-sales cust, need to affect the vat of dragon sales/////
						}
						///this testing we need to know the vat number here also
						elseif($website_type=="Amazon.cp.uk"||$website_type=="Amazon.fr"||$website_type=="Amazon.be")
						{
							$vat_acc_id_to_use='1014';////if customer is dragon-sales cust, need to affect the vat of dragon sales/////
						}elseif($website_type=="Amazon")
						{
							$vat_acc_id_to_use='1014';
						}
						
						else{}

			  /////////////////vat o/p account data //////////////////			 	
					$data_tx['atx_user_created']=$this->session->userdata['user']['username'];
					$data_tx['atx_type_tx']='Vat_OP';
					$data_tx['atx_date']=$new_formated_date1;
					$data_tx['atx_doc_no']=$act_doc_num;
					$data_tx['atx_main_id']=$sales_id_inv_id;
					$data_tx['atx_acc_id']=$vat_acc_id_to_use;
					$data_tx['atx_cust_id']=$customer_acc_id;
					$data_tx['atx_tot_amount']=$total_tax;
					$data_tx['atx_paid_amount']='0';
					$data_tx['atx_bal_amount']=$total_tax;
					$data_tx['atx_dt_updt']=get_date_time();
					$data_tx['atx_sts']='1';
					$data_tx['atx_amount_type']='Income';
					$data_tx['atx_tranfer_type']='sales_invoice';
					$data_tx['atx_region']=$atx_region;
					$data_tx['atx_narration']='Online Transaction';
					$data_tx['atx_quantity']=array_sum($qnty_details);
					$data_tx['atx_salesman']=$salesman_id;
					$data_tx['atx_currency_value']=$conv_value;
					$data_tx['atx_currency_type']=$conv_value_name;
					//pre_list($data_tx);
				if(!empty($edit_inv_id))
				{	
					// echo "inside if - vat";
					// pre_list($data_tx);
				        $this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_main_id'=>$edit_inv_id,'atx_doc_no'=>$this->input->post('si_doc_no'),'atx_type_tx'=>'Vat_OP','atx_region'=>$page_type ));
				}
				else
				{
					// echo "inside else - vat";
					// pre_list($data_tx);
			      $insert_id_acc_vat_tx=$this->Admin_model->insert_data('account_all_tx',$data_tx);
				}
                 
				 		 





				        
				$data_sts['inv_sts']='2';
				$this->Admin_model->update_data('incoming_invoice_online',$data_sts,array('order_number'=>$incoming_invoice_online1[0]->order_number,'shop_name'=>$incoming_invoice_online1[0]->shop_name ));
		
			redirect('list-incoming-invoice-online/'.$page_type);////if customer is dragon-sales cust, need to affect the vat of dragon sales/////
			
		/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////
		}
		else
		{
			 $this->session->set_flashdata('errors', 'Error on data found. Please try again.');
		 		redirect('list-incoming-invoice-online/'.$page_type);////if customer is dragon-sales cust, need to affect the vat of dragon sales/////		
		}
	}
////////////ending if for checking insert_id exist here////////////////////////////////////////////////
	}	
}











}