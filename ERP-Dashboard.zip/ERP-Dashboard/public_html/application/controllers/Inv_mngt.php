<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inv_mngt extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','img','gnrl'));	
	}

function excel_upload()
{

 if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='upload-invoice-excel')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


	$this->load->view('admin/invoice/excel_upload');
}

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 




	
}

function submit_inv_excel()
{
		$this ->load-> library('excel');
		$this ->load-> library('image_lib');
		$path = 'uploads/complete_sales_excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this->upload ->do_upload('userfile')) 
		{
			$error = array('error' => $this -> upload -> display_errors());
			$this ->session-> set_flashdata('errors', $error['error']);
			redirect("upload-invoice-excel", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this -> upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
				$date=trim($allDataInSheet[$i]['A']);
				$rct_no=trim($allDataInSheet[$i]['B']);
				$customer=trim($allDataInSheet[$i]['D']);
				$amount=trim($allDataInSheet[$i]['E']);
				$narration=trim($allDataInSheet[$i]['F']);
				$reference_detail=trim($allDataInSheet[$i]['G']);

				if(!empty($date))
				{
					$date_ref=date("Y-m-d", strtotime($date));
					$ref_no=$rct_no;
					$payment_mode=$customer;
					$paid_amount=str_replace(',', '', $amount);
					$narration_details=$narration;

					$ref_date_array[]=date("Y-m-d", strtotime($date));
					$ref_no_array[]=$rct_no;
					$payment_mode_array[]=$customer;
					$paid_amount_array[]=str_replace(',', '', $amount);
					$narration_array[]=$narration;
				}
				else
				{
					$date_ref=end($ref_date_array);
					$ref_no=end($ref_no_array);
					$payment_mode=end($payment_mode_array);
					$paid_amount=end($paid_amount_array);
					$narration_details=end($narration_array);
				}

				$string_change_1=preg_replace('/\s+/', ' ', $reference_detail);
				$exploded_ref_details=explode(' ',$string_change_1);
				
				if(!empty($exploded_ref_details[1]) && !empty($exploded_ref_details[2]))
				{
					$rct_inv_no=$exploded_ref_details[0];
					$rct_inv_date=date("Y-m-d", strtotime($exploded_ref_details[1]));
					$rct_inv_amount=$exploded_ref_details[2];
				}
				else
				{
					$rct_inv_no=$exploded_ref_details[0];
					$rct_inv_date='';
					$rct_inv_amount='';
				}

			if(!empty($exploded_ref_details[0]))
			{	
				$fetchData2 = array(
					'irr_date'=>$date_ref,
				  	'irr_reg_no'=>$ref_no,
                   	'irr_payment_mode'=>$payment_mode,
                   	'irr_amount_total'=>$paid_amount,
                   	'irr_narration'=>$narration_details,
                   	'irr_date_sales'=>$rct_inv_date,
                   	'irr_voc_no_sales'=>$rct_inv_no,
                   	'irr_amount_sales'=>$rct_inv_amount,
                   	'irr_sts'=>'1',
                   	);
				$insert_id_child=$this->Admin_model->insert_data('inv_recipt_reg',$fetchData2);
			if($insert_id_child)
				$status = true;
			else
				$status = false;
			//pre_list($fetchData2);
			}
		}
		if ($status)
			$this ->session-> set_flashdata('success', 'Excel Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error in Excel Upload. Try again!');
		redirect("upload-invoice-excel", "refresh");
}

function excel_upload_complete_sales_report()
{

 if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='excel_upload_complete_sales_report')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {




	$this->load->view('admin/invoice/excel_upload_complete_sales_report');


   }

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 



	
}

function submit_complete_sales_excel()
{
$this ->load-> library('excel');
		$this ->load-> library('image_lib');
		$path = 'uploads/complete_sales_excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this->upload ->do_upload('userfile')) 
		{
			$error = array('error' => $this ->upload-> display_errors());
			$this ->session-> set_flashdata('errors', $error['error']);
			redirect("excel_upload_complete_sales_report", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this ->upload-> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			$sales_no=trim($allDataInSheet[$i]['A']);
			$date=trim($allDataInSheet[$i]['B']);
			$customer_details=trim($allDataInSheet[$i]['C']);
			$cutomer_extra_details=trim($allDataInSheet[$i]['E']);
			$vat_amount=trim($allDataInSheet[$i]['G']);
			$total_amount=trim($allDataInSheet[$i]['H']);
			$sales_man=trim($allDataInSheet[$i]['I']);
			$credit_days=trim($allDataInSheet[$i]['J']);
			$price_level=trim($allDataInSheet[$i]['K']);
			$delivery_date=trim($allDataInSheet[$i]['L']);
			$country_city=trim($allDataInSheet[$i]['M']);
			$payment_type=trim($allDataInSheet[$i]['N']);


			if(!empty($sales_no) && empty($date))
				{
					if($sales_no !="-----------------------------")
						{
							$branch_name_array[]=str_replace("'", '', $sales_no);
						}
				}
			
			if(!empty($sales_no) && !empty($date))
			{
				if($sales_no !="-----------------------------")
				{
						$data_insert=array(
								'icsr_voc_no'=>$sales_no,
								'icsr_date'=>date("Y-m-d", strtotime($date)),
								'icsr_customer_main'=>$customer_details,
								'icsr_vat'=>str_replace(',', '', $vat_amount),
								'icsr_amount'=>str_replace(',', '', $total_amount),
								'icsr_salesman'=>$sales_man,
								'icsr_credit_days'=>$credit_days,
								'icsr_price_level'=>$price_level,
								'icsr_delivery_date'=>date("Y-m-d", strtotime($delivery_date)),
								'icsr_country_city'=>$country_city,
								'icsr_payment_type'=>$payment_type,
								'icsr_sts'=>'1',
								'icsr_branch_name'=>end($branch_name_array),
								'icsr_customer_extra'=>$cutomer_extra_details,
						);

// pre_list($data_insert);
						$insert_id_child=$this->Admin_model->insert_data('inv_complete_sales_report',$data_insert);
						if($insert_id_child)
							$status = true;
						else
							$status = false;
				}
			}
		}
		if ($status)
			$this ->session-> set_flashdata('success', 'Excel Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error in Excel Upload. Try again!');
		redirect("excel_upload_complete_sales_report", "refresh");
}

function compare_sales_report_receipt()
{

if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='compare-sales-report-receipt')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


	$data['result']=$this->Admin_model->get_compare_sales_receipt();
	$this->load->view('admin/invoice/sales_report_receipt',$data);
}

else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 





}
























}