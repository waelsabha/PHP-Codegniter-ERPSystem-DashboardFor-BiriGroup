<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Delivery_note extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','email_survey'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
		$this->load->library('numbertowordconvertsconver');		

        $this->load->library('numbertowordconvertsconverksa');	
		$this->load->library('Numbertoworduk');	
		require 'vendor/autoload.php';
		require_once 'vendor/khaled.alshamaa/ar-php/src/Arabic.php';		
	}


	function create_delivery_note($page_type=null,$dn=null)
	{
		if(logged_in())
		{

$salesman=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales', 'log_status !='=>'0'));
$data['page_type']=$page_type;
		foreach($salesman as $s)
		{
			$data['salesman'][]=$this->Admin_model->get_data('employee_details',array('ed_login_id'=>$s->log_id));
		}
		$data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
	
		$data['payment_method']=$this->Admin_model->get_data('master_payment_method',array('mpm_sts'=>'1'));
		$data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));
		$data['place_supply']=$this->Admin_model->get_data('master_place_supply',array('mps_sts'=>'1'));
		if($page_type=='uae')
				{
					$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'638'));
				}
				elseif($page_type=='ksa')
				{
						$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'490'));
				}	
				elseif($page_type=='dragon')
				{
						$data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'638'));
				}
				elseif($page_type=='export')
				{
					 $data['customers']=$this->Admin_model->get_data('master_accounts_tree');
				}	
					elseif($page_type=='amazonuk')
				{
					 $data['customers']=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>'1157'));
				}	
				else{}
			if(empty($dn))
			{
				if($page_type=="uae")
				{
					$val_recipt=$this->Admin_model->get_data('delivery_note',array('dn_sts'=>'1'),'','','dn_id','DESC');
				if(empty($val_recipt))
				$data['doc_num']='DLC 1200';
					else
					{
					$bal_string1=str_replace("DLC ", "", $val_recipt[0]->dn_doc_no);
					//print_r($bal_string1);
				           $new_id_1=($bal_string1)+1;
				            $data['doc_num']="DLC ".$new_id_1;
					}
				}
				else if($page_type=="ksa")
				{
					$val_recipt=$this->Admin_model->get_data('delivery_note_ksa',array('dn_sts'=>'1'),'','','dn_id','DESC');
				if(empty($val_recipt))
				$data['doc_num']='DLC:KSA 8994';
					else
					{
					$bal_string1=str_replace("DLC:KSA ", "", $val_recipt[0]->dn_doc_no);
					//print_r($bal_string1);
				           $new_id_1=($bal_string1)+1;
				            $data['doc_num']="DLC:KSA ".$new_id_1;
					}
				}
				else if($page_type=="dragon")
				{
					$val_recipt=$this->Admin_model->get_data('delivery_note_dragon',array('dn_sts'=>'1'),'','','dn_id','DESC');
				if(empty($val_recipt))
				$data['doc_num']='DLC:DSI 12749';
					else
					{
					$bal_string1=str_replace("DLC:DSI ", "", $val_recipt[0]->dn_doc_no);
					//print_r($bal_string1);
				           $new_id_1=($bal_string1)+1;
				            $data['doc_num']="DLC:DSI ".$new_id_1;
					}
				}
				else if($page_type=="export")
				{
					$val_recipt=$this->Admin_model->get_data('delivery_note_export',array('dn_sts'=>'1'),'','','dn_id','DESC');
				if(empty($val_recipt))
				$data['doc_num']='DLC:ESI 1200';
					else
					{
					$bal_string1=str_replace("DLC:ESI ", "", $val_recipt[0]->dn_doc_no);
					//print_r($bal_string1);
				           $new_id_1=($bal_string1)+1;
				            $data['doc_num']="DLC:ESI ".$new_id_1;
					}
				}
					else if($page_type=="amazonuk")
				{
					$val_recipt=$this->Admin_model->get_data('delivery_note_amazonuk',array('dn_sts'=>'1'),'','','dn_id','DESC');
				if(empty($val_recipt))
				$data['doc_num']='DLC:amz_uk 1000';
					else
					{
					$bal_string1=str_replace("DLC:amz_uk ", "", $val_recipt[0]->dn_doc_no);
					//print_r($bal_string1);
				           $new_id_1=($bal_string1)+1;
				            $data['doc_num']="DLC:amz_uk ".$new_id_1;
					}
				}
				else{}

			}
			$this->load->view('admin/transactions/delivery_note',$data);
		}
	}

	function list_delivery_note($page_name=null)
	{
		if(logged_in())
		{
			if(!empty($page_name))
			{
				if($page_name=="uae")
				{
					$from_table="delivery_note";
					$data['page_type']=$page_name;
				}
				elseif($page_name=="ksa")
				{
					$from_table="delivery_note_ksa";
					$data['page_type']=$page_name;
				}
				elseif($page_name=="dragon")
				{
					$from_table="delivery_note_dragon";
					$data['page_type']=$page_name;
				}
				elseif($page_name=="export")
				{
					$from_table="delivery_note_export";
					$data['page_type']=$page_name;
				}
					elseif($page_name=="amazonuk")
				{
					$from_table="delivery_note_amazonuk";
					$data['page_type']=$page_name;
				}
				else{}
			$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'list-delivery-note'));
		$sql2=$this->db->query("SELECT siv.*,mat.label as cust_acc,mat2.mw_name
	FROM ".$from_table." as siv  join master_accounts_tree as mat on mat.id=siv.dn_customer_acc_id
	join master_warehouse as mat2 on mat2.mw_id=siv.dn_warehouse 
	WHERE siv.dn_sts = '1' order by siv.dn_id DESC");
		$data['result']=$sql2->result_array();
			$this->load->view('admin/transactions/list_delivery_note',$data);
			}
		}
	}


	function get_cust_sales_inv()
	{
		$cust_id=$this->input->post('cust_id');
		$page_type=$this->input->post('page_type');
		$cust_id_inv=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$cust_id));
		if($page_type=="uae")
		$all_invoices=$this->Admin_model->get_data('sales_invoice',array('si_customer_acc_id'=>$cust_id,'si_delivery_sts !='=>'delivered','si_fullreturn_sts !='=>'1','si_sts !='=>'0' ));
		elseif($page_type=="ksa")
		//$testingcondition='si_delivery_sts=not_delivered or si_delivery_sts=partially_delivered';
		$all_invoices=$this->Admin_model->get_data('sales_invoice_ksa',array('si_customer_acc_id'=>$cust_id,'si_delivery_sts !='=>'delivered','si_fullreturn_sts !='=>'1','si_sts !='=>'0' ));
		elseif($page_type=="dragon")
		$all_invoices=$this->Admin_model->get_data('sales_invoice_dragon',array('si_customer_acc_id'=>$cust_id,'si_delivery_sts !='=>'delivered','si_fullreturn_sts !='=>'1','si_sts !='=>'0' ));
		elseif($page_type=="export")
		$all_invoices=$this->Admin_model->get_data('sales_invoice_export',array('si_customer_acc_id'=>$cust_id,'si_delivery_sts !='=>'delivered','si_fullreturn_sts !='=>'1','si_sts !='=>'0' ));
		elseif($page_type=="amazonuk")
		$all_invoices=$this->Admin_model->get_data('sales_invoice_uk_amazon',array('si_customer_acc_id'=>$cust_id,'si_delivery_sts !='=>'delivered','si_fullreturn_sts !='=>'1','si_sts !='=>'0' ));
		else{}

		foreach($all_invoices as $index=>$ai)
		{
			//print_r($index);
			$doc_num[]=$ai->si_doc_no;
			$date[]=$ai->si_date;
			$mark[]=$ai->si_mark;
			$inv_id[]=$ai->si_id;
			$prds_ids[]=explode('|#|',$ai->si_product);
			$warehouse_ids=explode('|#|',$ai->si_warehouse);
			$warehouse_details[]=$this->Admin_model->get_data('master_warehouse',array('mw_id'=>$warehouse_ids[0]));
			$company_details[]=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$ai->si_company));
			$rates[]=explode('|#|',$ai->si_rate);
			$qnty[]=explode('|#|',$ai->si_qnt_to_deliver);
			
			
		}

//print_r($rates);
		foreach($prds_ids as $ind=>$k)
		{
			foreach($k as $v1=>$v)
			{
				//print_r($rates[$ind][$v1]);
				 $prd_data=$this->tm->get_data('products',array('pid'=>$v));
				 $prd_details[$ind][]=$prd_data[0]->pname;
				 $mark_details[$ind][]=$mark[$ind];
				 $doc_num_details[$ind][]=$doc_num[$ind];
				 $date_details[$ind][]=$date[$ind];
				 $si_inv_details[$ind][]=$inv_id[$ind];
				 $cust_details_name[$ind][]=$cust_id_inv[0]->label;
				 $company_details_name[$ind][]=$company_details[$ind][0]->mcomp_name;
				 $warehouse_details_name[$ind][]=$warehouse_details[$ind][0]->mw_name;
				 $rate_details[$ind][]=$rates[$ind][$v1];
				 $qnty_details[$ind][]=$qnty[$ind][$v1];
			}
		}

		$ij=1;	
		$html="<div class='row'>
		<div class='col-md-12'>";
$html.="<table class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
			$html.="<thead>";
			$html.="<th></th>";
			$html.="<th>Document No.</th>";
			$html.="<th>Date</th>";
			$html.="<th>Particulars</th>";
			$html.="<th>Quantity</th>";
			$html.="<th>Branch Name</th>";
			$html.="<th>Customer</th>";
			$html.="<th>Store</th>";
			$html.="<th>Mark</th>";
			// $html.="<th>Balance Amount</th>";
			$html.="</thead>";
			$html.="<tbody>";
	if(!empty($cust_details_name))
	{
		foreach($cust_details_name as $ind1=>$civ)
		{
			foreach($civ as $ind2=>$civ2)
			{
			$html.="<tr>";
		$html.="<td><input type='checkbox' name='choose_inv' value='".$si_inv_details[$ind1][$ind2].",".$ind2."'></td>";
		$html.="<td><p>".$doc_num_details[$ind1][$ind2]."</p></td>";
		$html.="<td><p>".$date_details[$ind1][$ind2]."</p></td>";
		$html.="<td><p>".$prd_details[$ind1][$ind2]."</p></td>";
		$html.="<td><p>".$qnty_details[$ind1][$ind2]."</p></td>";
			
		$html.="<td><p>".$company_details_name[$ind1][$ind2]."</p></td>";
		$html.="<td><p>".$civ2."</p></td>";
		$html.="<td><p>".$warehouse_details_name[$ind1][$ind2]."</p></td>";
		$html.="<td><p>".$mark_details[$ind1][$ind2]."</p></td>";
		
			$html.="</tr>"; 
			$ij++;
			}
		}
	}	
		$html.="</tbody>";
			$html.="</table>";
			$html.="</div>		
			</div>";
			echo $html;
	}

	function get_inv_details_checked()
	{
		$checked_vals=explode(',',$this->input->post('checked_inv'));
		$page_type=$this->input->post('page_type');
		$inv_id=$checked_vals[0];
		$array_position=$checked_vals[1];

		if($page_type=="uae")
		$get_inv_details=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$inv_id));
		if($page_type=="ksa")
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$inv_id));
		if($page_type=="dragon")
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$inv_id));
		if($page_type=="export")
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$inv_id));
    if($page_type=="amazonuk")
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_uk_amazon',array('si_id'=>$inv_id));
		else{}
		$warehouses=explode('|#|',$get_inv_details[0]->si_warehouse);
		
		//print_r($total_gross);
		//print_r($warehouses[$array_position]);
		$data=array(
			'warehouse'=>$warehouses[$array_position],
			'payment'=>$get_inv_details[0]->si_payment_type,
			'pls_sup'=>$get_inv_details[0]->si_plc_supply,
			'jurisdiction'=>$get_inv_details[0]->si_jurisdiction,
			'salesman'=>$get_inv_details[0]->si_salesman,
			'mark'=>$get_inv_details[0]->si_mark,
			'delivery_addresss'=>$get_inv_details[0]->si_delivery_address,
			'narration'=>$get_inv_details[0]->si_narration,
			'bill_no'=>$get_inv_details[0]->si_doc_no,
			'lpo_no'=>$get_inv_details[0]->si_lpo_no,
			'ship_contact'=>$get_inv_details[0]->si_shipping_contact,
			'customer_contact'=>$get_inv_details[0]->si_contact,
			'currency'=>$get_inv_details[0]->si_currency,
			'currency_val'=>$get_inv_details[0]->si_conv_value,
			'tot_vat'=>$get_inv_details[0]->si_tot_vat_amount,
			'tot_net'=>$get_inv_details[0]->si_tot_amount,
			'sales_invoice_id'=>$get_inv_details[0]->si_id,
		);
		echo json_encode($data);
	}

	function get_inv_table_checked()
	{ 
		$warehouse=$this->input->post('warehouse_selected');
		$page_type=$this->input->post('page_type');

		$checked_vals=explode(',',$this->input->post('checked_inv'));
		$inv_id=$checked_vals[0];
		$array_position=$checked_vals[1];

		if($page_type=="uae")
		$get_inv_details=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$inv_id));
		if($page_type=="ksa")
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$inv_id));
		if($page_type=="dragon")
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$inv_id));
		if($page_type=="export")
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$inv_id));
    	if($page_type=="amazonuk")
		$get_inv_details=$this->Admin_model->get_data('sales_invoice_uk_amazon',array('si_id'=>$inv_id));
		else{}

		$prd_ids=explode('|#|',$get_inv_details[0]->si_product);
		$qntys=explode('|#|',$get_inv_details[0]->si_qnt_to_deliver);
		$rates=explode('|#|',$get_inv_details[0]->si_rate);
		$gross=explode('|#|',$get_inv_details[0]->si_gross);
		$add_charges=explode('|#|',$get_inv_details[0]->si_add_charges);
		$fnet=explode('|#|',$get_inv_details[0]->si_fnet);
		$vat=explode('|#|',$get_inv_details[0]->si_vat);
		$tax_code=explode('|#|',$get_inv_details[0]->si_tax_code);
		$delivery_date=explode('|#|',$get_inv_details[0]->si_delivery_date);
		$warehouse=explode('|#|',$get_inv_details[0]->si_warehouse);

		
		foreach($prd_ids as $ind=>$val)
		{
			if($ind==$array_position)
			{
				$prd_details[]=$this->tm->get_data('products',array('pid'=>$val));

				$stock_deatils_selected[]=$this->tm->get_data('stock_details',array('sd_warehouse_id'=>$warehouse[$ind],'sd_prd_id'=>$val));

				$qnty[]=$qntys[$ind];
				$rate[]=$rates[$ind];
				$gross_val[]=$gross[$ind];
				$ad_chrgs[]=$add_charges[$ind];
				$fnet_val[]=$fnet[$ind];
				$vat_val[]=$vat[$ind];
				$tax_val[]=$tax_code[$ind];
				$dlvry_date[]=$delivery_date[$ind];
			}
		}

		foreach($prd_details as $ind2=>$p_data)
		{
			//print_r($stock_deatils_selected[0]);
			if(!empty($stock_deatils_selected[0][0]))
			{
			if($stock_deatils_selected[0][0]->sd_stock_qnty >=$qnty[$ind2])
			{
			$gros_calc=$qnty[$ind2]*$rate[$ind2];
			if(!empty($ad_chrgs[$ind2]))
			$fnet_calc=$gros_calc+$ad_chrgs[$ind2];
		else
			$fnet_calc=$gros_calc+0;
		
			$vat_val_calc=$fnet_calc*($vat_val[$ind2]/100);

			$unit_details=$this->tm->get_data('prd_units',array('pu_pid_focus'=>$p_data[0]->prod_id_focus));
				//if(empty(var))
			//	print_r($unit_details);
			$html='<tr>
  <td><input type="text" name="dn_product[]"  value="'.$p_data[0]->pname.'"  step="any"  class="form-control "> <input type="hidden" name="each_prd[]" value="'.$p_data[0]->pid.'"> 
  
  </td>';
if(!empty($unit_details[0]->pu_base_unit))
{
 $html.= '<td><input type="text" name="dn_units[]"  value="'.$unit_details[0]->pu_base_unit.'"  step="any"  class="form-control"> </td>';
}
else
{
	$html.= '<td><input type="text" name="dn_units[]"  value="Default"  step="any"  class="form-control"> </td>';
}
    $html.=' <td><input type="number" name="dn_qnty[]"    value="'.$qnty[$ind2].'"  step="any"  class="form-control" oninput="maxLengthCheck(this)"   max="'.$qntys[$ind].'" min="0"> </td>
     <td><input type="text" name="dn_label[]" value="'.$get_inv_details[0]->si_doc_no.'"  step="any"  class="form-control"> </td>
    <td><input type="number" name="dn_rate[]" value="'.$rate[$ind2].'" step="any" readonly="" class="form-control "> </td>
    <td><input type="number" name="dn_gross[]" value="'.$gros_calc.'" step="any"  readonly="" class="form-control"></td>
    <td><input type="number"  name="dn_add_charges[]" value="'.$ad_chrgs[$ind2].'" readonly="" step="any"  class="form-control "> </td>
    <td><input type="number" name="dn_fnet[]"  value="'.$fnet_calc.'"  step="any"  readonly="" class="form-control"></td>
    <td><input type="text"  name="dn_vat[]" class="form-control " value="'.$vat_val[$ind2].'"> 
    <input type="hidden" name="each_vat_total[]" value="'.$vat_val_calc.'"></td>
    <td></td>
    </tr>';
   $data['html_result']=$html;
   	echo json_encode($data);
			}
			else
			{
				$data['error_result']='<p>'.$p_data[0]->pname. '- Only '.$stock_deatils_selected[0][0]->sd_stock_qnty.' quantity remaining</p><br/>';
   	echo json_encode($data);
			}
		}
			else
			{
				$data['error_result']='<p>Empty Quantity Found.</p></br>';
   	echo json_encode($data);
			}
		}	
	}

function submit_delivery_note()
{
	if(logged_in())
	{
		$page_name=$this->input->post('page_type');
		$edit_delv_id=$this->input->post('delv_id');
		 $main_date=$this->input->post('dn_date');
          $main_date1=explode('/',$main_date);
			$month2=$main_date1[0];
			$date2=$main_date1[1];
 			$year2=$main_date1[2];
          $new_formated_date1=$year2.'-'.$month2.'-'.$date2;

		$data['dn_user_created']=$this->session->userdata['user']['username'];
		$data['dn_doc_no']=$this->input->post('dn_doc_no');

		$data['dn_date']=$new_formated_date1;
		$data['dn_customer_acc_id']=$this->input->post('dn_customer_acc_id');
		$data['dn_salesman']=$this->input->post('dn_salesman');
		$data['dn_lpo_no']=$this->input->post('dn_lpo_no');
		$data['dn_bill_no']=$this->input->post('dn_bill_no');
		$data['dn_payment_type']=$this->input->post('dn_payment_type');
		$data['dn_narration']=$this->input->post('dn_narration');
		$data['dn_contact']=$this->input->post('dn_contact');
		$data['dn_mark']=$this->input->post('dn_mark');
		$data['dn_shipping_contact']=$this->input->post('dn_shipping_contact');
		$data['dn_delivery_address']=$this->input->post('dn_delivery_address');
		$data['dn_plc_supply']=$this->input->post('dn_plc_supply');
		$data['dn_jurisdiction']=$this->input->post('dn_jurisdiction');
		$data['dn_currency']=$this->input->post('dn_currency');
		$data['dn_conv_value']=$this->input->post('dn_conv_value');
		$data['dn_warehouse']=$this->input->post('dn_warehouse');
		$data['dn_product']=$this->input->post('hi_prd_id');
		$data['dn_label']=$this->input->post('hi_label');////add label 
		$data['dn_qnty']=$this->input->post('hi_qnty');
		$data['dn_units']=$this->input->post('hi_unit');
		$data['dn_rate']=$this->input->post('hi_rate');
		$data['dn_gross']=$this->input->post('hi_gross');
		$data['dn_add_charges']=$this->input->post('hi_add_charges');
		$data['dn_fnet']=$this->input->post('hi_fnet');
		// $data['dn_cogs']=$this->input->post('hi_cogs');
		$data['dn_vat']=$this->input->post('hi_vat');
		// $data['dn_delivery_date']=$this->input->post('hi_delivery_date');
		// $data['dn_tax_code']=$this->input->post('hi_tax_code');
		$data['dn_vat_total']=$this->input->post('dn_tot_vat');
		$data['dn_final_total']=$this->input->post('dn_tot_amount');
		$data['dn_sales_inv_id']=$this->input->post('sales_inv_id');
		$data['dn_sts']='1';


	      $prd_ids=explode('|#|', $this->input->post('hi_prd_id'));
				$qntys=explode('|#|', $this->input->post('hi_qnty'));

				//print_r($qntys);


			if($page_name=="uae"){
			$inv=$this->Admin_model->get_data('sales_invoice',array('si_doc_no'=>$data['dn_bill_no']));
			}
			 elseif($page_name=="ksa"){
				$inv=$this->Admin_model->get_data('sales_invoice_ksa',array('si_doc_no'=>$data['dn_bill_no']));
			}

			elseif($page_name=="dragon"){
				$inv=$this->Admin_model->get_data('sales_invoice_dragon',array('si_doc_no'=>$data['dn_bill_no']));
			}
			elseif($page_name=="export"){
				$inv=$this->Admin_model->get_data('sales_invoice_export',array('si_doc_no'=>$data['dn_bill_no']));
			}

      	elseif($page_name=="export"){
				$inv=$this->Admin_model->get_data('sales_invoice_uk_amazon',array('si_doc_no'=>$data['dn_bill_no']));
			}



					$qntyinv=explode('|#|', $inv[0]->si_qnt_to_deliver);
					$qntyprdinvcode=explode('|#|', $inv[0]->si_product);
					$invprdcount=count($qntyinv);
					$delivercount=count($qntys);

					$qntremain[]=0;
					 $qnty_remain=0;
					   $partiallyvalue=0;

					   $qntydelivried[]=0;
					$intermediate[]=0;

					$found = false;

						foreach ($qntyprdinvcode as $key_a => $val_a) {
						    $found = false;
						    foreach ($prd_ids as $key_b => $val_b) {
						       if ($val_a == $val_b) {
						           $intermediate[$key_a]=$qntys[$key_b]; 
						           
						            $found = true;
						        }     
						    }
						    if (!$found)
						    	{
						       $intermediate[$key_a]=0;
						    	} 
						}




											for($i=0;$i<$invprdcount;$i++)
											{

											          			$qntremain[$i]=intval( $qntyinv[$i]) - intval( $intermediate[$i]);
											                    $qntydelivried[$i]=intval( $intermediate[$i]);


											 if($qntremain[$i]<0)
											 {
											   print_r('worng value');
											 }
											 else if($qntremain[$i]==0)
											 {

											   $newqntybalance[$i]=0;
											   $newqntydeliverd[$i]=$qntydelivried[$i];
											   	

											 }
											 else if($qntremain[$i]>0)
											{
												 $newqntybalance[$i]=$qntremain[$i];
												 $newqntydeliverd[$i]=$qntydelivried[$i];
											    $partiallyvalue=$partiallyvalue+1;
												

											}


											}


												 $qnty_remain=implode('|#|', $newqntybalance);
												//$data['qnty_remain']=implode('|#|', $newqntybalance);
												$data['dn_qnty']=implode('|#|', $newqntydeliverd);
												 $qnty_delivried=implode('|#|', $newqntydeliverd);

												$delevired_satatu='';

												if($partiallyvalue==0)
												{
													$delevired_satatu='delivered';

												//if all partiallyvalue=0 then delivered all  
												}

												else{
													//if one of them not 0 then partially deliverd

													$delevired_satatu='partially_delivered';

												}
												 





				$delivery_date=explode('|#|', $this->input->post('hi_delivery_date'));
				$overload=0;



				

	    if ($overload==0)
       { 



			if(empty($edit_delv_id))////willl insert
			{
				if($page_name=="uae")
					{
						$document_bal_number=str_replace("DLC ", "", $this->input->post('dn_doc_no'));
					}
					elseif($page_name=="ksa")
					{
						$document_bal_number=str_replace("DLC:KSA ", "", $this->input->post('dn_doc_no'));
					}
					elseif($page_name=="dragon")
					{
						$document_bal_number=str_replace("DLC:DSI ", "", $this->input->post('dn_doc_no'));
					}
					elseif($page_name=="export")
					{
						$document_bal_number=str_replace("DLC:ESI ", "", $this->input->post('dn_doc_no'));
					}
          	elseif($page_name=="amazonuk")
					{
						$document_bal_number=str_replace("DLC:amz_uk ", "", $this->input->post('dn_doc_no'));
					}
					else{}
				$data['dn_doc_number']=$document_bal_number;
			}

		if(empty($edit_delv_id))////willl insert
		{
					//$insert_id='1';
					if(!empty($this->input->post('hi_prd_id')))
						if($page_name=="uae")
						{
							$insert_id=$this->Admin_model->insert_data('delivery_note',$data);
						}
						elseif($page_name=="ksa")
						{
							$insert_id=$this->Admin_model->insert_data('delivery_note_ksa',$data);
						}
						elseif($page_name=="dragon")
						{
							$insert_id=$this->Admin_model->insert_data('delivery_note_dragon',$data);
						}
						elseif($page_name=="export")
						{
							$insert_id=$this->Admin_model->insert_data('delivery_note_export',$data);
						}
            elseif($page_name=="amazonuk")
						{
							$insert_id=$this->Admin_model->insert_data('delivery_note_amazonuk',$data);
						}
						else{}
			
				if($insert_id)
				{
							  if($page_name=="uae")

								 	$this->Admin_model->update_data('sales_invoice',array('si_delivery_sts'=>$delevired_satatu,'si_qnty_dlevered'=>$qnty_delivried,'si_qnt_to_deliver'=>$qnty_remain), array('si_id'=>$this->input->post('sales_inv_id')) );

										if($page_name=="ksa")
									
								 	$this->Admin_model->update_data('sales_invoice_ksa',array('si_delivery_sts'=>$delevired_satatu,'si_qnty_dlevered'=>$qnty_delivried,'si_qnt_to_deliver'=>$qnty_remain), array('si_id'=>$this->input->post('sales_inv_id')) );

										if($page_name=="dragon")

								   
								  $this->Admin_model->update_data('sales_invoice_dragon',array('si_delivery_sts'=>$delevired_satatu,'si_qnty_dlevered'=>$qnty_delivried,'si_qnt_to_deliver'=>$qnty_remain), array('si_id'=>$this->input->post('sales_inv_id')) );

										if($page_name=="export")
							   $this->Admin_model->update_data('sales_invoice_export',array('si_delivery_sts'=>$delevired_satatu,'si_qnty_dlevered'=>$qnty_delivried,'si_qnt_to_deliver'=>$qnty_remain), array('si_id'=>$this->input->post('sales_inv_id')) );
								if($page_name=="amazonuk")
							   $this->Admin_model->update_data('sales_invoice_uk_amazon',array('si_delivery_sts'=>$delevired_satatu,'si_qnty_dlevered'=>$qnty_delivried,'si_qnt_to_deliver'=>$qnty_remain), array('si_id'=>$this->input->post('sales_inv_id')) );
							    else{}
							
									$prd_ids=explode('|#|', $this->input->post('hi_prd_id'));
									$qntys=explode('|#|', $this->input->post('hi_qnty'));
									$delivery_date=explode('|#|', $this->input->post('hi_delivery_date'));
									
                                    




                                     //Get All Shopify Product 
							//////this adjusment section will be different depending on the page wether ksa or uae or canada

							if($page_name=="uae")	
							{	
					       $shopify_products = json_decode( file_get_contents('https://3527ef9b39427d1d11184c88b2940757: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@biri-group.myshopify.com/admin/api/2022-10/products.json'));
									//$shopify_products = json_decode($shopify_products);
									//print_r($shopify_products);

									////test end ////
									foreach($shopify_products->products as $key => $shopify_product)
									{
										
										$sku_array[$key]=$shopify_product->variants[0]->sku;
										$inventory_array[$key]=$shopify_product->variants[0]->inventory_quantity;
										$inventory_item_array[$key]=$shopify_product->variants[0]->inventory_item_id;
										
									}

									$headerss = array(
										'X-Shopify-Access-Token: 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',
										'Content-Type: application/json'
										
									);
				                    	// // Get the location ID for the inventory level update
									$location_url = 'https://biri-group.myshopify.com/admin/api/2022-10/locations.json';
									//$location_response = shopify_api_call('GET', $location_url, array(), $headers);
									$inventory_url ='https://biri-group.myshopify.com/admin/api/2022-10/inventory_levels/set.json';

									$curl = curl_init();
									curl_setopt($curl, CURLOPT_URL, $location_url);
									curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
									curl_setopt($curl, CURLOPT_HTTPHEADER, $headerss);
									curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
									$location_response = curl_exec($curl);
									curl_close($curl);
									$test3=json_decode($location_response);
									$location_id = $test3->locations[1]->id; // Replace 0 with the index of the location you want to use
                               }
					////////end shopify setting /////////////////////////////////////


                      



									foreach($prd_ids as $ind=>$prd)
									{
										////get the current stock details in each warehuse from stock details table/////////////////////
										$data2=array(
											'sd_prd_id'=>$prd,
											'sd_qnty_delivered'=>$qntys[$ind],
											'sd_warehouse_id'=>$this->input->post('dn_warehouse'),
											'sd_delivered_id'=>$insert_id,
											'sd_sts'=>'1'
										);
													//pre_list($data2);
											if($page_name=="uae")
											$this->Admin_model->insert_data('stock_delivery_details',$data2);
											if($page_name=="ksa")
											$this->Admin_model->insert_data('stock_delivery_details_ksa',$data2);
											if($page_name=="dragon")
											$this->Admin_model->insert_data('stock_delivery_details_dragon',$data2);
											if($page_name=="export")
											$this->Admin_model->insert_data('stock_delivery_details_export',$data2);
											else{}
										
                                        $stock_product_id_sku=$this->tm->get_data('products',array('pid'=>$prd));
										$stock_details_data_stock_table=$this->tm->get_data('stock_details',array('sd_prd_id'=>$prd,'sd_warehouse_id'=>$this->input->post('dn_warehouse')));




										if(!empty($stock_details_data_stock_table[0]->sd_stock_qnty))
										{
										$avlb_stock=$stock_details_data_stock_table[0]->sd_stock_qnty-$qntys[$ind];
										if($avlb_stock<0)
										{
											$overload++;
										}

										$this->tm->update_data('stock_details',array('sd_stock_qnty'=>$avlb_stock),array('sd_id'=>$stock_details_data_stock_table[0]->sd_id));

                                                   ////////start shopify part1/////
                                   //For Inserting New Quantity when update dashboard inventory

									////here must to get the Sku product
								           if($page_name=="uae")	
							                {	
								               	$sku_prod=$stock_product_id_sku[0]->pcode;

												foreach($sku_array as $key_key => $sku)
												{
													if($sku==$sku_prod)
												{
													print_r('yes');
													$nventory_item[]=$inventory_item_array[$key_key];
													$avlb_stock_arr[]=$avlb_stock;
											    }
											       else{
											     	print_r('NO');
											        }
											    }

                                             }
                                                  ////////////////////end shopify part1///////////////////

										}
						        	}
                      	////////////////start sopify part 2////////////////////////
			if($page_name=="uae")
			{
				if(!empty($nventory_item)){
                             foreach($nventory_item as $ke=>$inventory_item_idn)
                         {
									$inventory_item_id=$inventory_item_idn;				
									$datashop[$ke] = array(
							'location_id' => $location_id,
							'inventory_item_id' => $inventory_item_id,
								'available' => $avlb_stock_arr[$ke] // Replace with the new inventory level
							);

							$curl = curl_init();
							curl_setopt($curl, CURLOPT_URL, $inventory_url);
							curl_setopt($curl, CURLOPT_CUSTOMREQUEST,'POST');
							curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($datashop[$ke]));
							curl_setopt($curl, CURLOPT_HTTPHEADER, $headerss);
							curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
							$responsess = curl_exec($curl);
							curl_close($curl);
						}	
				}
				}
				/////////////////////end sopify part 2/////////////////////////////////////////            
			    $act_doc_num=$this->input->post('dn_doc_no');
				$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'Delivery note created',
				'act_status'=>'delivery note id '.$insert_id,
				'act_type'=>'delivery_note',/////will be based on type, the activity will be extracted////
				'act_type_id'=>$insert_id,
                 
              'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
               'act_doc_num'=>$act_doc_num,

					);
				$this->Admin_model->insert_data('activities',$activity_data);
				$this->session->set_flashdata('success', 'Data sucessfully entered.');
			}

			else
			{
				$this->session->set_flashdata('errors', 'Error on entering data.PLease try again.');
			}
		}
	}

					redirect('list-delivery-note/'.$page_name);
	}////checking logged in ends////
}



/////////////////////////////////////Testing first////////////////////////////////////////////////////////////


function generate_delivery_pdf($page_type)
{
	if(logged_in())
	{
		$dn_bill=$this->input->post('sales_delrviry_id');
		$delrviry_pdf_type=$this->input->post('pdf-print-option');

		///for english - arabic number in words//////
 		$Arabic = new \ArPHP\I18N\Arabic();
 		 $Arabic->setNumberFeminine(1);
    	$Arabic->setNumberFormat(1);
    	///////end en-ar words/////////
  

		if(!empty($dn_bill))
		{

if($page_type=="uae")
    
      
      $dn_data= $this->Admin_model->get_data('delivery_note',array('dn_id'=>$dn_bill));
    
elseif($page_type=="ksa")
 
 	 
     $dn_data= $this->Admin_model->get_data('delivery_note_ksa',array('dn_id'=>$dn_bill));  
 
 
	elseif($page_type=="dragon")
	
		
		$dn_data= $this->Admin_model->get_data('delivery_note_dragon',array('dn_id'=>$dn_bill));
	
   
		elseif($page_type=="export")
		
			
          $dn_data= $this->Admin_model->get_data('delivery_note_export',array('dn_id'=>$dn_bill));  

          elseif($page_type=="amazonuk")
		
			
          $dn_data= $this->Admin_model->get_data('delivery_note_amazonuk',array('dn_id'=>$dn_bill)); 
		
      else{}

$prd_details=explode('|#|',$dn_data[0]->dn_product);
$qty_details=explode('|#|',$dn_data[0]->dn_qnty);
//$doc_details_id=explode(':',$dn_data[0]->dn_doc_no);
//$unt_price_details=explode('|#|',$dn_data[0]->si_rate);//
//$gross_details=explode('|#|',$siv_data[0]->si_gross);//
//$discount_per_details=explode('|#|',$siv_data[0]->si_dis_per);//
//$disc_amount_details=explode('|#|',$siv_data[0]->si_dis_amount);//
//$add_charge_details=explode('|#|',$siv_data[0]->si_add_charges);//
//$fnet_details=explode('|#|',$siv_data[0]->si_fnet);//
//$vat_pre_details=explode('|#|',$siv_data[0]->si_vat);//
//$delivery_date_details=explode('|#|',$siv_data[0]->si_delivery_date);//
//$remark_details=explode('|#|',$siv_data[0]->si_remrk);//
//$tax_code_details=explode('|#|',$siv_data[0]->si_tax_code);//

foreach($prd_details as $index=>$pd)
{
	$prd_table_data[]=$this->tm->get_data('products',array('pid'=>$pd));	
}

$salesman=$this->Admin_model->get_data('employee_details',array('ed_id'=>$dn_data[0]->dn_salesman));

$customer_extra_data=$this->Admin_model->get_data('master_accounts_tree_file_data',array('accounts_tree_id'=>$dn_data[0]->dn_customer_acc_id));

 $acc_customer_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dn_data[0]->dn_customer_acc_id));	
	
$currency=$this->Admin_model->get_data('master_currency_conv',array('currency_name'=>$dn_data[0]->dn_currency));

$warehose_from=$this->Admin_model->get_data('master_warehouse',array('mw_id'=>$dn_data[0]->dn_warehouse));

$stylesheet = file_get_contents('style_mpdf.css');
////////////////for qr code////////////////////////////
/*$this->load->library('ciqrcode');
//header("Content-Type: image/png");

$params['data'] = base_url('load_delivery_data/'.$doc_details_id[1]);
$params['level'] = 'H';
$params['size'] = 10;
$params['savename'] = './uploads/qr_code/'.$doc_details_id[1].'.png';
 $this->ciqrcode->generate($params);*/
//echo '<img src="'.base_url().'/uploads/inv_pdf/tes.png" />';
///////////qr code ends//////////////////////////////////////////

$html='<!doctype html>';
if($delrviry_pdf_type!='1')
{
$html.='<br/><br/><br/><br/>';
}

$html.='<head></head><body>';
if ($delrviry_pdf_type == '1') {
					$html .= '<div style="position: absolute; visibility: visible; left: 680px; top: 110px; z-index: 200;"></div>';
				}
				else{
					$html .= '<div style="position: absolute; visibility: visible; left: 680px; top: 230px; z-index: 200;"></div>';

				}
$html.='<div class="content" ><br/>';
	$head_all = '';
				$head_all.= '<table border="0" width="100%">';
				$head_all.= '<tr> <td>  </td></tr>';
				$head_all.= '<tr> <td>  </td></tr>';
				
				$head_all.= '<tr> <td> <br> </td></tr>';
				$head_all.= '<tr><td style="text-align:left;">';
				$head_all.= '<table border="0" width="100%" >';
				$head_all.= '<tbody>';

				if ($page_type == "ksa") {
					$head_all.= '<tr>';
					$head_all.= '<td>الرقم الضريبي  :310159338600003</b></td>';
					$head_all.= '</tr><br/>';
					$head_all.= '<tr>';
					$head_all.= '<td >' . $dn_data[0]->dn_narration . '</td>';
					$head_all.= '</tr><br/>';
				} 
        elseif($page_type == "amazonuk") {

					// $head_all.= '<tr>';
					// $head_all.= '<td align="right"><b align="right">Our TRN:</b></td>';
					// $head_all.= '</tr><br/>';
				//	$head_all.= '<tr>';
					//$head_all.= '<td ></td>';
				//	$head_all.= '</tr><br/>';
				}
        
        else {

					$head_all.= '<tr>';
					$head_all.= '<td align="right"><b align="right">Our TRN:100301351100003</b></td>';
					$head_all.= '</tr><br/>';
					$head_all.= '<tr>';
					$head_all.= '<td >TRN#100567461700003</td>';
					$head_all.= '</tr><br/>';
				}
				$head_all.= '<tr>';
				$head_all.= '<td ><b>' . $acc_customer_details[0]->label . '</b></td>';
				$head_all.= '</tr>';
			if ($page_type == "ksa") {

					$head_all.= '<tr>';
					$head_all.= '<td></td><td></td>';
					$head_all.= '</tr>';
				} else {
					$head_all.= '<tr>';
					$head_all.= '<td ></td>';
					$head_all.= '</tr>';
				}
				
				$head_all.= '<tr>';

				if ($page_type == "ksa") {
					$head_all.= '<td>رقم الهاتف   :' . $customer_extra_data[0]->phone . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
	                $head_all.= '<td>رقم الفاكس :' . $customer_extra_data[0]->fax . '</td>';
				} else {
					$head_all.= '<td>Tel No.:' . $customer_extra_data[0]->phone . '</td>';
						$head_all.= '</tr>';
						$head_all.= '<tr>';
					$head_all.= '<td>Fax No :' . $customer_extra_data[0]->fax . '</td>';
				}



				$head_all.= '</tr>';
				if ($page_type == "ksa") {
					$head_all.= '<tr>';
					$head_all.= '<td> عنوان الشحن   </td><td> ' . character_limiter($dn_data[0]->dn_delivery_address, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td> جهة اتصال الشحن   </td><td>' . $dn_data[0]->dn_shipping_contact . '</td>';
					$head_all.= '</tr>';
				} else {
					$head_all.= '<tr>';
					$head_all.= '<td>Shipping Address : </td><td> ' . character_limiter($dn_data[0]->dn_delivery_address, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Shipping Contact : </td><td>' . $dn_data[0]->dn_shipping_contact . '</td>';
					$head_all.= '</tr>';
				}
				$head_all.= '</tbody>';
				$head_all.= '</table>';
				$head_all.= '</td>';

				$head_all.= '<td style="text-align:right;">';
				$head_all.= '<table border="0" width="100%" >';
				$head_all.= '<tbody>';
			
				if ($page_type == "ksa") {
                    $head_all.= '<tr>';
						$head_all.= '<td align="left"><b align="left"> Delivery Order إذن التسليم  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</b></td>';
					$head_all.= '</tr><br/><br/>';

				} else {

					$head_all.= '<tr>';
					$head_all.= '<td align="left"><b align="left">Delivery Order</b></td>';
					$head_all.= '</tr><br/><br/>';
					
				}

				if ($page_type == "ksa") {

					$head_all.= '<tr>';
					$head_all.= '<td>مندوب المبيعات   :</td><td> ' . character_limiter($salesman[0]->ed_name, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td> رقم اذن التسليم :</td><td> ' . $dn_data[0]->dn_doc_no . '</td>';
					$head_all.= '</tr>';
                    $head_all.= '<tr>';
					$head_all.= '<td> رقم فاتورة الشراء :</td><td> ' . $dn_data[0]->dn_bill_no . '</td>';
					$head_all.= '</tr>';

					$head_all.= '<tr>';
					$head_all.= '<td> التاريخ: </td><td>' . $dn_data[0]->dn_date . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td> علامة الشحن  :</td><td> ' . character_limiter($dn_data[0]->dn_mark, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td> جهة اتصال العميل  :</td><td> ' . $dn_data[0]->dn_contact . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>رقم الطلب  :</td><td> ' . $dn_data[0]->dn_lpo_no . '</td>';
					$head_all.= '</tr>';
				}
        
        
        
         elseif($page_type == "amazonuk") {
					$head_all.= '<tr>';
					$head_all.= '<td>Sales Person :</td><td> ' . character_limiter($salesman[0]->ed_name, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Dlivery No. :</td><td> ' . $dn_data[0]->dn_doc_no . '</td>';
					$head_all.= '</tr>';
					 $head_all.= '<tr>';
					$head_all.= '<td> Bill No. :</td><td> ' . $dn_data[0]->dn_bill_no . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Date  : </td><td>' . $dn_data[0]->dn_date . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Mark :</td><td> ' . character_limiter($dn_data[0]->dn_mark, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Customer Contact :</td><td> ' . $dn_data[0]->dn_contact . '</td>';
					$head_all.= '</tr>';
				//	$head_all.= '<tr>';
				//	$head_all.= '<td>L.P.O No :</td><td> ' . $dn_data[0]->dn_lpo_no . '</td>';
				//	$head_all.= '</tr>';
				}
        
        
        
         else {
					$head_all.= '<tr>';
					$head_all.= '<td>Sales Person :</td><td> ' . character_limiter($salesman[0]->ed_name, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Dlivery No. :</td><td> ' . $dn_data[0]->dn_doc_no . '</td>';
					$head_all.= '</tr>';
					 $head_all.= '<tr>';
					$head_all.= '<td> Bill No. :</td><td> ' . $dn_data[0]->dn_bill_no . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Date  : </td><td>' . $dn_data[0]->dn_date . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Mark :</td><td> ' . character_limiter($dn_data[0]->dn_mark, 16) . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>Customer Contact :</td><td> ' . $dn_data[0]->dn_contact . '</td>';
					$head_all.= '</tr>';
					$head_all.= '<tr>';
					$head_all.= '<td>L.P.O No :</td><td> ' . $dn_data[0]->dn_lpo_no . '</td>';
					$head_all.= '</tr>';
				}

             
				$head_all.= '</tbody>';
				$head_all.= '</table>';
				$head_all.= '</td>';
				$head_all.= '</tr>';

				$head_all.= '</table>';
				$head_all.= '</div>';
$html.='</div>';

$html.='<div class="content">
<table  align="center"  width="100%">';
$html.='<tbody>';
if($page_type=="ksa")
{
$html.='<tr >';
$html.='<td align="center" class="prd_info_2">المستودع المصدر</td>';
$html.='<td align="center" class="prd_info_2">رمز الصنف  </td>';
$html.='<td align="center" class="prd_info_2">الصنف  </td>';
$html.='<td align="center" class="prd_info_2">وصف  </td>';
$html.='<td align="center" class="prd_info_2">الكمية </td>';
/*$html.='<td align="center" class="prd_info_2"></td>';
$html.='<td align="center" class="prd_info_2"></td>';*/
}
else
{
$html.='<tr >';
$html.='<td align="center" class="prd_info_2">Warehouse des</td>';
$html.='<td align="center" class="prd_info_2">Item Code</td>';
$html.='<td align="center" class="prd_info_2">Class </td>';
$html.='<td align="center" class="prd_info_2">Description</td>';
$html.='<td align="center" class="prd_info_2">Qty</td>';
/*$html.='<td align="center" class="prd_info_2"></td>';
$html.='<td align="center" class="prd_info_2"></td>';*/
}
	if($page_type=="uae")
	$html.='<td align="center" class="prd_info_2">VAT @5%</td>';
	elseif($page_type=="ksa")
		$html.='<td align="center" class="prd_info_2"></td>';
	elseif($page_type=="dragon")
	$html.='<td align="center" class="prd_info_2">VAT @5%</td>';
	elseif($page_type=="export")
  	$html.='';
  elseif($page_type=="amazonuk")
	$html.='<td align="center" class="prd_info_2"></td>';

$html.='</tr>';
$i=1;
$total_sum_prd='';
$total_vat_sum_prd='';
$total_discount_sum_prd='';


					foreach($prd_table_data as $index=>$pd3)
					{
						

						if($index % 10 == 0 && $index != 0){
						
						$html .= '<table align="center"  width="100%">';
						$html .= '<tbody>';
						if ($delrviry_pdf_type == '1') {
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
						}
						else{
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
							$html .= '<tr><td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td> <td> <br> </td></tr>';
						
						}
						
						
						if ($page_type == "ksa") {
							$html .= '<tr >';
							$html .= '<td align="center" class="prd_info_2">المستودع المصدّر</td>';
							$html .= '<td align="center" class="prd_info_2">رمز الصنف  </td>';
							$html .= '<td align="center" class="prd_info_2">الصنف   </td>';
							$html .= '<td align="center" class="prd_info_2">وصف  </td>';
							$html .= '<td align="center" class="prd_info_2">الكمية  </td>';
						/*	$html .= '<td align="center" class="prd_info_2"></td>';
							$html .= '<td align="center" class="prd_info_2"></td>';*/
						} else {
							$html .= '<tr >';
							$html .= '<td align="center" class="prd_info_2">Warehouse des</td>';
							$html .= '<td align="center" class="prd_info_2">Item Code</td>';
							$html .= '<td align="center" class="prd_info_2">Class </td>';
							$html .= '<td align="center" class="prd_info_2">Description</td>';
							$html .= '<td align="center" class="prd_info_2">Qty  </td>';
							/*$html .= '<td align="center" class="prd_info_2"></td>';
							$html .= '<td align="center" class="prd_info_2"></td>*/					
								}
						if ($page_type == "uae")
							$html .= '<td align="center" class="prd_info_2">VAT @5%</td>';
						elseif ($page_type == "ksa")
							$html .= '<td align="center" class="prd_info_2"></td>';
						elseif ($page_type == "dragon")
							$html .= '<td align="center" class="prd_info_2">VAT @5%</td>';
						elseif ($page_type == "export")
							$html .= '';
              	elseif ($page_type == "amazonuk")
                	$html .= '';
						$html .= '</tr >';
					}
$html.='<tr>';
$html.='<td align="center" width="20%">'.$warehose_from[0]->mw_name.'</td>';
$html.='<td align="center" width="20%">'.$pd3[0]->pcode.'</td>';
$html .= '<td align="center" width="20%"><p style="font-size:12px;">' . $pd3[0]->pcat . '</p></td>';
if($page_type!="ksa")
$html.='<td align="center" width="35%">'.$pd3[0]->pname;
else
{
	if(!empty($pd3[0]->pname_ar))
	{
		$html .= '<td align="center" style="height:25px !important;overflow: hidden !important;" width="30%"><p style="font-size:11px;">' . $pd3[0]->pname_ar .'<br>'.$pd3[0]->pname .'</p>';
	}
	else
	{
		$html.='<td align="center" width="35%">'.$pd3[0]->pname;
	}
}
$html.='</td>';
$html.='<td align="center" width="10%">'.$qty_details[$index].'</td>';
/*$html.='<td align="center" width="11%"></td>';
$html.='<td align="center" width="11%"></td>';
/*$vat_perce=$fnet_details[$index]*($vat_pre_details[$index]/100);
$vat_amount_tot[]=$fnet_details[$index]*($vat_pre_details[$index]/100);
$dis_per_tot[]=$gross_details[$index]*($discount_per_details[$index]/100);*/
/*if($page_type!="export")
{
$html.='<td align="center" width="11%"></td>';
}*/
$html.='</tr>';

					if($index % 9 == 0 && $index != 0)
					{
						$html .= '</tbody>';
						$html .= '</table>';
						
						$html .= "<pagebreak />";
					}
					$total_qty=$total_qty+($qty_details[$index]);
					}
$html.='</tbody>';
$html.='</table>';
$html.='</div>';




$html.='<div class="content_2">';
//$html.='<img align="bottom"  src="'.base_url().'/uploads/qr_code/'.$siv_data[0]->si_doc_no.'.png" width="100" height="100"/>';

$html.='<table class="prd_info_2" align="center" width="100%">';


if($page_type=="ksa")
{
  
    $ar_number_word = number_format((float)$total_qty);
    $text   = $Arabic->int2str($ar_number_word);
    
    // echo "<p align=center>$number<br />$text</p>";////not to use////
$html.='<tr>';
$html.='<td align="right" >   '. $text.'  </td>   <td align="right" width="11%">  ' . $total_qty. ':Total   </td>';
$html.='</tr>';
}


else
	
{
$html.='<tr>';
$html.='<td align="right" > '.$this->numbertowordconvertsconver->convert_number($total_qty).'  </td>   <td align="right" width="11%">  ' . $total_qty. ':Total   </td>'; 
$html.='</tr>';
}
$html.='</table>';


$html.='<table width="100%">';
$html.='<tr>';

$html.='<td>';
$html.='<table width="80%">';
$html.='<tbody>';
$html.='<tr>';
if($page_type=="ksa")
$html.='<td ><u class="underline_space"></u></td>';
else
$html.='<td><u class="underline_space"></u></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td></td>';
if($page_type=="ksa")
{
  
    /*$ar_number_word = number_format((float)$siv_data[0]->si_tot_amount, 2, '.', '');
    $text   = $Arabic->money2str($ar_number_word, 'SAR', 'ar');*/
    
    // echo "<p align=center>$number<br />$text</p>";////not to use////
$html.='<td colspan="2"></td>';
}
else
$html.='<td colspan="2"></td>';
$html.='</tr>';

if($page_type=="ksa")
{
$html.='<tr>';
$html.='<td> توقيع المستلم   :</td>';
$html.='<td></td>';
$html.='<td>  توقيع المفوض   </td>';
$html.='</tr>';
}
else
{
	$html.='<tr>';
$html.='<td>Receiver`s Signature:</td>';
$html.='<td></td>';
$html.='<td>Authorised   </td>';
$html.='</tr>';
}

$html.='</tbody>';
$html.='</table>';
$html.='</td>';

$html.='<td>';
$html.='<table width="80%">';
$html.='<tbody>';
if($page_type=="ksa")
{
$html.='<tr>';
$html.='<td> </td>';
$html.='</tr>';

$html.='<tr>';
$html.='<td><b></b></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td></td>';
$html.='<td></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td> </td>';
$html.='<td></td>';
$html.='</tr>';
$html.='<tr>';
}
else
{
$html.='<tr>';
$html.='<td></td>';
$html.='</tr>';

$html.='<tr>';
$html.='<td><b></b></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td></td>';
$html.='<td></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td></td>';
$html.='<td></td>';
$html.='</tr>';
$html.='<tr>';
}

if($page_type=="uae")
{
	$html.='<td>VAT @5%</td>';
$html.='<td></td>';
}
elseif($page_type=="ksa")
{
	$html.='<td></td>';
$html.='<td></td>';
}
elseif($page_type=="dragon")
{
$html.='<td>VAT @5%</td>';
$html.='<td></td>';
}
elseif($page_type=="export")
$html.='';
elseif($page_type=="amazonuk")
$html.='';


$html.='</tr>';
$html.='<tr>';
if($page_type=="ksa")
$html.='<td> </td>';
else
$html.='<td></td>';

$html.='<td></td>';	
$html.='</tr>';
$html.='</tbody>';
$html.='</table>';
$html.='</td>';

$html.='</tr>';
$html.='</table ><br/><br/>';

$html.='</div>';


$html.='</body>';
$html.='</html>';

//echo $html;
$pdfFilePath = $dn_data[0]->dn_doc_no.'.pdf';

	 $mpdf = new \Mpdf\Mpdf();
	 $mpdf->autoScriptToLang = true;
	$mpdf->autoLangToFont = true;
    $mpdf->autoArabic=true;
	$mpdf->defaultfooterline = 0;





  if($page_type=="uae")
		{    
			$delivery_company_details=$this->Admin_model->get_data('sales_invoice',array('si_doc_no'=>$dn_data[0]->dn_bill_no));
	       $company_details_si=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$delivery_company_details[0]->si_company));
	    }

	elseif($page_type=="ksa"){
		
		$delivery_company_details=$this->Admin_model->get_data('sales_invoice_ksa',array('si_doc_no'=>$dn_data[0]->dn_bill_no));
	       $company_details_si=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$delivery_company_details[0]->si_company));
	}
		elseif($page_type=="dragon"){
			
			$delivery_company_details=$this->Admin_model->get_data('sales_invoice_dragon',array('si_doc_no'=>$dn_data[0]->dn_bill_no));
	       $company_details_si=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$delivery_company_details[0]->si_company));
		}
			
			elseif($page_type=="export"){
				
		$delivery_company_details=$this->Admin_model->get_data('sales_invoice_export',array('si_doc_no'=>$dn_data[0]->dn_bill_no));
	     $company_details_si=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$delivery_company_details[0]->si_company));
				}

        	elseif($page_type=="amazonuk"){
				
		$delivery_company_details=$this->Admin_model->get_data('sales_invoice_uk_amazon',array('si_doc_no'=>$dn_data[0]->dn_bill_no));
	     $company_details_si=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$delivery_company_details[0]->si_company));
				}
				else{}




 






 
if($delrviry_pdf_type=='1')
{
if ( strpos($company_details_si[0]->mcomp_name, 'UAE ') !== false) {

 	$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');
}
elseif ( strpos($company_details_si[0]->mcomp_name, 'UAE') !== false) {

 	$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');
}
elseif(strpos($company_details_si[0]->mcomp_name, 'Dubai ') !== false)
{
 $mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');

}
elseif(strpos($company_details_si[0]->mcomp_name, 'FACTORY') !== false)
{
 	$mpdf->SetHeader('<img src="'.base_url("biri_industries_header.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("biri_industries_footer.png").'">');
}
elseif($page_type=="ksa")
{
 $mpdf->SetHeader('<img src="'.base_url("ksa-header-new.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("ksa-footer-new.png").'">');

}
elseif($page_type=="amazonuk")
{
 $mpdf->SetHeader('<img src="'.base_url("UK Header2.png").'">'.$head_all);
 	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("UK footer2.png").'">');

}
else
{}

}
else
{
	$mpdf->SetHeader($head_all);
	$mpdf->SetFooter('<div style="margin-bottom:100px;">Page {PAGENO} of {nb}</div>');
}
//echo $html;
//print_r($fnet_details);
		 $mpdf->WriteHTML($stylesheet,1);
		 if ($delrviry_pdf_type == '1') {
					$mpdf->AddPage(
						'', // L - landscape, P - portrait 
						'',
						'',
						'',
						'',
						5, // margin_left
						5, // margin right
						89, // margin top
						20, // margin bottom
						0, // margin header
						0
					); // margin footer
				}
				else{
					$mpdf->AddPage(
						'', // L - landscape, P - portrait 
						'',
						'',
						'',
						'',
						5, // margin_left
						5, // margin right
						97, // margin top
						20, // margin bottom
						60, // margin header
						30
					); // margin footer
				}
   
	     $mpdf->WriteHTML($html,2);	     
	     //save in folder
		$mpdf->Output("./uploads/inv_pdf/".$pdfFilePath, "F");
  		$mpdf->Output($pdfFilePath,'D');
				
 		}
	}
}



/////////////////////////////////////////////testing first///////////////////////////////////////////////////////////////////////



/*function load_delivery_data($doc_details_id=null)
{
	//echo str_replace('_', ' ', $doc_num);
	if(!empty($doc_details_id))
	{
		//header('Content-Type: application/pdf');
//   echo '<iframe src="'.base_url().'uploads/inv_pdf/'.str_replace('_', ' ', $doc_num).'.pdf" width="90%" height="500px">
// </iframe>';
//$filename = "".base_url()."/uploads/inv_pdf/".str_replace('_', ' ', $doc_num);
//echo "<iframe src=\"".base_url()."uploads/inv_pdf/".str_replace('_', ' ', $doc_num)."\" width=\"100%\" style=\"height:100%\"></iframe>";
		// $file = file_get_contents("".base_url()."uploads/inv_pdf/".str_replace('_', ' ', $doc_num).".pdf", true);
		// echo $file;
		// $myfile = fopen("".base_url()."uploads/inv_pdf/".str_replace('_', ' ', $doc_num).".pdf", "r") or die("Unable to open file!");
		// echo fread($myfile,filesize("".base_url('uploads/inv_pdf/')."".str_replace('_', ' ', $doc_num).".pdf"));
		// fclose($myfile);

		//echo "<a href='".base_url()."uploads/inv_pdf/".$doc_num.".pdf'>ghffffffffffffffffffffffffffff open</a>";
		//$filename= base_url("uploads/inv_pdf/").$doc_num.".pdf";
  
// // // Header content type
// header("Content-type: application/pdf");
  
// header("Content-Length: " . filesize($filename));
  
// // Send the file to the browser.
// echo $filename;
$filePath=base_url("uploads/inv_pdf/").$doc_details_id.".pdf";
$filename=base_url("uploads/inv_pdf/").$doc_details_id.".pdf";
header('Content-type:application/pdf');
header('Content-disposition: inline; filename="'.$filename.'"');
header('content-Transfer-Encoding:binary');
header('Accept-Ranges:bytes');
@ readfile($filePath);
	}
}


*/

          ///also testing'///////
































function get_doc_details()
{
	$delvry_id=$this->input->post('main_id');
	$page_type=$this->input->post('page_type');
	if($page_type=="uae")
	$dataa=$this->Admin_model->get_data('delivery_note',array('dn_id'=>$delvry_id));
	elseif($page_type=="dragon")
	$dataa=$this->Admin_model->get_data('delivery_note_dragon',array('dn_id'=>$delvry_id));	
	elseif($page_type=="export")
	$dataa=$this->Admin_model->get_data('delivery_note_export',array('dn_id'=>$delvry_id));
	elseif($page_type=="ksa")
	$dataa=$this->Admin_model->get_data('delivery_note_ksa',array('dn_id'=>$delvry_id));	

  elseif($page_type=="amazonuk")
	$dataa=$this->Admin_model->get_data('delivery_note_amazonuk',array('dn_id'=>$delvry_id));	
	else{}

	$warehouse=$this->Admin_model->get_data('master_warehouse',array('mw_id'=>$dataa[0]->dn_warehouse));
	$customer=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->dn_customer_acc_id));
	$salesman=$this->Admin_model->get_data('employee_details',array('ed_id'=>$dataa[0]->dn_salesman));
	$plc_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->dn_plc_supply));
	$jurisdiction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->dn_jurisdiction));
	$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->dn_currency));
	$payment_type=$this->Admin_model->get_data('master_payment_method',array('mpm_id'=>$dataa[0]->dn_payment_type));

	$prd_details=explode('|#|',$dataa[0]->dn_product);
	$qnty_details=explode('|#|',$dataa[0]->dn_qnty);
	$label=explode('|#|',$dataa[0]->dn_label);
	$unit=explode('|#|',$dataa[0]->dn_units);
	$rate=explode('|#|',$dataa[0]->dn_rate);
	$gross=explode('|#|',$dataa[0]->dn_gross);
	$fnet=explode('|#|',$dataa[0]->dn_fnet);
	$add_charges=explode('|#|',$dataa[0]->dn_add_charges);
	$vat=explode('|#|',$dataa[0]->dn_vat);

$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Delivery Note Data</h4>";
					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->dn_doc_no ."</p>";					
					$html.="<p>Date: ".$dataa[0]->dn_date."</p>";
					$html.="<p>Connected Invoice: ".$dataa[0]->dn_bill_no."</p>";
					$html.="<p>Warehouse: ".$warehouse[0]->mw_name."</p>";
					$html.="<p>Salesman: ".$salesman[0]->ed_name."</p>";
					$html.="<p>LPO No.: ".$dataa[0]->dn_lpo_no."</p>";
					$html.="<p>Bill No.: ".$dataa[0]->dn_bill_no."</p>";
					$html.="<p>Payment Type: ".$payment_type[0]->mpm_name."</p>";
					$html.="<p>Place of Supply: ".$plc_supply[0]->mps_name."</p>";
					$html.="<p>Jurisdiction: ".$jurisdiction[0]->mps_name."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Customer: ".$customer[0]->label."</p>";
					$html.="<p>Delivery Address: ".$dataa[0]->dn_delivery_address."</p>";
					$html.="<p>Contact: ".$dataa[0]->dn_contact."</p>";
					$html.="<p>Mark: ".$dataa[0]->dn_mark."</p>";
					$html.="<p>Ship Contact: ".$dataa[0]->dn_shipping_contact."</p>";
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>User Created: ".$dataa[0]->dn_user_created."</p>";
					$html.="<p>Narration: ".$dataa[0]->dn_narration."</p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

					$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th>";
					$html.="<th>Product</th>";
					$html.="<th>Quantity</th>";
					$html.="<th>Label</th>";
					$html.="<th>Units</th>";
		
					$html.="</thead>";
					$html.="<tbody>";
					$i=1;
					foreach($prd_details as $key=>$d)
					{
						$data_prd=$this->tm->get_data('products',array('pid'=>$d));
						$html.="<tr>";
						$html.="<td>".$i++."</td>";
						$html.="<td>".$data_prd[0]->pname."</td>";
						$html.="<td>".$qnty_details[$key]."</td>";
						$html.="<td>".$label[$key]."</td>";
						$html.="<td>".$unit[$key]."</td>";
			
						$html.="</tr>";
					}
					$html.="</tbody>";
					$html.="</table>";
						$html.="<div class='row'>";
					$html.="<div class='col-md-12'><div class='col-md-4'>";
					$html.="<p>Final Vat Amount : ".$dataa[0]->dn_vat_total."</p>";
						$html.="<p>Final Total Amount : ".$dataa[0]->dn_final_total."</p>";
					$html.="</div>";$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/
					echo $html;
}




}