<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Proforma_Invoice extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->library('numbertowordconvertsconver');			
		$this->load->model(array('Second_db_model','Sales_book_model'));
		$this->load->model('Third_db_model','tm');		
		require 'vendor/autoload.php';
		require_once 'vendor/khaled.alshamaa/ar-php/src/Arabic.php';	
	}

function export_performa($type,$qid)
{
	///for english - arabic number in words//////
 		$Arabic = new \ArPHP\I18N\Arabic();
 		 $Arabic->setNumberFeminine(1);
    	$Arabic->setNumberFormat(1);
    	///////end en-ar words/////////

	$quotation_data=$this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$qid));
	
	if(!empty($quotation_data[0]->q_country_orgin))
	{
	$sql1=$this->db->query("SELECT name FROM country_val where country_id in (".$quotation_data[0]->q_country_orgin.") ");
		$country_orgin=$sql1->result_array();
		foreach($country_orgin as $co)
		{
			$co_vals[]=$co['name'];
		}
	}	

	if(!empty($quotation_data[0]->q_country_final))
	{
	$sql2=$this->db->query("SELECT name FROM country_val where country_id in (".$quotation_data[0]->q_country_final.") ");
		$country_final=$sql2->result_array();	
		foreach($country_final as $cf)
		{
			$cf_vals[]=$cf['name'];
		}
	}

	if(!empty($quotation_data[0]->q_country_loading))
	$country_loading=$this->Admin_model->get_data('country_val',array('country_id'=>$quotation_data[0]->q_country_loading));
	if(!empty($quotation_data[0]->q_country_discharge))
	$country_discharge=$this->Admin_model->get_data('country_val',array('country_id'=>$quotation_data[0]->q_country_discharge));
	if(!empty($quotation_data[0]->q_port_orgin))
	$port_orgin=$this->Admin_model->get_data('country_ports',array('pid'=>$quotation_data[0]->q_port_orgin));
	if(!empty($quotation_data[0]->q_port_final))
	$port_final=$this->Admin_model->get_data('country_ports',array('pid'=>$quotation_data[0]->q_port_final));

	$stylesheet = file_get_contents('style_mpdf.css');

	$html='<!doctype html>
<head></head>
    <body> ';

    $html.='<div class="content">
    <h4 align="center"> PROFORMA INVOICE </h4>
				<table class="prd_info" width="100%">
				<tbody>';
	$html.='<tr>';	
		$html.='<td><b>Exporter</b></td>
		
		<td class="prd_info"><b>المصدر </b></td>
		<td class="prd_info" ><b>Invoice Date<p align="right">التاريخ  </p></b></td>
		<td class="prd_info" colspan="2"><b>Invoice No.<p align="right">رقم الفاتورة  </p></b></td>';	
	$html.='</tr>';		

		$html.='<tr>';	
if($type=="birind")
{
		$html.='<td colspan="2" class="prd_info"><p align="right">بيري للصناعات ش.ذ.م.م  </p>
<p>BIRI INDUSTRIES L.L.C </p>
<p>Al Tourmaline St. Al Hamra Industrial Area </p>
<p>Ras Al khaimah - U.A.E </p>
<p>Tel: +971-7-2447874  , <br/>Fax:+971 7 2447875  </p></td>';
}
else
{
		$html.='<td colspan="2" class="prd_info">
<p>Berry Building Materials Trading LLC </p>
<p>(HO) - Shop 3,Arcade Building  </p>
<p>Al Garhoud - U.A.E </p>
<p>Tel: +971-4-2281144   <br/> Fax:+971 4 2348825  </p>
		 </td>';
}
		$html.='<td colspan="2">
		<table class="prd_info" width="100%">
		<tr>
		<td class="prd_info" >'.$quotation_data[0]->q_inv_date.'</td>
		<td class="prd_info" colspan="2">'.$quotation_data[0]->q_inv_no.'</td>
		</tr>
		</table>

		
		<table class="prd_info" width="100%">
		<tr>
		<td class="prd_info" ><b>Buyer`s Order No. & Date<p>رقم طلب الشراء وتاريخه  </p></b></td>
		<td class="prd_info" ><b>Other Reference (s)<p>أرقام مرجعية أخرى   </p></b></td>
		<td class="prd_info" ><b>Exporter`s Ref.<p>مرجع المصدر   </p></b></td>
		</tr>

	

		<tr>
		<td class="prd_info" > </td>
		<td class="prd_info" > </td>
		<td class="prd_info" > </td>
		</tr>
		</table>

		</td>';	
	$html.='</tr>';	
$html.='</tbody></table>';
	$html.='
	<table width="100%" class="prd_info"><tbody>';
	$html.='<tr>';	
		$html.='<td class="prd_info"><b>Importer </b></td>
		
		<td class="prd_info"><b> المستورد </b></td>
		<td colspan="2"><b>Bank Transfer </b></td> 
		<td align="right"> <b>التحويل البنكي    </b> </td>';	
	$html.='</tr>';
if($quotation_data[0]->proforma_cust_details)
		{
			$c_details=explode('$#$',$quotation_data[0]->proforma_cust_details);
		$c_comp_name=explode(':',$c_details[0]);
    	$c_cust_name=explode(':',$c_details[1]);
        $c_cust_email=explode(':',$c_details[2]);
        $c_cust_mobile=explode(':',$c_details[3]);
    	$c_tel_no=explode(':',$c_details[4]);
        $c_address=explode(':',$c_details[5]);
        $c_cust_country=explode(':',$c_details[6]);
        $c_cust_pin=explode(':',$c_details[7]);
        $c_cust_fax=explode(':',$c_details[8]);

        $c_country_name=$this->Admin_model->get_data('country_val',array('country_id'=>$c_cust_country[1]));
	}

	$html.='<tr>';	
	$html.='<td colspan="2" class="prd_info">'.$c_comp_name[1].
	'<br/>'.$c_cust_name[1].','.$c_address[1].',&nbsp;&nbsp;&nbsp;'.$c_country_name[0]->name.' 
	<br/>P.O.Box :'.$c_cust_pin[1].'<br/>TEL : '.$c_tel_no[1].'<br/>FAX : '.$c_cust_fax[1].'</td>';

if($type=="birind")
{
	$html.='<td colspan="3" class="prd_info">Benificiary : Biri Industries<br/>Bank Name : Abu Dhabi Islamic Bank,Branch : Arenco, DIC - Dubai<br/>A/C No. : 16233984 Swift code: ABDIAEADDUB <br/>IBAN : AE920500000000016233984 <br/>Benificiary Tax NO. 100301351100003 </td>';
}
else
{
	$html.='<td colspan="3" class="prd_info">Benificiary : Berry Building Materials Trading LLC<br/>Bank Name : Abu Dhabi Islamic Bank,Branch : Arenco, DIC - Dubai<br/>A/C No. : 16201796 Swift code: ABDIAEADXXX <br/>IBAN : AE480500000000016201796 <br/>Benificiary Tax NO. 100301351100003 </td>';
}
	$html.='</tr>';	
$html.='</tbody></table>';
	$html.='
	<table width="100%" class="prd_info"><tbody>';
	$html.='<tr>';	
		$html.='<td class="prd_info"><b>Notify Party </b></td>';
		if($quotation_data[0]->q_notify_val=='2')
		{
			$notify_details=explode('$#$',$quotation_data[0]->proforma_notify_cust_details);
		$n_comp_name=explode(':',$notify_details[0]);
    	$n_cust_name=explode(':',$notify_details[1]);
        $n_address=explode(':',$notify_details[2]);
        $n_cust_tel=explode(':',$notify_details[3]);
    	$n_country=explode(':',$notify_details[4]);
        $n_cust_pin=explode(':',$notify_details[5]);
        $n_cust_fax=explode(':',$notify_details[6]);

        $n_country_name=$this->Admin_model->get_data('country_val',array('country_id'=>$n_country[1]));

	$html.='<td colspan="6" class="prd_info">'.$n_comp_name[1].
	'<br/>'.$n_comp_name[1].','.$n_address[1].',&nbsp;&nbsp;&nbsp; '.$n_country_name[0]->name.
	'<br/>P.O.Box :'.$n_cust_pin[1].' <br/>TEL : '.$n_cust_tel[1].'<br/>FAX : '.$n_cust_fax[1].'</td>';
		}
		else
		{
		$html.='<td colspan="6" class="prd_info">Same as Consignee</td>';	
		}
	$html.='</tr>';		
$html.='</tbody></table>';
	$html.='
	<table width="100%" class="prd_info"><tbody>';
	$html.='<tr>';	
		$html.='<td  class="prd_info"><b>Port Of Loading<p align="right">  يميناء التحميل  </p></b></td>
		<td  class="prd_info"><b>DELIVERY CONDITION:<p align="right">  طريقة التسليم  </p></b></td>
		<td class="prd_info" ><b>Other Terms<p align="right"> شروط أخرى   </p></b></td>';	
	$html.='</tr>';	

	$html.='<tr>';	
		$html.='<td  class="prd_info">'.$port_orgin[0]->pname.' &nbsp;&nbsp;&nbsp;  '.$country_loading[0]->name.'</td>
		<td  class="prd_info">'.$quotation_data[0]->q_deliver_condition.'</td>
		<td rowspan="5" class="prd_info"></td>';	
	$html.='</tr>';	

	$html.='<tr>';	
		$html.='<td class="prd_info"><b>Port of Discharge<p align="right"> يميناء التفريغ  </p></b></td>
		<td class="prd_info"><b>Payment Terms:<p align="right"> شروط الدفع  </p></b></td>';	
	$html.='</tr>';	

	$html.='<tr>';	
		$html.='<td class="prd_info">'.$port_final[0]->pname.' &nbsp;&nbsp;&nbsp;  '.$country_discharge[0]->name.'</td>
		<td class="prd_info">'.$quotation_data[0]->q_payment_type.'</td>';	
	$html.='</tr>';	

	$html.='<tr>';	
		$html.='<td class="prd_info"><b>Country of Origin <p align="right">  بلد المنشأ    </p></b></td>
		<td  class="prd_info"><b>Country of Final Destination <p align="right">  بلد المقصد النهائي    </p></b></td>';	
	$html.='</tr>';	

	$html.='<tr>';	
		$html.='<td  class="prd_info">'.implode(',',$co_vals).'</td>
		<td  class="prd_info">'.implode(',',$cf_vals).'</td>';	
	$html.='</tr>';	
$html.='</tbody></table>';
	$html.='
	<table width="100%" class="prd_info"><tbody>';
$html.='<tr>';	
if($quotation_data[0]->q_display_hsc=='2')
		{
		$html.='<td class="prd_info" align="center" colspan="2"><p align="center"><b>تفاصيل البضاعة  <br/>Description of Goods </b></p></td>';
		}
		else
		{
		$html.='<td class="prd_info" align="center"><p align="center"><b>تفاصيل البضاعة  <br/>Description of Goods </b></p></td>';
		}
		$html.='<td class="prd_info" align="center"><p align="center"><b>الوزن  <br/>Weight </b></p></td>';
		if($quotation_data[0]->q_display_hsc=='1')
		{
		$html.='<td class="prd_info" align="center"><p align="center"><b>الوزن  <br/>HSC Code </b></p></td>';
		}
		$html.='<td class="prd_info" align="center"><p align="center"><b>الكمية   <br/>Qty </b></p></td>
		<td class="prd_info" align="center"><p align="center"><b>سعر الوحدة  <br/>Item price </b></p></td>
		<td class="prd_info" align="center"><p align="center"><b> الإجمالي  <br/>Total </b></p></td>';	
	$html.='</tr>';

	$prd_details=explode('|#|',$quotation_data[0]->q_prd_id);
$qty_details=explode('|#|',$quotation_data[0]->q_prd_qnty);
$unt_price_details=explode('|#|',$quotation_data[0]->q_prd_price);
$vat_pre_details=explode('|#|',$quotation_data[0]->q_prd_vat);
$tot_price_details=explode('|#|',$quotation_data[0]->q_prd_tot);

$extra_prd_details=explode('|#|',$quotation_data[0]->q_remarks);
$prd_wgt=explode('|#|',$quotation_data[0]->q_prd_wgt);
$prd_hsc=explode('|#|',$quotation_data[0]->q_prd_hsc);

foreach($prd_details as $index=>$pd)
{
	//print_r($pd);
	
	$prd_table_data[]=$this->tm->get_data('products',array('pid'=>$pd));
	
}
$total_sum_prd='0';
$total_vat_sum_prd='0';
$total_discount_sum_prd='0';
	foreach($prd_table_data as $index=>$pd3)
					{
						//print_r($img_path);
						$pname=explode('|~~|',$pd3[0]->pname);
						if(!empty($pname[0]))
						{
							$prd_names=explode(',',$pname[0]);
							$product_name=$prd_names[0];
							//$product_name=$pname[0];
						}
						else
						{
						 	$pname=explode(',',$pd3[0]->pname);
						 	$product_name=$pname[0];
						}
						//$product_name=$pname;
						
$total_sum_prd=$total_sum_prd+$tot_price_details[$index];

$total_vat_sum_prd=$tot_price_details[$index]+$total_vat_sum_prd;
///////////////here the products listed with foreach ////////
	$html.='<tr>';	
	if($quotation_data[0]->q_display_hsc=='2')
		{
		$html.='<td class="prd_info" align="center" colspan="2">'.$product_name.'<br/>';
		if(!empty($extra_prd_details[$index]))
		$html.='Extra Details: '.$extra_prd_details[$index].'</td>';
		}
	else{
			$html.='<td class="prd_info" align="center">'.$product_name.'<br/>';
		if(!empty($extra_prd_details[$index]))
		$html.='Extra Details: '.$extra_prd_details[$index].'</td>';
		}

		if(!empty($prd_wgt[$index]))
		$html.='<td class="prd_info" align="center">'.$prd_wgt[$index].'</td>';
		else
		$html.='<td class="prd_info" align="center">0</td>';
if($quotation_data[0]->q_display_hsc=='1')
	{
	if(!empty($prd_hsc[$index]))
		$html.='<td class="prd_info" align="center">'.$prd_hsc[$index].'</td>';
		else
		$html.='<td class="prd_info" align="center">0</td>';
	}
		$html.='<td class="prd_info" align="center">'.$qty_details[$index].'</td>
		<td class="prd_info" align="center">'.number_format((float)$unt_price_details[$index], 2, '.', '').'</td>
		<td class="prd_info"  align="center">'.number_format((float)$tot_price_details[$index], 2, '.', '').'</td>';	
	$html.='</tr>';
/////////////end of products listed with foreach ////////
	}
	$dicount_per=$quotation_data[0]->q_discount_per;

if(!empty($quotation_data[0]->q_additional_charge))
	$additional_price=$quotation_data[0]->q_additional_charge;
else
	$additional_price=0;

if(!empty($quotation_data[0]->q_discount_per))
	$dic_price=$quotation_data[0]->q_discount_per;
else
	$dic_price=0;

$total_discount_sum_prd=$total_sum_prd-((($dicount_per/100)*$total_sum_prd));
$net_total=(($quotation_data[0]->q_total_price+$additional_price)-$dic_price);

					// if(!empty($quotation_data[0]->q_discount_per))
					// {
					// $vat_as_per_new_instruction=($net_total*0.05);
					// $grand_total_new_instruction=$net_total+$vat_as_per_new_instruction;
					// }
					// else
					// {
					// $vat_as_per_new_instruction=$quotation_data[0]->q_total_vat;
					// $grand_total_new_instruction=$quotation_data[0]->q_grand_total;
					// }

	$html.='</tbody></table>';
	$html.='
	<table width="100%" class="prd_info"><tbody>
	<tr>';	
		$html.='<td colspan="2">
		<table class="prd_info" width="100%">
		<tr>
		<td>';
 $ar_number_word = number_format((float)$net_total, 2, '.', '');
    $text   = $Arabic->money2str($ar_number_word,$quotation_data[0]->q_currency_type, 'ar');
    
    // echo "<p align=center>$number<br />$text</p>";////not to use////
		$html.='<b>'.$text.'</b></td>
		</tr>
		<tr>
		<td class="prd_info" ><b> Only : '.$this->numbertowordconvertsconver->convert_number($net_total).'</b> </td>
		</tr>
		</table>
		</td>

		<td colspan="2" rowspan="2" class="prd_info" align="center">
		<p><b> القيمة الإجمالية   </b> </p>
			TOTAL AMOUNT 
		</td>
		<td  align="center">'.number_format((float)$net_total, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>';	

	$html.='</tr>';
	$html.='</tbody>
		</table>';

		$html.='<table  width="100%" ><tbody>';


if($quotation_data[0]->show_stamp_proforma=="1")
					{
						if($quotation_data[0]->p_approval_stamp_sign=="2")
						{
					$html.='<tr><td align="right" style="text-align:center;" >';
	if($type=="birind")
	$html.='<img align="right" src="'.base_url('uploads/quot_signature/biri_ind_sig_stmp.jpg').'" width="120" height="120">';
	else
		$html.='<img align="right" src="'.base_url('uploads/quot_signature/berry_bldg_si_stamp.jpg').'" width="120" height="120">';
$html.='</td></tr>';
						}
					}
					$html.='<tr><td align="right"><p align="right">Signature & stamp</p></td></tr>';
$html.='</tbody></table>';
		
		$html.='</div>';
		
	  	$html.='</body>
					</html>';
//echo $html;
	$pdfFilePath = 'proforma_'.$quotation_data[0]->q_ref_no.'.pdf';

	  $mpdf = new \Mpdf\Mpdf();
	   $mpdf->autoScriptToLang = true;
		$mpdf->autoLangToFont = true;
    $mpdf->autoArabic=true;
 
		//  $this->load->library('m2_pdf');

		 if($type=="birind")
		 {
		 	$mpdf->SetHeader('<img src="'.base_url("biri_industries_header.png").'">');
 			$mpdf->SetFooter('<img src="'.base_url("biri_industries_footer.png").'">');
		}
		else
		{
			$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">');
		  	$mpdf->SetFooter('<img src="'.base_url("berry_footer.png").'">');
		}
		  
		
		   $mpdf->WriteHTML($stylesheet,1);
		   $mpdf->AddPage('', // L - landscape, P - portrait 
        '', '', '', '',
        5, // margin_left
        5, // margin right
       38, // margin top
       30, // margin bottom
        0, // margin header
        0); // margin footer
        
  //         //$this->m2_pdf->pdf->SetDirectionality('rtl');
  //       
            
            
	 //     $this->m2_pdf->pdf->WriteHTML($html,2);
	     
	 //     //save in folder
		// $this->m2_pdf->pdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");

  // 		$this->m2_pdf->pdf->Output($pdfFilePath,'I');
//$mpdf->SetDirectionality('rtl');		   
 $mpdf->WriteHTML($html,2);
 $mpdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");
        $mpdf->Output($pdfFilePath,'I');
}


function excel_proforma($qid)
{
	$this->load->library("excel");
  $object = new PHPExcel();
  $object->setActiveSheetIndex(0);
  $quotation_data=$this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$qid));
	//pre_list($quotation_data);
	$sql1=$this->db->query("SELECT name FROM country_val where country_id in (".$quotation_data[0]->q_country_orgin.") ");
		$country_orgin=$sql1->result_array();
		foreach($country_orgin as $co)
		{
			$co_vals[]=$co['name'];
		}
		

	$sql2=$this->db->query("SELECT name FROM country_val where country_id in (".$quotation_data[0]->q_country_final.") ");
		$country_final=$sql2->result_array();	
		foreach($country_final as $cf)
		{
			$cf_vals[]=$cf['name'];
		}

	$country_loading=$this->Admin_model->get_data('country_val',array('country_id'=>$quotation_data[0]->q_country_loading));
	$country_discharge=$this->Admin_model->get_data('country_val',array('country_id'=>$quotation_data[0]->q_country_discharge));
	$port_orgin=$this->Admin_model->get_data('country_ports',array('pid'=>$quotation_data[0]->q_port_orgin));
	$port_final=$this->Admin_model->get_data('country_ports',array('pid'=>$quotation_data[0]->q_port_final));

	//$object->getActiveSheet()->setCellValue('A1', 'Item Code');

         $object->getActiveSheet()->setCellValue('B1', 'Exporter ');
         $object->getActiveSheet()->mergeCells('C1:D1');
         $object->getActiveSheet()->setCellValue('E1', 'لمصدر ');
         //echo $excel_rows;				 
//pre_list($object);
  $object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
  header('Content-Type: application/vnd.ms-excel');
  header('Content-Disposition: attachment;filename="Installation excel.xls"');
  $object_writer->save('php://output');

}








































}