<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Receipt_Master extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
		$this->load->library('numbertowordconvertsconver');	
	}

function create_receipt($cbr_id=null,$type_recpt=null)
{
	if(logged_in())
	{

  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
      $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
          if ((($page_cred[$i]=='create-receipt')||($this ->session->userdata['user']['main_dept'])=="Main"))
          {
            $excist=true;
               $i=$cred_count;
          } 

            else
              {$excist=false;}

         }
       if ($excist) {


		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'create-receipt'));
		$salesman=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales', 'log_status !='=>'0'));
		foreach($salesman as $s)
		{
			$data['salesman'][]=$this->Admin_model->get_data('employee_details',array('ed_login_id'=>$s->log_id));
		}
		//$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent IN  (638,490)");
		////TO GET OPERATING EXPENSE A/C NAMES AND CUSTOMER A/C NAMES COMBINED
		$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent IN  (638,620,630,492,596,786,639,640,641,852,1143,245,490,592,604,35,22,674,482)");
			$data['customers']=$sql_cust->result_array();                                
		$data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
		$sql2=$this->db->query("SELECT *
FROM master_accounts_tree
WHERE parent = 700
UNION
SELECT * 
FROM master_accounts_tree
WHERE parent IN 
    (SELECT id FROM master_accounts_tree WHERE parent = 700)");
		$data_result_set1=$sql2->result_array();
	//	pre_list($dtt); 
		 	foreach($data_result_set1 as $ds2)
		 	{
		 		//pre_list($ds2['id']);
		 		$data['cash_bank'][]=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>$ds2['id']));
			}
			//unset($data['cash_bank'][0]);
		//	pre_list($data['cash_bank']);
		if(empty($cbr_id))
		{
			$val_recipt=$this->Admin_model->get_data('cash_bank_receipt',array('cbr_sts'=>'1'),'','','cbr_id','DESC');
			if(empty($val_recipt))
			$data['doc_num']='RTC 1200';
				else
				{                                                     
				$bal_string1=str_replace("RTC ", "", $val_recipt[0]->cbr_doc_no);
				//print_r($bal_string1);
			        $new_id_1=($bal_string1)+1;
			        $data['doc_num']="RTC ".$new_id_1;
				}
		}
		else////  
		{
			
			if(!empty($type_recpt))
			{
				if($type_recpt=="convert_receipt")
				{
					///////get document number/////////
					$val_recipt=$this->Admin_model->get_data('cash_bank_receipt',array('cbr_sts'=>'1'),'','','cbr_id','DESC');
			
				if(empty($val_recipt))
				$data['doc_num']='RTC 1200';
				else
				{
				$bal_string1=str_replace("RTC ", "", $val_recipt[0]->cbr_doc_no);
				//print_r($bal_string1);
			           $new_id_1=($bal_string1)+1;
			            $data['doc_num']="RTC ".$new_id_1;
				}
				///////get document number/////////
				
				$data['pdr_result']=$this->Admin_model->get_data('cash_bank_pdr',array('cbr_id'=>$cbr_id));

			
				$data['result_ac_tx']=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_type_tx'=>'PDR'));

				}
			}
			else
			{
				$data['result']=$this->Admin_model->get_data('cash_bank_receipt',array('cbr_id'=>$cbr_id));
				$data['result_ac_tx']=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_type_tx'=>'Receipt'));
				foreach($data['result_ac_tx'] as $ind=>$tx_amnt)
				{
					//pre_list($tx_amnt);
					$data['bal_data_tx'][]=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$tx_amnt->atx_id));
				}
	
				foreach($data['bal_data_tx'] as $ind1=>$bal)
				{
					//pre_list($bal);
					foreach($bal as $ind2=>$b2)
					{
						$data['bal_data_tx_refs'][$ind1][]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$b2->actb_to_id));
						
					}
				}
			}
		}
            
      $this->load->view('admin/cash_bank/create_receipt',$data);


	}

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


	}
	//pre_list($data['bal_data_tx_refs']);
	//pre_list($data['pdr_result']);pre_list($data['result_ac_tx']);

}

function list_receipt()
{
	if(logged_in())
	{


           $another_condition = '';
	         $sort_by = '';
			if(!empty($this->input->post('sortBy')))
			{
				$sort_by = $this->input->post('sortBy');
				if($sort_by == 'approved')
				{
					$another_condition = "and cbr.cbr_current_status='" . 'approved' . "' ";
				}
				elseif($sort_by == 'not-converted')
				{
					$another_condition = "and cbr.cbr_current_status='" . 'not-converted' . "' ";
				}
				else{
					$another_condition = "and cbr.cbr_current_status='" . 'deleted' . "' ";
				}
				
			}





		  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-receipt')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

	  $data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'list-receipt'));
	  $sql2=$this->db->query("SELECT cbr.*,mc.mcomp_name,mat.label
       FROM cash_bank_receipt as cbr join master_company as mc on mc.mcomp_id=cbr.cbr_company join master_accounts_tree as mat on mat.id=cbr.cbr_acc 
       WHERE  cbr.cbr_current_status<>'deleted' and  cbr.cbr_sts = '1' order by cbr.cbr_id DESC");
	  $data['result']=$sql2->result_array();
	  $data['sort_by'] = $sort_by;
	  $this->load->view('admin/cash_bank/list_receipt',$data);	

	}

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 
	}
}

function get_details_salesman()
{
	$login_salesman=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales', 'log_status !='=>'0'));
		foreach($login_salesman as $s)
		{
			$salesman[]=$this->Admin_model->get_data('employee_details',array('ed_login_id'=>$s->log_id));
		}

		$table_id=$this->input->post('table_id');
		$html='<select data-plugin-selectTwo  class="form-control populate salesman_'.$table_id.'" name="cbr_salesman[]"  ><option >Choose</option>';
		foreach($salesman as $sm)
		{
			if(!empty($sm[0]->ed_name))
        	{
        $html.="<option value=".$sm[0]->ed_id.">".strtolower($sm[0]->ed_name)."</option>";
        	} 
		}
		$html.='</select>';
	echo $html;	
}

function get_details_customer_acc()
{
		$table_id=$this->input->post('table_id');
	
	$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent IN  (638,490)");////TO GET OPERATING EXPENSE A/C NAMES AND CUSTOMER A/C NAMES COMBINED
			$customers=$sql_cust->result_array();
	$html='<select data-plugin-selectTwo  class="form-control populate cust_acc_'.$table_id.' cust'.$table_id.'" name="cbr_customer_acc[]"  onchange="get_cust_details('.$table_id.')"><option value="">Choose</option>';
	foreach($customers as $cu)
	{
	$html.="<option value=".$cu['id'].">".strtolower($cu['label'])."</option>";
	}
$html.='</select>';
	echo $html; 
}

function get_currency_conv_val()
{
	$currecny_id=$this->input->post('currecny_selected');
$result=$this->Admin_model->get_data('master_currency_conv',array('currency_name'=>$currecny_id));
echo $result[0]->currency_val;
}

function submit_receipt()
{
	$page_type=$this->input->post('page_type');

		
	$edited_id=$this->input->post('added_cbr_id');
	
	$created_pdr_id=$this->input->post('created_pdr_id');
	$recpt_type=$this->input->post('recipt_type');////////checking if this is a pdr convertion to recipt//////

 



	/////for upload files//////
$image = array();
	$uploadImgData = array();

  $ImageCount = count($_FILES['files']['name']);
 
        for($i = 0; $i < $ImageCount; $i++)
        {     
            $_FILES['file']['name']       = $_FILES['files']['name'][$i];
            $_FILES['file']['type']       = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['files']['error'][$i];
            $_FILES['file']['size']       = $_FILES['files']['size'][$i];

            // File upload configuration
            $uploadPath = 'uploads/receipt_files/';
         $config['file_name'] = time() .preg_replace("/[^a-z0-9\_\-\.]/i", '', basename($_FILES["files"]["name"][$i]));
            $config['upload_path'] = $uploadPath;
            //$config['max_size'] = '3000000';////3mb
            $config['allowed_types'] = '*';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'business_card');
            $this->business_card->initialize($config);

            // Upload file to server
            if($this->business_card->do_upload('file'))
            {
              // Uploaded file data
                $imageData = $this->business_card->data();
              
                $uploadImgData[]=$imageData['file_name'];
              
                if(!empty($uploadImgData))
                {
              		$data_image=implode(',',$uploadImgData);
              	}
              	else
              	{
              		 $data_image='';
    			}	
                //print_r($uploadImgData);
            } 
            else
            {
           	 if(!empty($this->input->post('files_added')))
        		{
        		$data_image=$this->input->post('files_added');
				}
            		else
           		{
            		$data_image='';
    			}
            }      
        }
  
////end of for upload files//////////

        $main_date=$this->input->post('hid_date');
$main_date1=explode('/',$main_date);
			$month1=$main_date1[0];
			$date1=$main_date1[1];
			$year1=$main_date1[2];
$new_formated_date1=$year1.'-'.$month1.'-'.$date1;

 $main_due_date=$this->input->post('cbr_date');
$main_due_date1=explode('/',$main_due_date);
			$month2=$main_due_date1[0];
			$date2=$main_due_date1[1];
			$year2=$main_due_date1[2];
$new_formated_date2=$year2.'-'.$month2.'-'.$date2;
	
	
		$data['cbr_doc_no']=$this->input->post('cbr_doc_no');
	//$data['cbr_date']=$new_formated_date1;

		$data['cbr_due_date']=$new_formated_date2;
		$data['cbr_acc']=$this->input->post('cbr_acc');
		$data['cbr_company']=$this->input->post('cbr_company');
		$data['cbr_cheque_no']=$this->input->post('cbr_cheque_no');
		$data['cbr_pdc_id']=$this->input->post('created_pdr_id');
		$data['cbr_pdc_no']=$this->input->post('cbr_pdc_no');
		$data['cbr_currency']=$this->input->post('cbr_currency');
		$data['cbr_rate_currency']=$this->input->post('cbr_rate_currency');
		$data['cbr_bill_no']=$this->input->post('cbr_bill_no');
		$data['cbr_attachments']=$data_image;
		$data['cbr_salesman']=$this->input->post('hid_salesman');
		$data['cbr_customer_acc']=$this->input->post('hid_customer');
		$data['cbr_amount']=$this->input->post('hid_amounts');
		$data['cbr_ref']=$this->input->post('hid_ref');
		$data['cbr_remark']=$this->input->post('hid_remark');
		$data['cbr_tot_amount']=$this->input->post('cbr_tot_amount');
		$data['cbr_sts']='1';
		
		$data['cbr_dt_updt']=get_date_time();
		$data['cbr_narration']=$this->input->post('cbr_narration');

        	//  print_r($recpt_type);
            // exit(0);
           
if(empty($edited_id))////willl insert
	{
		$document_bal_number=str_replace("RTC ", "", $this->input->post('cbr_doc_no'));
         	
		$data['cbr_doc_number']=$document_bal_number;
	}
	$salesman_vlues=explode('|#|', $this->input->post('hid_salesman'));
	$customer_account=explode('|#|',$this->input->post('hid_customer'));
	$customer_amounts=explode('|#|',$this->input->post('hid_amounts'));
	$customer_remark=explode('|#|',$this->input->post('hid_remark'));
	$customer_refs=array_filter(explode('|#|',$this->input->post('hid_ref')));

	//$sales_inv_cust_id=array_filter(explode('|#|',$this->input->post('sales_inv_cust_id')));
	$sales_inv_id=array_filter(explode('|#|',$this->input->post('sales_inv_id')));
	$sales_inv_amount=array_filter(explode('|#|',$this->input->post('sales_inv_amount')));
	$sales_inv_amount_paid=array_filter(explode('|#|',$this->input->post('sales_inv_amount_paid')));
	$sales_doc_num=array_filter(explode('|#|',$this->input->post('sales_doc_num')));
	$tot_inv_amount_paid_from_ref=array_sum($sales_inv_amount_paid);

// pre_list($customer_amounts);
// pre_list($customer_account);

// pre_list($sales_inv_id);
// pre_list($sales_inv_amount);
// pre_list($sales_inv_amount_paid);
// pre_list($sales_doc_num);

	if(empty($edited_id))////willl insert
	{
// echo "inserting here";echo "<br/>";
// print_r($data);echo "<br/>";
	$insert_id=$this->Admin_model->insert_data('cash_bank_receipt',$data);
	//$insert_id='12';
		if(!empty($insert_id))
		{
$this->Admin_model->update_data('cash_bank_receipt',array('cbr_insert_date'=>date('Y-m-d'),'cbr_dt_crtd'=>get_date_time(),'cbr_date'=>$new_formated_date1,'cbr_current_status'=>'approved','cbr_created_by'=>$this->session->userdata['user']['username']),array('cbr_id'=>$insert_id) );
		
		foreach($customer_account as $index=>$c_acc)
		{
//pre_list($insert_id_acc_tx);
//$insert_id_acc_tx=array('22','23','24');
			  if(!empty($created_pdr_id))///updating 
			  {
			  	$data_pdr=array(
			  		'cbr_receipt_id'=>$insert_id,
			  		'cbr_receipt_no'=>$this->input->post('cbr_doc_no'),
			  		'cbr_converted_status'=>'converted',
			  		'cbr_dt_updt'=>get_date_time(),
			  	);
			  	//echo "<br/>";
			  	//print_r($data_pdr);echo "<br/>";echo "inside updating pdr";echo "<br/>";
			 	$this->Admin_model->update_data('cash_bank_pdr',$data_pdr,array('cbr_id'=>$created_pdr_id));
			  }
		}
$cbr_doc_num=$this->input->post('cbr_doc_no');
			  ///check for sales invoice related data////		
		$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'receipt created',
				'act_status'=>'receipt id '.$insert_id.' created,also added to account_master_trasaction table',
				'act_doc_num'=>$cbr_doc_num,
				'act_receipt_id'=>$insert_id,
				'act_type_id'=>$insert_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
				'act_type'=>'Receipt'
			);
		$this->Admin_model->insert_data('activities',$activity_data);
		$this->session->set_flashdata('success', 'Data Successfully inserted');
		}
	}
	else////will updATE(do the edit of invoices -> sales in edit, pending)
	{
		//echo "else-updating";
		$this->Admin_model->update_data('cash_bank_receipt',$data,array('cbr_id'=>$edited_id) );

		$current_recpt_amount=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$edited_id,'atx_doc_no'=>$this->input->post('cbr_doc_no'),'atx_type_tx'=>'Receipt'));

		if(!empty($current_recpt_amount))
			{
				foreach($current_recpt_amount as $index=>$cra)
				{
					$cust_id_array[]=$cra->atx_cust_id;
					$tx_id_array[]=$cra->atx_id;
					$cust_tx_amount_array[]=$cra->atx_tot_amount;
					$cust_tx_bal_amount_array[]=$cra->atx_bal_amount;
					$current_sales_bal_amount[$index][]=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$cra->atx_id));
					
					if(!empty($current_sales_bal_amount))
					{
						foreach($current_sales_bal_amount[$index] as $index2=>$csb)
						{
							//pre_list($csb);
							$acc_tx_details_2=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$csb[0]->actb_to_id));

							$current_paid_amount=$acc_tx_details_2[0]->atx_paid_amount;
							$current_bal_amount=$acc_tx_details_2[0]->atx_bal_amount;
							$new_paid_amount=$current_paid_amount-$csb[0]->actb_paid_amount;
							$new_bal_amount=$current_bal_amount+$csb[0]->actb_paid_amount;
							$array_new_data=array(
						'atx_paid_amount'=>$new_paid_amount,
						'atx_bal_amount'=>$new_bal_amount,
						'atx_date'=>$new_formated_date1,
					);
							//print_r($array_new_data);
					$this->Admin_model->update_data('account_all_tx',$array_new_data,array('atx_id'=>$csb[0]->actb_to_id));
					$this->Admin_model->delete_data('account_tx_bal_data',array('actb_tx_id'=>$csb[0]->actb_tx_id));
						}	
					}
				}
			
 			}
 			
	$cbr_doc_num=$this->input->post('cbr_doc_no');
			  ///check for sales invoice related data////		
		$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'receipt created',
				'act_status'=>'receipt id '.$insert_id.' created,also added to account_master_trasaction table',
				'act_doc_num'=>$cbr_doc_num,
				'act_receipt_id'=>$insert_id,
				'act_type_id'=>$insert_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
				'act_type'=>'Receipt'
			);
	   	$this->Admin_model->insert_data('activities',$activity_data);
		 $this->session->set_flashdata('success', 'Data Successfully updated');		
	}
	
	/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////	
	if(!empty($insert_id) || !empty($edited_id) )
		{//echo "string";echo "<br/>";
	//echo $recpt_type;
			if(!empty($insert_id))
			{
				$rect_id_inv_id=$insert_id;
			}
			elseif (!empty($edited_id)) 
			{
				$rect_id_inv_id=$edited_id;
			}
			else
			{
				$rect_id_inv_id='';
			}
		
		if(!empty($rect_id_inv_id))
		{  
			
		if(empty($recpt_type))////////do this opr when its a not a pdr////////////////////
			{
		foreach($customer_account as $index=>$c_acc)
			{		
				$data_tx['atx_user_created']=$this->session->userdata['user']['username'];
				$data_tx['atx_type_tx']='Receipt';
				$data_tx['atx_date']=$new_formated_date1;
				$data_tx['atx_doc_no']=$this->input->post('cbr_doc_no');
				$data_tx['atx_main_id']=$rect_id_inv_id;
				$data_tx['atx_acc_id']=$this->input->post('cbr_acc');
				$data_tx['atx_cust_id']=$c_acc;
				$data_tx['atx_tot_amount']=$customer_amounts[$index];
				if(empty($edited_id))	
				$data_tx['atx_paid_amount']='0';

				$data_tx['atx_dt_updt']=get_date_time();
				$data_tx['atx_sts']='1';
				$data_tx['atx_amount_type']='Expense';
				$data_tx['atx_region']=$page_type;
					$data_tx['atx_narration']=$this->input->post('cbr_narration');
					$data_tx['atx_salesman']=$salesman_vlues[$index];
					$data_tx['atx_bill_no']=$this->input->post('cbr_bill_no');
					$data_tx['atx_cheque_no']=$this->input->post('cbr_cheque_no');
					$data_tx['atx_currency_value']=$this->input->post('cbr_rate_currency');
					$data_tx['atx_currency_type']=$this->input->post('cbr_currency');

///////////////here logic to update the same table, for recipt, with the amount paid for referecnes(not include any new-ref here)//  
			if(!empty($sales_inv_amount_paid[$index]))
							{
							$sales_inv_amount_total=explode('|$$|',$sales_inv_amount_paid[$index]);
							if(!empty(array_sum($sales_inv_amount_total)))
								{
									//echo "inside last if";echo "<br/>";
									$data_final_bal_amount=$customer_amounts[$index]-array_sum($sales_inv_amount_total);
									//print_r($data_final_bal_amount);echo "<br/>";print_r(array_sum($sales_inv_amount_total));
									
									$data_tx['atx_bal_amount']=$data_final_bal_amount;
									$data_tx['atx_paid_amount']=array_sum($sales_inv_amount_total);
								}
								else
								{
									$data_tx['atx_bal_amount']=$customer_amounts[$index];
									$data_tx['atx_paid_amount']='0';
								}
							}
							else
							{
								$data_tx['atx_bal_amount']=$customer_amounts[$index];
								$data_tx['atx_paid_amount']='0';
							}	

			if(!empty($edited_id))	
				{
					///////////////here logic to update the same table, for recipt, with the amount paid for referecnes(not include any new-ref here)//  
				if(in_array($c_acc, $cust_id_array))
					{
						$insert_id_acc_tx[]=$current_recpt_amount[$index]->atx_id;
			$this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_id'=>$current_recpt_amount[$index]->atx_id));
						//print_r($insert_id_acc_tx);
					}
					else
					{
						//echo "in else 2";
						$insert_id_acc_tx[]=$this->Admin_model->insert_data('account_all_tx',$data_tx);
						//print_r($insert_id_acc_tx);
					}
				}
				else
				{
					//echo "in else 3";
					$insert_id_acc_tx[]=$this->Admin_model->insert_data('account_all_tx',$data_tx);
					//echo "<br/>";
				}
			}
			/////the foreach of cusotmer acc ends here//////////////

			foreach($sales_inv_id as $index=>$si)
			{
				// print_r($index);	echo "<br/>";	
				// print_r($insert_id_acc_tx[$index]);	
				$sales_inv_id_extra=explode('|$$|',$si);
				$sales_inv_amount_extra=explode('|$$|',$sales_inv_amount[$index]);
				$sales_inv_amount_paid_extra=explode('|$$|',$sales_inv_amount_paid[$index]);
				$sales_inv_doc_num_extra=explode('|$$|',$sales_doc_num[$index]);

			if(!empty($sales_inv_amount_paid[$index]))
				{
					// echo "inside ssales invoice amount paid";echo "<br/>";
					// print_r($sales_inv_id_extra);
				foreach($sales_inv_id_extra as $index2=>$si2)
					{
						//print_r($si2);
						if(!empty($sales_inv_amount_paid_extra[$index2]))
						{
							$amount_paid_till_now=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$si2));
							$total_paid_amount_from_another_ref[]=$sales_inv_amount_paid_extra[$index2];
				  			$bal_amount_sales_inv=$sales_inv_amount_extra[$index2]-$sales_inv_amount_paid_extra[$index2];///this for invoice table
				  		
				  		$data_si_array=array(
				  			'atx_paid_amount'=>$amount_paid_till_now[0]->atx_paid_amount+$sales_inv_amount_paid_extra[$index2],
				  			'atx_bal_amount'=>$bal_amount_sales_inv,
				  		);
					
					//pre_list($data_si_array);
					$this->Admin_model->update_data('account_all_tx',$data_si_array,array('atx_id'=>$si2));
				$data_tx_bal=array(
						'actb_tx_id'=>$insert_id_acc_tx[$index],
						'actb_to_type'=>$sales_inv_doc_num_extra[$index2],
						'actb_paid_amount'=>$sales_inv_amount_paid_extra[$index2],
						'actb_to_id'=>$si2,
						'actd_sts'=>'1',
						'actb_user_created'=>$this->session->userdata['user']['username'],
					);	
				//pre_list($data_tx_bal);
				$this->Admin_model->insert_data('account_tx_bal_data',$data_tx_bal);
				  		}
				  	}
				}
			} 
			/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////	
			}////////skipping this opr when its a converted pdr////////////////////
			else
			{  
				//echo "skipping all the abv steps to chnage only the a/c data table";
				$all_account_data_tx=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$created_pdr_id,'atx_type_tx'=>'PDR'));
				foreach($all_account_data_tx as $ind=>$act)
				{
					$data_to_update_pdr=array
					(
						'atx_type_tx'=>'Receipt',
						'atx_doc_no'=>$this->input->post('cbr_doc_no'),
						'atx_main_id'=>$rect_id_inv_id,
					);
					$this->Admin_model->update_data('account_all_tx',$data_to_update_pdr,array('atx_id'=>$act->atx_id));
				}
			}

		redirect('list-receipt');
		}
		else
		{
		 $this->session->set_flashdata('errors', 'Error on data found. Please try again.');
		redirect('list-receipt');
		}	
		
	}
}


function delete_receipt($cbr_id)
{
	if(logged_in())
	{
		$cash_bank_details=$this->Admin_model->get_data('cash_bank_receipt',array('cbr_id'=>$cbr_id));


     foreach ($cash_bank_details as $key) {
     $cbr_doc_num=$key->cbr_doc_no;
     }

    
		$acc_tx_details=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_doc_no'=>$cbr_doc_num,'atx_sts'=>'1'));
          $pdr_related_num=$cbr_doc_num;
	   	$Reason_of_delete=$this->input->post('reason-of-delete');
		   	
		  //$Reason_of_delete= $this->session->set_flashdata('reason-of-delete', form_error('reason-of-delete'));
		

		if(!empty($acc_tx_details))

		{
			foreach($acc_tx_details as $index=>$actx)
			{
				$acc_bal_tx=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$actx->atx_id,'actd_sts'=>'1'));
				
			if(!empty($acc_bal_tx))
			{
				
				foreach($acc_bal_tx as $index2=>$acb)
				{
					

					// if(!empty($acb))
				//  { 
							//$acbtoid=$acb[$index]->actb_to_id;
					
					//  	print_r($acb);
					// exit(0);
					$acc_tx_details_2=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$acb->actb_to_id));
				
					$current_paid_amount=$acc_tx_details_2[0]->atx_paid_amount;
								
					$current_bal_amount=$acc_tx_details_2[0]->atx_bal_amount;
					
					$new_paid_amount=$current_paid_amount-$acb->actb_paid_amount;
					 
					$new_bal_amount=$current_bal_amount+$acb->actb_paid_amount;
					
					$array_new_data=array(
						'atx_paid_amount'=>$new_paid_amount,
						'atx_bal_amount'=>$new_bal_amount,
					);


			
					$this->Admin_model->update_data('account_all_tx',$array_new_data,array('atx_id'=>$acb->actb_to_id));
					$this->Admin_model->update_data('account_tx_bal_data',array('actd_sts'=>'0'),array('actb_to_id'=>$acb->actb_to_id));
				  $this->Admin_model->update_data('account_tx_bal_data',array('actd_sts'=>'0'),array('actb_tx_id'=>$acb->actb_tx_id));
					// }
                    
					}	
					
				}	
				 
				 		
			}
		}
	 $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_main_id'=>$cbr_id,'atx_doc_no'=>$cbr_doc_num));
	 	
     if(!empty($pdr_related_num))
		 {  

			
             $this->Admin_model->update_data('cash_bank_pdr',array('cbr_current_status'=>'deleted','cbr_attachments'=>$Reason_of_delete),array('cbr_doc_no'=>$pdr_related_num));
			 $this->Admin_model->update_data('cash_bank_receipt',array('cbr_current_status'=>'deleted','cbr_attachments'=>$Reason_of_delete),array('cbr_id'=>$cbr_id));

		 }
		 else{
                 $this->Admin_model->update_data('cash_bank_receipt',array('cbr_current_status'=>'deleted','cbr_attachments'=>$Reason_of_delete),array('cbr_id'=>$cbr_id));
		 }

		

		
        


	
		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'receipt deleted',
			'act_status'=>'receipt id '.$cbr_id.' deleted',
			'act_doc_num'=>$cbr_doc_num,
			'act_receipt_id'=>$cbr_id,
			'act_type_id'=>$cbr_id,
			'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
				'act_type'=>'Receipt'
		);
		  $this->Admin_model->insert_data('activities',$activity_data);

		  $this->session->set_flashdata('success', 'Data Successfully deleted');
	redirect('list-receipt');
	}
}

function get_cust_sales_inv()
{	
	$cust_id=$this->input->post('cust_id');
	$table_id=$this->input->post('table_id');
	$account_id=$this->input->post('ac_tx_id');/////////used or will get at the time of edit function///////////// 
	//pre_list($account_id);
	$cust_paid_amount=$this->input->post('cust_amount_paid');

// print_r($cust_paid_amount);
// exit(0);


	if(!empty($account_id))
	{	
	$account_tx_details=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$account_id,'atx_sts'=>'1'));
	$acc_tx_bal_data=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_details[0]->atx_id,'actd_sts'=>'1'));
///pre_list($acc_tx_bal_data);
		foreach($acc_tx_bal_data as $to_id)
		{
			$to_id_details[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$to_id->actb_to_id,'atx_sts'=>'1'));
		}
	$cust_id=$account_tx_details[0]->atx_cust_id;
	}
	//pre_list($to_id_details);
	$sql2=$this->db->query("SELECT * FROM account_all_tx where atx_cust_id=".$cust_id." and atx_type_tx IN ('Payments','Petty_Cash','PDP','Sales_Invoice','JRN_Debit','Sales_Return') and atx_bal_amount!='0' and atx_sts='1' ");
	$cust_sales=$sql2->result_array();

	$ij=1;$kl=551;
		$html="
		<div class='row'>
		<div class='col-md-12'>
		<div class='col-md-10'>
		<span class='pull-left'>";
		if(!empty($account_id))
		{	
		if(empty($acc_tx_bal_data))
			{
				$tot_amount_ref=$account_tx_details[0]->atx_tot_amount;
			}
			elseif(!empty($account_tx_details[0]->atx_bal_amount))
			{
				$tot_amount_ref=$account_tx_details[0]->atx_bal_amount;
			}
			else
			{
				$tot_amount_ref='0';
			}
		}
		else
		{
			$tot_amount_ref='0';
		}
		//print_r($tot_amount_ref);
$html.="<input type='text' class='refrence_amount_".$table_id."' value='".$tot_amount_ref."' name='refrence'>";
		$html.="<br/><p>Add as new reference </p></span><br/>
		
		<table class='table table-striped table-bordered table-sm' id='datatable-default2'>";
			$html.="<thead>";
			$html.="<th></th>";
			$html.="<th>Reference</th>";
			$html.="<th>Bill Amount</th>";
			$html.="<th>Amount Adjusted</th>";
			// $html.="<th>Balance Amount</th>";
			$html.="</thead>";
			$html.="<tbody>";
	if(!empty($account_id))
	{	
		foreach($to_id_details as $tid)
		{
			//pre_list($tid);
			$array_atx_id[]=$tid[0]->atx_id;
			//pre_list($tid[0]->atx_id);
		$html.="<tr>";
		$html.="<td><input name='cust_id_modal' type='hidden' value='".$tid[0]->atx_cust_id."'>";

		$html.="<input type='checkbox' class='class_checkbox inv_selected_".$kl."' checked='checked' onchange='pass_param_2(event.target,".$kl.")' value='".$tid[0]->atx_doc_no."' name='inv_selected[]'>";
		$html.="<input name='table_id_modal' type='hidden' value='".$table_id."'>
		</td>";
			$html.="<td><input name='inv_id_modal[]' type='hidden' value='".$tid[0]->atx_id."'><input name='inv_doc_numbers_modal[]' class='ref_doc_numbers_".$kl."' type='hidden' value='".$tid[0]->atx_doc_no."'>".$tid[0]->atx_doc_no."</td>";

				if(empty($tid[0]->atx_bal_amount))
				{
					if($tid[0]->atx_type_tx=="Sales_Invoice" )
					{
						$tot_amount_to_show=round($tid[0]->atx_tot_amount);//


					}
					else
					{
						if(!empty($tid[0]->atx_vat_amount))
						$tot_amount_to_show=round($tid[0]->atx_tot_amount+$tid[0]->atx_vat_amount);/////take total amount with vat(if present), else take the tot-amount only///

						else
						$tot_amount_to_show=round($tid[0]->atx_tot_amount+0);
					}
					
				}
				else
				{
					$tot_amount_to_show=round($tid[0]->atx_bal_amount);
				
				}
			//pre_list($tot_amount_to_show);

			$html.="<td><input name='sales_inv_amount_modal[]' type='number' step='any' value='".round($tot_amount_to_show)."' readonly='' class='tot_sales_amount_".$kl." org_amounts'><br/>
			<p>Total Amount:".round($tid[0]->atx_tot_amount)."</p>
			</td>";
			
			$html.="<td><input name='paid_amount_modal[]' type='number' step='any' value='".$acc_tx_bal_data[0]->actb_paid_amount."' min='0' max='".$acc_tx_bal_data[0]->actb_paid_amount."' onchange='check_val_less_than_amount(".$kl.");' class='tot_sales_amount_paid_".$kl."'><br/>";	
			
		
			$html.="<br/><small class='amount_overdue_".$kl." text_data_issue' style='color:red;'></small>
			</td>";
			// $html.="<td>
			// <input name='sales_inv_bal_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_bal_amount_".$ij."'>
			// </td>";
			$html.="</tr>"; 
			$kl++;
		}
	}	
	if(!empty($cust_sales))
	{
//echo "else in cust sales ";
		foreach($cust_sales as $index=>$civ)
		{
			if(!empty($account_id))
			{
				if(in_array($civ['atx_id'],$array_atx_id))
				{
					unset($cust_sales[$index]);
					//$new_array_cust_sales[]=$cust_sales[$index];
				}
				else
				{
					$new_array_cust_sales[]=$cust_sales[$index];
				}
			}
			else
			{
				$new_array_cust_sales[]=$cust_sales[$index];
			}
		}
	if(!empty($new_array_cust_sales))
	{
		foreach($new_array_cust_sales as $index=>$civ)
		{		//pre_list($civ);
			$html.="<tr>";
		$html.="<td><input name='cust_id_modal' type='hidden' value='".$cust_id."'>
		<input type='checkbox' class='class_checkbox inv_selected_".$ij."' onchange='pass_param_2(event.target,".$ij.")' value='".$ij."' name='inv_selected[]'>
		<input name='table_id_modal' type='hidden' value='".$table_id."'>
		</td>";
			$html.="<td><input name='inv_id_modal[]' type='hidden' value='".$civ['atx_id']."'><input name='inv_doc_numbers_modal[]' class='ref_doc_numbers_".$ij."' type='hidden' value='".$civ['atx_doc_no']."'>".$civ['atx_doc_no']."</td>";

			if(empty($civ['atx_paid_amount']))
			{
				if($civ['atx_type_tx']=="Sales_Invoice")
					{
						$tot_amount_to_show=$civ['atx_tot_amount'];
					}
					else
					{
						if(!empty($civ['atx_vat_amount']))
						$tot_amount_to_show=$civ['atx_tot_amount']+$civ['atx_vat_amount'];/////take total amount with vat(if present), else take the tot-amount only///
						else
						$tot_amount_to_show=$civ['atx_tot_amount']+0;
					}
			}
			else
			{
				$tot_amount_to_show=$civ['atx_bal_amount'];
			}

			$html.="<td><input name='sales_inv_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_amount_".$ij." org_amounts'><br/>
			<p>Total Amount:".$civ['atx_tot_amount']."</p>
			</td>";
			
			$html.="<td><input name='paid_amount_modal[]' type='number' step='any' value='0' min='0' max='".$tot_amount_to_show."' onchange='check_val_less_than_amount(".$ij.");' class='tot_sales_amount_paid_".$ij."'><br/>
		
			<br/><small class='amount_overdue_".$ij." text_data_issue' style='color:red;'></small>
			</td>";
			// $html.="<td>
			// <input name='sales_inv_bal_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_bal_amount_".$ij."'>
			// </td>";
		
			$html.="</tr>"; 
			$ij++;
		}
	}
		}	
		$html.="</tbody>";
			
			$html.="</table>";
			

			
				// print_r($ij);
				// //print_r($kl);
				// exit(0);
		
			$html.="</div>		
<div class='col-md-2'>
<button class='btn btn-primary pull-right get_pick_amount' onclick='get_pick_amount(".$table_id.");'>Pick Amount</button>
</div>
</div>
<div class='col-md-12'>
	<div class='col-md-4'>";
	if(!empty($cust_paid_amount))
	$html.="<p> Amount to adjust:<span class='amount_to_adj'>".$cust_paid_amount."</span></p>";
	else
	$html.="<p> Amount to adjust:<span class='amount_to_adj'>0</span></p>";
	$html.="</div>";
	if(!empty($account_id))
	{
		$amount_adjsted=round($account_tx_details[0]->atx_paid_amount);		
	}
	else
	{
		$amount_adjsted='0';
	}
	$html.="<div class='col-md-4'>
	<p> Amount adjusted:<span class='amount_adjusted'>".$amount_adjsted."</span></p>
	</div>";
	
	$html.="<div class='col-md-4'>
	<p>To be adjusted:<span class='to_be_adjust'>0</span></p>
	</div>";

	$html.="<div class='col-md-12'>
	<p><button class='btn btn-danger' type='button' onclick='reset_fields()'>Reset Fields</button></p>
	</div>";

$html.="</div>
		</div>";

///// this code we will use if we need all the row in one table   ///// wael //
$html.="

<script>
$(document).ready(function() {
    var table = $('#datatable-default2').dataTable( {
        scrollY:1000,
        paging: false
    });
  
});
</script>

";

			echo $html;		
}
function create_receipt_for_cutomer($recipt_id, $cutomer_id, $index_val = null)
	{
		if (logged_in()) {
			if (!empty($recipt_id) && !empty($cutomer_id)) {
				$data['recpt_data'] = $this->Admin_model->get_data('cash_bank_receipt', array('cbr_id' => $recipt_id));
				$company_id = $data['recpt_data'][0]->cbr_company;
				$company_details = $this->Admin_model->get_data('master_company', array('mcomp_id' => $company_id));
				$data['amount'] = explode('|#|', $data['recpt_data'][0]->cbr_amount);
				$data['remarks'] = explode('|#|', $data['recpt_data'][0]->cbr_remark);
				$data['reference'] = explode('|#|', $data['recpt_data'][0]->cbr_ref);

				$data['index_val'] = $index_val;
				$data['cutomer_data'] = $this->Admin_model->get_data('master_accounts_tree', array('id' => $cutomer_id));
				$data['currency_name'] = $this->Admin_model->get_data('master_currency_conv', array('currency_name' => $data['recpt_data'][0]->cbr_currency));
				$stylesheet = file_get_contents('payment_recipt.css');
				// print_r($data['recpt_data'][0]->cbr_currency);
				// exit(0);
							
			
		// 	print_r($this->numbertowordconvertsconver->convert_number($data['amount'][$index_val]));
		// exit(0);
		// <td colspan="2"><h3><ul> RECEIPT VOUCHER</ul></h3></td>';	
			
				
				$html_data = '
				
			<table >
			<tbody >

		<tr>
		
			<td class="border-class" style="border: 1px solid black;">' . $data['currency_name'][0]->currency_name . '' . $data['amount'][$index_val] . '</td>
			
			<td colspan="2"><h3><img src="'. base_url('recipt.jpg').'"></h3></td>
			<td class="border-class"><p><span>No. ' . $data['recpt_data'][0]->cbr_doc_no . '</span><br/>

				<span>Date: ' . $data['recpt_data'][0]->cbr_date . '</span></p></td>

		</tr>

		<tr>

			<td><p>Received from Mr./Ms. :</p></td>
			<td colspan="2">' . $data['cutomer_data'][0]->label . ' <br/> ' . $data['recpt_data'][0]->cbr_narration . '</td>
			<td><p><span style="color: blue;">: استلمنا من السيد/الساده
            </span></p></td>
		</tr>

		<tr >

			<td><p>The Sum of : ' . $data['currency_name'][0]->currency_name . '</p></td>

            <td colspan="2"> ' . $this->numbertowordconvertsconver->convert_number($data['amount'][$index_val]) . '</td>
			<td><p></span> <span style="color: blue;">: مبلغ وقدره
            </span></p></td>
		</tr>

		<tr >';
		

			$html_data .= '<td><p>Cheque Number #:</p></td>

            <td colspan="2"> ' . $data['recpt_data'][0]->cbr_cheque_no . '</td>
			<td ><p><span style="color: blue;">: نقدا/شيك رقم
            </span></td>
		</tr>

		<tr>';
		
			$html_data .= '<td><p >Being :</p></td>
			<td colspan="2"><span>';
				if (!empty($data['recpt_data'][0]->cbr_bill_no))
					$html_data .= "Bill No #: " . $data['recpt_data'][0]->cbr_bill_no . " ";

				if (!empty($data['reference'][$index_val]))
					$html_data .= "Reference #: " . $data['reference'][$index_val] . " ";

				if (!empty($data['remarks'][$index_val]))
					$html_data .= "Remark #: " . $data['remarks'][$index_val] . " ";

				$html_data .= '</span> <span>' . $data['recpt_data'][0]->cbr_due_date . '</span></td>
				<td> <p><span style="color: blue;">: وذلك عن
				</span></p> </td>
		</tr>
		
		<tr>

			<td>Recivers Signature<br/><span style="color: blue;">ريسيفرز التوقيع  </span></td>
			<td class="dotted-line"></td>
						
			<td>Signature <br/><span style="color: blue;">إمضاء </span></td>
			<td class="dotted-line"></td>
				
			
		</tr>
<tr>

			<td colspan="4"><small>NOTE: Cash or trasnfer amount subject to bank clearance and confirmation</small></td>
			
			
		</tr>

</tbody>
	</table>';
				//$this->load->view('admin/cash_bank/recipt_customer_print',$data);

				//$html_data=$this->load->view('admin/cash_bank/recipt_customer_print','',true);

				// print_r($company_details);
				//print_r($html_data);
				
				$pdfFilePath = str_replace(' ', '_', $data['recpt_data'][0]->cbr_doc_no) . '.pdf';
				// 	//  print_r($html);

				$mpdf = new \Mpdf\Mpdf();
				$mpdf->autoScriptToLang = true;

				$mpdf->autoLangToFont = true;
				$mpdf->autoArabic = true;
				$mpdf->defaultfooterline = 0;


				// $this->load->library('m2_pdf');
				// $this->m2_pdf->pdf->autoScriptToLang = true;

				// $this->m2_pdf->pdf->autoLangToFont = true;
				// $this->m2_pdf->pdf->autoArabic = true;
				if (strpos($company_details[0]->mcomp_name, 'UAE ') !== false) {

					$mpdf->SetHeader('<img src="' . base_url("berry_header.png") . '">');
					$mpdf->SetFooter('<img src="' . base_url("berry_footer.png") . '">');
				} elseif (strpos($company_details[0]->mcomp_name, 'UAE') !== false) {

					$mpdf->SetHeader('<img src="' . base_url("berry_header.png") . '">');
					$mpdf->SetFooter('<img src="' . base_url("berry_footer.png") . '">');
				} elseif (strpos($company_details[0]->mcomp_name, 'Dubai ') !== false) {
					$mpdf->SetHeader('<img src="' . base_url("berry_header.png") . '">');
					$mpdf->SetFooter('<img src="' . base_url("berry_footer.png") . '">');
				} elseif (strpos($company_details[0]->mcomp_name, 'FACTORY') !== false) {
					$mpdf->SetHeader('<img src="' . base_url("biri_industries_header.png") . '">');
					$mpdf->SetFooter('<img src="' . base_url("biri_industries_footer.png") . '">');
				} elseif (strpos($company_details[0]->mcomp_name, 'KSA') !== false) {	
					$mpdf->SetHeader('<img src="' .  base_url("ksa-header-new.png") . '">');
					$mpdf->SetFooter('<div >Page {PAGENO} of {nb}</div><img src="' . base_url("ksa-footer-new.png") . '">');
				}
				else {
				}
				
				$mpdf->WriteHTML($stylesheet, 1);
				$mpdf->AddPage(
					'', // L - landscape, P - portrait 
					'',
					'',
					'',
					'',
					5, // margin_left
					5, // margin right
					35, // margin top
					20, // margin bottom
					0, // margin header
					0
				); // margin footer 
				$mpdf->WriteHTML($html_data, 2);

				//save in folder
				$mpdf->Output("./uploads/mpdf_files/" . $pdfFilePath, "F");

				$mpdf->Output($pdfFilePath, 'D');

				redirect('list-receipt');
			} else {
				$this->session->set_flashdata('errors', 'Data error');
				redirect('list-receipt');
			}
		}
	}
function print_page_data($data)
{
	$page_data=$this->load->view('admin/cash_bank/recipt_customer_print',$data);
	return $page_data;
}





function create_pdr($cbr_id=null)
{
	if(logged_in())
	{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		 $cred_count=count($page_cred);


			        for($i=0;$i<$cred_count;$i++)
			        {
			         	if ((($page_cred[$i]=='create-pdr')||($this ->session->userdata['user']['main_dept'])=="Main"))
			         	{
				           $excist=true;
			               $i=$cred_count;
			         	}	

			           else
			            	{$excist=false;}
		   
			        }
			       if ($excist) {

		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'create-pdr'));		
		$salesman=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales', 'log_status !='=>'0'));
		foreach($salesman as $s)
		{
			$data['salesman'][]=$this->Admin_model->get_data('employee_details',array('ed_login_id'=>$s->log_id));
		}
			$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent  IN  (638,620,630,492,596,786,639,640,641,852,1143,245,490,592,604,35,22,674,482)");////TO GET OPERATING EXPENSE A/C NAMES AND CUSTOMER A/C NAMES COMBINED
			$data['customers']=$sql_cust->result_array();		                               
		$data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));		
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
		$sql2=$this->db->query("SELECT *
		FROM master_accounts_tree
		WHERE parent = 700
		UNION
		SELECT * 
		FROM master_accounts_tree
		WHERE parent IN 
    	(SELECT id FROM master_accounts_tree WHERE parent = 700)");
		$data_result_set1=$sql2->result_array();
	//	pre_list($dtt); 

		 	foreach($data_result_set1 as $ds2)
		 	{
		 		//pre_list($ds2['id']);
		 		$data['cash_bank'][]=$this->Admin_model->get_data('master_accounts_tree',array('parent'=>$ds2['id']));
			}
			//unset($data['cash_bank'][0]);
		//	pre_list($data['cash_bank']);
		if(empty($cbr_id))
		{
			$val_recipt=$this->Admin_model->get_data('cash_bank_pdr',array('cbr_sts'=>'1'),'','','cbr_id','DESC');
			if(empty($val_recipt))
			$data['doc_num']='PDR 1200';
			else
			{
			$bal_string1=str_replace("PDR ", "", $val_recipt[0]->cbr_doc_no);
			//print_r($bal_string1);
		           $new_id_1=($bal_string1)+1;
		            $data['doc_num']="PDR ".$new_id_1;
			}			
		}
		else
		{
			$data['result']=$this->Admin_model->get_data('cash_bank_pdr',array('cbr_id'=>$cbr_id));
		}


		$this->load->view('admin/cash_bank/create_pdr',$data);

 } 
		
        else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
          }


	}
}
function get_details_customer_acc_pdr()
{
 $table_id=$this->input->post('table_id');
//$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent IN  (638,620,630,490)");
$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree WHERE parent IN  (638,620,630,492,596,786,639,640,641,852,1143,245,490,592,604,35,22,674,482)");
$customers=$sql_cust->result_array();                        
$html='<select data-plugin-selectTwo  class="form-control populate custmoer_accounts cust_acc_'.$table_id.' cust'.$table_id.'" name="cbr_customer_acc[]"  onchange="get_cust_details('.$table_id.')"><option value="">Choose</option>';
	foreach($customers as $cu)
	{
		$html.="<option value=".$cu['id'].">".strtolower($cu['label'])."</option>";
	}
$html.='</select>';
	echo $html; 	
}

function submit_pdr()
{
	$page_type=$this->input->post('page_type');
	$edited_id=$this->input->post('added_cbr_id');
	/////for upload files//////
$image = array();
	$uploadImgData = array();

  $ImageCount = count($_FILES['files']['name']);
 
        for($i = 0; $i < $ImageCount; $i++)
        {     
            $_FILES['file']['name']       = $_FILES['files']['name'][$i];
            $_FILES['file']['type']       = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['files']['error'][$i];
            $_FILES['file']['size']       = $_FILES['files']['size'][$i];
//$target_file = $target_dir . preg_replace("/[^a-z0-9\_\-\.]/i", '', basename($_FILES['fileToUpload']["name"]));
            // File upload configuration
            $uploadPath = 'uploads/receipt_files/';
         $config['file_name'] = time().preg_replace("/[^a-z0-9\_\-\.]/i", '', basename($_FILES["files"]["name"][$i]));
            $config['upload_path'] = $uploadPath;
            //$config['max_size'] = '3000000';////3mb
            $config['allowed_types'] = '*';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'business_card');
            $this->business_card->initialize($config);

            // Upload file to server
            if($this->business_card->do_upload('file'))
            {
              // Uploaded file data
                $imageData = $this->business_card->data();
              
                $uploadImgData[]=$imageData['file_name'];
              
                if(!empty($uploadImgData))
                {
              		$data_image=implode(',',$uploadImgData);
              	}
              	else
              	{
              		 $data_image='';
    			}	
                //print_r($uploadImgData);
            } 
            else
            {
           	 if(!empty($this->input->post('files_added')))
            		{
            		$data_image=$this->input->post('files_added');
    				}
            		else
           		{
            		$data_image='';
    			}
            }      
        }
////end of for upload files//////////
        $main_date=$this->input->post('hid_date');
$main_date1=explode('/',$main_date);
			$month1=$main_date1[0];
			$date1=$main_date1[1];
			$year1=$main_date1[2];
$new_formated_date1=$year1.'-'.$month1.'-'.$date1;

 $main_due_date=$this->input->post('cbr_maturity_date');
$main_due_date1=explode('/',$main_due_date);
			$month2=$main_due_date1[0];
			$date2=$main_due_date1[1];
			$year2=$main_due_date1[2];
$new_formated_date2=$year2.'-'.$month2.'-'.$date2;
$cash_bank_acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$this->input->post('cbr_acc')));

		$data['cbr_doc_no']=$this->input->post('cbr_doc_no');
		
		$data['cbr_maturity_date']=$new_formated_date2;
		$data['cbr_acc']=$this->input->post('cbr_acc');
		$data['cbr_company']=$this->input->post('cbr_company');
		$data['cbr_cheque_no']=$this->input->post('cbr_cheque_no');
		$data['cbr_currency']=$this->input->post('cbr_currency');
		$data['cbr_rate_currency']=$this->input->post('cbr_rate_currency');
		$data['cbr_bill_no']=$this->input->post('cbr_bill_no');
		$data['cbr_attachments']=$data_image;
		$data['cbr_salesman']=$this->input->post('hid_salesman');
		$data['cbr_customer_acc']=$this->input->post('hid_customer');
		$data['cbr_amount']=$this->input->post('hid_amounts');
		$data['cbr_ref']=$this->input->post('hid_ref');
		$data['cbr_remark']=$this->input->post('hid_remark');
		$data['cbr_tot_amount']=$this->input->post('cbr_tot_amount');
		$data['cbr_sts']='1';
		$data['cbr_dt_updt']=get_date_time();
		$data['cbr_narration']=$this->input->post('cbr_narration');

	if(empty($edited_id))////willl insert
	{
		$document_bal_number=str_replace("PDR ", "", $this->input->post('cbr_doc_no'));
		$data['cbr_doc_number']=$document_bal_number;
	}
	$salesman_vlues=explode('|#|', $this->input->post('hid_salesman'));
	$customer_account=explode('|#|',$this->input->post('hid_customer'));
	$customer_amounts=explode('|#|',$this->input->post('hid_amounts'));
	$customer_remark=explode('|#|',$this->input->post('hid_remark'));
	$customer_refs=array_filter(explode('|#|',$this->input->post('hid_ref')));

	$vat_amounts=explode('|#|',$this->input->post('hid_vat'));

$sales_inv_id=array_filter(explode('|#|',$this->input->post('sales_inv_id')));
$sales_inv_amount=array_filter(explode('|#|',$this->input->post('sales_inv_amount')));
$sales_inv_amount_paid=array_filter(explode('|#|',$this->input->post('sales_inv_amount_paid')));
$sales_doc_num=array_filter(explode('|#|',$this->input->post('sales_doc_num')));
$tot_inv_amount_paid_from_ref=array_sum($sales_inv_amount_paid);

	//pre_list($sales_inv_amount_paid);
	if(empty($edited_id))////willl insert
	{
	$insert_id=$this->Admin_model->insert_data('cash_bank_pdr',$data);
		//$insert_id='12';
		if(!empty($insert_id))
		{
			$this->Admin_model->update_data('cash_bank_pdr',array('cbr_insert_date'=>date('Y-m-d'),'cbr_dt_crtd'=>get_date_time(),'cbr_converted_status'=>'not-converted','cbr_date'=>$new_formated_date1,'cbr_created_by'=>$this->session->userdata['user']['username'] ),array('cbr_id'=>$insert_id) );	
	  		
	  		if($cash_bank_acc_details[0]->parent=="596")
			{
				$this->Admin_model->update_data('cash_bank_pdp',array('cbr_current_status'=>'approved'),array('cbr_id'=>$insert_id) );
			}
			elseif($cash_bank_acc_details[0]->parent=="786")
			{
				$this->Admin_model->update_data('cash_bank_pdp',array('cbr_current_status'=>'approved'),array('cbr_id'=>$insert_id) );
			}
			else
			{
				$this->Admin_model->update_data('cash_bank_pdp',array('cbr_current_status'=>'non-approved'),array('cbr_id'=>$insert_id) );
			}
     
	$cbr_doc_numtext=$this->input->post('cbr_doc_no');

			$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'pdr created',
				'act_status'=>'pdr id '.$insert_id.' created',
				'act_doc_num'=>$cbr_doc_numtext,
				'act_pdr_cb_id'=>$insert_id,
				'act_type_id'=>$insert_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
				'act_type'=>'PDR'
			);
			 $this->Admin_model->insert_data('activities',$activity_data);

		$this->session->set_flashdata('success', 'Data Successfully inserted');
		}
	}
	else////will updATE
	{
		$this->Admin_model->update_data('cash_bank_pdr',$data,array('cbr_id'=>$edited_id) );
		$current_recpt_amount=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$edited_id,'atx_doc_no'=>$this->input->post('cbr_doc_no'),'atx_type_tx'=>'PDR'));
		if(!empty($current_recpt_amount))
			{
				foreach($current_recpt_amount as $index=>$cra)
				{
					$cust_id_array[]=$cra->atx_cust_id;
					$tx_id_array[]=$cra->atx_id;
					$cust_tx_amount_array[]=$cra->atx_tot_amount;
					$cust_tx_bal_amount_array[]=$cra->atx_bal_amount;
					$current_sales_bal_amount[$index][]=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$cra->atx_id));
					
					if(!empty($current_sales_bal_amount))
					{
						foreach($current_sales_bal_amount[$index] as $index2=>$csb)
						{
								$acc_tx_details_2=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$csb->actb_to_id));
							$current_paid_amount=$acc_tx_details_2[0]->atx_paid_amount;
							$current_bal_amount=$acc_tx_details_2[0]->atx_bal_amount;
							$current_tot_amount=$acc_tx_details_2[0]->atx_tot_amount;
							$new_tot_amount=$current_tot_amount+$csb->actb_paid_amount;
							$new_paid_amount=$current_paid_amount+$csb->actb_paid_amount;
							$new_bal_amount=$current_bal_amount+$csb->actb_paid_amount;
							$array_new_data=array(
						'atx_paid_amount'=>$new_paid_amount,
						'atx_bal_amount'=>$new_bal_amount,
						'atx_tot_amount'=>	$new_tot_amount
					);
					$this->Admin_model->update_data('account_all_tx',$array_new_data,array('atx_id'=>$csb->actb_to_id));
					$this->Admin_model->delete_data('account_tx_bal_data',array('actb_tx_id'=>$csb->actb_tx_id));
							}
						}	
					}
 			}
$cbr_doc_numtext=$this->input->post('cbr_doc_no');

			$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'pdr edited',
				'act_status'=>'pdr id '.$edited_id.' Edited',
				'act_doc_num'=>$cbr_doc_numtext,
				'act_pdr_cb_id'=>$edited_id,
				'act_type_id'=>$edited_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
				'act_type'=>'PDR'
			);
			  $this->Admin_model->insert_data('activities',$activity_data);

		$this->session->set_flashdata('success', 'Data Successfully updated');
	}

/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////	
if(!empty($insert_id) || !empty($edited_id) )
		{
			if(!empty($insert_id))
			{
				$pdr_rcpt_id=$insert_id;
			}
			elseif (!empty($edited_id)) 
			{
				$pdr_rcpt_id=$edited_id;
			}
			else
			{
				$pdr_rcpt_id='';
			}
	if(!empty($pdr_rcpt_id))
	{	
	foreach($customer_account as $index=>$c_acc)
			{
					$data_tx['atx_user_created']=$this->session->userdata['user']['username'];
					$data_tx['atx_type_tx']='PDR';
					$data_tx['atx_date']=$new_formated_date1;
					$data_tx['atx_doc_no']=$this->input->post('cbr_doc_no');
					$data_tx['atx_main_id']=$pdr_rcpt_id;
					$data_tx['atx_cust_id']=$c_acc;
					$data_tx['atx_acc_id']=$this->input->post('cbr_acc');
					$data_tx['atx_tot_amount']=$customer_amounts[$index];
					if (!empty($edited_id)) 
					$data_tx['atx_paid_amount']='0';
					//$data_tx['atx_bal_amount']=$customer_amounts[$index];
					$data_tx['atx_dt_updt']=get_date_time();
					$data_tx['atx_sts']='1';
					$data_tx['atx_amount_type']='Expense';
						$data_tx['atx_region']=$page_type;
						$data_tx['atx_narration']=$this->input->post('cbr_narration');
					$data_tx['atx_salesman']=$salesman_vlues[$index];
					$data_tx['atx_bill_no']=$this->input->post('cbr_bill_no');
					$data_tx['atx_cheque_no']=$this->input->post('cbr_cheque_no');
					$data_tx['atx_currency_value']=$this->input->post('cbr_rate_currency');
					$data_tx['atx_currency_type']=$this->input->post('cbr_currency');

	///////////////here logic to update the same table, for recipt, with the amount paid for referecnes(not include any new-ref here)//  
	if(!empty($sales_inv_amount_paid[$index]))
					{
					$sales_inv_amount_total=explode('|$$|',$sales_inv_amount_paid[$index]);
					if(!empty(array_sum($sales_inv_amount_total)))
						{
							//echo "inside last if";echo "<br/>";
							$data_final_bal_amount=$customer_amounts[$index]-array_sum($sales_inv_amount_total);
							//print_r($data_final_bal_amount);echo "<br/>";print_r(array_sum($sales_inv_amount_total));
							//
							$data_tx['atx_bal_amount']=$data_final_bal_amount;
							$data_tx['atx_paid_amount']=array_sum($sales_inv_amount_total);
						}
						else
						{
							$data_tx['atx_bal_amount']=$customer_amounts[$index];
							$data_tx['atx_paid_amount']='0';
						}
					}
					else
					{
						$data_tx['atx_bal_amount']=$customer_amounts[$index];
						$data_tx['atx_paid_amount']='0';
					}			
		
			if(!empty($edited_id))	
				{
					if(in_array($c_acc, $cust_id_array))
					{
						$insert_id_acc_tx[]=$current_recpt_amount[$index]->atx_id;
						$this->Admin_model->update_data('account_all_tx',$data_tx,array('atx_id'=>$current_recpt_amount[$index]->atx_id));	
					}
					else
					{
						$insert_id_acc_tx[]=$this->Admin_model->insert_data('account_all_tx',$data_tx);
					}
				}
				else
				{
					$insert_id_acc_tx[]=$this->Admin_model->insert_data('account_all_tx',$data_tx);
				}
			}
	//pre_list($data_tx);
			  ///check for sales invoice related data////
	foreach($sales_inv_id as $index=>$si)
			{		
			//print_r($insert_id_acc_tx[$index]);
		
			$sales_inv_id_extra=explode('|$$|',$si);
			$sales_inv_amount_extra=explode('|$$|',$sales_inv_amount[$index]);
			$sales_inv_amount_paid_extra=explode('|$$|',$sales_inv_amount_paid[$index]);
			$sales_inv_doc_num_extra=explode('|$$|',$sales_doc_num[$index]);

		if(!empty($sales_inv_amount_paid[$index]))
			{
			foreach($sales_inv_id_extra as $index2=>$si2)
				{
					//	print_r($si2);	
					if(!empty($sales_inv_amount_paid_extra[$index2]))
					{
						$amount_paid_till_now=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$si2));
						$total_paid_amount_from_another_ref[]=$sales_inv_amount_paid_extra[$index2];
			  		$bal_amount_sales_inv=$sales_inv_amount_extra[$index2]-$sales_inv_amount_paid_extra[$index2];
			  		
			  		$data_si_array=array(
			  			'atx_paid_amount'=>$amount_paid_till_now[0]->atx_paid_amount+$sales_inv_amount_paid_extra[$index2],
			  			'atx_bal_amount'=>$bal_amount_sales_inv,
			  		);
			  		//pre_list($data_si_array);
			  	$this->Admin_model->update_data('account_all_tx',$data_si_array,array('atx_id'=>$si2));

				$data_tx_bal=array(
					'actb_tx_id'=>$insert_id_acc_tx[$index],
					'actb_to_type'=>$sales_inv_doc_num_extra[$index2],
					'actb_paid_amount'=>$sales_inv_amount_paid_extra[$index2],
					'actb_to_id'=>$si2,
					'actd_sts'=>'1',
				'actb_user_created'=>$this->session->userdata['user']['username'],
				);	
				//pre_list($data_tx_bal);
			$this->Admin_model->insert_data('account_tx_bal_data',$data_tx_bal);
			  		}
			  	}
			}
		}  
	/////////////alll opr related to addding to acc_all_tx or acc_bal_tx table ////////////////		

			redirect('list-pdr');
		}
		else
		{
		 $this->session->set_flashdata('errors', 'Error on data found. Please try again.');
		 redirect('list-pdr');
		}
	}
}


function list_pdr()
{
	if(logged_in())
	{
            $another_condition = '';
	         $sort_by = '';
			if(!empty($this->input->post('sortBy')))
			{
				$sort_by = $this->input->post('sortBy');
				if($sort_by == 'converted')
				{
					$another_condition = "and cbr.cbr_converted_status='" . 'converted' . "' ";
				}
				elseif($sort_by == 'not-converted')
				{
					$another_condition = "and cbr.cbr_converted_status='" . 'not-converted' . "' ";
				}
				else{
					$another_condition = "and cbr.cbr_converted_status='" . 'deleted' . "' ";
				}
				
			}




          

            $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		    $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-pdr')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'list-pdr'));
		$sql2=$this->db->query("SELECT cbr.*,mc.mcomp_name,mat.label
	FROM cash_bank_pdr as cbr join master_company as mc on mc.mcomp_id=cbr.cbr_company join master_accounts_tree as mat on mat.id=cbr.cbr_acc 	
	WHERE cbr.cbr_converted_status<>'deleted'  and cbr.cbr_sts = '1'".$another_condition." order by cbr.cbr_id DESC");
		$data['result']=$sql2->result_array();
			
		$data['sort_by'] = $sort_by;
			$this->load->view('admin/cash_bank/list_pdr',$data);
	}

	 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 


}
}

function delete_pdr($cbr_id=null)
{
	if(logged_in())
	{
		if(!empty($cbr_id))
		{

			$cash_bank_details=$this->Admin_model->get_data('cash_bank_pdr',array('cbr_id'=>$cbr_id));
					    	foreach($cash_bank_details as $s)
		{
	    $cbr_doc_num=$s->cbr_doc_no;
}
	 
	    
		$acc_tx_details=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_doc_no'=>$cbr_doc_num,'atx_sts'=>'1'));


        
		   	$Reason_of_delete_pdr=$this->input->post('reason-of-delete-pdr');

		
				 
		if(!empty($acc_tx_details))
		{
			foreach($acc_tx_details as $index=>$actx)
			{
				
				$acc_bal_tx=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$actx->atx_id,'actd_sts'=>'1'));
         
                 
			
	
			 if(!empty($acc_bal_tx))
			 {
				
				
				foreach($acc_bal_tx as $index2=>$acb)
				{
                    
				
					$acc_tx_details_2=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$acb->actb_to_id,'atx_sts'=>'1'));
	                // print_r('----second foreach----');
				    //   print_r($acc_tx_details_2);
				 
					$current_paid_amount=$acc_tx_details_2[0]->atx_paid_amount;
					
					$current_bal_amount=$acc_tx_details_2[0]->atx_bal_amount;
					
					$new_paid_amount=$current_paid_amount-$acb->actb_paid_amount;
					
				
					$new_bal_amount=$current_bal_amount+$acb->actb_paid_amount;
			
					$array_new_data=array(
						'atx_paid_amount'=>$new_paid_amount,
						'atx_bal_amount'=>$new_bal_amount,
					);

               
                   
					$this->Admin_model->update_data('account_all_tx',$array_new_data,array('atx_id'=>$acb->actb_to_id));
					$this->Admin_model->update_data('account_tx_bal_data',array('actd_sts'=>'0'),array('actb_to_id'=>$acb->actb_to_id));
					$this->Admin_model->update_data('account_tx_bal_data',array('actd_sts'=>'0'),array('actb_tx_id'=>$acb->actb_tx_id));
					
              
                
                         
				
				}
				    
			 } 
		
			
		  }	
		 
		}

		
	 $this->Admin_model->update_data('account_all_tx',array('atx_sts'=>'0'),array('atx_main_id'=>$cbr_id,'atx_doc_no'=>$cbr_doc_num));

	//    if(!empty($pdr_related_num))
	// 	 {  

			
    //          $this->Admin_model->update_data('cash_bank_pdr',array('cbr_current_status'=>'deleted','cbr_attachments'=>$Reason_of_delete),array('cbr_doc_no'=>$pdr_related_num));
	// 		 $this->Admin_model->update_data('cash_bank_receipt',array('cbr_current_status'=>'deleted','cbr_attachments'=>$Reason_of_delete),array('cbr_id'=>$cbr_id));

	// 	 }
	 	$this->Admin_model->update_data('cash_bank_pdr',array('cbr_converted_status'=>'deleted','cbr_attachments'=>$Reason_of_delete_pdr),array('cbr_id'=>$cbr_id));
        


		$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'pdr deleted',
				'act_status'=>'pdr id '.$cbr_id.' deleted',
				'act_doc_num'=>$cbr_doc_num,
				'act_pdr_cb_id'=>$cbr_id,
				'act_type_id'=>$cbr_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
				'act_type'=>'PDR'
			);
		  $this->Admin_model->insert_data('activities',$activity_data);
			  $this->session->set_flashdata('success', 'Data Successfully deleted');
		redirect('list-pdr');
		}
	}
}

function get_doc_details()
{
	$cbr_id=$this->input->post('main_id');
	$doc_type=$this->input->post('type_doc');

	if($doc_type=="receipt")
	{
$dataa=$this->Admin_model->get_data('cash_bank_receipt',array('cbr_id'=>$cbr_id));
	}
	else{
	$dataa=$this->Admin_model->get_data('cash_bank_pdr',array('cbr_id'=>$cbr_id));
	}
			
	if($dataa)
				{
					$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->cbr_company));
					$acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->cbr_acc));
					$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->cbr_currency));
					$customer_list=explode('|#|',$dataa[0]->cbr_customer_acc);

            
					//// my testing   


						  $docname=$dataa[0]->cbr_doc_no;


							$datatx=$this->Admin_model->get_data('account_all_tx',array('atx_doc_no'=>$docname));
              // print_r($datatx);
              // exit(0);
							$so_many_tx=count($datatx);
							$i=0;
							for($txmany=0;$txmany<$so_many_tx;$txmany++)
							{
                 
							///uou have two atx_id or maybe more 
							$txnum[$i]=$datatx[$txmany]->atx_id;
							$i++;


						}


						for($j=0;$j<$i;$j++){

							//print_r($txnum[$j]);
							
								$balancedetails[$j]=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$txnum[$j]));
								$how_invoice_you_have[$j]=count($balancedetails[$j]);
							
						}
            


					
							

							

							

					///  end of my testing 



					foreach($customer_list as $cs)
					{
						$data_cl[]=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$cs));
					}
					
						$salesman_list=explode('|#|',$dataa[0]->cbr_salesman);
					foreach($salesman_list as $sl)
					{
						$data_sl[]=$this->Admin_model->get_data('employee_details',array('ed_id'=>$sl));
					}

					$cust_amount_list=explode('|#|',$dataa[0]->cbr_amount);
				$ref_list=explode('|#|',$dataa[0]->cbr_ref);
					$ref_list2=explode('|$$|',$dataa[0]->cbr_ref);
					$rmk_list=explode('|#|',$dataa[0]->cbr_remark);

					$account_tx_data=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$cbr_id,'atx_type_tx'=>'Receipt'));
					if(!empty($account_tx_data))
					{
						$account_bal_data_1=$this->Admin_model->get_data('account_tx_bal_data',array('actb_to_id'=>$account_tx_data[0]->atx_id));
						if(!empty($account_bal_data_1))
						{
							foreach($account_bal_data_1 as $abd)
							{
								$tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_tx_id));
							}
						}
						else
						{
							$account_bal_data_2=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_data[0]->atx_id));
							if(!empty($account_bal_data_2))
							{
								foreach($account_bal_data_2 as $abd)
								{
									$tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_to_id));
								}	
							}
						}
					}
	
					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Recipt Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->cbr_doc_no."</p>";
					$html.="<p>User Created: ".$dataa[0]->cbr_created_by."</p>";
					$html.="<p>Date: ".$dataa[0]->cbr_date."</p>";
					if($doc_type=="receipt")
					{
					$html.="<p>Due Date: ".$dataa[0]->cbr_due_date."</p>";
					}
					else
					{
				$html.="<p>Maturity Date: ".$dataa[0]->cbr_maturity_date."</p>";	
					}
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					$html.="<p style='color:blue'><b>Linked to :</b></p>";

					for($j=0;$j<$i;$j++)

		{
					if(!empty($balancedetails[$j]))
					{
						// foreach($tx_data_related as $tx)
						// {
						// 	$html.="<p style='color:blue'>".$tx[0]->atx_doc_no."</p>";
						// }

             	//foreach($data_cl as $key=>$m)
						

				


               		 	for($ourrecipt=0;$ourrecipt<$how_invoice_you_have[$j];$ourrecipt++)
					{
                   
						
                      $invoice_name=$balancedetails[$j][$ourrecipt]->actb_to_type;
                      $invoice_amount=$balancedetails[$j][$ourrecipt]->actb_paid_amount;
											
											// print_r( $test);
           //            print_r($test2);
										
									
                 	$html.="<p style='color:blue'> ".$invoice_name. "=" . $invoice_amount."</p>";
                 

					}



					
	// exit(0);
			        		
		 
					}	
			}
					
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Cash &amp; Bank : ".$acc_details[0]->label."</p>";
					$html.="<p>Company: ".$company_details[0]->mcomp_name."</p>";
					if($doc_type=="receipt")
					{
					$html.="<p>PDC No.: ".$dataa[0]->cbr_pdc_no."</p>";
					}
					$html.="<p>Cheque No.: ".$dataa[0]->cbr_cheque_no."</p>";
					$html.="<p>Bill No.: ".$dataa[0]->cbr_bill_no."</p>";
					$html.="<p>Narration.: ".$dataa[0]->cbr_narration."</p>";
					
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Total Amount : ".$dataa[0]->cbr_tot_amount."</p>";
				$html.="<p>Current Status: ".$dataa[0]->cbr_current_status."</p>";
					$html.="<p>Attachements: <a href='".base_url('uploads/receipt_files/'.$dataa[0]->cbr_attachments)."' target='_blank'> ".$dataa[0]->cbr_attachments."</a></p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

					$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th><th>Salesman</th><th>Account</th><th>Amounts</th><th>Reference</th><th>Remark</th></thead>";
					$html.="<tbody>";
					foreach($data_cl as $key=>$d)
					{
						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$data_sl[$key][0]->ed_name."</td>";
						$html.="<td>".$d[0]->label."</td>";
						$html.="<td>".$cust_amount_list[$key]."</td>";
						$html.="<td>".$ref_list[$key]."</td>";
						$html.="<td>".$rmk_list[$key]."</td>";
						$html.="</tr>";
					}
					$html.="</tbody>";
					$html.="</table>";

					/*** start of table  ***/
					echo $html;
	}
}

function check_edit()
	{
		$cbr_id = $this->input->post('main_id');
		$type = $this->input->post('type');
		$page_name = $this->input->post('page_name');
		$acc_tx_details = $this->Admin_model->get_data('account_all_tx', array('atx_main_id' => $cbr_id, 'atx_type_tx' => $type, 'atx_region' => $page_name));
		if (!empty($acc_tx_details)) {
			foreach ($acc_tx_details as $ac) {
				$acc_bal_data[] = $this->Admin_model->record_count2('account_tx_bal_data', array('actb_tx_id' => $ac->atx_id));
			}
		}

		if (!empty(array_filter($acc_bal_data))) {
			echo false;
		} else {
			echo true;
		}
	}

}