<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_dashboard_controller extends CI_Controller {

public function __construct() {
		parent::__construct();
	  
	    $this->load->helper(array('session','email','img','gnrl','email_survey','text','email_po','prd'));
		$this->load->model('Third_db_model','tm');
		$this->load->model('Sales_book_model','sbm');
		

			
	}


function dashboard()
{


    $excist=false;

		if(logged_in())
		{

          $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);
 ///that for checking wich store should i redirect the user for pending and approval
		   for($k=0;$k<$cred_count;$k++)
		    {
		      if ($page_cred[$k]=='dubai-store-privelige')
		         {  
		           //$warehouse_number=strval(23);
		         	$Pending_warehouse=strval(23);
		         	$Approved_warehouse=strval(23);

		            $k=$cred_count;

		          }
		          else if($page_cred[$k]=='k-store-riyadh-privelige')
		          	{ 

		          	 	$Pending_warehouse=strval(22);

		          	$Approved_warehouse=strval(22);

		  }
		    else if ($page_cred[$k]=='2019k-store-riyadh-privelige')
		          	{ 

		          	 	$Pending_warehouse=strval(21);

		          	$Approved_warehouse=strval(21);

		  }
		    else if($page_cred[$k]=='new-rak-store-privelige')
		          	{ 

		          	 	$Pending_warehouse=strval(20);

		          	$Approved_warehouse=strval(20);

		  }
		    else if($page_cred[$k]=='new-dragon-privelige')
		          	{ 

		          	 	$Pending_warehouse=strval(19);

		          	$Approved_warehouse=strval(19);

		  }
		     else if($page_cred[$k]=='diera-2019-privelige')
		      { 

		          	 	$Pending_warehouse=strval(18);

		          	$Approved_warehouse=strval(18);

		       }
		        else if($page_cred[$k]=='new-garhoud-privelige')
		      { 

		          	 	$Pending_warehouse=strval(19);

		          	$Approved_warehouse=strval(19);

		       }

             else if($page_cred[$k]=='baniyas-privelige')
		      { 

		          	 	$Pending_warehouse=strval(16);

		          	$Approved_warehouse=strval(16);

		       }

            else if($page_cred[$k]=='aweer-privelige')
		      { 

		          	 	$Pending_warehouse=strval(15);

		          	$Approved_warehouse=strval(15);

		       }

            else if($page_cred[$k]=='jeddah-privelige')
		      { 

		          	 	$Pending_warehouse=strval(11);

		          	$Approved_warehouse=strval(11);

		       }


 else {

	                $Pending_warehouse=strval(7);

		          	$Approved_warehouse=strval(7);

 }

		  }
//end adding///

        for($i=0;$i<$cred_count;$i++)
         {
            if ((($page_cred[$i]=='marketing-dashboard')||($this ->session->userdata['user']['main_dept'])=="Sales"))
             {
				 $excist=true;
				  $i=$cred_count;
			 }
         else
          {$excist=false;}
			  	

         }
        if ($excist) {



///////////////////////////for query///////////


$salesman_focus=$this->session->userdata['user']['salesman_focus'];

//$salesman_focus="Kristine";
$dept_logged_in=$this->session->userdata['user']['main_dept'];
	$log_sub_type=$this->session->userdata['user']['sub_dept'];
	if($dept_logged_in=="Sales" && $log_sub_type=="ksa")
	{
	$city_list=array();
	 $city_list=array('Al Dammam','Jeddah','Riyadh');
	}
	else
	{
	
	$city_list=array();
	}
		


$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
$current_month= $dt->format('m');
$current_year= $dt->format('Y');
$previous_year=$dt->format('Y')-1;
	
$last_previous_year=$dt->format('Y')-2;
$last_last_previous_year=$dt->format('Y')-3;
$last_last_previous_yearfourth=$dt->format('Y')-4;//for add online
$last_last_previous_yearfifth=$dt->format('Y')-5;

$months=array('01','02','03','04','05','06','07','08','09','10','11','12');


foreach($months as $m)
{
	// $datt['curnt_yr'][]=$this->sbm->bar_chart_data_curnt_year($current_year,$m,$city_list);
	// $datt['prev_yr'][]=$this->sbm->bar_chart_data_prev_year($previous_year,$m,$city_list);	
	// $datt['last_prev_yr'][]=$this->sbm->bar_chart_data_prev_year($last_previous_year,$m,$city_list);
	// $datt['last_last_prev_yr'][]=$this->sbm->bar_chart_data_prev_year($last_last_previous_year,$m,$city_list);	
	// $datt['last_last_last_prev_yr'][]=$this->sbm->bar_chart_data_prev_year($last_last_previous_yearfourth,$m,$city_list);	//for add online
	// $datt['last_last_last_prev_yr_fifth'][]=$this->sbm->bar_chart_data_prev_year($last_last_previous_yearfifth,$m,$city_list);
    $datt['curnt_yr'][]=$this->sbm->bar_chart_data_curnt_year2($current_year,$m,$city_list,'',$salesman_focus);
	$datt['prev_yr'][]=$this->sbm->bar_chart_data_prev_year2($previous_year,$m,$city_list,'',$salesman_focus);	
	$datt['last_prev_yr'][]=$this->sbm->bar_chart_data_prev_year2($last_previous_year,$m,$city_list,'',$salesman_focus);
	$datt['last_last_prev_yr'][]=$this->sbm->bar_chart_data_prev_year2($last_last_previous_year,$m,$city_list,'',$salesman_focus);	
	$datt['last_last_last_prev_yr'][]=$this->sbm->bar_chart_data_prev_year2($last_last_previous_yearfourth,$m,$city_list,'',$salesman_focus);	//for add online
	$datt['last_last_last_prev_yr_fifth'][]=$this->sbm->bar_chart_data_prev_year2($last_last_previous_yearfifth,$m,$city_list,'',$salesman_focus);
}

if($dept_logged_in=="Sales" && $log_sub_type=="ksa")
	{

		 $data['total_sales_all_years']=$this->sbm->total_sales_all_years_ksa2($salesman_focus);
	}
	else 
	{
		$data['total_sales_all_years']=$this->sbm->total_sales_all_years2($salesman_focus);
		
		
	}
foreach($datt['curnt_yr'] as $dc)
{
	$data['months_curnt'][]=$dc[0]->total_amount;


}

foreach($datt['prev_yr'] as $dp)
{
	$data['months_prev'][]=$dp[0]->total_amount;
}

foreach($datt['last_prev_yr'] as $dp)
{
	$data['months_last_prev'][]=$dp[0]->total_amount;
}

foreach($datt['last_last_prev_yr'] as $dp)
{
	$data['months_last_last_prev'][]=$dp[0]->total_amount;
}
//for add online
foreach($datt['last_last_last_prev_yr'] as $dp)
{
	$data['months_last_last_last_prev'][]=$dp[0]->total_amount;
}
foreach($datt['last_last_last_prev_yr_fifth'] as $dp)
{
	$data['months_last_last_last_prev_fifth'][]=$dp[0]->total_amount;
}

$datt['cat_curnt_yr'][]=$this->sbm->all_category2($current_year,'','',$city_list);
if(empty($datt['cat_curnt_yr'][0]))
{
$datt2['cat_curnt_yr'][]=$this->sbm->all_category2($previous_year,'','',$city_list);
}


if(!empty($datt['cat_curnt_yr'][0]))
{
$all_cat_names=array();$all_cat_sum1=array();
foreach($datt['cat_curnt_yr'][0] as $cat_c)
{
	if(!empty($all_cat_names))
	{
	if(!in_array($cat_c->sbp_ar_category, $all_cat_names))
	$all_cat_names[]=$cat_c->sbp_ar_category;
	}
	else
	{
	$all_cat_names[]=$cat_c->sbp_ar_category;
	}
$all_cat_sum1[$cat_c->sbp_ar_category][]=$cat_c->total_gross_amount;
}  
foreach($all_cat_names as $c)
{
$datt['cat_prev_yr'][]=$this->sbm->all_category2($previous_year,array('sbp_ar_category'=>$c),'',$city_list,'',$salesman_focus);
$datt['cat_last_prev_yr'][]=$this->sbm->all_category2($last_previous_year,array('sbp_ar_category'=>$c),'',$city_list,'',$salesman_focus);
$datt['cat_last_last_prev_yr'][]=$this->sbm->all_category2($last_last_previous_year,array('sbp_ar_category'=>$c),'',$city_list,'',$salesman_focus);
$datt['cat_last_last_last_prev_yr'][]=$this->sbm->all_category2($last_last_previous_yearfourth,array('sbp_ar_category'=>$c),'',$city_list,'',$salesman_focus);//for add online

$datt['cat_last_last_last_prev_yr_fifth'][]=$this->sbm->all_category2($last_last_previous_yearfifth,array('sbp_ar_category'=>$c),'',$city_list,'',$salesman_focus);
}
foreach($datt['cat_prev_yr'] as $indx=>$c2)
{
$all_cat_sum2[]=$c2;
}
	
foreach($datt['cat_last_prev_yr'] as $indx=>$c2)
{
$all_cat_sum3[]=$c2;
}

foreach($datt['cat_last_last_prev_yr'] as $indx=>$c3)
{
$all_cat_sum4[]=$c3;
}
foreach($datt['cat_last_last_last_prev_yr'] as $indx=>$c4)
{
$all_cat_sum5[]=$c4;
}
foreach($datt['cat_last_last_last_prev_yr_fifth'] as $indx=>$c5)
{
$all_cat_sum6[]=$c5;
}
	
	$data['cat_amount_curnt']=$all_cat_sum1;
	$data['cat_amount_prev']=$all_cat_sum2;
	$data['cat_amount_last_prev']=$all_cat_sum3;
	$data['cat_amount_last_last_prev']=$all_cat_sum4;
	$data['cat_amount_last_last_last_prev']=$all_cat_sum5;//for add online
	$data['cat_amount_last_last_last_fifth']=$all_cat_sum6;
}
else
{
$all_cat_names=array();$all_cat_sum1=array();
	foreach($datt2['cat_curnt_yr'][0] as $cat_c)
	{
		if(!empty($all_cat_names))
		{
		if(!in_array($cat_c->sbp_ar_category, $all_cat_names))
		$all_cat_names[]=$cat_c->sbp_ar_category;
		}
		else
		{
		$all_cat_names[]=$cat_c->sbp_ar_category;
		}
	$all_cat_sum1[$cat_c->sbp_ar_category][]=$cat_c->total_gross_amount;
	}
	
	foreach($all_cat_names as $c)
	{
	$datt['cat_prev_yr'][]=$this->sbm->all_category2($previous_year,array('sbp_ar_category'=>$c),'',$city_list,'',$salesman_focus);
	
	$datt['cat_last_prev_yr'][]=$this->sbm->all_category2($last_previous_year,array('sbp_ar_category'=>$c),'',$city_list,'',$salesman_focus);
	
	$datt['cat_last_last_prev_yr'][]=$this->sbm->all_category2($last_last_previous_year,array('sbp_ar_category'=>$c),'',$city_list,'',$salesman_focus);
	  $datt['cat_last_last_last_prev_yr'][]=$this->sbm->all_category2($last_last_previous_yearfourth,array('sbp_ar_category'=>$c),'',$city_list,'',$salesman_focus);//for add online
	   $datt['cat_last_last_last_prev_yr_fifth'][]=$this->sbm->all_category2($last_last_previous_yearfifth,array('sbp_ar_category'=>$c),'',$city_list,'',$salesman_focus);
	}
	
    //add online

    foreach($datt['cat_last_last_last_prev_yr_fifth'] as $indx=>$c2)
	{
	$all_cat_sum6[]=$c2;
	}
	foreach($datt['cat_last_last_last_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum5[]=$c2;
	}


	foreach($datt['cat_last_last_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum4[]=$c2;
	}
	
	foreach($datt['cat_last_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum3[]=$c2;
	}
	
	foreach($datt['cat_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum2[]=$c2;
	}
	
	
	$data['cat_amount_curnt']=array();
	$data['cat_amount_prev']=$all_cat_sum2;
	//$data['cat_amount_prev']=$all_cat_sum2;
	$data['cat_amount_last_prev']=$all_cat_sum3;
	$data['cat_amount_last_last_prev']=$all_cat_sum4;
	$data['cat_amount_last_last_last_prev']=$all_cat_sum5;//add online
	$data['cat_amount_last_last_last_fifth']=$all_cat_sum6;
}


$data['all_category_comparison']=$all_cat_names;
$data['current_year']=$current_year;
$data['previous_year']=$previous_year;
$data['last_previous_year']=$last_previous_year;
$data['last_last_prev_yr']=$last_last_previous_year;
$data['last_last_last_prev_yr']=$last_last_previous_yearfourth;//add online 
$data['last_last_last_prev_yr_fifth']=$last_last_previous_yearfifth;

        	//////////////end quere for charts ///////

//////query for total of unpaid or due total//////////////////////////////////////////////
$salesman_focus=$this->session->userdata['user']['salesman_focus'];
$username_logged_in=$this->session->userdata['user']['userlogid'];

$from_table="account_all_tx ";

$sql2=$this->db->query("SELECT SUM(atx_bal_amount) as total_due from ".$from_table." where atx_salesman='".$username_logged_in."' and atx_type_tx='sales_invoice' ");

$query_duetotal=$sql2->result_array();

$totaldue=doubleval($query_duetotal[0]['total_due']);
$data['totaldue']=$totaldue;

///////////////////////end of query for total of unpaid or due total////////////////////////// 

// SELECT * FROM `sales_invoice_ksa` WHERE `si_current_sts`='not-paid' and `si_salesman`='55' order by 'si_id' limit 10
// SELECT * FROM `sales_invoice_ksa` WHERE `si_current_sts`='partially-paid' and `si_salesman`='55' order by 'si_id' limit 10


	if($log_sub_type=='ksa')
	{
		$from_salesinvice='sales_invoice_ksa';
           
	}
	else if($log_sub_type=='gcc'){
		$from_salesinvice='sales_invoice';
	}else if($log_sub_type=='export'){
		$from_salesinvice='sales_invoice_export';
	}
	else if($log_sub_type=='dragon'){
		$from_salesinvice='sales_invoice_dragon';
	}
		else if($log_sub_type=='uk'){
		$from_salesinvice='sales_invoice_uk';
	}
//print_r($from_salesinvice);exit();

// print_r('$sql2');
// exit(0);

$sql2=$this->db->query("SELECT * from ".$from_salesinvice." where si_current_sts='not-paid' and si_salesman='".$username_logged_in."' order by si_id limit 5 ");

$query_unpaid=$sql2->result_array();


$sql2=$this->db->query("SELECT * from ".$from_salesinvice." where si_current_sts='partially-paid' and si_salesman='".$username_logged_in."' order by si_id limit 5 ");

$query_partiallypaid=$sql2->result_array();

$sales_not_paid=array_merge($query_partiallypaid,$query_unpaid);
// print_r($sales_not_paid);
// exit(0);
$data['sales_not_paid']=$sales_not_paid;

//////////////////////////////testing //////////////////////////////////////////////////////////

$date=getdate();

$dayname = $date['weekday'];

 $monthname =$date['month'];
 $day=$date['mday'];
 $month=$date['mon'];

 $year = $date['year'];

 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////this the number of the day in week and the day in month so if we are in the first week in month we will not back to previous month but will calculate from 1 to 30  so if we are in th first 6 day we will calculate what in the current month or we will calculate from the second week/////////////////////


$data['num_day_of_week']=$date['wday'];

 if ($day<=7) {
$data['num_week_by_month']='First Week';
 $week_of_month='First Week';
 	//here to be sure if we in the first week in month
 		switch ($day) {
 			case '1':
 				$start_date_cond="$year-$month-$day";
 				$end_date_cond="$year-$month-$day";
 				break;
 				case '2':
                   $daydiff=$day-1;
 					$start_date_cond="$year-$month-$daydiff";
		              $end_date_cond="$year-$month-$day";
 				break;
 				case '3':
                   $daydiff=$day-2;
 					$start_date_cond="$year-$month-$daydiff";
		              $end_date_cond="$year-$month-$day";
 				break;
 				case '4':
                   $daydiff=$day-3;
 					$start_date_cond="$year-$month-$daydiff";
		              $end_date_cond="$year-$month-$day";
 				break;
 				case '5':
                   $daydiff=$day-4;
 					$start_date_cond="$year-$month-$daydiff";
		              $end_date_cond="$year-$month-$day";
 				break;
 				case '6':
                   $daydiff=$day-5;
 					$start_date_cond="$year-$month-$daydiff";
		              $end_date_cond="$year-$month-$day";
 				break;
 			
 			default:
 				// code...
 				break;
 		}
 	
 }
 else
 { 
 	////here we will check with the three week from mkonth
 	$number_day_inweek=$date['wday'];
switch ($number_day_inweek) {
	case '1':
		$start_date_cond="$year-$month-$day";
		break;
		case '2':
		$daydiff=$day-1;
			
		break;
		case '3':
		$daydiff=$day-2;
				
		break;
		case '4':
		$daydiff=$day-3;
				
		break;
	
		case '5':
		$daydiff=$day-4;
		
		break;
		case '6':
		$daydiff=$day-5;
		
		break;
		case '7':
		$daydiff=$day-6;
			
		break;
	
	default:
		break;
}
if ($day>7 && $day>=8) {
	if($day<=14 ) {
         $data['num_week_by_month']='Second Week';
         $week_of_month='Second Week';
	}
	else if($day<=21)
	{
		 $data['num_week_by_month']='Third Week';
		 $week_of_month='Third Week';	}
	else 
	{
		 $data['num_week_by_month']='Fourth Week';
		 $week_of_month='Fourth Week';
	}
	
}


$start_date_cond="$year-$month-$daydiff";
$end_date_cond="$year-$month-$day";

 }
///////////////detect the conditions for all query///////////////////

 /////////////detect the sales man register or login
$salesman=$this->session->userdata['user']['userlogid'];
$delivery_status='fully_returned';

//detect the conditions for wich table depending on sales man
 $sales_branch=$this->session->userdata['user']['sub_dept'];
if ($sales_branch=='ksa') {
	$from_table='sales_invoice_ksa';
}elseif ($sales_branch=='gcc'){
	$from_table='sales_invoice';
}

$currentdateday="$year-$month-$day";

////////////////day/////////////////////
$totaldayquery=$this->sbm->total_daily_target($currentdateday,$salesman_focus);
     $totalday=doubleval($totaldayquery[0]->total_amount_day); 

$data['totalday']=$totalday;

/////////////////////////////////////////////////////////////////
/////////////////////week////////////////////
//keep this for when you get the repoert from the invoice
// $sqlweek=$this->db->query("SELECT SUM(si_tot_amount) as total_bal_week from ".$from_table." where si_salesman='".$salesman."' and si_delivery_sts!='fully_returned' and si_date between '".$start_date_cond."' and '".$end_date_cond."'  ");

// $query_week=$sqlweek->result_array();

// $totalweek=doubleval($query_week[0]['total_bal_week']);
$condweekly="sbr_vou_date between '".$start_date_cond."' and '".$end_date_cond."' ";
$totalweekquery=$this->sbm->total_weekly_target($condweekly,$salesman_focus);
     $totalweek=doubleval($totalweekquery[0]->total_amount_week); 

$data['totalweek']=$totalweek;


if ($sales_branch=='ksa') {
	$startingday='Saturday';
	$endday='Thursday';
		// code...
	
}
else if ($sales_branch=='gcc'){
		$startingday=='Monday';
		$endday='Saturday';
	// code...
	
}


if ($dayname==$startingday) {


//$number_day_inweek_current=$date['wday'];

if ($day<=7) {






	if ($month==5||$month==7||$month==10||$month==12||$month==2) {

    $mon_prev=$month-1;
     $mont_current=$month;
      $Year_end=$year;
            $year_start=$year;
   switch ($day) {
		case '7':
			$day_start=30;
			$day_end=6;

			break;
			case '6':
			$day_start=29;
			$day_end=5;
			break;
			case '5':
			$day_start=28;
			$day_end=4;
			break;
			case '4':
			$day_start=27;
			$day_end=3;
			break;
			case '3':
			$day_start=26;
			$day_end=2;
			break;
			case '2':
			$day_start=25;
			$day_end=1;
			break;
		
			case '1':
			$day_start=24;
			$day_end=30;
			$mon_prev=$month-1;
         $mont_current=$month-1;
			break;
		
		
		default:
			// code...
			break;
	}

}
	
elseif ($month==8||$month==4||$month==6||$month==9||$month==11)
{
   $mon_prev=$month-1;
     $mont_current=$month;
      $Year_end=$year;
            $year_start=$year;
   switch ($day) {
case '7':
			$day_start=31;
			$day_end=6;

			break;
			case '6':
			$day_start=30;
			$day_end=5;
			break;
			case '5':
			$day_start=29;
			$day_end=4;
			break;
			case '4':
			$day_start=28;
			$day_end=3;
			break;
			case '3':
			$day_start=27;
			$day_end=2;
			break;
				case '2':
			$day_start=26;
			$day_end=1;
			break;
		
			case '1':
			$day_start=25;
			$day_end=31;
			 $mon_prev=$month2-1;
            $mont_current=$month2-1;
			break;
		
		default:
			// code...
			break;
	}
}


elseif ($month==3)
{
            $mon_prev=$month-1;
            $mont_current=$month;
             $Year_end=$year;
            $year_start=$year;
   switch ($day) {
   	case '7':
		$day_start=28;
			$day_end=6;
			
			break;
			case '6':
			$day_start=27;
			$day_end=5;
			 
			break;
			case '5':
			$day_start=26;
			$day_end=4;
			break;
			case '4':
			$day_start=25;
			$day_end=3;
			break;
			case '3':
			$day_start=24;
			$day_end=2;
			break;
				case '2':
			$day_start=23;
			$day_end=1;
			break;
		
			case '1':
			$day_start=22;
			$day_end=28;
			 $mon_prev=$month-1;
            $mont_current=$month-1;
			break;
		
		
		default:
			// code...
			break;
	}
}



	


elseif($month==1) {
	 $mon_prev=12;
            $mont_current=$month;
             $Year_end=$year;
            $year_start=$year;

   switch ($day) {
case '7':
			$day_start=31;
			$day_end=6;
			 $mon_prev=12;
          $mont_current=$month;
          $Year_end=$year;
          $year_start=$year-1;
			break;
			case '6':
			$day_start=30;
			$day_end=5;
			 $mon_prev=12;
            $mont_current=$month;
            $Year_end=$year;
            $year_start=$year-1;
			break;
			case '5':
			$day_start=29;
			$day_end=4;
			 $mon_prev=12;
            $mont_current=$month;
            $Year_end=$year;
            $year_start=$year-1;
			break;
			case '4':
			$day_start=28;
			$day_end=3;
			 $mon_prev=12;
            $mont_current=$month;
            $Year_end=$year;
            $year_start=$year-1;
			break;
			case '3':
			$day_start=27;
			$day_end=2;
			 $mon_prev=12;
            $mont_current=$month;
            $Year_end=$year;
            $year_start=$year-1;
			break;
				case '2':
			$day_start=26;
			$day_end=1;
			 $mon_prev=12;
            $mont_current=$month;
            $Year_end=$year;
            $year_start=$year-1;
			break;
		
			case '1':
			$day_start=25;
			$day_end=31;
			$mon_prev=12;
         $mont_current=$month;
         $Year_end=$year;
         $year_start=$year-1;
			break;
		
		default:
			// code...
			break;
	}
}



	
}
// ////else we are in the same month
else{
$year_start=$year;
$mon_prev=$month;
$day_start=$day-7;
$Year_end=$year;
$mont_current=$month;
$day_end=$day-1;
}


$start_date_cond_current="$year_start-$mon_prev-$day_start";

$end_date_cond_current="$Year_end-$mont_current-$day_end";


//keep this for when you get the repoert from the invoice
	// $sqlweek_current_emial=$this->db->query("SELECT SUM(si_tot_amount) as total_bal_week from ".$from_table." where si_salesman='".$salesman."' and si_delivery_sts!='fully_returned' and si_date between '".$start_date_cond."' and '".$end_date_cond."'  ");
//$query_weekforemail=$sqlweek_current_emial->result_array();
//$query_total_week_for_email=doubleval($query_weekforemail[0]['total_bal_week']);
$condweeklyemail="sbr_vou_date between '".$start_date_cond."' and '".$end_date_cond."' ";
$totalweekquerymail=$this->sbm->total_weekly_target($condweekly,$salesman_focus);
 $query_total_week_for_email=doubleval($totalweekquerymail[0]->total_amount_week); 


$data['total_bal_week_email']=$query_total_week_for_email;
 

}
else{}

///////////////////////////////////////////////////////////

///////////monthly//////////////////////////////////////
$firstday='1';
$end_date_cond_monthly="$year-$month-$day";
$start_date_cond_monthly="$year-$month-$firstday";
//keep this for when you get the repoert from the invoice
// $sqlmonth=$this->db->query("SELECT SUM(si_tot_amount) as total_bal_month from ".$from_table." where si_salesman='".$salesman."' and si_delivery_sts!='fully_returned' and si_date between '".$start_date_cond_monthly."' and '".$end_date_cond_monthly."'  ");
//$query_monthly=$sqlmonth->result_array();
//$totalmonth=doubleval($query_monthly[0]['total_bal_month']);

$condmonthely="sbr_vou_date between '".$start_date_cond_monthly."' and '".$end_date_cond_monthly."' ";

$totalmonthely=$this->sbm->total_monthely_target($condmonthely,$salesman_focus);

 $totalmonth=doubleval($totalmonthely[0]->total_amount_month); 

// print_r($totalmonth);
// exit();
$data['totalmonth']=$totalmonth;

///////////////////////////////////////////////////////////////////

///////////////////quarter  (we must divied our year to 4 part  |jan feb march | |april may june| | july aug  sep |  | Octobe november Dec  |  )  ///

if ($month==12||$month==11||$month==10) {
   $start_month_qu=10;////fourth quarter
   $data['current_quarter']='Fourth';
}
elseif ($month==9||$month==8||$month==7){
 $start_month_qu=7;	/////third quarter
 $data['current_quarter']='Third';
}
elseif ($month==6||$month==5||$month==4){
 $start_month_qu=4;///second qouarter 
 $data['current_quarter']='Second';
}
else{
 $start_month_qu=1;/////first qouarter
 $data['current_quarter']='First';

}
$f_d_q=1;
$end_date_cond_qouarter="$year-$month-$day";
 $start_date_cond_qouarter="$year-$start_month_qu-$f_d_q";
//keep this for when you get the repoert from the invoice
// $sqlqouarter=$this->db->query("SELECT SUM(si_tot_amount) as total_bal_qouarter from ".$from_table." where si_salesman='".$salesman."' and si_delivery_sts!='fully_returned' and si_date between '".$start_date_cond_qouarter."' and '".$end_date_cond_qouarter."'  ");

// $query_qouarter=$sqlqouarter->result_array();

$condqouarter="sbr_vou_date between '".$start_date_cond_qouarter."' and '".$end_date_cond_qouarter."' ";

$query_qouarter=$this->sbm->total_qouarter_target($condqouarter,$salesman_focus);

 $totalqouarter=doubleval($query_qouarter[0]->total_amount_qouarter); 


$data['totalqouarter']=$totalqouarter;

/////////////////////////////////////////////qouarter End/////////////////////////////////////////////////////////////////////////////////////////


///////now we will get  the target info dependeng on username and date 


$salesman_name=$this->session->userdata['user']['username'];



$alesmantargetsql=$this->db->query("SELECT *FROM sales_target WHERE st_sales_person='".$salesman_name."' and st_month='".$month."' and st_year='".$year."' and st_sts='1' ");

$checksalesman=$alesmantargetsql->result_array();

if ($checksalesman[0]!=''||$checksalesman[0]!='null') {

$monthely_requested_target=$checksalesman[0]['st_total_target'];
$data['monthely_requested_target']=$monthely_requested_target;
$quarter_requested_target=$checksalesman[0]['si_quarter_target'];

if ($quarter_requested_target==''||$quarter_requested_target=='null') {
	$quarter_requested_target=intval($monthely_requested_target*3);
	$data['quarter_requested_target']=$quarter_requested_target;
}
else{
	$quarter_requested_target=$checksalesman[0]['si_quarter_target'];
	$data['quarter_requested_target']=$quarter_requested_target;
}

}
else{
	$monthely_requested_target='0';$quarter_requested_target='0';
	$data['monthely_requested_target']=0;
	$data['quarter_requested_target']=0;
}

///this value for the level of the achivement monthly
$warning_value=doubleval($monthely_requested_target-($monthely_requested_target*0.15));
$dangerous_value=doubleval($monthely_requested_target-($monthely_requested_target*0.49));
$extra_value=doubleval($monthely_requested_target+($monthely_requested_target*0.05));
///weekly/////
$weekly_requested_target=doubleval($monthely_requested_target/4);
$data['weekly_requested_target']=$weekly_requested_target;
$warning_value_week=doubleval($weekly_requested_target-($weekly_requested_target*0.15));
$dangerous_value_week=doubleval($weekly_requested_target-($weekly_requested_target*0.49));
$extra_value_week=doubleval($weekly_requested_target+($weekly_requested_target*0.05));
///////
///daily////
$daily_requested_target=intval($monthely_requested_target/26);
$data['daily_requested_target']=$daily_requested_target;
$warning_value_daily=doubleval($daily_requested_target-($daily_requested_target*0.15));
$dangerous_value_daily=doubleval($daily_requested_target-($daily_requested_target*0.49));
$extra_value_daily=doubleval($daily_requested_target+($daily_requested_target*0.05));
/////
/////quarter////

$warning_value_quarter=doubleval($quarter_requested_target-($quarter_requested_target*0.15));
$dangerous_value_quarter=doubleval($quarter_requested_target-($quarter_requested_target*0.49));
$extra_value_quarter=doubleval($quarter_requested_target+($quarter_requested_target*0.05));
/////


if ($totalmonth>$extra_value) {
// print_r($totalmonth);
	  $data['monthly_status']='great';               


	// code...
}
else if ($totalmonth==$monthely_requested_target||$totalmonth>=$warning_value) {

// print_r($totalmonth);
	
	$data['monthly_status']='done';
	
	// code...
}
else if ($totalmonth<=$dangerous_value) {

// print_r($totalmonth);
	//print_r('your monthely target is so low dangerous');
	$data['monthly_status']='danger';
	
	// code...
}
else if ($totalmonth<$warning_value) {


	
	$data['monthly_status']='warning';
	

	// code...
}


if ($query_total_week_for_email>$extra_value_week) {




$weekly_email_result='You did Great Work this week by Achiveing Over Target ';

	// code...
}
else if ($query_total_week_for_email==$weekly_requested_target||$query_total_week_for_email>=$warning_value_week) {



	$weekly_email_result='You did Your Sales Target this week';
	

}
else if ($query_total_week_for_email<=$dangerous_value_week) {



		$weekly_email_result='Be Careful You are too Far from Achiveing the target So Make More Effort To Be Better';

}
else if ($query_total_week_for_email<$warning_value_week) {


	
	$weekly_email_result=' You are Close from Achiveing the target So Make More Effort To Be Better';


	
}



if ($totalweek>$extra_value_week) {



$data['weekly_status']='great';

}
else if ($totalweek==$weekly_requested_target||$totalweek>=$warning_value_week) {


	$data['weekly_status']='done';

	

}
else if ($totalweek<=$dangerous_value_week) {


	$data['weekly_status']='danger';
	

}
else if ($totalweek<$warning_value_week) {


	$data['weekly_status']='warning';
	


	
}







if ($totalday>$extra_value_daily) {

	$data['daily_status']='great';


}
else if ($totalday==$daily_requested_target||$totalday>=$warning_value_daily) {

	$data['daily_status']='done';

}
else if ($totalday<=$dangerous_value_daily) {

	$data['daily_status']='danger';

}
else if ($totalday<$warning_value_daily) {

	$data['daily_status']='warning';

}



switch ($month) {
	case '3':

$data['quarter_num']='First';
if ($totalqouarter>$extra_value_quarter) {

$data['quarter_status']='great';
	

}
else if ($totalqouarter==$quarter_requested_target||$totalqouarter>=$warning_value_quarter) {


	$data['quarter_status']='done';

}
else if ($totalqouarter<=$dangerous_value_quarter) {

	$data['quarter_status']='danger';
	
}
else if ($totalqouarter<$warning_value_quarter) {

	$data['quarter_status']='warning';
	
}


		break;
		case '6':
		

$data['quarter_num']='Second';
if ($totalqouarter>$extra_value_quarter) {




$data['quarter_status']='great';

	// code...
}
else if ($totalqouarter==$quarter_requested_target||$totalqouarter>=$warning_value_quarter) {

	$data['quarter_status']='done';

}
else if ($totalqouarter<=$dangerous_value_quarter) {

	$data['quarter_status']='danger';

}
else if ($totalqouarter<$warning_value_quarter) {

	$data['quarter_status']='warning';

}

		break;
		case '9':
		

$data['quarter_num']='Third';
if ($totalqouarter>$extra_value_quarter) {

$data['quarter_status']='great';

}
else if ($totalqouarter==$quarter_requested_target||$totalqouarter>=$warning_value_quarter) {

	$data['quarter_status']='done';

}
else if ($totalqouarter<=$dangerous_value_quarter) {

	$data['quarter_status']='danger';

}
else if ($totalqouarter<$warning_value_quarter) {

	$data['quarter_status']='warning';

}


		break;
		case '12':
	

$data['quarter_num']='Fourth';
if ($totalqouarter>$extra_value_quarter) {

$data['quarter_status']='great';

}
else if ($totalqouarter==$quarter_requested_target||$totalqouarter>=$warning_value_quarter) {

	$data['quarter_status']='done';

}
else if ($totalqouarter<=$dangerous_value_quarter) {

	$data['quarter_status']='danger';

}
else if ($totalqouarter<$warning_value_quarter) {

	$data['quarter_status']='warning';

}


		break;


	
	default:
	
$data['qouarter-early']='you are not in the last of quarter';

		break;
}

////////////////////////////////trying to send message to the users at the end of the week///////////////////////////////////


if ($sales_branch=='ksa') {
	$start_new_week='Saturday';
}elseif ($sales_branch=='gcc'){
	$start_new_week='Monday';
}

if ($dayname2==$start_new_week)
 {
 /////we must count the entries to send the email at the first time that user will log in to account
		$alesmantargetsql=$this->db->query("SELECT COUNT(id) as NumberOfentries from user_code where  user_id='".$salesman."' and datecreated like '%".$currentdateday."%' ");
		$query_count=$alesmantargetsql->result_array();

		$login_times=$query_count[0]['NumberOfentries'];

			if ($login_times<=1)
			 {


            $this->send_mail_weekly_Report($weekly_email_result,$weekly_requested_target,$query_total_week_for_email,$week_of_month,$monthname); 
			
		     
			
			}
			else{

					
				}




}

/////////////////////////////////end oftrying to send message to the users at the endof the week//////////////////////////////////////////



////////////////////////////////////end for get the values///////////////


















/////test to get the three report//
// if($dept_logged_in=="Sales" && $log_sub_type=="ksa")
// 	{

// 		 $data['total_sales_all_years']=$this->sbm->total_sales_all_years_ksa();
// 	}
// 	else 
// 	{
// 		$data['total_sales_all_years']=$this->sbm->total_sales_all_years();
// 	}









/////////////////////////end of testing/////////////////////////////////////////



           $this->send_mail_loguser();  

				$activitylogin_data=array(
				'page_user'=>$this->session->userdata['user']['username'],
				'user_activity'=>'User Logged',
				'page_userip'=>$this->session->userdata['user']['location_ip'],
				'page_pc'=>$this->session->userdata['user']['devicedetailsinfo'],
				'page_country'=>$this->session->userdata['user']['state'],
				'date_time_logged'=>get_date_time(),
			);
			   $this->Admin_model->insert_data('activitieslogin',$activitylogin_data);


			


   	// code...
////////////coding for sales return pending//////////////////////


///that for checking wich store should i redirect the user


    	$condretpending=array('srt_warehouse'=>$Pending_warehouse,'srt_po_sts'=>'1','srt_po_warehouserep'=>'1');

     $order_by=('srt_po_sts');
		$order_type="DESC";
		//$limit='10';
		//$dept=$this->session->userdata['user']['main_dept'];
		
		$data['return_result']=$this->Admin_model->get_srproduct_details('sales_return',$condretpending,'','',$order_by,$order_type);
	      if(!empty($data['return_result']))
       {
			foreach ($data['return_result'] as $index=>$val) 
			{
				$prd_id=explode('|#|',$val->srt_product);	

		 		$data['prd_data1'][]=$this->tm->prd_list_var($prd_id);
				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
		$data['new_return']=count($data['return_result']);
}else{}



////////////coding for sales return Approving/////////////////////


$condretapproving=array('srt_warehouse'=>$Approved_warehouse,'srt_po_sts'=>'1','srt_po_warehouserep'=>'2');


     $order_by=('srt_po_sts');
		$order_type="DESC";

$data['return_result_approve']=$this->Admin_model->get_srproduct_details('sales_return',$condretapproving,'','',$order_by,$order_type);


if(!empty($data['return_result_approve']))
		{
			foreach ($data['return_result_approve'] as $val) 
			{
				$prd_id=explode('|#|',$val->srt_product);	
		 		$data['prd_data2'][]=$this->tm->prd_list_var($prd_id);
				// $prd_id=explode('|#|',$val->po_prd_name);	
				// $data['prd_data1'][]=$this->tm->prd_var($prd_id);///getting product details	
			}
			// foreach ($data['result2'] as $val) 
			// {
			// 	$prd_id=explode('|#|',$val->po_prd_name);	
			// 	$data['prd_data2'][]=$this->tm->prd_var($prd_id);///getting product details	
			// }
			$data['approved_return']=count($data['return_result_approve']);
		}
		else{}




	if( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Sales") )
	{
		$cond_user=array('sca_staff_id'=>($this ->session->userdata['user']['username']) );
	}
	else
	{
		$cond_user='';
	}
	
	$select=('COUNT(sca_id) as row_count');	
$data['cust_count']=$this->Admin_model->sales_custmr_count($select,$cond_user,'');

$select1=('COUNT(sca_id) as row_count');
$group_by=('sca_cust_country');
$country_count = $this->Admin_model->sales_custmr_count($select1,$cond_user,$group_by);

$select2=('COUNT(sca_id) as row_count,country_val.name,country_val.code');
$group_by=('sca_cust_country');
$join=('country_val');
$join_cond=
('country_val.country_id=sales_customer_entry.sca_cust_country');
$join_type=('left');
$data['pie_result']=$this->Admin_model->sales_custmr_count($select2,$cond_user,$group_by,$join,$join_cond,$join_type);


$data['country_count']=count($country_count);	

if( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Sales") )
	{
		$cond_po=array('po_sales_person'=>($this->session->userdata['user']['username']));

		$main_fact_total_orders=$this->tm->get_po_details_main_fact('prd_order',$cond_po,'','','','');

		$traffic_sign_total_orders=$this->tm->get_po_details_tx_sign('prd_order',$cond_po,'','','','');

		$data['total_po']=$main_fact_total_orders+$traffic_sign_total_orders;
		/////////////////////end total orders/////////

		$cond_po_11=array('po_sales_person'=>($this->session->userdata['user']['username']),'po_order_status_fact'=>'5');

		$main_fact_total_delivered=$this->tm->get_po_details_main_fact('prd_order',$cond_po_11);

		$cond_po_12=array('po_sales_person'=>($this->session->userdata['user']['username']),'po_order_status_adv'=>'5');

		$traffic_sign_total_delivered=$this->tm->get_po_details_tx_sign('prd_order',$cond_po_12);

		$data['total_po_delivered']=$main_fact_total_delivered+$traffic_sign_total_delivered;
			/////////////////////end total delivered/////////

		$cond_po_21=array('po_sales_person'=>($this->session->userdata['user']['username']),'po_order_status_fact'=>'0');

		$main_fact_total_rejected=$this->tm->get_po_details_main_fact('prd_order',$cond_po_21);

		$cond_po_22=array('po_sales_person'=>($this->session->userdata['user']['username']),'po_order_status_adv'=>'0');

		$traffic_sign_total_rejected=$this->tm->get_po_details_tx_sign('prd_order',$cond_po_22);

		$data['total_po_rejected']=$main_fact_total_rejected+$traffic_sign_total_rejected;

		/////////////////////end total rejected/////////
	
	}
	else
	{
		//$cond_user='';
		$main_fact_total_orders=$this->tm->get_po_details_main_fact('prd_order');

		$traffic_sign_total_orders=$this->tm->get_po_details_tx_sign('prd_order');

		$data['total_po']=$main_fact_total_orders+$traffic_sign_total_orders;
		/////////////////////end total orders/////////

		$cond_po_11=array('po_order_status_fact'=>'5');

		$main_fact_total_delivered=$this->tm->get_po_details_main_fact('prd_order',$cond_po_11);

		$cond_po_12=array('po_order_status_adv'=>'5');

		$traffic_sign_total_delivered=$this->tm->get_po_details_tx_sign('prd_order',$cond_po_12);

		$data['total_po_delivered']=$main_fact_total_delivered+$traffic_sign_total_delivered;
			/////////////////////end total delivered/////////

		$cond_po_21=array('po_order_status_fact'=>'0');

		$main_fact_total_rejected=$this->tm->get_po_details_main_fact('prd_order',$cond_po_21);

		$cond_po_22=array('po_order_status_adv'=>'0');

		$traffic_sign_total_rejected=$this->tm->get_po_details_tx_sign('prd_order',$cond_po_22);

		$data['total_po_rejected']=$main_fact_total_rejected+$traffic_sign_total_rejected;

		/////////////////////end total rejected/////////
	}
	


$this->load->view('admin/sales/sales_dashboard',$data,$datt);

}

else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}


}
}




function approve_return()
	{
	if(logged_in())
		{
		$srt_id=$this->input->post('srt_id');

		$srt_details=$this->Admin_model->get_data('sales_return',array('srt_id'=>$srt_id));

		
		$dept_name=$this->session->userdata['user']['main_dept'];
		
	
		$return_result_approve=array('srt_po_warehouserep'=>'2');
		
		//$mail_data=array(
			//'srt_id'=>$srt_id,
		//);
		//$mail_info=send_po_approved_mail($mail_data);
		
		//$mail_info=send_srt_sts_mail($srt_id,'Approved');
		
		//print_r($mail_info);

		//if($mail_info==1)
	//{
			$cond2=array('srt_id'=>$srt_id);
		$this->Admin_model->update_data('sales_return',$return_result_approve,$cond2);
		$data_activity=array(
		'act_function'=>'sales return Approved',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_po_id'=>$srt_id,
		'act_status'=>'approved',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);	

		//echo true;
		//}
		//else{
			
		//	echo false;
		//}
		
		}
	}


function send_mail_loguser()
{
	     $this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
         $config['smtp_crypto'] = 'tls'; 
         $config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

$page_user= $this->session->userdata['user']['username'];
//$page_userip=$this->session->userdata['user']['location_ip'];

$page_userip=$this->session->userdata['user']['ipsession'];
$page_serverip= $this->session->userdata['user']['server_ip'];
$page_email=$this->session->userdata['user']['user_email'];
$page_pc=$this->session->userdata['user']['computername'];
$page_state=$this->session->userdata['user']['state'];
$page_country=$this->session->userdata['user']['country'];
$page_cityserverprovider=$this->session->userdata['user']['cityserverprovider'];
$page_hostname=$this->session->userdata['user']['hostname'];
$page_lat=$this->session->userdata['user']['user_lat'];
$user_long=$this->session->userdata['user']['user_long'];
  
$user_serverorg=$this->session->userdata['user']['user_serverorg'];

$browsername=$this->session->userdata['user']['browsername'];
$browserversion=$this->session->userdata['user']['browserversion'];
$operatingsystem=$this->session->userdata['user']['operatingsystem'];


$devicedetailsinfo=$this->session->userdata['user']['devicedetailsinfo'];
$ipsession=$this->session->userdata['user']['ipsession'];
// $mobile=$this->session->userdata['user']['mobile'];
$date_time=get_date_time();

// print_r($page_email);
// exit(0);


     
          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to("support@birigroup.com");
          $this->email->to($page_email);    

          $this->email->subject('Loggedin Activity Happend :');
		 $msg="Dear ".$page_user.", <br/> Your Account Loggedin From Device Below  <br/><br/>";

		 $msg.="You Loggedin From  :  "  .$page_country."<br/><br/>";
		  $msg.="State :  "  .$page_state."<br/><br/>";
		  $msg.="Using IP Adress :  "  .$ipsession."<br/><br/>";
	
		  $msg.="from Device :  "  .$devicedetailsinfo." on server  " .   $page_pc  .     "<br/><br/>";
		  $msg.="Operating System:  "  .$operatingsystem.  "  <br/><br/>";
        $msg.="Browser:  ".$browsername." Version :  " .$browserversion. "  <br/><br/>";

         $msg.="Server Provider :  "  .$user_serverorg."<br/><br/>";

          $msg.="Host Name :  "  .$page_hostname."<br/><br/>";
           $msg.="Latitude :  "  .$page_lat. "<br/><br/>"; 
           $msg.="Longtude :  "  .$user_long. "<br/><br/>";        
                       
        
		  $msg.="Login date  :  "  .$date_time."<br/><br/>";
		
		  $msg.="<br/><br/>";
 $msg.="Thank you!<br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}




function send_mail_weekly_Report($weekly_email_result,$weekly_requested_target,$query_total_week_for_email,$week_of_month,$monthname)
{
	     $this->load->library('email');
        //$config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
         $config['smtp_crypto'] = 'tls'; 
         $config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

$date_time=get_date_time();
$page_user= $this->session->userdata['user']['username'];
$page_email=$this->session->userdata['user']['user_email'];
// print_r($page_email);
// exit(0);


     
          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to($page_email);    

          $this->email->subject('Weekly Target Report');


		   // $msg="Dear ".$page_user.", <br/> Your Weekly Target Details For ".$week_of_month." Of ".$monthname." is : <br/><br/>";

		     
         $msg="Dear ".$page_user.", <br/> Your Weekly Target Details For the last Week is : <br/><br/>"; 
        
		  $msg.="Weekly requested target  :  ".$weekly_requested_target."<br/><br/>";
		  $msg.="Weekly Achivement  :  "  .$query_total_week_for_email."<br/><br/>";

		   $msg.="$weekly_email_result";
		
		  $msg.="<br/><br/>";$msg.="<br/><br/>";$msg.="<br/><br/>";

         $msg.="in case of any Problem with the Report Please Contact With IT Department <br/><br/>";

       	$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";

        $msg.="Thank you!<br/><br/>";


		
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}










}






