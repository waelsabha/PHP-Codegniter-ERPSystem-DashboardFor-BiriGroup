<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_target extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper('session');	
		$this->load->model(array('Second_db_model','Sales_book_model'));
	}

function add_sales_target($trg_id=null)
{
	if(logged_in())
	{

   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='add-sales-target')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

		$data['salesperson']=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales','log_status'=>'1'));

		if(empty($trg_id))
		$this->load->view('admin/sales/add_target',$data);
		else
		{
			$data['result']=$this->Admin_model->get_data('sales_target',array('st_sts'=>'1','st_id'=>$trg_id));
			$this->load->view('admin/sales/add_target',$data);
		}


    }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


	}
}


function list_sales_target()
{
	if(logged_in())
	{

  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='list-sales-target')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {


		$data['result']=$this->Admin_model->get_data('sales_target',array('st_sts'=>'1'));
		$this->load->view('admin/sales/list_target',$data);

  }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


		
	}
}

function submit_sales_target()
{
	 $this->form_validation->set_rules('st_sales_person', 'Salesperson', 'trim');
	$this->form_validation->set_rules('st_month', 'Month', 'trim');
	$this->form_validation->set_rules('st_total_target', 'Total Target ', 'trim');
	$this->form_validation->set_rules('si_quarter_target', 'Target quarter suggest', 'trim');
	
	 if ($this->form_validation->run() == FALSE)
        {          
        	$this->session->set_flashdata('st_sales_person', form_error('st_sales_person'));
		$this->session->set_flashdata('st_month',form_error('st_month'));
		$this->session->set_flashdata('st_total_target',form_error('st_total_target'));
		$this->session->set_flashdata('si_quarter_target', form_error('si_quarter_target'));
		redirect('add-sales-target','refersh');
        }
        else
        {
        	$tz = 'Asia/Dubai'; // your required location time zone.
			$timestamp = time();
			$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
			$dt->setTimestamp($timestamp);
			$current_year=$dt->format('Y');

////////////////////////////////////////////////this for check if there is sales target for this month before then we will update the statue of the old to disabled///////////////////////////////////////////////////////////////////////////////////////////////

$sales_person=$this->input->post('st_sales_person');
$sales_month=$this->input->post('st_month');


$alesmantargetsql=$this->db->query("SELECT *FROM sales_target WHERE st_sales_person='".$sales_person."' and st_month='".$sales_month."' and st_year='".$current_year."' and st_sts='1' ");

$checksalesman=$alesmantargetsql->result_array();

if ($checksalesman[0]!=''||$checksalesman[0]!='null') {


	$insert_id=$this->Admin_model->update_data('sales_target',array('st_sts'=>'0'),array('st_id'=>$checksalesman[0]['st_id']));



	// code...
}
else{

}

              

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        	 $data=array(
           	'st_sales_person'=>$this->input->post('st_sales_person'),
            'st_month'=>$this->input->post('st_month'),
            'st_year'=>$current_year,
           	'st_total_target'=>$this->input->post('st_total_target'),
           	'si_quarter_target'=>$this->input->post('si_quarter_target'),
           	'st_sts'=>'1'
           );

        	 $edit_target_id=$this->input->post('edit_target_id');

        	 if(empty($edit_target_id))
        	 {
        	 $insert_id=$this->Admin_model->insert_data('sales_target',$data);
        	  $this->session->set_flashdata('success', 'Data Successfully inserted');
        	  }
        		else
        		{
        		$insert_id=$this->Admin_model->update_data('sales_target',$data,array('st_id'=>$edit_target_id));
        		 $this->session->set_flashdata('success', 'Data Successfully edited');
        		}	
        	
        	 redirect('list-sales-target');
        }
}


function delete_target_details($trg_id=null)
{
	$insert_id=$this->Admin_model->update_data('sales_target',array('st_sts'=>'0'),array('st_id'=>$trg_id));
        		 $this->session->set_flashdata('success', 'Data Successfully deleted');
        		  redirect('list-sales-target');
}
























































































}