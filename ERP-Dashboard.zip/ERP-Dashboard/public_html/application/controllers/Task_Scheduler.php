<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task_Scheduler extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','mail_task_request'));	
		$this->load->library('numbertowordconvertsconver');			
		$this->load->model(array('Second_db_model','Sales_book_model','Item_request_model'));
		$this->load->model('Third_db_model','tm');
	
	}


function add_task_request($t_id=null,$page_name=null)
{
if(logged_in())
	{

$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);

$sub_dept=$this->session->userdata['user']['sub_dept'];
// print_r($sub_dept);
// exit(0);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='add_task_request'||($this ->session->userdata['user']['main_dept'])=="Main")
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


 
      ///this for user have account in dashboard from table
		//$data['usersdata']=$this->Admin_model->get_data('login_credentials',array('log_status'=>'1'));

  $con=' et_sts=1 and   ed_login_id > 0 ';
		//this for user that we need more information about him like code or detailed name
		$data['usersmoreinfo']=$this->Admin_model->get_data('tbl_emp_tree', $con);


  

	$val_task_req=$this->Admin_model->get_data('task_scheduler',array('t_enable'=>'1'),'','','t_id','DESC');
	if(empty($val_task_req))
	$data['task_id']='1';
	else
	{
	$bal_string1= $val_task_req[0]->t_id;

           $new_id_1=($bal_string1)+1;
            $data['task_id']=$new_id_1;

	}

	if(empty($t_id))
		{

			$this->load->view('admin/tasks/add_task_request',$data);
		}
	else
		{

			$data['result']=$this->Admin_model->get_data('task_scheduler',array('t_id'=>$t_id));
			$users_ids=explode('|#|', $data['result'][0]->t_to_group);
				 foreach($users_ids as $uid)
				 {
				 	$data['users'][]=$this->Admin_model->get_data('login_credentials',array('log_id'=>$uid));
				 	$data['usersinfo'][]=$this->Admin_model->get_data('tbl_emp_tree',array('ed_login_id'=>$uid));
				 }

			$this->load->view('admin/tasks/add_task_request',$data);
		}
 
	
}
   else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	  	} 




	}


}

function add_item_request_ksa($ir_id=null,$page_name=null)
{
if(logged_in())
	{

$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);

$sub_dept=$this->session->userdata['user']['sub_dept'];
// print_r($sub_dept);
// exit(0);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='add_item_request_ksa')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {




		$data['products']=$this->tm->get_data('products',array('p_sts'=>'1'));



		$val_task_req=$this->Admin_model->get_data('ksa_item_request',array('ir_sts'=>'1'),'','','ir_id','DESC');
			if(empty($val_task_req))
			$data['task_id']='K-IR1000';
			else
			{
			$bal_string1=str_replace("K-IR", "", $val_task_req[0]->ir_req_no);
			//print_r($bal_string1);
		           $new_id_1=($bal_string1)+1;
		            $data['task_id']="K-IR".$new_id_1;
			}

			if(empty($ir_id))
				{
					$this->load->view('admin/sales/add_item_request_ksa',$data);
				}
			else
				{
					$data['result']=$this->Admin_model->get_data('ksa_item_request',array('ir_id'=>$ir_id));
					$prd_ids=explode('|#|', $data['result'][0]->ir_prd_id);
						 foreach($prd_ids as $pid)
						 {
						 	$data['prds'][]=$this->tm->get_data('products',array('pid'=>$pid));
						 }

					$this->load->view('admin/sales/add_item_request_ksa',$data);
				}

}
   else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	  	} 




	}


}



function indextask()
{  

  if(logged_in())
	{   

    $user_id_task=$this->session->userdata['user']['userlogid'];

		if($this->session->userdata['user']['main_dept']=="Main")
		{
			
	 			$sql1=$this->db->query("SELECT * FROM task_scheduler where t_enable='1'  and t_user_created='".$this->session->userdata['user']['username']."' or t_to_group LIKE '%".$user_id_task."%'  order by t_id desc");
				 $data['result']=$sql1->result_array();
	 		
 		}
		 else
		 {


        $sql1=$this->db->query("SELECT * FROM task_scheduler where t_enable='1' and t_to_group LIKE '%".$user_id_task."%'   order by t_id desc");

         $data['result']=$sql1->result_array();

		 }
 
		
		 $data['proceccing_task']=$this->Admin_model->record_count2('task_scheduler',array('t_status'=>'1','t_enable'=>'1'));
		  $data['postponent_task']=$this->Admin_model->record_count2('task_scheduler',array('t_status'=>'2','t_enable'=>'1'));
		   $data['Canceled_task']=$this->Admin_model->record_count2('task_scheduler',array('t_status'=>'3','t_enable'=>'1'));
		    $data['Done_task']=$this->Admin_model->record_count2('task_scheduler',array('t_status'=>'4','t_enable'=>'1'));
		     

 	$this->load->view('admin/tasks/list_task_request',$data);
 	}
 	   else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	  	} 
}

function list_completed_item_request()
{

	// print_r('hello');
	// exit(0);
	if(logged_in())
	{
        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		 $cred_count=count($page_cred);
        $sub_dept=$this->session->userdata['user']['sub_dept'];

        for($i=0;$i<$cred_count;$i++)
        {
         	if ($page_cred[$i]=='list-completed-item-request')
         	{
	            $excist=true;
               $i=$cred_count;
         	}	

           else
            	{$excist=false;}

        }
       if ($excist) {





		     if($this->session->userdata['user']['main_dept']=="Sales")
		    {
				        	if($this->session->userdata['user']['user_desig']=="Team-lead")
					    {


						 if ($sub_dept=='ksa') {


							      $sql1=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and ir_req_status='7' order by ir_id desc");
					    	}

					    	else{

						       	$sql1=$this->db->query("SELECT * FROM item_request where ir_sts='1' and ir_req_status='7' order by ir_id desc");
						      }
						
						          $data['result']=$sql1->result_array();
				    	}









      //////that for sales dubaidirect warehouse 

		 		    	else
			 	    	{

			 			if ($sub_dept=='ksa') {

			 					$sql1=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and ir_req_status='7' and ir_user_created='".$this->session->userdata['user']['username']."'  order by ir_id desc");

			 					 $data['result']=$sql1->result_array();
		              }
		                      


                            else if($this->session->userdata['user']['log_designation']=="Dubai_Direct")
		                      
                           {

		                          $sqlksa=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and request_type='dubai supply' and ir_req_status='7'   order by ir_id desc");

				 		          	    $sql1=$this->db->query("SELECT * FROM item_request where ir_sts='1' and ir_req_status='7' and  ir_user_created='".$this->session->userdata['user']['username']."'  order by ir_id desc");
			        
				             
				         
				                     $data['result1']=$sql1->result_array();
				                     //$data['resultksa']=$sqlksa->result_array();

				                     $data['result'] = array_merge($data['result1'], $data['resultksa']);

		              }
			 		
						
			 			//$data['result']= $this->Admin_model->get_data('item_request',array('ir_sts'=>'1','ir_user_created'=>$this->session->userdata['user']['username'],'ir_req_status !='=>'7','ir_req_status !='=>'6'),'','','ir_id','DESC');
			 		}
 		}


 		// if you purchase or manager 
		 else
		 {

		 		if ($sub_dept=='ksa') {

                 	$sql1=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and ir_req_status='7'   order by ir_id desc");
                 	 $data['result']=$sql1->result_array();

		 		}


                      else if($this->session->userdata['user']['main_dept']=="Purchase")
                     {

						         $sql1=$this->db->query("SELECT * FROM item_request where ir_sts='1' and ir_req_status='7'   order by ir_id desc");
						         $sqlksa=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and request_type='direct import' and ir_req_status='7'   order by ir_id desc");
						      
						        $data['result1']=$sql1->result_array();
						        $data['resultksa']=$sqlksa->result_array();

						       $data['result'] = array_merge($data['result1'], $data['resultksa']);

                     }


                    else {
                               $sql1=$this->db->query("SELECT * FROM item_request where ir_sts='1' and ir_req_status='7'   order by ir_id desc");
						         $sqlksa=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and ir_req_status='7'   order by ir_id desc");
						      
						        $data['result1']=$sql1->result_array();
						        $data['resultksa']=$sqlksa->result_array();

						       $data['result'] = array_merge($data['result1'], $data['resultksa']);

                    }
	

		 }
 
		 foreach($data['result'] as $index=>$t)
		 {


		 	///// for sales employee even ksa or uae 
		 	if($this->session->userdata['user']['main_dept']=="Sales")
		 	{

		 		////if only ksa request wasim
		 		if ($sub_dept=='ksa') {

		 		$data['req_reply'][]=$this->Admin_model->get_data('ksa_item_req_content',array('itr_req_id'=>$t['ir_id']));

		 	}

		 	//////if not ksa but direct dubai or direct importmahmoud because he is sales in uae
		 	      else
                  {
                  		
                       
                       $data['req_replyksa'][]=$this->Admin_model->get_data('ksa_item_req_content',array('itr_req_id'=>$t['ir_id']));
                       $data['req_replyuae'][]=$this->Admin_model->get_data('item_req_content',array('itr_req_id'=>$t['ir_id']));
                      

                       $data['req_reply'][]=array_merge($data['req_replyksa'],  $data['req_replyuae']);
                

                  }








		 	}

		 
		 $prd_ids=explode('|#|', $t['ir_prd_id']);
		 	foreach($prd_ids as $pid)
		 	{
		 
		 	$data['prds'][$index][]=$this->tm->get_data('products',array('pid'=>$pid));
		 	}
		 }

		 
		 $data['page_type']='completed';

////////now we need to test all situation started with ksa 




  ////for if you wasim ksa manager 

	 		if ($sub_dept=='ksa') {
		 			
					  $data['new_req']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
					  $data['approved_req']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'2','ir_sts'=>'1'));
					   $data['req_ordered']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
					    $data['ready_ship']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'4','ir_sts'=>'1'));
					     $data['shipped']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
					      $data['completed']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'7','ir_sts'=>'1'));
					        $data['rejected']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'6','ir_sts'=>'1'));
					       

		 		}

		 		////now for direct import showing 


 else if($this->session->userdata['user']['log_designation']=="Dubai_Direct")

       {

          
            $data['new_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'1','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['approved_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'2','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['req_ordered_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'3','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['ready_ship_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'4','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['shipped_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'5','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['completed_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'7','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['rejected_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'6','ir_sts'=>'1','request_type'=>'dubai supply'));



			      $data['new_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
			      $data['approved_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'2','ir_sts'=>'1'));
			      $data['req_ordered_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
			      $data['ready_ship_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'4','ir_sts'=>'1'));
			      $data['shipped_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
			      $data['completed_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'7','ir_sts'=>'1'));
			      $data['rejected_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'6','ir_sts'=>'1'));

               

               $data['new_req']=$data['new_req_ksa']+$data['new_req_uae'];
			      $data['approved_req']=$data['approved_req_ksa']+$data['approved_req_uae'];
			      $data['req_ordered']=$data['req_ordered_ksa']+ $data['req_ordered_uae'];
			      $data['ready_ship']=$data['ready_ship_ksa']+$data['ready_ship_uae'];
			      $data['shipped']=$data['shipped_ksa']+ $data['shipped_uae'];
			      $data['completed']=$data['completed_ksa']+$data['completed_uae'];
			      $data['rejected']=$data['rejected_ksa']+$data['rejected_uae'];

            
       }


        /////if purchase meriel for direct import 
       else if($this->session->userdata['user']['main_dept']=="Purchase"){


                   $data['new_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'1','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['approved_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'2','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['req_ordered_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'3','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['ready_ship_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'4','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['shipped_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'5','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['completed_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'7','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['rejected_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'6','ir_sts'=>'1','request_type'=>'direct import'));



			      $data['new_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
			      $data['approved_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'2','ir_sts'=>'1'));
			      $data['req_ordered_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
			      $data['ready_ship_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'4','ir_sts'=>'1'));
			      $data['shipped_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
			      $data['completed_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'7','ir_sts'=>'1'));
			      $data['rejected_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'6','ir_sts'=>'1'));

               $data['new_req']=$data['new_req_ksa']+  $data['new_req_uae'];
			      $data['approved_req']=$data['approved_req_ksa']+  $data['approved_req_uae'];
			      $data['req_ordered']=$data['req_ordered_ksa']+  $data['req_ordered_uae'];
			      $data['ready_ship']=$data['ready_ship_ksa']+  $data['ready_ship_uae'];
			      $data['shipped']=$data['shipped_ksa']+  $data['shipped_uae'];
			      $data['completed']=$data['completed_ksa']+  $data['completed_uae'];
			      $data['rejected']=$data['rejected_ksa']+ $data['rejected_uae'];


      
       }
       ///////for management every thing will show 
       else if($this->session->userdata['user']['main_dept']=="Main") {

          $data['new_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
		      $data['approved_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'2','ir_sts'=>'1'));
		      $data['req_ordered_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
		      $data['ready_ship_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'4','ir_sts'=>'1'));
		      $data['shipped_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
		      $data['completed_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'7','ir_sts'=>'1'));
		      $data['rejected_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'6','ir_sts'=>'1'));



			      $data['new_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
			      $data['approved_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'2','ir_sts'=>'1'));
			      $data['req_ordered_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
			      $data['ready_ship_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'4','ir_sts'=>'1'));
			      $data['shipped_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
			      $data['completed_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'7','ir_sts'=>'1'));
			      $data['rejected_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'6','ir_sts'=>'1'));

               $data['new_req']=$data['new_req_ksa']+  $data['new_req_uae'];
			      $data['approved_req']=$data['approved_req_ksa']+  $data['approved_req_uae'];
			      $data['req_ordered']=$data['req_ordered_ksa']+  $data['req_ordered_uae'];
			      $data['ready_ship']=$data['ready_ship_ksa']+  $data['req_replyuae'];
			      $data['shipped']=$data['shipped_ksa']+  $data['shipped_uae'];
			      $data['completed']=$data['completed_ksa']+  $data['completed_uae'];
			      $data['rejected']=$data['rejected_ksa']+  $data['rejected_uae'];
       }
              
                else{}


 	  $this->load->view('admin/tasks/index',$data);








   }
   else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	  	} 



 	}
}

function list_rejected_item_request()
{
	if(logged_in())
	{

    $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		 $cred_count=count($page_cred);

$sub_dept=$this->session->userdata['user']['sub_dept'];
        for($i=0;$i<$cred_count;$i++)
        {
         	if ($page_cred[$i]=='list-rejected-item-request')
         	{
	$excist=true;
               $i=$cred_count;
         	}	

           else
            	{$excist=false;}

        }
       if ($excist) {


			if($this->session->userdata['user']['main_dept']=="Sales")
		{
			if($this->session->userdata['user']['user_desig']=="Team-lead")
			{

        	 if ($sub_dept=='ksa') {


							    $sql1=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and ir_req_status='6' order by ir_id desc");
					    	}

					    	else{

						       $sql1=$this->db->query("SELECT * FROM item_request where ir_sts='1' and ir_req_status='6' order by ir_id desc");
						      }
						
						          $data['result']=$sql1->result_array();

			}







 			else
	 		{
               
			 			if ($sub_dept=='ksa') {

			 					$sql1=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and ir_req_status='6' and ir_user_created='".$this->session->userdata['user']['username']."'  order by ir_id desc");

			 					 $data['result']=$sql1->result_array();
		              }
		                      


                            else if($this->session->userdata['user']['log_designation']=="Dubai_Direct")
		                      
                           {

		                          $sqlksa=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and request_type='dubai supply' and ir_req_status='6'   order by ir_id desc");

				 		          	    $sql1=$this->db->query("SELECT * FROM item_request where ir_sts='1' and ir_req_status='6' and ir_user_created='".$this->session->userdata['user']['username']."'  order by ir_id desc");

			        
				              
				         
				                     $data['result1']=$sql1->result_array();
				                     $data['resultksa']=$sqlksa->result_array();

				                     $data['result'] = array_merge($data['result1'], $data['resultksa']);

		              }
			 	

	 		}












 		}


 		////if not sales then purchase or manager 

		 else
		 {
                  
		 		if ($sub_dept=='ksa') {

                 	$sql1=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and ir_req_status='6'   order by ir_id desc");
                 	 $data['result']=$sql1->result_array();

		 		}


                      else if($this->session->userdata['user']['main_dept']=="Purchase")
                     {

						         $sql1=$this->db->query("SELECT * FROM item_request where ir_sts='1' and ir_req_status='6'   order by ir_id desc");
						         $sqlksa=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and request_type='direct import' and ir_req_status='6'   order by ir_id desc");
						      
						        $data['result1']=$sql1->result_array();
						        $data['resultksa']=$sqlksa->result_array();

						       $data['result'] = array_merge($data['result1'], $data['resultksa']);

                     }


                    else {
                               $sql1=$this->db->query("SELECT * FROM item_request where ir_sts='1' and ir_req_status='6'   order by ir_id desc");
						         $sqlksa=$this->db->query("SELECT * FROM ksa_item_request where ir_sts='1' and ir_req_status='6'   order by ir_id desc");
						      
						        $data['result1']=$sql1->result_array();
						        $data['resultksa']=$sqlksa->result_array();

						       $data['result'] = array_merge($data['result1'], $data['resultksa']);

                    }

		 	
		
		 }


 
		 foreach($data['result'] as $index=>$t)
		 {
			 	 	///// for sales employee even ksa or uae 
			 	if($this->session->userdata['user']['main_dept']=="Sales")
			 	{

			 		////if only ksa request wasim
			 		if ($sub_dept=='ksa') {

			 		$data['req_reply'][]=$this->Admin_model->get_data('ksa_item_req_content',array('itr_req_id'=>$t['ir_id']));

			 	}

		 	//////if not ksa but direct dubai or direct importmahmoud because he is sales in uae
		 	      else
                  { 
                       $data['req_replyksa'][]=$this->Admin_model->get_data('ksa_item_req_content',array('itr_req_id'=>$t['ir_id']));
                       $data['req_replyuae'][]=$this->Admin_model->get_data('item_req_content',array('itr_req_id'=>$t['ir_id']));
                      
                       $data['req_reply'][]=array_merge($data['req_replyksa'],  $data['req_replyuae']);
                  }

				 	}

				 
				 $prd_ids=explode('|#|', $t['ir_prd_id']);
				 	foreach($prd_ids as $pid)
				 	{
				 
				 	$data['prds'][$index][]=$this->tm->get_data('products',array('pid'=>$pid));
				 	}
		 }






		  $data['page_type']='rejected';


		 
	 		if ($sub_dept=='ksa') {
		 			
					  $data['new_req']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
					  $data['approved_req']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'2','ir_sts'=>'1'));
					   $data['req_ordered']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
					    $data['ready_ship']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'4','ir_sts'=>'1'));
					     $data['shipped']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
					      $data['completed']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'7','ir_sts'=>'1'));
					        $data['rejected']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'6','ir_sts'=>'1'));
					       

		 		}

		 		////now for direct import showing 


 else if($this->session->userdata['user']['log_designation']=="Dubai_Direct")

       {

          
            $data['new_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'1','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['approved_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'2','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['req_ordered_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'3','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['ready_ship_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'4','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['shipped_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'5','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['completed_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'7','ir_sts'=>'1','request_type'=>'dubai supply'));
		      $data['rejected_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'6','ir_sts'=>'1','request_type'=>'dubai supply'));



			      $data['new_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
			      $data['approved_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'2','ir_sts'=>'1'));
			      $data['req_ordered_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
			      $data['ready_ship_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'4','ir_sts'=>'1'));
			      $data['shipped_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
			      $data['completed_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'7','ir_sts'=>'1'));
			      $data['rejected_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'6','ir_sts'=>'1'));

               

               $data['new_req']=$data['new_req_ksa']+$data['new_req_uae'];
			      $data['approved_req']=$data['approved_req_ksa']+$data['approved_req_uae'];
			      $data['req_ordered']=$data['req_ordered_ksa']+ $data['req_ordered_uae'];
			      $data['ready_ship']=$data['ready_ship_ksa']+$data['ready_ship_uae'];
			      $data['shipped']=$data['shipped_ksa']+ $data['shipped_uae'];
			      $data['completed']=$data['completed_ksa']+$data['completed_uae'];
			      $data['rejected']=$data['rejected_ksa']+$data['rejected_uae'];

            
       }


        /////if purchase meriel for direct import 
       else if($this->session->userdata['user']['main_dept']=="Purchase"){


                   $data['new_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'1','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['approved_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'2','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['req_ordered_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'3','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['ready_ship_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'4','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['shipped_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'5','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['completed_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'7','ir_sts'=>'1','request_type'=>'direct import'));
		      $data['rejected_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'6','ir_sts'=>'1','request_type'=>'direct import'));



			      $data['new_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
			      $data['approved_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'2','ir_sts'=>'1'));
			      $data['req_ordered_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
			      $data['ready_ship_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'4','ir_sts'=>'1'));
			      $data['shipped_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
			      $data['completed_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'7','ir_sts'=>'1'));
			      $data['rejected_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'6','ir_sts'=>'1'));

               $data['new_req']=$data['new_req_ksa']+  $data['new_req_uae'];
			      $data['approved_req']=$data['approved_req_ksa']+  $data['approved_req_uae'];
			      $data['req_ordered']=$data['req_ordered_ksa']+  $data['req_ordered_uae'];
			      $data['ready_ship']=$data['ready_ship_ksa']+  $data['ready_ship_uae'];
			      $data['shipped']=$data['shipped_ksa']+  $data['shipped_uae'];
			      $data['completed']=$data['completed_ksa']+  $data['completed_uae'];
			      $data['rejected']=$data['rejected_ksa']+ $data['rejected_uae'];


      
       }
       ///////for management every thing will show 
       else if($this->session->userdata['user']['main_dept']=="Main") {

          $data['new_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
		      $data['approved_req_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'2','ir_sts'=>'1'));
		      $data['req_ordered_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
		      $data['ready_ship_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'4','ir_sts'=>'1'));
		      $data['shipped_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
		      $data['completed_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'7','ir_sts'=>'1'));
		      $data['rejected_ksa']=$this->Admin_model->record_count2('ksa_item_request',array('ir_req_status'=>'6','ir_sts'=>'1'));



			      $data['new_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'1','ir_sts'=>'1'));
			      $data['approved_req_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'2','ir_sts'=>'1'));
			      $data['req_ordered_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'3','ir_sts'=>'1'));
			      $data['ready_ship_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'4','ir_sts'=>'1'));
			      $data['shipped_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'5','ir_sts'=>'1'));
			      $data['completed_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'7','ir_sts'=>'1'));
			      $data['rejected_uae']=$this->Admin_model->record_count2('item_request',array('ir_req_status'=>'6','ir_sts'=>'1'));

               $data['new_req']=$data['new_req_ksa']+  $data['new_req_uae'];
			      $data['approved_req']=$data['approved_req_ksa']+  $data['approved_req_uae'];
			      $data['req_ordered']=$data['req_ordered_ksa']+  $data['req_ordered_uae'];
			      $data['ready_ship']=$data['ready_ship_ksa']+  $data['req_replyuae'];
			      $data['shipped']=$data['shipped_ksa']+  $data['shipped_uae'];
			      $data['completed']=$data['completed_ksa']+  $data['completed_uae'];
			      $data['rejected']=$data['rejected_ksa']+  $data['rejected_uae'];
       }
              
                else{}


 	  $this->load->view('admin/tasks/index',$data);




		  	
 	
}

   else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	  	} 


 	}

}

function ajax_load_view_task()
{

	$t_id=$this->input->post('t_id');


	

	

			$data=$this->Admin_model->get_data('task_scheduler',array('t_id'=>$t_id));
	//$req_data=$this->Admin_model->get_data('item_req_content',array('itr_req_id'=>$req_id));
	
	
	$user_id=explode('|#|', $data[0]->t_to_group);
	// $qnty=explode('|#|',$data[0]->ir_prd_qnty);
	// $remark=explode('|#|',$data[0]->ir_prd_extra_data);
	$html='
	<div class="container">
	<div class="row">
	<div class="col-md-12">
	
	<p><b>Task Number :</b> '.$data[0]->t_id.' </p>
	<p><b> Created By : </b>'.$data[0]->t_user_created.' </p>
     <p><b>Title : </b>'.$data[0]->t_summary.' </p>
	<p><b> Task Created on :</b> '.$data[0]->t_create_date .' </p>
	<p><b> Task Start Date :</b> '.$data[0]->t_start_date .'|| '.$data[0]->t_start_time. '   </p>
	<p><b> Task End Date :</b> '.$data[0]->t_end_date .'|| '.$data[0]->t_end_time. ' </p> 
	<p><b> Description : </b>'.$data[0]->t_description.' </p>';


$html.='</div>
</div>
</div>';

		 	$html.='<table class="table table-responsive table-bordered table-striped">
		<thead>
			<th></th>
			<th> Employee Included</th>
			
		</thead><tbody>';
		$i=1;
		foreach($user_id as $index=>$p)
		{
		

			$usr_info=$this->Admin_model->get_data('tbl_emp_tree',array('ed_login_id'=>$p));
		//	print_r($prd_info[0]->pname);
				$prd_name_db=$usr_info[0]->et_name;

				// if(empty($prd_info[0]->p_prd_img))
    //                     {
    //                         $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
    //                      if (file_exists($filename)) {
    //                         $img_path=$filename;
    //                         } else {
    //                         $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
    //                         }
    //                     }
    //                     else
    //                     {
    //                         $first_img_prd=explode(',',$prd_info[0]->p_prd_img);
    //                         if(!empty($first_img_prd[0]))
    //                         $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
    //                         else
    //                         $img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
                            
    //                     }
		$html.='
		<tr>
		<td>'.$i++.'</td>
		<td>';	
			
						$html.= $usr_info[0]->et_name;
					
			$html.='</td>
				
		</tr>';
		}
		$html.='</tbody></table>';
	
	
	$html.='<br/>';
		
	
	

	
echo $html;
}



function search_user_id_quot()
{
	$search_usr_id=$this->input->post('search_usr_id');
	
	$cond1=array('et_sts'=>'1','ed_login_id'=>$search_usr_id);
	$data=$this->Admin_model->get_data('tbl_emp_tree',$cond1);
	// foreach($data as $d)
	// {
	// 	//$prd_wgt=$d->po_wgt;
	// 	$var_names=$d->et_name;
	// 	$var_branch=$d->et_branch;
	// 	$var_code=$d->et_code_branch;
	// 	// $new_var_val=array();
	// 	// 	$new_var_names=array();
	// 			foreach($var_names as $key1=>$vn)
	// 			{
	// 				$new_var_names[]=$vn;
	// 				$new_var_val[$vn]=$var_values[$key1];
	// 			}
	// }
	$usr_name=$data[0]->et_name;
	

	$script_data=array(
		'usr_name'=>$usr_name,
		
		'usr_branch'=>$data[0]->et_branch,
		'usr_code'=>$data[0]->et_code_branch
			
		);
		echo json_encode($script_data);
}




// function ajax_load_view_ksa()
// {
// print_r($this->input->post('req_id'));
// exit(0);
// 	$req_id=$this->input->post('req_id');

	
// 		$data=$this->Admin_model->get_data('ksa_item_request',array('ir_id'=>$req_id));
// 	   $req_data=$this->Admin_model->get_data('ksa_item_req_content',array('itr_req_id'=>$req_id));


// 	$prd_ids=explode('|#|', $data[0]->ir_prd_id);
// 	$qnty=explode('|#|',$data[0]->ir_prd_qnty);
// 	$remark=explode('|#|',$data[0]->ir_prd_extra_data);
// 	$html='
// 	<div class="container">
// 	<div class="row">
// 	<div class="col-md-12">
	
// 	<p><b>Item Request :</b> '.$data[0]->ir_req_no.' </p>
// 	<p><b> Created By : </b>'.$data[0]->ir_user_created.' </p>
// 	<p><b> Order Created on :</b> '.$data[0]->ir_order_date .' </p>
// 	<p><b> Order Type :</b> '.$data[0]->ir_delivery_type .' </p> ';

// 	if(!empty($req_data))
// 	{
// 		$html.='<h4>More information on the request</h4>';
// 	$html.='<ul class="simple-bullet-list mb-xlg">';

// 	foreach($req_data as $rq)
// 	{
		
// 		if($rq->itr_req_type=='request')
// 		{
// 			$array_req_type[]=$rq->itr_req_type;
// 			$class='red';
// 			$subject="Request";
// 		}
// 		else
// 		{
// 			$array_reply_type[]=$rq->itr_req_type;
// 			$class='green';
// 			$subject="Reply";
// 		}

// $html.='<li class="'.$class.'">
// <span class="title"><b>'.$subject.' Subject: </b> '.$rq->itr_sub.'</span>';
// $html.='<div class="container">';
// $html.='<span class=" truncate"><b> Content: </b><br/>';
// $html.='<p> '.wordwrap($rq->itr_content,120,"<br>\n").'</p></span>';
// $html.='</div>';
// $html.='</li>';
// }

// if(count($array_req_type)!=count($array_reply_type))
// 	{
// 		if($this->session->userdata['user']['username']==$data[0]->ir_user_created)
// 		{
// 			$html.='<a href="'.base_url("item_reply_request/".$data[0]->ir_id).'" style="color:green;">Click here to send reply </a>';
// 		}		
// 	}
// $html.='</ul>';
// }
// $html.='</div>
// </div>
// </div>';

// 		 	$html.='<table class="table table-responsive table-bordered table-striped">
// 		<thead>
// 			<th></th>
// 			<th> Name</th>
// 			<th> Image</th>
// 			<th>Quantity</th>
// 			<th>Remark</th>
// 		</thead><tbody>';
// 		$i=1;
// 		foreach($prd_ids as $index=>$p)
// 		{
		

// 			$prd_info=$this->tm->get_data('products',array('pid'=>$p));
// 		//	print_r($prd_info[0]->pname);
// 				$prd_name_db=explode('|--|',$prd_info[0]->pname);

// 				if(empty($prd_info[0]->p_prd_img))
//                         {
//                             $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
//                          if (file_exists($filename)) {
//                             $img_path=$filename;
//                             } else {
//                             $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
//                             }
//                         }
//                         else
//                         {
//                             $first_img_prd=explode(',',$prd_info[0]->p_prd_img);
//                             if(!empty($first_img_prd[0]))
//                             $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
//                             else
//                             $img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
                            
//                         }
// 		$html.='
// 		<tr>
// 		<td>'.$i++.'</td>
// 		<td>';	
// 			if(!empty($prd_name_db[1]))
// 						$html.= $prd_name_db[0].'<br/>'.$prd_name_db[1];
// 					else
// 						$html.= $prd_info[0]->pname;
// 				$html.= '<br/> <br/> Code '.$prd_info[0]->pcode;		
// 			$html.='</td>
// 			<td><img src="'.$img_path.'" width="100" height="100"></td>
// 			<td>'.$qnty[$index].'</td>
// 			<td>'.$remark[$index].'</td>	
// 		</tr>';
// 		}
// 		$html.='</tbody></table>';
	
// 	if(!empty($data[0]->q_files))
// 	{
	
// 	$html.='<div class="col-md-12 col-sm-12"> 
// 	<p>Files submitted for inquiry:<br/></p>';
	
// 	$files_data=explode(',',$data[0]->ir_attachments);
// 	foreach($files_data as $fd)
// 	{
// 	$html.='<a target="_blank" href="'.base_url().'uploads/file_manager'.$fd.'">'.$fd.'</a><br/>';
// 	}
// 	$html.='</div>';
// 	}
	
// 	$html.='<br/>';
		
// 	if(!empty($data[0]->ir_order_files))
// 	{
	
// 	$html.='<div class="col-md-12 col-sm-12"> 
// 	<p>Files related to order:<br/></p>
// <a target="_blank" href="'.base_url().'uploads/item_request/'.$data[0]->ir_order_files.'">'.$data[0]->ir_order_files.'</a><br/>
// </div>';

// 	}		
		
// $html.='<br/>';		
// 	if(!empty($data[0]->ir_payment_files))
// 	{
// 	$html.='<div class="col-md-12 col-sm-12"> 
// 	<p>Files related to payment:<br/></p>
// <a target="_blank" href="'.base_url().'uploads/item_request/'.$data[0]->ir_payment_files.'">'.$data[0]->ir_payment_files.'</a><br/>
// </div>';
// 	}

// 	$html.='<br/>';		
// 	if(!empty($data[0]->ir_shipment_files))
// 	{
// 	$html.='<div class="col-md-12 col-sm-12"> 
// 	<p>Files related to shipment:<br/></p>
// <a target="_blank" href="'.base_url().'uploads/item_request/'.$data[0]->ir_shipment_files.'">'.$data[0]->ir_shipment_files.'</a><br/>
// </div>';
// 	}

	
// if(!empty($data[0]->date_expected))
// 	{
// 		$html.='<div class="col-md-12 col-sm-12"> 
// 	<p>Ready to ship - Expected Shipment date:<br/>'.$data[0]->date_expected.'</p></div>';
// 	}

// $html.='<br/>';		
// 	if(!empty($data[0]->new_expected_date))
// 	{
// 		$html.='<div class="col-md-12 col-sm-12"> 
// 	<p>Shipped - Expected Shipment date:<br/>'.$data[0]->new_expected_date.'</p></div>';
// 	}

// $html.='<br/>';		
// 	if(!empty($data[0]->tracking_details) || (!empty($data[0]->tracking_code))) 
// 	{
// 		$html.='<div class="col-md-12 col-sm-12"> 
// 	<p>Tracking Details:<br/>'.$data[0]->tracking_details.'</p>
// 	<p>Tracking Code:<br/>'.$data[0]->tracking_code.'</p></div>';
// 	}

// 	if($data[0]->ir_req_status=='7')
// 	{
// 		if(!empty($data[0]->mrn))
// 		{
// 			$html.='<p> MRN Details: '.$data[0]->mrn.'</p>';
// 		}
// 		if(!empty($data[0]->pv))
// 		{
// 			$html.='<p> PV Details: '.$data[0]->pv.'</p>';
// 		}
// 	}	
	
// echo $html;
// }






function  load_completed_req()
{

	$sub_dept=$this->session->userdata['user']['sub_dept'];

	if ($sub_dept=='ksa') {

        $data=$this->Admin_model->get_data('ksa_item_request',array('ir_req_status'=>'7'));
		
	}
	else{
		$data=$this->Admin_model->get_data('item_request',array('ir_req_status'=>'7'));
	}

	
	$i=1;
	foreach($data as $d)
	{
		$html='<tr>';
		$html.='<td>'.$i++.'</td>';
		$html.='<td>'.$d->ir_req_no.'</td>';
		$html.='<td>'.$d->ir_req_title.'</td>';
		$html.='<td>'.$d->ir_user_created.'</td>';
		$html.='<td><button type="button" class="btn btn-sm" style="background-color:#00cc00;color:white;">Completed</button></td>';
		$html.='<td>'.$d->ir_delivery_type.'</td>';
		$html.='<td>'.$d->ir_exact_delivery_date.'</td>';
		$html.='<td><div class="dropdown-primary dropdown">
<button class="btn btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >Action</button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">

<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="'.base_url("generate_req_order/".$d->ir_id).'"><i class="fa fa-pdf"></i>Download as PDF</a>

<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="'.base_url('item_request_history/').$d->ir_id.'" >See Activity </a>

<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="'.base_url('delete_item_request/').$d->ir_id.'" >Delete </a>

</div>
</div></td>';

		$html.='</tr>';
		echo $html;
	}

}


function submit_task_req()
{     
   // $sub_dept=$this->session->userdata['user']['sub_dept'];
	
		$tz = 'Asia/Dubai'; // your required location time zone.
		$timestamp = time();
		$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
		$dt->setTimestamp($timestamp);
		$new_order_date=$dt->format('Y-m-d');
      // print_r($new_order_date);
      // exit(0);
  //$sub_dept=$this->session->userdata['user']['sub_dept'];
	$update_task_id=$this->input->post('edit_task_req_id');

	if(($update_task_id)=='')
	{

		$task_crtd_by=$this->session->userdata['user']['username'];


  }
	else{
			$task_crtd_by=$this->input->post('task_created_by');

	}






     
        





$date_start=$this->input->post('t_start_start_date');

		$date1=explode('/',$date_start);
					$month_delivery_date1=$date1[0];
					$date_delivery_date1=$date1[1];
					$year_delivery_date1=$date1[2];
		$new_formated_start_date=$year_delivery_date1.'-'.$month_delivery_date1.'-'.$date_delivery_date1;



		$date_end=$this->input->post('t_end_date');

		$date2=explode('/',$date_end);
					$month_delivery_date2=$date2[0];
					$date_delivery_date2=$date2[1];
					$year_delivery_date2=$date2[2];
		$new_formated_end_date=$year_delivery_date2.'-'.$month_delivery_date2.'-'.$date_delivery_date2;

		$data=array(
		't_user_created'=>$task_crtd_by,
        't_to_group'=>$this->input->post('usrids'),
		't_summary'=>$this->input->post('t_req_title'),
      
		't_id'=>$this->input->post('t_req_no'),

		't_start_date'=>$new_formated_start_date,
		't_end_date'=>$new_formated_end_date,
         't_start_time'=>$this->input->post('t_start_time'),
	     't_end_time'=>$this->input->post('t_end_time'),

	     't_description'=>$this->input->post('t_description'),
	     't_brief'=>$this->input->post('t_brief'),

        't_status'=>'1',
		't_enable'=>'1',
		 't_create_date'=>get_date_time(),
		 't_update_date'=>get_date_time(),
		);


		if(empty($update_task_id))
		{  

		   	$insert_id=$this->Admin_model->insert_data('task_scheduler',$data);

			if(!empty($insert_id))
			{
				$task_current_status="NEW Task Request";
				$data_update=array(
					't_status'=>'1',////means its new
					't_update_date'=>$new_order_date
				);



			
						$this->Admin_model->update_data('task_scheduler',$data_update,array('t_id'=>$insert_id));
						$mail_data=mail_task_request($insert_id);
					
				//$item_inserted_id=$insert_id;
			}
			//echo $insert_id;
			$data_activity=array(
					'act_function'=>'task request created',
					'act_user'=>$this->session->userdata['user']['username'],
					
					'act_status'=>$task_current_status,
					'act_date'=>get_date(),
					'act_time'=>get_time(),
					'act_date_time'=>get_date_time(),
					'act_notification_sts'=>'1',
					'act_notification_sts_mngmnt'=>'1',
					 'act_doc_num'=>$insert_id,
					 'act_type_id'=>$insert_id,
				'act_type'=>'Task Request',
					);
					$this->Admin_model->insert_data('activities',$data_activity);	
			//print_r($insert_id);
			if($mail_data==true)
				$this->session->set_flashdata('success', 'Data Successfully inserted');
			else
				$this->session->set_flashdata('errors', 'Error found in sending mail.');
			
			if(!empty($insert_id))
			{
			redirect('item-task-status/'.$insert_id);
			}
			else
			{
			redirect('task-schedule');
			}
		//redirect('quotation-status/'.$insert_id);
		}
		else
		{  	

     
			$q_current_status="Update Item Request";
			
						$this->Admin_model->update_data('task_scheduler',$data,array('t_id'=>$update_task_id));
						$mail_data=mail_task_request($update_task_id);	
					
			
			$data_activity=array(
					'act_function'=>'Item request updated',
					'act_user'=>$this->session->userdata['user']['username'],
					'act_item_req_id'=>$update_req_id,
					'act_status'=>$q_current_status,
					'act_date'=>get_date(),
					'act_time'=>get_time(),
					'act_date_time'=>get_date_time(),
					'act_notification_sts'=>'1',
					'act_notification_sts_mngmnt'=>'1',
					 'act_doc_num'=>$update_task_id,
					 'act_type_id'=>$update_task_id,
				'act_type'=>'Task Request',
					);
					$this->Admin_model->insert_data('activities',$data_activity);		
			
			if($mail_data==true)
				$this->session->set_flashdata('success', 'Data Successfully updated');
			else
				$this->session->set_flashdata('errors', 'Error found in sending mail.');
				
			redirect('task-schedule');
		}





}


	function submit_item_req_ksa()
{   
   $sub_dept=$this->session->userdata['user']['sub_dept'];
	// print_r($sub_dept);
	// exit(0);

		$tz = 'Asia/Dubai'; // your required location time zone.
		$timestamp = time();
		$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
		$dt->setTimestamp($timestamp);
		$new_order_date=$dt->format('Y-m-d');

  //$sub_dept=$this->session->userdata['user']['sub_dept'];
	$update_req_id=$this->input->post('edit_item_req_id');

	if(!empty($update_req_id))
	$qution_crtd_by=$this->input->post('quotation_created_by');
	else
	$qution_crtd_by=$this->session->userdata['user']['username'];

		if($this->input->post("ir_delivery_type")=="Sold")
		{
		$date_ref=$this->input->post('ir_exact_delivery_date');

		$date1=explode('/',$date_ref);
					$month_delivery_date=$date1[0];
					$date_delivery_date=$date1[1];
					$year_delivery_date=$date1[2];
		$new_formated_date=$year_delivery_date.'-'.$month_delivery_date.'-'.$date_delivery_date;
		}
		else
		{
		$new_formated_date='';
		}
	/////for upload files//////
		$image = array();
		$uploadImgData = array();


	  $ImageCount = count($_FILES['ir_attachments']['name']);
	 
	       $targetfolder='./uploads/file_manager/';
	  if (isset($_FILES['ir_attachments']['name']) && $_FILES['ir_attachments']['name'] != "") 	
			{
				$img_array1=array(
					'img_name'=>'ir_attachments',
					'upload_path'=>$targetfolder,
				);
				$pic_names=img_upload($img_array1);

				if(!empty($pic_names))
				{
					if(!empty($pic_names[0][0]['file_name']))
					{
						foreach($pic_names[0] as $k1)
						{
							$pp_aray[]=$k1['file_name'];
							$value_pp_aray=implode(',',$pp_aray);
						}
					}
				}
				else
				{
					if(!empty($this->input->post('edit_files')))
					{
						$value_pp_aray=$this->input->post('edit_files');
					}
					else
					{
						$value_pp_aray='';
					}
				}	
			}
	   
		////for upload files//////////


                            $data=array(
			'ir_user_created'=>$qution_crtd_by,
			'ir_req_title'=>$this->input->post('ir_req_title'),
			'ir_req_no'=>$this->input->post('ir_req_no'),
			'ir_exact_delivery_date'=>$new_formated_date,
			'ir_attachments'=>$value_pp_aray,
			'ir_delivery_type'=>$this->input->post('ir_delivery_type'),
			'ir_email_sts'=>$this->input->post('ir_email_sts'),
			'ir_extra_details'=>$this->input->post('ir_extra_details'),
		    'request_type'=>$this->input->post('request_type'),
			'ir_prd_id'=>$this->input->post('prdids'),
			'ir_prd_qnty'=>$this->input->post('qntys'),
			'ir_prd_extra_data'=>$this->input->post('extra_detail'),
			'ir_sts'=>'1'
			);



	
		if(empty($update_req_id))
		{  
			
							                	$insert_id=$this->Admin_model->insert_data('ksa_item_request',$data);
		              
		        
			if(!empty($insert_id))
			{
				$q_current_status="create Item Request";
				$data_update=array(
					'ir_req_status'=>'1',////means its new
					'ir_order_date'=>$new_order_date
				);



				      	$this->Admin_model->update_data('ksa_item_request',$data_update,array('ir_id'=>$insert_id));
				           	$mail_data=mail_item_request_ksa($insert_id);
		          
		        
				//$item_inserted_id=$insert_id;
			}


			//echo $insert_id;
			$data_activity=array(
					'act_function'=>'Item request created',
					'act_user'=>$this->session->userdata['user']['username'],
					'act_item_req_id'=>$insert_id,
					'act_status'=>$q_current_status,
					'act_date'=>get_date(),
					'act_time'=>get_time(),
					'act_date_time'=>get_date_time(),
					'act_notification_sts'=>'1',
					'act_notification_sts_mngmnt'=>'1',
							'act_notification_sts_mngmnt'=>'1',
					 'act_doc_num'=>$insert_id,
					 'act_type_id'=>$insert_id,
				'act_type'=>'Item Request',
					);
					$this->Admin_model->insert_data('activities',$data_activity);	
			//print_r($insert_id);
			if($mail_data==true)
				$this->session->set_flashdata('success', 'Data Successfully inserted');
			else
				$this->session->set_flashdata('errors', 'Error found in sending mail.');
			
			if(!empty($insert_id))
			{
			redirect('item-task-status/'.$insert_id);
			}
			else
			{
			redirect('task-schedule');
			}
		//redirect('quotation-status/'.$insert_id);
		}
		else
		{  $q_current_status="edit Item Request";
			
						$this->Admin_model->update_data('ksa_item_request',$data,array('ir_id'=>$update_req_id));
						$mail_data=mail_item_request_ksa($update_req_id);	
				
				
			
			$data_activity=array(
					'act_function'=>'Item request updated',
					'act_user'=>$this->session->userdata['user']['username'],
					'act_item_req_id'=>$update_req_id,
					'act_status'=>$q_current_status,
					'act_date'=>get_date(),
					'act_time'=>get_time(),
					'act_date_time'=>get_date_time(),
					'act_notification_sts'=>'1',
					'act_notification_sts_mngmnt'=>'1',
							 'act_doc_num'=>$update_req_id,
					 'act_type_id'=>$update_req_id,
				'act_type'=>'Item Request',
					);
					$this->Admin_model->insert_data('activities',$data_activity);		
			
			if($mail_data==true)
				$this->session->set_flashdata('success', 'Data Successfully updated');
			else
				$this->session->set_flashdata('errors', 'Error found in sending mail.');
				
			redirect('task-schedule');
		}





	}










function ordered_file_upload()
{	
	$req_type=$this->input->post('req_type');
	$req_id=$this->input->post('req_id');
	$req_expected_date=$this->input->post('expected_date');
	$ship_tracking_code=$this->input->post('tracking_code');
	$ship_tracking_details=$this->input->post('tracking_details');
	$date1=explode('/',$req_expected_date);
			$month=$date1[0];
			$date=$date1[1];
			$year=$date1[2];
   $new_formated_date=$year.'-'.$month.'-'.$date;

	$targetfolder='./uploads/item_request/';
if (isset($_FILES['ordered_file_data']['name']) && $_FILES['ordered_file_data']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'ordered_file_data',
				'upload_path'=>$targetfolder,
			);
			$pic_names=single_img_upload($img_array1);
			if(!empty($pic_names))
			{
				$value_pp_aray=$pic_names;
			}
			else
			{
				$value_pp_aray='';
			}	
		}
		
		$sub_dept=$this->session->userdata['user']['sub_dept'];

	$item_details_data=$this->Admin_model->get_data('item_request',array('ir_id'=>$req_id));
				

				if($req_type=="ordered")
				{
					$data=array(
					//	'ir_order_files'=>$value_pp_aray,
						'ir_req_status'=>'3',
						'date_expected'=>$new_formated_date,
						);



	$this->Admin_model->update_data('item_request',$data,array('ir_id'=>$req_id));
		$mail_data=mail_item_request($req_id);

			
		

				$data_activity=array(
					'act_function'=>'Item request updated',
					'act_user'=>$this->session->userdata['user']['username'],
					'act_item_req_id'=>$req_id,
					'act_status'=>'Request Ordered',
					'act_date'=>get_date(),
					'act_time'=>get_time(),
					'act_date_time'=>get_date_time(),
					'act_notification_sts'=>'1',
					'act_notification_sts_mngmnt'=>'1',
						 'act_doc_num'=>$req_id,
					 'act_type_id'=>$req_id,
				'act_type'=>'Item Request',
					);
				$this->Admin_model->insert_data('activities',$data_activity);	
					echo true;
				}

			elseif($req_type=="ready_shipping")
			{
				if(!empty($value_pp_aray))
				{
					$data=array(
						'ir_payment_files'=>$value_pp_aray,
						'ir_req_status'=>'4',
						'date_expected'=>$new_formated_date,
						);
				
				$this->Admin_model->update_data('item_request',$data,array('ir_id'=>$req_id));
				$mail_data=mail_item_request($req_id);
	
			
				$data_activity=array(
					'act_function'=>'Item request updated',
					'act_user'=>$this->session->userdata['user']['username'],
					'act_item_req_id'=>$req_id,
					'act_status'=>'Ready to ship',
					'act_date'=>get_date(),
					'act_time'=>get_time(),
					'act_date_time'=>get_date_time(),
					'act_notification_sts'=>'1',
					'act_notification_sts_mngmnt'=>'1',
							 'act_doc_num'=>$req_id,
					 'act_type_id'=>$req_id,
				'act_type'=>'Item Request',
					);
				$this->Admin_model->insert_data('activities',$data_activity);	
						echo true;
				}
				else
				{
						echo false;
				}
			}
			elseif($req_type=="shipped")
				{
					$data=array(
					//	'ir_order_files'=>$value_pp_aray,
						'ir_req_status'=>'5',
						'new_expected_date'=>$new_formated_date,
						'ir_shipment_files'=>$value_pp_aray,
						'tracking_details'=>$ship_tracking_details,
						'tracking_code'=>$ship_tracking_code,
						);

				$this->Admin_model->update_data('item_request',$data,array('ir_id'=>$req_id));
				$mail_data=mail_shipped_created($req_id);
		
		
				$data_activity=array(
					'act_function'=>'Item request updated',
					'act_user'=>$this->session->userdata['user']['username'],
					'act_item_req_id'=>$req_id,
					'act_status'=>'Request Shipped',
					'act_date'=>get_date(),
					'act_time'=>get_time(),
					'act_date_time'=>get_date_time(),
					'act_notification_sts'=>'1',
					'act_notification_sts_mngmnt'=>'1',
							 'act_doc_num'=>$req_id,
					 'act_type_id'=>$req_id,
				'act_type'=>'Item Request'
					);
				$this->Admin_model->insert_data('activities',$data_activity);	
					echo true;
				}
				else{}			
}










function ordered_file_upload_ksa()
{	
	$req_type=$this->input->post('req_type');
	$req_id=$this->input->post('req_id');
	$req_expected_date=$this->input->post('expected_date');
	$ship_tracking_code=$this->input->post('tracking_code');
	$ship_tracking_details=$this->input->post('tracking_details');
	$date1=explode('/',$req_expected_date);
			$month=$date1[0];
			$date=$date1[1];
			$year=$date1[2];
   $new_formated_date=$year.'-'.$month.'-'.$date;

	$targetfolder='./uploads/item_request/';
if (isset($_FILES['ordered_file_data']['name']) && $_FILES['ordered_file_data']['name'] != "") 	
		{
			$img_array1=array(
				'img_name'=>'ordered_file_data',
				'upload_path'=>$targetfolder,
			);
			$pic_names=single_img_upload($img_array1);
			if(!empty($pic_names))
			{
				$value_pp_aray=$pic_names;
			}
			else
			{
				$value_pp_aray='';
			}	
		}
		
		$sub_dept=$this->session->userdata['user']['sub_dept'];

	$item_details_data=$this->Admin_model->get_data('ksa_item_request',array('ir_id'=>$req_id));
				

				if($req_type=="ordered")
				{
					$data=array(
					//	'ir_order_files'=>$value_pp_aray,
						'ir_req_status'=>'3',
						'date_expected'=>$new_formated_date,
						);



	$this->Admin_model->update_data('ksa_item_request',$data,array('ir_id'=>$req_id));
		$mail_data=mail_item_request($req_id);

			
		

				$data_activity=array(
					'act_function'=>'ksa Item request updated',
					'act_user'=>$this->session->userdata['user']['username'],
					'act_item_req_id'=>$req_id,
					'act_status'=>'Request Ordered',
					'act_date'=>get_date(),
					'act_time'=>get_time(),
					'act_date_time'=>get_date_time(),
					'act_notification_sts'=>'1',
					'act_notification_sts_mngmnt'=>'1',
								 'act_doc_num'=>$req_id,
					 'act_type_id'=>$req_id,
				'act_type'=>'Item Request'
					);
				$this->Admin_model->insert_data('activities',$data_activity);	
					echo true;
				}

			elseif($req_type=="ready_shipping")
			{
				if(!empty($value_pp_aray))
				{
					$data=array(
						'ir_payment_files'=>$value_pp_aray,
						'ir_req_status'=>'4',
						'date_expected'=>$new_formated_date,
						);
				
				$this->Admin_model->update_data('ksa_item_request',$data,array('ir_id'=>$req_id));
				$mail_data=mail_item_request($req_id);
	
			
				$data_activity=array(
					'act_function'=>' ksa Item request updated',
					'act_user'=>$this->session->userdata['user']['username'],
					'act_item_req_id'=>$req_id,
					'act_status'=>'Ready to ship',
					'act_date'=>get_date(),
					'act_time'=>get_time(),
					'act_date_time'=>get_date_time(),
					'act_notification_sts'=>'1',
					'act_notification_sts_mngmnt'=>'1'
					);
				$this->Admin_model->insert_data('activities',$data_activity);	
						echo true;
				}
				else
				{
						echo false;
				}
			}
			elseif($req_type=="shipped")
				{
					$data=array(
					//	'ir_order_files'=>$value_pp_aray,
						'ir_req_status'=>'5',
						'new_expected_date'=>$new_formated_date,
						'ir_shipment_files'=>$value_pp_aray,
						'tracking_details'=>$ship_tracking_details,
						'tracking_code'=>$ship_tracking_code,
						);

				$this->Admin_model->update_data('ksa_item_request',$data,array('ir_id'=>$req_id));
				$mail_data=mail_shipped_created($req_id);
		
		
				$data_activity=array(
					'act_function'=>'ksa_Item request updated',
					'act_user'=>$this->session->userdata['user']['username'],
					'act_item_req_id'=>$req_id,
					'act_status'=>'Request Shipped',
					'act_date'=>get_date(),
					'act_time'=>get_time(),
					'act_date_time'=>get_date_time(),
					'act_notification_sts'=>'1',
					'act_notification_sts_mngmnt'=>'1'
					);
				$this->Admin_model->insert_data('activities',$data_activity);	
					echo true;
				}
				else{}			
}














function item_task_status($t_id)
{

		$data['result']= $this->Admin_model->get_data('task_scheduler',array('t_id'=>$t_id));  
	 $usr_ids=explode('|#|', $data['result'][0]->t_to_group);
	
	 foreach($usr_ids as $uid)
	 {
	 	$data['usr'][]=$this->Admin_model->get_data('tbl_emp_tree',array('ed_login_id'=>$uid));
	 	
	 //exit(0);
	 }
      $this->load->view('admin/tasks/task_req_sts',$data);

}

function change_item_req_sts_ksa($sts,$req_id)
{

$sub_dept=explode(',', $this->session->userdata['user']['sub_dept']);
$data_updt=array(
'ir_req_status'=>$sts,
);



	$this->Admin_model->update_data('ksa_item_request',$data_updt,array('ir_id'=>$req_id));
$mail_data=mail_item_request_ksa($req_id);






$sts_value='';
switch($sts)
{
case 2:
$sts_value='Request Accepted';
break;

case 3:
$sts_value='Ordered';
break;

case 4:
$sts_value='Ready to Ship';
break;

case 5:
$sts_value='Shipped';
break;

case 6:
$sts_value='Rejected';
break;

case 7:
$sts_value='Completed';
break;

default:
$sts_value='';
break;

}
$data_activity=array(
		'act_function'=>'Status Changed',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_item_req_id'=>$req_id,
		'act_status'=>$sts_value,
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);

if($mail_data==true)
$this->session->set_flashdata('success', 'Item status Successfully updated');
else
$this->session->set_flashdata('errors', 'Error found in sending mail.');

redirect('task-schedule');
}



function change_task_req_sts($sts,$req_id)
{

//$sub_dept=explode(',', $this->session->userdata['user']['sub_dept']);
$data_updt=array(
't_status'=>$sts,
);



	$this->Admin_model->update_data('task_scheduler',$data_updt,array('t_id'=>$req_id));
$mail_data=mail_task_request($req_id);


$sts_value='';
switch($sts)
{
case 2:
$sts_value='Task Postponent';
break;

case 3:
$sts_value=' Task Cancelled';
break;

case 4:
$sts_value='Task Done';
break;

case 1:
$sts_value='task Return Procecing';
break;


default:
$sts_value='';
break;

}
$data_activity=array(
		'act_function'=>'Status Changed',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_item_req_id'=>$req_id,
		'act_status'=>$sts_value,
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);

if($mail_data==true)
$this->session->set_flashdata('success', 'Item status Successfully updated');
else
$this->session->set_flashdata('errors', 'Error found in sending mail.');

redirect('task-schedule');
}






function submit_item_req_sts()
{
	$item_req_sts_id=$this->input->post('item_req_sts_id');
		$req_sts=$this->input->post('status_value');
$hold_date=$this->input->post('hold_date');
if(!empty($hold_date))
{
$hold_date11=explode('/',$hold_date);
			$month2=$hold_date11[0];
			$date2=$hold_date11[1];
			$year2=$hold_date11[2];
$new_formated_date2=$year2.'-'.$month2.'-'.$date2;
}
else
{
$new_formated_date2='';
}

if($req_sts=="5")
{
	$data_updt=array(
	'ir_req_status'=>$req_sts,
	'ir_eta'=>$new_formated_date2,
	);
	$activity_sts="Shipped";
}
elseif($req_sts=="6")
{
$data_updt=array(
	'ir_req_status'=>$req_sts,
	'rejection_reason'=>$this->input->post('rejection_reason'),
	);
	$activity_sts="Rejcted";

}
else
{
	$data_updt=array(
	'ir_req_status'=>$req_sts,
	'expected_shipment_date'=>$new_formated_date2,
	);
	if($req_sts=="3")
	$activity_sts="Ordered";
	else
		$activity_sts="Ready to Ship";
}

$sub_dept=$this->session->userdata['user']['sub_dept'];
if ($sub_dept=='ksa') {

	$this->Admin_model->update_data('ksa_item_request',$data_updt,array('ir_id'=>$item_req_sts_id));

$mail_data=mail_item_request_ksa($item_req_sts_id);
}
else
{
	$this->Admin_model->update_data('item_request',$data_updt,array('ir_id'=>$item_req_sts_id));

$mail_data=mail_item_request($item_req_sts_id);
}


//print_r($mail_data);
$data_activity=array(
		'act_function'=>'Status Changed',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_item_req_id'=>$item_req_sts_id,
		'act_status'=>$activity_sts,
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);

if($mail_data==true)				
$this->session->set_flashdata('success', 'Data Successfully updated');
else
$this->session->set_flashdata('errors', 'Error found in sending mail.');
redirect('task-schedule');
}

function item_request_history($ir_id)
{
$data['result']=$this->Admin_model->get_data('activities',array('act_item_req_id'=>$ir_id));
$this->load->view('admin/sales/item_req_history',$data);
}

function delete_item_request($ir_id)
{
$sub_dept=$this->session->userdata['user']['sub_dept'];


     $this->Admin_model->update_data('item_request',array('ir_sts'=>'0'),array('ir_id'=>$ir_id));

	
	$this->session->set_flashdata('success', 'Data Successfully removed');
redirect('task-schedule');


}


function delete_item_request_ksa($ir_id)
{
$sub_dept=$this->session->userdata['user']['sub_dept'];

	$this->Admin_model->update_data('ksa_item_request',array('ir_sts'=>'0'),array('ir_id'=>$ir_id));


	
	$this->session->set_flashdata('success', 'Data Successfully removed');
redirect('task-schedule');


}

function manage_item_request($ir_id)
{
	$sub_dept=$this->session->userdata['user']['sub_dept'];
	if ($sub_dept=='ksa') {
$data['result']=$this->Admin_model->get_data('ksa_item_request',array('ir_id'=>$ir_id));


	}
	else{
		$data['result']=$this->Admin_model->get_data('item_request',array('ir_id'=>$ir_id));
	}

$prd_ids=explode('|#|', $data['result'][0]->ir_prd_id);
	 foreach($prd_ids as $pid)
	 {
	 	$data['prds'][]=$this->tm->get_data('products',array('pid'=>$pid));
	 }
$this->load->view('admin/sales/manage_item_request',$data);
}


function submit_more_info_req()
{
	$task_dept=$this->session->userdata['user']['sub_dept'];
	$task_id=$this->input->post('item_task_id');
	$task_sub=$this->input->post('task_sub');
	$task_info=$this->input->post('task_info');
	$task_type=$this->input->post('item_task_type');
$dtaacreated=get_date_time();

	$data=array(
		'tr_req_id'=>$task_id,
		'tr_user'=>$this->session->userdata['user']['username'],
		'tr_sub'=>$task_sub,
		'tr_content'=>$task_info,
		'tr_req_type'=>$task_type,
		'tr_sts'=>'1',
		'tr_dt_crtd'=>$dtaacreated,
		'tr_dt_updt'=>$dtaacreated,
	);



	$insert_id=$this->Admin_model->insert_data('task_comment_content',$data);
	$mail_send_sts=mail_req_info($insert_id);
	
	
	if($mail_send_sts)
	{
	$this->session->set_flashdata('success', 'Mail Successfully send');
	redirect('task-schedule');
	}
	else
	{
	$this->session->set_flashdata('errors', 'Error on sending mail.Please try again');
	redirect('task-schedule');
	}

}

function item_reply_request($item_req_id)
{
	if ($this->session->userdata('user'))
	{
    $sub_dept=$this->session->userdata['user']['sub_dept'];
    if ($sub_dept=='ksa') {
     $data['item_req_details']=$this->Admin_model->get_data('ksa_item_request',array('ir_id'=>$item_req_id));
    }
else{
			$data['item_req_details']=$this->Admin_model->get_data('item_request',array('ir_id'=>$item_req_id));
    }

		$item_req_prds=explode('|#|',$data['item_req_details'][0]->ir_prd_id);
		foreach($item_req_prds as $prd)
		{
				$data['prds'][]=$this->tm->get_data('products',array('pid'=>$prd));
		}
		  if ($sub_dept=='ksa')
		   {
              $data['req_reply']=$this->Admin_model->get_data('ksa_item_req_content',array('itr_req_id'=>$item_req_id));
		  }
		  else
		  {
		  	$data['req_reply']=$this->Admin_model->get_data('item_req_content',array('itr_req_id'=>$item_req_id));
		  }

		
		$this->load->view('admin/sales/item_reply_request',$data);
	}
	else
	{
		$data['page_current_url']='item_reply_request/'.$item_req_id;
		$this->load->view('admin/login',$data);
	}
}

function current_prd_qnty()
{
	$item_req_id=$this->input->post('item_re_id');

 $sub_dept=$this->session->userdata['user']['sub_dept'];
    if ($sub_dept=='ksa') 
    {

    		$item_req_details=$this->Admin_model->get_data('ksa_item_request',array('ir_id'=>$item_req_id));
    }
    else 
    {
    		$item_req_details=$this->Admin_model->get_data('item_request',array('ir_id'=>$item_req_id));
    }




	$prd_data=explode('|#|',$item_req_details[0]->ir_prd_id);

	$prd_qnty_org=explode('|#|',$item_req_details[0]->ir_prd_qnty);
	$html="<table class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
	$html.="<thead>";
	$html.="<th>Image</th>";
	$html.="<th>Name</th>";
	$html.="<th>Orginal Quantity</th>";
	$html.="<th>Accepted Quantity</th>";
	$html.="</thead>";
	$html.="<tbody>";

		foreach($prd_data as $index=>$pd3)
		{
				$prd_info=$this->tm->get_data('products',array('pid'=>$pd3));
			if(empty($prd_info[0]->p_prd_img))
			{
				$filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
			 if (file_exists($filename)) {
			 	$img_path=$filename;
				} else {
				$img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
			    }
			}
			else
			{
				$first_img_prd=explode(',',$prd_info[0]->p_prd_img);
				if(!empty($first_img_prd[0]))
			 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
			 	
			 	else
			 	$img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
			 	
			}
			$prd_name_db=explode('|--|',$prd_info[0]->pname);
			$html.="<tr>";
			$html.='
			<td><img src="'.$img_path.'" width="100" height="100"></td>
			<td>';	
			if(!empty($prd_name_db[1]))
						$html.= $prd_name_db[0].'<br/>'.$prd_name_db[1];
					else
						$html.= $prd_info[0]->pname;
				$html.= '<br/> <br/> Code '.$prd_info[0]->pcode;		
			$html.='</td>';
			$html.="<td><input type='text' readonly name='org_qnty[]' value='".$prd_qnty_org[$index]."'></td>";
			$html.="<td><input type='number' required='' name='accepted_qnty[]'  max='".$prd_qnty_org[$index]."'></td>";
			$html.="</tr>";
		}	

	$html.="</tbody>";
	$html.="</table>";
	$html.="<input type='hidden' name='item_req_id_accepted_data' value='".$item_req_id."'>";
	echo $html;
}





function current_prd_qnty_ksa()
{
	$item_req_id=$this->input->post('item_re_id');

 $sub_dept=$this->session->userdata['user']['sub_dept'];
  
    		$item_req_details=$this->Admin_model->get_data('ksa_item_request',array('ir_id'=>$item_req_id));
    
   



	$prd_data=explode('|#|',$item_req_details[0]->ir_prd_id);

	$prd_qnty_org=explode('|#|',$item_req_details[0]->ir_prd_qnty);
	$html="<table class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
	$html.="<thead>";
	$html.="<th>Image</th>";
	$html.="<th>Name</th>";
	$html.="<th>Orginal Quantity</th>";
	$html.="<th>Accepted Quantity</th>";
	$html.="</thead>";
	$html.="<tbody>";

		foreach($prd_data as $index=>$pd3)
		{
				$prd_info=$this->tm->get_data('products',array('pid'=>$pd3));
			if(empty($prd_info[0]->p_prd_img))
			{
				$filename="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpeg";
			 if (file_exists($filename)) {
			 	$img_path=$filename;
				} else {
				$img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($prd_info[0]->pcode).".jpg";
			    }
			}
			else
			{
				$first_img_prd=explode(',',$prd_info[0]->p_prd_img);
				if(!empty($first_img_prd[0]))
			 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
			 	
			 	else
			 	$img_path="https://birigroup.com/uploads/prd_images/".$prd_info[0]->p_prd_img."";
			 	
			}
			$prd_name_db=explode('|--|',$prd_info[0]->pname);
			$html.="<tr>";
			$html.='
			<td><img src="'.$img_path.'" width="100" height="100"></td>
			<td>';	
			if(!empty($prd_name_db[1]))
						$html.= $prd_name_db[0].'<br/>'.$prd_name_db[1];
					else
						$html.= $prd_info[0]->pname;
				$html.= '<br/> <br/> Code '.$prd_info[0]->pcode;		
			$html.='</td>';
			$html.="<td><input type='text' readonly name='org_qnty[]' value='".$prd_qnty_org[$index]."'></td>";
			$html.="<td><input type='number' required='' name='accepted_qnty[]'  max='".$prd_qnty_org[$index]."'></td>";
			$html.="</tr>";
		}	

	$html.="</tbody>";
	$html.="</table>";
	$html.="<input type='hidden' name='item_req_id_accepted_data' value='".$item_req_id."'>";
	echo $html;
}






function submit_adj_qnty()
{
	$item_req_id=$this->input->post('req_id');

	 $sub_dept=$this->session->userdata['user']['sub_dept'];
    
	$item_req_details=$this->Admin_model->get_data('item_request',array('ir_id'=>$item_req_id));


	
	
	$qntys=array_values(array_filter(explode('|#|',$this->input->post('acptd_qnty'))));
	if(!empty($qntys))
	{
//print_r($qntys);
	
	$org_qnty=explode('|#|', $item_req_details[0]->ir_prd_qnty);
	foreach($org_qnty as $ind=>$or)
	{
		if($qntys[$ind]>$or)
			{
			//$data=[];
				$update=false;
			}
			else
			{
				$update=true;	
			}	
	}
$data=array(
	'ir_req_status'=>'2',
	'ir_prd_qnty_accepted'=>implode('|#|', $qntys),
);
// foreach($prd_ids as $key=>$pid)
// {
// 	if(!empty($qntys[$key]))
// 	$to_update_qnty[]=$qntys[$key];
// 	else
// 		$to_update_qnty[]='0';
// }
	if(!empty($update))
	{
		//pre_list($data);

	
       
   
        $result=$this->Admin_model->update_data('item_request',$data,array('ir_id'=>$item_req_id));
   


////send mail, chnage sts of item request also////////
//mail_accepted_qnty($item_req_id);
$this->session->set_flashdata('success', 'Approved-Quantity successfully updated/adjusted');
echo true;
//redirect('task-schedule');
	}
		else
		{
			echo false;
		}
	}
	else
	{
		echo false;
	}
}


function submit_adj_qnty_ksa()
{
	$item_req_id=$this->input->post('req_id');

	 $sub_dept=$this->session->userdata['user']['sub_dept'];
  
    	$item_req_details=$this->Admin_model->get_data('ksa_item_request',array('ir_id'=>$item_req_id));


	
	
	$qntys=array_values(array_filter(explode('|#|',$this->input->post('acptd_qnty'))));
	if(!empty($qntys))
	{
//print_r($qntys);
	
	$org_qnty=explode('|#|', $item_req_details[0]->ir_prd_qnty);
	foreach($org_qnty as $ind=>$or)
	{
		if($qntys[$ind]>$or)
			{
			//$data=[];
				$update=false;
			}
			else
			{
				$update=true;	
			}	
	}
$data=array(
	'ir_req_status'=>'2',
	'ir_prd_qnty_accepted'=>implode('|#|', $qntys),
);
// foreach($prd_ids as $key=>$pid)
// {
// 	if(!empty($qntys[$key]))
// 	$to_update_qnty[]=$qntys[$key];
// 	else
// 		$to_update_qnty[]='0';
// }
	if(!empty($update))
	{
		


          $result=$this->Admin_model->update_data('ksa_item_request',$data,array('ir_id'=>$item_req_id));


        $this->session->set_flashdata('success', 'Approved-Quantity successfully updated/adjusted');
echo true;
//redirect('task-schedule');
	}
		else
		{
			echo false;
		}
	}
	else
	{
		echo false;
	}
}













function generate_shipment()
{


  if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='generate-shipment-item-request')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {




		 $sub_dept=$this->session->userdata['user']['sub_dept'];
    if ($sub_dept=='ksa') {


	$data['result']=$this->Admin_model->get_data('ksa_item_request',array('ir_sts'=>'1','ir_req_status <='=>'1'));

}
else{
	$data['result']=$this->Admin_model->get_data('item_request',array('ir_sts'=>'1','ir_req_status <='=>'1'));
}



	$this->load->view('admin/sales/generate_shipment_req',$data);
}

else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}
function choose_req()
{
	$item_choosed=$this->input->post('item_choosed');

$sub_dept=$this->session->userdata['user']['sub_dept'];
    if ($sub_dept=='ksa') {


    		$result=$this->Admin_model->get_data('ksa_item_request',array('ir_id'=>$item_choosed));
    }


else{
		$result=$this->Admin_model->get_data('item_request',array('ir_id'=>$item_choosed));

}

	$shipment_generated=$this->Admin_model->get_data('generate_shipment_details',array('gsd_item_req_id'=>$item_choosed),'1','','gsd_id','DESC');

	if(!empty($shipment_generated))
	{		
		$data['shipment_generated']=$shipment_generated;
		$prd_ids=explode(',', $shipment_generated[0]->gsd_prd_id);

		$data_prd['qnty']=explode(',', $shipment_generated[0]->gsd_prd_qty_remaining);

		foreach($prd_ids as $pindex=>$pid)
			 {
			 	if(array_filter($data_prd['qnty'])==true)
				{
					//echo "in if";
					$data_prd[]=$this->tm->get_data('products',array('pid'=>$pid));
				}
				else
				{
					//echo "in else";
					$data_prd[]='';
				}
			 	
			 }
			// pre_list($data_prd);
		// foreach($prd_id_new as $pid)
		// {
		// 	if(array_filter(input))
		// 	{
		// 		$prd_id_new[]=$prd_ids[$kk];
		// 	}
		// 	else
		// 	{
		// 		$prd_id_new[]='';
		// 	}
		// }
		// if(!empty($prd_id_new))
		// {
		// 	 foreach($prd_id_new as $pid)
		// 	 {
		// 	 	$data_prd[]=$this->tm->get_data('products',array('pid'=>$pid));
		// 	 }
		// }
	}
	else
	{
		$prd_ids=explode('|#|', $result[0]->ir_prd_id);
		$data_prd['qnty']=explode('|#|', $result[0]->ir_prd_qnty);
		 foreach($prd_ids as $pid)
		 {
		 	$data_prd[]=$this->tm->get_data('products',array('pid'=>$pid));
		 }
	}
//	pre_list($data_prd);
	echo json_encode($data_prd);
}

function submit_generate_shipment()
{
	$prd_id=$this->input->post('prdids');
	$prd_ids_exploded=explode('|#|', $prd_id);
	//print_r($prd_ids_exploded);
	$org_qnty=explode('|#|',$this->input->post('org_qntys'));
	$qty_shipped=explode('|#|',$this->input->post('qntys'));

	$qty_remaining=explode('|#|',$this->input->post('remaining_qnty'));
	$item_req=explode('|#|',$this->input->post('itemid'));

	$item_req_count=count($item_req);

	for($i=0;$i<$item_req_count;$i++)
	{
		$item_result=$this->Admin_model->get_data('item_request',array('ir_id'=>$item_req[$i]));
		$prd_ids=explode('|#|',$item_result[0]->ir_prd_id);
		$count_prd_ids=count($prd_ids);
		//pre_list($count_prd_ids);
		for($j=0;$j<$count_prd_ids;$j++)
		{
			$prd_data_array[$i][]=$prd_ids[$j];
			if($j<$count_prd_ids)
			{
				if($qty_shipped[$j]=='0')
				{
					$qty_shipped_array[$i][]=$qty_shipped[$j];
				$qty_remaining_array[$i][]=$org_qnty[$j];
				}
				else
				{
					$qty_shipped_array[$i][]=$qty_shipped[$j];
				$qty_remaining_array[$i][]=$qty_remaining[$j];
				}
				
			}
			unset($qty_shipped[$j]);
			unset($qty_remaining[$j]);
		}
			$qty_shipped = array_values($qty_shipped);
			$qty_remaining = array_values($qty_remaining);
	}

	foreach($item_req as $key=>$irq)
	{
		$new_prd_array[]=implode(',',$prd_data_array[$key]);
		$new_qty_shipped_array[]=implode(',',$qty_shipped_array[$key]);
		$new_qty_remaining_array[]=implode(',',$qty_remaining_array[$key]);
	}

	$data=array(
		'gs_user_session'=>$this->session->userdata['user']['username'],
		'gs_number'=>$this->input->post('gnr_no'),
		'gs_shiping_status'=>$this->input->post('shipment_sts'),
		'gs_date_shipment'=>$this->input->post('date_shipment'),
		'gs_extra_details'=>$this->input->post('extra_details'),
		'gs_sts'=>'1'
	);

	$insert_id=$this->Admin_model->insert_data('generate_shipment',$data);
	foreach($item_req as $key1=>$pa)
	{
		$data2=array(
			'gsd_gs_id'=>$insert_id,
			'gsd_item_req_id'=>$pa,
			'gsd_prd_id'=>$new_prd_array[$key1],
			'gsd_prd_qty_shipped'=>$new_qty_shipped_array[$key1],
			'gsd_prd_qty_remaining'=>$new_qty_remaining_array[$key1],
			'gsd_sts'=>'1',
		);

		$insert_id_2=$this->Admin_model->insert_data('generate_shipment_details',$data2);
	}
	 $this->session->set_flashdata('success', 'Shipment Generated successfully.');
	redirect('list-generate-shipment');
}

function submit_completed_extra_data()
{
	$req_id=$this->input->post('item_req_id');
	$data=array(
		'mrn'=>$this->input->post('mrn_num'),
		'pv'=>$this->input->post('pv_num'),
		'ir_req_status'=>$this->input->post('status_value'),
	);
	$this->Admin_model->update_data('item_request',$data,array('ir_id'=>$req_id));
	 $this->session->set_flashdata('success', 'Status Changed to completed');
	redirect('list-completed-item-request');
}

function list_generate_shipment()
{


 if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-generate-shipment')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {






	$data['result']=$this->Admin_model->get_data('generate_shipment',array('gs_shiping_status !='=>'6'));
	
	//pre_list($data['prd_data']);
	$this->load->view('admin/sales/list_generate_shipment',$data);

}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 



}


function view_shipment_details($gs_id)
{
		$data['shipment_details']=$this->Item_request_model->get_combined_item_generate_shipment(array('gsd_gs_id'=>$gs_id));
	
	foreach($data['shipment_details'] as $j=>$dd)
		{
			$exploded_prd_id=explode(',',$dd->gsd_prd_id);
				foreach($exploded_prd_id as $ep)
				{
					$data['prd_data'][$j][]=$this->tm->get_data('products',array('pid'=>$ep));
				}			
		}
	$this->load->view('admin/sales/view_generate_shipment',$data);
}


function generate_req_order($po_id)
{

//$quot_id=$this->input->post('quotation_id');

 $item_req_data= $this->Admin_model->get_data('item_request',array('ir_id'=>$po_id,'ir_sts'=>'1'));  
         
$prd_details=explode('|#|',$item_req_data[0]->ir_prd_id);
$po_qnty=explode('|#|',$item_req_data[0]->ir_prd_qnty);
$remarks=explode('|#|',$item_req_data[0]->ir_prd_extra_data);

foreach($prd_details as $index=>$pd)
{
	//print_r($pd);
	$prd_table_data[]=$this->tm->get_data('products',array('pid'=>$pd));
}

//$logged_users_details=$this->Admin_model->join_qry('login_credentials','employee_details','ed_login_id','log_id',array('log_uname'=>$this->session->userdata['user']['username']),('employee_details.*,login_credentials.*'));

//print_r($prd_table_data);
//print_r($logged_users_details);

$stylesheet = file_get_contents('style_mpdf.css');

	$html='<!doctype html>
<head>
          
</head>

    <body> ';
				$html.='
				<div class="content">
				<table border="0" width="100%">
				<tr >
					<td align="left" rowspan="3"><h1 style="text-align:left">Item Request </h1></td>
					
					<td style="text-align:right;" align="right">
						<div style="text-align:right;">
							<p align="right" style="text-align:justify;">Created by: '.$item_req_data[0]->ir_user_created.'</p>
							
							<p align="right" style="text-align:justify;">Item Request No: #'.$item_req_data[0]->ir_req_no.'</p>
							
							
						</div>
					</td>
				</tr>
				
				
				</table>
				
				
				
				</div>';

			$order_type=$item_req_data[0]-> ir_req_status;
				
					$value_status_fact;
					switch($order_type)
					{
						case '1':
						$value_status_fact="New Request";
						break;
						case '2':
						$value_status_fact="Request Approved";
						break;
						case '3':
						$value_status_fact="Request Ordered";
						break;
						case '4':
						$value_status_fact="Ready for shippment ";
						break;
						case '5':
						$value_status_fact="Shipped";
						break;
						case '0':
						$value_status_fact="Request Rejected";
						break;
						default:
						$value_status_fact="";
						break;
					}
				$html.='<table align="center" class="cusotmer_info"  width="80%" border="1">';
				
				$html.='
				<tr>
					<td>Order Created on: '.$item_req_data[0]->ir_order_date.'</td>
					<td>Delivery Type: '.$item_req_data[0]->ir_delivery_type.'</td>
						
				</tr>
				<tr>
					<td>Department: Purchase</td>';
					
					if(!empty($item_req_data[0]-> ir_exact_delivery_date)){
					$html.='<td>Exact date of delivery: '.$item_req_data[0]-> ir_exact_delivery_date.'</td>';
					}
					
					$html.='</tr>
					<tr><td>Current Status: '.$value_status_fact.'</td>';
				if($item_req_data[0]->ir_req_status=='1' || $item_req_data[0]->ir_req_status=='2')
				{
				$html.='<td><b>Request Created on:</b><br/>'.$item_req_data[0]->ir_order_date.'</td>';
				}
				elseif(($item_req_data[0]->ir_req_status>'2') && ($item_req_data[0]->ir_req_status<'5'))
				{
				$html.='<td><b>ESD:</b>'.$item_req_data[0]->expected_shipment_date.'</td>';
				}
				elseif(($item_req_data[0]->ir_req_status=='5') )
				{
				$html.='<td><b>ETA:</b>'.$item_req_data[0]->ir_eta.'</td>';
				}
				else{
				$html.='<td></td>';
				}
					
					
				$html.='</tr>';
				
				$html.='<tr>
				<td colspan="2">Subject : '.$item_req_data[0]->ir_req_title.'</td></tr>';
						
				$html.='</table>


				<table align="center" class="prd_info"  width="80%" border="1">
					<tr class="prd_head" >
					 <td align="center">No.#</td>
					 <td align="center">Picture</td>
					 <td align="center">Model No.</td>
					 <td align="center">Product Description</td>
					 <td align="center" width="10%">Qty</td>
					   <td align="center">Remarks</td>
					</tr>';
$i=1;

					foreach($prd_table_data as $index=>$pd3)
					{
						
						if(empty($pd3[0]->p_prd_img))
						{
							$filename="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpeg";
						 if (file_exists($filename)) {
						 	$img_path=$filename;
							} else {
							$img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpg";
						    }
						}
						else
						{
							$first_img_prd=explode(',',$pd3[0]->p_prd_img);
							if(!empty($first_img_prd[0]))
						 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
						 	
						 	else
						 	$img_path="https://birigroup.com/uploads/prd_images/".$pd3[0]->p_prd_img."";
						 	
						}
						
						//print_r($img_path);
						$pname=explode('|~~|',$pd3[0]->pname);
						if(!empty($pname[0]))
						{
							$prd_names=explode(',',$pname[0]);
							$product_name=$prd_names[0];
							//$product_name=$pname[0];
						}
						else
						{
						 	$pname=explode(',',$pd3[0]->pname);
						 	$product_name=$pname[0];
						}
						//$product_name=$pname;
						


					$html.='<tr style="text-align:center;">
					 <td align="center">'.$i++.'</td>';

					 if(!empty($img_path))
					 $html.='<td align="center"><img src="'.$img_path.'" width="100" height="100"></td>';
					else
						 $html.='<td align="center">'.$product_name.'</td>';

					 $html.='<td align="center">'.$pd3[0]->pcode.'</td>';
					 
					 $html.='<td>'.$product_name.'</td>';
					
						
					
					  $html.='<td align="center">'.$po_qnty[$index].'</td>
					
					  <td align="center">'.$remarks[$index].'</td>
					</tr>';
				}
				
					
				$html.='</table>';

if(!empty($item_req_data[0]->ir_extra_details))
{
				$html.='
		
				<div style="padding-left:2%;">
<p>Additional Note :  '.$item_req_data[0]->ir_extra_details.' </p></div>';
}
//$files_attached=array();


			$html.='</body>
					</html>';

					//echo $html;
//$header_image=base_url('admin_assets/header_pdf.png');
 $pdfFilePath = 'item-request'.$item_req_data[0]-> ir_id.'.pdf';
	  
		 $this->load->library('m2_pdf');
		 $this->m2_pdf->pdf->SetHeader('<img src="'.base_url("berry_header.png").'">');
		  $this->m2_pdf->pdf->SetFooter('<img src="'.base_url("berry_footer.png").'">');
		  
		    	//$this->m2_pdf->autoScriptToLang = true;
			//$this->m2_pdf->autoLangToFont = true;
		 // $this->m2_pdf->pdf->autoArabic=true;
		  $this->m2_pdf->pdf->WriteHTML($stylesheet,1);
		  $this->m2_pdf->pdf->AddPage('', // L - landscape, P - portrait 
        '', '', '', '',
        5, // margin_left
        5, // margin right
       35, // margin top
       20, // margin bottom
        0, // margin header
        0); // margin footer
        
          //$this->m2_pdf->pdf->SetDirectionality('rtl');
         //    $this->m2_pdf->pdf->autoScriptToLang = true;
         // $this->m2_pdf->pdf->autoLangToFont   = true;
           //$this->m2_pdf->pdf->autoArabic=true;
            
            
	     $this->m2_pdf->pdf->WriteHTML($html,2);
	     
	     //save in folder
		$this->m2_pdf->pdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");

  		$this->m2_pdf->pdf->Output($pdfFilePath,'D');
  		
  		//echo $html;
}






function generate_req_order_ksa($po_id)
{

//$quot_id=$this->input->post('quotation_id');

 $item_req_data= $this->Admin_model->get_data('ksa_item_request',array('ir_id'=>$po_id,'ir_sts'=>'1'));  
         
$prd_details=explode('|#|',$item_req_data[0]->ir_prd_id);
$po_qnty=explode('|#|',$item_req_data[0]->ir_prd_qnty);
$remarks=explode('|#|',$item_req_data[0]->ir_prd_extra_data);

foreach($prd_details as $index=>$pd)
{
	//print_r($pd);
	$prd_table_data[]=$this->tm->get_data('products',array('pid'=>$pd));
}

//$logged_users_details=$this->Admin_model->join_qry('login_credentials','employee_details','ed_login_id','log_id',array('log_uname'=>$this->session->userdata['user']['username']),('employee_details.*,login_credentials.*'));

//print_r($prd_table_data);
//print_r($logged_users_details);

$stylesheet = file_get_contents('style_mpdf.css');

	$html='<!doctype html>
<head>
          
</head>

    <body> ';
				$html.='
				<div class="content">
				<table border="0" width="100%">
				<tr >
					<td align="left" rowspan="3"><h1 style="text-align:left">Item Request </h1></td>
					
					<td style="text-align:right;" align="right">
						<div style="text-align:right;">
							<p align="right" style="text-align:justify;">Created by: '.$item_req_data[0]->ir_user_created.'</p>
							
							<p align="right" style="text-align:justify;">Item Request No: #'.$item_req_data[0]->ir_req_no.'</p>
							
							
						</div>
					</td>
				</tr>
				
				
				</table>
				
				
				
				</div>';

			$order_type=$item_req_data[0]-> ir_req_status;
				
					$value_status_fact;
					switch($order_type)
					{
						case '1':
						$value_status_fact="New Request";
						break;
						case '2':
						$value_status_fact="Request Approved";
						break;
						case '3':
						$value_status_fact="Request Ordered";
						break;
						case '4':
						$value_status_fact="Ready for shippment ";
						break;
						case '5':
						$value_status_fact="Shipped";
						break;
						case '0':
						$value_status_fact="Request Rejected";
						break;
						default:
						$value_status_fact="";
						break;
					}
				$html.='<table align="center" class="cusotmer_info"  width="80%" border="1">';
				
				$html.='
				<tr>
					<td>Order Created on: '.$item_req_data[0]->ir_order_date.'</td>
					<td>Delivery Type: '.$item_req_data[0]->ir_delivery_type.'</td>
						
				</tr>
				<tr>
					<td>Department: Purchase</td>';
					
					if(!empty($item_req_data[0]-> ir_exact_delivery_date)){
					$html.='<td>Exact date of delivery: '.$item_req_data[0]-> ir_exact_delivery_date.'</td>';
					}
					
					$html.='</tr>
					<tr><td>Current Status: '.$value_status_fact.'</td>';
				if($item_req_data[0]->ir_req_status=='1' || $item_req_data[0]->ir_req_status=='2')
				{
				$html.='<td><b>Request Created on:</b><br/>'.$item_req_data[0]->ir_order_date.'</td>';
				}
				elseif(($item_req_data[0]->ir_req_status>'2') && ($item_req_data[0]->ir_req_status<'5'))
				{
				$html.='<td><b>ESD:</b>'.$item_req_data[0]->expected_shipment_date.'</td>';
				}
				elseif(($item_req_data[0]->ir_req_status=='5') )
				{
				$html.='<td><b>ETA:</b>'.$item_req_data[0]->ir_eta.'</td>';
				}
				else{
				$html.='<td></td>';
				}
					
					
				$html.='</tr>';
				
				$html.='<tr>
				<td colspan="2">Subject : '.$item_req_data[0]->ir_req_title.'</td></tr>';
						
				$html.='</table>


				<table align="center" class="prd_info"  width="80%" border="1">
					<tr class="prd_head" >
					 <td align="center">No.#</td>
					 <td align="center">Picture</td>
					 <td align="center">Model No.</td>
					 <td align="center">Product Description</td>
					 <td align="center" width="10%">Qty</td>
					   <td align="center">Remarks</td>
					</tr>';
$i=1;

					foreach($prd_table_data as $index=>$pd3)
					{
						
						if(empty($pd3[0]->p_prd_img))
						{
							$filename="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpeg";
						 if (file_exists($filename)) {
						 	$img_path=$filename;
							} else {
							$img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpg";
						    }
						}
						else
						{
							$first_img_prd=explode(',',$pd3[0]->p_prd_img);
							if(!empty($first_img_prd[0]))
						 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
						 	
						 	else
						 	$img_path="https://birigroup.com/uploads/prd_images/".$pd3[0]->p_prd_img."";
						 	
						}
						
						//print_r($img_path);
						$pname=explode('|~~|',$pd3[0]->pname);
						if(!empty($pname[0]))
						{
							$prd_names=explode(',',$pname[0]);
							$product_name=$prd_names[0];
							//$product_name=$pname[0];
						}
						else
						{
						 	$pname=explode(',',$pd3[0]->pname);
						 	$product_name=$pname[0];
						}
						//$product_name=$pname;
						


					$html.='<tr style="text-align:center;">
					 <td align="center">'.$i++.'</td>';

					 if(!empty($img_path))
					 $html.='<td align="center"><img src="'.$img_path.'" width="100" height="100"></td>';
					else
						 $html.='<td align="center">'.$product_name.'</td>';

					 $html.='<td align="center">'.$pd3[0]->pcode.'</td>';
					 
					 $html.='<td>'.$product_name.'</td>';
					
						
					
					  $html.='<td align="center">'.$po_qnty[$index].'</td>
					
					  <td align="center">'.$remarks[$index].'</td>
					</tr>';
				}
				
					
				$html.='</table>';

if(!empty($item_req_data[0]->ir_extra_details))
{
				$html.='
		
				<div style="padding-left:2%;">
<p>Additional Note :  '.$item_req_data[0]->ir_extra_details.' </p></div>';
}
//$files_attached=array();


			$html.='</body>
					</html>';

					//echo $html;
//$header_image=base_url('admin_assets/header_pdf.png');
 $pdfFilePath = 'item-request'.$item_req_data[0]-> ir_id.'.pdf';
	  
		 $this->load->library('m2_pdf');
		 $this->m2_pdf->pdf->SetHeader('<img src="'.base_url("ksa-header-new.png").'">');
		  $this->m2_pdf->pdf->SetFooter('<img src="'.base_url("ksa-footer-new.png").'">');
		  
		    	//$this->m2_pdf->autoScriptToLang = true;
			//$this->m2_pdf->autoLangToFont = true;
		 // $this->m2_pdf->pdf->autoArabic=true;
		  $this->m2_pdf->pdf->WriteHTML($stylesheet,1);
		  $this->m2_pdf->pdf->AddPage('', // L - landscape, P - portrait 
        '', '', '', '',
        5, // margin_left
        5, // margin right
       35, // margin top
       20, // margin bottom
        0, // margin header
        0); // margin footer
        
          //$this->m2_pdf->pdf->SetDirectionality('rtl');
         //    $this->m2_pdf->pdf->autoScriptToLang = true;
         // $this->m2_pdf->pdf->autoLangToFont   = true;
           //$this->m2_pdf->pdf->autoArabic=true;
            
            
	     $this->m2_pdf->pdf->WriteHTML($html,2);
	     
	     //save in folder
		$this->m2_pdf->pdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");

  		$this->m2_pdf->pdf->Output($pdfFilePath,'D');
  		
  		//echo $html;
}



}









































