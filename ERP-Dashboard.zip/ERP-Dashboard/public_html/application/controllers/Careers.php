<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Careers extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->model(array('Account_model'));
		$this->load->helper(array('session','gnrl','img','email'));	
			require 'vendor/autoload.php';
		require_once 'vendor/khaled.alshamaa/ar-php/src/Arabic.php';	

	}

function add_jobs($job_id=null)
{
if(logged_in())
{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='add-jobs')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {
	if(!empty($job_id))
	{
	$data['result']=$this->Admin_model->get_data('add_jobs',array('j_sts'=>'1','j_id'=>$job_id));
	$this->load->view('admin/hr/add_jobs',$data);
	}
	else
	{
	$this->load->view('admin/hr/add_jobs');
	}

	}

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


}
}

function list_jobs()
{
	if(logged_in())
	{
             $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='list-jobs')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

	$data['result']=$this->Admin_model->get_data('add_jobs',array('j_sts'=>'1'));
	$this->load->view('admin/hr/list_jobs',$data);
}

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


	}
}

function delete_job_details($job_id)
{
$this->Admin_model->update_data('add_jobs',array('j_sts'=>'0'),array('j_id'=>$job_id));
$this->session->set_flashdata('success', 'Data deleted successfully');
redirect('list-jobs','refersh');
}

function submit_add_jobs()
{
$job_id=$this->input->post('update_job_id');
$data1=array(
			'j_title'=>$this->input->post('job_title'),
			'j_location'=>$this->input->post('location'),
			'j_slug'=>prd_slug($this->input->post('job_title')),
			'j_emp_type'=>$this->input->post('emp_type'),
			'j_cntrct_type'=>implode(',',$this->input->post('contract_type')),
			'j_salary'=>$this->input->post('salary'),
			'j_desc'=>$this->input->post('job_desc'),
			'j_sts'=>'1',
			);
if(empty($job_id))
{
$this->Admin_model->insert_data('add_jobs',$data1);
$this->session->set_flashdata('success', 'Data added successfully');
redirect('add-jobs','refersh');
}
else
{
$this->Admin_model->update_data('add_jobs',$data1,array('j_id'=>$job_id));
$this->session->set_flashdata('success', 'Data updated successfully');
redirect('list-jobs','refersh');
}


		

}


function job_offer($id=null)
{
//$this->Admin_model->update_data('add_jobs',array('j_sts'=>'0'),array('j_id'=>$job_id));
//$this->session->set_flashdata('success', 'Data deleted successfully');
//redirect('job-offer','refersh');
   

//$data['master_company']=$this->Admin_model->get_data('master_company',array('mcomp_sts'=>'1','mcomp_pid'=>'0'));
		//foreach($data['master_company'] as $key=>$er)
		//{
		//	$data['child'][$key][]=$this->Admin_model->get_data('master_company',array('mcomp_sts'=>'1','mcomp_pid'=>$er->mcomp_id));
		//}

	if(empty($id)){
		
      $data['languages_skill']=$this->Admin_model->get_data('languages_skill');
	$data['master_company']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0','mcomp_pid !='=>'0'));
	$data['position_name']=$this->Admin_model->get_data('positions',array('position_sts'=>'1'));
	$data['nationality']=$this->Admin_model->get_data('country_val',array('status'=>'1'));
	$this->load->view('admin/hr/job_offer',$data);	
}
else{

//$data['result']=$this->Admin_model->get_data('job_offer',array('job_id'=>$id));


$sql2=$this->db->query("SELECT jof.*,mc.mcomp_name,pot.position_name,nat.name FROM job_offer as jof join master_company as mc on mc.mcomp_id=jof.jo_master_comp join positions as pot on pot.pos_id=jof.jo_position_id join country_val as nat on nat.country_id=jof.jo_recipt_nationality WHERE job_id='".$id."'  order by jof.job_id  DESC");



		$data['result']=$sql2->result();



$data['master_company']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0','mcomp_pid !='=>'0'));
	$data['position_name']=$this->Admin_model->get_data('positions',array('position_sts'=>'1'));
	$data['nationality']=$this->Admin_model->get_data('country_val',array('status'=>'1'));
	$this->load->view('admin/hr/job_offer',$data);
		//$data['result']=$sql2->result();


}

}


function submit_job_offer()
{


	$update_job_offer=$this->input->post('update_job_offer');



   $master_company_branch=$this->input->post('master_company');
   $total_salary=$this->input->post('tot_salary');

 $branch=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0','mcomp_id '=> $master_company_branch));
$Mastercomp=$branch[0]->mcomp_pid;
//to get precentage of salary depending on branch or company that employee had offer in it//////////////
$Basic_salary_precentage=$this->Admin_model->get_data('emp_sal_structure',array('struct_detail_name '=>'Basic Salary','branch_company '=> $Mastercomp));


$Housing_precentage=$this->Admin_model->get_data('emp_sal_structure',array('struct_detail_name '=>'Housing Allowance','branch_company '=> $Mastercomp));
$Transport_precentage=$this->Admin_model->get_data('emp_sal_structure',array('struct_detail_name '=>'Transport / Petrol','branch_company '=> $Mastercomp));
$Telephone_precentage=$this->Admin_model->get_data('emp_sal_structure',array('struct_detail_name '=>'Telephone allowance','branch_company '=> $Mastercomp));
$Food_precentage=$this->Admin_model->get_data('emp_sal_structure',array('struct_detail_name '=>'Food Allowance','branch_company '=> $Mastercomp));
$Car_precentage=$this->Admin_model->get_data('emp_sal_structure',array('struct_detail_name '=>'Car Allowance (if any)','branch_company '=> $Mastercomp));
$Other_precentage=$this->Admin_model->get_data('emp_sal_structure',array('struct_detail_name '=>'Other allowances','branch_company '=> $Mastercomp));



$Over_time='Over time';


$salary_details_arr[0]=$Basic_salary_precentage[0]->struct_detail_name;
$salary_details_arr[1]=$Housing_precentage[0]->struct_detail_name;
$salary_details_arr[2]=$Transport_precentage[0]->struct_detail_name;
$salary_details_arr[3]=$Telephone_precentage[0]->struct_detail_name;
$salary_details_arr[4]=$Food_precentage[0]->struct_detail_name;
$salary_details_arr[5]=$Car_precentage[0]->struct_detail_name;
$salary_details_arr[6]=$Other_precentage[0]->struct_detail_name;
$salary_details_arr[7]=$Over_time;


$working_hour=doubleval($this->input->post('jo_working_hours'));

//////////////////////additional code//////////////////
$Basic_and_over_time_hour=round(floatval($working_hour*(26)),1);
$over_time_hour=round(floatval(($Basic_and_over_time_hour-208)*1.25),1);
$total_paid_hour=round(floatval($over_time_hour+208),1);
 $time_price_per_hour=round(floatval((($total_salary)/2)/$total_paid_hour),1);
 $test=round(floatval($time_price_per_hour*1.25),1);
 $fixed_overtime=round(floatval(($Basic_and_over_time_hour-208)*$test),1);
 $Basic_salary=round(floatval(($total_salary-$fixed_overtime)/2),1);

$total_over_time_pay_per_monthrounded=$fixed_overtime;
$total_Without_overtime=round(floatval($total_salary-$fixed_overtime),1);
$Housing= round(floatval($total_Without_overtime*(($Housing_precentage[0]->precentage)/100)),1);
 $other_allowance_amount=round(floatval($total_salary-$total_Without_overtime));
$salary_precentage_arr[0]= $Basic_salary;

$salary_precentage_arr[1]=$Housing;
$salary_precentage_arr[2]=round(floatval($total_Without_overtime*(($Transport_precentage[0]->precentage)/100)),1); 


$salary_precentage_arr[3]=round(floatval($total_Without_overtime*(($Telephone_precentage[0]->precentage)/100)),1);

$salary_precentage_arr[4]=round(floatval($total_Without_overtime*(($Food_precentage[0]->precentage)/100)),1);

$salary_precentage_arr[5]=round(floatval($total_Without_overtime*(($Car_precentage[0]->precentage)/100)),1);

$salary_precentage_arr[6]= round(floatval($total_Without_overtime*(($Other_precentage[0]->precentage)/100)),1);

$salary_precentage_arr[7]= round(floatval($total_over_time_pay_per_monthrounded),1);

$emp_salary_details=implode(',',$salary_details_arr);

$emp_salary_precentage=implode(',',$salary_precentage_arr);

$lang_interest_array=$this->input->post('languages[]');
        	$new_lang=implode(',',$lang_interest_array);

	if ($update_job_offer=='-1')
	{
	$offer_datecreate=get_date_time();
$offer_update=get_date_time();
$data1=array(
			'jo_master_comp'=>$Mastercomp,
			'jo_position_id'=>$this->input->post('position_name'),
			'jo_branch'=>$master_company_branch,
			'jo_working_hours'=>$this->input->post('jo_working_hours'),

			'jo_to_hour'=>$this->input->post('jo_to_hour'),

			'jo_from_hour'=>$this->input->post('jo_from_hour'),

			'jo_from_brk'=>$this->input->post('jo_from_brk'),
			'jo_to_brk'=>$this->input->post('jo_to_brk'),
                                           
			'jo_total_salary'=>$this->input->post('tot_salary'),
		    'salary_details'=>$emp_salary_details,
			'salary_precentage'=>$emp_salary_precentage,

			'jo_contract_yr_num'=>$this->input->post('jo_contract_yr_num'),

			'jo_recipt_name'=>$this->input->post('jo_recipt_name'),
			'jo_recipt_name_ar'=>$this->input->post('jo_recipt_name_ar'),

			'jo_recipt_nationality'=>$this->input->post('jo_recipt_nationality'),

			'day_start'=>$this->input->post('day_start'),
			'day_end'=>$this->input->post('day_end'),

                   'day_off'=>$this->input->post('day_off'),
			'increment_sts'=>$this->input->post('increment_sts'),
               'increment_amount'=>$this->input->post('increment_amount'),
                   'probation_period'=>$this->input->post('probation_period'),
                   'termination_employee'=>$this->input->post('termination_employee'),
                   'termination_employer'=>$this->input->post('termination_employer'),
                   'languages'=>$new_lang,
                   'offer_crtd'=>$offer_datecreate,
                  'offer_updt'=>$offer_update,
             	'jo_phone'=>$this->input->post('jo_phone'),
			'jo_email'=>$this->input->post('jo_email'),
			'jo_status'=>'1',
			);

$this->Admin_model->insert_data('job_offer',$data1);
$this->session->set_flashdata('success', 'Data added successfully');
redirect('list_job_offer','refersh');
}

 else
{
$offer_update=get_date_time();

$data2=array(
			'jo_master_comp'=>$Mastercomp,
			'jo_position_id'=>$this->input->post('position_name'),
			'jo_branch'=>$master_company_branch,
			'jo_working_hours'=>$this->input->post('jo_working_hours'),

			'jo_to_hour'=>$this->input->post('jo_to_hour'),

			'jo_from_hour'=>$this->input->post('jo_from_hour'),
			'jo_from_brk'=>$this->input->post('jo_from_brk'),
			'jo_to_brk'=>$this->input->post('jo_to_brk'),
                                           
			'jo_total_salary'=>$this->input->post('tot_salary'),
		    'salary_details'=>$emp_salary_details,
			'salary_precentage'=>$emp_salary_precentage,

			'jo_contract_yr_num'=>$this->input->post('jo_contract_yr_num'),

			'jo_recipt_name'=>$this->input->post('jo_recipt_name'),
			'jo_recipt_name_ar'=>$this->input->post('jo_recipt_name_ar'),

			'jo_recipt_nationality'=>$this->input->post('jo_recipt_nationality'),

			'day_start'=>$this->input->post('day_start'),
			'day_end'=>$this->input->post('day_end'),

                   'day_off'=>$this->input->post('day_off'),
			'increment_sts'=>$this->input->post('increment_sts'),
               'increment_amount'=>$this->input->post('increment_amount'),
                   'probation_period'=>$this->input->post('probation_period'),
                   'termination_employee'=>$this->input->post('termination_employee'),
                   'termination_employer'=>$this->input->post('termination_employer'),
                   'languages'=>$new_lang,
                   //'offer_crtd'=>$this->input->post('offer_crtd'),
                   
                    'offer_updt'=>$offer_update,
             	'jo_phone'=>$this->input->post('jo_phone'),
			'jo_email'=>$this->input->post('jo_email'),

			);



$this->Admin_model->update_data('job_offer',$data2,array('job_id'=>$update_job_offer));
$this->session->set_flashdata('success', 'Data updated successfully');
redirect('list_job_offer','refersh');
}

}

function delete_job_offer_details($job_id)
{
$this->Admin_model->update_data('job_offer',array('jo_sts'=>'0'),array('job_id'=>$job_id));
$this->session->set_flashdata('success', 'Data deleted successfully');
redirect('list_job_offer','refersh');
}



function job_offer_approve($job_id)
{
$this->Admin_model->update_data('job_offer',array('jo_status'=>'2'),array('job_id'=>$job_id));
$this->session->set_flashdata('success', 'Job Offer Approved');
redirect('list_job_offer','refersh');
}
function job_offer_reject($job_id)
{
$this->Admin_model->update_data('job_offer',array('jo_status'=>'0'),array('job_id'=>$job_id));
$this->session->set_flashdata('success', 'Job Offer Deleted');
redirect('list_job_offer','refersh');
}











function list_job_offer()
{
	if(logged_in())
	{
            $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='job_offer_manage')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

              $data['user_cred']='manage';
			   }


	


		$sql7=$this->db->query("SELECT jof.*,mc.mcomp_name,pot.position_name,nat.name FROM job_offer as jof join master_company as mc on mc.mcomp_id=jof.jo_master_comp join positions as pot on pot.pos_id=jof.jo_position_id join country_val as nat on nat.country_id=jof.jo_recipt_nationality WHERE jof.jo_status !='0' order by jof.job_id  DESC");


         
		$data['result']=$sql7->result();
		//$data['resultlang']=$this->Admin_model->get_data('languages_skill');
		
		// print_r($data);
		// exit(0);

	$this->load->view('admin/hr/list_job_offer',$data);
//}

     // else{
	//		//echo false;
//$this->session->unset_userdata('user', null);
	     //   	redirect('login','refersh');
		//}  


	}
}



function job_offer_draft($job_id)
{
	require 'vendor/autoload.php';
		require_once 'vendor/khaled.alshamaa/ar-php/src/Arabic.php';
	if(logged_in())
	{




$sqloffer=$this->db->query("SELECT jof.*,mc.mcomp_name,pot.position_name,nat.name FROM job_offer as jof join master_company as mc on mc.mcomp_id=jof.jo_master_comp join positions as pot on pot.pos_id=jof.jo_position_id join country_val as nat on nat.country_id=jof.jo_recipt_nationality  WHERE job_id='".$job_id."'  order by jof.job_id  DESC");


$job_offer_data=$sqloffer->result();


		//$sale_id=$this->input->post('sales_inv_id');
		//$invoice_pdf_type=$this->input->post('pdf-print-option');

		///for english - arabic number in words//////
 		$Arabic = new \ArPHP\I18N\Arabic();
 		 $Arabic->setNumberFeminine(1);
    	$Arabic->setNumberFormat(1);
    	///////end en-ar words/////////
  

		if(!empty($job_id))
		{
$master_company=$job_offer_data[0]->mcomp_name;




////for chosing the headaer depending on 
if($master_company=="Dubai - BERRY")
  {
  	$Position_At_company='Berry Building Materials';
  	$Position_At_company_ar='بيري لتجارة مواد البناء';
  }
elseif($master_company=="KSA")
    {
    	$Position_At_company='Biri Trading Est.';
    	$Position_At_company_ar='مؤسسة بيري التجارية';
    }
	elseif($master_company=="FACTORY")
 {
		   $Position_At_company='Biri Industries';
		    $Position_At_company_ar='بيري للصناعات';;
		   }
      else{}

$salary_details=explode(',',$job_offer_data[0]->salary_details);
$salary_precentage=explode(',',$job_offer_data[0]->salary_precentage);

//print_r($salary_precentage);
//exit(0);

$other_val=intval($salary_precentage[4])+(intval($salary_precentage[5]))+(intval($salary_precentage[6]));
//print_r($other_val);
//exit(0);


$position_name=$job_offer_data[0]->position_name;

$company_branch=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$job_offer_data[0]->jo_branch));

$working_place_branch=$company_branch[0]->mcomp_name;

 switch ($working_place_branch) {
        case 'UAE - Garhoud':
            
            $working_place_branch_ar =' دبي القرهود  ';
            break;

       case 'UAE-BANIYAS BRANCH':
            
            $working_place_branch_ar =' دبي  بانياس  ';
            break;
			case 'UAE - Diera':
            
            $working_place_branch_ar =' دبي  الديرة  ';
            break;
			case 'UAE - Dragon':
            
            $working_place_branch_ar =' دبي السوق الصيني دراجون  ';
            break;
			case 'KSA - Riyadh':
            
            $working_place_branch_ar =' السعودية -الرياض ';
            break;

			case 'FACTORY':
            
            $working_place_branch_ar =' السعودية جدة  ';
            break;
				case 'Dubai Store':
            $working_place_branch_ar ='مكتب رأس الخور';
			$working_place_branch='Ras Al-Khour Office';
            break;
            default:
            $working_place_branch_ar ='   ';
            break;
    }



$stylesheet = file_get_contents('style_mpdf.css');

if($master_company=="KSA")
     {
    	

     $currency_type='SR';
     $currency_type_ar='ريال ';



}
else
{
   $currency_type='AED';
   $currency_type_ar='درهم  ';


}

$position_details=$this->Admin_model->get_data('positions',array('pos_id'=>$job_offer_data[0]->jo_position_id));

$job_description=$position_details[0]->job_description;
$job_description_ar=$position_details[0]->job_description_ar;


$responsibilities=$position_details[0]->position_responsibilities;
$responsibilities_ar=$position_details[0]->position_responsibilities_ar;


$requirements=$position_details[0]->position_requirement;
$requirements_ar=$position_details[0]->position_requirement_ar;


$position_brief=$position_details[0]->position_brief;
$position_brief_ar=$position_details[0]->position_brief_ar;


$position_name_ar=$position_details[0]->position_name_ar;

$knowledge_skills_ability=$position_details[0]->knowledge_skills_ability;
$knowledge_skills_ability_ar=$position_details[0]->knowledge_skills_ability_ar;



if($job_offer_data[0]->name=="Afghanistan")
   {  $nationality_en="Afghan";
	$nationality_ar="الافغانية";

	} 

else if($job_offer_data[0]->name=="India")
 {  $nationality_en="indian";
	$nationality_ar="الهندية";

	} 

else if($job_offer_data[0]->name=="Pakistan")
 {  $nationality_en="Pakistani";
	$nationality_ar="باكستاني  ";

	}

	else if($job_offer_data[0]->name=="Syria")
 {  $nationality_en="syrian";
	$nationality_ar=" سوري   ";

	}

	else if($job_offer_data[0]->name=="Philippines")
 {  $nationality_en="Philippine, Filipino";
	$nationality_ar="فلبين  ";

	}
		else if($job_offer_data[0]->name=="Jordan")
 {  $nationality_en="Jordanian";
	$nationality_ar="اردني";

	}

else {}



if ($job_offer_data[0]->languages=="english")
  $language_skill_ar=" الانجليزية  ";
else if($job_offer_data[0]->languages=="arabic")
  $language_skill_ar=" العربية   ";

else if($job_offer_data[0]->languages=="english,arabic")
 $language_skill_ar=" العربية والانجليزية بطلاقة    ";



/*
////////////////for qr code////////////////////////////
$this->load->library('ciqrcode');
//header("Content-Type: image/png");
$params['data'] = base_url('load_invoice_data/'.$siv_data[0]->si_doc_no);
$params['level'] = 'H';
$params['size'] = 10;
$params['savename'] = './uploads/qr_code/'.$siv_data[0]->si_doc_no.'.png';
 $this->ciqrcode->generate($params);
//echo '<img src="'.base_url().'/uploads/inv_pdf/tes.png" />';
///////////qr code ends//////////////////////////////////////////
*/

$html='<!doctype html>';


$html.='<head></head><body>';
/*if ($invoice_pdf_type == '1') {
					$html .= '<div style="position: absolute; visibility: visible; left: 680px; top: 120px; z-index: 200;"><img align="bottom"  src="' . base_url() . '/uploads/qr_code/' . $siv_data[0]->si_doc_no . '.png" width="100" height="100"/></div>';
				}
				else{
					$html .= '<div style="position: absolute; visibility: visible; left: 680px; top: 230px; z-index: 200;"><img align="bottom"  src="' . base_url() . '/uploads/qr_code/' . $siv_data[0]->si_doc_no . '.png" width="100" height="100"/></div>';

				}*/
$html.='
				<div class="contentimgoffer">
				<div class="content">';
$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">';
$html.='<tbody>';

$html.='<tr style="height:562pt">';
$html.='<td style="width:258pt;border-right-style:solid;border-right-width:1pt">';

$html.='<p class="s1" style="padding-left: 35pt;text-indent: 0pt;line-height: 14pt;text-align: left;">EMPLOYMENT OFFER LETTER</p>';

$html.='<p style="text-indent: 0pt;text-align: left;">';
$html.='<br> </p>';




$html.='<p class="s1" style="padding-left: 2pt;text-indent: 0pt;text-align: left;">Date:'.$job_offer_data[0]->offer_crtd.'</p>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Reference Number:'. $job_offer_data[0]->job_id. '<span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';
$html.='Recipient Name:'. $job_offer_data[0]->jo_recipt_name. '<span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Nationality:'. $nationality_en. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';






$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Contact Number:'. $job_offer_data[0]->jo_phone. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';







$html.='<p style="padding-left: 2pt;text-indent: 0pt;text-align: left;">';

$html.='<a href="mailto:vparunima73@gmail.com" style=" color: black; font-family:"Times New Roman", serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 12pt;" target="_blank">Email: </a>';

$html.='<a href="mailto:vparunima73@gmail.com" class="s4" target="_blank">'.$job_offer_data[0]->jo_email.'</a>';

$html.='</p>';


$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 2pt;text-indent: 0pt;line-height: 14pt;text-align: left;">Dear '.$job_offer_data[0]->jo_recipt_name. ' </p>


<p class="s3" style="padding-left: 2pt;text-indent: 0pt;text-align: left;">



We are pleased to offer you a position in ';

$html.='<b>'.$Position_At_company. '</b>


under the following job details and benefits:

</p>';



$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>1.Position and Location :</b>';



$html.='<p class="s2" style="padding-top: 2pt;padding-left: 23pt;text-indent: 0pt;text-align: left;">'.$job_offer_data[0]->position_name.'</p>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Job Location:'. $working_place_branch. '  / Location might be changed based on work needs. <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';







$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>2.Working days and Timing :</b>';




$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Working Time:'.$job_offer_data[0]->jo_from_hour . 'To'  .$job_offer_data[0]->jo_to_hour.'<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>';

$html.='Break Time:'.$job_offer_data[0]->jo_from_brk . 'To'  .$job_offer_data[0]->jo_to_brk.'<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Workdays:'.$job_offer_data[0]->day_start. 'To'  .$job_offer_data[0]->day_end.'<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='working time might differs based on working needs.<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';










$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>3.Salary :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Total Salary:'.$job_offer_data[0]->jo_total_salary.' '.$currency_type. '  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';
if($job_offer_data[0]->increment_amount=='0'||$job_offer_data[0]->increment_amount=='0.0'||$job_offer_data[0]->increment_amount=='')
{
	$html.='a possibility of increment :as company policy <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}
else {
	$html.='a possibility of   '  .$job_offer_data[0]->increment_amount.  '    increment after  '  .$job_offer_data[0]->increment_sts.  '   month  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


}





if ($job_offer_data[0]->position_name=='Sales Executive')

{

$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='With commotion as per company policy <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



}





$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Basic Salary _ '.$salary_precentage[0].  '' .$currency_type. ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';
if($salary_precentage[7]=='0')
{
// 	$html.='<span class="s2"></span>';
// $html.='<p style="text-indent: 0pt;text-align: left;">
// <br>
// </p>';

}
else{
$html.='Fixed Overtime _ '.$salary_precentage[7].  '' .$currency_type. ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
}





$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Housing Allowance  _  '  .$salary_precentage[1].  ' '.$currency_type. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Transportation Allowance  _  '  .$salary_precentage[2].  '  '.$currency_type. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Food :   ' .$salary_precentage[4].'' .$currency_type. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

if($salary_precentage[5]=='0')
{
// $html.='Car : - <span class="s2"></span>';
// $html.='<p style="text-indent: 0pt;text-align: left;">
// <br>
// </p>';
}
else{
$html.='Car :   ' .$salary_precentage[5].'' .$currency_type. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
}


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';
if($salary_precentage[6]=='0')
{

}
else{
$html.='Other :  ' .$salary_precentage[6].'' .$currency_type. ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
}



$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';
if($salary_precentage[3]=='0')
{

}
else{
$html.='Others (mobile) :   ' .$salary_precentage[3].'' .$currency_type. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
}

$html.='</td>';




//now arabic

if($master_company=="Dubai - BERRY")
  {

     $company_ar='بيري لتجارة مواد البناء  ';

  }

  else if($master_company=="KSA")
  {
  	 $company_ar='بيري للتجارة   ';
  }
   else if($master_company=="FACTORY")
  {
  	 $company_ar='  بيري للصناعات    ';
  }



$html.='<td style="width:250pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl;">
<p class="s5" style="padding-right: 119pt;text-indent: 0pt;line-height: 14pt;text-align: right;"></p>
<br><br><br>
<p class="s5" style="padding-right: 119pt;text-indent: 0pt;line-height: 14pt;text-align: right;"><b>عرض العمل <b></p>

<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-right: 2pt;text-indent: 0pt;text-align: right;"> التاريخ    '.$job_offer_data[0]->offer_crtd.'</p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';







$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;"> الرقم المرجعي   : '.$job_offer_data[0]->job_id.'</p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';





$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;">  اسم المستلم  : ' .$job_offer_data[0]->jo_recipt_name_ar.' </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;">  الجنسية   :  '.$nationality_ar.' </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;"> رقم الهاتف   :  '.$job_offer_data[0]->jo_phone. ' </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;"> البريد الالكتروني   :  '.$job_offer_data[0]->jo_email. '   </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;">  السيد/ة  :  '.$job_offer_data[0]->jo_recipt_name_ar. '  </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">


<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;">يسعدنا ان نقدم لك عرض العمل في شركة  : <b>'.$company_ar. '<b>بموجب التفاصيل والمزايا التالية  : </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>  1. المنصب المقترح ومكان العمل  </b>';



$html.='<p class="s2" style="padding-top: 2pt;padding-left: 23pt;text-indent: 0pt;text-align: left;">'.$position_name_ar.'</p>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='مكان العمل  :'. $working_place_branch_ar. '   <span class="s2"></span>';
// $html.='<p style="text-indent: 0pt;text-align: left;">
// <br>
// </p>';
$html.='  قابل للتغيير حسب حاجة العمل  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>  2. ايام العمل والتوقيت  </b>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



switch ($job_offer_data[0]->jo_from_hour) {
	  case '7 am':
      $jo_from_hour_ar="7:00 صباحاً  ";
        break;
    case '8 am':
        $jo_from_hour_ar= "8:00 صباحاً  ";
        break;
		 case '9 am':
       $jo_from_hour_ar= "9:00 صباحاً  ";
        break;
		 case '10 am':
		$jo_from_hour_ar= "10:00 صباحاً  ";
        break;
			 case '7:30 am':
		$jo_from_hour_ar= "7:30 صباحاً  ";
        break;
			 case '8:30 am':
		$jo_from_hour_ar= "8:30 صباحاً  ";
        break;
    default:
        $jo_from_hour_ar= "8:00 صباحاً";
        break;
}
switch ($job_offer_data[0]->jo_to_hour) {
	  case '5 pm':
      $jo_to_hour_ar="5:00 مساءً  ";
        break;
    case '6 pm':
        $jo_to_hour_ar= "6:00 مساءً  ";
        break;
		 case '7 pm':
       $jo_to_hour_ar= "7:00 مساءً  ";
        break;
		 case '8 pm':
		$jo_to_hour_ar= "8:00 مساءً  ";
        break;
			 case '8:30 pm':
		$jo_to_hour_ar= "8:30 مساءً  ";
        break;
		 case '9 pm':
		$jo_to_hour_ar= "9:00 مساءً  ";
        break;
    default:
        $jo_to_hour_ar= "7:00 مساءً";
        break;
}




switch ($job_offer_data[0]->jo_from_brk) {
	  case '1 pm':
      $jo_from_brk_ar="1:00 مساءً  ";
        break;
    case '2 pm':
        $jo_from_brk_ar= "2:00 مساءً  ";
        break;
		 case '3 pm':
       $jo_from_brk_ar= "3:00 مساءً  ";
        break;
		 case '4 pm':
		$jo_from_brk_ar= "4:00 مساءً  ";
        break;
    default:
        $jo_from_brk_ar= "5:00 مساءً  ";
        break;
}
switch ($job_offer_data[0]->jo_to_brk) {
	  case '2 pm':
      $jo_to_brk_ar="2:00 مساءً  ";
        break;
    case '3 pm':
        $jo_to_brk_ar= "3:00 مساءً  ";
        break;
		 case '4 pm':
       $jo_to_brk_ar= "4:00 مساءً  ";
        break;
		 case '5 pm':
		$jo_to_brk_ar= "5:00 مساءً  ";
        break;
    default:
        $jo_to_brk_ar= "6:00 مساءً  ";
        break;
}


//$jo_from_hour_ar= echo $hoursjob;





$html.='اوقات العمل  من  :'.  $jo_from_hour_ar . 'الى   ' .$jo_to_hour_ar. '   <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>';
$html.='اوقات  الاستراحة  :'.  $jo_from_brk_ar . 'الى   ' .$jo_to_brk_ar. '   <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




switch ($job_offer_data[0]->day_start) {
	  case 'Monday':
      $starting_day="الاثنين";
        break;
    case 'Tuseday':
        $starting_day= "الثلاثاء";
        break;
		 case 'Saturday':
       $starting_day= "السبت";
        break;
		 case 'Sunday':
		$starting_day= "الاحد";
        break;
			 case 'Thursday':
      $ending_day="الخميس";
        break;
		 case 'Friday':
      $ending_day="الجمعة";
        break;
    default:
        $starting_day= "الاثنين";
        break;
}

switch ($job_offer_data[0]->day_end) {
	  case 'Monday':
      $ending_day="الاثنين";
        break;
    case 'Tuseday':
        $ending_day= "الثلاثاء";
        break;
		 case 'Saturday':
       $ending_day= "السبت";
        break;
		 case 'Sunday':
		$ending_day= "الاحد";
        break;
		 case 'Thursday':
      $ending_day="الخميس";
        break;
		 case 'Friday':
      $ending_day="الجمعة";
        break;
    default:
        $ending_day= "الاحد";
        break;
}







$html.='ايام العمل   من  :'. $starting_day. '   الى   ' .$ending_day. '   <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='ايام العمل قابلة للتغيير حسب الحاجة  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>  3. الراتب    </b>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='الراتب  :'. $job_offer_data[0]->jo_total_salary.' '.$currency_type_ar. '   <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


if ($job_offer_data[0]->increment_amount=='0'||$job_offer_data[0]->increment_amount=='0.0'||$job_offer_data[0]->increment_amount=='')
{
	$html.=' امكانية الزيادة : حسب سياسة الشركة  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}
else
{
	$html.='امكانية الزيادة   :'.$job_offer_data[0]->increment_amount.' بعد  ' .$job_offer_data[0]->increment_sts.  ' شهر    <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}









if ($job_offer_data[0]->position_name=='Sales Executive')

{



$html.='مع عمولة  محددة بحسب سياسة الشركة  ';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}







$html.=' <b> الراتب الاساسي   : </b>'.$salary_precentage[0].' ' .$currency_type_ar.' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
if($salary_precentage[7]=='0')
{
// $html.='<b> اضافي ساعات العمل : </b> -  <span class="s2"></span>';
// $html.='<p style="text-indent: 0pt;text-align: left;">
// <br>
// </p>';
}

else{
	$html.=' <b> اضافي ساعات العمل : </b> '.$salary_precentage[7].'' .$currency_type_ar.' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}




$html.=' <b> بدل السكن   : </b> '  .$salary_precentage[1].'  ' .$currency_type_ar.  ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';






$html.=' <b> بدل المواصلات   : </b> '  .$salary_precentage[2].' ' .$currency_type_ar. ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.=' <b> بدل طعام  : </b>  ' .$salary_precentage[4].' ' .$currency_type_ar.' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


if($salary_precentage[5]=='0')
{
// 	$html.=' <b> بدل محروقات    : </b> - <span class="s2"></span>';
// $html.='<p style="text-indent: 0pt;text-align: left;">
// <br>
// </p>';

}
else{
$html.=' <b> بدل محروقات    : </b> '  .$salary_precentage[5].' ' .$currency_type_ar. ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
}


if($salary_precentage[6]=='0')
{

}
else{
	$html.=' <b> بدلات اخرى  : </b>  '.$salary_precentage[6].' ' .$currency_type_ar.' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}



if($salary_precentage[3]=='0')
{

}
else {
	$html.=' <b> بدل اتصالات (موبايل ) </b>  '.$salary_precentage[3]. ' ' .$currency_type_ar.'  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}






$html.='</tr>';

$html.='</div></div>';
$html.='</tbody>';

$html.='</table>';











$html.='

<p style="text-indent: 0pt;text-align: left;">

<br>
</p>
';


//////page 2 ////////////////////////////////////////////////////////////////////////////////////
$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">
<tbody>

<tr style="height:534pt">';
//for eng
$html.='<td style="width:258pt;border-right-style:solid;border-right-width:1pt ">
</br>';
$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;"></p>
<br>        <br> <br>';


$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>4.Contract Type  :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Employment contract: Limited (<b>'. $job_offer_data[0]->jo_contract_yr_num.'Year</b> )
The contract starts after the status modification
Probation Period: <b>' . $job_offer_data[0]->probation_period. ' Month </b>
Employee required notifying the company if he would like to renew his contract 3 month before the end of contract.
Employee has all the responsibility to provide all the document and certificate needed for his contract and accepting any fine in case of delay or reject by the government. <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';





 if($job_offer_data[0]->termination_employee==0)
 {
 	$terminationemployee_sts='Not possible';

      $terminationemployee_sts_ar='غير متاح ';

 }
 else {

 	  $terminationemployee_sts=$job_offer_data[0]->termination_employee;

      $terminationemployee_sts_ar=$job_offer_data[0]->termination_employee;
 }





 if($job_offer_data[0]->termination_employer==0)
 {
 	$terminationemployer_sts='Not possible';

      $terminationemployer_sts_ar='غير متاح ';

 }
 else {

 	  $terminationemployer_sts=$job_offer_data[0]->termination_employer.'month';

      $terminationemployer_sts_ar=$job_offer_data[0]->termination_employer.'شهر';
 }



$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>5.Termination and Resining :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Termination of contract from employee side:
'. $terminationemployee_sts.'
Termination of contract from employer:
'.$terminationemployer_sts.'
In case of resignation from employee during the contract, Employee must pay for the company amount of 225 AED for each month till the end of contract plus the base salary for 3 months. The employee will lose his right in receiving the end-of-service salary and any additional amounts. <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>6.Holiday and Annual Leave :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='30 calendar days annual leave after completing of 12 months working inside the company.
Annual leave must apply at least 3 months in advance and the date of leave to be discussed by your manager.
Leave salary (Basic salary) Leave salary will be released after return from the annual leave.
Ticket to country: upon completion of 24 month of service the company shall reimburse economic one-way ticket to your home county at the end of contract, in case of renew the contract company will provide 2-way ticket after renewing the contract, maximum covered ticket (800) AED<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
$html.=' <b> Medical Insurance: provided, </b> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='</td>';



//for arabic
$html.='<td style="width:258pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl;">';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: -18pt;text-align: left;">
<b>  4.نوع العقد  </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='عقد توظيف محدد المدة <b>( '. $job_offer_data[0]->jo_contract_yr_num.' سنوات )</b>
يبدأالعقد إعتبارا من تاريخ تعديل الوضع
المدة التجريبية: <b>'. $job_offer_data[0]->probation_period.'  شهر   </b>يجب على الموظف إخطار الشركة إذا كان يرغب في تجديد عقده
قبل 3 أشهر من انتهاء العقد.
ويتحمل الموظف مسؤولية إحضار كافة الاوراق والمستندات
الرسمية الخاصة ب إصدار تصريح العمل الخاص به وفي حال
رفضها أو حصول أي تأخير لا تتحمل الشركة أي رسوم أو
غرامات ناتجة عن ذلك    <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>  5. إنهاء العقد أو الاستقالة  </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='إنهاء العقد من قبل الموظف:
'.$terminationemployee_sts_ar.'
أنهاء العقد من قبل الشركة:
فترة الاشعار  '. $terminationemployer_sts_ar.  '
في حالة الاستقالة من العمل خلال مدة العقد يجب على الموظف
دفع مبلغ 225 درهم عن كل شهر عمل حتى انتهاء مدة العقد
بالإضافة الى خصم راتب ثلاثة أشهر. الموظف المستقيل سوف
يفقد حقه باستلام راتب نهاية الخدمة أو ايه مستحقات إضافية. 
فترة الانذار في حال الاستقالة 3 أشهر
<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> 6.العطلات والاجازات السنوية: </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='تمنح الشركة إجازة سنوية مدتها 30 يوماً بعد إتمام 12 شهراً من
العمل داخل الشركة .
يجب أن يتم التقدم للحصول على الإجازة السنوية قبل 3 أشهر على
الأقل من موعد الإجازة على ان يتم مناقشة موعد الاجازة من قبل
مديرك.
راتب الإجازة هو )الراتب الأساسي( ويُصرف راتب الإجازة بعد
العودة من الإجازة السنوية.
تذكرة السفر : عند الانتهاء من الخدمة لمدة 24 شهرًاتقدم الشركة
قيمة التذكرة على الدرجة السياحية في اتجاه واحد إلى بلدك
الأصلي في نهاية العقدفي حال الرغبة بالسفر ، الحد الأقصى
للتذكرة المغطاة ) 800 ( درهم ، وفي حالة تجديد العقد، ستقدم
الشركة تذكرة ثنائية الاتجاه بعد تجديد العقد. <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';






$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='<b>  التأمين الصحي مقدم من قبل الشركة      </b><span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='</td>
</tr>
</tbody>
</table>';




//page 3 //////////////////////////////////////////////////////////////////////////////////////////////

$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">
<tbody>

<tr style="height:534pt">';
//for eng
$html.='<td style="width:258pt;border-right-style:solid;border-right-width:1pt">';


$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> Sick leave policy: :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='During probation period you are no eligible for sick leave,
Sick leave accepted only with official sick leave certificate mention the number of days employee need to rest,
The sick leave calculation as following:
<br>

- Full paid for a period of first 15 days,
<br>
-Half paid for the second 15 days,
<br>
-Unpaid for the third 15 days.<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> Emergency leave:</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='In case of the death of a first-degree relative after approval of the administration,
Employee can get 7 days unpaid leave or any other costs. This leave does not apply to the first six months of employment.
Note: Sick leave and emergency leave as per company policy and might be changed. <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> 7.Location & Timing :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Strictly follow the work timing.
<br><br>
- Working hours should be always attended in the office, not able to work from home.
<br><br>
- When 3 days late (10 min or later punch in) 1 day will be deducted, when absent 1 day without approval 2 days will be deduct.
<br><br>
- Employer have right to change your working hours and location as per business requirements,
<br><br>
- Please note that working hours are scheduled by the company based on business level and maybe extended during holiday or after work timing any additional hours will be calculated as an overtime.<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='</td>';

///////////arabic //////////////////////////////
$html.='<td style="width:254pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl;">';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> سياسة الإجازة المرضية   </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='خلال فترة الاختبار، لا يحق لك الحصول على إجازة مرضية
تُقبل الإجازة المرضية فقط مع شهادة إجازة مرضية رسمية تذكر
عدد الأيام التي يحتاجها الموظف للراحة،
يتم حساب الإجازة المرضية على النحو التالي:
<br><br>
- إجازة مدفوعة بالكامل خلال فترة ال 15 يوم الأولى
<br><br>
- إجازة نصف مدفوعة خلال فترة ال 15 يوم الثانية
<br><br>
-- إجازة غير مدفوعة لفترة ال 15 يوم الثالثة   <br><br> <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>الإجازات الطارئة: </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='في حالة وفاة قريب من الدرجة الأولى، وبعد موافقة الإدارة يمكن
للموظف الحصول على إجازة غير مدفوعة الأجر لمدة 7 أيام ولا
تغطى أي تكاليف أخرى.
لا تنطبق هذه الإجازة على الأشهر الستة الأولى من العمل
ملحوظة: سياسة الإجازة المرضية والإجازة الطارئة قد تتغير
حسب سياسة الشركة. <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>7.الموقع والتوقيت   </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='التزم بدقة بتوقيت العمل
<br><br>
-يجب حضور ساعات العمل دائمًا في المكتب، إمكانية
العمل من المنزل غير قابلة للتطبيق
<br><br>
-عندما تتأخر ل 3 أيام متتالية )مدة 10 دقائق أو أكثر(
سيتم خصم يوم عمل واحد، وفي حالة الغياب لمدة يوم
واحد بدون موافقة الإدارة سيتم خصم يومين عمل
بالمقابل. .
<br><br>
- يحق لصاحب العمل تغيير ساعات العمل والموقع وفقًا
لمتطلبات العمل.
<br><br>
-يرجى ملاحظة أن ساعات العمل يتم تحديدها من قبل
الشركة بناءً على مستوى العمل وربما يتم تمديدها أثناء
العطلة أو بعد ساعات العمل الرسمية، وسيتم احتساب
أجر أي تعديل على ساعات العمل على أنها ساعات
عمل إضافية. <br><span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
$html.='</td>
</tr>
</tbody>
</table>';
///////end of page 3 



////////page  4 ////////


$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">

<tbody>

<tr style="height:534pt">';
//for eng
$html.='<td style="width:344pt;border-right-style:solid;border-right-width:1pt">';


$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> 8.Job Description :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' '.$job_description.'<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> 9.Duties and Responsibilities :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=''.$responsibilities.'<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='</td>';

///////////arabic //////////////////////////////
$html.='<td style="width:344pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl; font-size:16px;">';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> 8.توصيف العمل  </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=''.$job_description_ar.'<span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>9.المهمات والمسؤوليات   </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' '.$responsibilities_ar   .' <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='</td>
</tr>
</tbody>
</table>';

/////end 4 table page




/////page 5 






$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">
<tbody>

<tr style="height:534pt">';
//for eng
$html.='<td style="width:258pt;border-right-style:solid;border-right-width:1pt">';

$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;"></p>
<br>        <br> <br>';

$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> 10. Requirements :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' '.$requirements.'<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
<br>
<br>
<br>
</p>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> Language skills : </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=''.$job_offer_data[0]->languages.'<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
<br>
</p>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> Knowledge, Skills and Abilities Required: </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=''.$knowledge_skills_ability.'<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
</br>
<br>
<br>

</p>';


$html.='</td>';

///////////arabic //////////////////////////////
$html.='<td style="width:254pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl;">';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>10.متطلبات المنصب   </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=''.$requirements_ar.'<span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
<br>
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> مهارات اللغة   </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' '.$language_skill_ar.' <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
</p>';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>المعرفة والمهارات المطلوبة  </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' '.$knowledge_skills_ability_ar.' <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
</p>';




$html.='</td>
</tr>
</tbody>
</table>';

/////end page 5 



////page 6  














$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">
<tbody>
<tr style="height:534pt">';
//for eng
$html.='<td style="width:258pt;border-right-style:solid;border-right-width:1pt">';





$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;"></p>
<br>        <br> <br> <br> <br>';


$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> 11. Additional Skills required :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' Training on the use of accounting software and the companys supplementary software  Knowledge of all available products and prices for the main items<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>12. Additional requirements for this position </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='_Employee must acknowledge that all company information and business contacts that have been developed during the period employment here, belongs exclusively to Biri Group and Berry Building Materials Trading.<br>
_The company code of conduct and non-compete agreement must be signed before work begins  Don’t use own devices during work timing (exception lunch break).<br> _ Use only company phone.<br> _ Provide customers only with company’s contact information.<br> _Don’t use own phone, e- mail and messengers for contacting customers<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</p>
<br>
<br>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>Bachir BERRY CEO </b>
<br>
<br>';
$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>Bianora BIRI       Administrative director   </b>
<br>
<br>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';


$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' I accept the offer as outlined above <br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' Name & signature :  <br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' Date:  <br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='</td>';

///////////arabic //////////////////////////////
$html.='<td style="width:254pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl;">';

$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> </b> </p> <br><br><br><br><br><br><br>';
$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> 11 . المهارات الإضافية المطلوبة : </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='-
التدريب على استخدام برنامج المحاسبة وبرامج الشركة  الملحقة  .
<br>


- المعرفة لكافة المنتجات المتوفرة والاسعار للأصناف    الرئيسة  .
<br>

 <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> 12 . متطلبات إضافية لهذا المنصب: </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' -يجب أن يقر الموظف بأن جميع معلومات الشركة وجهات
الاتصال التجارية التي طورها أثناء عمله هنا تنتمي حصريًا إلى
مجموعة بيري وشركة بيري لتجارة مواد البناء.
 يجب توقيع اتفاقية عدم إفشاء وعدم التنافس قبل بدء العمل  . 
 <br>
- عدم استخدام الأجهزة الخاصة أثناء توقيت العمل
(باستثناء استراحة الغداء). <br> و التاكيد على استخدم اجهزة
الشركة فقط.  .<br>
- تزويد العملاء بمعلومات الاتصال الخاصة بالشركة
فقط. . <br>و التأكيد على عدم استخدام الهاتف والبريد
الإلكتروني الشخصييم لمراسلة وللاتصال بالعملاء  .<br><span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">

<br>
<br>
<br>
<br>
<br>
<br>
<br>
</p>';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>  </b></p> <br><br><br> <br><br><br> <br><br><br>';

$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>الرئيس التنفيذي: بشير بيري  </b></p> <br>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' المدير الاداري : بيانورا بيري <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p> <br> <br>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='  أقبل العرض كما هو موضح أعلاه  <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>

</p>';
$html.=' الاسم والتوقيع:  <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>

</p>';
$html.='  التاريخ :  <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>

</p>';




$html.='</td>
</tr>
</tbody>
</table>';

/////////end page 6










$html.='</body>';
$html.='</html>';

//echo $html;
$pdfFilePath = $job_offer_data[0]->job_id.'.pdf';

	 $mpdf = new \Mpdf\Mpdf();
	 $mpdf->autoScriptToLang = true;
	$mpdf->autoLangToFont = true;
    $mpdf->autoArabic=true;
    // $mpdf->SetDirectionality('rtl');
	$mpdf->defaultfooterline = 0;

 	//$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$siv_data[0]->si_company));



 if($master_company=="Dubai - BERRY")
  {
//   	$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');

      $mpdf->SetHeader('<img src="' . base_url("berry_header.png") . '">');
	$mpdf->SetFooter('<img src="' . base_url("berry_footer.png") . '">');
  }
      elseif($master_company=="KSA")
     {
    	
//        $mpdf->SetHeader('<img src="'.base_url("ksa-header-new.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("ksa-footer-new.png").'">');

     	$mpdf->SetHeader('<img src="' .  base_url("ksa-header-new.png") . '">');
	$mpdf->SetFooter('<div >Page {PAGENO} of {nb}</div><img src="' . base_url("ksa-footer-new.png") . '">');
  }
 	elseif($master_company=="FACTORY")
{
		 
//  	$mpdf->SetHeader('<img src="'.base_url("biri_industries_header.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("biri_industries_footer.png").'">');

	$mpdf->SetHeader('<img src="' . base_url("biri_industries_header.png") . '">');
	$mpdf->SetFooter('<img src="' . base_url("biri_industries_footer.png") . '">');
		   }



// else
// {
// 	$mpdf->SetHeader($head_all);
// 	$mpdf->SetFooter('<div style="margin-bottom:100px;">Page {PAGENO} of {nb}</div>');
// }
//echo $html;
//print_r($fnet_details);
		 $mpdf->WriteHTML($stylesheet,1);
		
					$mpdf->AddPage(
						'', // L - landscape, P - portrait 
						'',
						'',
						'',
						'',
						4, // margin_left
						4, // margin right
						40, // margin top
						30, // margin bottom
						0, // margin header
						0
					); // margin footer
				
				// else{
				// 	$mpdf->AddPage(
				// 		'', // L - landscape, P - portrait 
				// 		'',
				// 		'',
				// 		'',
				// 		'',
				// 		5, // margin_left
				// 		5, // margin right
				// 		97, // margin top
				// 		20, // margin bottom
				// 		60, // margin header
				// 		30
				// 	); // margin footer
				// }
   
	     $mpdf->WriteHTML($html,2);	     
	     //save in folder
		$mpdf->Output("./uploads/inv_pdf/".$pdfFilePath, "F");
  		$mpdf->Output($pdfFilePath,'D');
				
 		}
	}
}




















function job_offer_final($job_id)
{
	require 'vendor/autoload.php';
		require_once 'vendor/khaled.alshamaa/ar-php/src/Arabic.php';
	if(logged_in())
	{




$sqloffer=$this->db->query("SELECT jof.*,mc.mcomp_name,pot.position_name,nat.name FROM job_offer as jof join master_company as mc on mc.mcomp_id=jof.jo_master_comp join positions as pot on pot.pos_id=jof.jo_position_id join country_val as nat on nat.country_id=jof.jo_recipt_nationality  WHERE job_id='".$job_id."'  order by jof.job_id  DESC");


$job_offer_data=$sqloffer->result();


		//$sale_id=$this->input->post('sales_inv_id');
		//$invoice_pdf_type=$this->input->post('pdf-print-option');

		///for english - arabic number in words//////
 		$Arabic = new \ArPHP\I18N\Arabic();
 		 $Arabic->setNumberFeminine(1);
    	$Arabic->setNumberFormat(1);
    	///////end en-ar words/////////
  

		if(!empty($job_id))
		{
$master_company=$job_offer_data[0]->mcomp_name;




////for chosing the headaer depending on 
if($master_company=="Dubai - BERRY")
  {
  	$Position_At_company='Berry Building Materials';
  	$Position_At_company_ar='بيري لتجارة مواد البناء';
  }
elseif($master_company=="KSA")
    {
    	$Position_At_company='Biri Trading Est.';
    	$Position_At_company_ar='مؤسسة بيري التجارية';
    }
	elseif($master_company=="FACTORY")
 {
		   $Position_At_company='Biri Industries';
		    $Position_At_company_ar='بيري للصناعات';;
		   }
      else{}

$salary_details=explode(',',$job_offer_data[0]->salary_details);
$salary_precentage=explode(',',$job_offer_data[0]->salary_precentage);

//print_r($salary_precentage);
//exit(0);

$other_val=intval($salary_precentage[4])+(intval($salary_precentage[5]))+(intval($salary_precentage[6]));
//print_r($other_val);
//exit(0);


$position_name=$job_offer_data[0]->position_name;

$company_branch=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$job_offer_data[0]->jo_branch));

$working_place_branch=$company_branch[0]->mcomp_name;

 switch ($working_place_branch) {
        case 'UAE - Garhoud':
            
            $working_place_branch_ar =' دبي القرهود  ';
            break;

       case 'UAE-BANIYAS BRANCH':
            
            $working_place_branch_ar =' دبي  بانياس  ';
            break;
			case 'UAE - Diera':
            
            $working_place_branch_ar =' دبي  الديرة  ';
            break;
			case 'UAE - Dragon':
            
            $working_place_branch_ar =' دبي السوق الصيني دراجون  ';
            break;
			case 'KSA - Riyadh':
            
            $working_place_branch_ar =' السعودية -الرياض ';
            break;

			case 'FACTORY':
            
            $working_place_branch_ar =' السعودية جدة  ';
            break;

					case 'Dubai Store':
            $working_place_branch_ar ='مكتب رأس الخور';
			$working_place_branch='Ras Al-Khour Office';
            break;
			
            default:
            $working_place_branch_ar =' دبي القرهود  ';
            break;
    }



$stylesheet = file_get_contents('style_mpdf.css');

if($master_company=="KSA")
     {
    	

     $currency_type='SR';
     $currency_type_ar='ريال ';



}
else
{
   $currency_type='AED';
   $currency_type_ar='درهم  ';


}

$position_details=$this->Admin_model->get_data('positions',array('pos_id'=>$job_offer_data[0]->jo_position_id));

$job_description=$position_details[0]->job_description;
$job_description_ar=$position_details[0]->job_description_ar;


$responsibilities=$position_details[0]->position_responsibilities;
$responsibilities_ar=$position_details[0]->position_responsibilities_ar;


$requirements=$position_details[0]->position_requirement;
$requirements_ar=$position_details[0]->position_requirement_ar;


$position_brief=$position_details[0]->position_brief;
$position_brief_ar=$position_details[0]->position_brief_ar;


$position_name_ar=$position_details[0]->position_name_ar;

$knowledge_skills_ability=$position_details[0]->knowledge_skills_ability;
$knowledge_skills_ability_ar=$position_details[0]->knowledge_skills_ability_ar;



if($job_offer_data[0]->name=="Afghanistan")
   {  $nationality_en="Afghan";
	$nationality_ar="الافغانية";

	} 

else if($job_offer_data[0]->name=="India")
 {  $nationality_en="indian";
	$nationality_ar="الهندية";

	} 

else if($job_offer_data[0]->name=="Pakistan")
 {  $nationality_en="Pakistani";
	$nationality_ar="باكستاني  ";

	}

	else if($job_offer_data[0]->name=="Syria")
 {  $nationality_en="syrian";
	$nationality_ar=" سوري   ";

	}

	else if($job_offer_data[0]->name=="Philippines")
 {  $nationality_en="Philippine, Filipino";
	$nationality_ar="فلبين  ";

	}
			else if($job_offer_data[0]->name=="Jordan")
 {  $nationality_en="Jordanian";
	$nationality_ar="اردني";

	}

else {}



if ($job_offer_data[0]->languages=="english")
  $language_skill_ar=" الانجليزية  ";
else if($job_offer_data[0]->languages=="arabic")
  $language_skill_ar=" العربية   ";

else if($job_offer_data[0]->languages=="english,arabic")
 $language_skill_ar=" العربية والانجليزية بطلاقة    ";



/*
////////////////for qr code////////////////////////////
$this->load->library('ciqrcode');
//header("Content-Type: image/png");
$params['data'] = base_url('load_invoice_data/'.$siv_data[0]->si_doc_no);
$params['level'] = 'H';
$params['size'] = 10;
$params['savename'] = './uploads/qr_code/'.$siv_data[0]->si_doc_no.'.png';
 $this->ciqrcode->generate($params);
//echo '<img src="'.base_url().'/uploads/inv_pdf/tes.png" />';
///////////qr code ends//////////////////////////////////////////
*/

$html='<!doctype html>';


$html.='<head></head><body>';
/*if ($invoice_pdf_type == '1') {
					$html .= '<div style="position: absolute; visibility: visible; left: 680px; top: 120px; z-index: 200;"><img align="bottom"  src="' . base_url() . '/uploads/qr_code/' . $siv_data[0]->si_doc_no . '.png" width="100" height="100"/></div>';
				}
				else{
					$html .= '<div style="position: absolute; visibility: visible; left: 680px; top: 230px; z-index: 200;"><img align="bottom"  src="' . base_url() . '/uploads/qr_code/' . $siv_data[0]->si_doc_no . '.png" width="100" height="100"/></div>';

				}*/

$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">';
$html.='<tbody>';

$html.='<tr style="height:562pt">';
$html.='<td style="width:258pt;border-right-style:solid;border-right-width:1pt">';

$html.='<p class="s1" style="padding-left: 35pt;text-indent: 0pt;line-height: 14pt;text-align: left;">EMPLOYMENT OFFER LETTER</p>';

$html.='<p style="text-indent: 0pt;text-align: left;">';
$html.='<br> </p>';




$html.='<p class="s1" style="padding-left: 2pt;text-indent: 0pt;text-align: left;">Date:'.$job_offer_data[0]->offer_crtd.'</p>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Reference Number:'. $job_offer_data[0]->job_id. '<span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';
$html.='Recipient Name:'. $job_offer_data[0]->jo_recipt_name. '<span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Nationality:'. $nationality_en. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';






$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Contact Number:'. $job_offer_data[0]->jo_phone. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';







$html.='<p style="padding-left: 2pt;text-indent: 0pt;text-align: left;">';

$html.='<a href="mailto:vparunima73@gmail.com" style=" color: black; font-family:"Times New Roman", serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 12pt;" target="_blank">Email: </a>';

$html.='<a href="mailto:vparunima73@gmail.com" class="s4" target="_blank">'.$job_offer_data[0]->jo_email.'</a>';

$html.='</p>';


$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 2pt;text-indent: 0pt;line-height: 14pt;text-align: left;">Dear '.$job_offer_data[0]->jo_recipt_name. ' </p>


<p class="s3" style="padding-left: 2pt;text-indent: 0pt;text-align: left;">



We are pleased to offer you a position in ';

$html.='<b>'.$Position_At_company. '</b>


under the following job details and benefits:

</p>';



$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>1.Position and Location :</b>';



$html.='<p class="s2" style="padding-top: 2pt;padding-left: 23pt;text-indent: 0pt;text-align: left;">'.$job_offer_data[0]->position_name.'</p>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Job Location:'. $working_place_branch. '  / Location might be changed based on work needs. <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';







$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>2.Working days and Timing :</b>';




$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Working Time:'.$job_offer_data[0]->jo_from_hour . 'To'  .$job_offer_data[0]->jo_to_hour.'<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>';

$html.='Break Time:'.$job_offer_data[0]->jo_from_brk . 'To'  .$job_offer_data[0]->jo_to_brk.'<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Workdays:'.$job_offer_data[0]->day_start. 'To'  .$job_offer_data[0]->day_end.'<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='working time might differs based on working needs.<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';










$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>3.Salary :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Total Salary:'.$job_offer_data[0]->jo_total_salary.' '.$currency_type. '  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';
if($job_offer_data[0]->increment_amount=='0'||$job_offer_data[0]->increment_amount=='0.0'||$job_offer_data[0]->increment_amount=='')
{
	$html.='a possibility of increment :as company policy <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}
else {
	$html.='a possibility of   '  .$job_offer_data[0]->increment_amount.  '    increment after  '  .$job_offer_data[0]->increment_sts.  '   month  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


}





if ($job_offer_data[0]->position_name=='Sales')

{

$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='With commotion as per company policy <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



}





$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Basic Salary _ '.$salary_precentage[0].  '' .$currency_type. ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';
if($salary_precentage[7]=='0')
{
// 	$html.='<span class="s2"></span>';
// $html.='<p style="text-indent: 0pt;text-align: left;">
// <br>
// </p>';

}
else{
$html.='Fixed Overtime _ '.$salary_precentage[7].  '' .$currency_type. ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
}





$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Housing Allowance  _  '  .$salary_precentage[1].  ' '.$currency_type. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Transportation Allowance  _  '  .$salary_precentage[2].  '  '.$currency_type. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Food :   ' .$salary_precentage[4].'' .$currency_type. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

if($salary_precentage[5]=='0')
{
// $html.='Car : - <span class="s2"></span>';
// $html.='<p style="text-indent: 0pt;text-align: left;">
// <br>
// </p>';
}
else{
$html.='Car :   ' .$salary_precentage[5].'' .$currency_type. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
}


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';
if($salary_precentage[6]=='0')
{

}
else{
$html.='Other :  ' .$salary_precentage[6].'' .$currency_type. ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
}



$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';
if($salary_precentage[3]=='0')
{

}
else{
$html.='Others (mobile) :   ' .$salary_precentage[3].'' .$currency_type. '<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
}

$html.='</td>';




//now arabic

if($master_company=="Dubai - BERRY")
  {

     $company_ar='بيري لتجارة مواد البناء  ';

  }

  else if($master_company=="KSA")
  {
  	 $company_ar='بيري للتجارة   ';
  }
   else if($master_company=="FACTORY")
  {
  	 $company_ar='  بيري للصناعات    ';
  }



$html.='<td style="width:250pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl;">
<p class="s5" style="padding-right: 119pt;text-indent: 0pt;line-height: 14pt;text-align: right;"></p>
<br><br><br>
<p class="s5" style="padding-right: 119pt;text-indent: 0pt;line-height: 14pt;text-align: right;"><b>عرض العمل <b></p>

<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-right: 2pt;text-indent: 0pt;text-align: right;"> التاريخ    '.$job_offer_data[0]->offer_crtd.'</p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';







$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;"> الرقم المرجعي   : '.$job_offer_data[0]->job_id.'</p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';





$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;">  اسم المستلم  : ' .$job_offer_data[0]->jo_recipt_name_ar.' </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;">  الجنسية   :  '.$nationality_ar.' </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;"> رقم الهاتف   :  '.$job_offer_data[0]->jo_phone. ' </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;"> البريد الالكتروني   :  '.$job_offer_data[0]->jo_email. '   </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;">  السيد/ة  :  '.$job_offer_data[0]->jo_recipt_name_ar. '  </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">


<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;padding-right: 2pt;text-indent: 15pt;line-height: 200%;text-align: left;">يسعدنا ان نقدم لك عرض العمل في شركة  : <b>'.$company_ar. '<b>بموجب التفاصيل والمزايا التالية  : </p>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>  1. المنصب المقترح ومكان العمل  </b>';



$html.='<p class="s2" style="padding-top: 2pt;padding-left: 23pt;text-indent: 0pt;text-align: left;">'.$position_name_ar.'</p>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='مكان العمل  :'. $working_place_branch_ar. '   <span class="s2"></span>';
// $html.='<p style="text-indent: 0pt;text-align: left;">
// <br>
// </p>';
$html.='  قابل للتغيير حسب حاجة العمل  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>  2. ايام العمل والتوقيت  </b>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



switch ($job_offer_data[0]->jo_from_hour) {
	  case '7 am':
      $jo_from_hour_ar="7:00 صباحاً  ";
        break;
    case '8 am':
        $jo_from_hour_ar= "8:00 صباحاً  ";
        break;
		 case '9 am':
       $jo_from_hour_ar= "9:00 صباحاً  ";
        break;
		 case '10 am':
		$jo_from_hour_ar= "10:00 صباحاً  ";
        break;
			 case '7:30 am':
		$jo_from_hour_ar= "7:30 صباحاً  ";
        break;
			 case '8:30 am':
		$jo_from_hour_ar= "8:30 صباحاً  ";
        break;
    default:
        $jo_from_hour_ar= "8:00 صباحاً";
        break;
}
switch ($job_offer_data[0]->jo_to_hour) {
	  case '5 pm':
      $jo_to_hour_ar="5:00 مساءً  ";
        break;
    case '6 pm':
        $jo_to_hour_ar= "6:00 مساءً  ";
        break;
		 case '7 pm':
       $jo_to_hour_ar= "7:00 مساءً  ";
        break;
		 case '8 pm':
		$jo_to_hour_ar= "8:00 مساءً  ";
        break;
			 case '8:30 pm':
		$jo_to_hour_ar= "8:30 مساءً  ";
        break;
		 case '9 pm':
		$jo_to_hour_ar= "9:00 مساءً  ";
        break;
    default:
        $jo_to_hour_ar= "7:00 مساءً";
        break;
}




switch ($job_offer_data[0]->jo_from_brk) {
	  case '1 pm':
      $jo_from_brk_ar="1:00 مساءً  ";
        break;
    case '2 pm':
        $jo_from_brk_ar= "2:00 مساءً  ";
        break;
		 case '3 pm':
       $jo_from_brk_ar= "3:00 مساءً  ";
        break;
		 case '4 pm':
		$jo_from_brk_ar= "4:00 مساءً  ";
        break;
    default:
        $jo_from_brk_ar= "5:00 مساءً  ";
        break;
}
switch ($job_offer_data[0]->jo_to_brk) {
	  case '2 pm':
      $jo_to_brk_ar="2:00 مساءً  ";
        break;
    case '3 pm':
        $jo_to_brk_ar= "3:00 مساءً  ";
        break;
		 case '4 pm':
       $jo_to_brk_ar= "4:00 مساءً  ";
        break;
		 case '5 pm':
		$jo_to_brk_ar= "5:00 مساءً  ";
        break;
    default:
        $jo_to_brk_ar= "6:00 مساءً  ";
        break;
}


//$jo_from_hour_ar= echo $hoursjob;





$html.='اوقات العمل  من  :'.  $jo_from_hour_ar . 'الى   ' .$jo_to_hour_ar. '   <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>';
$html.='اوقات  الاستراحة  :'.  $jo_from_brk_ar . 'الى   ' .$jo_to_brk_ar. '   <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




switch ($job_offer_data[0]->day_start) {
	  case 'Monday':
      $starting_day="الاثنين";
        break;
    case 'Tuseday':
        $starting_day= "الثلاثاء";
        break;
		 case 'Saturday':
       $starting_day= "السبت";
        break;
		 case 'Sunday':
		$starting_day= "الاحد";
        break;
			 case 'Thursday':
      $ending_day="الخميس";
        break;
		 case 'Friday':
      $ending_day="الجمعة";
        break;
    default:
        $starting_day= "الاثنين";
        break;
}

switch ($job_offer_data[0]->day_end) {
	  case 'Monday':
      $ending_day="الاثنين";
        break;
    case 'Tuseday':
        $ending_day= "الثلاثاء";
        break;
		 case 'Saturday':
       $ending_day= "السبت";
        break;
		 case 'Sunday':
		$ending_day= "الاحد";
        break;
		 case 'Thursday':
      $ending_day="الخميس";
        break;
		 case 'Friday':
      $ending_day="الجمعة";
        break;
    default:
        $ending_day= "الاحد";
        break;
}







$html.='ايام العمل   من  :'. $starting_day. '   الى   ' .$ending_day. '   <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='ايام العمل قابلة للتغيير حسب الحاجة  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>  3. الراتب    </b>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='الراتب  :'. $job_offer_data[0]->jo_total_salary.' '.$currency_type_ar. '   <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


if ($job_offer_data[0]->increment_amount=='0'||$job_offer_data[0]->increment_amount=='0.0'||$job_offer_data[0]->increment_amount=='')
{
	$html.=' امكانية الزيادة : حسب سياسة الشركة  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}
else
{
	$html.='امكانية الزيادة   :'.$job_offer_data[0]->increment_amount.' بعد  ' .$job_offer_data[0]->increment_sts.  ' شهر    <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}









if ($job_offer_data[0]->position_name=='Sales Executive')

{



$html.='مع عمولة  محددة بحسب سياسة الشركة  ';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



}



$html.=' <b> الراتب الاساسي   : </b>'.$salary_precentage[0].' ' .$currency_type_ar.' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
if($salary_precentage[7]=='0')
{
// $html.='<b> اضافي ساعات العمل : </b> -  <span class="s2"></span>';
// $html.='<p style="text-indent: 0pt;text-align: left;">
// <br>
// </p>';
}

else{
	$html.=' <b> اضافي ساعات العمل : </b> '.$salary_precentage[7].'' .$currency_type_ar.' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}




$html.=' <b> بدل السكن   : </b> '  .$salary_precentage[1].'  ' .$currency_type_ar.  ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';






$html.=' <b> بدل المواصلات   : </b> '  .$salary_precentage[2].' ' .$currency_type_ar. ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.=' <b> بدل طعام  : </b>  ' .$salary_precentage[4].' ' .$currency_type_ar.' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


if($salary_precentage[5]=='0')
{
// 	$html.=' <b> بدل محروقات    : </b> - <span class="s2"></span>';
// $html.='<p style="text-indent: 0pt;text-align: left;">
// <br>
// </p>';

}
else{
$html.=' <b> بدل محروقات    : </b> '  .$salary_precentage[5].' ' .$currency_type_ar. ' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
}


if($salary_precentage[6]=='0')
{

}
else{
	$html.=' <b> بدلات اخرى  : </b>  '.$salary_precentage[6].' ' .$currency_type_ar.' <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}



if($salary_precentage[3]=='0')
{

}
else {
	$html.=' <b> بدل اتصالات (موبايل ) </b>  '.$salary_precentage[3]. ' ' .$currency_type_ar.'  <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

}



$html.='</tr>';

$html.='</div></div>';
$html.='</tbody>';

$html.='</table>';











$html.='

<p style="text-indent: 0pt;text-align: left;">

<br>
</p>
';


//////page 2 ////////////////////////////////////////////////////////////////////////////////////
$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">
<tbody>

<tr style="height:534pt">';
//for eng
$html.='<td style="width:258pt;border-right-style:solid;border-right-width:1pt ">
</br>';
$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;"></p>
<br>        <br> <br>';


$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>4.Contract Type  :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Employment contract: Limited (<b>'. $job_offer_data[0]->jo_contract_yr_num.'Year</b> )
The contract starts after the status modification
Probation Period: <b>' . $job_offer_data[0]->probation_period. ' Month </b>
Employee required notifying the company if he would like to renew his contract 3 month before the end of contract.
Employee has all the responsibility to provide all the document and certificate needed for his contract and accepting any fine in case of delay or reject by the government. <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';





 if($job_offer_data[0]->termination_employee==0)
 {
 	$terminationemployee_sts='Not possible';

      $terminationemployee_sts_ar='غير متاح ';

 }
 else {

 	  $terminationemployee_sts=$job_offer_data[0]->termination_employee;

      $terminationemployee_sts_ar=$job_offer_data[0]->termination_employee;
 }





 if($job_offer_data[0]->termination_employer==0)
 {
 	$terminationemployer_sts='Not possible';

      $terminationemployer_sts_ar='غير متاح ';

 }
 else {

 	  $terminationemployer_sts=$job_offer_data[0]->termination_employer.'month';

      $terminationemployer_sts_ar=$job_offer_data[0]->termination_employer.'شهر';
 }



$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>5.Termination and Resining :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Termination of contract from employee side:
'. $terminationemployee_sts.'
Termination of contract from employer:
'.$terminationemployer_sts.'
In case of resignation from employee during the contract, Employee must pay for the company amount of 225 AED for each month till the end of contract plus the base salary for 3 months. The employee will lose his right in receiving the end-of-service salary and any additional amounts. <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>6.Holiday and Annual Leave :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='30 calendar days annual leave after completing of 12 months working inside the company.
Annual leave must apply at least 3 months in advance and the date of leave to be discussed by your manager.
Leave salary (Basic salary) Leave salary will be released after return from the annual leave.
Ticket to country: upon completion of 24 month of service the company shall reimburse economic one-way ticket to your home county at the end of contract, in case of renew the contract company will provide 2-way ticket after renewing the contract, maximum covered ticket (800) AED<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
$html.=' <b> Medical Insurance: provided, </b> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='</td>';



//for arabic
$html.='<td style="width:258pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl;">';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: -18pt;text-align: left;">
<b>  4.نوع العقد  </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='عقد توظيف محدد المدة <b>( '. $job_offer_data[0]->jo_contract_yr_num.' سنوات )</b>
يبدأالعقد إعتبارا من تاريخ تعديل الوضع
المدة التجريبية: <b>'. $job_offer_data[0]->probation_period.'  شهر   </b>يجب على الموظف إخطار الشركة إذا كان يرغب في تجديد عقده
قبل 3 أشهر من انتهاء العقد.
ويتحمل الموظف مسؤولية إحضار كافة الاوراق والمستندات
الرسمية الخاصة ب إصدار تصريح العمل الخاص به وفي حال
رفضها أو حصول أي تأخير لا تتحمل الشركة أي رسوم أو
غرامات ناتجة عن ذلك    <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>  5. إنهاء العقد أو الاستقالة  </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='إنهاء العقد من قبل الموظف:
'.$terminationemployee_sts_ar.'
أنهاء العقد من قبل الشركة:
فترة الاشعار  '. $terminationemployer_sts_ar.  '
في حالة الاستقالة من العمل خلال مدة العقد يجب على الموظف
دفع مبلغ 225 درهم عن كل شهر عمل حتى انتهاء مدة العقد
بالإضافة الى خصم راتب ثلاثة أشهر. الموظف المستقيل سوف
يفقد حقه باستلام راتب نهاية الخدمة أو ايه مستحقات إضافية. 
فترة الانذار في حال الاستقالة 3 أشهر
<span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> 6.العطلات والاجازات السنوية: </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='تمنح الشركة إجازة سنوية مدتها 30 يوماً بعد إتمام 12 شهراً من
العمل داخل الشركة .
يجب أن يتم التقدم للحصول على الإجازة السنوية قبل 3 أشهر على
الأقل من موعد الإجازة على ان يتم مناقشة موعد الاجازة من قبل
مديرك.
راتب الإجازة هو )الراتب الأساسي( ويُصرف راتب الإجازة بعد
العودة من الإجازة السنوية.
تذكرة السفر : عند الانتهاء من الخدمة لمدة 24 شهرًاتقدم الشركة
قيمة التذكرة على الدرجة السياحية في اتجاه واحد إلى بلدك
الأصلي في نهاية العقدفي حال الرغبة بالسفر ، الحد الأقصى
للتذكرة المغطاة ) 800 ( درهم ، وفي حالة تجديد العقد، ستقدم
الشركة تذكرة ثنائية الاتجاه بعد تجديد العقد. <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';






$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='<b>  التأمين الصحي مقدم من قبل الشركة      </b><span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='</td>
</tr>
</tbody>
</table>';




//page 3 //////////////////////////////////////////////////////////////////////////////////////////////

$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">
<tbody>

<tr style="height:534pt">';
//for eng
$html.='<td style="width:258pt;border-right-style:solid;border-right-width:1pt">';


$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> Sick leave policy: :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='During probation period you are no eligible for sick leave,
Sick leave accepted only with official sick leave certificate mention the number of days employee need to rest,
The sick leave calculation as following:
<br>

- Full paid for a period of first 15 days,
<br>
-Half paid for the second 15 days,
<br>
-Unpaid for the third 15 days.<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> Emergency leave:</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='In case of the death of a first-degree relative after approval of the administration,
Employee can get 7 days unpaid leave or any other costs. This leave does not apply to the first six months of employment.
Note: Sick leave and emergency leave as per company policy and might be changed. <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> 7.Location & Timing :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='Strictly follow the work timing.
<br><br>
- Working hours should be always attended in the office, not able to work from home.
<br><br>
- When 3 days late (10 min or later punch in) 1 day will be deducted, when absent 1 day without approval 2 days will be deduct.
<br><br>
- Employer have right to change your working hours and location as per business requirements,
<br><br>
- Please note that working hours are scheduled by the company based on business level and maybe extended during holiday or after work timing any additional hours will be calculated as an overtime.<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='</td>';

///////////arabic //////////////////////////////
$html.='<td style="width:254pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl;">';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> سياسة الإجازة المرضية   </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='خلال فترة الاختبار، لا يحق لك الحصول على إجازة مرضية
تُقبل الإجازة المرضية فقط مع شهادة إجازة مرضية رسمية تذكر
عدد الأيام التي يحتاجها الموظف للراحة،
يتم حساب الإجازة المرضية على النحو التالي:
<br><br>
- إجازة مدفوعة بالكامل خلال فترة ال 15 يوم الأولى
<br><br>
- إجازة نصف مدفوعة خلال فترة ال 15 يوم الثانية
<br><br>
-- إجازة غير مدفوعة لفترة ال 15 يوم الثالثة   <br><br> <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>الإجازات الطارئة: </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='في حالة وفاة قريب من الدرجة الأولى، وبعد موافقة الإدارة يمكن
للموظف الحصول على إجازة غير مدفوعة الأجر لمدة 7 أيام ولا
تغطى أي تكاليف أخرى.
لا تنطبق هذه الإجازة على الأشهر الستة الأولى من العمل
ملحوظة: سياسة الإجازة المرضية والإجازة الطارئة قد تتغير
حسب سياسة الشركة. <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>7.الموقع والتوقيت   </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='التزم بدقة بتوقيت العمل
<br><br>
-يجب حضور ساعات العمل دائمًا في المكتب، إمكانية
العمل من المنزل غير قابلة للتطبيق
<br><br>
-عندما تتأخر ل 3 أيام متتالية )مدة 10 دقائق أو أكثر(
سيتم خصم يوم عمل واحد، وفي حالة الغياب لمدة يوم
واحد بدون موافقة الإدارة سيتم خصم يومين عمل
بالمقابل. .
<br><br>
- يحق لصاحب العمل تغيير ساعات العمل والموقع وفقًا
لمتطلبات العمل.
<br><br>
-يرجى ملاحظة أن ساعات العمل يتم تحديدها من قبل
الشركة بناءً على مستوى العمل وربما يتم تمديدها أثناء
العطلة أو بعد ساعات العمل الرسمية، وسيتم احتساب
أجر أي تعديل على ساعات العمل على أنها ساعات
عمل إضافية. <br><span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';
$html.='</td>
</tr>
</tbody>
</table>';
///////end of page 3 



////////page  4 ////////


$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">

<tbody>

<tr style="height:534pt">';
//for eng
$html.='<td style="width:344pt;border-right-style:solid;border-right-width:1pt">';


$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> 8.Job Description :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' '.$job_description.'<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> 9.Duties and Responsibilities :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=''.$responsibilities.'<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='</td>';

///////////arabic //////////////////////////////
$html.='<td style="width:344pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl; font-size:16px;">';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> 8.توصيف العمل  </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=''.$job_description_ar.'<span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>9.المهمات والمسؤوليات   </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' '.$responsibilities_ar   .' <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';

$html.='</td>
</tr>
</tbody>
</table>';

/////end 4 table page




/////page 5 






$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">
<tbody>

<tr style="height:534pt">';
//for eng
$html.='<td style="width:258pt;border-right-style:solid;border-right-width:1pt">';

$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;"></p>
<br>        <br> <br>';

$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> 10. Requirements :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' '.$requirements.'<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
<br>
<br>
<br>
</p>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> Language skills : </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=''.$job_offer_data[0]->languages.'<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
<br>
</p>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> Knowledge, Skills and Abilities Required: </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=''.$knowledge_skills_ability.'<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
</br>
<br>
<br>

</p>';


$html.='</td>';

///////////arabic //////////////////////////////
$html.='<td style="width:254pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl;">';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>10.متطلبات المنصب   </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=''.$requirements_ar.'<span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
<br>
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> مهارات اللغة   </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' '.$language_skill_ar.' <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
</p>';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>المعرفة والمهارات المطلوبة  </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' '.$knowledge_skills_ability_ar.' <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
</p>';




$html.='</td>
</tr>
</tbody>
</table>';

/////end page 5 



////page 6  














$html.='<table style="border-collapse:collapse;margin-left:42.325pt" cellspacing="0">
<tbody>
<tr style="height:534pt">';
//for eng
$html.='<td style="width:258pt;border-right-style:solid;border-right-width:1pt">';





$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;"></p>
<br>        <br> <br> <br> <br>';


$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b> 11. Additional Skills required :</b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' Training on the use of accounting software and the companys supplementary software  Knowledge of all available products and prices for the main items<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>12. Additional requirements for this position </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='_Employee must acknowledge that all company information and business contacts that have been developed during the period employment here, belongs exclusively to Biri Group and Berry Building Materials Trading.<br>
_The company code of conduct and non-compete agreement must be signed before work begins  Don’t use own devices during work timing (exception lunch break).<br> _ Use only company phone.<br> _ Provide customers only with company’s contact information.<br> _Don’t use own phone, e- mail and messengers for contacting customers<br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</p>
<br>
<br>';




$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>Bachir BERRY CEO </b>
<br>
<br>';
$html.='<p class="s5" style="padding-left: 38pt;text-indent: -18pt;text-align: left;">
<b>Bianora BIRI       Administrative director   </b>
<br>
<br>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';


$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';




$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' I accept the offer as outlined above <br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' Name & signature :  <br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' Date:  <br> <span class="s2"></span>';
$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';


$html.='</td>';

///////////arabic //////////////////////////////
$html.='<td style="width:254pt;border-left-style:solid;border-left-width:1pt text-align: right; direction: rtl;">';

$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> </b> </p> <br><br><br><br><br><br><br>';
$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> 11 . المهارات الإضافية المطلوبة : </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='-
التدريب على استخدام برنامج المحاسبة وبرامج الشركة  الملحقة  .
<br>


- المعرفة لكافة المنتجات المتوفرة والاسعار للأصناف    الرئيسة  .
<br>

 <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p>';



$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b> 12 . متطلبات إضافية لهذا المنصب: </b>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' -يجب أن يقر الموظف بأن جميع معلومات الشركة وجهات
الاتصال التجارية التي طورها أثناء عمله هنا تنتمي حصريًا إلى
مجموعة بيري وشركة بيري لتجارة مواد البناء.
 يجب توقيع اتفاقية عدم إفشاء وعدم التنافس قبل بدء العمل  . 
 <br>
- عدم استخدام الأجهزة الخاصة أثناء توقيت العمل
(باستثناء استراحة الغداء). <br> و التاكيد على استخدم اجهزة
الشركة فقط.  .<br>
- تزويد العملاء بمعلومات الاتصال الخاصة بالشركة
فقط. . <br>و التأكيد على عدم استخدام الهاتف والبريد
الإلكتروني الشخصييم لمراسلة وللاتصال بالعملاء  .<br><span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">

<br>
<br>
<br>
<br>
<br>
<br>
<br>
</p>';


$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>  </b></p> <br><br><br> <br><br><br> <br><br><br>';

$html.='<p class="s1" style="padding-left: 124pt;text-indent: 18pt;text-align: left;">
<b>الرئيس التنفيذي: بشير بيري  </b></p> <br>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.=' المدير الاداري : بيانورا بيري <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>
</p> <br> <br>';


$html.='<p class="s1" style="padding-left: 2pt;padding-right: 59pt;text-indent: 0pt;line-height: 198%;text-align: left;">';

$html.='  أقبل العرض كما هو موضح أعلاه  <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>

</p>';
$html.=' الاسم والتوقيع:  <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>

</p>';
$html.='  التاريخ :  <span class="s2"></span>';

$html.='<p style="text-indent: 0pt;text-align: left;">
<br>

</p>';




$html.='</td>
</tr>
</tbody>
</table>';

/////////end page 6










$html.='</body>';
$html.='</html>';

//echo $html;
$pdfFilePath = $job_offer_data[0]->job_id.'.pdf';

	 $mpdf = new \Mpdf\Mpdf();
	 $mpdf->autoScriptToLang = true;
	$mpdf->autoLangToFont = true;
    $mpdf->autoArabic=true;
    // $mpdf->SetDirectionality('rtl');
	$mpdf->defaultfooterline = 0;

 	//$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$siv_data[0]->si_company));



 if($master_company=="Dubai - BERRY")
  {
//   	$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("berry_footer.png").'">');

      $mpdf->SetHeader('<img src="' . base_url("berry_header.png") . '">');
	$mpdf->SetFooter('<img src="' . base_url("berry_footer.png") . '">');
  }
      elseif($master_company=="KSA")
     {
    	
//        $mpdf->SetHeader('<img src="'.base_url("ksa-header-new.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("ksa-footer-new.png").'">');

     	$mpdf->SetHeader('<img src="' .  base_url("ksa-header-new.png") . '">');
	$mpdf->SetFooter('<div >Page {PAGENO} of {nb}</div><img src="' . base_url("ksa-footer-new.png") . '">');
  }
 	elseif($master_company=="FACTORY")
{
		 
//  	$mpdf->SetHeader('<img src="'.base_url("biri_industries_header.png").'">'.$head_all);
//  	$mpdf->SetFooter('<div>Page {PAGENO} of {nb}</div><img src="'.base_url("biri_industries_footer.png").'">');

	$mpdf->SetHeader('<img src="' . base_url("biri_industries_header.png") . '">');
	$mpdf->SetFooter('<img src="' . base_url("biri_industries_footer.png") . '">');
		   }



// else
// {
// 	$mpdf->SetHeader($head_all);
// 	$mpdf->SetFooter('<div style="margin-bottom:100px;">Page {PAGENO} of {nb}</div>');
// }
//echo $html;
//print_r($fnet_details);
		 $mpdf->WriteHTML($stylesheet,1);
		
					$mpdf->AddPage(
						'', // L - landscape, P - portrait 
						'',
						'',
						'',
						'',
						4, // margin_left
						4, // margin right
						40, // margin top
						30, // margin bottom
						0, // margin header
						0
					); // margin footer
				
				// else{
				// 	$mpdf->AddPage(
				// 		'', // L - landscape, P - portrait 
				// 		'',
				// 		'',
				// 		'',
				// 		'',
				// 		5, // margin_left
				// 		5, // margin right
				// 		97, // margin top
				// 		20, // margin bottom
				// 		60, // margin header
				// 		30
				// 	); // margin footer
				// }
   
	     $mpdf->WriteHTML($html,2);	     
	     //save in folder
		$mpdf->Output("./uploads/inv_pdf/".$pdfFilePath, "F");
  		$mpdf->Output($pdfFilePath,'D');
				
 		}
	}
}
















}