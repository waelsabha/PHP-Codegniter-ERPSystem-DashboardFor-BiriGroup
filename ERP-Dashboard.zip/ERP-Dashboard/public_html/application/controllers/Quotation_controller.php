<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quotation_controller extends CI_Controller {

public function __construct() {
		parent::__construct();
	  $this->load->helper(array('session','email','img','gnrl','mail_img_request'));	
		$this->load->library('numbertowordconvertsconver');	
    	$this->load->library('numbertowordconvertsconverksa');
      //	$this->load->library('numbertowords');		
		$this->load->model(array('Second_db_model','Sales_book_model'));
		$this->load->model('Third_db_model','tm');	
		require 'vendor/autoload.php';
		require_once 'vendor/khaled.alshamaa/ar-php/src/Arabic.php';		

	}

function add_quotation($qid=null,$page_name=null)
{

if(logged_in())
	{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
         $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {
            if ($page_cred[$i]=='add-quotation')
            {
               $excist=true;
               $i=$cred_count;
            }   

           else
                {$excist=false;}

        }
       if ($excist) {


	if($this->session->userdata['user']['role'] !='1')
	$data['customers']=$this->Admin_model->get_data('sales_customer_entry',array('sca_status'=>'1','sca_staff_id'=>$this->session->userdata['user']['username']));	
	else
		$data['customers']=$this->Admin_model->get_data('sales_customer_entry',array('sca_status'=>'1'));
		
	$data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));
if(empty($qid))//onl on creating new quotations/////
{
	$val_quotation=$this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1'),'','','q_id','DESC');
	if(empty($val_quotation))
	$data['doc_num']='SQ2500';
	else
	{
	$bal_string1=str_replace("SQ", "", $val_quotation[0]->q_ref_no);
	//print_r($bal_string1);
           $new_id_1=($bal_string1)+1;
            $data['doc_num']="SQ".$new_id_1;
	}
	
}
elseif(!empty($qid) && !empty($page_name))//on performas////
{
	$val_quotation=$this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1'),'','','q_id','DESC');
	if(empty($val_quotation))
	$data['doc_num']='SQ2500';
	else
	{
	$bal_string1=str_replace("SQ", "", $val_quotation[0]->q_ref_no);
	//print_r($bal_string1);
           $new_id_1=($bal_string1)+1;
            $data['doc_num']="SQ".$new_id_1;

           // print_r($data['doc_num']);
	}
	$data['result2']= $this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$qid));  
	
	 if(!empty($data['result2'][0]->q_cusotmer_id))
	 {
	 	$data['customers_data']=$this->Admin_model->get_data('sales_customer_entry',array('sca_status'=>'1','sca_id'=>$data['result2'][0]->q_cusotmer_id)); 
	 }

	 $prd_ids=explode('|#|', $data['result2'][0]->q_prd_id);
	 foreach($prd_ids as $pid)
	 {
	 	$data['prds'][]=$this->tm->get_data('products',array('pid'=>$pid));
	 }

}
else////on editing the quotation///////
{
	 $data['result']= $this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$qid));  
	 if(!empty($data['result'][0]->q_cusotmer_id))
	 {
	 	$data['customers_data']=$this->Admin_model->get_data('sales_customer_entry',array('sca_status'=>'1','sca_id'=>$data['result'][0]->q_cusotmer_id)); 
	 }
}	
$data['page_name']=$page_name;
	$data['class_data']=$this->tm->get_data('category',array('cstatus'=>'1'));
	$data['project_masters']=$this->Admin_model->get_data('master_project',array('mpj_sts'=>'1'));
	//pre_list($data['result']);
	$this->load->view('admin/sales/add_quotation',$data);


}

	else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
        } 
}




}

function list_quotation($type=null)
{
	//print_r($type);
if(logged_in())
	{
		
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
         $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {
            if ($page_cred[$i]=='list-quotation')
            {
               $excist=true;
               $i=$cred_count;
            }   

           else
                {$excist=false;}

        }
       if ($excist) {


		if($this->session->userdata['user']['main_dept']=="Sales")
			{
				if($this->session->userdata['user']['user_desig']=="Team-lead")
		 		 $data['result']= $this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1'),'','','q_id','DESC');
		 		else
		 		$data['result']= $this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1','q_user_id'=>$this->session->userdata['user']['username']),'','','q_id','DESC');
	 			
	 		}
			 elseif($this->session->userdata['user']['main_dept']=="Main")
			 {
			  $data['result']= $this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1'),'','','q_id','DESC');
			 }
			 else
			 {
			 	$data['result']= $this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1','q_user_id'=>$this->session->userdata['user']['username']),'','','q_id','DESC');
			 }		
		//pre_list($data['result']);
 foreach($data['result'] as $index=>$t)
 {
 $prd_ids=explode('|#|', $t->q_prd_id);
 	foreach($prd_ids as $pid)
 	{
 	$data['prds'][$index][]=$this->tm->get_data('products',array('pid'=>$pid));
 	}
 }
 $data['page_type']=$type;
 //echo "<pre>";
 //print_r($data['prds']);
 // echo "</pre>";
 $this->load->view('admin/sales/list_quotation',$data);

}
else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
        } 
 }
}

function quotation_status($qot_id)
{
 $data['result']= $this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$qot_id));  
 $prd_ids=explode('|#|', $data['result'][0]->q_prd_id);
 foreach($prd_ids as $pid)
 {
 	$data['prds'][]=$this->tm->get_data('products',array('pid'=>$pid));
 }
      $this->load->view('admin/sales/quotation_sts',$data);
}

function add_signature()
{
if(logged_in())
	{

        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
         $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {
            if ($page_cred[$i]=='add-signature')
            {
               $excist=true;
               $i=$cred_count;
            }   

           else
                {$excist=false;}

        }
       if ($excist) {

         $this->load->view('admin/sales/add_signature');

}

 else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
        } 


  }
}

function submit_signature()
{
 $user_data_sig=$this->Admin_model->get_data('quotation_signature',array('qs_user_id'=>$this->session->userdata['user']['username']));

$this->load->library('image_lib');
  $this->load->library('upload');
$targetfolder='./uploads/quot_signature/';
		if (!is_dir($targetfolder)) 
            {
            	mkdir('./'.$targetfolder, 0777, TRUE);
	   }
	   
  $image = array();

if (isset($_FILES['signature']['name']) && $_FILES['signature']['name'] != "") 
{

      $config = array();
      $config['file_name'] = time() . $_FILES['signature']["name"];
    $config['upload_path'] = $targetfolder;
      $config['allowed_types'] = 'jpg|jpeg|png|JPG|JPEG|PNG';
     // $config['max_size'] = '2048000';////2mb
      $config['file_ext_tolower'] = TRUE;
      $config['overwrite'] = FALSE;
      $config['remove_spaces'] = TRUE;
      $this->load->library('upload', $config);
      // Create custom object for cover upload
     
      $this->upload ->initialize($config);     

      if($this->upload->do_upload('signature'))
      {
        $data3 = $this->upload->data();
        $configer =  array(
              'image_library'   => 'gd2',
              'source_image'    =>  $data3['full_path'],
              'maintain_ratio'  =>  TRUE,
              'width'           =>  250,
              'height'          =>  180,
            );
            $this->image_lib->clear();
            $this->image_lib->initialize($configer);
            $this->image_lib->resize();
            
        $uploadedfile3 = $data3['file_name'];
        $data=array(
      'qs_user_id'=>$this->session->userdata['user']['username'],
      'qs_file'=>$uploadedfile3,
      'qs_sts'=>'1',
      );
      if(empty($user_data_sig))
      {
      $insert_id=$this->Admin_model->insert_data('quotation_signature',$data);
      $this->session->set_flashdata('success', 'File Successfully uploaded');
      }
      else
      {
       $insert_id=$this->Admin_model->update_data('quotation_signature',$data,array('qs_user_id'=>$this->session->userdata['user']['username']));
      $this->session->set_flashdata('success', 'File Successfully uploaded');
      }
redirect('add-signature');
      }
      else
      {
     //$uploadedfile3 =  $this->upload->display_errors();
       $this->session->set_flashdata('errors', $this->upload->display_errors());
redirect('add-signature');
      }  
}		
}

function get_details_prd()
{
	$table_id=$this->input->post('table_id');
	$prd_data=$this->tm->get_data('products',array('p_sts'=>'1'));
$html='<select data-plugin-selectTwo  class="form-control populate product_'.$table_id.'" name="si_product[]" onchange="get_product_details('.$table_id.');"><option >Choose</option>';
	foreach($prd_data as $pd)
	{
	$html.="<option value=".$pd->pid.">".$pd->pname.":: <br/>".$pd->pcode."</option>";
	}
  $html.="</select>";
  echo $html;
}

function submit_quotation_details()
{
if(logged_in())
	{
$update_quotation_id=$this->input->post('quotation_id');
$date_ref=$this->input->post('date_ref');
$date1=explode('/',$date_ref);
			$month=$date1[0];
			$date=$date1[1];
			$year=$date1[2];
$new_formated_date=$year.'-'.$month.'-'.$date;
$checkbox_cash_customer=$this->input->post('add_cash_customer');

$edit_cust_data_id=$this->input->post('edit_cust_data_id');
	if($checkbox_cash_customer=='1')
	{
		if(!empty($this->input->post('cash_cust_name')))
		$custname=$this->input->post('cash_cust_name');
		else
			$custname='';

		if(!empty($this->input->post('cash_cust_comp')))
		$custcomp=$this->input->post('cash_cust_comp');
		else
			$custcomp='';

		if(!empty($this->input->post('cash_cust_email')))
		$custemail=$this->input->post('cash_cust_email');
		else
			$custemail='';

		if(!empty($this->input->post('cash_cust_mob')))
		$custmob=$this->input->post('cash_cust_mob');
		else
			$custmob='';

		if(!empty($this->input->post('cash_cust_land')))
		$custland=$this->input->post('cash_cust_land');
		else
			$custland='';	
			
		$data_customer_insert=array(
           	'sca_cust_name'=>$custname,
           	'sca_cust_country'=>'228',
            'sca_cust_email'=>$custemail,
           	'sca_cust_company'=>$custcomp,
           	'sca_cust_landline'=>$custland,
           	'sca_cust_mobile'=>$custmob,
           	'sca_staff_id'=>$this->session->userdata['user']['username'], 
           	'sca_status'=>'1'
           ); 	
           	if(empty($update_quotation_id))////only during insertion
          	{
          		
        	$customer_insert_id=$this->Admin_model->insert_data('sales_customer_entry',$data_customer_insert);
        	$cust_id="CUST_".str_pad($customer_insert_id, 2, '0', STR_PAD_LEFT);
	     		$data1_cust=array('sca_cust_id'=>$cust_id);
	    	$this->Admin_model->update_data('sales_customer_entry',$data1_cust,array('sca_id'=>$customer_insert_id));
	     	}
	     	else
	     	{
	     
	     		if(!empty($edit_cust_data_id))
	     		{
	     		$this->Admin_model->update_data('sales_customer_entry',$data_customer_insert,array('sca_id'=>$edit_cust_data_id));
	     		$customer_insert_id=$edit_cust_data_id;
	     		}
	     		else
	     		{
	     		$customer_insert_id=$this->Admin_model->insert_data('sales_customer_entry',$data_customer_insert);
        			$cust_id="CUST_".str_pad($customer_insert_id, 2, '0', STR_PAD_LEFT);
	     			$data1_cust=array('sca_cust_id'=>$cust_id);
	     			$this->Admin_model->update_data('sales_customer_entry',$data1_cust,array('sca_id'=>$customer_insert_id));
	     		}
	     	}		     			
	}
else{
$customer_insert_id=$this->input->post('choose_customer');

	$cusotmer_details=$this->Admin_model->get_data('sales_customer_entry',array('sca_id'=>$this->input->post('choose_customer')));
	
	if(!empty($cusotmer_details[0]->sca_cust_name))
	$custname=$cusotmer_details[0]->sca_cust_name;
	else
	$custname=$this->input->post('cash_cust_name');
	
	if(!empty($cusotmer_details[0]->sca_cust_company))
	$custcomp=$cusotmer_details[0]->sca_cust_company;
	else
	$custcomp=$this->input->post('cash_cust_comp');
	
	if(!empty($cusotmer_details[0]->sca_cust_email))
	$custemail=$cusotmer_details[0]->sca_cust_email;
	else
	$custemail=$this->input->post('cash_cust_email');
	
	if(!empty($cusotmer_details[0]->sca_cust_mobile))
	$custmob=$cusotmer_details[0]->sca_cust_mobile;
	else
	$custmob=$this->input->post('cash_cust_mob');
	
	if(!empty($cusotmer_details[0]->sca_cust_landline))
	$custland=$cusotmer_details[0]->sca_cust_landline;
	else
	$custland=$this->input->post('cash_cust_land');	
	
	$data_customer_insert=array(
           	'sca_cust_name'=>$custname,
           	'sca_cust_country'=>'228',
            'sca_cust_email'=>$custemail,
           	'sca_cust_company'=>$custcomp,
           	'sca_cust_landline'=>$custland,
           	'sca_cust_mobile'=>$custmob,
           	'sca_staff_id'=>$this->session->userdata['user']['username'], 
           	'sca_status'=>'1'
           ); 	
     $this->Admin_model->update_data('sales_customer_entry',$data_customer_insert,array('sca_id'=>$customer_insert_id));      
}
	$payment_type=$this->input->post('payment_type');
	if($payment_type=="Advance")
$adv_payment=$this->input->post('adv_paymnt_amount');
else
$adv_payment='';

if(!empty($update_quotation_id))
$qution_crtd_by=$this->input->post('quotation_created_by');
else
$qution_crtd_by=$this->session->userdata['user']['username'];

/////for upload files//////
$image = array();
	$uploadImgData = array();


  $ImageCount = count($_FILES['files']['name']);
 
        for($i = 0; $i < $ImageCount; $i++)
        {
            $_FILES['file']['name']       = $_FILES['files']['name'][$i];
            $_FILES['file']['type']       = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['files']['error'][$i];
            $_FILES['file']['size']       = $_FILES['files']['size'][$i];

            // File upload configuration
            $uploadPath = 'uploads/file_manager/';
         $config['file_name'] = time() . $_FILES["files"]["name"][$i];
            $config['upload_path'] = $uploadPath;
            //$config['max_size'] = '3000000';////3mb
            $config['allowed_types'] = '*';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'business_card');
            $this->business_card->initialize($config);

            // Upload file to server
            if($this->business_card->do_upload('file'))
            {           
                // Uploaded file data
                $imageData = $this->business_card->data();
              
                $uploadImgData[]=$imageData['file_name'];
              
                if(!empty($uploadImgData))
                {
              		$data_image=implode(',',$uploadImgData);
              		$q_current_status='Inquiry';
              	}
              	else
              	{
              		 $data_image='';
    			$q_current_status='Quotation Issued';
              	}	
                //print_r($uploadImgData);
            } 
            else
            {
           	 if(!empty($this->input->post('inquiry_files')))
            		{
            		$data_image=$this->input->post('inquiry_files');
    			$q_current_status='Quotation Issued';
            		}
            		else
           		{
            		$data_image='';
    			$q_current_status='Quotation Issued';
    			}
            }      
        }

////for upload files//////////
$data['q_user_id']=$qution_crtd_by;
$data['q_sub']=$this->input->post('quote_sub');
$data['q_date']=$new_formated_date;
$data['q_cusotmer_id']=$customer_insert_id;
$data['q_cat']=$this->input->post('choose_category');
$data['q_delivery_time']=$this->input->post('delivery_time');
$data['q_offer_validity']=$this->input->post('offer_vailidity');
$data['q_payment_type']=$this->input->post('payment_type');
//'q_payment_days'=>$this->input->post('payment_days'),
$data['show_stamp']=$this->input->post('show_stamp');
$data['show_total']=$this->input->post('show_grand_total');
$data['q_payment_notes']=$this->input->post('q_payment_notes');

$data['q_cust_name']=$custname;
$data['q_cust_comp']=$custcomp;
$data['q_cust_email']=$custemail;
$data['q_cust_mob']=$custmob;
$data['q_cust_landline']=$custland;
//'q_adv_pay_amount'=>$adv_payment,

$data['q_prd_id']=$this->input->post('prdids');
$data['q_prd_qnty']=$this->input->post('qntys');
$data['q_prd_wgt']=$this->input->post('wgt_prds');
$data['q_prd_hsc']=$this->input->post('hsccodes_prds');


$data['q_prd_vat']=$this->input->post('vat_pers');

$data['q_remarks']=$this->input->post('extra_detail');

$data['q_currency_type']=$this->input->post('currency_type');

if ($data['q_currency_type']=='sr')
{
	$data['q_prd_price']=$this->input->post('unit_prices_ksa');
	$data['q_prd_tot']=$this->input->post('total_prices_ksa');
}
else if ($data['q_currency_type']=='usd')
{
	$data['q_prd_price']=$this->input->post('unit_prices_usd');
	$data['q_prd_tot']=$this->input->post('total_prices_usd');
}
else
{
	$data['q_prd_price']=$this->input->post('unit_prices');
	$data['q_prd_tot']=$this->input->post('total_prices');
}



$data['q_discount_per']=$this->input->post('discount_percentage');
$data['q_stock_note']=$this->input->post('stock_ava');
$data['q_mpdf_file']=$this->input->post('ref_no').'.pdf';
$data['q_sts']='1';

$data['q_total_price']=$this->input->post('total_price_final');
$data['q_total_vat']=$this->input->post('total_vat_final');
$data['q_net_total']=$this->input->post('net_total');
$data['q_additional_charge']=$this->input->post('additional_charge');
$data['q_grand_total']=$this->input->post('grand_total');

$data['q_add_notes']=$this->input->post('q_add_notes');
$data['q_files']= $data_image;
$data['q_current_status']= $q_current_status;
$data['q_approval_stamp_sign']=$this->input->post('approved_sts_sign');
$data['q_price_ar']=$this->input->post('converted_ar');

$data['q_project']= $this->input->post('q_project');;
$data['q_tendor_no']= $this->input->post('q_tendor_no');

if(empty($update_quotation_id))////willl insert
	{
		$document_bal_number=str_replace("SQ", "", $this->input->post('ref_no'));
		//$data['ref_number_part']=$document_bal_number;
		$check_number_doc=$this->Admin_model->get_data('qoutattion_entry',array('ref_number_part'=>$document_bal_number));
		if(!empty($check_number_doc))/////means the number already exists
		{
			$get_last_val=$this->Admin_model->get_data('qoutattion_entry','','1','','q_id','DESC');
			$bal_string=$get_last_val[0]->ref_number_part;

			 $new_id_1=($bal_string)+1;
			$data['ref_number_part']=$new_id_1;
			$data['q_ref_no']="SQ".$new_id_1; 
		}
		else
		{
			$data['ref_number_part']=$document_bal_number;
			$data['q_ref_no']=$this->input->post('ref_no');
		}
	}
//pre_list($data);
if(empty($update_quotation_id))
{
$insert_id=$this->Admin_model->insert_data('qoutattion_entry',$data);

//echo $insert_id;
$data_activity=array(
		'act_function'=>'quotation created',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_quot_id'=>$insert_id,
		'act_status'=>$q_current_status,
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);	
//print_r($insert_id);
	if(!empty($insert_id))
	{
		if($this->input->post('show_stamp')=='1')
		{
			send_quot_approval_mail_mngt_stamp_sign($insert_id);
			$this->session->set_flashdata('success', 'Data Successfully inserted.Mail send requesting approval for stamp and signature.');
		}
		else
		{
			$this->session->set_flashdata('success', 'Data Successfully inserted');
		}
		
		if(empty($data_image))
		redirect('quotation-status/'.$insert_id);
		else
		redirect('list-quotation');
	}
	else
	{
		$this->session->set_flashdata('errors', 'Unable to insert.Please try again later.');
		redirect('list-quotation');
	}
//redirect('quotation-status/'.$insert_id);
}
else
{
//print_r($data);
$this->Admin_model->update_data('qoutattion_entry',$data,array('q_id'=>$update_quotation_id));
$data_activity=array(
		'act_function'=>'quotation edited',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_quot_id'=>$update_quotation_id,
		'act_status'=>'Updated Quotation',
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);
		
$this->session->set_flashdata('success', 'Data Successfully updated');
if(empty($data_image))
redirect('quotation-status/'.$update_quotation_id);
else
redirect('list-quotation');
}
//print_r($data);
//echo '<br/>';
//echo $insert_id;
//$this->send_mail_quotation($insert_id);
  }		
}
function generate_quotation($quot_id,$as_pi=null)
{

//$quot_id=$this->input->post('quotation_id');

 $quotation_data= $this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$quot_id));  
         
$prd_details=explode('|#|',$quotation_data[0]->q_prd_id);
$qty_details=explode('|#|',$quotation_data[0]->q_prd_qnty);
$unt_price_details=explode('|#|',$quotation_data[0]->q_prd_price);
$vat_pre_details=explode('|#|',$quotation_data[0]->q_prd_vat);
$tot_price_details=explode('|#|',$quotation_data[0]->q_prd_tot);
$extra_prd_details=explode('|#|',$quotation_data[0]->q_remarks);


foreach($prd_details as $index=>$pd)
{
	//print_r($pd);
	
	$prd_table_data[]=$this->tm->get_data('products',array('pid'=>$pd));
	
}
$authorized_signture=$this->Admin_model->get_data('quotation_signature',array('qs_user_id'=>$this->session->userdata['user']['username']));

$logged_users_details=$this->Admin_model->join_qry('login_credentials','employee_details','ed_login_id','log_id',array('log_uname'=>$quotation_data[0]-> q_user_id),('employee_details.*,login_credentials.*'));

//print_r($prd_table_data);
//print_r($logged_users_details);

$stylesheet = file_get_contents('style_mpdf.css');


	$html='<!doctype html>
<head>

</head>

    <body> ';
	  
	 
				$html.='
				<div class="contentimg">
				<div class="content">
				<table border="0" width="100%">
				<tr >';
				if(!empty($as_pi))
$html.='<td align="left" rowspan="4"><h1 style="text-align:left">PRO FORMA INVOICE</h1></td>';
					else
					$html.='<td align="left" rowspan="3"><h1 style="text-align:left">SALES QUOTATION</h1></td>';
					
					$html.='<td style="text-align:right;" align="right">
						<div style="text-align:right;">
							<p align="right" style="text-align:justify;">Issued by: '.$logged_users_details[0]->ed_name.'</p>
						
							
							<p align="right" style="text-align:justify;">Document No: '.$quotation_data[0]->q_ref_no.'</p>
							
							<p align="right" style="text-align:justify;">Date: '.$quotation_data[0]->q_date.'</p>';
						if(!empty($as_pi))
						$html.='<p align="right" style="text-align:justify;">Our TRN: 100301351100003</p>';
						
						$html.='</div>
					</td>
				</tr>
				
				
				</table>
				
				
				
				</div>';

			 
				$html.='<table align="center" class="cusotmer_info"  width="80%" border="1">';
				
				$html.='<tr>
					<td>To: '.$quotation_data[0]->q_cust_comp.'</td>
					<td>Attn: '.$quotation_data[0]-> q_cust_name.'</td>
				</tr>';
				if(!empty($as_pi))
				{
					$html.='<tr>
					<td>TRN Number: '.$quotation_data[0]->q_pi_trn.'</td>
					<td>LPO: '.$quotation_data[0]-> q_pi_po_number.'</td>
				</tr>';
				}
				$html.='<tr>
					<td>Email: '.$quotation_data[0]->q_cust_email.'</td>
					<td>Tel: '.$quotation_data[0]->q_cust_landline.'</td>
				</tr>
				<tr>
					<td>Subj:'.$quotation_data[0]->q_sub.' </td>
					<td>Mobile: '.$quotation_data[0]-> q_cust_mob.'</td>
				</tr>';
				
				
				
				$html.='</table>


				<table align="center" class="prd_info"  width="80%" border="1">
					<tr class="prd_head" >
					 <td align="center">No.#</td>
					 <td align="center">Picture</td>
					 <td align="center">Model No.</td>
					 <td align="center">Product Description</td>
					 
					 <td align="center" width="10%">Qty</td>
					 <td align="center">Price Excl.VAT</td>
					 <td align="center">Total</td>
					  <td align="center">VAT</td>
					</tr>';
$i=1;
$total_sum_prd='0';
$total_vat_sum_prd='0';
$total_discount_sum_prd='0';
					foreach($prd_table_data as $index=>$pd3)
					{
						
						if(empty($pd3[0]->p_prd_img))
						{
							$filename="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpeg";
						 if (file_exists($filename)) {
						 	$img_path=$filename;
							} else {
							$img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpg";
						    }
						}
						else
						{
							$first_img_prd=explode(',',$pd3[0]->p_prd_img);
							if(!empty($first_img_prd[0]))
						 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
						 	
						 	else
						 	$img_path="https://birigroup.com/uploads/prd_images/".$pd3[0]->p_prd_img."";
						 	
						}
						
						//print_r($img_path);
						$pname=explode('|~~|',$pd3[0]->pname);
						if(!empty($pname[0]))
						{
							$prd_names=explode(',',$pname[0]);
							$product_name=$prd_names[0];
							//$product_name=$pname[0];
						}
						else
						{
						 	$pname=explode(',',$pd3[0]->pname);
						 	$product_name=$pname[0];
						}
						//$product_name=$pname;
						
$total_sum_prd=$total_sum_prd+$tot_price_details[$index];

$total_vat_sum_prd=$tot_price_details[$index]+$total_vat_sum_prd;


					$html.='<tr style="text-align:center;">
					 <td align="center">'.$i++.'</td>';

					 if(!empty($img_path))
					 $html.='<td align="center"><img src="'.$img_path.'" width="100" height="100"></td>';
					else
						 $html.='<td align="center">'.$product_name.'</td>';

					 $html.='<td align="center">'.$pd3[0]->pcode.'</td>';
					 
					if( (!empty($pd3[0]->p_dimenstion)) && (!empty($pd3[0]->p_material)) && (!empty($pd3[0]->p_wgt)) )
						{
						
						//echo "in if<br/>";
						 $html.='<td>Name:'.$product_name.'<br/>Brand:'.$pd3[0]->pcat.'<br/>';
						if(!empty($pd3[0]->p_dimenstion))
						 $html.='Dimension:'.$pd3[0]->p_dimenstion.'<br/>';
						 if(!empty($pd3[0]->p_wgt))
							$html.='Weight:'.$pd3[0]->p_wgt.'<br/>';
							if(!empty($pd3[0]->p_material))
							$html.='Material:'.$pd3[0]->p_material.'<br/>';
							
							if(!empty($extra_prd_details[$index]))
						$html.=$extra_prd_details[$index];
						
							$html.='</td>';
						}
						elseif(!empty($pd3[0]->p_desc_2))
						{
						//echo "in elseif<br/>";
						$html.='<td>'.$pd3[0]->p_desc_2.'<br/>';
						
						if(!empty($extra_prd_details[$index]))
						$html.=$extra_prd_details[$index];
						
						$html.='</td>';
						}
						else
						{
						//echo "in else<br/>";						
					 $html.='<td>Name:'.$product_name.'<br/>
						Brand:'.$pd3[0]->pcat.'<br/>';
						
						if(!empty($extra_prd_details[$index]))
						$html.=$extra_prd_details[$index];
						
						$html.='</td>';
						}
						
					
					  $html.='
					 
					  <td align="center">'.$qty_details[$index].'</td>
					 <td align="center">'.number_format((float)$unt_price_details[$index], 2, '.', '').'</td>
					 <td align="center">'.number_format((float)$tot_price_details[$index], 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					 <td align="center">'.number_format((float)$vat_pre_details[$index], 2, '.', '').'</td>
					</tr>';
				}
				
				$dicount_per=$quotation_data[0]->q_discount_per;

$total_discount_sum_prd=$total_sum_prd-((($dicount_per/100)*$total_sum_prd));
if($quotation_data[0]->q_currency_type =='usd')	
{
	$fixed_rate='3.67250';
}		
elseif($quotation_data[0]->q_currency_type =='sr')
{
	$fixed_rate='0.975';
}
else
{
	$fixed_rate='1.0';
}

if($quotation_data[0]->show_total=="1")
{

					$html.='<tr>
						<td colspan="6" align="center">TOTAL Price </td>
						<td colspan="3" align="center">'.number_format((float)$quotation_data[0]->q_total_price, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';
					if(!empty($quotation_data[0]->q_discount_per))
					{
					$dic_price=$quotation_data[0]->q_discount_per;
					$html.='<tr>
						<td colspan="6" align="center">Discount Price</td>
						<td colspan="3" align="center">'.number_format((float)$quotation_data[0]->q_discount_per, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';
					}
					else
					{
					$dic_price=0;
					}
					
					if(!empty($quotation_data[0]->q_additional_charge))
					{
					$additional_price=$quotation_data[0]->q_additional_charge;
					$html.='<tr>
						<td colspan="6" align="center">Additional Charges </td>
						<td colspan="3" align="center">'.number_format((float)$quotation_data[0]->q_additional_charge, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';
					
					}
					else
					{
					$additional_price=0;
					}
					
					$net_total=(($quotation_data[0]->q_total_price+$additional_price)-$dic_price);
					if(!empty($quotation_data[0]->q_discount_per))
					{
						if($quotation_data[0]->q_total_vat=='0')
						{
							$vat_as_per_new_instruction=$quotation_data[0]->q_total_vat;
						}else{
                                  $vat_as_per_new_instruction=($net_total*0.05);
						}
					
					$grand_total_new_instruction=$net_total+$vat_as_per_new_instruction;
					}
					else
					{
					$vat_as_per_new_instruction=$quotation_data[0]->q_total_vat;

					$grand_total_new_instruction=$quotation_data[0]->q_grand_total;
					}
						
						$html.='<tr>
						<td colspan="6" align="center">NET TOTAL </td>
						<td colspan="3" align="center">'.number_format((float)$net_total, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';
					
					$html.='<tr>
						<td colspan="6" align="center">Total VAT (5%)</td>
						<td colspan="3" align="center">'.number_format((float)$vat_as_per_new_instruction, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';
						
					
					$html.='<tr>
						<td colspan="6" align="center">GRAND TOTAL </td>
						<td colspan="3" align="center">'.number_format((float)$grand_total_new_instruction, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';

					if ($quotation_data[0]->q_currency_type=='sr')
          {  
            
            	$html.='<tr>
						<td colspan="3" align="center">GRAND TOTAL in words ('.$quotation_data[0]->q_currency_type.')</td>
						<td colspan="6" align="center">'.$this->numbertowordconvertsconverksa->convert_number($grand_total_new_instruction).' only </td>
				   	</tr>';


          }
          else if($quotation_data[0]->q_currency_type=='usd') 
          { 
            	$html.='<tr>
						<td colspan="3" align="center">GRAND TOTAL in words ('.$quotation_data[0]->q_currency_type.')</td>
						<td colspan="6" align="center">'.$this->numbertowordconvertsconver->convert_number($grand_total_new_instruction).' only </td>
					</tr>';

               

          }
          else 
          {
                	$html.='<tr>
						<td colspan="3" align="center">GRAND TOTAL in words ('.$quotation_data[0]->q_currency_type.')</td>
						<td colspan="6" align="center">'.$this->numbertowordconvertsconver->convert_number($grand_total_new_instruction).' only </td>
					</tr>';
          }
					

}              
				$html.='</table>';
				
if(empty($as_pi))
{
				$html.='
				<small><b>Disclaimer: This document is for quotation purpose only and does not guarantee stock availability.</b></small><br/>
				Notes:';
}				
				$html.='<div style="padding-left:2%;">
<p>1- Delivery :  '.$quotation_data[0]->q_delivery_time.' </p>';

/*
if($quotation_data[0]->q_payment_type=="Advance")
{
$html.='<p>2- Payment : '.$quotation_data[0]->q_adv_pay_amount.'% as '.$quotation_data[0]->q_payment_type.'  within '.$quotation_data[0]->q_payment_days.' </p>';
}
else
{
if(!empty($quotation_data[0]->q_payment_days))
$html.='<p>2- Payment : '.$quotation_data[0]->q_payment_type.'  within '.$quotation_data[0]->q_payment_days.' </p>';
else
$html.='<p>2- Payment : '.$quotation_data[0]->q_payment_type.'</p>';
}*/
$html.='<p>2- Payment : '.$quotation_data[0]->q_payment_notes.'</p>';


$html.='<p>3- Offer validity : '.$quotation_data[0]->q_offer_validity.' days.</p> ';
if(!empty($quotation_data[0]->q_add_notes))
				{
			 $html.='<p>Additional Notes :'.$quotation_data[0]->q_add_notes.'</p>';
				}


 $html.='<h5 style="color:red"> Note :Quotation Only not valid for payment please request for invoice before payment </h5> ';
$html.='<h5 style="color:red;" align=right > ملاحظة:عرض سعر فقط غير صالح للدفع الرجاء طلب الفاتورة قبل الدفع </h5>';
$html.='</div>';
  
$html.='			<table border="0" width="100%">
				<tr >
					<td ><div class="regards_style">Best Regards,<p>'.$logged_users_details[0]->ed_name.'</p>
<p>'.$logged_users_details[0]->ed_pos.'</p>
<p>'.$logged_users_details[0]->ed_mob.' '.$logged_users_details[0]->log_email.'</p></div></td>';
					
					if($quotation_data[0]->show_stamp=="1")
					{
						if($quotation_data[0]->q_approval_stamp_sign=="2")
						{
					$html.='<td style="text-align:center;"  rowspan="3">';
						if(!empty($authorized_signture[0]->qs_file))
	$html.='<img src="'.base_url('uploads/quot_signature/berry_bldg_si_stamp.jpg').'" width="120" height="120">';
					$html.='</td>';
						}
					}
					
				$html.='</tr>
				</table>';
	
			$html.='   </div>
			          </body>
					</html>';
// print_r($html);
// exit(0);
					//echo $html;
//$header_image=base_url('admin_assets/header_pdf.png');
 $pdfFilePath = $quotation_data[0]->q_ref_no.'.pdf';
	  
		  $mpdf = new \Mpdf\Mpdf();
	   $mpdf->autoScriptToLang = true;
		$mpdf->autoLangToFont = true;
    $mpdf->autoArabic=true;
 


		//  $this->load->library('m2_pdf');
	// 	    $mpdf->SetHeader('<img src="https://ad.birigroup.ae/berry_header.png">');
    //  $mpdf->SetFooter('<img src="https://ad.birigroup.ae/berry_footer.png">');
		$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">');
		$mpdf->SetFooter('<img src="'.base_url("berry_footer.png").'">');
	
  
		   $mpdf->WriteHTML($stylesheet,1);
		   $mpdf->AddPage('', // L - landscape, P - portrait 
        '', '', '', '',
        5, // margin_left
        5, // margin right
       45, // margin top
       30, // margin bottom
        0, // margin header
        0); // margin footer
        
  //         //$this->m2_pdf->pdf->SetDirectionality('rtl');
  //       
            
            
	 //     $this->m2_pdf->pdf->WriteHTML($html,2);
	     
	 //     //save in folder
		// $this->m2_pdf->pdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");

  // 		$this->m2_pdf->pdf->Output($pdfFilePath,'I');
//$mpdf->SetDirectionality('rtl');		   
 $mpdf->WriteHTML($html,2);

 $mpdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");
 $mpdf->Output($pdfFilePath,'D');
  		
  		//echo $html;
}





function generate_localproforma($quot_id,$as_pi=null)
{

//$quot_id=$this->input->post('quotation_id');

 $quotation_data= $this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$quot_id));  
         
$prd_details=explode('|#|',$quotation_data[0]->q_prd_id);
$qty_details=explode('|#|',$quotation_data[0]->q_prd_qnty);
$unt_price_details=explode('|#|',$quotation_data[0]->q_prd_price);
$vat_pre_details=explode('|#|',$quotation_data[0]->q_prd_vat);
$tot_price_details=explode('|#|',$quotation_data[0]->q_prd_tot);
$extra_prd_details=explode('|#|',$quotation_data[0]->q_remarks);


foreach($prd_details as $index=>$pd)
{
	//print_r($pd);
	
	$prd_table_data[]=$this->tm->get_data('products',array('pid'=>$pd));
	
}
$authorized_signture=$this->Admin_model->get_data('quotation_signature',array('qs_user_id'=>$this->session->userdata['user']['username']));

$logged_users_details=$this->Admin_model->join_qry('login_credentials','employee_details','ed_login_id','log_id',array('log_uname'=>$quotation_data[0]-> q_user_id),('employee_details.*,login_credentials.*'));

//print_r($prd_table_data);
//print_r($logged_users_details);

$stylesheet = file_get_contents('style_mpdf.css');
	$html='<!doctype html>
<head>

</head>

    <body> ';
	  
	 
				$html.='
				<div class="contentprof">
				<div class="content">
				<table border="0" width="100%">
				<tr >';
				if(!empty($as_pi))
$html.='<td align="left" rowspan="4"><h1 style="text-align:left">PRO FORMA INVOICE</h1></td>';
					else
					$html.='<td align="left" rowspan="3"><h1 style="text-align:left">SALES QUOTATION</h1></td>';
					
					$html.='<td style="text-align:right;" align="right">
						<div style="text-align:right;">
							<p align="right" style="text-align:justify;">Issued by: '.$logged_users_details[0]->ed_name.'</p>
						
							
							<p align="right" style="text-align:justify;">Document No: '.$quotation_data[0]->q_ref_no.'</p>
							
							<p align="right" style="text-align:justify;">Date: '.$quotation_data[0]->q_date.'</p>';
						if(!empty($as_pi))
						$html.='<p align="right" style="text-align:justify;">Our TRN: 100301351100003</p>';
						
						$html.='</div>
					</td>
				</tr>
				
				
				</table>
				
				
				
				</div>';

			 
				$html.='<table align="center" class="cusotmer_info"  width="80%" border="1">';
				
				$html.='<tr>
					<td>To: '.$quotation_data[0]->q_cust_comp.'</td>
					<td>Attn: '.$quotation_data[0]-> q_cust_name.'</td>
				</tr>';
				if(!empty($as_pi))
				{
					$html.='<tr>
					<td>TRN Number: '.$quotation_data[0]->q_pi_trn.'</td>
					<td>LPO: '.$quotation_data[0]-> q_pi_po_number.'</td>
				</tr>';
				}
				$html.='<tr>
					<td>Email: '.$quotation_data[0]->q_cust_email.'</td>
					<td>Tel: '.$quotation_data[0]->q_cust_landline.'</td>
				</tr>
				<tr>
					<td>Subj:'.$quotation_data[0]->q_sub.' </td>
					<td>Mobile: '.$quotation_data[0]-> q_cust_mob.'</td>
				</tr>';
				
				
				
				$html.='</table>


				<table align="center" class="prd_info"  width="80%" border="1">
					<tr class="prd_head" >
					 <td align="center">No.#</td>
					 <td align="center">Picture</td>
					 <td align="center">Model No.</td>
					 <td align="center">Product Description</td>
					 
					 <td align="center" width="10%">Qty</td>
					 <td align="center">Price Excl.VAT</td>
					 <td align="center">Total</td>
					  <td align="center">VAT(5 %)</td>
					</tr>';
$i=1;
$total_sum_prd='0';
$total_vat_sum_prd='0';
$total_discount_sum_prd='0';
					foreach($prd_table_data as $index=>$pd3)
					{
						
						if(empty($pd3[0]->p_prd_img))
						{
							$filename="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpeg";
						 if (file_exists($filename)) {
						 	$img_path=$filename;
							} else {
							$img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpg";
						    }
						}
						else
						{
							$first_img_prd=explode(',',$pd3[0]->p_prd_img);
							if(!empty($first_img_prd[0]))
						 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
						 	
						 	else
						 	$img_path="https://birigroup.com/uploads/prd_images/".$pd3[0]->p_prd_img."";
						 	
						}
						
						//print_r($img_path);
						$pname=explode('|~~|',$pd3[0]->pname);
						if(!empty($pname[0]))
						{
							$prd_names=explode(',',$pname[0]);
							$product_name=$prd_names[0];
							//$product_name=$pname[0];
						}
						else
						{
						 	$pname=explode(',',$pd3[0]->pname);
						 	$product_name=$pname[0];
						}
						//$product_name=$pname;
						
$total_sum_prd=$total_sum_prd+$tot_price_details[$index];

$total_vat_sum_prd=$tot_price_details[$index]+$total_vat_sum_prd;


					$html.='<tr style="text-align:center;">
					 <td align="center">'.$i++.'</td>';

					 if(!empty($img_path))
					 $html.='<td align="center"><img src="'.$img_path.'" width="100" height="100"></td>';
					else
						 $html.='<td align="center">'.$product_name.'</td>';

					 $html.='<td align="center">'.$pd3[0]->pcode.'</td>';
					 
					if( (!empty($pd3[0]->p_dimenstion)) && (!empty($pd3[0]->p_material)) && (!empty($pd3[0]->p_wgt)) )
						{
						
						//echo "in if<br/>";
						 $html.='<td>Name:'.$product_name.'<br/>Brand:'.$pd3[0]->pcat.'<br/>';
						if(!empty($pd3[0]->p_dimenstion))
						 $html.='Dimension:'.$pd3[0]->p_dimenstion.'<br/>';
						 if(!empty($pd3[0]->p_wgt))
							$html.='Weight:'.$pd3[0]->p_wgt.'<br/>';
							if(!empty($pd3[0]->p_material))
							$html.='Material:'.$pd3[0]->p_material.'<br/>';
							
							if(!empty($extra_prd_details[$index]))
						$html.=$extra_prd_details[$index];
						
							$html.='</td>';
						}
						elseif(!empty($pd3[0]->p_desc_2))
						{
						//echo "in elseif<br/>";
						$html.='<td>'.$pd3[0]->p_desc_2.'<br/>';
						
						if(!empty($extra_prd_details[$index]))
						$html.=$extra_prd_details[$index];
						
						$html.='</td>';
						}
						else
						{
						//echo "in else<br/>";						
					 $html.='<td>Name:'.$product_name.'<br/>
						Brand:'.$pd3[0]->pcat.'<br/>';
						
						if(!empty($extra_prd_details[$index]))
						$html.=$extra_prd_details[$index];
						
						$html.='</td>';
						}
						
					
					  $html.='
					 
					  <td align="center">'.$qty_details[$index].'</td>
					 <td align="center">'.number_format((float)$unt_price_details[$index], 2, '.', '').'</td>
					 <td align="center">'.number_format((float)$tot_price_details[$index], 2, '.', '').'</td>
					 <td align="center">'.number_format((float)$vat_pre_details[$index], 2, '.', '').'</td>
					</tr>';
				}
				
				$dicount_per=$quotation_data[0]->q_discount_per;

$total_discount_sum_prd=$total_sum_prd-((($dicount_per/100)*$total_sum_prd));
if($quotation_data[0]->q_currency_type =='usd')	
{
	$fixed_rate='3.67250';
}		
elseif($quotation_data[0]->q_currency_type =='sr')
{
	$fixed_rate='0.979333';
}
else
{
	$fixed_rate='1.0';
}

if($quotation_data[0]->show_total=="1")
{

					$html.='<tr>
						<td colspan="6" align="center">TOTAL Price </td>
						<td colspan="3" align="center">'.number_format((float)$quotation_data[0]->q_total_price, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';
					if(!empty($quotation_data[0]->q_discount_per))
					{
					$dic_price=$quotation_data[0]->q_discount_per;
					$html.='<tr>
						<td colspan="6" align="center">Discount Price</td>
						<td colspan="3" align="center">'.number_format((float)$quotation_data[0]->q_discount_per, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';
					}
					else
					{
					$dic_price=0;
					}
					
					if(!empty($quotation_data[0]->q_additional_charge))
					{
					$additional_price=$quotation_data[0]->q_additional_charge;
					$html.='<tr>
						<td colspan="6" align="center">Additional Charges </td>
						<td colspan="3" align="center">'.number_format((float)$quotation_data[0]->q_additional_charge, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';
					
					}
					else
					{
					$additional_price=0;
					}
					
					$net_total=(($quotation_data[0]->q_total_price+$additional_price)-$dic_price);
					if(!empty($quotation_data[0]->q_discount_per))
					{
					$vat_as_per_new_instruction=($net_total*0.05);
					$grand_total_new_instruction=$net_total+$vat_as_per_new_instruction;
					}
					else
					{
					$vat_as_per_new_instruction=$quotation_data[0]->q_total_vat;
					$grand_total_new_instruction=$quotation_data[0]->q_grand_total;
					}
						
						$html.='<tr>
						<td colspan="6" align="center">NET TOTAL </td>
						<td colspan="3" align="center">'.number_format((float)$net_total, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';
					
					$html.='<tr>
						<td colspan="6" align="center">Total VAT (5%)</td>
						<td colspan="3" align="center">'.number_format((float)$vat_as_per_new_instruction, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';
						
					
					$html.='<tr>
						<td colspan="6" align="center">GRAND TOTAL </td>
						<td colspan="3" align="center">'.number_format((float)$grand_total_new_instruction, 2, '.', '').' '.$quotation_data[0]->q_currency_type.'</td>
					</tr>';

					
						$html.='<tr>
						<td colspan="3" align="center">GRAND TOTAL in words</td>
						<td colspan="6" align="center">'.$this->numbertowordconvertsconver->convert_number($grand_total_new_instruction).' only </td>
					</tr>';

}              
				$html.='</table>';
				
if(empty($as_pi))
{
				//$html.='
				//<small><b>Disclaimer: This document is for quotation purpose only and does not guarantee stock availability.</b></small><br/>
				//Notes:';
}				
				$html.='<div style="padding-left:2%;">
<p>1- Delivery :  '.$quotation_data[0]->q_delivery_time.' </p>';

/*
if($quotation_data[0]->q_payment_type=="Advance")
{
$html.='<p>2- Payment : '.$quotation_data[0]->q_adv_pay_amount.'% as '.$quotation_data[0]->q_payment_type.'  within '.$quotation_data[0]->q_payment_days.' </p>';
}
else
{
if(!empty($quotation_data[0]->q_payment_days))
$html.='<p>2- Payment : '.$quotation_data[0]->q_payment_type.'  within '.$quotation_data[0]->q_payment_days.' </p>';
else
$html.='<p>2- Payment : '.$quotation_data[0]->q_payment_type.'</p>';
}*/
$html.='<p>2- Payment : '.$quotation_data[0]->q_payment_notes.'</p>';


$html.='<p>3- Offer validity : '.$quotation_data[0]->q_offer_validity.' days.</p> ';
if(!empty($quotation_data[0]->q_add_notes))
				{
			 $html.='<p>Additional Notes :'.$quotation_data[0]->q_add_notes.'</p>';
				}


 
$html.='</div>';
  
$html.='			<table border="0" width="100%">
				<tr >
					<td ><div class="regards_style">Best Regards,<p>'.$logged_users_details[0]->ed_name.'</p>
<p>'.$logged_users_details[0]->ed_pos.'</p>
<p>'.$logged_users_details[0]->ed_mob.' '.$logged_users_details[0]->log_email.'</p></div></td>';
					
					if($quotation_data[0]->show_stamp=="1")
					{
						if($quotation_data[0]->q_approval_stamp_sign=="2")
						{
					$html.='<td style="text-align:center;"  rowspan="3">';
						if(!empty($authorized_signture[0]->qs_file))
	$html.='<img src="'.base_url('uploads/quot_signature/berry_bldg_si_stamp.jpg').'" width="120" height="120">';
					$html.='</td>';
						}
					}
					
				$html.='</tr>
				</table>';
	
			$html.='   </div>
			          </body>
					</html>';

					//echo $html;
//$header_image=base_url('admin_assets/header_pdf.png');
 $pdfFilePath = $quotation_data[0]->q_ref_no.'.pdf';
	  
		  $mpdf = new \Mpdf\Mpdf();
	   $mpdf->autoScriptToLang = true;
		$mpdf->autoLangToFont = true;
    $mpdf->autoArabic=true;
 
		//  $this->load->library('m2_pdf');
		$mpdf->SetHeader('<img src="'.base_url("berry_header.png").'">');
		$mpdf->SetFooter('<img src="'.base_url("berry_footer.png").'">');
		
		   $mpdf->WriteHTML($stylesheet,1);
		   $mpdf->AddPage('', // L - landscape, P - portrait 
        '', '', '', '',
        5, // margin_left
        5, // margin right
       45, // margin top
       30, // margin bottom
        0, // margin header
        0); // margin footer
        
  //         //$this->m2_pdf->pdf->SetDirectionality('rtl');
  //       
            
            
	 //     $this->m2_pdf->pdf->WriteHTML($html,2);
	     
	 //     //save in folder
		// $this->m2_pdf->pdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");

  // 		$this->m2_pdf->pdf->Output($pdfFilePath,'I');
//$mpdf->SetDirectionality('rtl');		   
 $mpdf->WriteHTML($html,2);
 $mpdf->Output("./uploads/mpdf_files/".$pdfFilePath, "F");
 $mpdf->Output($pdfFilePath,'D');
  		
  		//echo $html;
}





function send_mail_quotation($quot_id,$as_pi=null)
{
        $this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';

         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;
         
          $this->email->initialize($config);
          
          $quotation_data= $this->Admin_model->get_data('qoutattion_entry',array('q_id'=>$quot_id));  
         
          $this->email->from('noreply@birigroup.com','Biri Group');
         $this->email->to($this->session->userdata['user']['user_email']);
		// $this->email->to('support@birigroup.com');
       
        if(empty($as_pi))
		  $this->email->subject('New Quotation :'.$quotation_data[0]->q_ref_no);
		  else
		  $this->email->subject('Pro Forma Invoice :'.$quotation_data[0]->q_ref_no);
		   	
		    $this->email->attach("./uploads/mpdf_files/".$quotation_data[0]->q_mpdf_file);	
		    if(empty($as_pi))
		  $msg="QUOTATION Berry Building Materials- attached";
		else
		{
			$msg="Pro Forma Invoice Berry Building Materials- attached";
		}
        
		 $this->email->message($msg);

	if(empty($as_pi))
	{	
         if($this->email->send())
         {
           $this->session->set_flashdata('success', 'Mail send Successfully');
		redirect('list-quotation');
		}
         else
         {
          $this->session->set_flashdata('errors', $this->email->print_debugger());
           redirect('list-quotation');
         } 
    }
    else
    {
    	 if($this->email->send())
         {
           $this->session->set_flashdata('success', 'Mail send Successfully');
		redirect('list-porforma');
		}
         else
         {
          $this->session->set_flashdata('errors', $this->email->print_debugger());
           redirect('list-porforma');
         } 
    }      
}

function price_list()
{
	if(logged_in())
	{


      $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='price-list')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {








		$data['prds']=$this->tm->get_data('products',array('p_sts'=>'1'));
		$this->load->view('admin/sales/price_list',$data);

}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


	}
}

function get_price_item()
{



if(logged_in())
	{

   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
         $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {
            if ($page_cred[$i]=='get_price_item')
            {
               $excist=true;
               $i=$cred_count;
            }   

           else
                {$excist=false;}

        }
       if ($excist) {


$data['prds']=$this->tm->get_data('products',array('p_sts'=>'1'));
$item_id=$this->input->post('price_list');
$data['option_choosed_form']=$this->input->post('price_list');
$data['result_data']=$this->tm->get_data('products',array('pid'=>$item_id));

$data['stock_data']=$this->Admin_model->get_data('product_stock',array('ps_prd_code'=>$data['result_data'][0]->pcode));
$sub_category_data=$data['result_data'][0]->p_website_cat2;
$data['more_this_cat']=$this->tm->get_data('products',array('p_website_cat2'=>$sub_category_data));

foreach($data['more_this_cat'] as $dt)
{
	$data['sub_cat_stock'][]=$this->Admin_model->get_data('product_stock',array('ps_prd_code'=>$dt->pcode));
}
$this->load->view('admin/sales/price_list',$data);

}

 else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
        } 

}


}



function quotation_sts($sts,$qout_id)
{
$sts_value='';
switch($sts)
{
case 1:
$sts_value='Sent to Customer';
break;

case 2:
$sts_value='1st follow up';
break;

case 3:
$sts_value='2nd follow up';
break;

case 4:
$sts_value='3rd follow up';
break;

case 5:
$sts_value='Converted to PI';
break;

default:
$sts_value='';
break;

}
$data_updt=array(
'q_current_status'=>$sts_value,
);
$this->Admin_model->update_data('qoutattion_entry',$data_updt,array('q_id'=>$qout_id));
$data_activity=array(
		'act_function'=>'Status Changed',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_quot_id'=>$qout_id,
		'act_status'=>$sts_value,
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);

$this->session->set_flashdata('success', 'Quotation status Successfully updated');
redirect('list-quotation');
}

function submit_quotation_sts()
{
$quot_sts_id=$this->input->post('qtn_sts_id');

$hold_date=$this->input->post('hold_date');
if(!empty($hold_date))
{
$hold_date11=explode('/',$hold_date);
			$month2=$hold_date11[0];
			$date2=$hold_date11[1];
			$year2=$hold_date11[2];
$new_formated_date2=$year2.'-'.$month2.'-'.$date2;
}
else
{
$new_formated_date2='';
}

$data_updt=array(
'q_current_status'=>$this->input->post('qtn_sts_type'),
'lost_note'=>$this->input->post('reason_lost'),
'sts_hold_date'=>$new_formated_date2,
);

$this->Admin_model->update_data('qoutattion_entry',$data_updt,array('q_id'=>$quot_sts_id));

$data_activity=array(
		'act_function'=>'Status Changed',
		'act_user'=>$this->session->userdata['user']['username'],
		'act_quot_id'=>$quot_sts_id,
		'act_status'=>$this->input->post('qtn_sts_type'),
		'act_date'=>get_date(),
		'act_time'=>get_time(),
		'act_date_time'=>get_date_time(),
		'act_notification_sts'=>'1',
		'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$data_activity);
				
$this->session->set_flashdata('success', 'Quotation status Successfully updated');
redirect('list-quotation');
}

function quot_history($qot_id)
{
$data['result']=$this->Admin_model->get_data('activities',array('act_quot_id'=>$qot_id));
//print_r($data['result']);
$this->load->view('admin/sales/history',$data);
}

function get_customer_details()
{
	$cust_id=$this->input->post('customer_id');
	$result=$this->Admin_model->get_data('sales_customer_entry',array('sca_id'=>$cust_id));
	$data=array(
		'sca_cust_name'=>$result[0]->sca_cust_name,
		'sca_cust_company'=>$result[0]->sca_cust_company,
		'sca_cust_mobile'=>$result[0]->sca_cust_mobile,
		'sca_cust_email'=>$result[0]->sca_cust_email,
		'sca_cust_landline'=>$result[0]->sca_cust_landline,
	);
	echo json_encode($data);
}

function issue_performa_invoice($quot_id)
{
	$this->Admin_model->update_data('qoutattion_entry',array('q_pi'=>'1'),array('q_id'=>$quot_id));
	redirect('list-porforma');	
}

function list_performa()
{
	if(logged_in())
	{
      $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
         $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {//for issue oroforma for sales team
            if ($page_cred[$i]=='list-porforma')
            {
               $excist=true;
               $i=$cred_count;
            }   

           else
                {$excist=false;}

        }
       if ($excist) {



		if($this->session->userdata['user']['main_dept']=="Sales")
		{
			if($this->session->userdata['user']['user_desig']=="Team-lead")
 		 $data['result']= $this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1','q_pi'=>'1'),'','','q_id','DESC');
 		else
 		$data['result']= $this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1','q_pi'=>'1','q_user_id'=>$this->session->userdata['user']['username']),'','','q_id','DESC');			
 		}
		 elseif($this->session->userdata['user']['main_dept']=="Main")
		 {
		  $data['result']= $this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1','q_pi'=>'1'),'','','q_id','DESC');
		 }
		 else
		 {
		 	$data['result']= $this->Admin_model->get_data('qoutattion_entry',array('q_sts'=>'1','q_user_id'=>$this->session->userdata['user']['username']),'','','q_id','DESC');
		 }
	// $data['result']=$this->Admin_model->get_data('qoutattion_entry',array('q_pi'=>'1','q_sts'=>'1'),'','','q_id','DESC');
	
	$this->load->view('admin/sales/list_performa',$data);

}

 else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
        } 

	}
}

function extra_details_performa($qid)
{
	$data['details']=$this->Admin_model->get_data('qoutattion_entry',array('q_pi'=>'1','q_sts'=>'1','q_id'=>$qid));
	$data['port']=$this->Admin_model->get_data('country_ports',array('psts'=>'1'));
	$data['country']=$this->Admin_model->get_data('country_val',array('status'=>'1'));
	if(!empty($qid))
	{
		$country_orgin=$data['details'][0]->q_country_loading;
		$country_final=$data['details'][0]->q_country_discharge;

		if(!empty($country_orgin))
		{
			$country_name1=$this->Admin_model->get_data('country_val',array('country_id'=>$country_orgin));
		$sql1=$this->db->query("SELECT * FROM country_ports where pcountry like '%".$country_name1[0]->name."%' ");
		$data['port_org']=$sql1->result_array();
		}

		if(!empty($country_final))
		{
			$country_name2=$this->Admin_model->get_data('country_val',array('country_id'=>$country_final));
		$sql2=$this->db->query("SELECT * FROM country_ports where pcountry like '%".$country_name2[0]->name."%' ");
		$data['port_final']=$sql2->result_array();
		}
	}
	$this->load->view('admin/sales/extra_details_porforma',$data);
}

function get_port_details()
{
	$country_id=$this->input->post('country_id');
	$type=$this->input->post('type');
	$country_name=$this->Admin_model->get_data('country_val',array('country_id'=>$country_id));
	$sql2=$this->db->query("SELECT * FROM country_ports where pcountry like '%".$country_name[0]->name."%' ");
	$data=$sql2->result_array();
	//$data=$this->Admin_model->get_data('country_ports',array('pcountry'=>$country_name[0]->name));
	if($type=="orgin")
	$html='<select data-plugin-selectTwo  class="form-control" name="q_port_load"  ><option >Choose</option>';
	else
	$html='<select data-plugin-selectTwo  class="form-control" name="q_port_final"  ><option >Choose</option>';
		foreach($data as $d)
		{
		$html.="<option value=".$d['pid'].">".$d['pname']."</option>";
        }
		$html.='</select>';
		echo $html;
	//echo json_decode($data);
}

function update_product_stock()
{
	if(logged_in())
	{

    $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
         $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
        {
            if ($page_cred[$i]=='update-product-stock-1')
            {
               $excist=true;
               $i=$cred_count;
            }   

           else
                {$excist=false;}

        }
       if ($excist) {

		$data['prd_stock']=$this->Admin_model->get_data('product_stock');
		$this->load->view('admin/sales/update_product_stock',$data);

}

 else{
            //echo false;
             $this->session->unset_userdata('user', null);
                redirect('login','refersh');
        } 


	}
}

function excel_download_sample_update_stock()
{
	if(logged_in())
	{
	  $this->load->library("excel");
	  $object = new PHPExcel();
	  $object->setActiveSheetIndex(0);

		$object->getActiveSheet()->setCellValue('A1', 'Item Code');
         $object->getActiveSheet()->setCellValue('B1', 'DXB Quantity');
         $object->getActiveSheet()->setCellValue('C1', 'RAK Quantity');
         
        $prd_ids= $this->tm->get_data('products',array('p_sts'=>'1'));

 		$ex_row=2;
		foreach($prd_ids as $index_p=>$p1)
		{
			$object->getActiveSheet()->setCellValue('A' . $ex_row, $p1->pcode);						
		    $object->getActiveSheet()->setCellValue('B' . $ex_row,'');
	        $object->getActiveSheet()->setCellValue('C' . $ex_row,'');
	       $ex_row++;
		}

		 $object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
		  header('Content-Type: application/vnd.ms-excel');
		  header('Content-Disposition: attachment;filename="Product_stock_update_'.get_date().'.xls"');
		  $object_writer->save('php://output');	
	}
}

function submit_product_update_stock()
{
		$flag = 0;
		
		$this->load ->library('excel');
		
		$path='./uploads/stock_update_1/';
		if (!is_dir($path)) 
            {
            	mkdir('./'.$path, 0777, TRUE);
	   }
		$config['upload_path'] = $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;	
		
		$this->load->library('upload', $config);
		$this->upload->initialize($config);

		if (!$this->upload->do_upload('userfile')) 
		{
			$error = array('error' => $this ->upload -> display_errors());
			$this ->session -> set_flashdata('errors', $error['error']);
			redirect("update-product-stock-1", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this ->upload -> data());
		}

		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
	try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		}catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);

			$data23=array(
			'pse_file_name'=>$import_xls_file,
			'pse_date'=>get_date(),
			'pse_time'=>get_time(),
			);
			$insert_id=$this->Admin_model->insert_data("product_stock_excel", $data23);		
			  $this->Admin_model->truncate_table('product_stock');
		for ($i =2; $i <= $arrayCount; $i++) 
		{
			$prd_code = trim($allDataInSheet[$i]['A']);	
			
			if((!empty($allDataInSheet[$i]['B'])))
			$prd_qty_dxb = trim($allDataInSheet[$i]['B']);		
			else
			$prd_qty_dxb ='0';

			if((!empty($allDataInSheet[$i]['C'])))
			$prd_qnty_rak = trim($allDataInSheet[$i]['C']);
			else
			$prd_qnty_rak ='0';

			if(!empty($prd_code))
			{
				$fetchData = array(
					'ps_prd_code'=>$prd_code,
                   	'ps_dxb_qnty'=>$prd_qty_dxb,
                   	'ps_rak_qnty'=>$prd_qnty_rak,
                   	'ps_date'=>get_date(),
                   	'ps_time'=>get_time(),
                   	'ps_sts'=>'1',
                   	'ps_excel_id'=>$insert_id
                  	);

				$excel_id_2=$this->Admin_model->insert_data("product_stock",$fetchData);
			}
		}

		if ($excel_id_2)
			
				
		$this ->session-> set_flashdata('success', 'Imported Successfully');
		
		else

			$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		redirect("update-product-stock-1", "refresh");
}


function raise_stock_ticket($prd_id)
{
	if(logged_in())
	{
		if(!empty($prd_id))
		{
			$data['products']=$this->tm->get_data('products',array('p_sts'=>'1','pid'=>$prd_id));

		$everyday_limit=$this->Admin_model->get_data('ticket_stock',array('ts_date'=>get_date(),'ts_user_id'=>$this->session->userdata['user']['username']));/////everyday limit to raise ticket for each sales person should be less than 2//////

		$current_date=date('Y-m-d');
		$current_date_exploded=explode('-',$current_date);

		$check_same_prd_for_month=$this->Admin_model->get_data('ticket_stock',array('ts_year'=>$current_date_exploded[0],'ts_month'=>$current_date_exploded[1],'ts_user_id'=>$this->session->userdata['user']['username'],'ts_prd_id'=>$prd_id));////only one time per month for same product, allowed to raise ticket////////

		if( (count($everyday_limit)<=2) && (empty($check_same_prd_for_month)) )
			{
				$this->load->view('admin/sales/raise_stock_ticket',$data);
			}
		else
			{
				if(!empty($check_same_prd_for_month))
				$this->session-> set_flashdata('errors','You have submitted this product earlier this month. Wait till next month');	
				else
				$this->session-> set_flashdata('errors', 'You have already submitted two tickets in this day.Wait for next day.');
				redirect('all-tickets');
			}
		}
	}
}

function submit_ticket_stock()
{
	$ticket_id=$this->input->post('ticket_id');
	$prd_id=$this->input->post('ts_prd_id');
	$ticket_date=get_date();
	$ticket_exploded=explode('-', $ticket_date);

	if(!empty($this->input->post('ts_ticket_reply')))
	{
		$ticket_reply=$this->input->post('ts_ticket_reply');
		$ticket_reply_date=get_date();
		$ticket_reply_time=get_time();
		$ticket_response_sts='1';
    $ticket_created_by=$this->input->post('user_edit_session_id');
	 $ticket_replied_by=$this->session->userdata['user']['username'];
	}
	else
	{
		$ticket_reply='';
		$ticket_reply_date='';
		$ticket_reply_time='';
		$ticket_response_sts='0';
		 $ticket_created_by=$this->session->userdata['user']['username'];
		 $ticket_replied_by='';
	}

	$data=array(
		'ts_user_id'=>$ticket_created_by,
		'ts_replied_user_id'=>$ticket_replied_by,
		'ts_subject'=>$this->input->post('ts_subject'),
		'ts_prd_id'=>$this->input->post('ts_prd_id'),
		'ts_details'=>$this->input->post('ts_details'),
		'ts_sts'=>'1',
		'ts_ticket_action'=>'0',
		'ts_date'=>get_date(),
        'ts_month'=>$ticket_exploded[1],
        'ts_year'=>$ticket_exploded[0],
        'ts_time'=>get_time(),
        'ts_ticket_reply'=>$ticket_reply,
        'ts_ticket_reply_date'=>$ticket_reply_date,
        'ts_ticket_reply_time'=>$ticket_reply_time,
        'ts_ticket_action'=>$ticket_response_sts,
	);
	if(empty($this->input->post('ticket_id')))
	{
		$insert_id=$this->Admin_model->insert_data('ticket_stock',$data);
	}
	else
	{
		$this->Admin_model->update_data('ticket_stock',$data,array('ts_id'=>$ticket_id));
	}	
	if(!empty($ticket_id))
	$email_data=$this->email_ticket_reply_warehouse($ticket_id);
	else
	$email_data=$this->email_ticket_warehouse($insert_id);
}

function setting()
    {
     $this->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;
         return $config;        
    }

function email_ticket_warehouse($insert_id)
{
	$this->email->initialize($this->setting());
	    $this->email->from('noreply@birigroup.com','Biri Group');
   
    $ticket_details=$this->Admin_model->get_data('ticket_stock',array('ts_id'=>$insert_id));
     $prd_details=$this->tm->get_data('products',array('pid'=>$ticket_details[0]->ts_prd_id));
        //$this->email->to('support@birigroup.com');
        $this->email->to('berrywarehouse@birigroup.com');
        $this->email->subject('Issue in Stock Quantity : Ticket #'.$insert_id);
        $msg="Hi,<br/>";
       $msg.='You have a new ticket raised for product :'.$prd_details[0]->pcode.'<br/>';
        $msg.='Ticket subject :<br/>';
     $msg.=$ticket_details[0]->ts_subject.'<br/>';
       $msg.='Below are the ticket details <br/>';
     $msg.=$ticket_details[0]->ts_details.'<br/>';

     $msg.='<a href="http://ad.birigroup.ae/reply_ticket/'.$insert_id.'">Click here to reply to this ticket</a> <br/><br/>';
        $msg.="<b>NOTE:Please make sure that you will reply to this ticket within 24 hours, else this ticket will be send to Management for further proceedings. </b><br/><br/>";        
         $msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
        $this->email->message($msg);

         if($this->email->send())
         {
			$this->session->set_flashdata('success', 'Mail send successfully to warehouse.');
         }
          else
         {
         	$this->session->set_flashdata('errors', 'Failed to send mail to warehouse. Please try again later.');
            //echo $this->email->print_debugger();
         } 
         	redirect("raise_stock_ticket/".$ticket_details[0]->ts_prd_id."", "refresh"); 
}

function email_ticket_reply_warehouse($insert_id)
{
	$this->email->initialize($this->setting());
	    $this->email->from('noreply@birigroup.com','Biri Group');
   
    $ticket_details=$this->Admin_model->get_data('ticket_stock',array('ts_id'=>$insert_id));
     $prd_details=$this->tm->get_data('products',array('pid'=>$ticket_details[0]->ts_prd_id));
     $user_email=$this->Admin_model->get_data('login_credentials',array('log_uname'=>$ticket_details[0]->ts_user_id));

        $this->email->to($user_email[0]->log_email);
        $this->email->subject('Reply to Issue in Stock Quantity : Ticket #'.$insert_id);
      $msg="Hi,<br/>";
      $msg.='You have a new reply for the ticket raised for product code '.$prd_details[0]->pcode.'. Below are the details :<br/>';
      $msg.='Ticket subject :<br/>';
      $msg.=$ticket_details[0]->ts_subject.'<br/>';
      $msg.='Ticket details :<br/>';
     $msg.=$ticket_details[0]->ts_details.'<br/>';
     $msg.='Ticket reply :<br/>';
     $msg.=$ticket_details[0]->ts_ticket_reply.'<br/>';

    $msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
        $this->email->message($msg);

         if($this->email->send())
         {
			$this->session->set_flashdata('success', 'Reply send successfully.');
         }
          else
         {
         	$this->session->set_flashdata('errors', 'Failed to send reply. Please try again later.');
            //echo $this->email->print_debugger();
         } 
		 redirect('all-tickets');
         //	redirect("reply_ticket/".$insert_id."", "refresh"); 
}

function reply_ticket($ticket_id)
{
	$url_array['url']=array(
			'email_ticket_reply_url'=>'reply_ticket/'.$ticket_id
		);
		$this->session->set_userdata($url_array);
	if(logged_in())
	{
		$data['result']=$this->Admin_model->get_data('ticket_stock',array('ts_id'=>$ticket_id));
		$data['prd_details']=$this->tm->get_data('products',array('pid'=>$data['result'][0]->ts_prd_id));
		$this->load->view('admin/sales/reply_ticket',$data);
	}
	else
	{
		redirect('login');
	}
}

function submit_pi_details()
{
	$quot_id=$this->input->post('qout_id');
	$date1=explode('/',$this->input->post('inv_date'));
			$month=$date1[0];
			$date=$date1[1];
			$year=$date1[2];
$new_formated_date=$year.'-'.$month.'-'.$date;

$cust_details=array(
	'c_comp_name'=>$this->input->post('c_comp_name'),
	'c_cust_name'=>$this->input->post('c_cust_name'),
	'c_cust_email'=>$this->input->post('c_cust_email'),
	'c_cust_mobile'=>$this->input->post('c_cust_mobile'),
	'c_tel_no'=>$this->input->post('c_tel_no'),
	'c_address'=>$this->input->post('c_address'),
	'c_cust_country'=>$this->input->post('c_cust_country'),
	'c_cust_pin'=>$this->input->post('c_cust_pin'),
	'c_cust_fax'=>$this->input->post('c_cust_fax'),
);

$notify_cust_details=array(
	'n_comp_name'=>$this->input->post('n_comp_name'),
	'n_cust_name'=>$this->input->post('n_cust_name'),
	'n_address'=>$this->input->post('n_address'),
	'n_cust_tel'=>$this->input->post('n_cust_tel'),
	'n_country'=>$this->input->post('n_country'),
	'n_cust_pin'=>$this->input->post('n_cust_pin'),
	'n_cust_fax'=>$this->input->post('n_cust_fax'),
);
foreach($cust_details as $key=>$cd)
	{
		if(!empty($cd))
		$final_cd[]=$key.':'.$cd;
	else
		$final_cd[]=$key.':'.'';
	}

	foreach($notify_cust_details as $key=>$nd)
	{
		if(!empty($nd))
		$final_nd[]=$key.':'.$nd;
	else
		$final_nd[]=$key.':'.'';
	}

	$data=array(
		'q_pi_trn'=>$this->input->post('trn_number'),
		'q_pi_po_number'=>$this->input->post('lpo_number'),	
		'q_country_orgin'=>implode(',',$this->input->post('q_orgin_country')),
		'q_country_final'=>implode(',',$this->input->post('q_final_country')),
		'q_inv_no'=>$this->input->post('inv_number'),
		'q_inv_date'=>$new_formated_date,
		'q_deliver_condition'=>$this->input->post('delivery_cond'),
		'q_port_orgin'=>$this->input->post('q_port_load'),
		'q_port_final'=>$this->input->post('q_port_final'),
		'proforma_cust_details'=>implode('$#$',$final_cd),
		'proforma_notify_cust_details'=>implode('$#$',$final_nd),
		'q_notify_val'=>$this->input->post('same_notify'),
		'q_country_loading'=>$this->input->post('country_loading'),
		'q_country_discharge'=>$this->input->post('country_discharge'),
		'q_display_hsc'=>$this->input->post('display_hsc'),
		'show_stamp_proforma'=>$this->input->post('show_stamp'),
		'p_approval_stamp_sign'=>$this->input->post('approved_sts_sign'),
		'q_price_ar'=>$this->input->post('converted_ar'),
	);
	//pre_list($data);
	$this->Admin_model->update_data('qoutattion_entry',$data,array('q_id'=>$quot_id));
	if($this->input->post('show_stamp')=='1')
	{
		send_proforma_approval_mail_mngt_stamp_sign($quot_id);
	}
	$this->session->set_flashdata('success', 'Data entered successfully');
	redirect('list-porforma');
}

public function list_stock($page_type='')
{

   if(logged_in())
	{


      $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-stock')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {










		$all_sort=$this->Admin_model->get_data('product_stock',array('ps_dxb_qnty!='=>''),'','','ps_dxb_qnty','DESC');
	foreach($all_sort as $p)
	{
	$prd_details[]=$this->tm->get_data('products',array('pcode'=>$p->ps_prd_code),'','','','',('p_prd_img,pname,pcat,pcode'));
	}
$category_names=array();

	foreach($prd_details as $index=>$pd)
	{
	//pre_list($pd[0]->p_prd_img);
		if(empty($category_names))
		{
			$category_names[]=$pd[0]->pcat;
			$prd_data_related[$pd[0]->pcat]['dxb_qnty'][]=$all_sort[$index]->ps_dxb_qnty;
			$prd_data_related[$pd[0]->pcat]['image'][]=$pd[0]->p_prd_img;
			$prd_data_related[$pd[0]->pcat]['p_name'][]=$pd[0]->pname;
			$prd_data_related[$pd[0]->pcat]['p_code'][]=$all_sort[$index]->ps_prd_code;
		}
		else
		{
			if(in_array($pd[0]->pcat,$category_names))
			{
				$prd_data_related[$pd[0]->pcat]['dxb_qnty'][]=$all_sort[$index]->ps_dxb_qnty;
				$prd_data_related[$pd[0]->pcat]['image'][]=$pd[0]->p_prd_img;
				$prd_data_related[$pd[0]->pcat]['p_name'][]=$pd[0]->pname;
				$prd_data_related[$pd[0]->pcat]['p_code'][]=$all_sort[$index]->ps_prd_code;
			}
			else
			{
				$category_names[]=$pd[0]->pcat;
				$prd_data_related[$pd[0]->pcat]['dxb_qnty'][]=$all_sort[$index]->ps_dxb_qnty;
				$prd_data_related[$pd[0]->pcat]['image'][]=$pd[0]->p_prd_img;
				$prd_data_related[$pd[0]->pcat]['p_name'][]=$pd[0]->pname;
				$prd_data_related[$pd[0]->pcat]['p_code'][]=$all_sort[$index]->ps_prd_code;
			}
		}
	}
$data['result']=$prd_data_related;
if(empty($page_type))
$this->load->view('admin/sales/list_stock',$data);
else
$this->load->view('admin/sales/print_list_stock',$data);

}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  



}
}


function approve_req_quot()
{
	$quot_id=$this->input->post('quot_id');
	$type_req=$this->input->post('type_req');
	if($type_req=="approve")
	$this->Admin_model->update_data('qoutattion_entry',array('q_approval_stamp_sign'=>'2'),array('q_id '=>$quot_id));
	else
	$this->Admin_model->update_data('qoutattion_entry',array('q_approval_stamp_sign'=>'3'),array('q_id '=>$quot_id));	
	echo send_mail_req_accept($quot_id,$type_req);
	//echo 1;
}

function approve_req_proforma()
{
	$quot_id=$this->input->post('quot_id');
	$type_req=$this->input->post('type_req');
	if($type_req=="approve")
	$this->Admin_model->update_data('qoutattion_entry',array('p_approval_stamp_sign'=>'2'),array('q_id '=>$quot_id));
	else
	$this->Admin_model->update_data('qoutattion_entry',array('p_approval_stamp_sign'=>'3'),array('q_id '=>$quot_id));	
	send_mail_req_accept_porforma($quot_id,$type_req);
	echo 1;
}




function get_picture_report($prd_id)
{
   
	if(logged_in())
	{
		if(!empty($prd_id))
		{
			$data['products']=$this->tm->get_data('products',array('p_sts'=>'1','pid'=>$prd_id));

		$everyday_limit=$this->Admin_model->get_data('ticket_stock',array('ts_date'=>get_date(),'ts_user_id'=>$this->session->userdata['user']['username']));/////everyday limit to raise ticket for each sales person should be less than 2//////

		$current_date=date('Y-m-d');
		$current_date_exploded=explode('-',$current_date);

		$check_same_prd_for_month=$this->Admin_model->get_data('ticket_stock',array('ts_year'=>$current_date_exploded[0],'ts_month'=>$current_date_exploded[1],'ts_user_id'=>$this->session->userdata['user']['username'],'ts_prd_id'=>$prd_id));////only one time per month for same product, allowed to raise ticket////////

		if( (count($everyday_limit)<=1) && (empty($check_same_prd_for_month)) )
			{
				$this->load->view('admin/sales/get_picture_report',$data);
			}/*
		else
			{
				if(!empty($check_same_prd_for_month))
				$this->session-> set_flashdata('errors','You have submitted this product earlier this month. Wait till next month');	
				else
				$this->session-> set_flashdata('errors', 'You have already submitted two tickets in this day.Wait for next day.');
				redirect('all-tickets');
			} 

		}
		*/
	}

}
}




function submit_picture_report()
{
  //$pr_id=$this->input->post('ticket_id');
	$pr_prd_name=$this->input->post('pr_prd_name');
	$pr_prd_id=$this->input->post('pr_prd_id');
	$pr_prd_code=$this->input->post('pr_prd_code');
	$pr_another_note=$this->input->post('pr_another_note');
	$pr_date=get_date();
	$pr_exploded=explode('-', $pr_date);
    $Problem_detect=$this->input->post('view_option');
	$report_created_by=$this->session->userdata['user']['username'];




	$data=array(
		'pr_user_created'=>$report_created_by,
		'pr_exact_problem'=>$Problem_detect,
		'pr_another_note'=>$pr_another_note,
		'pr_prd_id'=>$this->input->post('pr_prd_id'),
		'pr_prd_name'=>$this->input->post('pr_prd_name'),
		'pr_prd_code'=>$this->input->post('pr_prd_code'),
		'pr_sts'=>'1',
		'pr_date'=>get_date(),
        'pr_month'=>$pr_exploded[1],
        'pr_year'=>$pr_exploded[0],
        'pr_time'=>get_time(),
       // 'ts_ticket_reply'=>$ticket_reply,
       // 'ts_ticket_reply_date'=>$ticket_reply_date,
       /// 'ts_ticket_reply_time'=>$ticket_reply_time,
      //  'ts_ticket_action'=>$ticket_response_sts,
	);

	
		$insert_id=$this->Admin_model->insert_data('picture_report',$data);
	

	if($insert_id)
	{
      //$this->load->view('admin/sales/get_picture_report',$pr_prd_id);
     //print_r($insert_id2);
		$email_data2=mail_img_request($insert_id);

		
	}




if($email_data2==true)
$this->session->set_flashdata('success', 'Item status Successfully updated');
else
$this->session->set_flashdata('errors', 'Error found in sending mail.');

redirect('get_picture_report/'.$pr_prd_id);
	
//$this->load->view('admin/sales/get_picture_report',$data);
}



function email_picture_report($insert_id2)
{
	$this->email->initialize($this->setting());


	    $this->email->from('noreply@birigroup.com','Biri Group');
   
    $picture_report_details=$this->Admin_model->get_data('picture_report',array('pr_id'=>$insert_id2));
     $prd_details=$this->tm->get_data('products',array('pid'=> $picture_report_details[0]->pr_prd_id));
       //$this->email->to('waelibro555@gmail.com');
        $this->email->to('birigroup.designer@gmail.com');
        $this->email->subject('Issue in picture : report #'.$insert_id2);
        $msg="Hi,<br/>";
       $msg.='we have a problem with product picture with code :'.$prd_details[0]->pcode.'<br/>';
        $msg.='product name:<br/>';
     $msg.=$prd_details[0]->pname.'<br/>';
       $msg.='the main problem is :  <br/>';
     $msg.=$picture_report_details[0]->pr_exact_problem.'<br/>';


  $msg.='and there is note that : <br/>';
     $msg.=$picture_report_details[0]->pr_another_note.'<br/>';
         
         $msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
        $this->email->message($msg);
        //hi_arya();
            // $this->email->message('test');
         if($this->email->send())
         {
			$this->session->set_flashdata('success', 'Mail send successfully to Designer.');
         }
          else
         {
         	$this->session->set_flashdata('errors', 'Failed to send mail to Designer. Please try again later.');
            echo $this->email->print_debugger();
         } 

         $data22['prds']=$this->tm->get_data('products',array('p_sts'=>'1'));
		$this->load->view('admin/sales/price_list',$data22);

         	//redirect("price_list/".$data22., "refresh"); 
}















}