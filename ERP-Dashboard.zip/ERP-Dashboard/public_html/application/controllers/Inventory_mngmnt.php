<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inventory_mngmnt extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper('session');	
		$this->load->model(array('Second_db_model','Sales_book_model'));
		$this->load->model('Third_db_model','tm');
			
	}
	
function timestamp_data()
{
$tz = 'Asia/Dubai'; // your required location time zone.
		$timestamp = time();
		$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
		$dt->setTimestamp($timestamp);
		return $dt->format('Y-m-d H:i:s');
}	

function add_inventory()
{
 
 if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='all-tickets')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {




$this->load->view('admin/inventory/add_inventory');
}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


}



}

function list_inventory()
{
  if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-inventory')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {





$data['result']=$this->Admin_model->get_data('excel_inventory',array('ei_sts'=>'1'));
$this->load->view('admin/inventory/list_inventory',$data);


}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

}

function view_inventory($e_id)
{
$data['result']=$this->Admin_model->get_data('inventory_data',array('in_excel_id'=>$e_id));
$this->load->view('admin/inventory/list_view_inventory',$data);
}

function submit_inventory_excel()
{
$flag = 0;
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/excel/inventory_excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this->upload->do_upload('userfile')) 
		{
			$error = array('error' => $this->upload-> display_errors());
			$this->session ->set_flashdata('errors', $error['error']);
			redirect("add-inventory", "refresh");
		} 
		else 
		{
		$data = array('userfile' => $this->upload->data());
		}
	
		if (!empty($data['userfile']['file_name'])) 
		{
		$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path.$import_xls_file;
		try 
		{
		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
		die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME).'": '.$e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 3; $i <= $arrayCount; $i++) 
		{			
		$code = trim($allDataInSheet[$i]['A']);
		$quantity = trim($allDataInSheet[$i]['B']);
		$ware_house = trim($allDataInSheet[$i]['C']);
		}
		if($flag==1)
		{
		
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/excel/inventory_excel/".$import_xls_file);
			redirect('add-inventory','refresh');
		}
		else
		{
			$dwnload_title=$this->input->post('dwnload_title');
			$data23=array(
			'ei_file_name'=>$dwnload_title,
			'ei_file'=>$inputFileName,
			'ei_sts'=>"1",
			'ei_dt_ad'=>$this->timestamp_data(),
			'ei_dt_updt'=>$this->timestamp_data(),
			);
			$insert_id=$this->Admin_model->insert_data("excel_inventory", $data23);
			 $this->insert_table($allDataInSheet);
		}
		//print_r($flag);
}



function insert_table($allDataInSheet) 
{
	$arrayCount = count($allDataInSheet);
	$flag = 0;
	
	for($i=3;$i<=$arrayCount;$i++) 
	{			
		$code = trim($allDataInSheet[$i]['A']);
		$quantity = trim($allDataInSheet[$i]['B']);
		$ware_house = trim($allDataInSheet[$i]['C']);
		
		
		if(!empty($quantity) )
		{
				$data_empty_array=array(
					'in_excel_id'=>$insert_id,
					'in_code'=>$code,
					'in_warehouse'=>$ware_house,
					'in_qunatity'=>$quantity,
					'in_sts'=>'1',
					'in_dt_ad'=>$this->timestamp_data(),
					'in_dt_updt'=>$this->timestamp_data(),
					);
			
			$insert_id_vochr=$this->Admin_model->insert_data("inventory_data", $data_empty_array);
			if(!($insert_id_vochr))
			$flag = false;
			else
				$flag = true;
		}
	
	}

	if ($flag)
			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');

		redirect("add-inventory", "refresh");	
}










}