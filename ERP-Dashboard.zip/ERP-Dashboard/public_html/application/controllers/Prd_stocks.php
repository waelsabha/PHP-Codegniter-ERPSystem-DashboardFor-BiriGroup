<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Prd_stocks extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','email_survey'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
		$this->load->library('numbertowordconvertsconver');		
		 $this->db2 = $this->load->database('three', TRUE);	
	}

function opening_stock($os=null)
{
	if(logged_in())
	{
     $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		 $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	 if ((($page_cred[$i]=='opening-stock')||($this ->session->userdata['user']['main_dept'])=="Main"))  
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'opening-stock'));
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
		$data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));
		$data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));
		if(empty($os))
		{
			$opening_stock_data=$this->tm->get_data('prd_stock',array('ps_sts'=>'1'),'1','','ps_id ','DESC');
			if(empty($opening_stock_data))
			{
				$data['doc_num']='1';
			}
			else
			{
				$data['doc_num']=$opening_stock_data[0]->ps_id;
			}
		}
		else
		{
			$data['result']=$this->tm->get_data('prd_stock',array('ps_id'=>$os));
			$data['result_details']=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$os));
		}
		$this->load->view('admin/stocks/opening_stock',$data);

}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}


function list_opening_stock()
{
	if(logged_in())
	{

  
 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-opening-stock')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


		//$data['result']=$this->tm->get_data('prd_stock',array('ps_sts'=>'1'));
		$sql2=$this->db2->query("SELECT prd_stock.*,sum(prd_stock_details.psd_qnty) as tot_qnty
		FROM prd_stock join prd_stock_details  on prd_stock_details.psd_ps_id=prd_stock.ps_id 
		WHERE prd_stock.ps_sts = '1' and prd_stock_details.psd_type='opening_stock' group by  prd_stock_details.psd_ps_id order by prd_stock.ps_id   DESC");
		$data['result']=$sql2->result_array();
		$this->load->view('admin/stocks/list_opening_stock',$data);


}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}

function get_product_extras()
{
	$prd_id=$this->input->post('prd_id');
	$table_id=$this->input->post('table_id');
	$sql2=$this->db2->query("SELECT products.pid,prd_units.* FROM products join prd_units on prd_units.pu_pid_focus=products.prod_id_focus where products.pid='".$prd_id."' ");
	$data_result_set1=$sql2->result_array();
	if(!empty($data_result_set1))
	{
		$units=explode('|##|',$data_result_set1[0]['pu_units']);
		$base_unit=$data_result_set1[0]['pu_base_unit'];
		$html="<option value='".$base_unit."'>".$base_unit."</option>";
		foreach($units as $u)
		{
			$html.="<option value='".$u."'>".$u."</option>";
		}
	}
	else
	{
		$html="<option value='Default'>Default</option>";
	}
	echo $html;
}

function get_details_warehouse()
{
	$table_id=$this->input->post('table_id');
	$warehouse=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));

$html= '<select data-plugin-selectTwo  class="form-control populate warehouse_'.$table_id.'" name="psd_warehouse[]" ><option >Choose</option>';
foreach($warehouse as $w)
{
$html.="<option value=".$w->mw_id.">".$w->mw_name."</option>";
}
  $html.="</select>";
	  echo $html;
}


function get_details_prd()
{
	$table_id=$this->input->post('table_id');
	$prd_data=$this->tm->get_data('products',array('p_sts'=>'1'));
$html='<select data-plugin-selectTwo  class="form-control populate product_'.$table_id.'" name="psd_product[]" onchange="get_product_details('.$table_id.')"><option >Choose</option>';
	foreach($prd_data as $pd)
	{
	$html.="<option value=".$pd->pid.">".$pd->pname.":: <br/>".$pd->pcode."</option>";
	}
  $html.="</select>";
  echo $html;
}

function submit_opening_stock()
{
	$added_ps_id=$this->input->post('added_ps_id');
        $main_date=$this->input->post('hid_date');
$main_date1=explode('/',$main_date);
			$month2=$main_date1[0];
			$date2=$main_date1[1];
			$year2=$main_date1[2];
$new_formated_date2=$year2.'-'.$month2.'-'.$date2;
	
	$data['ps_company']=$this->input->post('ps_company');
	$data['ps_narration']=$this->input->post('ps_narration');
	//$data['ps_attachments']=$data_image;
	$data['ps_user_created']=$this->session->userdata['user']['username'];
	$data['ps_sts']='1';
	$data['ps_total']=$this->input->post('ps_total');
	$data['ps_dt_updt']=get_date_time();
//pre_list($data);
if(empty($added_ps_id))
	$insert_id=$this->tm->insert_data('prd_stock',$data);
else
{
	$this->tm->update_data('prd_stock',$data,array('ps_id'=>$added_ps_id) );	
}
//$insert_id=12;
	if(!empty($insert_id))
	$this->tm->update_data('prd_stock',array('ps_dt_crtd'=>get_date_time(),'ps_date'=>$new_formated_date2 ),array('ps_id'=>$insert_id) );	

	$prds_array=explode('|#|',$this->input->post('hid_item'));
	$hid_warehouse=explode('|#|',$this->input->post('hid_warehouse'));
	$hid_unit=explode('|#|',$this->input->post('hid_unit'));
	$hid_qnty=explode('|#|',$this->input->post('hid_qnty'));
	$hid_rate=explode('|#|',$this->input->post('hid_rate'));
	$hid_gross=explode('|#|',$this->input->post('hid_gross'));

if(!empty($added_ps_id))
$stock_details_id=explode('|#|',$this->input->post('stock_details_ids'));

	foreach($prds_array as $index=>$pds)
	{
		$data_stock['psd_warhouse']=$hid_warehouse[$index];
		$data_stock['psd_unit']=$hid_unit[$index];
		$data_stock['psd_qnty']=$hid_qnty[$index];
		$data_stock['psd_rate']=$hid_rate[$index];
		$data_stock['psd_gross']=$hid_gross[$index];
		$data_stock['psd_product']=$pds;
		$data_stock['psd_type']='opening_stock';
		if(empty($added_ps_id))
		$data_stock['psd_ps_id']=$insert_id;
	  else
		$data_stock['psd_ps_id']=$added_ps_id;
//pre_list($data_stock);
		if(empty($added_ps_id))
		{
		$insert_id_2=$this->tm->insert_data('prd_stock_details',$data_stock);	
		}
		else
		{
			if($stock_details_id[$index])
			$this->tm->update_data('prd_stock_details',$data_stock,array('psd_id'=>$stock_details_id[$index],'psd_type'=>'opening_stock'));
			else
			$this->tm->insert_data('prd_stock_details',$data_stock);
		}
//////////////////////////////////add to stock details table, where all stocks are saved////////////////////////
		$data_prd_stock['sd_warehouse_id']=$hid_warehouse[$index];
			$data_prd_stock['sd_stock_qnty']=$hid_qnty[$index];
			$data_prd_stock['sd_prd_id']=$pds;

			$stock_table=$this->tm->get_data('stock_details',array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$hid_warehouse[$index]));

			
			if(empty($stock_table))///insert here//////////////////////
			{
				//echo "in if to insert as new val";pre_list($data_stock);
				$this->tm->insert_data('stock_details',$data_prd_stock);/////this table should only have single entery for prd-warehouse combination///
			}
			else///////upddate here/////////////////////
			{
				//print_r($stock_table);
				$stock_table_qnty=$stock_table[0]->sd_stock_qnty;
				$new_qnty_stock=$stock_table_qnty+$hid_qnty[$index];
				
				if(empty($added_ps_id))///when inserting new values///
				{
					//echo "in esle of if inserting as new value";echo "<br/>";
					$data_prd_stock['sd_stock_qnty']=$new_qnty_stock;
					//pre_list($data_stock);
				$this->tm->update_data('stock_details',$data_prd_stock,array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$hid_warehouse[$index]));
				}
				else///when updating existing values of opening stock , update the same///
				{
					$stock_details_table_data=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$added_ps_id,'psd_type'=>'opening_stock'));
					if($stock_details_table_data[0]->psd_qnty==$hid_qnty[$index])////check if the old_qnty = new_qnty updating, left unchanged////
					{}
					else/// if the old qnty is different than new, then only chnage/////
					{
							$diff_in_qnty=abs($stock_details_table_data[0]->psd_qnty-$hid_qnty[$index]);
							if($hid_qnty[$index]>$stock_details_table_data[0]->psd_qnty)///check if the newly updated qnty is greater than existing qnty in table,
							{
								$new_qnty_stock_11=$stock_table_qnty+$diff_in_qnty;
								$data_prd_stock['sd_stock_qnty']=$new_qnty_stock_11;
								$this->tm->update_data('stock_details',$data_prd_stock,array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$hid_warehouse[$index]));
							}
							else
							{
								$new_qnty_stock_11=$stock_table_qnty-$diff_in_qnty;
								$data_prd_stock['sd_stock_qnty']=$new_qnty_stock_11;
								$this->tm->update_data('stock_details',$data_prd_stock,array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$hid_warehouse[$index]));
							}
					}
					$this->tm->update_data('stock_details',$data_prd_stock,array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$hid_warehouse[$index]));
				}
			}
			/////////////////////end here , stock details table////////////////
	}

$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'opening stock created',
				'act_status'=>'opening stock id '.$insert_id,
				'act_type'=>'opening_stock',/////will be based on type, the activity will be extracted////
				'act_type_id'=>$insert_id,
			
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
				'act_type'=>'Opening Stock'

			);
if(empty($added_ps_id))
	$this->Admin_model->insert_data('activities',$activity_data);

	if(empty($added_ps_id))
	{
		$this->session->set_flashdata('success', 'Data Successfully inserted');	
		redirect('list-opening-stock');
	}
	else
	{
		$this->session->set_flashdata('success', 'Data Successfully updated');	
		redirect('list-opening-stock');
	}
}

function delete_opening_stock($psid=null)
{
	if(logged_in())
	{


   $stock_details_table_data=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$psid,'psd_type'=>'opening_stock'));


  foreach ($stock_details_table_data	 as $key => $value) 

  {
						$psd_warehouse_id[$key]=$stock_details_table_data[$key]->psd_warhouse;

						$psd_product_id[$key]=$stock_details_table_data[$key]->psd_product;
						$psd_qnty_id[$key]=$stock_details_table_data[$key]->psd_qnty;



						


						$stock_table=$this->tm->get_data('stock_details',array('sd_prd_id'=>$psd_product_id[$key],'sd_warehouse_id'=>$psd_warehouse_id[$key]));


						// $existqnty=$stock_table[0]->sd_stock_qnty;
						// print($stock_table[0]->sd_stock_qnty);
						// exit(0);

						 if(empty($stock_table))///if qnty not exist you cannont be minus so you need to break //////////////////////
					{
						 $this->session->set_flashdata('errors', 'Error on data found. cannot delete now.');
				 		redirect('list-opening-stock');
					}

					else if($stock_table[0]->sd_stock_qnty <$psd_qnty_id[$key])
					{
		             $this->session->set_flashdata('errors', 'Error on data found.cannot delete now.');
				 		redirect('list-opening-stock');

					}

					else///////upddate here/////////////////////
					{
						//print_r($stock_table);
						$stock_table_qnty=$stock_table[0]->sd_stock_qnty;
						$new_qnty_stock=$stock_table_qnty-$psd_qnty_id[$key];

                 	$data_prd_stock['sd_warehouse_id']=$psd_warehouse_id[$key];
					$data_prd_stock['sd_stock_qnty']=$new_qnty_stock;

						$data_prd_stock['sd_prd_id']=$psd_product_id[$key];
      //               print_r($data_prd_stock['sd_stock_qnty']);

						// print_r($new_qnty_stock);
						// exit(0);
						$this->tm->update_data('stock_details',$data_prd_stock,array('sd_prd_id'=>$psd_product_id[$key],'sd_warehouse_id'=>$psd_warehouse_id[$key]));

                }



	}
	$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'opening stock deleted',
				'act_status'=>'opening stock id '.$psid,
				'act_type'=>'opening_stock',/////will be based on type, the activity will be extracted////
				'act_type_id'=>$psid,
			
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
				'act_type'=>'Opening Stock'

			);

	$this->tm->update_data('prd_stock',array('ps_sts'=>'0'),array('ps_id'=>$psid));
		$this->session->set_flashdata('success', 'Data Successfully deleted');	
		redirect('list-opening-stock');
}
}

function get_doc_details()
{
	$psid=$this->input->post('main_id');
	$type=$this->input->post('type');
	if($type=="opening_stock")
	$dataa=$this->tm->get_data('prd_stock',array('ps_id'=>$psid));
	else
	{
		if($type=="stock_excess")
		$dataa=$this->tm->get_data('prd_stock_adjustment',array('ps_id'=>$psid));
		else 	if($type=="stock_shortage")
		$dataa=$this->tm->get_data('prd_stock_adjustment',array('ps_id'=>$psid));
    else	if($type=="stock_transfer")
    $dataa=$this->tm->get_data('prd_stock_transfer',array('ps_id'=>$psid));
	}
	$company_data=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->ps_company));

	if($type=="opening_stock")
	$ps_details=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$dataa[0]->ps_id,'psd_type'=>'opening_stock'));
elseif($type=="stock_excess")
		$ps_details=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$dataa[0]->ps_id,'psd_type'=>'stock_excess'));
elseif($type=="stock_shortage")
		$ps_details=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$dataa[0]->ps_id,'psd_type'=>'stock_shortage'));
elseif($type=="stock_transfer")
$ps_details=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$dataa[0]->ps_id,'psd_type'=>'stock_transfer'));
	else{}

	$html="<div class='row'>";
		if($type=="opening_stock")
					$html.="<div class='col-md-12'><h4>Opening Stock Data</h4>";
				else
					$html.="<div class='col-md-12'><h4> Stock Adjustment Data</h4>";	

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->ps_id ."</p>";
					$html.="<p>User Created: ".$dataa[0]->ps_user_created."</p>";
					$html.="<p>Date: ".$dataa[0]->ps_date."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
				
					$html.="<p>Company: ".$company_data[0]->mcomp_name."</p>";
					$html.="<p>Narration: ".$dataa[0]->ps_narration."</p>";
					
				$html.="</div>";

					// $html.="<div class='col-md-4'>";
					// $html.="<p>Attachements: <a href='".base_url('uploads/receipt_files/'.$dataa[0]->ps_attachments)."' target='_blank'> ".$dataa[0]->ps_attachments."</a></p>";
					// $html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

					$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th>
					<th>Warehouse</th><th>Product</th>";
						if(($type=="stock_excess") || ($type=="stock_shortage"))
					$html.="<th>Description</th>";
					$html.="<th>Unit</th>
					<th>Quantity</th><th>Rate</th>
					<th>Gross</th></thead>";
					$html.="<tbody>";
					foreach($ps_details as $key=>$d)
					{
						$data_wl=$this->Admin_model->get_data('master_warehouse',array('mw_id'=>$d->psd_warhouse));
						$data_prd=$this->tm->get_data('products',array('pid'=>$d->psd_product));


						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$data_wl[0]->mw_name."</td>";
						$html.="<td>".$data_prd[0]->pname."</td>";

						if(($type=="stock_excess") || ($type=="stock_shortage"))
							$html.="<td>".$d->psd_desc."</td>";
						
						$html.="<td>".$d->psd_unit."</td>";
						$html.="<td>".$d->psd_qnty."</td>";
						$html.="<td>".$d->psd_rate."</td>";
						$html.="<td>".$d->psd_gross."</td>";
						$html.="</tr>";
					}
					$html.="</tbody>";
					$html.="</table>";
						$html.="<div class='row'>";
					$html.="<div class='col-md-12'><div class='col-md-4'>";
						$html.="<p>Total Amount : ".$dataa[0]->ps_total."</p>";
					$html.="</div>";$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/
					echo $html;
}


function stock_excess($os=null)
{
	if(logged_in())
	{

		   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='stock-excess')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'opening-stock'));
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
		$data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));
		$data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));
		$data['stock_ac']=$this->Admin_model->get_data('master_accounts_tree',array('id'=>'193'));
		$data['party_ac']=$this->Admin_model->get_data('master_accounts_tree',array('id'=>'1036'));
		
		if(empty($os))
		{
		$opening_stock_data=$this->tm->get_data('prd_stock_adjustment',array('ps_sts'=>'1','ps_type'=>'stock_excess'),'1','','ps_id ','DESC');
			if(empty($opening_stock_data))
			{
				$data['doc_num']='1';
			}
			else
			{
				$data['doc_num']=$opening_stock_data[0]->ps_doc_num+1;
			}
		}
		else
		{
			$data['result']=$this->tm->get_data('prd_stock_adjustment',array('ps_id'=>$os));
			if($data['result'][0]->ps_type=="stock_excess")
				$data['result_details']=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$os,'psd_type'=>'stock_excess'));
			else
				$data['result_details']=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$os,'psd_type'=>'stock_shortage'));
		}
		$this->load->view('admin/stocks/stock_excess',$data);


    }
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 


	}
}


function stock_shortage($os=null)
{
	if(logged_in())
	{
    $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='stock-shortage')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'opening-stock'));
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
		$data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));
		$data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));
		$data['stock_ac']=$this->Admin_model->get_data('master_accounts_tree',array('id'=>'193'));
		$data['party_ac']=$this->Admin_model->get_data('master_accounts_tree',array('id'=>'1036'));
		
		if(empty($os))
		{
	$opening_stock_data=$this->tm->get_data('prd_stock_adjustment',array('ps_sts'=>'1','ps_type'=>'stock_shortage'),'1','','ps_id ','DESC');
			if(empty($opening_stock_data))
			{
				$data['doc_num']='1';
			}
			else
			{
				$data['doc_num']=$opening_stock_data[0]->ps_doc_num+1;
			}
		}
		else
		{
			$data['result']=$this->tm->get_data('prd_stock_adjustment',array('ps_id'=>$os));
			if($data['result'][0]->ps_type=="stock_excess")
				$data['result_details']=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$os,'psd_type'=>'stock_excess'));
			else
				$data['result_details']=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$os,'psd_type'=>'stock_shortage'));
		}
		$this->load->view('admin/stocks/stock_shortage',$data);


    }
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 

	}
}

function list_excess_stock()
{
	if(logged_in())
	{

  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='list-excess-stock')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {
       	
		$data['result']=$this->tm->get_data('prd_stock_adjustment',array('ps_sts'=>'1','ps_type'=>'stock_excess'));
		$this->load->view('admin/stocks/list_excess_stock',$data);

		    }
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 


	}
}


function list_shortage_stock()
{
	if(logged_in())
	{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-shortage-stock')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


		$data['result']=$this->tm->get_data('prd_stock_adjustment',array('ps_sts'=>'1','ps_type'=>'stock_shortage'));
		$this->load->view('admin/stocks/list_shortage_stock',$data);
}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  



		
	}
}


function get_product_quantity()
{
	$prd_id=$this->input->post('prd_id');
	$warehouse_to=$this->input->post('warehouse_to');
	$warehouse_from=$this->input->post('warehouse_from');
//print_r($warehouse_to);print_r($warehouse_from);print_r();
	$stock_details=$this->tm->get_data('stock_details',array('sd_warehouse_id'=>$warehouse_from,'sd_prd_id'=>$prd_id));

	if (empty($stock_details[0]->sd_stock_qnty)){
		echo 0;
	}
	else{echo $stock_details[0]->sd_stock_qnty;}

	
}



function submit_stock_adj()
{
	$form_type=$this->input->post('form_type');
	$added_ps_id=$this->input->post('added_ps_id');
        $main_date=$this->input->post('hid_date');
$main_date1=explode('/',$main_date);
			$month2=$main_date1[0];
			$date2=$main_date1[1];
			$year2=$main_date1[2];
$new_formated_date2=$year2.'-'.$month2.'-'.$date2;

	
	$data['ps_company']=$this->input->post('ps_company');
	$data['ps_narration']=$this->input->post('ps_narration');
	//$data['ps_attachments']=$data_image;
	$data['ps_user_created']=$this->session->userdata['user']['username'];
	$data['ps_sts']='1';
	$data['ps_total']=$this->input->post('ps_total');
	$data['ps_dt_updt']=get_date_time();
	$data['ps_type']=$this->input->post('form_type');
	$data['ps_stock_ac']=$this->input->post('ps_stock_ac');
	$data['ps_party_ac']=$this->input->post('ps_party_ac');
	$data['ps_doc_num']=$this->input->post('stock_doc_no');
	
//pre_list($data);
	if(empty($added_ps_id))
	$insert_id=$this->tm->insert_data('prd_stock_adjustment',$data);
	else
	{
		$this->tm->update_data('prd_stock_adjustment',$data,array('ps_id'=>$added_ps_id) );	
	}

	if(!empty($insert_id))
	$this->tm->update_data('prd_stock_adjustment',array('ps_dt_crtd'=>get_date_time(),'ps_date'=>$new_formated_date2 ),array('ps_id'=>$insert_id) );	

	$prds_array=explode('|#|',$this->input->post('hid_item'));
	$hid_warehouse=explode('|#|',$this->input->post('hid_warehouse'));
	$hid_unit=explode('|#|',$this->input->post('hid_unit'));
	$hid_qnty=explode('|#|',$this->input->post('hid_qnty'));
	$hid_rate=explode('|#|',$this->input->post('hid_rate'));
	$hid_gross=explode('|#|',$this->input->post('hid_gross'));
	$hid_desc=explode('|#|',$this->input->post('hid_desc'));

	if(!empty($added_ps_id))
$stock_details_id=explode('|#|',$this->input->post('stock_details_ids'));

	foreach($prds_array as $index=>$pds)
	{
		$data_stock['psd_warhouse']=$hid_warehouse[$index];
		$data_stock['psd_unit']=$hid_unit[$index];
		$data_stock['psd_qnty']=$hid_qnty[$index];
		$data_stock['psd_rate']=$hid_rate[$index];
		$data_stock['psd_gross']=$hid_gross[$index];
		$data_stock['psd_product']=$pds;
		$data_stock['psd_desc']=$hid_desc[$index];

		if($this->input->post('form_type')=="stock_excess")
		$data_stock['psd_type']='stock_excess';
		else
			$data_stock['psd_type']='stock_shortage';

		if(empty($added_ps_id))
		$data_stock['psd_ps_id']=$insert_id;
	else
		$data_stock['psd_ps_id']=$added_ps_id;
//pre_list($data_stock);
		if(empty($added_ps_id))
		$insert_id_2=$this->tm->insert_data('prd_stock_details',$data_stock);
		else
		{
			if($stock_details_id[$index])
			{
				if($this->input->post('form_type')=="stock_excess")
				{
					$this->tm->update_data('prd_stock_details',$data_stock,array('psd_id'=>$stock_details_id[$index],
						'psd_type'=>'stock_excess'));
				}
				else
				{
					$this->tm->update_data('prd_stock_details',$data_stock,array('psd_id'=>$stock_details_id[$index],'psd_type'=>'stock_shortage'));
				}
			}
			else
			$this->tm->insert_data('prd_stock_details',$data_stock);
		}

    

//////////////////////////////////add to stock details table, where all stocks are saved////////////////////////
		$data_prd_stock['sd_warehouse_id']=$hid_warehouse[$index];
			$data_prd_stock['sd_stock_qnty']=$hid_qnty[$index];
			$data_prd_stock['sd_prd_id']=$pds;



			$stock_table=$this->tm->get_data('stock_details',array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$hid_warehouse[$index]));
			if(empty($stock_table))///insert here//////////////////////
			{
				//echo "in if to insert as new val";pre_list($data_stock);
				$this->tm->insert_data('stock_details',$data_prd_stock);/////this table should only have single entery for prd-warehouse combination///
			}
			else///////upddate here/////////////////////
			{


				if($this->input->post('form_type')=="stock_shortage")
				{
               $stock_table_qnty=$stock_table[0]->sd_stock_qnty;
				  $new_qnty_stock=$stock_table_qnty-$hid_qnty[$index];

				}
				else {
					          $stock_table_qnty=$stock_table[0]->sd_stock_qnty;
				  $new_qnty_stock=$stock_table_qnty+$hid_qnty[$index];
				}
				//print_r($stock_table);
				
				
				if(empty($added_ps_id))///when inserting new values///
				{
					//echo "in esle of if inserting as new value";echo "<br/>";
					$data_prd_stock['sd_stock_qnty']=$new_qnty_stock;
					//pre_list($data_stock);
				$this->tm->update_data('stock_details',$data_prd_stock,array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$hid_warehouse[$index]));
				}
				else///when updating existing values of opening stock , update the same///
				{   

					 if($this->input->post('form_type')=="stock_shortage")
                {
                		$stock_details_table_data=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$added_ps_id,'psd_type'=>'stock_shortage'));
                }
                else{
                		$stock_details_table_data=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$added_ps_id,'psd_type'=>'stock_excess'));
                }
				
					if($stock_details_table_data[0]->psd_qnty==$hid_qnty[$index])////check if the old_qnty = new_qnty updating, left unchanged////
					{}
					else/// if the old qnty is different than new, then only chnage/////
					{
							$diff_in_qnty=abs($stock_details_table_data[0]->psd_qnty-$hid_qnty[$index]);
							if($hid_qnty[$index]>$stock_details_table_data[0]->psd_qnty)///check if the newly updated qnty is greater than existing qnty in table,
							{
								$new_qnty_stock_11=$stock_table_qnty+$diff_in_qnty;
								$data_prd_stock['sd_stock_qnty']=$new_qnty_stock_11;
								$this->tm->update_data('stock_details',$data_prd_stock,array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$hid_warehouse[$index]));
							}
							else
							{
								$new_qnty_stock_11=$stock_table_qnty-$diff_in_qnty;
								$data_prd_stock['sd_stock_qnty']=$new_qnty_stock_11;
								$this->tm->update_data('stock_details',$data_prd_stock,array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$hid_warehouse[$index]));
							}
					}
					$this->tm->update_data('stock_details',$data_prd_stock,array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$hid_warehouse[$index]));
				}
			}
			/////////////////////end here , stock details table////////////////
	}


				$activity_data['act_user']=$this->session->userdata['user']['username'];
				if($this->input->post('form_type')=="stock_excess")
				{
					$activity_data['act_function']='stock adjustment - stock excess created';
				}
				else
				{
					$activity_data['act_function']='stock adjustment - stock shortage created';
				}
			$activity_data['act_status']='stock adjustment id '.$insert_id;
				$activity_data['act_type']='stock adjustment';/////will be based on type, the activity will be extracted////
				$activity_data['act_type_id']=$insert_id;
				$activity_data['act_type']='Stock Adjustment';
				$activity_data['act_date']=get_date();
				$activity_data['act_time']=get_time();
				$activity_data['act_date_time']=get_date_time();
		
if(empty($added_ps_id))
	$this->Admin_model->insert_data('activities',$activity_data);

	if(empty($added_ps_id))
	{
		$this->session->set_flashdata('success', 'Data Successfully inserted');	
		if($this->input->post('form_type')=="stock_excess")
			redirect('list-excess-stock');
		else
      redirect('list-shortage-stock');
		
	}
	else
	{
		$this->session->set_flashdata('success', 'Data Successfully updated');	
		if($this->input->post('form_type')=="stock_excess")
				redirect('list-excess-stock');
		else
			redirect('list-shortage-stock');
	}
}

function stock_transfer($os=null)
{
	if(logged_in())
	{
   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='stock-transfer')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

									$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'opening-stock'));
									$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
									$data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));
									$data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));
									
									if(empty($os))
									{
								$opening_stock_data=$this->tm->get_data('prd_stock_transfer',array('ps_sts'=>'1'),'1','','ps_id ','DESC');
										if(empty($opening_stock_data))
										{
											$data['doc_num']='1';
										}
										else
										{
											$data['doc_num']=$opening_stock_data[0]->ps_id+1;
										}
									}
									else
									{
										$data['result']=$this->tm->get_data('prd_stock_transfer',array('ps_id'=>$os));
										$data['result_details']=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$os,'psd_type'=>'stock_transfer'));
									}
									$this->load->view('admin/stocks/stock_transfer',$data);

    }
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 
		
	}
}

function list_transfer_stock()
{
	if(logged_in())
	{
		
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-transfer-stock')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



		$data['result']=$this->tm->get_data('prd_stock_transfer',array('ps_sts'=>'1'));

	
		$this->load->view('admin/stocks/list_transfer_stock',$data);

}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


	}

}

function submit_stock_transfer()
{
	$added_ps_id=$this->input->post('added_ps_id');
    $main_date=$this->input->post('hid_date');
	$main_date1=explode('/',$main_date);

			$month2=$main_date1[0];
			$date2=$main_date1[1];
			$year2=$main_date1[2];
         $new_formated_date2=$year2.'-'.$month2.'-'.$date2;


		$prds_array=explode('|#|',$this->input->post('hid_item'));


		$hid_unit=explode('|#|',$this->input->post('hid_unit'));
		$hid_qnty=explode('|#|',$this->input->post('hid_qnty'));

		$hid_rate=explode('|#|',$this->input->post('hid_rate'));
		$hid_gross=explode('|#|',$this->input->post('hid_gross'));
	
	
	
	$data['ps_company']=$this->input->post('ps_company');
	$data['ps_narration']=$this->input->post('ps_narration');
	//$data['ps_attachments']=$data_image;
	$data['ps_transfer_to']=$this->input->post('ps_transfer_to');
	

	$data['ps_transfer_from']=$this->input->post('ps_transfer_from');
	
 

	$data['ps_user_created']=$this->session->userdata['user']['username'];
	$data['ps_sts']='1';
	
	$data['ps_dt_updt']=get_date_time();
	$data['ps_tot_qnty']=array_sum($hid_qnty);
//pre_list($data);
	if(empty($added_ps_id))
	$insert_id=$this->tm->insert_data('prd_stock_transfer',$data);
else
{
	$this->tm->update_data('prd_stock_transfer',$data,array('ps_id'=>$added_ps_id) );	
}
//$insert_id='12';
	if(!empty($insert_id))
	$this->tm->update_data('prd_stock_transfer',array('ps_dt_crtd'=>get_date_time(),'ps_date'=>$new_formated_date2 ),array('ps_id'=>$insert_id) );	
//print_r($prds_array);

if(!empty($added_ps_id))
$stock_details_id=explode('|#|',$this->input->post('stock_details_ids'));

	foreach($prds_array as $index=>$pds)
	{ 
 
		if ($index==0) {
			$ik=$index;
		}
		else{
			$ik=0;

		}
	
        $data_stock['psd_unit']=$hid_unit[$index];
        
		   $data_stock['psd_qnty']=$hid_qnty[$index];
           
			$data_stock['psd_rate']=$hid_rate[$index];
	              
			$data_stock['psd_gross']=$hid_gross[$index];
	              
			$data_stock['psd_product']=$pds;
	                

			$data_stock['psd_type']='stock_transfer';
	                
			if(empty($added_ps_id))
			  $data_stock['psd_ps_id']=$insert_id;
		   else
			   $data_stock['psd_ps_id']=$added_ps_id;

		    $data_stock['psd_warhouse']=$this->input->post('ps_transfer_to');//////this warehouse is to which the qnty is transfered///
	      //pre_list($data_stock);
			if(empty($added_ps_id))
			$insert_id_2=$this->tm->insert_data('prd_stock_details',$data_stock);
			else
			{
				if($stock_details_id[$index])
				$this->tm->update_data('prd_stock_details',$data_stock,array('psd_id'=>$stock_details_id[$index],'psd_type'=>'stock_transfer'));
				else
				$this->tm->insert_data('prd_stock_details',$data_stock);
			}



			if(!empty($added_ps_id))
			{
			$stock_details_table_data=$this->tm->get_data('prd_stock_details',array('psd_ps_id'=>$added_ps_id,'psd_type'=>'stock_transfer'));/////put it here, bocz if there is any prd added , on update , which was not there at the time of insert, then it will not affect the stock checking;	
			}	
			   //////////////////////////////////add to stock details table, where all stocks are saved////////////////////////

				
		 $stock_table_1=$this->tm->get_data('stock_details',array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_to')));////details of transfer to warehouse, to be incremented///////
     

		 $stock_table_2=$this->tm->get_data('stock_details',array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_from')));///details of transfer from warehouse, to be decreased////

  
				$stock_table_qnty_1=$stock_table_1[$ik]->sd_stock_qnty;
                  
	   
				if($stock_table_qnty_1!='Null'||$stock_table_qnty_1!='null' ||$stock_table_qnty_1<'0')
				{
					
					if ($hid_qnty[$index]=='0'||$hid_qnty[$index]=='') {

						$new_qnty_stock_1=0;

					}
					else{
						   $new_qnty_stock_1=$stock_table_qnty_1+$hid_qnty[$index];
					}

					
	
		    } 

	
		 	else
		 	{
                 if ($hid_qnty[$index]=='0'||$hid_qnty[$index]=='') {

						$new_qnty_stock_1=0;

					}
					else{
						  $new_qnty_stock_1=$hid_qnty[$index]+0;
					}





				
					
		 	}
				

	 		$stock_table_qnty_2=$stock_table_2[$ik]->sd_stock_qnty;
				
       
		 		if(!empty($stock_table_qnty_2))
				{
                       if($stock_table_qnty_2<$hid_qnty[$index])
					{

                                 	$this->session->set_flashdata('errors', 'Be Atenttion The Quantitiy you entered more than we have re enter please.    /    يرجى الانتباه واعادة الادخال لان الكمية التي ادخلتها اكبر من المخزون لدينا ');
				
                                  redirect('stock-transfer');

					}
					else {

				     $new_qnty_stock_2=$stock_table_qnty_2-$hid_qnty[$index];
					}

		    	}
		    	else{
		    		
		    	}



				if(empty($added_ps_id))///when inserting new values, add to existing
				{ 
					if(($stock_table_1[$ik]->sd_stock_qnty)!='Null')
					{
				// 		  print_r('here');
				// exit(0);
						//echo "cin if 1";
						$this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_qnty_stock_1),array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_to')));
					}
					else
					{
						//echo "cin esle";
						$this->tm->insert_data('stock_details',array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_to'),'sd_stock_qnty'=>$new_qnty_stock_1));
					}

					if(!empty($stock_table_2[$ik]))
					{
						//echo "in if 2";
			       	$this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_qnty_stock_2),array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_from') ));
					}
				}
				else///
				{
					if($stock_details_id[$index])////here need to check if same prds are updting or different///
					{
							if($stock_details_table_data[$ik]->psd_qnty==$hid_qnty[$index])////if old_table_qnty=now_table_qnty, then do nothing as it is already updated
							{}
						else
						{
							///find the difference in quantity, from the last inserted quantity, and add or minus this diff to the existing//
							$diff_in_qnty=abs($stock_details_table_data[$ik]->psd_qnty-$hid_qnty[$index]);

							if($hid_qnty[$index]>$stock_details_table_data[$ik]->psd_qnty)///check if the newly updated qnty is greater than existing qnty in table,
							{
								$new_qnty_stock_11=$stock_table_qnty_1+$diff_in_qnty;
								$new_qnty_stock_21=$stock_table_qnty_2-$diff_in_qnty;

								 $this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_qnty_stock_11),array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_to')));

								 $this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_qnty_stock_21),array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_from') ));
							}
							else
							{
								$new_qnty_stock_11=$stock_table_qnty_1-$diff_in_qnty;
								$new_qnty_stock_21=$stock_table_qnty_2+$diff_in_qnty;

								 $this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_qnty_stock_11),array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_to')));

								 $this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_qnty_stock_21),array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_from') ));
							}
						}
					}
					else////update for the new values added on update///
					{
					 $this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_qnty_stock_1),array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_to')));

					 $this->tm->update_data('stock_details',array('sd_stock_qnty'=>$new_qnty_stock_2),array('sd_prd_id'=>$pds,'sd_warehouse_id'=>$this->input->post('ps_transfer_from') ));
					}							
				}

	  	
		// 	/////////////////////end here , stock details table////////////////
	} ///end for each


$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'stock_transfer created',
				'act_status'=>'stock_transfer id '.$insert_id,
				'act_type'=>'Stock Transfer',/////will be based on type, the activity will be extracted////
				'act_type_id'=>$insert_id,
				'act_sales_inv_page_type'=>$page_type,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time(),
					
			);
if(empty($added_ps_id))
	$this->Admin_model->insert_data('activities',$activity_data);

	if(empty($added_ps_id))
	{
		$this->session->set_flashdata('success', 'Data Successfully inserted');	
		redirect('list-transfer-stock');
	}
	else
	{
		$this->session->set_flashdata('success', 'Data Successfully updated');	
		redirect('list-transfer-stock');
	}
}
function list_current_stock()
{
	if(logged_in())
	{

$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-current-stock')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


		// $sql2=$this->db2->query("SELECT sum(stock_details.sd_stock_qnty) as tot_qnty,products.pname,products.pcode,stock_details.sd_suggested_qnty
		// FROM stock_details join products  on products.pid=stock_details.sd_prd_id 
		// WHERE products.p_sts = '1' group by stock_details.sd_prd_id  order by stock_details.sd_id DESC");
		// $data['result']=$sql2->result_array();
		$data['warehouse']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1'));
		//pre_list($data['result']);
		$this->load->view('admin/stocks/list_current_stock',$data);
}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  



		
	}
}
function get_current_stock_warehouse()
{
if(logged_in())
	{
	$warehouse_id=$this->input->post('warehouse_id');
		if ($warehouse_id!=''	) {

/////try to put our code for updating the quantity and sync with shpify website////////////////

///  When Other shopify websites be ready we will put the conditions to get  $shopify_products depending on the whare house but now we have only one shopify website 
if($warehouse_id=='23'){
	$curl = curl_init();
	$url="https:///biri-group.myshopify.com/admin/api/2022-10/products.json";
	// dd($url);
	curl_setopt_array($curl, array(
	  CURLOPT_URL => $url,
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_SSL_VERIFYHOST => 0,
	  CURLOPT_SSL_VERIFYPEER => 0,
	  CURLOPT_TIMEOUT => 30000,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => 'GET',
	  CURLOPT_HTTPHEADER => array(
		"X-Shopify-Access-Token: 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",
		"Content-Type: application/json",
	  ),
	));
	$response = curl_exec($curl);
	$err = curl_error($curl);
	curl_close($curl);
	$shopify_products = json_decode($response);

//   print_r($shopify_products);exit();
	////////////////////////////////////End Of Part Get Product From Shopify///////////////////
	$Wharehouse_uae='23';
	////part to get The produce exist in dashboard and shopify together////////////////////
	$sql2=$this->db2->query("SELECT stock_details.sd_stock_qnty as tot_qnty,products.pname,products.pcode,products.p_prd_img,products.pcat,stock_details.sd_prd_id as prd_id
		FROM stock_details join products  on products.pid=stock_details.sd_prd_id WHERE products.p_sts = '1' and stock_details.sd_warehouse_id='".$warehouse_id."' group by stock_details.sd_prd_id  order by stock_details.sd_stock_qnty DESC ");
		$result=$sql2->result_array();
	$sku_array = array();
	$inventory_array=array();
	$common_product=array();
	$common_product_qntydash=array();
	$common_product_qntyshop=array();
	$common_product_id=array();
	foreach($shopify_products->products as $key => $shopify_product)
			{
				
				$sku_array[$key]=$shopify_product->variants[0]->sku;
				$inventory_array[$key]=$shopify_product->variants[0]->inventory_quantity;
			}
		 foreach($result as $key_pr => $prsku){
			foreach($sku_array as $key_key => $sku)
			 {
					if($prsku[pcode]==$sku)
			 {
				 $common_product[]=$prsku[pcode];
				 $common_product_id[]=$prsku[prd_id];
				 $common_product_qntydash[]=$prsku[tot_qnty];
				$common_product_qntyshop[]=$inventory_array[$key_key];
		 
			}
			else{
			  // print_r('NO');
			}
	
	
			 }
		  
		}

	foreach($common_product as $key_prd => $sku)
			 {
	             // print_r('matched');
				$this->tm->update_data('stock_details',array('sd_stock_qnty'=>$common_product_qntyshop[$key_prd]),array('sd_prd_id'=>$common_product_id[$key_prd],'sd_warehouse_id'=>$warehouse_id));
	
			 }

		//	 exit();
}
else
{


         		 $data['warehouse_name']=$this->Admin_model->get_data('master_warehouse',array('mw_id'=>$warehouse_id));
	
    $sql2=$this->db2->query("SELECT stock_details.sd_stock_qnty as tot_qnty,products.pname,products.pcode,products.p_prd_img,products.pcat
		FROM stock_details join products  on products.pid=stock_details.sd_prd_id WHERE products.p_sts = '1' and stock_details.sd_warehouse_id='".$warehouse_id."' group by stock_details.sd_prd_id  order by stock_details.sd_stock_qnty DESC ");
		$result=$sql2->result_array();






}
///////////////////end shoopify sync/////////////////////////////

	


}
else {
          $data['warehouse_name']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1'));
    
	$sql2=$this->db2->query("SELECT sum(stock_details.sd_stock_qnty) as tot_qnty,products.pname,products.pcode,stock_details.sd_suggested_qnty,products.p_prd_img,products.pcat
		FROM stock_details join products  on products.pid=stock_details.sd_prd_id 
		WHERE products.p_sts = '1' group by stock_details.sd_prd_id  order by stock_details.sd_stock_qnty DESC");

}





	$data['warehouse']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1'));

		
		$data['result']=$sql2->result_array();

$this->load->view('admin/stocks/list_current_stock',$data);


	}
}



function list_low_stock()
{
	if(logged_in())
	{

$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-current-stock')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


		$sql2=$this->db2->query("SELECT sum(stock_details.sd_stock_qnty) as tot_qnty,products.pname,products.pcode,stock_details.sd_suggested_qnty
		FROM stock_details join products  on products.pid=stock_details.sd_prd_id 
		WHERE stock_details.sd_stock_qnty <='10' and  products.p_sts = '1' group by stock_details.sd_prd_id  order by stock_details.sd_stock_qnty ASC");
		$data['result']=$sql2->result_array();
		$data['warehouse']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1'));
		//pre_list($data['result']);
		$this->load->view('admin/stocks/list_low_stock',$data);
}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  



		
	}
}



function get_Low_stock_warehouse()
{
	$warehouse_id=$this->input->post('warehouse_id');
		$sql2=$this->db2->query("SELECT sum(stock_details.sd_stock_qnty) as tot_qnty,products.pname,products.pcode
		FROM stock_details join products  on products.pid=stock_details.sd_prd_id WHERE  stock_details.sd_stock_qnty <='10' and  products.p_sts = '1' and stock_details.sd_warehouse_id='".$warehouse_id."' group by stock_details.sd_prd_id  order by stock_details.sd_stock_qnty ASC");
		$result=$sql2->result_array();

	if(!empty($result))
	{
		foreach($result as $t)
		{
		$html='<tr>
			<td>'.$t['pname'].'</td>		
			<td>   '.$t['pcode'].'  </td>	
		    <td> <p class="errors"> '.$t['tot_qnty'].'  </p> </td> 
		   </tr>';
		   echo $html;
		}
	}
}


function stock_delivery_report($page_type)
{
	if(logged_in())
	{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='stock-delivery-report')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



		if($page_type=="uae")
		{
			$table1='stock_delivery_details';
			$table2='delivery_note';
		}
		elseif($page_type=="ksa")
		{
			$table1='stock_delivery_details_ksa';
			$table2='delivery_note_ksa';
		}
		elseif($page_type=="dragon")
		{
			$table1='stock_delivery_details_dragon';
			$table2='delivery_note_dragon';
		}
		else
		{
			$table1='stock_delivery_details_export';
			$table2='delivery_note_export';
		}
		$sql=$this->db->query('SELECT sd.*,mw.mw_name,dlv.dn_doc_no from '.$table1.' as sd 
			join master_warehouse as mw on mw.mw_id = sd.sd_warehouse_id 
			join '.$table2.' as dlv on dlv.dn_id =sd.sd_delivered_id where sd.sd_sts="1"
			');
		// print_r('SELECT sd.*,mw.mw_name,dlv.dn_doc_no from '.$table1.' as sd 
		// 	join master_warehouse as mw on mw.mw_id = sd.sd_warehouse_id 
		// 	join '.$table2.' as dlv on dlv.dn_id =sd.sd_delivered_id where sd.sd_sts="1"');
		$data['result']=$sql->result_array();
	$this->load->view('admin/stocks/stock_delivery_report',$data);


}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


	}
}







function price_shopify($page_type)
{
	if(logged_in())
	{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='stock-delivery-report')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

  //Get All Shopify Product 
							//////this adjusment section will be different depending on the page wether ksa or uae or canada

		if($page_type=="uae")	
							{	

												

					       $shopify_products = json_decode( file_get_contents('https://3527ef9b39427d1d11184c88b2940757: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@biri-group.myshopify.com/admin/api/2022-10/products.json?limit=250'));
									//$shopify_products = json_decode($shopify_products);
									
	                         
									////test end ////
									foreach($shopify_products->products as $key => $shopify_product)
									{
										
										$sku_array[$key]=$shopify_product->variants[0]->sku;
									//	$inventory_array[$key]=$shopify_product->variants[0]->inventory_quantity;
									//	$inventory_item_array[$key]=$shopify_product->variants[0]->inventory_item_id;
                                       $price_array[$key]=$shopify_product->variants[0]->price;

										 $product_id_array[$key]=$shopify_product->variants[0]->product_id;
									}

								// 	print_r($sku_array);
								// 	print_r($price_array);
									
								//  	print_r($product_id_array);
								//  exit();

                   
                                // print_r($shopify_product->variants[0]);exit();
									$headerss = array(
										'X-Shopify-Access-Token: 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',
										'Content-Type: application/json'
										
									);
				                    	// // Get the location ID for the inventory level update
									// $location_url = 'https://biri-group.myshopify.com/admin/api/2022-10/locations.json';
									// //$location_response = shopify_api_call('GET', $location_url, array(), $headers);
									

									// $curl = curl_init();
									// curl_setopt($curl, CURLOPT_URL, $location_url);
									// curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
									// curl_setopt($curl, CURLOPT_HTTPHEADER, $headerss);
									// curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
									// $location_response = curl_exec($curl);
									// curl_close($curl);
									// $test3=json_decode($location_response);
									// $location_id = $test3->locations[1]->id; // Replace 0 with the index of the location you want to use
             }







		elseif($page_type=="ksa")
		{
        
		 print_r('ksa here');exit();
			$table1='stock_delivery_details_ksa';
			$table2='delivery_note_ksa';
		}
		elseif($page_type=="dragon")
		{
			print_r('dragon here');exit();
			$table1='stock_delivery_details_dragon';
			$table2='delivery_note_dragon';
		}
		else
		{
			print_r('nope here');exit();
			$table1='stock_delivery_details_export';
			$table2='delivery_note_export';
		}

		 $stock_product_id_sku=$this->tm->get_data('products',array('p_sts'=>'1'));
         foreach($stock_product_id_sku as $ind=>$prd)
		 {	
			 $sku_prod[]=$prd->pcode;
			 $price_before[]=$prd->p_selling_price;
			 //if worked we will make it ($prd->p_selling_price+(($prd->p_selling_price)*0.15))
              $toshopify_item_price[]=($prd->p_selling_price+(($prd->p_selling_price)*0.15));
		 }
	 
		 $exist=0;
		 $notexist=0;
		  foreach($sku_prod as $key_dash=>$sku_dash)
		 {
			 foreach($sku_array as $key_key=>$sku)
			{
                  if($sku_array[$key_key]==$sku_dash) 
				  {
                    if($sku_array[$key_key]==''||$sku_array[$key_key]==' ')
				    {
					
					}
				 else{

						 //item sku matching
					  $item_sku_prod[]=$sku_array[$key_key];
					 
					  //price in dashboard
					  $item_price_before[]=$price_before[$key_dash];
					  //price in shopify
					   $price_on_shopify[]=$price_array[$key_key];
                    // $item_price[]=$toshopify_item_price[$key_dash];


					 //$test_sku[]=$sku_dash;
					  $product_id_fromshopify[]=$product_id_array[$key_key];

					   $product_matching[]=$this->tm->get_data('products',array('pcode'=>$sku_array[$key_key]));

					}
					$exist++;

				  }
				  else{
					  // $test_sku[]='';
                      $notexist++;
				  } 
				           
			}
               
			        
		 }
//print_r($product_matching);
//  print_r($item_sku_prod);
//   print_r($item_price_before);
// // // print_r($item_price);
//   print_r($price_on_shopify);
//  print_r($product_id_fromshopify);

 //exit();

		
		 foreach($item_sku_prod as $kt=>$ee)
		 {
			// $data['dashboard_prd_id'][]=$product_matching[$kt][0]->pid;
			// $data['p_prd_img'][]=$product_matching[$kt][0]->p_prd_img;
			// $data['pcode'][]=$product_matching[$kt][0]->pcode;
			// $data['pname'][]=$product_matching[$kt][0]->pname;
			// $data['price_on_shpify'][]=$price_on_shopify[$kt];
			// $data['price_on_dashboard'][]=$item_price_before[$kt];
			// $data['shopify_prd_id'][]=$product_id_fromshopify[$kt];


			 $data['result'][]=array(
			'dashboard_prd_id'=>$product_matching[$kt][0]->pid,
			'p_prd_img'=>$product_matching[$kt][0]->p_prd_img,
			'pcode'=>$product_matching[$kt][0]->pcode,
			'pname'=>$product_matching[$kt][0]->pname,
			'price_on_shpify'=>$price_on_shopify[$kt],
			'price_on_dashboard'=>$item_price_before[$kt],
			'shopify_prd_id'=>$product_id_fromshopify[$kt],
			'p_purchase_price'=>$product_matching[$kt][0]->p_purchase_price,
		
			);
			
			// print_r($product_matching[$kt][0]->pcode);

             // print_r($item_sku_prod[$kt].',');
			   // print_r('|');
		 }
		$data['page_type']=$page_type;
	// foreach($data['result'] as $index11=>$t)
    // {  
    //  print_r($t[pcode]);
    //    ///print_r($index11);

    //  }

	// // print_r($dd);
	// exit();
       $this->load->view('admin/production/adjust_pricing_with_shopify',$data);
		
		

		//pass the data to view it then update it again :


//      foreach($test_sku as $ke=>$item_id)
//                          {   
//                            print_r($product_id_fromshopify[$ke]); 

// 						  }


}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


	}
}





function submit_prd_pricing_all()
{
if(logged_in())
	{
	
	// $this->Admin_model->insert_data('prd_grps_pricing',array('gc_grp_main_id'=>$this->input->post('main_grp_id'),'gc_grp_sub_name'=>$this->input->post('add_sub_prd_name'),'gc_sts'=>'1'));
    $main_code=$this->input->post('main_prd_code');
		
    $main_prd_id=$this->input->post('main_prd_id');
	
	$main_prd_id_shopify=$this->input->post('main_prd_id_shopify');

	$page_type=$this->input->post('page_type');
	
$final_price=$this->input->post('add_prd_price_dashboard');
$uae1_percentage=$final_price*0.10;
$p_uae_l1=$final_price+$uae1_percentage;

$p_uae_l2_percentage=$final_price*0.25;
$p_uae_l2=$final_price+$p_uae_l2_percentage;

$p_uae_l3_percentage=$final_price*0.35;
$p_uae_l3=$final_price+$p_uae_l3_percentage;

$p_ksa_percentage=$final_price+12.5;
$p_ksa=$final_price+12.5;

$p_ksa_reg_1_percentage=$p_ksa*(0.10);
$p_ksa_reg_1=$p_ksa+$p_ksa_reg_1_percentage;

$p_ksa_comp_2_perc=$p_ksa*(0.20);
$p_ksa_comp_2=$p_ksa+$p_ksa_comp_2_perc;

$p_ksa_retail_3_per=$p_ksa*(0.50);
$p_ksa_retail_3=$p_ksa+$p_ksa_retail_3_per;

$datadashboard=array(
			'p_selling_price'=>$this->input->post('add_prd_price_dashboard'),
			'p_uae_final'=>$this->input->post('add_prd_price_dashboard'),
			'p_uae_l1'=>$p_uae_l1,
		    'p_uae_l2'=>$p_uae_l2,
			'p_uae_l3'=>$p_uae_l3,
			'p_ksa'=>$p_ksa,
			'p_ksa_reg_1'=>$p_ksa_reg_1,
			'p_ksa_comp_2'=>$p_ksa_comp_2,
			'p_ksa_retail_3'=>$p_ksa_retail_3,
			
			
			
			
			);

	$this->tm->update_data('products',$datadashboard,array('pcode'=>$main_code));


 $data_focus=array(
	 'prd_id'=>$main_prd_id,
	 'prd_code'=>$main_code,
	 'prd_price_new'=>$this->input->post('add_prd_price_dashboard'),
	 'active_sts'=>'0',
	 'changed_by'=>$this->session->userdata['user']['username'],
	 'date_create'=>get_date(),
	 'date_update'=>get_date()

 );

$this->tm->insert_data('focus_price_statue',$data_focus);

 $this->send_mail_checking($main_code,$final_price);

   $price_on_shpify=$this->input->post('add_prd_price_shopify');








	// $data=array(
	// 		'purchase_price'=>$this->input->post('add_prd_purchase'),
	// 		'shipping_val_perce'=>$this->input->post('add_prd_shipp_perce'),
	// 		'added_val_perce'=>$this->input->post('add_prd_addedval_perce'),
	// 		 'alert_qnty'=>$this->input->post('alert_qnty_uk'),
	// 		'bin_capacity'=>$this->input->post('bin_capacity_uk'),
	// 		);

	// $this->ukdb->update_data('products',$data,array('id'=>$main_prd_id));
        
			$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'Product Pricing',
				'act_status'=>'product  code ('.$main_code.')  mkae Change in the Pricing for shopify and dashboard ',
				
			     'act_doc_num'=>$main_code,
				'act_type'=>'Product Pricing ',
				
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()
			);
			   $this->Admin_model->insert_data('activities',$activity_data); 
	


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           
		               	////////////////start sopify part 2////////////////////////

	               $headerss = array(
										'X-Shopify-Access-Token: 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',
										'Content-Type: application/json'
										
									);


			if($page_type=="uae")
			{
				
								$productData = array(
								'product' => array(
									'id' => $main_prd_id_shopify,
									'variants' => array(
										array(
											'price' =>  $price_on_shpify,
											'sku'=>$main_code
										)
									)
								)
							);
							
                            $updateprice_url ='https://biri-group.myshopify.com/admin/api/2022-10/products/'.$main_prd_id_shopify.'.json';
						
							$curl = curl_init();
							curl_setopt($curl, CURLOPT_URL, $updateprice_url);
							curl_setopt($curl, CURLOPT_CUSTOMREQUEST,'PUT');
							curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($productData));
							curl_setopt($curl, CURLOPT_HTTPHEADER, $headerss);
							curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
							$responsess = curl_exec($curl);
							curl_close($curl);
						
				
				}



				
            // if($page_type=="uae")
			// {
			// 	if(!empty($product_id_array)){
            //                  foreach($product_id_array as $ke=>$inventory_item_idn)
            //              {
			// 						$inventory_item_id=$inventory_item_idn;				
			// 						$datashop[$ke] = array(
			// 				'location_id' => $location_id,
			// 				'inventory_item_id' => $inventory_item_id,
			// 					'available' => $avlb_stock_arr[$ke] // Replace with the new inventory level
			// 				);

			// 				$curl = curl_init();
			// 				curl_setopt($curl, CURLOPT_URL, $inventory_url);
			// 				curl_setopt($curl, CURLOPT_CUSTOMREQUEST,'POST');
			// 				curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($datashop[$ke]));
			// 				curl_setopt($curl, CURLOPT_HTTPHEADER, $headerss);
			// 				curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			// 				$responsess = curl_exec($curl);
			// 				curl_close($curl);
			// 			}	
			// 	}
			// 	}

				
				/////////////////////end sopify part 2/////////////////////////////////////////     


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////









    

 		$this->session->set_flashdata('success', 'New Pricing added successfully');
 		redirect('shopify-price-test/'.$page_type);
		   
 	}
}








function view_list_new_pricing()
{


	if(logged_in())
	{

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-check-new-price')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            
            	{$excist=false;}

         }
       if ($excist) {



	
			$table1='focus_price_statue';
		
	
		$sql=$this->db2->query('SELECT fb.*,p.* from '.$table1.' as fb 
			join products as p on p.pid = fb.prd_id 
			 where fb.active_sts="0"
				');
	  //print_r('teast');exit();
		$data['result']=$sql->result_array();

    // print_r($data);
    // exit();
	$this->load->view('admin/stocks/view_list_new_pricing',$data);


}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


	}
}




function approve_pricing($prd_id)
{
	if(logged_in())
	{
	
    
	
$data['active_sts']=1;

$data['date_update']=get_date();

                    $this->tm->update_data('focus_price_statue',$data,array('prd_id'=>$prd_id) );	
 
					



 


		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'checking approve for prd',
			'act_status'=>'product '.$prd_id.' approved checking',
			'act_receipt_id'=>$prd_id,
			  'act_doc_num'=>$prd_id,
				'act_type'=>'product price ',
				'act_type_id'=>$prd_id,
				'act_date'=>get_date(),
				'act_time'=>get_time(),
				'act_date_time'=>get_date_time()

		);
		  $this->Admin_model->insert_data('activities',$activity_data);

		  $this->session->set_flashdata('success', 'Data Successfully checked');
	redirect('list-check-new-price');
	}
}






	function send_mail_checking($main_code,$final_price)
{
	     $this->load->library('email');
        //  $config['protocol'] = "smtp";
         $config['mailpath']     = "/usr/bin/sendmail";
         $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
         $config['smtp_crypto'] = 'tls'; 
         $config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;

      $this->email->initialize($config);

$page_user= $this->session->userdata['user']['username'];

$page_email=$this->session->userdata['user']['user_email'];

$page_state=$this->session->userdata['user']['state'];

$date_time=get_date_time();


          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to("sales1@birigroup.com");
		  $CI->email->cc(array('support@birigroup.com','sales4@birigroup.com'));
		  // $this->email->to("");
         // $this->email->to($page_email);    

          $this->email->subject('Checking Product New Pricing');
		 $msg="Dear Employee  , <br/> Management Made Change Price of Product ((  ".$main_code."  ))<br/><br/>";

		 
         $msg.="The New Price is :  "  .$final_price."  AED <br/><br/>";

	 $msg.="Changed By:  "  .$page_user."<br/><br/>";
		
		  $msg.="<br/><br/>";
 $msg.="Please Check The Same Price In Focus And Do The Necessary And Check New Price List to make Approve That You made the change <br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}



















}