<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Study_stock extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','email_survey'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
		$this->load->library('numbertowordconvertsconver');		
		 $this->db2 = $this->load->database('three', TRUE);	
	}
//// will how page that will select our condition for the statistical suggusted including wharehouse name and date we must return to  
function study_stock_qnty($os=null)
{
	if(logged_in())
	{
     $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		 $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	 if ((($page_cred[$i]=='study-stock-qnty')||($this ->session->userdata['user']['main_dept'])=="Main"))  
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {




       
      $data['warehouse']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));

	
		$this->load->view('admin/stocks/study_stock_qnty',$data);

}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}
// it will give this query to handle it and save it in another database table
/////it will take the query from the other page when it take the information then redirect to other page when we will use the new table and show what we need 
function submit_wharehouse_stock()
{

	
   


	if(logged_in())
	{
     $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		 $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	 if ((($page_cred[$i]=='study-stock-qnty')||($this ->session->userdata['user']['main_dept'])=="Main"))  
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

          	$warehouse_id=$this->input->post('warehouse_id');

          	if(!empty($warehouse_id)){
                           
          		 $this->tm->delete_data('study_prd_qnty',array('warehousenum'=>$warehouse_id));


          	}

     if($warehouse_id=='19'){
		 $sql2=$this->db->query("SELECT si_doc_no,si_warehouse,si_product,si_qnty,si_date FROM sales_invoice_dragon WHERE si_sts = '1' and si_warehouse like '%".$warehouse_id."%' and si_delivery_sts LIKE 'delivered' and si_date >='2021/06/29'  ORDER BY si_date DESC");
		$result=$sql2->result_array();

	 }
	 else  if($warehouse_id=='30'){ 
		 $sql2=$this->db->query("SELECT si_doc_no,si_warehouse,si_product,si_qnty,si_date FROM sales_invoice_ksa WHERE si_sts = '1' and si_warehouse like '%".$warehouse_id."%' and si_delivery_sts LIKE 'delivered' and si_date >='2021/06/29'  ORDER BY si_date DESC");
		$result=$sql2->result_array();
	 }
	


 
if(!empty($result)){

foreach($result as $t)
{
	


$si_doc_no=explode('|#|',$t['si_doc_no']);



 $si_warehouse=explode('|#|',$t['si_warehouse']);
 $si_product=explode('|#|',$t['si_product']);
 $si_qnty=explode('|#|',$t['si_qnty']);
$si_date=explode('|#|',$t['si_date']);

 


  $wh_count=count($si_warehouse);
$wh=0;
while($wh< $wh_count)
{

	
 $data_doc[$wh]=$si_doc_no[$wh];
 $data_whs[$wh]=$si_warehouse[$wh];
 $data_pd[$wh]=$si_product[$wh];
 $data_qnt[$wh]=$si_qnty[$wh];
 $data_dat[$wh]=$si_date[$wh];

$data_st['inv_num']= $data_doc[$wh];
  $data_st['warehousenum']=$data_whs[$wh];
 $data_st['pid']=$data_pd[$wh];
  $data_st['qnty']=$data_qnt[$wh];
  $data_st['inv_date']= $data_dat[$wh];



		$html='<tr>
			<td>'.$data_doc[$wh].'</td>		
			<td>   '.$data_whs[$wh].'  </td>	
		    <td> <p class="errors"> '.$data_pd[$wh].'  </p> </td> 
		    <td>   '.$data_qnt[$wh].'  </td>	
		    <td>   '.$data_dat[$wh].'  </td>	
		   </tr>';
		   echo $html;



 $this->tm->insert_data('study_prd_qnty',$data_st);


$wh++;
 }




}

}



$datawharehouse['wharehousevalue']=$warehouse_id;
      //$data['warehouse_data']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));

	
		$this->load->view('admin/stocks/suggested_stock_qnty',$datawharehouse);

}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}




function filter_type()
{
	if(logged_in())
	{
	$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		 $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	 if ((($page_cred[$i]=='study-stock-qnty')||($this ->session->userdata['user']['main_dept'])=="Main"))  
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

          	$warehouse_id=$this->input->post('warehouse');
       

	$sql2=$this->db->query(" SELECT si_doc_no,si_warehouse,si_product,si_qnty,si_date FROM sales_invoice_ksa WHERE si_sts = '1' and si_warehouse like '%".$warehouse_id."%' and si_delivery_sts LIKE 'delivered' and si_date >='22/06/2021'  ORDER BY si_date DESC");
		$result=$sql2->result_array();


$html.="</tbody>";
	//pre_list($data['result']);
	$html= "<table class='table table-bordered table-striped mb-none' id='datatable-default2'>
	 <thead>
        <tr>
         <th></th>
           <th>Invoice Doc</th>
            <th>WhareHouse ID</th>
			<th>Product ID</th>
			<th>Qnty</th>
			<th>Sales Date</th>
        </tr>
    </thead>
    <tbody>";
		$ij=1;




		foreach($result as $t)
{
	


$si_doc_no=explode('|#|',$t['si_doc_no']);



 $si_warehouse=explode('|#|',$t['si_warehouse']);
 $si_product=explode('|#|',$t['si_product']);
 $si_qnty=explode('|#|',$t['si_qnty']);
$si_date=explode('|#|',$t['si_date']);

 


  $wh_count=count($si_warehouse);
$wh=0;
while($wh< $wh_count)
{

	
 $data_doc[$wh]=$si_doc_no[$wh];
 $data_whs[$wh]=$si_warehouse[$wh];
 $data_pd[$wh]=$si_product[$wh];
 $data_qnt[$wh]=$si_qnty[$wh];
 $data_dat[$wh]=$si_date[$wh];

$data_st['inv_num']= $data_doc[$wh];
  $data_st['warehousenum']=$data_whs[$wh];
 $data_st['pid']=$data_pd[$wh];
  $data_st['qnty']=$data_qnt[$wh];
  $data_st['inv_date']= $data_dat[$wh];


   $html="<tr>";

	$html.="<td>".$ij++."</td>";
			$html.="<td>#".$data_doc[$wh]."</td>";
			$html.="<td>".$data_whs[$wh]."</td>";
			$html.="<td>".$data_pd[$wh]."</td>";
		  $html.="<td>".$data_qnt[$wh]."</td>";
		  $html.="<td>".$data_dat[$wh]."</td>";

		 $html.= "</tr>";
		  
		   // echo $html;

 $this->tm->insert_data('study_prd_qnty',$data_st);


$wh++;
 }




}



	$html.="</tbody></table>";
		
		echo $html;

		
	}

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}

	
}
}













function new_sugussted_stock()
{
	if(logged_in())
	{
     $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		 $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	 if ((($page_cred[$i]=='study-stock-qnty')||($this ->session->userdata['user']['main_dept'])=="Main"))  
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


          $data['warehouse']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));


$data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));

	
		$this->load->view('admin/stocks/new_sugussted_stock',$data);




}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}












function suggested_stock_qnty()
{
	if(logged_in())
	{

  
 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='study-stock-qnty')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {
             


//   $data['warehouse']=$this->Admin_model->get_data('master_warehouse',array('mw_sts'=>'1','mw_status'=>'1','mw_parent !='=>'0'));


// $data['products_list']=$this->tm->get_data('products',array('p_sts'=>'1'));
$warehouse_id=$this->input->post('wh_id');


$prod_id=$this->input->post('pd_id');


// $wharehouse_id=$this->input->post('wharehouse_id');
// $prod_id=$this->input->post('product_id');


	//$sqlyaerly=$this->db->query(" SELECT * FROM study_prd_qnty WHERE warehousenum = '.$warehouse_id.'  and pid >='.$prod_id.'  ");
	$sqlyaerly=$this->db2->query(" SELECT sum(qnty) as 'qqq' FROM study_prd_qnty WHERE warehousenum = $warehouse_id and pid = $prod_id ");
		

		$resultyaerly=$sqlyaerly->result_array();



  $arr=array_values($resultyaerly[0]);


    
foreach($arr as $val) {






$stock_level_quarter=intval($val /4);

}

$this->tm->update_data('stock_details',array('sd_suggested_qnty'=>$stock_level_quarter),array('sd_prd_id'=>$prod_id,'sd_warehouse_id'=>$warehouse_id));


if ($stock_level_quarter > 0)
{ 
	   print_r('yearly Qauntity is : '  .$val. ' and The  ');
	 print_r('Sugussted for quarter  is :'  .$stock_level_quarter);


}
else {
	 print_r('this Product Not Exist in this wharehouse or there is no sales for it ');
}
  
  
	
		//$this->load->view('admin/stocks/list_opening_stock',$data);










}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  

	}
}



















}