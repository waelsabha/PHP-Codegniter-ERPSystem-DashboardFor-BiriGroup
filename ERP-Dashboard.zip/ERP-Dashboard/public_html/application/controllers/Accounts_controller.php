<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts_controller extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','gnrl'));
	}
	
function submit_lstacc_sorting()
{
if(logged_in())
	{
	$cash_type=$this->input->post('cash_type');
	$bank_name=$this->input->post('bank_name');
	$month_selected=$this->input->post('month_selected');
	$year_selected=$this->input->post('year_selected');
	$start_date_rng=$this->input->post('start_date_rng');
	$end_date_rng=$this->input->post('end_date_rng');
	$date_entred=$this->input->post('date_entred');

	if(!empty($start_date_rng))
	$date_range_start= date("Y-m-d", strtotime($start_date_rng));
	else
		$date_range_start='';
	
	if(!empty($end_date_rng))
	$date_range_end= date("Y-m-d", strtotime($end_date_rng));
	else
		$date_range_end='';

	if(!empty($date_entred))
	$date_entred_val= date("Y-m-d", strtotime($date_entred));
	else
		$date_entred_val='';

	$order_by=('ae_date');
	$order_type="ASC";
	$data['result']=$this->Admin_model->get_data_list_account($cash_type,$bank_name,$month_selected,$year_selected,$date_range_start,$date_range_end,$date_entred_val,'','',$order_by,$order_type);

	$data['selection_val']=array(
		'cash_type'=>$cash_type,
		'bank_name'=>$bank_name,
		'month'=>$month_selected,
		'year'=>$year_selected,
		'start_date'=>$start_date_rng,
		'end_date'=>$end_date_rng,
		'entry_date'=>$date_entred,
	);


	$selection['selection_val']=array(
		'cash_type'=>$cash_type,
		'bank_name'=>$bank_name,
		'month'=>$month_selected,
		'year'=>$year_selected,
		'start_date'=>$start_date_rng,
		'end_date'=>$end_date_rng,
		'entry_date'=>$date_entred,
	);
	//print_r($data);

	$this->session->set_userdata($selection);

$this->load->view('admin/list_accounts',$data);
  }
}



function reconcile_entries($reconcilled=null)
{
if(logged_in())
 {
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
        if ((($page_cred[$i]=='reconcile_entries')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

	if(empty($reconcilled))
	{
		$order_by=('ae_date');
		$order_type="ASC";
	$data['result']=$this->Admin_model->get_data('account_entry1',array('ae_reconcile'=>'0','ae_status'=>'1','ae_desc !='=>'Opening Balances'),'','',$order_by,$order_type);
	$this->load->view('admin/reconcile',$data);
	}
	else
	{
		$order_by=('ae_date');
		$order_type="ASC";
	$data['result']=$this->Admin_model->get_data('account_entry1',array('ae_reconcile'=>'1','ae_status'=>'1','ae_desc !='=>'Opening Balances'),'','',$order_by,$order_type);
	$data['page_name']="list_reconcilled";
	$this->load->view('admin/reconcile',$data);
	}

}
     else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	    	redirect('login','refersh');
	}


  }

}

function reconcile_data_now($id)
{
if(logged_in())
 {
$cond1=array('ae_id'=>$id);
$data1=array('ae_reconcile'=>'1');
$qry=$this->Admin_model->update_data('account_entry1',$data1,$cond1);
 $this->session->set_flashdata('success', 'Data successfully reconciled');
redirect('reconcile_entries');
 }
}

function un_reconcile_data_now($id)
{
if(logged_in())
	{
$cond1=array('ae_id'=>$id);
$data1=array('ae_reconcile'=>'0');
$this->Admin_model->update_data('account_entry1',$data1,$cond1);
 $this->session->set_flashdata('success', 'Data successfully un-reconciled');
redirect('reconcile_entries');
  }
}

function list_pending_tx()
{
if(logged_in())
		{
	$Today = date("Y-m-d");
	$cond=array('ae_status'=>'1','ae_status_data' =>'1','ae_date <='=>$Today);
	$order_by='ae_date';
$order_type="ASC";
$data['pending_tx']=$this->Admin_model->get_data('account_entry1',$cond,'','',$order_by,$order_type);

$this->load->view('admin/list_pending_tx',$data);

 }
}

function update_date_id()
{
	$table_id=$this->input->post('table_id');
	$date_updated=$this->input->post('date_updated');
	$dt = new DateTime($date_updated);

$date_s = $dt->format('m/d/Y');
$time_s = $dt->format('g:i A');

//echo $date_s, ' | ', $time_s;

$convert_time=date("H:i:s", strtotime($time_s));
  $date = str_replace("/", "-", $date_s);             	

$date1=explode('-', $date);
			$month=$date1[0];
			$date=$date1[1];
			$year=$date1[2];
$new_formated_date=$year.'-'.$month.'-'.$date;

	$data=array('ae_date'=>$new_formated_date,
                   	'ae_time'=>$convert_time,
                   	'ae_month'=>$month,
                   	'ae_year'=>$year);
		$cond=array('ae_id'=>$table_id);
		$qry=$this->Admin_model->update_data('account_entry1',$data,$cond);

	
$bal_amount=$this->Admin_model->get_data('account_entry1',array('ae_id'=>$table_id));
	$bank_name=$bal_amount[0]->ae_bank;

	$bank_bal['bal_update']=array(
		'bank_name_updated'=>$bank_name,
		);
	$this ->session->set_userdata($bank_bal);	

	// $cond2=array('ae_id'=>$table_id);
	// $data['result']=$this->Admin_model->get_data('account_entry1',$cond2);			 	
		if($qry)
			echo $new_formated_date;
			//echo TRUE;
}


function list_opening_bal()
{
if(logged_in())
      {

 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
        if ((($page_cred[$i]=='list_opening_bal')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



							$banks_array=array('ADIB-BBMS','ADIB-Factory','ENBD','EI Bank','Cash Mr. Bachir Book','Cash Garhoud','Cash Factory','Other Bank');
						foreach($banks_array as $bank)
						{
							$cond_new=array('ae_bank'=>$bank);
								$opening_bal_bbms=$this->Admin_model->get_opening_bal($cond_new);
							$val[]=$opening_bal_bbms[0]->ae_amount;
						}

						$data['bank_name']=$banks_array;
						$data['base_val']=$val;
							$cond=array('ae_status'=>'1','ae_desc' =>'Opening Balances','ae_date !='=>'2019-05-31');
							$order_by='ae_date';
						$order_type="ASC";
						$data['result']=$this->Admin_model->get_data('account_entry1',$cond,'','',$order_by,$order_type);

							$this->load->view('admin/list_opening_bal',$data);

}
     else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	    	redirect('login','refersh');
	}


	
	}
}

function edit_opening_bal()
{
	echo $this->input->post('new_bal');
	echo "<br/>";
	echo $this->input->post('table_id');
$data1=array('ae_amount'=>$this->input->post('new_bal'));
$cond1=array('ae_id'=>$this->input->post('table_id'),'ae_desc'=>'Opening Balances');
$this->Admin_model->update_data('account_entry1',$data1,$cond1);
echo $this->input->post('new_bal');
}

















}