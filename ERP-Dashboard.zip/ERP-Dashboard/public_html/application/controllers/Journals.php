<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Journals extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
		$this->load->library('numbertowordconvertsconver');	
	}


function create_journal($id=null)
{
	if(logged_in())
	{

$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		  $cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ((($page_cred[$i]=='create-journal')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



		$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'create-journal'));

		$salesman=$this->Admin_model->get_data('login_credentials',array('log_dept'=>'Sales', 'log_status !='=>'0'));
		foreach($salesman as $s)
		{
			$data['salesman'][]=$this->Admin_model->get_data('employee_details',array('ed_login_id'=>$s->log_id));
		}
				$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree ");////TO GET OPERATING EXPENSE A/C NAMES AND CUSTOMER A/C NAMES COMBINED
			$data['customers']=$sql_cust->result_array();
		$data['company_masters']=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
		$data['currency_convt']=$this->Admin_model->get_data('master_currency_conv',array('c_sts'=>'1'));
		$data['place_supply']=$this->Admin_model->get_data('master_place_supply',array('mps_sts'=>'1'));
		$val_recipt=$this->Admin_model->get_data('cash_bank_journals',array('cbr_sts'=>'1'),'','','cbr_id','DESC');
			if(empty($val_recipt))
			$data['doc_num']='JVN 1200';
			else
			{
			$bal_string1=str_replace("JVN ", "", $val_recipt[0]->cbr_doc_no);
			//print_r($bal_string1);
		           $new_id_1=($bal_string1)+1;
		            $data['doc_num']="JVN ".$new_id_1;
			}
		$this->load->view('admin/cash_bank/create_journal',$data);


}
else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
	        	} 


	}
}
function get_details_company()
{
	$table_id=$this->input->post('table_id');
$company=$this->Admin_model->get_data('master_company',array('mcomp_sts !='=>'0'));
$html='<select data-plugin-selectTwo  class="form-control populate company_'.$table_id.'" name="cbr_company[]" ><option >Choose</option>';

foreach($company as $cmp)
{
$html.="<option value=".$cmp->mcomp_id.">".$cmp->mcomp_name."</option>";
}
  $html.='</select>';
	echo $html;
}

function get_details_customer_acc()
{
	$table_id=$this->input->post('table_id');
	$sql_cust=$this->db->query("SELECT * FROM master_accounts_tree ");////TO GET OPERATING EXPENSE A/C NAMES AND CUSTOMER A/C NAMES COMBINED	
	$customers=$sql_cust->result_array();
	$html='<select data-plugin-selectTwo  class="form-control populate cust_acc_'.$table_id.' cust'.$table_id.'" name="cbr_customer_acc[]" onchange="get_cust_details('.$table_id.');"><option value="">Choose</option>';
	foreach($customers as $cu)
	{
	$html.="<option value=".$cu['id'].">".strtolower($cu['label'])."</option>";
	}
$html.='</select>';
	echo $html; 
	//echo json_encode($customers);
}

function submit_journal()
{
	$edited_id=$this->input->post('edit_cbr_id');
	        $main_date=$this->input->post('cbr_date');
$main_date1=explode('/',$main_date);
			$month1=$main_date1[0];
			$date1=$main_date1[1];
			$year1=$main_date1[2];
$new_formated_date1=$year1.'-'.$month1.'-'.$date1;

/////for upload files//////
$image = array();
	$uploadImgData = array();

  $ImageCount = count($_FILES['files']['name']);
 
        for($i = 0; $i < $ImageCount; $i++)
        {     
            $_FILES['file']['name']       = $_FILES['files']['name'][$i];
            $_FILES['file']['type']       = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['files']['error'][$i];
            $_FILES['file']['size']       = $_FILES['files']['size'][$i];

            // File upload configuration
            $uploadPath = 'uploads/journal_files/';
         $config['file_name'] = time().preg_replace("/[^a-z0-9\_\-\.]/i", '', basename($_FILES["files"]["name"][$i]));
            $config['upload_path'] = $uploadPath;
            //$config['max_size'] = '3000000';////3mb
            $config['allowed_types'] = '*';

            // Load and initialize upload library
            $this->load->library('upload', $config, 'business_card');
            $this->business_card->initialize($config);

            // Upload file to server
            if($this->business_card->do_upload('file'))
            {
              // Uploaded file data
                $imageData = $this->business_card->data();
              
                $uploadImgData[]=$imageData['file_name'];
              
                if(!empty($uploadImgData))
                {
              		$data_image=implode(',',$uploadImgData);
              	}
              	else
              	{
              		 $data_image='';
    			}	
                //print_r($uploadImgData);
            } 
            else
            {
           	 if(!empty($this->input->post('files_added')))
            		{
            		$data_image=$this->input->post('files_added');
    				}
            		else
           		{
            		$data_image='';
    			}
            }      
        }
////end of for upload files//////////

		$data['cbr_created_by']=$this->session->userdata['user']['username'];
		$data['cbr_doc_no']=$this->input->post('cbr_doc_no');
		
		$data['cbr_currency']=$this->input->post('cbr_currency');
		$data['cbr_rate_currency']=$this->input->post('cbr_rate_currency');
		$data['cbr_place_supply_id']=$this->input->post('cbr_place_supply_id');
		$data['cbr_jurisdication']=$this->input->post('cbr_jurisdication');
		$data['cbr_sts']='1';
		
		$data['cbr_dt_updt']=get_date_time();
		$data['cbr_narration']=$this->input->post('cbr_narration');
		$data['cbr_attachments']=$data_image;
		$data['cbr_company']=$this->input->post('hi_company');
		$data['cbr_customer_acc']=$this->input->post('hi_cust_acc');
		$data['cbr_salesman']=$this->input->post('hi_salesman');
		$data['cbr_ref']=$this->input->post('hi_refern');
		$data['cbr_remark']=$this->input->post('hi_remark');
		$data['cbr_debit']=$this->input->post('hi_debit');
		$data['cbr_credit']=$this->input->post('hi_credit');
		$data['cbr_tax_code']=$this->input->post('hi_tax_cod');
		$data['cbr_vat']=$this->input->post('hi_vat_code');
		$data['cbr_bill_no']=$this->input->post('hi_bill_no');
	
	if(empty($edited_id))////willl insert
	{
		$document_bal_number=str_replace("JVN ", "", $this->input->post('cbr_doc_no'));
		$data['cbr_doc_number']=$document_bal_number;
	}
	//pre_list($data);
	$amnts_debited=explode('|#|',$this->input->post('hi_debit'));
	$amnts_credited=explode('|#|',$this->input->post('hi_credit'));
	$cust_accs=explode('|#|',$this->input->post('hi_cust_acc'));
	$cust_bill_nos=explode('|#|',$this->input->post('hi_bill_no'));
		$vat_amounts=explode('|#|',$this->input->post('hi_vat_code'));
		//print_r($vat_amounts);

	$sales_inv_cust_id=array_filter(explode('|#|',$this->input->post('sales_inv_cust_id')));
	$sales_inv_id=array_filter(explode('|#|',$this->input->post('sales_inv_id')));
	$sales_inv_amount=array_filter(explode('|#|',$this->input->post('sales_inv_amount')));
	$sales_inv_amount_paid=array_filter(explode('|#|',$this->input->post('sales_inv_amount_paid')));
	$sales_doc_num=array_filter(explode('|#|',$this->input->post('sales_doc_num')));

	$jrn_paid_from_ref=explode('|#|',$this->input->post('hi_jrn_paid'));
	$jrn_bal_from_ref=explode('|#|',$this->input->post('hi_jrn_bal'));
	$tot_cust_acc=count($cust_accs);
	$tot_debit_acc=count(array_filter($amnts_debited));

	$insert_id=$this->Admin_model->insert_data('cash_bank_journals',$data);
	//print_r($insert_id);echo "<br/>";
	//$insert_id='12';
		if(!empty($insert_id))
		{
	$this->Admin_model->update_data('cash_bank_journals',array('cbr_insert_date'=>date('Y-m-d'),'cbr_dt_crtd'=>get_date_time(),'cbr_date'=>$new_formated_date1,'cbr_current_status'=>'approved'),array('cbr_id'=>$insert_id) );
$array_debit_credit=array();
			foreach($cust_accs as $k=>$v)
			{
				if(!empty($amnts_debited[$k]))
				{
					// echo "in if -amnt debited has val";echo "<br/>";
					// print_r($vat_amounts[$k]);echo "<br/>";
				$array_debit_credit[]='debit';
				if(!empty($vat_amounts[$k]))
				{
	//echo "in vat of debit has value";echo "<br/>";
					$org_amount=$amnts_debited[$k]/1.05;
					$array_amount[]=$org_amount;
					$vat_on_org_amount=$org_amount*0.05;
					$array_vat_amount[]=$vat_on_org_amount;
					$org_amount_array[]=$amnts_debited[$k];
				}
				else
				{
					//echo "in else -vat of debit has value";echo "<br/>";
					$array_amount[]=$amnts_debited[$k];
					$org_amount_array[]=$amnts_debited[$k];
				}
				
				$array_cust_acc[]=$v;
				
					if($jrn_paid_from_ref[$k])
					{
						$array_jrn_bal[]=$jrn_bal_from_ref[$k];
						$array_jrn_paid[]=$jrn_paid_from_ref[$k];
					}
					else
					{
						if(!empty($vat_amounts[$k]))
						{
							$org_amount=$amnts_debited[$k]/1.05;
							$array_jrn_bal[]=$org_amount;
						}
						else
						{
							$array_jrn_bal[]=$amnts_debited[$k];
						}
						$array_jrn_paid[]='0';
					}
				}
				else
				{
					// echo "in else -amnt credited has val";echo "<br/>";
					// print_r($vat_amounts[$k]);echo "<br/>";
				$array_debit_credit[]='credit';
				if(!empty($vat_amounts[$k]))
				{
					//echo "in vat of credit has value";echo "<br/>";
					$org_amount=$amnts_credited[$k]/1.05;
					$array_amount[]=$org_amount;
					$vat_on_org_amount=$org_amount*0.05;
					$array_vat_amount[]=$vat_on_org_amount;
					$org_amount_array[]=$amnts_credited[$k];
				}
				else
				{
					$array_amount[]=$amnts_credited[$k];
					$org_amount_array[]=$amnts_credited[$k];
				}
				
				$array_cust_acc[]=$v;
				if($jrn_paid_from_ref[$k])
					{
						// echo "in if of else";echo "<br/>";
						// print_r($jrn_paid_from_ref[$k]);echo "<br/>";
						$array_jrn_bal[]=$jrn_bal_from_ref[$k];
						$array_jrn_paid[]=$jrn_paid_from_ref[$k];
					}
					else
					{
						//echo "in else of else";echo "<br/>";
						if(!empty($vat_amounts[$k]))
						{
							$org_amount=$amnts_credited[$k]/1.05;
							$array_jrn_bal[]=$org_amount;
						}
						else
						{
							$array_jrn_bal[]=$amnts_credited[$k];
						}
						$array_jrn_paid[]='0';
					}				
				}
			}
// 		echo "array_jrn_bal";
// print_r($array_jrn_bal);echo "<br/>";
$tot_index='';
	
$all_credit_amounts_before_debit=0;
$all_credit_amounts_after_debit=0;
$credit_sums=0;$debit_sums=0;$debit_sum_total=0;

			for($i=0;$i<=$tot_cust_acc;$i++)
			{
				// pre_list($amnts_debited[$i]);echo "<br/>";
				// pre_list($amnts_credited[$i]);echo "<br/>";
				// echo $i;echo "<br/>";echo "has vat";
				// pre_list($vat_amounts[$i]);
				if(!empty($amnts_debited[$i]))///first is debit
					{
						// echo "first is debit amoount";echo "<br/>";
						// pre_list($amnts_debited);pre_list($amnts_credited);

						if(!empty($amnts_credited[$i]))
						{
						$credit_sums=$credit_sums+$amnts_credited[$i];
						//pre_list($credit_sums);
						$cred_accs[]=$cust_accs[$i];
							if(!empty($vat_amounts[$i]))
							{
								//echo "the vat in debit-if ";echo "<br/>";
								$org_amount=$amnts_credited[$i]/1.05;
								$vat_on_org_amount=$org_amount*0.05;
								$cred_vat_amount[]=$vat_on_org_amount;
								$cred_amnts[]=$org_amount;

							}
							else
							{
								//echo "the vat in debit-if else ";echo "<br/>";
								$cred_amnts[]=$amnts_credited[$i];	
							}
						}
						else
						{
							//echo "inside else for empty credit amount";echo "<br/>";
							$credit_sums=$credit_sums+$amnts_credited[$i+1];
						//pre_list($credit_sums);
						$cred_accs[]=$cust_accs[$i+1];
							if(!empty($vat_amounts[$i]))
							{
								//echo "the vat in debit-else if ";echo "<br/>";
								$org_amount=$amnts_credited[$i+1]/1.05;
								$vat_on_org_amount=$org_amount*0.05;
								$cred_vat_amount[]=$vat_on_org_amount;
								$cred_amnts[]=$org_amount;

							}
							elseif(!empty($vat_amounts[$i+1]))
							{
								$org_amount=$amnts_credited[$i+1]/1.05;
								$vat_on_org_amount=$org_amount*0.05;
								$cred_vat_amount[]=$vat_on_org_amount;
								$cred_amnts[]=$org_amount;
							}
							else
							{
								//echo "the vat in debit-else else ";echo "<br/>";
								$cred_vat_amount[]=0;
								$cred_amnts[]=$amnts_credited[$i+1];
							}
						}
						//echo "1st debit";echo "<br/>";
							if(round($credit_sums)==round($amnts_debited[$i]))
							{
								// echo "tot credit sum".$credit_sums."";echo "<br/>";
								// print_r($amnts_debited[$i]);echo "<br/>";
								if(!empty($cred_accs))
								{
								foreach($cred_accs as $k=>$c)
									{
										// echo "in c";echo "<br/>";
										// pre_list($c);
										$acc_data['accs'][$cust_accs[$i]][]=$c;
										$acc_data['amounts'][$cust_accs[$i]][]=$cred_amnts[$k];
										$acc_data['amount_vat'][$cust_accs[$i]][]=$cred_vat_amount[$k];
										$acc_data['amount_type'][$cust_accs[$i]][]='debit';	
									}
								}									
							}
					elseif(round($amnts_debited[$i])==round($amnts_credited[$i+1]))//satisfy 1-1 condition
						{
							//echo "1st debit- 1-1 i+1 condition";echo "<br/>";

							$acc_data['accs'][$cust_accs[$i]][]=$cust_accs[$i+1];
									if(!empty($vat_amounts[$i]))
									{
										$org_amount=$amnts_credited[$i+1]/1.05;
										$vat_on_org_amount=$org_amount*0.05;
										$acc_data['amount_vat'][$cust_accs[$i]][]=$vat_on_org_amount;
										$acc_data['amounts'][$cust_accs[$i]][]=$org_amount;

									}
									elseif(!empty($vat_amounts[$i+1]))
									{
										$org_amount=$amnts_credited[$i+1]/1.05;
										$vat_on_org_amount=$org_amount*0.05;
										$acc_data['amount_vat'][$cust_accs[$i]][]=$vat_on_org_amount;
										$acc_data['amounts'][$cust_accs[$i]][]=$org_amount;
									}
									else
									{
										$acc_data['amount_vat'][$cust_accs[$i]][]=0;
										$acc_data['amounts'][$cust_accs[$i]][]=$amnts_credited[$i+1];
									}
									
							if($array_debit_credit[$i]=='credit')
							{
							//	echo "in credit 1";echo "<br/>";
								$acc_data['amount_type'][$cust_accs[$i]][]='credit';
							}
							else
							{
							//	echo "in debit 1";echo "<br/>";
								$acc_data['amount_type'][$cust_accs[$i]][]='debit';	
							}
						}
						elseif(round($amnts_debited[$i])==round($amnts_credited[$i-1]))//satisfy 1-1 condition
						{
							//echo "1st debit- 1-1 i-1 condition";echo "<br/>";
						
							$acc_data['accs'][$cust_accs[$i]][]=$cust_accs[$i-1];
									if(!empty($vat_amounts[$i]))
									{
										$org_amount=$amnts_credited[$i-1]/1.05;
										$vat_on_org_amount=$org_amount*0.05;
										$acc_data['amount_vat'][$cust_accs[$i]][]=$vat_on_org_amount;
										$acc_data['amounts'][$cust_accs[$i]][]=$org_amount;

									}
									elseif (!empty($vat_amounts[$i-1])) {
											$org_amount=$amnts_credited[$i-1]/1.05;
										$vat_on_org_amount=$org_amount*0.05;
										$acc_data['amount_vat'][$cust_accs[$i]][]=$vat_on_org_amount;
										$acc_data['amounts'][$cust_accs[$i]][]=$org_amount;
									}
									else
									{
										$acc_data['amount_vat'][$cust_accs[$i]][]=0;
										$acc_data['amounts'][$cust_accs[$i]][]=$amnts_credited[$i-1];
									}
								
							if($array_debit_credit[$i]=='credit')
							{	
								//echo "in credit 12";echo "<br/>";
								$acc_data['amount_type'][$cust_accs[$i]][]='credit';
							}
							else
							{
								//echo "in debit 12";echo "<br/>";
								$acc_data['amount_type'][$cust_accs[$i]][]='debit';
							}
						}
						else/////getting an alone debit sum here
						{
						// echo "in else-> get debit alone";echo "<br/>";
						// pre_list($amnts_debited[$i]);

							$debit_sum_total=$debit_sum_total+$amnts_debited[$i];
							
							if(!empty($vat_amounts[$i]))
									{
										$org_amount=$amnts_debited[$i]/1.05;
										$vat_on_org_amount=$org_amount*0.05;
										$debit_vat_amount[]=$vat_on_org_amount;
										$debit_amnts[]=$org_amount;

									}
									else
									{
										$debit_vat_amount[]=0;
										$debit_amnts[]=$amnts_debited[$i];
									}
							$debit_acc[]=$cust_accs[$i];
						}
						//$credit_sums=0;$cred_accs=array();$cred_amnts=array();///////////////dont remove///
					}
					else
					{
					// echo "in main else".$i;echo "<br/>";			
					// 	pre_list($debit_sum_total);
					// 	pre_list($credit_sums);
						if(round($credit_sums)==round($debit_sum_total))
						{
							// echo "credit=debit";echo "</br>";echo "debit acc is";
							// pre_list($debit_acc);
							if(!empty($debit_acc))
							{
								foreach($debit_acc as $k=>$d)
								{
								//echo 'this is $d in main else :'.$d;echo "</br>";
								//	pre_list($d);pre_list($i);pre_list($k);
									$acc_data['accs'][$cust_accs[$i]][]=$d;
									$acc_data['amounts'][$cust_accs[$i]][]=$debit_amnts[$k];
									$acc_data['amount_vat'][$cust_accs[$i]][]=$debit_vat_amount[$k];
									$acc_data['amount_type'][$cust_accs[$i]][]='credit';
								}
							}	
						$credit_sums=0;$debit_sum_total=0;
						$cred_accs=array();$cred_amnts=array();
						}
						else{
						//	echo "credit sum != debit sum";echo "<br/>";
						}
					}
			}
//    pre_list($acc_data['accs']);
//     pre_list($acc_data['amounts']);
//       pre_list($acc_data['amount_type']);
// pre_list($array_cust_acc);

// 			pre_list($acc_data);
// pre_list($array_jrn_bal);
			foreach($acc_data['accs'] as $index=>$ac)
			{
			//	pre_list($ac);
				if(!empty($index))
				{
				foreach($ac as $cust_index=>$cust_accounts)
				{
					if(!empty($cust_accounts))
					{
						if(in_array($cust_accounts, $array_cust_acc))///main focus on cust-acc only to see if its a credit or debit type amount 
						{
							// echo "in if <br/>";
							// echo "in main if array, where customer id is found in_array";echo "<br/>";
							$array_search_val_cust_acc=array_search($cust_accounts,$array_cust_acc);//getting array index here////search for customer a/c's only

							//print_r($array_search_val_cust_acc);echo "<br/>";
							if(round($array_amount[$array_search_val_cust_acc])==round($acc_data['amounts'][$index][$cust_index]))
								{
									//echo "in if amounts equal";echo "<br/>";
									if($array_debit_credit[$array_search_val_cust_acc]=='debit')/////credit for customer a/c, then income for main a/c
									{
									//	echo "in if with debit for customer".$array_debit_credit[$array_search_val_cust_acc];echo "<br/>";
										//$customer_accounts=$cust_accounts;
										$main_acc_tx_type='Income';
										$main_acc_ref_type='JRN_Debit';
									}
									else////////debit for customer a/c, then expense for main a/c 
									{
									//	echo "in if-else with credit for customer".$array_debit_credit[$array_search_val_cust_acc];echo "<br/>";
										$main_acc_tx_type='Expense';
										$main_acc_ref_type='JRN_Credit';
									}
									$main_cust_ac=$cust_accounts;
									$main_sales_ac=$index;
									$main_array_cust_acc_index=$array_search_val_cust_acc;
									$main_bal_amount_ref=$array_jrn_bal[$array_search_val_cust_acc];
									$main_paid_amount_ref=$array_jrn_paid[$array_search_val_cust_acc];
								}
								else
								{
									//echo "in else -searching for array of amounts";echo "<br/>";
									 $array_search_val_amounts=array_search($acc_data['amounts'][$index][$cust_index],$array_amount);//getting array index here///
									 if($cust_accounts==$array_cust_acc[$array_search_val_amounts])///check if it equal to customer acc
									 {
									 	//echo "in else -if val = to cust a/c";echo "<br/>";
									 	if($array_debit_credit[$array_search_val_amounts]=='debit')
									 	{
									 	//	echo "in else with debit for customer";echo "<br/>";
									 		$main_acc_tx_type='Income';
									 		$main_acc_ref_type='JRN_Debit';
									 	}
									 	else
									 	{
									 	//	echo "in else with credit for customer";echo "<br/>";
									 		$main_acc_tx_type='Expense';
									 		$main_acc_ref_type='JRN_Credit';
									 	}
									 	$main_cust_ac=$cust_accounts;
										$main_sales_ac=$index;
										$main_array_cust_acc_index=$array_search_val_amounts;
										$main_bal_amount_ref=$array_jrn_bal[$array_search_val_cust_acc];
										$main_paid_amount_ref=$array_jrn_paid[$array_search_val_cust_acc];

									 	//echo "equal to cust acc";echo "<br/>";
									 }
									 elseif($index==$array_cust_acc[$array_search_val_amounts])///check if it equal to any main accounts
									 {
									 	//echo "in else -elseif val = to main a/c";echo "<br/>";
									 	if($array_debit_credit[$array_search_val_amounts]=='debit')
									 	{
									 		//echo "in else with debit for customer";echo "<br/>";
											$main_acc_tx_type='Income';
											$main_acc_ref_type='JRN_Debit';
									 	}
									 	else
									 	{
									 		//echo "in else with credit for customer";echo "<br/>";
									 		$main_acc_tx_type='Expense';
									 		$main_acc_ref_type='JRN_Credit';
									 	}	
									 	//echo "equal to main acc";echo "<br/>";
									 		$main_cust_ac=$index;
										$main_sales_ac=$cust_accounts;
										$main_array_cust_acc_index=$array_search_val_amounts;
										$main_bal_amount_ref=$array_jrn_bal[$array_search_val_cust_acc];
										$main_paid_amount_ref=$array_jrn_paid[$array_search_val_cust_acc];

									 }
									 else{}
								}
						}
						else//////checking main sales accounts found in main array of customers //////////
						{	
							 // echo "in else <br/>";
							 // echo "in main else - checking for the main sales a/c ";echo "<br/>";
						$array_search_val_cust_acc=array_search($cust_accounts,$array_cust_acc);//getting array index here////search for customer a/c's only
						$main_array_cust_acc_index=$array_search_val_cust_acc;
						}

					// echo "main_paid_amount_ref -";	print_r($main_paid_amount_ref);echo "<br/>";
					 		//echo "main_bal_amount_ref -";print_r($main_bal_amount_ref);
					//pre_list($main_array_cust_acc_index);
					
					$data_tx['atx_user_created']=$this->session->userdata['user']['username'];
					$data_tx['atx_type_tx']=$main_acc_ref_type;
					$data_tx['atx_date']=$new_formated_date1;
					$data_tx['atx_doc_no']=$this->input->post('cbr_doc_no');
					$data_tx['atx_main_id']=$insert_id;
					$data_tx['atx_acc_id']=$main_sales_ac;
					$data_tx['atx_cust_id']=$main_cust_ac;
					$data_tx['atx_tot_amount']=number_format((float)$acc_data['amounts'][$index][$cust_index], 2, '.', '');
					$data_tx['atx_paid_amount']=$main_paid_amount_ref;
					$data_tx['atx_bal_amount']=$main_bal_amount_ref;
					$data_tx['atx_dt_updt']=get_date_time();
					$data_tx['atx_sts']='1';
					$data_tx['atx_amount_type']=$main_acc_tx_type;
					$data_tx['atx_tranfer_type']='journal';
					$data_tx['atx_vat_amount']=number_format((float)$acc_data['amount_vat'][$index][$cust_index], 2, '.', '');
					$data_tx['atx_currency_value']=$this->input->post('cbr_rate_currency');
					$data_tx['atx_currency_type']=$this->input->post('cbr_currency');
					$data_tx['atx_narration']=$this->input->post('cbr_narration');
					

			//pre_list($sales_inv_amount_paid);
			
				//pre_list($data_tx);
				$insert_id_acc_vat_tx=$this->Admin_model->insert_data('account_all_tx',$data_tx);
				$save_insert_id[$main_array_cust_acc_index][]=$insert_id_acc_vat_tx;

					}
				}
			}
		}	
				if(array_filter($vat_amounts))
				{
					//echo "inside the vat account tx";
					foreach($vat_amounts as $iv=>$va)
					{
						if(!empty($va))
						{
							//echo "va is not empty";
						$vat_ratios=(($org_amount_array[$iv]/1.05)*0.05);
							if($array_debit_credit[$iv]=="debit")
								$v_type='Expense';
							else
								$v_type='Income';

							$data_tx_vat=array(
									'atx_user_created'=>$this->session->userdata['user']['username'],
									'atx_type_tx'=>'Vat_IP',
									'atx_date'=>$new_formated_date1,
									'atx_doc_no'=>$this->input->post('cbr_doc_no'),
									'atx_main_id'=>$insert_id,
									'atx_acc_id'=>'1013',
									'atx_cust_id'=>$cust_accs[$iv],
									'atx_tot_amount'=>number_format((float)$vat_ratios, 2, '.', ''),
									'atx_paid_amount'=>'0',
									'atx_bal_amount'=>number_format((float)$vat_ratios, 2, '.', ''),
									'atx_dt_updt'=>get_date_time(),
									'atx_sts'=>'1',
									'atx_amount_type'=>$v_type,
									'atx_tranfer_type'=>'journal',
									'atx_narration'=>$this->input->post('cbr_narration'),
									'atx_currency_value'=>$this->input->post('cbr_rate_currency'),
									'atx_currency_type'=>$this->input->post('cbr_currency'),
								);	
							//pre_list($data_tx_vat);
							$this->Admin_model->insert_data('account_all_tx',$data_tx_vat);
						}
					}
				}	
//pre_list($save_insert_id);

 //    $save_insert_id[]=array();
 // $save_insert_id[]=array('106');
 //    $save_insert_id[]=array('107');
 //    $save_insert_id[]=array('84');
 //  pre_list($save_insert_id);
		foreach($sales_inv_id as $index=>$si)
			{	
				//pre_list($index);
				$tot_amount_sales_paid=0;
			//print_r($index);echo "<br/>";
			$sales_inv_id_extra=array_filter(explode('|$$|',$si));
			$sales_inv_amount_extra=array_filter(explode('|$$|',$sales_inv_amount[$index]));
			$sales_inv_amount_paid_extra=array_filter(explode('|$$|',$sales_inv_amount_paid[$index]));
			$sales_inv_doc_num_extra=array_filter(explode('|$$|',$sales_doc_num[$index]));

		// 	print_r($sales_inv_amount_paid);
		// 	print_r($sales_inv_amount_extra);echo "<br/>";
		// print_r($sales_inv_amount_paid_extra);echo "<br/>";
		// 	print_r($sales_inv_doc_num_extra);echo "<br/>";
		// 	print_r($sales_inv_id_extra);echo "<br/>";

		// 	Array ( [0] => 100 ); Array ( [0] => 100 ); Array ( [0] => JVN 1204 );Array ( [0] => 16 );
		// Array ( [0] => 1.15 [1] => 12 [2] => 1000 [3] => 1000 [4] => 1000 [5] => 1000 ); Array ( [1] => 12 ); Array ( [0] => JVN 1201 [1] => JVN 1202 [2] => JVN 1206 [3] => JVN 1207 [4] => JVN 1208 [5] => JVN 1210 ); Array ( [0] => 11 [1] => 13 [2] => 18 [3] => 20 [4] => 24 [5] => 46 );
//pre_list($save_insert_id);
		if(!empty($sales_inv_amount_paid[$index]))
			{
				if(!empty($save_insert_id[$index]))
					{
						$new_saved_insert_id=$save_insert_id[$index][0];
					}
					elseif(!empty($save_insert_id[$index+1]))
					{
						$new_saved_insert_id=$save_insert_id[$index+1][0];
					}
					elseif(!empty($save_insert_id[$index-1]))
					{
						$new_saved_insert_id=$save_insert_id[$index-1][0];
					}
					else
					{
						$new_saved_insert_id='';
					}

					$data_jrn_array=array(
			  			'atx_paid_amount'=>$jrn_paid_from_ref[$index],
			  			'atx_bal_amount'=>$jrn_bal_from_ref[$index],
			  		);
			  	$this->Admin_model->update_data('account_all_tx',$data_jrn_array,array('atx_id'=>$new_saved_insert_id));
				// pre_list($save_insert_id[$index]);
				//array_filter($save_insert_id[$index]);
			foreach($sales_inv_id_extra as $index2=>$si2)
				{
					// print_r($si2);
					// pre_list($index2);
					// pre_list($save_insert_id[$index][0]);
					// pre_list($sales_inv_amount_paid_extra[$index2]);
					if(!empty($sales_inv_amount_paid_extra[$index2]))
					{			
						$amount_paid_till_now=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$si2));
						$total_paid_amount_from_another_ref[]=$sales_inv_amount_paid_extra[$index2];
			  		$bal_amount_sales_inv=$sales_inv_amount_extra[$index2]-$sales_inv_amount_paid_extra[$index2];
			  		$data_si_array=array(
			  			'atx_paid_amount'=>$amount_paid_till_now[0]->atx_paid_amount+$sales_inv_amount_paid_extra[$index2],
			  			'atx_bal_amount'=>$bal_amount_sales_inv,
			  		);
			  		//pre_list($data_si_array);
			$this->Admin_model->update_data('account_all_tx',$data_si_array,array('atx_id'=>$si2));

				$data_tx_bal=array(
					'actb_tx_id'=>$new_saved_insert_id,
					'actb_to_type'=>$sales_inv_doc_num_extra[$index2],
					'actb_paid_amount'=>$sales_inv_amount_paid_extra[$index2],
					'actb_to_id'=>$si2,
					'actd_sts'=>'1',
					'actb_user_created'=>$this->session->userdata['user']['username'],
				);	
			//pre_list($data_tx_bal);
			$this->Admin_model->insert_data('account_tx_bal_data',$data_tx_bal);
			  		}
			  	}			 		
			}
		}  
			$activity_data=array(
				'act_user'=>$this->session->userdata['user']['username'],
				'act_function'=>'Journal Entry created',
				'act_status'=>'Journal Entry id '.$insert_id.' created,also added to account_master_trasaction table',
				'act_journal_id'=>$insert_id
			);
			$this->Admin_model->insert_data('activities',$activity_data);

		   $this->session->set_flashdata('success', 'Data Successfully inserted');
		   redirect('list-journal-entries');
		}////////////////end of if->insert id not empty checking /////////	
}

function list_journal_entries()
{
	if(logged_in())
	{


 $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-journal-entries')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {


 

			$data['chat']=$this->Admin_model->get_data('discussion_chat',array('page_url'=>'list-journal-entries'));
			
		$data['result']=$this->Admin_model->get_data('cash_bank_journals',array('cbr_sts'=>'1'));
		$this->load->view('admin/cash_bank/list_journal_entries',$data);

}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


	}



}

function delete_jv($id)
{
	if(logged_in())
	{
		$data=$this->Admin_model->get_data('master_acc_transfers',array('mact_journal_table_id'=>$id));
		pre_list($data);
		// if($id)
		// {
		// 	//$this->Admin_model->update
		// }
	}
}

function get_doc_details()
{
	$cbr_id=$this->input->post('main_id');
$dataa=$this->Admin_model->get_data('cash_bank_journals',array('cbr_id'=>$cbr_id));

	if(!empty($dataa[0]))
	{
			$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->cbr_currency));
				$place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->cbr_place_supply_id));
				$jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->cbr_jurisdication));
				$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->cbr_currency));
				$place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->cbr_place_supply_id));
				$jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->cbr_jurisdication));

				$comp_list=explode('|#|',$dataa[0]->cbr_company);
				foreach($comp_list as $cl)
				{
				$data_cmp[]=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$cl));
				}

				$customer_list=explode('|#|',$dataa[0]->cbr_customer_acc);
				foreach($customer_list as $cs)
				{
					$data_cl[]=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$cs));
				}
				
				$salesman_list=explode('|#|',$dataa[0]->cbr_salesman);
				foreach($salesman_list as $sl)
				{
					$data_sl[]=$this->Admin_model->get_data('employee_details',array('ed_id'=>$sl));
				}

					$ref_list=explode('|#|',$dataa[0]->cbr_ref);
					$rmk_list=explode('|#|',$dataa[0]->cbr_remark);
					$tax_list=explode('|#|',$dataa[0]->cbr_tax_code);
					$credit_list=explode('|#|',$dataa[0]->cbr_credit);
					$debit_list=explode('|#|',$dataa[0]->cbr_debit);
					$bill_no=explode('|#|',$dataa[0]->cbr_bill_no);
					$tax_list=explode('|#|',$dataa[0]->cbr_tax_code);
					$vat_per_list=explode('|#|',$dataa[0]->cbr_vat);


					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Journal Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->cbr_doc_no."</p>";
					$html.="<p>User Created: ".$dataa[0]->cbr_created_by."</p>";
					$html.="<p>Date: ".$dataa[0]->cbr_date."</p>";
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Narration: ".$dataa[0]->cbr_narration."</p>";
					$html.="<p>Place of Supply: ".$place_supply[0]->mps_name."</p>";
					$html.="<p>Jurisdiction: ".$jurisdaction[0]->mps_name."</p>";
					$html.="<p>Linked to Invoice.: ".str_replace('|#|', '<br/>', $dataa[0]->cbr_sales_inv_linked)."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
				
				$html.="<p>Current Status: ".$dataa[0]->cbr_current_status."</p>";
					$html.="<p>Attachements: <a href='".base_url('uploads/journal_files/'.$dataa[0]->cbr_attachments)."' target='_blank'> ".$dataa[0]->cbr_attachments."</a></p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

						$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th><th>Company</th><th>Salesman</th><th>Account</th><th>Debit</th><th>Credit</th><th>Reference</th><th>Remark</th><th>Bill No.</th><th>Tax Code</th><th>Vat%</th></thead>";
					$html.="<tbody>";
					foreach($data_cl as $key=>$d)
					{
						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$data_cmp[$key][0]->mcomp_name."</td>";
						$html.="<td>".$data_sl[$key][0]->ed_name."</td>";
						$html.="<td>".$d[0]->label."</td>";
						$html.="<td>";
						if(!empty($debit_list[$key]))
						{
							$html.=$debit_list[$key];
							$debit_tot[]=$debit_list[$key];
						}
						else
						{
							$html.='0';
						}
						$html.="</td>";
						$html.="<td>";
						if(!empty($credit_list[$key]))
						{
							$html.=$credit_list[$key];
						$credit_tot[]=$credit_list[$key];
						}
						else
						{
							$html.='0';
						}
						$html.="</td>";
						$html.="<td>".$ref_list[$key]."</td>";
						$html.="<td>";
						if(!empty($rmk_list[$key]))
						$html.=$rmk_list[$key];
						$html.="</td>";
						$html.="<td>";
						if(!empty($bill_no[$key]))
						$html.=$bill_no[$key];
						$html.="</td>";
						$html.="<td>";
						if(!empty($tax_list[$key]))
							$html.=$tax_list[$key];
						$html.="</td>";
						$html.="<td>";
						if(!empty($vat_per_list[$key]))
						$html.=$vat_per_list[$key];
						$html.="</td>";
						$html.="</tr>";
					}
					$html.="</tbody>";
					$html.="</table>";
				$html.="<p>Debit Amount Total:".array_sum($debit_tot)."</p>";
				$html.="<p>Credit Amount Total:".array_sum($credit_tot)."</p>";
					/*** start of table  ***/
					echo $html;
	}
}

function get_cust_sales_inv()
{
	$cust_id=$this->input->post('cust_id');
	$table_id=$this->input->post('table_id');
	$debit_amount=$this->input->post('debit_amount');
	$credit_amount=$this->input->post('credit_amount');

$sql_cust_suplier=$this->db->query("SELECT id FROM master_accounts_tree WHERE parent IN  (638,639,640,641,490)");
$cust_suplier=$sql_cust_suplier->result();

foreach($cust_suplier as $cs)
{
	$array_ids[]=$cs->id;
}

if(in_array($cust_id,$array_ids))
{
	if(!empty($credit_amount))
	$sql2=$this->db->query("SELECT * FROM account_all_tx where atx_cust_id=".$cust_id." and atx_type_tx IN ('Payments','Petty_Cash','PDP','Sales_Invoice','JRN_Debit') and atx_bal_amount!='0' and atx_sts='1' ");
	else
	$sql2=$this->db->query("SELECT * FROM account_all_tx where atx_cust_id=".$cust_id." and atx_type_tx IN ('Receipt','PDR','JRN_Credit','Sales_Return','Purchase') and atx_bal_amount!='0' and atx_sts='1' ");///here add the purchase voucher and sales return  also

	$cust_sales=$sql2->result_array();

		$ij=1;
		$html="
		<div class='row'>
		<div class='col-md-12'>
		<div class='col-md-10'>
		<span class='pull-left'><input type='text'  class='refrence_amount_".$table_id."' value='0' name='refrence'><br/><p>Add as new reference </p></span><br/>";

if(!empty($credit_amount))
	$html.="<input type='hidden' class='amount_type' value='credit_amount_type'>";
	else
	$html.="<input type='hidden' class='amount_type' value='debit_amount_type'>";
		
		$html.="<table class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
			$html.="<thead>";
			$html.="<th></th>";
			$html.="<th>Reference</th>";
			$html.="<th>Bill Amount</th>";
			$html.="<th>Amount Adjusted</th>";
			// $html.="<th>Balance Amount</th>";
			$html.="</thead>";
			$html.="<tbody>";
	if(!empty($cust_sales))
	{
		foreach($cust_sales as $civ)
		{
			$html.="<tr>";
		$html.="<td><input name='cust_id_modal' type='hidden' value='".$cust_id."'>
		<input type='checkbox' class='class_checkbox inv_selected_".$ij."' onclick='pass_param();' value='".$ij."' name='inv_selected[]'>
		<input name='table_id_modal' type='hidden' value='".$table_id."'>
		</td>";
			$html.="<td><input name='inv_id_modal[]' type='hidden' class='inv_ids_".$ij."' value='".$civ['atx_id']."'><input name='inv_doc_numbers_modal[]' class='ref_doc_numbers_".$ij."' type='hidden' value='".$civ['atx_doc_no']."'>".$civ['atx_doc_no']."</td>";

			if(empty($civ['atx_paid_amount']))
			{
					if($civ['atx_type_tx']=="Sales_Invoice" )
					{
						$tot_amount_to_show=$civ['atx_tot_amount'];
					}
					elseif($civ['atx_type_tx']=="Sales_Return")
					{
						$tot_amount_to_show=$civ['atx_tot_amount'];
					}
						
					else
					{
						if(!empty($civ['atx_vat_amount']))
						$tot_amount_to_show=$civ['atx_tot_amount']+$civ['atx_vat_amount'];
						else
						$tot_amount_to_show=$civ['atx_tot_amount']+0;
					}
			}
			else
			{
				$tot_amount_to_show=$civ['atx_bal_amount'];
			}

			$html.="<td><input name='sales_inv_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_amount_".$ij." org_amounts'><br/>
			<p>Total Amount:".$civ['atx_tot_amount']."</p>
			</td>";
			
			$html.="<td><input name='paid_amount_modal[]' type='number' step='any' value='0' min='0' max='".$tot_amount_to_show."' onchange='check_val_less_than_amount(".$ij.");' class='tot_sales_amount_paid_".$ij."'><br/>
		
			<br/><small class='amount_overdue_".$ij." text_data_issue' style='color:red;'></small>
			</td>";
			// $html.="<td>
			// <input name='sales_inv_bal_amount_modal[]' type='number' step='any' value='".$tot_amount_to_show."' readonly='' class='tot_sales_bal_amount_".$ij."'>
			// </td>";
			$html.="</tr>"; 
			$ij++;
		}
		}	
		$html.="</tbody>";
			$html.="</table>";
			$html.="</div>		
<div class='col-md-2'>";
if(!empty($credit_amount))
$html.="<button class='btn btn-primary pull-right get_pick_amount' onclick='get_pick_amount(".$table_id.");'>Pick Amount</button>";
else
$html.="<button class='btn btn-primary pull-right get_pick_amount' onclick='get_pick_amount(".$table_id.");'>Pick Amount</button>";
$html.="</div>
</div>
<div class='col-md-12'>
	<div class='col-md-4'>";

	if(!empty($credit_amount))
		$html.="<p> Amount to adjust:<span class='amount_to_adj'>".$credit_amount."</span></p>";
	elseif(!empty($debit_amount))
		$html.="<p> Amount to adjust:<span class='amount_to_adj'>".$debit_amount."</span></p>";
	else
		$html.="<p> Amount to adjust:<span class='amount_to_adj'>0</span></p>";

	$html.="</div>
	<div class='col-md-4'>
	<p> Amount adjusted:<span class='amount_adjusted'>0</span></p>
	</div>
	<div class='col-md-4'>
	<p>To be adjusted:<span class='to_be_adjust'>0</span></p>
	</div>";
	$html.="<div class='col-md-12'>
	<p><button class='btn btn-danger' type='button' onclick='reset_fields()'>Reset Fields</button></p>
	</div>";
$html.="</div>
		</div>
		";
			echo $html;			
}
}














}