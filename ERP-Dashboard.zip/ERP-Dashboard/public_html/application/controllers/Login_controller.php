<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_controller extends CI_Controller {

	public function __construct() 
	{
			parent::__construct();
		$this->load->library('encryption','user_agent');
			// $this->load->library('googleapi');
		    // $this->load->config('geolocation', true);
             $this->load->helper(array('session','email','img','gnrl'));	
			
			
	}

	function index()
	{
		
		$this->load->view('admin/login');
	}

	function login()
	{  
		$this->load->view('admin/login');
	}

	function contact()
	{
		$this->load->view('contact');
	}

	function display()
	{
		$this->load->view('display');
	}

	function submit_login()
	{	
        	$this->load->library('user_agent');
    	 $browsername=$this->agent->browser();
		$browserversion=$this->agent->version();
		$operatingsystem=$this->agent->platform();
		$agent =$_SERVER['HTTP_USER_AGENT'];
		$page_devicename=explode('(', $agent);
       $firsdevicenfo=$page_devicename[1];
       $devicedetails=explode(')', $firsdevicenfo);

	   ///to get only device name if it mobile but if it was windows it cannot
        $devicedetailsinfo=$devicedetails[0];

		
       // my router ip because its fixed and accurate
         $testip= $this->input->ip_address();
$apikey='ca6a43d093ec4977a8877945e51a0a4e';

$LocationArray []= json_decode( file_get_contents('https://ip-get-geolocation.com/api/json/'.$testip.'?key='.$apikey));


//  print_r($LocationArray);
//  exit(0);





         $cityserverprovider=$LocationArray[0]->city;

          $country=$LocationArray[0]->country;
          $state=$LocationArray[0]->regionName;
          $hostname=$LocationArray[0]->isp;
   
          $user_ip=$LocationArray[0]->query;
          $user_lat=$LocationArray[0]->lat;
          $user_long=$LocationArray[0]->lon;
           $user_serverorg=$LocationArray[0]->org;

// print_r($cityserverprovider);
// print_r($country);
// print_r($hostname);
// print_r($user_ip);

// print_r($user_serverorg);
// exit(0);

	$this->form_validation->set_rules('username', 'Username', 'trim|required');
		$this->form_validation->set_rules('pwd', 'Password', 'trim|required');

		if ($this->form_validation->run() == FALSE)
        {
        	$this->session->set_flashdata('username', form_error('username'));
        	$this->session->set_flashdata('pwd', form_error('pwd'));
        	      	redirect('login','refersh');
        }
        else
        {


        $page_current_url=$this->input->post('page_current_url');   
        	$cond=array('log_status'=>'1','log_uname'=>$this->input->post('username'));
			$data['result']=$this->Admin_model->get_data('login_credentials',$cond);
			if(empty($data['result']))
			{
				$this->session->set_flashdata('errors', 'Invalid Credentials. Please try again.');
				redirect('login','refersh');
			}
			else
			{
				$user_id=$data['result'][0]->log_id;
				$pwd_table=$data['result'][0]->log_pwd;
				$to_encrypt = $this->input->post('pwd');
				
				$ciphertext =$this->encryption->encrypt($to_encrypt);
		    	$decrypt_cipher= $this->encryption->decrypt($ciphertext);

				$decrypt_table=$this->encryption->decrypt($pwd_table);

				if($decrypt_cipher!=$decrypt_table)
				{
					$this->session->set_flashdata('errors', 'Invalid password. Please try again.');
					redirect('login','refersh');
				}
				else
				{




					$ipsession=$this->input->ip_address();

                     $computername=gethostname();

					$user_array['user']=array(
						'role'=>$data['result'][0]->log_role,
						'username'=>$data['result'][0]->log_uname,
						'userlogid'=>$data['result'][0]->log_id,
						'main_dept'=>$data['result'][0]->log_dept,
						'sub_dept'=>$data['result'][0]->log_sub_type,		
						'pages_permission'=>$data['result'][0]->log_page,
						'password'=>$data['result'][0]->log_pwd,
						'user_email'=>$data['result'][0]->log_email,
						'user_desig'=>$data['result'][0]->log_designation,	
						'user_position'=>$data['result'][0]->log_position,
						'log_designation'=>$data['result'][0]->log_designation,
						'salesman_focus'=>$data['result'][0]->focus_user_name,
						'server_ip'=>$ipsession,
						'location_ip'=>$ipsession,
						'computername'=>$computername,
						'state'=>$state,
						'country'=>$country,
						'cityserverprovider'=>$cityserverprovider,
						'hostname'=>$hostname,
						'user_lat'=>$user_lat,
                         'user_long'=>$user_long,
						'user_serverorg'=>$user_serverorg,
						'browsername'=>$browsername,
						'browserversion'=>$browserversion,
						'operatingsystem'=>$operatingsystem,
						'devicedetailsinfo'=>$devicedetailsinfo,
						 'ipsession'=> $ipsession,
						// 'mobile'=>$mobile, 

					);
					$this ->session->set_userdata($user_array);

                    $datacode['user_id']=$user_id;
                    $this->Admin_model->expireCode($user_id);
                     $datacode['code']=$this->Admin_model->generateCode($user_id);
                      $usercode=$datacode['code'];

                    ///now we need to send this code in email to the user


                       $this->send_mail_code($user_id,$usercode);
                    ////end


                     //now we will redirect you to another page to authenticate login with the special code 
                       // redirect('auth_code',$datacode);
                     $this->load->view('admin/auth_code',$datacode);

                        




				}
			}
        }	

	}

	function logout()
	{
		$this->session->unset_userdata('user', null);
		redirect('login','refersh');
	}


function authorize()
	{
		$user_id = $this->input->post('user_id');
		$code=$this->input->post('code');

       $dataauth['user_id']=$this->input->post('user_id');
       $dataauth['code']=$this->input->post('code');

		if($this->Admin_model->authenticateCode($user_id,$code))
		{
                $dept_user= $this->session->userdata['user']['main_dept'];


                
					// print_r($user_array);
					// exit(0);
					if($dept_user=="Sales")
					redirect('marketing-dashboard');
					//	redirect('sales-user-dashboard');
					elseif($dept_user=="Marketing")
						redirect('Designer-dashboard');
					elseif($dept_user=="Main factory")
						redirect('po-dashboard');
					elseif($dept_user=="Traffic Sign")
							redirect('po-dashboard');
					elseif($dept_user=="ksa-Sales")
							redirect('sales-book-dashboard');
					elseif($dept_user=="Purchase")
					{
						if($this->session->userdata['url']['email_ticket_reply_url'])
						{
							redirect($this->session->userdata['url']['email_ticket_reply_url']);
						}
						else
						{
							redirect('combined_db');
						}	
					}
					elseif(($dept_user=="Project Department") || ($dept_user=="Factory Staff"))
							redirect('survey-dashboard');	
                     elseif(!empty($page_current_url))
					{
						redirect($page_current_url);	
					}					
					else
							redirect('dashboard');

		}



		else{

               //$data['errors']='Sorry, the code you have entered is expired .please use the new code that send to your email';
               
               $this->session->set_flashdata('errors','Invalid Credentials Or That Code Is Expired.please use the new code that send to your email.');
               // redirect('auth_code',$dataauth);
                

			  
				
              // $this->load->view('static/head',$data);

                $this->load->view('admin/auth_code',$dataauth);

		}




	}


	function send_mail_code($user_id,$usercode)
{
        	     $this->load->library('email');
                //  $config['protocol'] = "smtp";
                $config['mailpath']     = "/usr/bin/sendmail";
                  $config['protocol'] = "smtp";
                 $config['smtp_host'] = 'smtp.ionos.com';
                 $config['smtp_port'] = '587';
                 $config['smtp_user'] = 'noreply@birigroup.com';
                 $config['smtp_pass'] = 'Noreply@000';
                 $config['smtp_crypto'] = 'tls'; 
                 $config['starttls'] = TRUE;
                 $config['mailtype'] = 'html';
                 $config['charset'] = 'utf-8';
                 $config['newline'] = "\r\n";
                 $config['crlf'] = "\r\n";
                 $config['wordwrap'] = TRUE;


    //             $this->load->library('email');
    //             //  $config['protocol'] = "smtp";
    //             $config['mailpath']     = "/usr/bin/sendmail";
    //             $config['protocol'] = "smtp";
    //             $config['smtp_host'] = 'mail.birigroup.co.uk';
    //             $config['smtp_port'] = '465';
    //             $config['smtp_user'] = 'temp@birigroup.co.uk';
    //             $config['smtp_pass'] = 'Noreply@111';
    //     $config['smtp_crypto'] = 'ssl'; 
    // //    $config['starttls'] = TRUE;
    //             $config['mailtype'] = 'html';
    //             $config['charset'] = 'utf-8';
    //             $config['newline'] = "\r\n";
    //             $config['crlf'] = "\r\n";
    //             $config['wordwrap'] = TRUE;





            $this->email->initialize($config);

        $page_user= $this->session->userdata['user']['username'];

        $page_email=$this->session->userdata['user']['user_email'];

        $page_state=$this->session->userdata['user']['state'];

        $date_time=get_date_time();


          $this->email->from('noreply@birigroup.com','Biri Group');
          $this->email->to("support@birigroup.com");
          $this->email->to($page_email);    

          $this->email->subject('Your one Time Code:');
		 $msg="is that You  ".$page_user.", <br/> Your Code for This login is: <br/><br/>";

		 
         $msg.="Code :  "  .$usercode."<br/><br/>";

		  $msg.="Login date  :  "  .$date_time."<br/><br/>";
		
		  $msg.="<br/><br/>";
         $msg.="it is Used Just One Time Thank you!<br/><br/>";


		$msg.="<small>This is an auto-generated message, so please do not reply to this email.</small>";
		 $this->email->message($msg);
         if($this->email->send())
         {
          return True;
	}
         else
         {
         return false;
         }  
		 
}



}