<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fund_tx extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper('session');
		$this->load->helper(array('session','gnrl'));	
	}
	function tx_funds()
	{
		if(logged_in())
		{
	  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
        if ((($page_cred[$i]=='tx_funds')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

		$current_year= date('Y');
		$start_date1=$current_year.'-01-01';
		$exploded_start_date='1-1-'.$current_year;

		$current_date=date('Y-m-d');
		$explode_date=explode('-',$current_date);	

		$year=ltrim($explode_date[0], '0');	
		$month=ltrim($explode_date[1], '0');
		$date=ltrim($explode_date[2], '0');
		
		$exploded_current_date=$month.'-'.$date.'-'.$year;

		$cond_start_date= array('ae_date >='=>$start_date1);
		$or_where_cond_start_date=array('ae_date >='=>$exploded_start_date);		

		$cond_end_date= array('ae_date ='=>$current_date);
		$or_where_cond_end_date=array('ae_date ='=>$exploded_current_date);


		$cond2=array('ae_bank'=>'ADIB-BBMS');
			$bbms_rx1=$this->Admin_model->bnk_bal_rx($cond2);
			$bbms_spend1=$this->Admin_model->bnk_bal_spend($cond2);
			$data['bbms_result1']=(($bbms_rx1[0]->rx_total)-($bbms_spend1[0]->spend_total));////total bal.

			$bbms_rx2=$this->Admin_model->bnk_bal_rx_btw_dates($cond2,$start_date1,$current_date);
			$bbms_spend2=$this->Admin_model->bnk_bal_spend_btw_dates($cond2,$start_date1,$current_date);
			$data['bbms_result2']=(($bbms_rx2[0]->rx_total)-($bbms_spend2[0]->spend_total));///upto this financial year	
			$cond2=array('ae_bank'=>'ADIB-Factory');
			$fact_rx1=$this->Admin_model->bnk_bal_rx($cond2);
			$fact_spend1=$this->Admin_model->bnk_bal_spend($cond2);
			$data['fact_result1']=(($fact_rx1[0]->rx_total)-($fact_spend1[0]->spend_total));//total bal

			$fact_rx2=$this->Admin_model->bnk_bal_rx_btw_dates($cond2,$start_date1,$current_date);
			$fact_spend2=$this->Admin_model->bnk_bal_spend_btw_dates($cond2,$start_date1,$current_date);
			$data['fact_result2']=(($fact_rx2[0]->rx_total)-($fact_spend2[0]->spend_total));///upto tis fin yr
			
			$cond2=array('ae_bank'=>'ENBD');			
			$enbd_rx1=$this->Admin_model->bnk_bal_rx($cond2);
			$enbd_spend1=$this->Admin_model->bnk_bal_spend($cond2);
			$data['ENBD1']=(($enbd_rx1[0]->rx_total)-($enbd_spend1[0]->spend_total));

			$enbd_rx2=$this->Admin_model->bnk_bal_rx_btw_dates($cond2,$start_date1,$current_date);
			$enbd_spend2=$this->Admin_model->bnk_bal_spend_btw_dates($cond2,$start_date1,$current_date);
			$data['ENBD2']=(($enbd_rx2[0]->rx_total)-($enbd_spend2[0]->spend_total));	
			
			$cond2=array('ae_bank'=>'EI Bank');
			$ei_rx1=$this->Admin_model->bnk_bal_rx($cond2);
			$ei_spend1=$this->Admin_model->bnk_bal_spend($cond2);
			$data['ei_bank1']=(($ei_rx1[0]->rx_total)-($ei_spend1[0]->spend_total));

			$ei_rx2=$this->Admin_model->bnk_bal_rx_btw_dates($cond2,$start_date1,$current_date);
			$ei_spend2=$this->Admin_model->bnk_bal_spend_btw_dates($cond2,$start_date1,$current_date);
			$data['ei_bank2']=(($ei_rx2[0]->rx_total)-($ei_spend2[0]->spend_total));	
			
			$cond2=array('ae_bank'=>'Other Bank');
			$other_rx1=$this->Admin_model->bnk_bal_rx($cond2);
			$other_spend1=$this->Admin_model->bnk_bal_spend($cond2);
			$data['others1']=(($other_rx1[0]->rx_total)-($other_spend1[0]->spend_total));

			$other_rx2=$this->Admin_model->bnk_bal_rx_btw_dates($cond2,$start_date1,$current_date);
			$other_spend2=$this->Admin_model->bnk_bal_spend_btw_dates($cond2,$start_date1,$current_date);
			$data['others2']=(($other_rx2[0]->rx_total)-($other_spend2[0]->spend_total));
			
			$cond2=array('ae_bank'=>'Cash Garhoud');
			$garhoud_rx1=$this->Admin_model->bnk_bal_rx($cond2);
			$garhoud_spend1=$this->Admin_model->bnk_bal_spend($cond2);
			$data['Garhoud1']=(($garhoud_rx1[0]->rx_total)-($garhoud_spend1[0]->spend_total));

			$garhoud_rx2=$this->Admin_model->bnk_bal_rx_btw_dates($cond2,$start_date1,$current_date);
			$garhoud_spend2=$this->Admin_model->bnk_bal_spend_btw_dates($cond2,$start_date1,$current_date);
			$data['Garhoud2']=(($garhoud_rx2[0]->rx_total)-($garhoud_spend2[0]->spend_total));
			
			$cond2=array('ae_bank'=>'Cash Mr. Bachir Book');
			$bachir_rx1=$this->Admin_model->bnk_bal_rx($cond2);
			$bachir_spend1=$this->Admin_model->bnk_bal_spend($cond2);
			$data['cash_bachir1']=(($bachir_rx1[0]->rx_total)-($bachir_spend1[0]->spend_total));

			$bachir_rx2=$this->Admin_model->bnk_bal_rx_btw_dates($cond2,$start_date1,$current_date);
			$bachir_spend2=$this->Admin_model->bnk_bal_spend_btw_dates($cond2,$start_date1,$current_date);
			$data['cash_bachir2']=(($bachir_rx2[0]->rx_total)-($bachir_spend2[0]->spend_total));

			$cond2=array('ae_bank'=>'Cash Factory');
			$cash_fact_rx1=$this->Admin_model->bnk_bal_rx($cond2);
			$cash_fact_spend1=$this->Admin_model->bnk_bal_spend($cond2);
			$data['cash_fact1']=(($cash_fact_rx1[0]->rx_total)-($cash_fact_spend1[0]->spend_total));

			$cash_fact_rx2=$this->Admin_model->bnk_bal_rx_btw_dates($cond2,$start_date1,$current_date);
			$cash_fact_spend2=$this->Admin_model->bnk_bal_spend_btw_dates($cond2,$start_date1,$current_date);
			$data['cash_fact2']=(($cash_fact_rx2[0]->rx_total)-($cash_fact_spend2[0]->spend_total));


		$this->load->view('admin/add_tx_fund',$data);
		}
     else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	    	redirect('login','refersh');
	}

	}
}

	function list_txs()
	{
	
	if(logged_in())
		{
	  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
        if ((($page_cred[$i]=='list_txs')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

		$cond2=array('ft_status'=>'1');
		$qry['result']=$this->Admin_model->get_data('fund_transfer',$cond2);
		$this->load->view('admin/list_tx_fund',$qry);

		}
     else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	    	redirect('login','refersh');
	}

		}
	}

	function crd_bank_bal()
	{
	if(logged_in())
		{
		$bank_name=$this->input->post('bank_name_selected');
		$cond2=array('ae_bank'=>$bank_name);
		$bachir_rx=$this->Admin_model->bnk_bal_rx($cond2);
		$bachir_spend=$this->Admin_model->bnk_bal_spend($cond2);
		$total_bal=(($bachir_rx[0]->rx_total)-($bachir_spend[0]->spend_total));
		echo $total_bal;
		}
	}


function submit_fund_tx()
{
if(logged_in())
	{
	$this->form_validation->set_rules('debit_bnk', 'Bank to Debit Fund', 'trim|required');
	$this->form_validation->set_rules('credit_bnk', 'Bank to Credit Fund', 'trim|required');
	$this->form_validation->set_rules('desc', 'Details', 'trim');
	$this->form_validation->set_rules('date', 'Date');
	$this->form_validation->set_rules('amount', 'Amount', 'trim|required|numeric');
	
  if ($this->form_validation->run() == FALSE)
    {
    	$this->session->set_flashdata('debit_bnk', form_error('debit_bnk'));
		$this->session->set_flashdata('credit_bnk', form_error('credit_bnk'));
		$this->session->set_flashdata('desc', form_error('desc'));
		$this->session->set_flashdata('amount', form_error('amount'));
	$this->session->set_flashdata('errors', validation_errors());

			redirect('tx_funds');
	}
	else
	{
		$fund_trsf_id=$this->input->post('fund_tr_id');
		
		$crd_bank=$this->input->post('credit_bnk');
			$cond2=array('ae_bank'=>$crd_bank);
			$fact_rx=$this->Admin_model->bnk_bal_rx($cond2);
			$fact_spend=$this->Admin_model->bnk_bal_spend($cond2);
			$fact_result=(($fact_rx[0]->rx_total)-($fact_spend[0]->spend_total));	

$s=$this->input->post('date');

  
 $dt = new DateTime($s);

$date_s = $dt->format('m/d/Y');
$time_s = $dt->format('g:i A');

//echo $date_s, ' | ', $time_s;

$convert_time=date("H:i:s", strtotime($time_s));
  $date = str_replace("/", "-", $date_s);             	

$date1=explode('-', $date);
			$month=$date1[0];
			$date=$date1[1];
			$year=$date1[2];
$new_formated_date=$year.'-'.$month.'-'.$date;
					
			$data1=array(
				'ft_dbt_bank'=>$this->input->post('debit_bnk'),
				'ft_crd_bnk'=>$this->input->post('credit_bnk'),
				'ft_dbt_bal_old'=>$this->input->post('cur_bal'),
				'ft_crd_bal_old'=>$fact_result,
				'ft_user'=>$this->session->userdata['user']['username'],
				'ft_status'=>'1',
				'ft_date'=>$new_formated_date,		
				'ft_desc'=>$this->input->post('desc'),
				'ft_amount'=>$this->input->post('amount'),
				'ft_trsnf_sts'=>'1'
			);
	
			  $data2=array(
                   	'ae_cat'=>"Others",
                   	'ae_bank'=>$this->input->post('debit_bnk'),
                   	'ae_sts'=>"Bank Transfer",
                   	'ae_date'=>$new_formated_date,
                   	'ae_time'=>$convert_time,
                   	'ae_month'=>$month,
                   	'ae_year'=>$year,
                   	'ae_cash_type'=>"Spend",
                   	'ae_desc'=>$this->input->post('desc'),
                   	'ae_cat_desc'=>'',
                   	'ae_sts_desc'=>'',
                   	'ae_bank_desc'=>'Fund Debited from '.$this->input->post('debit_bnk').' to '.$this->input->post('credit_bnk'),
                   	'ae_user'=>$this->session->userdata['user']['username'],
                   	'ae_amount'=>$this->input->post('amount'),
                   		'ae_status'=>'1',
                   		'ae_status_data'=>'1'
                   );
			

			  $data3=array(
                   	'ae_cat'=>"Others",
                   	'ae_bank'=>$this->input->post('credit_bnk'),
                   	'ae_sts'=>"Bank Transfer",
                   	'ae_date'=>$new_formated_date,
                   	'ae_time'=>$convert_time,
                   	'ae_month'=>$month,
                   	'ae_year'=>$year,
                   	'ae_cash_type'=>"Received",
                   	'ae_desc'=>$this->input->post('desc'),
                   	'ae_cat_desc'=>'',
                   	'ae_sts_desc'=>'',
                   	'ae_bank_desc'=>'Fund Credited to '.$this->input->post('credit_bnk').' from '.$this->input->post('debit_bnk'),
                   	'ae_user'=>$this->session->userdata['user']['username'],
                   	'ae_amount'=>$this->input->post('amount'),
                   		'ae_status'=>'1',
                   		'ae_status_data'=>'1'
                   );

			if(empty($fund_trsf_id))
			{
				$bank_bal['bal_update2']=
				array(
					'credit_bank'=>$this->input->post('credit_bnk'),
					'debit_bank'=>$this->input->post('debit_bnk'),
					);
				$this ->session->set_userdata($bank_bal);


			  	$insert_id1=$this->Admin_model->insert_data('fund_transfer',$data1);
			  	$insert_id2=$this->Admin_model->insert_data('account_entry1',$data2);
			$insert_id3=$this->Admin_model->insert_data('account_entry1',$data3);
			 $this->session->set_flashdata('success', 'Fund successfully transfered');
			 	redirect('tx_funds');
			}
			else///updating the fund transfer
			{

$s=$this->input->post('date');
$dt = new DateTime($s);

$date_s = $dt->format('m/d/Y');
$time_s = $dt->format('g:i A');

//echo $date_s, ' | ', $time_s;

$convert_time=date("H:i:s", strtotime($time_s));
  $date = str_replace("/", "-", $date_s);             	

$date1=explode('-', $date);
			$month=$date1[0];
			$date=$date1[1];
			$year=$date1[2];
$new_formated_date=$year.'-'.$month.'-'.$date;


$bank_bal['bal_update2']=
array(
	'credit_bank'=>$this->input->post('credit_bnk'),
	'debit_bank'=>$this->input->post('debit_bnk'),
	);
$this ->session->set_userdata($bank_bal);


				$cond1=array('ft_id'=>$fund_trsf_id);
				$this->Admin_model->update_data('fund_transfer',$data1,$cond1);

				$cond2=array('ae_sts'=>"Bank Transfer",'ae_bank'=>$this->input->post('debit_bnk'),	'ae_bank_desc'=>'Fund Debited from '.$this->input->post('debit_bnk').' to '.$this->input->post('credit_bnk'), 'ae_amount'=>$this->input->post('old_amount'),'ae_date'=>$new_formated_date);
				$set1=$this->Admin_model->update_data('account_entry1',$data2,$cond2);
			

				$cond3=array('ae_sts'=>"Bank Transfer",'ae_bank'=>$this->input->post('credit_bnk'),	'ae_bank_desc'=>'Fund Credited to '.$this->input->post('credit_bnk').' from '.$this->input->post('debit_bnk'), 'ae_amount'=>$this->input->post('old_amount'),'ae_date'=>$new_formated_date);
				$set2=$this->Admin_model->update_data('account_entry1',$data3,$cond3);
				

			$this->session->set_flashdata('success', 'Data successfully updated');
				redirect('list_txs');
			}                 
	}
	}
}




	function tx_funds_approve()
	{
	if(logged_in())
		{
    
           $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
      if ((($page_cred[$i]=='tx_funds_approve')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

		$cond2=array('ft_trsnf_sts'=>'1','ft_status'=>'1');
		$qry['result']=$this->Admin_model->get_data('fund_transfer',$cond2);
		$this->load->view('admin/approve_tx_funds',$qry);

    }
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	}

		}

	}
	function approve_tx()
	{
	if(logged_in())
		{
		$table_id=$this->input->post('table_id');
		$data=array('ft_trsnf_sts'=>'2');
		$cond=array('ft_id'=>$table_id);
		$qry=$this->Admin_model->update_data('fund_transfer',$data,$cond);

		// $cond1=array('ft_id'=>$table_id);
		// $qry['result']=$this->Admin_model->get_data('fund_transfer',$cond1);

		// $data2=array('ae_status_data'=>'2');

		// $cond2=array('ae_sts'=>"Bank Transfer",'ae_bank'=>$qry['result'][0]->ft_dbt_bank,'ae_amount'=>$amount,'ae_date'=>$date);
		// 	$set1=	$this->Admin_model->update_data('account_entry1',$data2,$cond2);
		
		// $cond=array('ft_id'=>$table_id);
		// $qry=$this->Admin_model->update_data('fund_transfer',$data,$cond);

		if($qry)
			echo TRUE;
		}


	}
	


function delete_fund_transfer($id,$amount)
{
	if(logged_in())
		{
	$cond1=array('ft_id'=>$id);
	$qry['result']=$this->Admin_model->get_data('fund_transfer',$cond1);

	$cond=array('ft_id'=>$id);
	$data=array('ft_status'=>'0');
	$data['result']=$this->Admin_model->update_data('fund_transfer',$data,$cond);

	$date=$qry['result'][0]->ft_date;

	$date1=explode('-', $date);
	// echo $date;
	// print_r($date1) ;
	$year=$date1[0];
			$month=$date1[1];
			

	$data2=array('ae_status'=>'0');

	$data3=array('ae_status'=>'0');

	$cond2=array('ae_sts'=>"Bank Transfer",'ae_bank'=>$qry['result'][0]->ft_dbt_bank,	'ae_bank_desc'=>'Fund Debited from '.$qry['result'][0]->ft_dbt_bank.' to '.$qry['result'][0]->ft_crd_bnk, 'ae_amount'=>$amount,'ae_date'=>$date);
			$set1=	$this->Admin_model->update_data('account_entry1',$data2,$cond2);
		//	echo $set1;

	$cond3=array('ae_sts'=>"Bank Transfer",'ae_bank'=>$qry['result'][0]->ft_crd_bnk,'ae_bank_desc'=>'Fund Credited to '.$qry['result'][0]->ft_crd_bnk.' from '.$qry['result'][0]->ft_dbt_bank, 'ae_amount'=>$amount,'ae_date'=>$date);
	$set2=$this->Admin_model->update_data('account_entry1',$data3,$cond3);
	//echo $set2;


	$bank_bal['bal_update2']=
array(
	'credit_bank'=>$qry['result'][0]->ft_crd_bnk,
	'debit_bank'=>$qry['result'][0]->ft_dbt_bank,
	);
$this ->session->set_userdata($bank_bal);


	 $this->session->set_flashdata('success', 'Data successfully removed');
	 redirect('list_txs','refersh');
	}
}






}