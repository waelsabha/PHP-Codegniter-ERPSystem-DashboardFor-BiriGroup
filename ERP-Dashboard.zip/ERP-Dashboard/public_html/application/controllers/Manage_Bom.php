<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manage_Bom extends CI_Controller {

	function create_bom_data()
	{
		$this->load->view('admin/sample_excel');
	}

	function submit_bom_data()
	{
		$this -> load -> library('excel');
		$this -> load -> library('image_lib');
		$path = 'uploads/excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this ->upload -> do_upload('userfile')) 
		{
			$error = array('error' => $this -> upload -> display_errors());
			$this -> session -> set_flashdata('errors', $error['error']);
			redirect("sample_excel_upload", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this -> upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			
			$parent = trim($allDataInSheet[$i]['M']);

			if($parent=="999")
			{
				$prd_name = trim($allDataInSheet[$i]['D']);
				$no_inputs = trim($allDataInSheet[$i]['E']);
				$size = trim($allDataInSheet[$i]['F']);

				$fetchData = array(
				  	'bom_prd_name'=>$this ->security -> xss_clean(stripslashes($prd_name)),
                   	'bom_size'=>$this ->security -> xss_clean(stripslashes($size)),
                   	'bom_no_inputs'=>$this ->security -> xss_clean(stripslashes($no_inputs)),
                   	'bom_sts'=>'1'
                   	);
				$insert_id_parent=$this->Admin_model->insert_data('bom_data',$fetchData);
			}
			else
			{
				$qnty=trim($allDataInSheet[$i]['N']);
				$base_qnty=trim($allDataInSheet[$i]['W']);
				$unit=trim($allDataInSheet[$i]['X']);
				$type=trim($allDataInSheet[$i]['O']);
				$position=trim($allDataInSheet[$i]['K']);
				$focus_id=trim($allDataInSheet[$i]['L']);
				$rate=trim($allDataInSheet[$i]['R']);
				$mould=trim($allDataInSheet[$i]['V']);

				$fetchData2 = array(
					'bom_parent_id'=>$insert_id_parent,
				  	'bom_position'=>$this ->security -> xss_clean(stripslashes($position)),
                   	'bom_focus_id'=>$this ->security -> xss_clean(stripslashes($focus_id)),
                   	'bom_qty'=>$this ->security -> xss_clean(stripslashes($qnty)),
                   	'bom_rate'=>$this ->security -> xss_clean(stripslashes($rate)),
                   	'bom_base_qnty'=>$this ->security -> xss_clean(stripslashes($base_qnty)),
                   	'bom_unit'=>$this ->security -> xss_clean(stripslashes($unit)),
                   	'bom_type'=>$this ->security -> xss_clean(stripslashes($type)),
                   	'bom_mould'=>$this ->security -> xss_clean(stripslashes($mould)),
                   	'bom_sts'=>'1',
                   	);
				$insert_id_child=$this->Admin_model->insert_data('bom_data',$fetchData2);
				//$status = true;
			}
		
			
				//print_r($fetchData);
			//if (!($this ->tm->update_data("products", $fetchData,array('prod_id_focus'=>trim($allDataInSheet[$i]['A'])))))
					//$status = false;
		}
		// if ($status)
		// 	$this ->session-> set_flashdata('success', 'Imported Successfully');
		// else
		// 	$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		 redirect("sample_bom", "refresh");
	}






























}