<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Import_excel extends CI_Controller {

	public function __construct() {
		parent::__construct();
		 $this -> load -> helper('session');
		
	}

	public function excel_upload() {
		if(logged_in())
		{
			  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
        if ((($page_cred[$i]=='acc_excel_upload')||($this ->session->userdata['user']['main_dept'])=="Main"))
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

			$this ->load-> view('admin/acc_excel_upload');
			}
      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}

		}
	}

	// upload xlsx|xls file
	// public function index() {
	// $data=null;
	// $this->load->view('admin/pages/import_table', $data);
	// }
	// import excel data
	public function submit_excel_sheet() 
	{
		$flag = 0;
		$er=array();
		$error_string=""; 
		
		$this -> load -> library('excel');
		$this -> load -> library('image_lib');
		$path = 'uploads/excel/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this -> load -> library('upload', $config);
		$this -> upload -> initialize($config);

		if (!$this -> upload -> do_upload('userfile')) 
		{
			$error = array('error' => $this -> upload -> display_errors());
			$this -> session -> set_flashdata('errors', $error['error']);
			redirect("acc_excel_upload", "refresh");
		} 
		else 
		{
			$data = array('userfile' => $this -> upload -> data());
		}
		
		if (!empty($data['userfile']['file_name'])) 
		{
			$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		try 
		{
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{
			$cat = trim($allDataInSheet[$i]['A']);
			
			$cat_desc = trim($allDataInSheet[$i]['B']);
			
			$bank = trim($allDataInSheet[$i]['C']);
			$bank_desc = trim($allDataInSheet[$i]['D']);
			$sts = trim($allDataInSheet[$i]['E']);
			$sts_desc = trim($allDataInSheet[$i]['F']);
			$amount=trim($allDataInSheet[$i]['G']);
			$cash_type = trim($allDataInSheet[$i]['H']);
			$main_desc = trim($allDataInSheet[$i]['I']);
			$date = trim($allDataInSheet[$i]['J']);
			
			
			if(empty($cat))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell A. Category cannot be empty.<br>";
			}
			if(empty($bank))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell C.Bank Name  cannot be empty.<br>";
			}
			if(empty($sts))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell E.Status cannot be empty.<br>";
			}
			if(empty($amount) || !is_numeric(trim($amount)))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell G.Amount cannot be empty and it should be numeric.<br>";
			}
			if(empty($cash_type))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell H.Cash Type  cannot be empty.<br>";
			}
			if(empty($main_desc))
			{
				$flag=1;
				$error_string.="You have an error in Row $i of Cell I.Main Description cannot be empty.<br>";
			}
			if(empty($date))
			{
				// $fun=$this->validateDate($date);
				// if($fun=='1')
				// {

				// }
				// else
				// {
					$flag=1;
				$error_string.="You have an error in Row $i of Cell J. Date cannot be empty. Please check the date format. It must be month/date/year time . Eg: 2/14/19 12:00 AM<br>";
				//}
				
			}		
		}
		if($flag==1)
		{
		
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/excel/".$import_xls_file);
			redirect('acc_excel_upload','refresh');
		}
		else
		{
			$dwnload_title=$this->input->post('dwnload_title');
			$data23=array(
			'excl_title'=>$dwnload_title,
			'excl_file'=>$inputFileName,
			'excl_status'=>"1",
			'excl_type' =>'result');
			$insert_id=$this ->Admin_model-> insert_data("excel_file", $data23);
			 $this -> insert_table($allDataInSheet,$insert_id);
		}
	}

	function insert_table($allDataInSheet,$insert_id) 
	{
		$arrayCount = count($allDataInSheet);
		$flag = 0;
		$status = true;
		for ($i = 2; $i <= $arrayCount; $i++) 
		{

			$s=$allDataInSheet[$i]['J'];
			$array = explode(' ', $s);
			$d = $array[1];
						
			$my_excel_date=date("m/d/Y", strtotime($array[0]));
			$my_excel_time=date("H:i:s", strtotime($d));

 $date = str_replace("/", "-", $my_excel_date);             	
			$date1=explode('-', $date);
			$month=$date1[0];
			$date=$date1[1];
			$year=$date1[2];
$new_formated_date=$year.'-'.$month.'-'.$date;

			$cat = trim($allDataInSheet[$i]['A']);	
			$cat_desc = trim($allDataInSheet[$i]['B']);		
			$bank = trim($allDataInSheet[$i]['C']);
			$bank_desc = trim($allDataInSheet[$i]['D']);
			$sts = trim($allDataInSheet[$i]['E']);
			$sts_desc = trim($allDataInSheet[$i]['F']);
						
			$amount=trim($allDataInSheet[$i]['G']);
			$cash_type = trim($allDataInSheet[$i]['H']);
			$main_desc = trim($allDataInSheet[$i]['I']);

			//$date = trim($allDataInSheet[$i]['I']);
					
			if (!empty($cat) && !empty($bank) && !empty($sts) && !empty($cash_type) && !empty($main_desc) 
			&& !empty($date))//checking duplication of keys
			{
				$fetchData = array(

					  	'ae_cat'=>$this ->security -> xss_clean(stripslashes($cat)),
                   	'ae_bank'=>$this ->security -> xss_clean(stripslashes($bank)),
                   	'ae_sts'=>$this ->security -> xss_clean(stripslashes($sts)),
                   	'ae_date'=>$new_formated_date,
                   	'ae_month'=>$month,
                   	'ae_year'=>$year,
                   	'ae_time'=>$my_excel_time,
                   	'ae_cash_type'=>$this ->security -> xss_clean(stripslashes($cash_type)),
                   	'ae_desc'=>$this ->security -> xss_clean(stripslashes($main_desc)),
                   	'ae_cat_desc'=>$this ->security -> xss_clean(stripslashes($cat_desc)),
                   	'ae_sts_desc'=>$this ->security -> xss_clean(stripslashes($sts_desc)),
                   	'ae_bank_desc'=>$this ->security -> xss_clean(stripslashes($bank_desc)),
                  'ae_amount'=>$this ->security -> xss_clean($amount),
                   	'ae_status'=>'1',
                   	'ae_status_data'=>'1',
				  'ae_excl_id_realtion'=>$insert_id,
				  'ae_user'=>$this->session->userdata['user']['username']
					);

				//print_r($fetchData);

			if (!($this ->Admin_model-> insert_data("account_entry1", $fetchData)))
					$status = false;
			}
		}

		if ($status)
			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');
		redirect("acc_excel_upload", "refresh");
	}
    

    function validateDate($date, $format = 'Y-m-d')
{
    $d = DateTime::createFromFormat($format, $date);
    // The Y ( 4 digits year ) returns TRUE for any integer with any number of digits so changing the comparison from == to === fixes the issue.
   if($d && $d->format($format) === $date)
   	return TRUE;
   else 
   	return false;
}
   


}
