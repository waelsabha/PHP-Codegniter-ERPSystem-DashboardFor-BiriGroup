<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts_suppliers extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->model(array('Account_model'));
		$this->load->helper(array('session','gnrl'));	
	}

	function add_suppliers()
	{
		if(logged_in())
		{

        

             $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='add-suppliers')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

				$cond=array('status'=>'1');
				$data['country']=$this->Admin_model->get_data('country_val',$cond);	
			   $this->load->view('admin/accounts/add_suppliers',$data);

		 }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


		}
	}

		function list_acc_suppliers()
	{
		if(logged_in())
		{
          $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='list-account-suppliers')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

		    $cond=array('as_sts'=>'1');
		   $data['result']=$this->Admin_model->get_data('acc_suppliers',$cond);	
	       $this->load->view('admin/accounts/list_acc_suppliers',$data);
  }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


		}
	}

	function delete_supplier($id)
	{
		if(logged_in())
		{
			$data=array('as_sts'=>'0');
			$cond1=array('as_id'=>$id);
			$this->Admin_model->update_data('acc_suppliers',$data,$cond1);
		$this->session->set_flashdata('success', 'Data successfully updated');
			redirect('list-account-suppliers');
		}

	}


	function submit_acc_supplier()
	{
		$this->form_validation->set_rules('sup_name', 'Supplier Name', 'trim|required');
		$this->form_validation->set_rules('landline', 'Landline', 'trim|required');
	   	$this->form_validation->set_rules('contct_person', 'Contact person', 'trim|required');
	   
		$this->form_validation->set_rules('mobile_num', 'Mobile Number', 'trim|required');
		$this->form_validation->set_rules('address', 'Address', 'trim');
		$this->form_validation->set_rules('notes', 'Notes', 'trim');	

		if ($this->form_validation->run() == FALSE)
        {          
        $this->session->set_flashdata('sup_name', form_error('sup_name'));
		$this->session->set_flashdata('landline',form_error('landline'));
		$this->session->set_flashdata('contct_person', form_error('contct_person'));
		$this->session->set_flashdata('mobile_num', form_error('mobile_num'));
		$this->session->set_flashdata('address', form_error('address'));
		$this->session->set_flashdata('notes', form_error('notes'));
		redirect('add-suppliers','refersh');
        }
        else
        {
        	$suplr_id=$this->input->post('suplier_id');

        	$data=array(
           'as_supplier_name'=>$this->input->post('sup_name'),
            'as_landline'=>$this->input->post('landline'),
           'as_contact_person'=>$this->input->post('contct_person'),
           	'as_address'=>$this->input->post('address'),
           	'as_notes'=>$this->input->post('notes'),
           	'as_mobile'=>$this->input->post('mobile_num'),   
           	'as_staff'=>$this->session->userdata['user']['username'], 
           	'as_sts'=>'1'
           );
        if(empty($suplr_id))
        {
	        $insert_id=$this->Admin_model->insert_data('acc_suppliers',$data);

	        $cutomer_code='1'.str_pad($insert_id, 4, '0', STR_PAD_LEFT);
	        $data2=array('as_code'=>$cutomer_code);
	        $cond1=array('as_id'=>$insert_id);

			$this->Admin_model->update_data('acc_suppliers',$data2,$cond1);
			$this->session->set_flashdata('success', 'Data successfully inserted');
		}
		else
		{
			$cond1=array('as_id'=>$suplr_id);
			$this->Admin_model->update_data('acc_suppliers',$data,$cond1);
			$this->session->set_flashdata('success', 'Data successfully updated');
		}
			redirect('add-suppliers');
		
        }
	}





























}