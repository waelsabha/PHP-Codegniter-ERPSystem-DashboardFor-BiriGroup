<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ledger extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
		$this->load->library('numbertowordconvertsconver');	
	}


function sub_ledger()
{
	if(logged_in())
	{

    $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='sub-ledger')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

		$data['acc']=$this->Admin_model->get_data('master_accounts_tree');
	    $this->load->view('admin/financial_accounting/sub_ledger',$data);
}
 else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


	}
}

function submit_sub_ledger()
{
	if(logged_in())
	{
		$start_date=$this->input->post('start_date');
$start_date1=explode('/',$start_date);
			$month1=$start_date1[0];
			$date1=$start_date1[1];
			$year1=$start_date1[2];
$new_formated_date1=$year1.'-'.$month1.'-'.$date1;

$end_date=$this->input->post('end_date');
$end_date1=explode('/',$end_date);
			$month2=$end_date1[0];
			$date2=$end_date1[1];
			$year2=$end_date1[2];
$new_formated_date2=$year2.'-'.$month2.'-'.$date2;

// Echo $new_formated_date1;echo "<br/>";
// Echo $new_formated_date2;
// echo "<br/>";
// echo $this->input->post('acc_master_id');
		$data['form_input']=array(
			'acc_master_id'=>$this->input->post('acc_master_id'),
			'start_date'=>$this->input->post('start_date'),
			'end_date'=>$this->input->post('end_date'),
			'type'=>$this->input->post('type'),
			's_type'=>$this->input->post('s_type'),
		);


	
//pre_list($data);
		$type_transfer='';
		if($this->input->post('type')!='all')
		{
			if($this->input->post('type')=="credit")
			{
				$type_transfer='Income';
			}
			else
			{
				$type_transfer='Expense';
			}
		}

		if($this->input->post('type')=='all')
		{
	//	echo "in alll";echo"<br/>";echo $new_formated_date1;echo"<br/>";echo $this->input->post('acc_master_id');echo"<br/>";
$sql2=$this->db->query("
 SELECT 
  ( 
     CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)
    
 WHEN mat.atx_type_tx='Sales_Return' THEN  mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
   
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0) )
ELSE
    mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
    
 END
   ) 
   as atx_tot_amount,mat.atx_date, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,mat.atx_id ,
    mat.atx_vat_amount , mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
 WHERE mat.atx_sts = '1' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."'  order by mat.atx_date ASC");
	$result=$sql2->result_array();
		
	//pre_list($data['result']);

	if(  ($this->input->post('acc_master_id') !='1014') && ($this->input->post('acc_master_id')!='1013') 
	&& ($this->input->post('acc_master_id')!='1016') && ($this->input->post('acc_master_id')!='759') )
	{
	//	echo "in if-without vat  a/c as master a/c"; echo "<br/>";
	$old_sql_income1=$this->db->query("
  SELECT 
  ( 
     CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN 
     sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0)     
 WHEN mat.atx_type_tx='Sales_Return' THEN (sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0))  
   
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',sum(mat.atx_tot_amount*mat.atx_currency_value),sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0))
ELSE sum(mat.atx_tot_amount*mat.atx_currency_value)+COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0)     
 END
   ) 
   as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' 
  and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'
   order by mat.atx_date ASC");

	//print_r("SELECT IF(mat.atx_type_tx='Sales_Invoice',sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0) , (sum(mat.atx_tot_amount) + 
  //COALESCE(sum(mat.atx_vat_amount),0) ) ) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' 
  //and mat.atx_amount_type='Income' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");echo"<br/>";
	$income1=$old_sql_income1->result_array();


	
  //print_r(	$income1);

		//print_r($income1);echo"<br/>";
	$old_sql_exp1=$this->db->query("
  SELECT 
  ( 
     CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN (sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0) )   
 WHEN mat.atx_type_tx='Sales_Return' THEN (sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0))     
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',sum(mat.atx_tot_amount*mat.atx_currency_value),sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0))
ELSE (sum(mat.atx_tot_amount*mat.atx_currency_value)+COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0))      
 END
   ) 
    as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
	//print_r("SELECT IF(mat.atx_type_tx='Sales_Invoice',sum(mat.atx_tot_amount)-COALESCE(sum(mat.atx_vat_amount),0) , (sum(mat.atx_tot_amount) + COALESCE(sum(mat.atx_vat_amount),0)) )
  // as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
	//echo"<br/>";
	$exp1=$old_sql_exp1->result_array();
  //print_r(	$exp1);
	//print_r($exp1);echo"<br/>";
	$data['old_result']=$exp1[0]['tot_old_exp']-$income1[0]['tot_old_income'];
  //print_r($data['old_result']);
	}
	else
	{
		//echo "in else-with vvat  a/c as master a/c"; echo "<br/>";
		$old_sql_income1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount*mat.atx_currency_value),0) 
			 as tot_old_income FROM account_all_tx as mat 
		WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
		//print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");echo"<br/>";
		$income1=$old_sql_income1->result_array();

		//	print_r($income1);echo"<br/>";
		$old_sql_exp1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount*mat.atx_currency_value,0)) as tot_old_exp FROM account_all_tx as mat 
		WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
		//print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
		//echo"<br/>";
		$exp1=$old_sql_exp1->result_array();
		//print_r($exp1);echo"<br/>";
		$data['old_result']=$exp1[0]['tot_old_exp']-$income1[0]['tot_old_income'];
	}


	
	//print_r($data['old_result']);
		if(empty($result))
		{
			//echo "in alll-in if";echo"<br/>";
			$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)    
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)   
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0) )
-- ELSE
--    mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
--  END
--    ) 
--    as atx_tot_amount,
  mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='759' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
	$result=$sql2->result_array();

			if(empty($data['old_result']))
			{
    //  echo "in alll-in if-old result";echo"<br/>";
	if( ($this->input->post('acc_master_id') !='1014') && ($this->input->post('acc_master_id')!='1013') 
	&& ($this->input->post('acc_master_id')!='1016') && ($this->input->post('acc_master_id')!='759') )
				{
				$old_sql_income1=$this->db->query("
       SELECT mat.atx_tot_amount*mat.atx_currency_value as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income'
		 and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
			//	print_r("SELECT sum(mat.atx_tot_amount) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo"<br/>";
				$income1=$old_sql_income1->result_array();
			
				$old_sql_exp1=$this->db->query("
        SELECT mat.atx_tot_amount*mat.atx_currency_value as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
			//	print_r("SELECT sum(mat.atx_tot_amount) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo "<br/>";
				$exp1=$old_sql_exp1->result_array();

				$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
			//print_r($data['old_result']);
				}
				else
				{
          //  echo "in alll-in else-old result";echo"<br/>";
					$old_sql_income1=$this->db->query("SELECT mat.atx_tot_amount*mat.atx_currency_value as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
				//  print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo"<br/>";
					$income1=$old_sql_income1->result_array();
				
					$old_sql_exp1=$this->db->query("SELECT mat.atx_tot_amount*mat.atx_currency_value as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
				//	print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo "<br/>";
					$exp1=$old_sql_exp1->result_array();

					$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
				//print_r($data['old_result']);
				}
			}
		}
		else
		{
			//	echo "in alll-in else";echo"<br/>";
				$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)     
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0) )
-- ELSE
--     mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)   
--  END
--    ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id , mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount 
    mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
			FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' 
			and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' or mat.atx_acc_id='".$this->input->post('acc_master_id')."' 
			and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
			$result=$sql2->result_array();

		//	print_r($result);

			if(empty($data['old_result']))
			{
   //   echo "in alll-in else-in if-old result";echo"<br/>";
				if(  ($this->input->post('acc_master_id') !='1014') && ($this->input->post('acc_master_id')!='1013')
				 && ($this->input->post('acc_master_id')!='1016') && ($this->input->post('acc_master_id')!='759') )
				{
				$old_sql_income1=$this->db->query(" SELECT
	 COALESCE(sum(mat.atx_tot_amount*mat.atx_currency_value),0)  as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and
		  mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'
		   or mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
				//print_r("SELECT sum(mat.atx_tot_amount) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo"<br/>";
				$income1=$old_sql_income1->result_array();
			
				$old_sql_exp1=$this->db->query("
        SELECT COALESCE(sum(mat.atx_tot_amount*mat.atx_currency_value),0) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and
		  mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and
		   mat.atx_date < '".$new_formated_date1."' 
		  or mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'
		  order by mat.atx_date ASC");
				//print_r("SELECT sum(mat.atx_tot_amount) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo "<br/>";
				$exp1=$old_sql_exp1->result_array();

				$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
			//print_r($data['old_result']);
				}
				else
				{
         //  echo "in alll-in else-in else- old result";echo"<br/>";
					$old_sql_income1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount*mat.atx_currency_value),0) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' or mat.atx_acc_id='".$this->input->post('acc_master_id')."'
					    and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'
					   order by mat.atx_date ASC");
				//  print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo"<br/>";
					$income1=$old_sql_income1->result_array();
				
					$old_sql_exp1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount*mat.atx_currency_value),0)  as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  
					 and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' or mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'
					  order by mat.atx_date ASC");
				//	print_r("SELECT COALESCE(sum(mat.atx_tot_amount),0) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");echo "<br/>";
					$exp1=$old_sql_exp1->result_array();

					$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
				//print_r($data['old_result']);
				}
			}

			// print_r("SELECT mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
			// FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
			// WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."'  and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' 
			// and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' or mat.atx_acc_id='".$this->input->post('acc_master_id')."' 
			// and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");echo"<br/>";
		}
		$data['result']=$result;
	}
	else
	{
	//	echo "in type";echo"<br/>";
		$sql2=$this->db->query("
	SELECT 
  ( 
     CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN  mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)   
 WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)   
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0) )
ELSE
   mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
    
 END
   ) 
   as atx_tot_amount,mat.atx_date, mat.atx_id,mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
    mat.atx_vat_amount ,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' 
and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
	$result=$sql2->result_array();

	$old_sql_income1=$this->db->query("
  SELECT 
  ( 
   CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN
   sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0)   
 WHEN mat.atx_type_tx='Sales_Return' THEN  sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0)
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',sum(mat.atx_tot_amount*mat.atx_currency_value),sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0))
ELSE
   sum(mat.atx_tot_amount*mat.atx_currency_value)+COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0) 
 END
   )  
  as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
	$income1=$old_sql_income1->result_array();
	
	$old_sql_exp1=$this->db->query("
  SELECT 
  ( 
    CASE 
    WHEN mat.atx_type_tx='Sales_Invoice' THEN sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0)  
 WHEN mat.atx_type_tx='Sales_Return' THEN sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0)
 WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',sum(mat.atx_tot_amount*mat.atx_currency_value),sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0) )
ELSE
   sum(mat.atx_tot_amount*mat.atx_currency_value)+COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0)  
    
 END
   ) 
   as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."' order by mat.atx_date ASC");
	$exp1=$old_sql_exp1->result_array();
	$data['old_result']=$exp1[0]['tot_old_exp']-$income1[0]['tot_old_income'];

		if(empty($result))
		{
		//	echo "in type-in if";echo"<br/>";
			if($this->input->post('type')=="credit")
			{
			//	echo "in type credit-in if";echo"<br/>";
				$type_transfer='Expense';
					$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)
--  WHEN mat.atx_tranfer_type='journal' THEN 
--  if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0) )
-- ELSE mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0) 
--  END
--    ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount 
    mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' 
and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
				if(empty($data['old_result']))
				{
					$old_sql_income1=$this->db->query("SELECT sum(mat.atx_tot_amount*mat.atx_currency_value) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Income' 
					and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
					$income1=$old_sql_income1->result_array();
				
					$old_sql_exp1=$this->db->query("SELECT sum(mat.atx_tot_amount*mat.atx_currency_value) as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and mat.atx_amount_type='Expense' 
					and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
					$exp1=$old_sql_exp1->result_array();
					$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
				}
			}
			else
			{
				//echo "in type debit-in if";echo"<br/>";
				$type_transfer='Income';
	$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)
--  WHEN mat.atx_type_tx='Sales_Return' THEN  mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)
--  WHEN mat.atx_tranfer_type='journal' THEN 
--  if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0))
-- ELSE mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
--  END
--    ) 
--    as atx_tot_amount  ,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
    -- mat.atx_vat_amount ,
    mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014'
 and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");

				if(empty($data['old_result']))
				{
					$old_sql_income1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount*mat.atx_currency_value),0) as tot_old_income FROM account_all_tx as mat WHERE mat.atx_sts = '1' and 
					mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
					$income1=$old_sql_income1->result_array();
				
					$old_sql_exp1=$this->db->query("SELECT COALESCE(sum(mat.atx_tot_amount*mat.atx_currency_value),0)  as tot_old_exp FROM account_all_tx as mat WHERE mat.atx_sts = '1' and
					 mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date < '".$new_formated_date1."'  order by mat.atx_date ASC");
					$exp1=$old_sql_exp1->result_array();
				}
			}
			$result=$sql2->result_array();
			$data['old_result']=$income1[0]['tot_old_income']-$exp1[0]['tot_old_exp'];
		}
		else
		{
			//	echo "in type-in else";echo"<br/>";
			if($this->input->post('type')=="credit")
			{
				$type_transfer='Expense';
				$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0) )
-- ELSE mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
--  END
--  ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount ,
     mat.*, mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
					FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
					WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' 
					and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and 
					mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' or mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' 
					and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' 
					order by mat.atx_date ASC");
			}
			else
			{
				$type_transfer='Income';
				$sql2=$this->db->query("SELECT 
--   ( 
--      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)   
--  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
--  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0) )
-- ELSE mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)   
--  END
--    ) 
--    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
--     mat.atx_vat_amount ,
  mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
				FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
				WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759'
				and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."'
				 or mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' 
				and mat.atx_type_tx!='PDR' and mat.atx_type_tx!='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
			}
			$result=$sql2->result_array();
		}
		$data['result']=$result;
	}
///////////////////start of pdp or pdr based reporting ////////////////////////////////////////////////////////////////////if you want pdp showin from here and also hiddien from here 21-8-2023

// 		if($this->input->post('type')=='all')
// 		{
// $sql21=$this->db->query("
// SELECT 
//   ( 
//      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)
//  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)
//  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0))
// ELSE
// 	mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)   
    
//  END
//    ) 
//    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
//     mat.atx_vat_amount ,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
// FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
// WHERE mat.atx_sts = '1' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_type_tx='PDR' or mat.atx_type_tx='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
// 	$data['result2']=$sql21->result_array();

// 		if(empty($data['result2']))
// 		{
// 			$sql21=$this->db->query(" SELECT 
// --   ( 
// --      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
// --  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value)
// --  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0) )
// -- ELSE mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)   
// --  END
// --    ) 
// --    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
// --     mat.atx_vat_amount ,
//       mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
// FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
// WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx='PDR' or mat.atx_type_tx='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
// 	$data['result2']=$sql21->result_array();

// 		}
// 	}
// 	else
// 	{
// 		$sql21=$this->db->query(" SELECT 
// --   ( 
// --      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value)
// --  WHEN mat.atx_type_tx='Sales_Return' THEN  mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)
// --  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',sum(mat.atx_tot_amount*mat.atx_currency_value),sum(mat.atx_tot_amount*mat.atx_currency_value)-COALESCE(sum(mat.atx_vat_amount*mat.atx_currency_value),0))
// -- ELSE
// --   mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)    
// --  END
// --    ) 
// --    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
// --     mat.atx_vat_amount ,
//     mat.*, mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
// FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
// WHERE mat.atx_sts = '1' and mat.atx_acc_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_type_tx='PDR' or mat.atx_type_tx='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
// 	$data['result2']=$sql21->result_array();

// 		if(empty($data['result2']))
// 		{
// 			if($this->input->post('type')=="credit")
// 			{
// 				$type_transfer='Expense';
// 					$sql21=$this->db->query("SELECT 
// --   ( 
// --      CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)     
// --  WHEN mat.atx_type_tx='Sales_Return' THEN mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)     
// --  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0))
// -- ELSE
// --    mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)      
// --  END
// --    ) 
// --    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
// --     mat.atx_vat_amount ,
//       mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
// FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
// WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx='PDR' or mat.atx_type_tx='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
// 			}
// 			else
// 			{
// 					$type_transfer='Income';
// 	$sql21=$this->db->query("SELECT 
// --   ( 
// --  CASE WHEN mat.atx_type_tx='Sales_Invoice' THEN  mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)    
// --  WHEN mat.atx_type_tx='Sales_Return' THEN  mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)  
// --  WHEN mat.atx_tranfer_type='journal' THEN if(mat.atx_vat_amount='null',mat.atx_tot_amount*mat.atx_currency_value,mat.atx_tot_amount*mat.atx_currency_value-COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0))
// -- ELSE mat.atx_tot_amount*mat.atx_currency_value+COALESCE(mat.atx_vat_amount*mat.atx_currency_value,0)    
// --  END
// --    ) 
// --    as atx_tot_amount,mat.atx_date,mat.atx_id, mat.atx_type_tx, mat.atx_doc_no, mat.atx_main_id, mat.atx_cust_id, mat.atx_acc_id, mat.atx_amount_type,  mat.atx_tranfer_type,mat.atx_region,mat.atx_narration,mat.atx_quantity,mat.atx_salesman,mat.atx_cheque_no,mat.atx_bill_no,
// --     mat.atx_vat_amount ,
//       mat.*,mat2.label as acc_name_bank_sales,mat3.label as cust_acc_name
// FROM account_all_tx as mat join master_accounts_tree as mat2 on mat2.id=mat.atx_acc_id join master_accounts_tree as mat3 on mat3.id=mat.atx_cust_id 
// WHERE mat.atx_sts = '1' and mat.atx_cust_id='".$this->input->post('acc_master_id')."' and mat.atx_amount_type='".$type_transfer."' and mat.atx_acc_id!='1014' and mat.atx_acc_id!='1013' and mat.atx_acc_id!='1016' and mat.atx_acc_id!='759' and mat.atx_type_tx='PDR' or mat.atx_type_tx='PDP' and mat.atx_date BETWEEN '".$new_formated_date1."' AND '".$new_formated_date2."' order by mat.atx_date ASC");
// 			}
// 			$data['result2']=$sql21->result_array();
// 		}
// 	}
$data['account_name']=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$this->input->post('acc_master_id')));
$data['acc']=$this->Admin_model->get_data('master_accounts_tree');

	//pre_list($data['old_result']);
//print_r($sql2); 
	//pre_list($data['result']);
	$this->load->view('admin/financial_accounting/sub_ledger',$data);
	}
}

function get_doc_details()
{
	$master_acc_id=$this->input->post('master_acc_id');
	$details_region=$this->input->post('region');

	$result=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$master_acc_id));

	if($result[0]->atx_type_tx=="Receipt" || $result[0]->atx_type_tx=="PDR")
	{
		if($result[0]->atx_type_tx=="PDR")
			$dataa=$this->Admin_model->get_data('cash_bank_pdr',array('cbr_id'=>$result[0]->atx_main_id));
		else
			$dataa=$this->Admin_model->get_data('cash_bank_receipt',array('cbr_id'=>$result[0]->atx_main_id));

				if($dataa)
				{
					$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->cbr_company));
					$acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->cbr_acc));
					$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->cbr_currency));
					$customer_list=explode('|#|',$dataa[0]->cbr_customer_acc);
					foreach($customer_list as $cs)
					{
						$data_cl[]=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$cs));
					}
					
						$salesman_list=explode('|#|',$dataa[0]->cbr_salesman);
					foreach($salesman_list as $sl)
					{
						$data_sl[]=$this->Admin_model->get_data('employee_details',array('ed_id'=>$sl));
					}

					$cust_amount_list=explode('|#|',$dataa[0]->cbr_amount);
					$ref_list=explode('|#|',$dataa[0]->cbr_ref);
					$rmk_list=explode('|#|',$dataa[0]->cbr_remark);
					
					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Recipt Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->cbr_doc_no."</p>";
					$html.="<p>User Created: ".$dataa[0]->cbr_created_by."</p>";
					$html.="<p>Date: ".$dataa[0]->cbr_date."</p>";
					$html.="<p>Due Date: ".$dataa[0]->cbr_due_date."</p>";
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Cash &amp; Bank : ".$acc_details[0]->label."</p>";
					$html.="<p>Company: ".$company_details[0]->mcomp_name."</p>";
					$html.="<p>PDC No.: ".$dataa[0]->cbr_pdc_no."</p>";
					$html.="<p>Cheque No.: ".$dataa[0]->cbr_cheque_no."</p>";
					$html.="<p>Bill No.: ".$dataa[0]->cbr_bill_no."</p>";
					$html.="<p>Narration.: ".$dataa[0]->cbr_narration."</p>";
					$html.="<p>Linked to Invoice.: ".str_replace('|#|', '<br/>', $dataa[0]->cbr_sales_inv_linked)."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Total Amount : ".$dataa[0]->cbr_tot_amount."</p>";
				$html.="<p>Current Status: ".$dataa[0]->cbr_current_status."</p>";
					$html.="<p>Attachements: <a href='".base_url('uploads/receipt_files/'.$dataa[0]->cbr_attachments)."' target='_blank'> ".$dataa[0]->cbr_attachments."</a></p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

					$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th><th>Salesman</th><th>Account</th><th>Amounts</th><th>Reference</th><th>Remark</th></thead>";
					$html.="<tbody>";
					foreach($data_cl as $key=>$d)
					{
						$cust_amount_tot[]=$cust_amount_list[$key];
						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$data_sl[$key][0]->ed_name."</td>";
						$html.="<td>".$d[0]->label."</td>";
						$html.="<td>".$cust_amount_list[$key]."</td>";
						$html.="<td>".$ref_list[$key]."</td>";
						$html.="<td>".$rmk_list[$key]."</td>";
						$html.="</tr>";
					}
					$html.="</tbody>";
					$html.='<tfoot>
						<tr>
							<td colspan="3" align="center">TOTALS:</td>
							<td>'.number_format((float)array_sum($cust_amount_tot), 2, '.', '').'</td>
							<td></td>
							<td></td>
						</tr>
					</tfoot>';
					$html.="</table>";
					/*** start of table  ***/
					echo $html;
				}
	}
	elseif($result[0]->atx_type_tx=="Payments" || $result[0]->atx_tranfer_type=="payments" || $result[0]->atx_type_tx=="PDP")
	{
		if($result[0]->atx_type_tx=="PDP")
			$dataa=$this->Admin_model->get_data('cash_bank_pdp',array('cbr_id'=>$result[0]->atx_main_id));
			else
			$dataa=$this->Admin_model->get_data('cash_bank_payments',array('cbr_id'=>$result[0]->atx_main_id));

			if($dataa)
			{
				$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->cbr_company));
				$acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->cbr_acc));
				$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->cbr_currency));
				$customer_list=explode('|#|',$dataa[0]->cbr_customer_acc);
				foreach($customer_list as $cs)
				{
					$data_cl[]=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$cs));
				}
				
					$salesman_list=explode('|#|',$dataa[0]->cbr_salesman);
				foreach($salesman_list as $sl)
				{
					$data_sl[]=$this->Admin_model->get_data('employee_details',array('ed_id'=>$sl));
				}
				$cust_amount_list=explode('|#|',$dataa[0]->cbr_amount);
					$ref_list=explode('|#|',$dataa[0]->cbr_ref);
					$rmk_list=explode('|#|',$dataa[0]->cbr_remark);
						$tax_list=explode('|#|',$dataa[0]->cbr_tax_code);
					$vat_per_list=explode('|#|',$dataa[0]->cbr_vat);

					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Payment Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->cbr_doc_no."</p>";
					$html.="<p>User Created: ".$dataa[0]->cbr_created_by."</p>";
					$html.="<p>Date: ".$dataa[0]->cbr_date."</p>";
					$html.="<p>Due Date: ".$dataa[0]->cbr_due_date."</p>";
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Cash &amp; Bank : ".$acc_details[0]->label."</p>";
					$html.="<p>Company: ".$company_details[0]->mcomp_name."</p>";
					$html.="<p>PDC No.: ".$dataa[0]->cbr_pdc_no."</p>";
					$html.="<p>Bill No.: ".$dataa[0]->cbr_bill_no."</p>";
					$html.="<p>Narration: ".$dataa[0]->cbr_narration."</p>";

					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Total Amount : ".number_format((float)$dataa[0]->cbr_tot_amount+$dataa[0]->cbr_tot_vat_amount, 2, '.', '')."</p>";
				$html.="<p>Current Status: ".$dataa[0]->cbr_current_status."</p>";
					$html.="<p>Attachements: <a href='".base_url('uploads/payments_files/'.$dataa[0]->cbr_attachments)."' target='_blank'> ".$dataa[0]->cbr_attachments."</a></p>";

					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

						$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
				$html.="<thead><th></th><th>Salesman</th><th>Account</th><th>Amounts</th><th>Reference</th><th>Remark</th><th>Tax Code</th><th>Vat%</th><th>Amount Total</th></thead>";
					$html.="<tbody>";
					foreach($data_cl as $key=>$d)
					{
						if($dataa[0]->cbr_vat_type=='1')
						{
						$new_tot_value=$cust_amount_list[$key]/1.05;
						$vat_amount_tot[]=$new_tot_value*0.05;
						$new_vat_value=$new_tot_value*0.05;
						$amount_tot[]=$cust_amount_list[$key]/1.05;
						$final_tot_amount[]=$cust_amount_list[$key];
						}
						else
						{
							$new_tot_value=$cust_amount_list[$key];
							$vat_amount_tot[]=0;
							$new_vat_value=$new_tot_value*0.05;
							$amount_tot[]=$cust_amount_list[$key];
							$final_tot_amount[]=$cust_amount_list[$key];
						}

						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$data_sl[$key][0]->ed_name."</td>";
						$html.="<td>".$d[0]->label."</td>";
						$html.="<td>".number_format((float)$new_tot_value, 2, '.', '')."</td>";
						$html.="<td>".$ref_list[$key]."</td>";
						$html.="<td>".$rmk_list[$key]."</td>";
						$html.="<td>".$tax_list[$key]."</td>";
						$html.="<td>".number_format((float)$new_vat_value, 2, '.', '')."</td>";
						$html.="<td>".number_format((float)$cust_amount_list[$key], 2, '.', '')."</td>";
						$html.="</tr>";
					}
					$vat_sum=array_sum($vat_amount_tot);
					$html.="</tbody>";
					$html.="<tfoot>";
					$html.="<tr>";
					
					$html.="<td colspan='3'>Totals:</td>";
					
					$html.="<td>".number_format((float)array_sum($amount_tot), 2, '.', '')."</td>";
					$html.="<td></td>";
					$html.="<td></td>";
					$html.="<td></td>";
					$html.="<td>".number_format((float)array_sum($vat_amount_tot), 2, '.', '')."</td>";
					$html.="<td>".number_format((float)array_sum($final_tot_amount), 2, '.', '')."</td>";
					
					$html.="</tr>";
					$html.="</tfoot>";
					$html.="</table>";
					$html.="<p>Vat Amount Total:".number_format((float)$vat_sum, 2, '.', '')."</p>";
					/*** start of table  ***/
					echo $html;	
			}
	}
	elseif($result[0]->atx_type_tx=="Petty_cash" || $result[0]->atx_tranfer_type=="petty_cash")
	{
		$dataa=$this->Admin_model->get_data('cash_bank_petty_cash',array('cbr_id'=>$result[0]->atx_main_id));
			if($dataa)
			{
				$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->cbr_company));
				$acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->cbr_acc));
				$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->cbr_currency));
				$place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->cbr_place_supply_id));
				$jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->cbr_jurisdication));

				$customer_list=explode('|#|',$dataa[0]->cbr_customer_acc);
				foreach($customer_list as $cs)
				{
					$data_cl[]=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$cs));
				}
				
				$salesman_list=explode('|#|',$dataa[0]->cbr_salesman);
				foreach($salesman_list as $sl)
				{
					$data_sl[]=$this->Admin_model->get_data('employee_details',array('ed_id'=>$sl));
				}

				$cust_amount_list=explode('|#|',$dataa[0]->cbr_amount);
					$ref_list=explode('|#|',$dataa[0]->cbr_ref);
					$rmk_list=explode('|#|',$dataa[0]->cbr_remark);
					$tax_list=explode('|#|',$dataa[0]->cbr_tax_code);
					$vat_per_list=explode('|#|',$dataa[0]->cbr_vat);

					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Petty Cash Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->cbr_doc_no."</p>";
					$html.="<p>User Created: ".$dataa[0]->cbr_created_by."</p>";
					$html.="<p>Date: ".$dataa[0]->cbr_date."</p>";
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					$html.="<p>Vat Type: ";
					if($dataa[0]->cbr_vat_type=='1')
					{
						$vat_tyype='Taxable';
					}
					else
					{
						$vat_tyype='Non-Taxable';
					}
					$html.=$vat_tyype;
					$html.="</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Cash &amp; Bank : ".$acc_details[0]->label."</p>";
					$html.="<p>Company: ".$company_details[0]->mcomp_name."</p>";
					$html.="<p>Bill No.: ".$dataa[0]->cbr_bill_no."</p>";
					$html.="<p>Narration: ".$dataa[0]->cbr_narration."</p>";
					$html.="<p>Place of Supply: ".$place_supply[0]->mps_name."</p>";
					$html.="<p>Jurisdiction: ".$jurisdaction[0]->mps_name."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Total Amount : ".number_format((float)$dataa[0]->cbr_tot_amount+$dataa[0]->cbr_tot_vat_amount, 2, '.', '')."</p>";
				
				$html.="<p>Current Status: ".$dataa[0]->cbr_current_status."</p>";
					$html.="<p>Attachements: <a href='".base_url('uploads/payments_files/'.$dataa[0]->cbr_attachments)."' target='_blank'> ".$dataa[0]->cbr_attachments."</a></p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

					$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th><th>Salesman</th><th>Account</th><th>Amounts</th><th>Reference</th><th>Remark</th><th>Tax Code</th><th>Vat%</th><th>Amount Total</th></thead>";
					$html.="<tbody>";
					foreach($data_cl as $key=>$d)
					{
						if($dataa[0]->cbr_vat_type=='1')
						{
						$new_tot_value=$cust_amount_list[$key]/1.05;
						$vat_amount_tot[]=$new_tot_value*0.05;
						$amount_tot[]=$cust_amount_list[$key]/1.05;
						$new_vat_value=$new_tot_value*0.05;
						$final_tot_amount[]=$cust_amount_list[$key];
						}
						else
						{
							$new_tot_value=$cust_amount_list[$key];
							$vat_amount_tot[]=0;
							$amount_tot[]=$cust_amount_list[$key];
							$new_vat_value=0;
							$final_tot_amount[]=$cust_amount_list[$key];
						}
						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$data_sl[$key][0]->ed_name."</td>";
						$html.="<td>".$d[0]->label."</td>";
						$html.="<td>".number_format((float)$new_tot_value, 2, '.', '')."</td>";
						$html.="<td>".$ref_list[$key]."</td>";
						$html.="<td>".$rmk_list[$key]."</td>";
						$html.="<td>".$tax_list[$key]."</td>";
						$html.="<td>".number_format((float)$new_vat_value, 2, '.', '')."</td>";
						$html.="<td>".number_format((float)$cust_amount_list[$key], 2, '.', '')."</td>";
						$html.="</tr>";
					}
					$vat_sum=array_sum($vat_amount_tot);
					$html.="</tbody>";
					$html.="<tfoot>";
					$html.="<tr>";
					
					$html.="<td colspan='3'>Totals:</td>";
					
					$html.="<td>".number_format((float)array_sum($amount_tot), 2, '.', '')."</td>";
					$html.="<td></td>";
					$html.="<td></td>";
					$html.="<td></td>";
					$html.="<td>".number_format((float)array_sum($vat_amount_tot), 2, '.', '')."</td>";
					$html.="<td>".number_format((float)array_sum($final_tot_amount), 2, '.', '')."</td>";
					
					$html.="</tr>";
					$html.="</tfoot>";
					$html.="</table>";
					$html.="<p>Vat Amount Total:".number_format((float)$vat_sum, 2, '.', '')."</p>";
					/*** start of table  ***/
					echo $html;
			}		
	}	
	elseif($result[0]->atx_type_tx=="Sales_Invoice" || $result[0]->atx_tranfer_type=="sales_invoice")
	{
		//echo "insdie rhe sales invoice";
		if($details_region=='uae')
		$dataa=$this->Admin_model->get_data('sales_invoice',array('si_id'=>$result[0]->atx_main_id));
	elseif($details_region=='ksa')
		$dataa=$this->Admin_model->get_data('sales_invoice_ksa',array('si_id'=>$result[0]->atx_main_id));
	elseif($details_region=='dragon')
		$dataa=$this->Admin_model->get_data('sales_invoice_dragon',array('si_id'=>$result[0]->atx_main_id));
	else
		$dataa=$this->Admin_model->get_data('sales_invoice_export',array('si_id'=>$result[0]->atx_main_id));
// echo '<br/>';
// echo $details_region;
// 	print_r($dataa);
		if($dataa)
			{
				$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->si_company));
				$sales_acc=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->si_sales_acc_id));
				$cust_acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->si_customer_acc_id));
				$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->si_currency));
				$price_level=$this->Admin_model->get_data('master_price_level',array('mpc_id'=>$dataa[0]->si_pc_level));
				$salesman=$this->Admin_model->get_data('employee_details',array('ed_id'=>$dataa[0]->si_salesman));
				$payment_type=$this->Admin_model->get_data('master_payment_method',array('mpm_id'=>$dataa[0]->si_payment_type));
				$country=$this->Admin_model->get_data('master_region',array('mr_id'=>$dataa[0]->si_country));
				$place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->si_plc_supply));
				$jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->si_jurisdiction));

				$warehouse_list=explode('|#|',$dataa[0]->si_warehouse);
				foreach($warehouse_list as $wl)
				{
					$data_wl[]=$this->Admin_model->get_data('master_warehouse',array('mw_id'=>$wl));
				}
				
				$prd_list=explode('|#|',$dataa[0]->si_product);
				foreach($prd_list as $pl)
				{
					$data_pl[]=$this->tm->get_data('products',array('pid'=>$pl));
				}

				$qnty_list=explode('|#|',$dataa[0]->si_qnty);
				$rate_list=explode('|#|',$dataa[0]->si_rate);
				$gross_list=explode('|#|',$dataa[0]->si_gross);
				$disc_per_list=explode('|#|',$dataa[0]->si_dis_per);
				$disc_amount_list=explode('|#|',$dataa[0]->si_dis_amount);
				$add_charges_list=explode('|#|',$dataa[0]->si_add_charges);
				$fnet_list=explode('|#|',$dataa[0]->si_fnet);
				$vat_list=explode('|#|',$dataa[0]->si_vat);
					$rmk_list=explode('|#|',$dataa[0]->si_remrk);
					$tax_list=explode('|#|',$dataa[0]->si_tax_code);
					$delivery_date_list=explode('|#|',$dataa[0]->si_delivery_date);

					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Sales Invoice Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->si_doc_no."</p>";
					$html.="<p>User Created: ".$dataa[0]->si_user_created."</p>";
					$html.="<p>Date: ".$dataa[0]->si_date."</p>";
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					$html.="<p>Vat Type: ";
					if($dataa[0]->si_vat_type=='1')
					{
						$vat_tyype='Taxable';
					}
					else
					{
						$vat_tyype='Non-Taxable';
					}
					$html.=$vat_tyype;
					$html.="</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
				
					$html.="<p>Sales Account: ".$sales_acc[0]->label."</p>";
					$html.="<p>LPO No.: ".$dataa[0]->si_lpo_no."</p>";
					$html.="<p>Company: ".$company_details[0]->mcomp_name."</p>";
					$html.="<p>Price Level: ";
					if(!empty($price_level[0]->mpc_name))
						$html.=$price_level[0]->mpc_name;
					$html.="</p>";
					$html.="<p>Salesman: ".$salesman[0]->ed_name."</p>";
				$html.="<p>Payment Type: ".$payment_type[0]->mpm_name."</p>";
				
					$html.="<p>Place of Supply: ".$place_supply[0]->mps_name."</p>";
					$html.="<p>Jurisdiction: ".$jurisdaction[0]->mps_name."</p>";
					$html.="<p>Narration: ".$dataa[0]->si_narration."</p>";
					
				$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Customer : ".$cust_acc_details[0]->label."</p>";
					$html.="<p>Contact : ".$dataa[0]->si_contact."</p>";
					$html.="<p>Delivery Address: ".$dataa[0]->si_delivery_address."</p>";
					$html.="<p>Mark: ".$dataa[0]->si_mark."</p>";
				$html.="<p>Ship Contact : ".$dataa[0]->si_shipping_contact."</p>";
					$html.="<p>Country : ".$country[0]->mr_name."</p>";
						
				$html.="<p>Current Status: ".$dataa[0]->si_current_sts."</p>";
					$html.="<p>Attachements: <a href='".base_url('uploads/sales_invoice/'.$dataa[0]->si_attachments)."' target='_blank'> ".$dataa[0]->si_attachments."</a></p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

						$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th>
					<th>Warehouse</th><th>Product</th>
					<th>Quantity</th><th>Rate</th>
					<th>Gross</th><th>Discount(%)</th>
					<th>Discount Amount</th><th>Add.Charges</th>
					<th>Fnet</th><th>Vat(%)</th>
					<th>Delivery Date</th>
					<th>Remark</th><th>Tax Code</th></thead>";
					$html.="<tbody>";
					foreach($data_pl as $key=>$d)
					{
						$qnty_tot[]=$qnty_list[$key];
						$rate_tot[]=$rate_list[$key];
						$gross_tot[]=$gross_list[$key];
						
						$dis_amnt_tot[]=$disc_amount_list[$key];
						$adchrg_tot[]=$add_charges_list[$key];
						$fent_tot[]=$fnet_list[$key];
					
						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$data_wl[$key][0]->mw_name."</td>";
						$html.="<td>".$d[0]->pname."</td>";
						
						$html.="<td>".$qnty_list[$key]."</td>";
						$html.="<td>".$rate_list[$key]."</td>";
						$html.="<td>".$gross_list[$key]."</td>";

						$html.="<td>".$gross_list[$key]*($disc_per_list[$key]/100);
						$dis_per_tot[]=$gross_list[$key]*($disc_per_list[$key]/100);
						$html.="</td>";
						$disc_per_list[$key]."</td>";
						$html.="<td>".$disc_amount_list[$key]."</td>";
						$html.="<td>".$add_charges_list[$key]."</td>";

						$html.="<td>".$fnet_list[$key]."</td>";
						$html.="<td>".$fnet_list[$key]*($vat_list[$key]/100);
						$vat_amount_tot[]=$fnet_list[$key]*($vat_list[$key]/100);
						$html.="</td>";

						$html.="<td>".$delivery_date_list[$key]."</td>";
						$html.="<td>".$rmk_list[$key]."</td>";
						$html.="<td>".$tax_list[$key]."</td>";
					
						$html.="</tr>";
					}
					$html.="</tbody>";
					$html.="</table>";
						$html.="<p>Total Quantity : ".array_sum($qnty_tot)."</p>";
					$html.="<p>Total Rate  : ".array_sum($rate_tot)."</p>";
					$html.="<p>Total Gross : ".array_sum($gross_tot)."</p>";
					$html.="<p>Total Discount(%) : ".array_sum($dis_per_tot)."</p>";
					$html.="<p>Total Discount Amount : ".array_sum($dis_amnt_tot)."</p>";
					$html.="<p>Total Additional Charges : ".array_sum($adchrg_tot)."</p>";
					$html.="<p>Total Fnet : ".array_sum($fent_tot)."</p>";
					$html.="<p>Total VAT Amount : ".array_sum($vat_amount_tot)."</p>";
					$html.="<p>Final Amount : ".$dataa[0]->si_tot_amount."</p>";
					/*** start of table  ***/
					echo $html;
			}
	}
	elseif($result[0]->atx_type_tx=="Sales_Return" || $result[0]->atx_tranfer_type=="sales_return")
	{
		$dataa=$this->Admin_model->get_data('sales_return',array('srt_id'=>$result[0]->atx_main_id));	
		if($dataa)
			{
				$company_details=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$dataa[0]->srt_company));
				$sales_acc=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->srt_sales_acc_id));
				$cust_acc_details=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$dataa[0]->srt_customer_acc_id));
				$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->srt_currency));
				$price_level=$this->Admin_model->get_data('master_price_level',array('mpc_id'=>$dataa[0]->srt_pc_level));
				$salesman=$this->Admin_model->get_data('employee_details',array('ed_id'=>$dataa[0]->srt_salesman));
				$payment_type=$this->Admin_model->get_data('master_payment_method',array('mpm_id'=>$dataa[0]->srt_payment_type));
				$country=$this->Admin_model->get_data('master_region',array('mr_id'=>$dataa[0]->srt_country));
				$place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->srt_plc_supply));
				$jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->srt_jurisdiction));
				$warehouse= $this->Admin_model->get_data('master_warehouse',array('mw_id'=>$dataa[0]->srt_warehouse));

				$account_tx_data=$this->Admin_model->get_data('account_all_tx',array('atx_main_id'=>$dataa[0]->srt_id,'atx_type_tx'=>'Sales_Return'));
				if(!empty($account_tx_data))
				{
					$account_bal_data_1=$this->Admin_model->get_data('account_tx_bal_data',array('actb_to_id'=>$account_tx_data[0]->atx_id));
					if(!empty($account_bal_data_1))
					{
						foreach($account_bal_data_1 as $abd)
						{
							$tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_tx_id));
						}
					}
					else
					{
						$account_bal_data_2=$this->Admin_model->get_data('account_tx_bal_data',array('actb_tx_id'=>$account_tx_data[0]->atx_id));
						if(!empty($account_bal_data_2))
						{
							foreach($account_bal_data_2 as $abd)
							{
								$tx_data_related[]=$this->Admin_model->get_data('account_all_tx',array('atx_id'=>$abd->actb_to_id));
							}	
						}
					}
				}
			
				$prd_list=explode('|#|',$dataa[0]->srt_product);
				foreach($prd_list as $pl)
				{
					$data_pl[]=$this->tm->get_data('products',array('pid'=>$pl));
				}

				$qnty_list=explode('|#|',$dataa[0]->srt_qnty);
				$rate_list=explode('|#|',$dataa[0]->srt_rate);

				$desc_list=explode('|#|',$dataa[0]->srt_desc);
				$label_list=explode('|#|',$dataa[0]->srt_label);
				$unit_list=explode('|#|',$dataa[0]->srt_units);

				$gross_list=explode('|#|',$dataa[0]->srt_gross);
				$disc_per_list=explode('|#|',$dataa[0]->srt_dis_per);
				$disc_amount_list=explode('|#|',$dataa[0]->srt_dis_amount);
				$add_charges_list=explode('|#|',$dataa[0]->srt_add_charges);
				$fnet_list=explode('|#|',$dataa[0]->srt_fnet);
				$vat_list=explode('|#|',$dataa[0]->srt_vat);
					$rmk_list=explode('|#|',$dataa[0]->srt_remrk);
					$tax_list=explode('|#|',$dataa[0]->srt_tax_code);
					$delivery_date_list=explode('|#|',$dataa[0]->srt_delivery_date);

					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Sales Return Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->srt_doc_no."</p>";
					$html.="<p>User Created: ".$dataa[0]->srt_user_created."</p>";
					$html.="<p>Date: ".$dataa[0]->srt_date."</p>";
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					
					$html.="</p>";

					$html.="<p style='color:blue'><b>Linked to :</b></p>";
					if(!empty($tx_data_related))
					{
						foreach($tx_data_related as $tx)
						{
							$html.="<p style='color:blue'>".$tx[0]->atx_doc_no."</p>";
						}
					}	

					if(!empty($label_list))
					{
						foreach($label_list as $ll)
						{
							$html.="<p style='color:blue'>".$ll."</p>";
						}
					}
					$html.="</div>";

					$html.="<div class='col-md-4'>";
				
					$html.="<p>Sales Account: ".$sales_acc[0]->label."</p>";
					$html.="<p>LPO No.: ".$dataa[0]->srt_lpo_no."</p>";
					$html.="<p>Company: ".$company_details[0]->mcomp_name."</p>";
					$html.="<p>Price Level: ";
					if(!empty($price_level[0]->mpc_name))
						$html.=$price_level[0]->mpc_name;
					$html.="</p>";
					$html.="<p>Salesman: ".$salesman[0]->ed_name."</p>";
				$html.="<p>Payment Type: ".$payment_type[0]->mpm_name."</p>";
				
					$html.="<p>Place of Supply: ".$place_supply[0]->mps_name."</p>";
					$html.="<p>Jurisdiction: ".$jurisdaction[0]->mps_name."</p>";
					$html.="<p>Narration: ".$dataa[0]->srt_narration."</p>";
					$html.="<p>Warehouse Location: ".$warehouse[0]->mw_name."</p>";
					
				$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Customer : ".$cust_acc_details[0]->label."</p>";
					$html.="<p>Contact : ".$dataa[0]->srt_contact."</p>";
					$html.="<p>Delivery Address: ".$dataa[0]->srt_delivery_address."</p>";
					$html.="<p>Mark: ".$dataa[0]->srt_mark."</p>";
				$html.="<p>Ship Contact : ".$dataa[0]->srt_shipping_contact."</p>";
					$html.="<p>Country : ".$country[0]->mr_name."</p>";
						
				$html.="<p>Current Status: ".$dataa[0]->srt_current_sts."</p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

						$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th>
					<th>Product</th><th>Description</th>
					<th>Units</th><th>Label</th>
					<th>Quantity</th><th>Rate</th>
					<th>Gross</th><th>Discount(%)</th>
					<th>Discount Amount</th><th>Add.Charges</th>
					<th>Fnet</th><th>Vat(%)</th>
					<th>Delivery Date</th>
					<th>Remark</th><th>Tax Code</th></thead>";
					$html.="<tbody>";
					foreach($data_pl as $key=>$d)
					{
						$qnty_tot[]=$qnty_list[$key];
						$rate_tot[]=$rate_list[$key];
						$gross_tot[]=$gross_list[$key];
						
						$dis_amnt_tot[]=$disc_amount_list[$key];
						$adchrg_tot[]=$add_charges_list[$key];
						$fent_tot[]=$fnet_list[$key];
					
						$html.="<tr>";
						$html.="<td></td>";
						
						$html.="<td>".$d[0]->pname."</td>";

						

						$html.="<td>".$desc_list[$key]."</td>";
						$html.="<td>".$unit_list[$key]."</td>";
						$html.="<td>".$label_list[$key]."</td>";

						$html.="<td>".$qnty_list[$key]."</td>";
						$html.="<td>".$rate_list[$key]."</td>";
						$html.="<td>".$gross_list[$key]."</td>";

						$html.="<td>".$gross_list[$key]*($disc_per_list[$key]/100);
						$dis_per_tot[]=$gross_list[$key]*($disc_per_list[$key]/100);
						$html.="</td>";
						$disc_per_list[$key]."</td>";
						$html.="<td>".$disc_amount_list[$key]."</td>";
						$html.="<td>".$add_charges_list[$key]."</td>";

						$html.="<td>".$fnet_list[$key]."</td>";
						$html.="<td>".$fnet_list[$key]*($vat_list[$key]/100);
						$vat_amount_tot[]=$fnet_list[$key]*($vat_list[$key]/100);
						$html.="</td>";

						$html.="<td>".$delivery_date_list[$key]."</td>";
						$html.="<td>".$rmk_list[$key]."</td>";
						$html.="<td>".$tax_list[$key]."</td>";
					
						$html.="</tr>";
					}
					$html.="</tbody>";
					$html.="</table>";
						$html.="<div class='row'>";
					$html.="<div class='col-md-12'><div class='col-md-4'>";
						$html.="<p>Total Quantity : ".array_sum($qnty_tot)."</p>";
					$html.="<p>Total Rate  : ".array_sum($rate_tot)."</p>";
					$html.="<p>Total Gross : ".array_sum($gross_tot)."</p>";
					$html.="</div>";
					$html.="<div class='col-md-4'>";
					$html.="<p>Total Discount(%) : ".array_sum($dis_per_tot)."</p>";
					$html.="<p>Total Discount Amount : ".array_sum($dis_amnt_tot)."</p>";
					$html.="<p>Total Additional Charges : ".array_sum($adchrg_tot)."</p>";
						$html.="</div>";
					$html.="<div class='col-md-4'>";
					$html.="<p>Total Fnet : ".array_sum($fent_tot)."</p>";
					$html.="<p>Total VAT Amount : ".array_sum($vat_amount_tot)."</p>";
					$html.="<p>Final Amount : ".$dataa[0]->srt_tot_amount."</p>";
					$html.="</div>";$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/
					echo $html;
			}
	}
	elseif(preg_match('/JRN_/', $result[0]->atx_type_tx) || $result[0]->atx_tranfer_type=="journal")
	{
		$dataa=$this->Admin_model->get_data('cash_bank_journals',array('cbr_id'=>$result[0]->atx_main_id));
		if($dataa)
			{
				$currency=$this->Admin_model->get_data('master_currency_conv',array('c_id'=>$dataa[0]->cbr_currency));
				$place_supply=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->cbr_place_supply_id));
				$jurisdaction=$this->Admin_model->get_data('master_place_supply',array('mw_id'=>$dataa[0]->cbr_jurisdication));

				$comp_list=explode('|#|',$dataa[0]->cbr_company);
				foreach($comp_list as $cl)
				{
				$data_cmp[]=$this->Admin_model->get_data('master_company',array('mcomp_id'=>$cl));
				}

				$customer_list=explode('|#|',$dataa[0]->cbr_customer_acc);
				foreach($customer_list as $cs)
				{
					$data_cl[]=$this->Admin_model->get_data('master_accounts_tree',array('id'=>$cs));
				}
				
				$salesman_list=explode('|#|',$dataa[0]->cbr_salesman);
				foreach($salesman_list as $sl)
				{
					$data_sl[]=$this->Admin_model->get_data('employee_details',array('ed_id'=>$sl));
				}

					$ref_list=explode('|#|',$dataa[0]->cbr_ref);
					$rmk_list=explode('|#|',$dataa[0]->cbr_remark);
					$tax_list=explode('|#|',$dataa[0]->cbr_tax_code);
					$credit_list=explode('|#|',$dataa[0]->cbr_credit);
					$debit_list=explode('|#|',$dataa[0]->cbr_debit);
					$bill_no=explode('|#|',$dataa[0]->cbr_bill_no);
					$vat_per_list=explode('|#|',$dataa[0]->cbr_vat);

					$html="<div class='row'>";
					$html.="<div class='col-md-12'><h4>Journal Data</h4>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Doc no: ".$dataa[0]->cbr_doc_no."</p>";
					$html.="<p>User Created: ".$dataa[0]->cbr_created_by."</p>";
					$html.="<p>Date: ".$dataa[0]->cbr_date."</p>";
					$html.="<p>Currency: ".$currency[0]->currency_name."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
					$html.="<p>Narration: ".$dataa[0]->cbr_narration."</p>";
					$html.="<p>Place of Supply: ".$place_supply[0]->mps_name."</p>";
					$html.="<p>Jurisdiction: ".$jurisdaction[0]->mps_name."</p>";
					$html.="<p>Linked to Invoice.: ".str_replace('|#|', '<br/>', $dataa[0]->cbr_sales_inv_linked)."</p>";
					$html.="</div>";

					$html.="<div class='col-md-4'>";
				
				$html.="<p>Current Status: ".$dataa[0]->cbr_current_status."</p>";
					$html.="<p>Attachements: <a href='".base_url('uploads/journal_files/'.$dataa[0]->cbr_attachments)."' target='_blank'> ".$dataa[0]->cbr_attachments."</a></p>";
					$html.="</div>";

					/*** end of col-md-12 and row ***/
					$html.="</div>";
					$html.="</div>";
					/*** start of table  ***/

						$html.="<table  class='table table-responsive table-bordered table-striped' id='datatable-default2'>";
					$html.="<thead><th></th><th>Company</th><th>Salesman</th><th>Account</th><th>Debit</th><th>Credit</th><th>Reference</th><th>Remark</th><th>Bill No.</th><th>Tax Code</th><th>Vat%</th></thead>";
					$html.="<tbody>";
					foreach($data_cl as $key=>$d)
					{
						$html.="<tr>";
						$html.="<td></td>";
						$html.="<td>".$data_cmp[$key][0]->mcomp_name."</td>";
						$html.="<td>".$data_sl[$key][0]->ed_name."</td>";
						$html.="<td>".$d[0]->label."</td>";
						$html.="<td>";
						if(!empty($debit_list[$key]))
						{
							$html.=$debit_list[$key];
							$debit_tot[]=$debit_list[$key];
						}
						else
						{
							$html.='0';
						}
						$html.="</td>";
						$html.="<td>";
						if(!empty($credit_list[$key]))
						{
							$html.=$credit_list[$key];
						$credit_tot[]=$credit_list[$key];
						}
						else
						{
							$html.='0';
						}
						$html.="</td>";
						$html.="<td>".$ref_list[$key]."</td>";
						$html.="<td>";
						if(!empty($rmk_list[$key]))
						$html.=$rmk_list[$key];
						$html.="</td>";
						$html.="<td>";
						if(!empty($bill_no[$key]))
						$html.=$bill_no[$key];
						$html.="</td>";
						$html.="<td>";
						if(!empty($tax_list[$key]))
							$html.=$tax_list[$key];
						$html.="</td>";
							$html.="<td>";
						if(!empty($vat_per_list[$key]))
						$html.=$vat_per_list[$key];
						$html.="</td>";
						$html.="</tr>";
					}
					$html.="</tbody>";
					$html.="</table>";
				$html.="<p>Debit Amount Total:".array_sum($debit_tot)."</p>";
				$html.="<p>Credit Amount Total:".array_sum($credit_tot)."</p>";
					/*** start of table  ***/
					echo $html;
			}
	}
	else
	{}
}





}