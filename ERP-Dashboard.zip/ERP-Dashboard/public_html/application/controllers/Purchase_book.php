<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase_book extends CI_Controller {

public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','prd'));
		$this->load->model(array('Purchase_book_model'));
	}


function pb_dashboard($year_selected=null)
{

	if(logged_in())
	{

$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='purchase-book-dashboard')||($this ->session->userdata['user']['main_dept'])=="Main" || ($this ->session->userdata['user']['main_dept'])=="Purchase" ))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {

		
$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
$current_month= $dt->format('m');
$current_year= $dt->format('Y');
$previous_year=$dt->format('Y')-1;
$last_previous_year=$dt->format('Y')-2;

$months=array('01','02','03','04','05','06','07','08','09','10','11','12');
foreach($months as $m)
{
	$datt['curnt_yr'][]=$this->Purchase_book_model->bar_chart_year($current_year,$m);

	$datt['prev_yr'][]=$this->Purchase_book_model->bar_chart_year($previous_year,$m);	
	$datt['last_prev_yr'][]=$this->Purchase_book_model->bar_chart_year($last_previous_year,$m);
}

foreach($datt['curnt_yr'] as $dc)
{
	$data['months_curnt'][]=$dc[0]->total_amount;
}

foreach($datt['prev_yr'] as $dp)
{
	$data['months_prev'][]=$dp[0]->total_amount;
}

foreach($datt['last_prev_yr'] as $dp)
{
 	$data['months_last_prev'][]=$dp[0]->total_amount;
}

$datt['cat_curnt_yr'][]=$this->Purchase_book_model->all_category($current_year);

if(empty($datt['cat_curnt_yr'][0]))
{
$datt2['cat_curnt_yr'][]=$this->Purchase_book_model->all_category($previous_year);
}

if(!empty($datt['cat_curnt_yr'][0]))
{
$all_cat_names=array();$all_cat_sum1=array();
foreach($datt['cat_curnt_yr'][0] as $cat_c)
{
	if(!empty($all_cat_names))
	{
	if(!in_array($cat_c->pb_class, $all_cat_names))
	$all_cat_names[]=$cat_c->pb_class;
	}
	else
	{
	$all_cat_names[]=$cat_c->pb_class;
	}
$all_cat_sum1[$cat_c->pb_class][]=$cat_c->total_amount;
}
foreach($all_cat_names as $c)
{
$datt['cat_prev_yr'][]=$this->Purchase_book_model->all_category($previous_year,array('pb_class'=>$c));
$datt['cat_last_prev_yr'][]=$this->Purchase_book_model->all_category($last_previous_year,array('pb_class'=>$c));
}
foreach($datt['cat_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum2[]=$c2;
	}
	
	foreach($datt['cat_last_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum3[]=$c2;
	}
	
	$data['cat_amount_curnt']=$all_cat_sum1;
	$data['cat_amount_prev']=$all_cat_sum2;
	$data['cat_amount_last_prev']=$all_cat_sum3;

}
else
{
$all_cat_names=array();$all_cat_sum1=array();
	foreach($datt2['cat_curnt_yr'][0] as $cat_c)
	{
		if(!empty($all_cat_names))
		{
		if(!in_array($cat_c->pb_class, $all_cat_names))
		$all_cat_names[]=$cat_c->pb_class;
		}
		else
		{
		$all_cat_names[]=$cat_c->pb_class;
		}
	$all_cat_sum1[$cat_c->pb_class][]=$cat_c->total_amount;
	}
	
	foreach($all_cat_names as $c)
	{
	
	$datt['cat_prev_yr'][]=$this->Purchase_book_model->all_category($previous_year,array('pb_class'=>$c),'');
	
	$datt['cat_last_prev_yr'][]=$this->Purchase_book_model->all_category($last_previous_year,array('pb_class'=>$c),'');
	}
	
	foreach($datt['cat_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum2[]=$c2;
	}

	foreach($datt['cat_last_prev_yr'] as $indx=>$c2)
	{
	$all_cat_sum3[]=$c2;
	}

	$data['cat_amount_curnt']=array();
	$data['cat_amount_prev']=$all_cat_sum2;
	$data['cat_amount_last_prev']=$all_cat_sum3;
}

$data['all_category_comparison']=$all_cat_names;

///////curent year-class-prd_code(year based comparison)/////////

if(!empty($year_selected))
{
	$data['all_category']=$this->Purchase_book_model->all_category($year_selected);

foreach($all_cat_names as $c)
	{
	$data['all_category_sales_purchase'][]=$this->Purchase_book_model->all_category($year_selected,array('pb_class'=>$c));
	}


	foreach($all_cat_names as $c)
	{
		$prd_code[]=$this->Purchase_book_model->all_prd($year_selected,'','',$c);

		if($c=="Plastic raw materia")
		{
			$raw_mat_data[$c][]=$this->Purchase_book_model->all_category_purchase($year_selected,'','','',array('MERMAID HOSE','STEEL WIRE HOSE','BERRY HOSES','LEVEL HOSES','GAS & AIR HOSES','FLAT HOSES','MASTER HOSE','Casper HOSES','Suction Hose','WATER STOP','BUCKETS','YEMEN EXPORT'));
		}
		elseif($c=="Signs Raw Materials")
		{
			$raw_mat_data[$c][]=$this->Purchase_book_model->all_category_purchase($year_selected,'','','',array('ALUMINIUM SIGN','TEMPORARY ROAD SIGN','PERMANENT ROAD SIGN'));
		}
		elseif($c=="Reflective Tape")
		{
			$raw_mat_data[$c][]=$this->Purchase_book_model->all_category_purchase($year_selected,'','','',array('REFLECTIVE SHEET'));
		}
		else
		{
			$raw_mat_data[$c][]=$this->Purchase_book_model->all_category_purchase($year_selected,array('sbp_ar_category'=>$c),'','','');
		}
	}

	$total_sum_sales_cat=0;
	foreach($raw_mat_data as $indx1=>$rm)
	{
		foreach($rm as $indx2=>$rm2)
		{
			foreach($rm2 as $indx3=>$rm3)
			{
				 $data['total_sales_cat'][$indx1][]=$rm3->total_gross_amount;
			}		
		
		}
	}

		$groups1 = [];
	foreach ($prd_code as $key2 => $pd) 
	{
		foreach($pd as $pd3)
		{
	$groups1[$pd3->pb_class][str_replace('"', '',$pd3->pb_prd_name)]['sum'][]=$pd3->pb_net_amount;   
		 }
	}

	 $sum_array=[];
	foreach ($groups1 as $key4 => $value) {
		foreach($value as $key5=>$v1)
		{
			if(!empty($v1))
			{
		 $data['prd_class_code'][$key4][]=array(
	 'sum'=>array_sum(str_replace(',', '', $v1['sum'])),
			'prd_code'=>$key5,
			);
			}
			else
			{
	$data['prd_class_code'][$key4][]=array();
			}
		}
		
	}	
	$data['year_selected']=$year_selected;


}
 

////end of curent year///
 //echo "<pre>";print_r($data['prd_class_code']);echo "</pre>";

///////data for grouping/comparison//


///end of data for comparison////

$data['current_year']=$current_year;
$data['previous_year']=$previous_year;
$data['last_previous_year']=$last_previous_year;

$strt_range=$this->input->post('start_date_rng');
$end_range=$this->input->post('end_date_rng');
$select_month=$this->input->post('month_selected');


if(!empty($strt_range) && !empty($end_range))
{
$cond_both_dates=array(
	'pb_voc_date >='=>date("Y-m-d", strtotime($strt_range)),
	'pb_voc_date <='=>date("Y-m-d", strtotime($end_range)),
	);
	
	$current_year='';
}
else if(!empty($end_range))
{
$cond_both_dates=array(
	'pb_voc_date <='=>date("Y-m-d", strtotime($end_range)),
	);
	$current_year='';
}
else if(!empty($strt_range))
{
$cond_both_dates=array(
	'pb_voc_date >='=>date("Y-m-d", strtotime($strt_range)),
	);
	$current_year='';
}
else{
	$cond_both_dates='';
}

if(!empty($select_month))
{
	$cond_month=array(
	'pb_month'=>$select_month,
	);	
}	
else
{
$cond_month='';
}

$data['start_date']=$strt_range;
$data['end_date']=$end_range;
$data['selected_month']=$select_month;

$this->load->view('admin/sales_book/pb_dashboard',$data);

}
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	
}
	}

}

function get_year_data()
{
	$selected_year=$this->input->post('selected_year');

	$data['all_category']=$this->Purchase_book_model->all_category($selected_year);

	foreach($data['all_category'] as $indx1=>$a_cat)
	{	

	$prd[]=$this->Sales_book_model->all_prd($a_cat->sbp_ar_category,'','',$current_year,$cond_both_dates,$cond_month,$city_list);
	}

	$groups = [];
	foreach ($prd as $key2 => $pd) 
	{
		foreach($pd as $pd3)
		{
	$groups[$pd3->sbp_ar_category][$pd3->sbp_prd_code]['sum'][]=$pd3->sbp_gross;   
	$groups[$pd3->sbp_ar_category][$pd3->sbp_prd_code]['qnty'][]=$pd3->sbp_qty;   
		 }
	}

	 $sum_array=[];
	foreach ($groups as $key4 => $value) {
		foreach($value as $key5=>$v1)
		{
		 $data['cat_prd'][$key4][]=array(
	 'sum'=>array_sum(str_replace(',', '', $v1['sum'])),
			'prd_qnty'=>array_sum(str_replace(',', '', $v1['qnty'])) ,
			'prd_code'=>$key5,
			);
	//echo "<pre>";
	 //print_r($v1['sum']);
	 //echo "</pre>";
		}
	}	

}



function purchase_book_excel_upload()
{
	if(logged_in())
	{
    
    $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
	 	   $cred_count=count($page_cred);


        for($i=0;$i<$cred_count;$i++)
         {
         	//this condition enable manager to access to all pages and the one has the premission
      if ((($page_cred[$i]=='purchase-book-excel')||($this ->session->userdata['user']['main_dept'])=="Main"))
         {  
             $excist=true;

            $i=$cred_count;
         }
          else
          {$excist=false;} 	

         }
        if ($excist) {


	$this ->load-> view('admin/sales_book/purchase_book');

}
		   else {
		  $this->session->unset_userdata('user', null);
	      	redirect('login','refersh');
	
}


	}
}


function submit_purchase_book_excel()
{
	$flag = 0;
		$error_string=""; 
		
		$this ->load -> library('excel');
		$this ->load -> library('image_lib');
		$path = 'uploads/excel/sales_vouchers/';

		$config['upload_path'] = './' . $path;
		$config['allowed_types'] = 'xlsx|xls';
		$config['remove_spaces'] = TRUE;
		$config['overwrite'] = TRUE;
		$this ->load-> library('upload', $config);
		$this ->upload-> initialize($config);

		if (!$this->upload->do_upload('userfile')) 
		{
			$error = array('error' => $this->upload-> display_errors());
			$this->session ->set_flashdata('errors', $error['error']);
			redirect("purchase-book-excel", "refresh");
		} 
		else 
		{
		$data = array('userfile' => $this->upload->data());
		}
	
		if (!empty($data['userfile']['file_name'])) 
		{
		$import_xls_file = $data['userfile']['file_name'];
		} 
		else 
		{
			$import_xls_file = 0;
		}
		$inputFileName = $path.$import_xls_file;
		try 
		{
		$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		$objPHPExcel = $objReader -> load($inputFileName);
		} 
		catch (Exception $e) 
		{
		die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME).'": '.$e -> getMessage());
		}
		$allDataInSheet = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
		$arrayCount = count($allDataInSheet);
		
		for ($i = 2; $i <= $arrayCount; $i++) 
		{			
		$voc_number = trim($allDataInSheet[$i]['C']);
		$voc_date = trim($allDataInSheet[$i]['B']);
			$vendor_name = trim($allDataInSheet[$i]['D']);
		$prd_name_en=trim($allDataInSheet[$i]['E']);
			
			$qty=str_replace(',', '', trim($allDataInSheet[$i]['F']));

			$prd_code=trim($allDataInSheet[$i]['G']);
			$category=trim($allDataInSheet[$i]['H']);
			$rate=trim($allDataInSheet[$i]['I']);

			$gross=str_replace(',', '', trim($allDataInSheet[$i]['J']));
			$rec_rate=trim($allDataInSheet[$i]['K']);
			$net_amount=str_replace(',', '',trim($allDataInSheet[$i]['L']));

		$branch = trim($allDataInSheet[$i]['M']);
		}
		if($flag==1)
		{		
			$this->session->set_flashdata('errors',$error_string);	
			unlink("uploads/excel/sales_vouchers/".$import_xls_file);
			redirect('purchase-book-excel','refresh');
		}
		else
		{
		$dwnload_title=$this->input->post('dwnload_title');
			$data23=array(
			'excl_title'=>$dwnload_title,
			'excl_file'=>$inputFileName,
			'excl_status'=>"1",
			'excl_type' =>'result');
			$insert_id=$this->Admin_model->insert_data("excel_file_sales_book", $data23);
			 $this->insert_table($allDataInSheet,$insert_id);
		}
}


function insert_table($allDataInSheet,$insert_id) 
{
	$arrayCount = count($allDataInSheet);
	$flag = 0;
	$vocr_array=array();
	$data_empty_array=array();
	$insert_id_vochr='';
	for($i=2;$i<=$arrayCount;$i++) 
		{			
			$voc_number = trim($allDataInSheet[$i]['C']);
			$voc_date = trim($allDataInSheet[$i]['B']);

			$new_voc_date=explode('-', $voc_date);///in the format d-m-y , i need is y-m-d.
			if(!empty($new_voc_date[1]))
			$month_voc=$new_voc_date[1];
			else
				$month_voc='';

			if(!empty($new_voc_date[0]))
			$date_voc=$new_voc_date[0];	

			if(!empty($new_voc_date[2]))
			$year_voc=$new_voc_date[2];
		else
			$year_voc='';

			if(!empty($month_voc) && !empty($date_voc) && !empty($year_voc) )
			{
				$voc_date_2=$year_voc.'-'.$month_voc.'-'.$date_voc;
			}
			else
				$voc_date_2='0000-00-00';

		$vendor_name = trim($allDataInSheet[$i]['D']);
		$prd_name_en=trim($allDataInSheet[$i]['E']);		
			$qty=str_replace(',', '', trim($allDataInSheet[$i]['F']));
			$prd_code=trim($allDataInSheet[$i]['G']);
			$category=trim($allDataInSheet[$i]['H']);
			$rate=trim($allDataInSheet[$i]['I']);

			$gross=str_replace(',', '', trim($allDataInSheet[$i]['J']));
			$rec_rate=trim($allDataInSheet[$i]['K']);
			$net_amount=str_replace(',', '',trim($allDataInSheet[$i]['L']));
		$branch= trim($allDataInSheet[$i]['M']);

		if(!empty($voc_number))
		{
				$data_empty_array=array(
					'pb_voc_num'=>$voc_number,
					'pb_class'=>$category,
					'pb_prd_code'=>$prd_code,
					'pb_prd_name'=>$prd_name_en,
					'pb_qnty'=>$qty,
					'pb_rate'=>$rate,
					'pb_gross'=>$gross,
					'pb_rcpt_rate'=>$rec_rate,
					'pb_net_amount'=>$net_amount,
					'pb_branch'=>$branch,
					'pb_vendor'=>$vendor_name,
					'pb_sts'=>'1',
					'pb_voc_date'=>$voc_date_2,
					'pb_excel_id'=>$insert_id,
					'pb_year'=>$year_voc,
					'pb_month'=>$month_voc,
					);

			$insert_id_vochr=$this->Admin_model->insert_data("purchase_book", $data_empty_array);
		}	
			if(!($insert_id_vochr))
			$status = false;
			else
				$status = true;						
	}

	if ($status)
			$this ->session-> set_flashdata('success', 'Imported Successfully');
		else
			$this ->session-> set_flashdata('errors', 'Error found. Try again!');

		redirect("purchase-book-excel", "refresh");	
}















}