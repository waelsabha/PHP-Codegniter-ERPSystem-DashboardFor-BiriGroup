<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_order_sample extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','datatable','email_po'));	
		$this->load->model(array('Second_db_model','Sales_book_model'));
		$this->load->model('Third_db_model','tm');		
	}

 public function POList()
    {
    	// 	$this->load->model('Datatables_prd');
            $this->tm->table = 'prd_order';
            $this->tm->column_order = array('po_id', 'po_sales_person', 'po_date_delivry', 'po_delivery_loc', 'po_dept','po_id');
            $this->tm->column_search = array('po_id', 'po_sales_person', 'po_date_delivry', 'po_delivery_loc', 'po_dept','po_id','po_rmks');
            $this->tm->order = array('po_id' => 'desc');  

     if($this->session->userdata['user']['main_dept']=="Main" || $this->session->userdata['user']['user_desig']=="Team-lead" )
		{
			if($this->session->userdata['user']['user_desig']=="Team-lead")
			{
				if($this ->session->userdata['user']['sub_dept']=="ksa")
				$cond1=array('po_sts'=>"1",'po_user_country'=>'ksa');
				else
				$cond1=array('po_sts'=>"1",'po_user_country'=>'uae');
			}
			else
			$cond1=array('po_sts'=>"1");
		}		
		else
		{
	/////	$cond1=array('po_sts'=>"1",'po_user_id'=>$this->session->userdata['user']['username'],'po_order_status_fact !='=>"5",
	////		'po_order_status_adv !='=>"5");
	$cond1=array('po_sts'=>"1",'po_user_id'=>$this->session->userdata['user']['username']);
		}

	// $order_by=('po_id');
	// $order_type="DESC";
		$fetch_data =$this->tm->getRows($_POST,$cond1); 
		//$this->tm->get_po_details('prd_order',$cond1,'','',$order_by,$order_type);
		$data = array();
		foreach ($fetch_data as $index1=>$t) 
		{
			 $action = null;
             $html=null;

			$qnty=explode('|#|',$t->po_qnty);
			$wgt=explode('|#|',$t->po_wgt);
			$req=explode('|#|',$t->po_spcl_rq);  
			$rmks=explode('|#|',$t->po_rmks);
			$pckg_type=explode('|#|',$t->po_pck_type);

			$sub_array = array();
		    $sub_array[] = '#'.$t->po_id;
            $sub_array[] = $t->po_sales_person;
            $sub_array[] = $t->po_date_delivry;
            $sub_array[] = $t->po_delivery_loc;
            $sub_array[] = $t->po_dept; 
             $sub_array[] =$rmks[0];
          
            $action.='<div class="dropdown-primary dropdown">
				<button class="btn btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
				<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">
				<a class="dropdown-item waves-light" onclick="view_po_data('."'".$t->po_id."'".')" ><i class="fa fa-eye"></i>View</a>
				<div class="dropdown-divider"></div>
				<a class="dropdown-item waves-light waves-effect" href="'.base_url("edit_prd_ordr/".$t->po_id).'"><i class="fa fa-pencil"></i>Edit Details</a>
				<div class="dropdown-divider"></div>
				<a class="dropdown-item waves-light" onclick="delete_po('."'".$t->po_id."'".')" ><i class="fa fa-trash-o"></i>Delete </a>
				<div class="dropdown-divider"></div>
				<a class="dropdown-item waves-light waves-effect" href="'.base_url().'po_history/'.$t->po_id.'">Check history</a>
				<div class="dropdown-divider"></div>
				<a class="dropdown-item waves-light waves-effect" href="'.base_url().'generate_po_pdf/'.$t->po_id.'">Generate PDF</a>';
				if($t->po_approve_ksa=="1")
				{
				if( ($this ->session->userdata["user"]["sub_dept"]=="ksa") && ($this->session->userdata["user"]["user_desig"]=="Team-lead"))
				{
				$action.='<div class="dropdown-divider"></div>
				<a class="dropdown-item waves-light waves-effect" href="'.base_url().'approve_po_ksa/'.$t->po_id.'">Approve PO</a>';
				}
				}
				$action.='</div>
				</div>';

			 $sub_array[] = $action;
                $data[] = $sub_array;
		}
        	  $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->tm->countAll(),
            "recordsFiltered" => $this->tm->countFiltered($_POST),
            "data" => $data,
        );
        	  echo json_encode($output);
            //render_table_prd($data);
    }

    function ajax_load_view_po_details()
    {
    		$po_id=$this->input->post('po_id');
    	$t=$this->tm->get_po_details('prd_order',array('po_id'=>$po_id));
	$prd_id=explode('|#|',$t[0]->po_prd_name);	
	//print_r($prd_id);
		 $prd_data=$this->tm->prd_list_var($prd_id);
		// pre_list($prd_data);
		 //$data['prd_data'][]=$this->tm->prd_var_data($prd_id);///getting product details		  
$qnty=explode('|#|',$t[0]->po_qnty);
$wgt=explode('|#|',$t[0]->po_wgt);
$req=explode('|#|',$t[0]->po_spcl_rq);  
$rmks=explode('|#|',$t[0]->po_rmks);
$pckg_type=explode('|#|',$t[0]->po_pck_type);

    	$html='<div class="row">
    	<div class="col-md-12 col-sm-12">
    <div class="col-md-12" style="margin-bottom: 2%;">

      <div class="col-md-4">
      <b>Order Created on :</b> '.$t[0]->po_dt_crt.'</br>
        <b>Sales Person:</b><br/> '.$t[0]->po_sales_person.'<br/>
        <b>Delivery Date:</b><br/> '.$t[0]->po_date_delivry.'<br/>
        <b>Is expected delivery same as delivery date?</b>';
        if(empty($t[0]->po_dlvry_days))
          {$html.= "Yes";}
        else{$html.= "No";}
       $html.="<br/>";
       
        if(!empty($t[0]->po_dlvry_days))
        {
        $html.="<b> Extended Delivery Date</b>: ". $t[0]->po_dlvry_days."<br/>";  
        }
       
      $html.='</div>

      <div class="col-md-4">
          <b>Delivery Location:</b><br/> '.$t[0]->po_delivery_loc.'
      </div>
      <div class="col-md-4">
        <b>Department:</b><br/>';
       $html.=$t[0]->po_dept;
        if(!empty($t[0]->fact_delivery_note))
        {
         $html.='<b>Final Delivery Note from Factory :</b>  '.$t[0]->fact_delivery_note;
		}
         if(!empty($t[0]->traffic_sign_delivery_note))
        {
       	$html.='<b>Final Delivery Note from Traffic Sign:</b> '.$t[0]->traffic_sign_delivery_note;
		 }
       $html.='</div>    
    </div>
<div class="col-md-12 col-sm-12 col-xs-12" style="margin-bottom: 2%;">
       <div class="col-md-6 col-sm-12 col-xs-12" >
      <p><b>Special Customer request:</b> ';
        if(!empty($t[0]->po_specl_customer_req)){  $html.=$t[0]->po_specl_customer_req;}
        $html.='</p>
      </div>

       <div class="col-md-6 col-sm-12 col-xs-12" >
      <p><b>Download attachments: </b>';
       if(!empty($t[0]->po_files))
        {
        $files_attached=explode(',',$t[0]->po_files);
          foreach($files_attached as $fa)
          {
             $file_parts = pathinfo($fa);
            if(($file_parts['extension']=="jpeg")||($file_parts['extension']=="jpg")||($file_parts['extension']=="png")||($file_parts['extension']=="PNG"))
            {
            
              $html.= "<a href='".base_url('uploads/production/prod_files/'.$fa)."' target='_blank'><img src='".base_url('/uploads/production/prod_files/').$fa."' width='100' height='100' ></a>";
              $html.=' ';
            }
            else
            {
           $html.='<a href="'.base_url('uploads/production/prod_files/'.$fa).'" target="_blank">'.$fa.'</a><br/>';
           }
          }
       }
       $html.='</p>
      </div>
	</div>

    <div class="col-md-12" style="border: 1px solid black;">';
     
         foreach($prd_data as $index2=>$p)
          {
             if(empty($p['p_prd_img']))
            {
           $filename="https://birigroup.com/uploads/prd_images/".$p['pcode'].'.jpeg';
             if (file_exists($filename)) {
              $img_path=$filename;
              } else {
              $img_path="https://birigroup.com/uploads/prd_images/".$p['pcode'].'.jpg';
                }
            }
           else
           {
              
            $first_img_prd=explode(',',$p['p_prd_img']);
            if(!empty($first_img_prd[0]))
            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
            else
            $img_path="https://birigroup.com/uploads/prd_images/".$p['p_prd_img'];
           }
             $html.='<div class="col-md-6 col-sm-6">';
            $html.='<img src="'.$img_path.'" width="100" height="100">';
           $html.='</div>';
           $html.='<div class="col-md-6 col-sm-6">';
            $prd_name_db=explode('|~~|',$p['pname']);
            $html.=$prd_name_db[0].',';
            $html.="<br/>";
            $html.='<b>Code :</b>'.$p['pcode'];
            $html.="<br/>";
            if(!empty($qnty[$index2]))
            {
            $html.='<b>Quantity :</b>'.$qnty[$index2];
            $html.="<br/>";
        	}
            if(!empty($wgt[$index2]))
            {
            $html.='<b>Weight :</b>'.$wgt[$index2];
            $html.="<br/>";
        	}
        	 if(!empty($pckg_type[$index2]))
            {
            $html.='<b>Package Type :</b>'.$pckg_type[$index2];
            $html.="<br/>";
        	}
        	 if(!empty($req[$index2]))
            {
            $html.='<b>Special Request :</b>'.$req[$index2];
            $html.="<br/>";
        	}
        	 if(!empty($rmks[$index2]))
            {
            $html.='<b>Remarks :</b>'.$rmks[$index2];
 				$html.= "<br/>";
           	}
           	 $html.= "<br/><hr/>";
           	$html.='</div>';
          }        
     $html.='</div>    
  </div>
    	</div>';
    	echo $html;
    }


function Prod_list()
{
			$this->tm->table = 'products';
	  		$this->tm->join_table = array('brand', 'category', 'units', 'country_val', 'hse_code');
            $this->tm->join_where = array('brand.bid=products.pbrand', 'category.cid=products.pcat', 'units.uid=products.punit', 'country_val.country_id=products.p_country', 'hse_code.hse_id=products.p_hse_id');
            $this->tm->column_order = array('pid', 'p_prd_img', 'pname', 'pcode', 'p_purchase_price','p_uae_final','pcat','p_sts');
            $this->tm->column_search = array('pid', 'p_prd_img', 'pname', 'pcode','p_purchase_price' ,'p_uae_final','pcat','p_sts');
			 $this->tm->order = array('pid' => 'desc');  
	// $order_by=('po_id');
	// $order_type="DESC";
            $filter_val=$this->input->post('filter_val');
            $filter_name=$this->input->post('filter_name');
           
             //echo $filter_val;         
		
         if(!empty($filter_val))
         {
        	$cond1=array('pcat'=>trim($filter_val));
			$fetch_data =$this->tm->getRows($_POST,$cond1); 
		 }
         else
         {
             $cond1=array('p_sts'=>'1');
			$fetch_data =$this->tm->getRows($_POST,$cond1);
         }

		
		$data = array();
			
		foreach($fetch_data as $t)
		{
            $action = null;
             $html=null;

            $pname=explode('|~~|',$t->pname);
			$pimage=explode(',',$t->p_prd_img);
			$pdatasheet=explode(',',$t->p_datasheets);
			
            $sub_array = array();
            
            if(empty($t->p_prd_img))
				{
					$filename="https://birigroup.com/uploads/prd_images/".$t->pcode.'.jpeg';
				 if (file_exists($filename)) {
				 	$img_path=$filename;
					} else {
					$img_path="https://birigroup.com/uploads/prd_images/".$t->pcode.'.jpg';
				    }
				}
				 else
				 {
				 	$first_img_prd=explode(',',$t->p_prd_img);
				 	if(!empty($first_img_prd[0]))
				 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
				 	else
				 	$img_path="https://birigroup.com/uploads/prd_images/".$t->p_prd_img;
				 }
		    $sub_array[] = '<img src="'.$img_path.'" width="100" height="100">';
		    if(!empty($pname[1]))
            $sub_array[] = $pname[0].'<br/>'.$pname[1];
        else
        	$sub_array[] = $pname[0];
            $sub_array[] = $t->pcode;
            $sub_array[] = $t->p_uae_final;
			$sub_array[] = $t->p_purchase_price;
            $sub_array[] = $t->pcat;
          
          $action.='<a  onclick="view_prd_data('."'".$t->pid."'".')" class="btn btn-default"><i class="fa fa-eye"></i></a>

				&nbsp; &nbsp;
<a href="'.base_url("edit_prd/".$t->pid).'" class="delete-row"><i class="fa fa-pencil"></i></a>	';
				
			if(($this ->session->userdata['user']['role'])=="1")
			{
			 $action.='<a href="'.base_url('delete_prd/'.$t->pid).'" class="delete-row"><i class="fa fa-trash-o"></i></a>';
			}
			$action.='&nbsp;&nbsp;
				<a class="btn btn-success btn-xs" onclick="edit_add_hgt('."'".$t->pid."'".')">Add/Edit width/height</a>&nbsp;&nbsp;';

				 $sub_array[] = $action;
                $data[] = $sub_array;
            
		}

 if(!empty($filter_val))
         {
         	$cond1=array('pcat'=>trim($filter_val));
			 $output = array(
	            "draw" => intval($_POST["draw"]),
	            "recordsTotal" => $this->tm->countAll(),
	            "recordsFiltered" => $this->tm->countFiltered($_POST,$cond1),
	            "data" => $data,
	        );
		}
		else
		{
			$output = array(
	            "draw" => intval($_POST["draw"]),
	            "recordsTotal" => $this->tm->countAll(),
	            "recordsFiltered" => $this->tm->countFiltered($_POST),
	            "data" => $data,
	        );
		}
		echo json_encode($output);
}

function ajax_load_view_prd()
{
	$prd_id=$this->input->post('prd_id');
	$this->tm->table = 'products';
	  		$this->tm->join_table = array('brand', 'category', 'units', 'country_val', 'hse_code');
            $this->tm->join_where = array('brand.bid=products.pbrand', 'category.cid=products.pcat', 'units.uid=products.punit', 'country_val.country_id=products.p_country', 'hse_code.hse_id=products.p_hse_id');
            $this->tm->column_order = array('pid', 'p_prd_img', 'pname', 'pcode', 'p_uae_final','pcat');
            $this->tm->column_search = array('pid', 'p_prd_img', 'pname', 'pcode', 'p_uae_final','pcat');
            $this->tm->order = array('pid' => 'desc');  
            $cond=array('pid'=>$prd_id);
	// $order_by=('po_id');
	// $order_type="DESC";
		$t =$this->tm->getRows($_POST,$cond); 
$pname=explode('|~~|',$t[0]->pname);
$pimage=explode(',',$t[0]->p_prd_img);
if(empty($t[0]->p_prd_img))
				{
					$filename="https://birigroup.com/uploads/prd_images/".$t[0]->pcode.'.jpeg';
				 if (file_exists($filename)) {
				 	$img_path=$filename;
					} else {
					$img_path="https://birigroup.com/uploads/prd_images/".$t[0]->pcode.'.jpg';
				    }
				}
				 else
				 {
				 	$first_img_prd=explode(',',$t[0]->p_prd_img);
				 	if(!empty($first_img_prd[0]))
				 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
				 	else
				 	$img_path="https://birigroup.com/uploads/prd_images/".$t[0]->p_prd_img;
				 }
$pdatasheet=explode(',', $t[0]->p_datasheets);
		$html='
			<div class="row">
			<div class="col-md-12 col-sm-12">
		<div class="col-md-9 col-sm-9">
			<div class="col-md-4">
				<b>SKU:</b>';if(!empty($t[0]->psku)){$html.=$t[0]->psku;} $html.='<br/>
				<b>Product Type:</b>';if(!empty($t[0]->ptype)){$html.=$t[0]->ptype;}$html.='<br/>
				<b>Brand:</b>';if(!empty($t[0]->bname)){$html.=$t[0]->bname;}$html.='<br/>
				<b>Product Code:</b>'. $t[0]->pcode.'<br/>
				<b>Selling Price:</b>';if(!empty($t[0]->p_selling_price)){$html.=$t[0]->p_selling_price;}$html.='<br/>
				<b>Purchase price:</b>';if(!empty($t[0]->p_purchase_price)){$html.=$t[0]->p_purchase_price;}$html.='<br/>
				<b>VAT Percentage:</b>';if(!empty($t[0]->p_vat_perc)){$html.=$t[0]->p_vat_perc;}$html.='<br/>
			</div>
			<div class="col-md-4">
				<b>Category:</b>';if(!empty($t[0]->cname)){$html.=$t[0]->cname;}$html.='<br/>
				<b>Sub-Category:</b>';if(!empty($t[0]->pcat_sub)){$html.=$t[0]->pcat_sub;}$html.='<br/>
				<b>Bin Capacity:</b>';if(!empty($t[0]->pbin_capacity)){$html.=$t[0]->pbin_capacity;}$html.='<br/>
				<b>Alert Quantity:</b>';if(!empty($t[0]->palert_qnty)){$html.=$t[0]->palert_qnty;}$html.='<br/>
				<b>Country of Orgin:</b>';if(!empty($t[0]->name)){$html.=$t[0]->name;}$html.='<br/>
				<b>Stock:</b>';if(!empty($t[0]->p_stock_val)){$html.=$t[0]->p_stock_val;}$html.='<br/>
				
			</div>
			<div class="col-md-4">
				<b>Product Weight:</b>';if(!empty($t[0]->p_wgt)){$html.=$t[0]->p_wgt;}$html.='<br/>
				<b>Unit:</b>';if(!empty($t[0]->uname)){$html.=$t[0]->uname;}$html.='<br/>
				<b>Packing Sizes (w):</b>';if(!empty($t[0]->p_pack_width)){$html.=$t[0]->p_pack_width;}$html.='<br/>
				<b>Packing Sizes (h):</b>';if(!empty($t[0]->p_pack_hgt)){$html.=$t[0]->p_pack_hgt;}$html.='<br/>
				<b>Packing Sizes (l):</b>';if(!empty($t[0]->p_pack_lgth)){$html.=$t[0]->p_pack_lgth;}$html.='<br/>';
			if(!empty($t->p_variation))
			{
				$var_names=explode("##",$t[0]->p_variation);
			$var_values=explode('##',$t[0]->p_variation_types);
			$new_var_val=array();
			$new_var_names=array();
				foreach($var_names as $key1=>$vn)
				{
					$new_var_names[]=$vn;
					$new_var_val[$vn]=$var_values[$key1];
				}
			$html.= "<b>Variation Available:</b>".implode(',',$new_var_names)."<br/>"; 
			$html.= "<b>Variation values:</b>";
				foreach($new_var_val as $k=>$test)
				{
					$html.= "<br/>";
					$html.=$k.'-'.ltrim($test,',');
				}
			}
			else
			{
				$html.= "<b>Variation Available:</b><br/>";
				$html.= "<b>Variation values:</b><br/>";
			}
			$html.='</div>
			<div class="col-md-12">
				<b>Description:</b>'.$t[0]->p_desc.'<br/>
			</div>
		</div>
		<div class="col-sm-3">
			<div class="thumbnail-gallery">
				<a class="img-thumbnail lightbox" href="'.$img_path.'" target="_blank" data-plugin-options="{ &quot;type&quot;:&quot;image&quot; }">
				<img class="img-responsive" width="215" src="'.$img_path.'">
				<!-- <span class="zoom">
				<i class="fa fa-search"></i>
				</span> -->
				</a>
			<div class="row">';
		foreach($pimage as $img)
		{	
		  $html.='<div class="column">
		    <img class="img-responsive" src="'.$img_path.'" width="50" height="50">
		  </div>';
  		}
		$html.='</div>
				</div>
		</div>
	</div>
	</div>';
	$html.='<div class="row"><div class="col-md-12 col-sm-12">
		<div class="col-md-4">
			<b>UAE Final:</b>'.$t->p_uae_final.'<br/>
			<b>UAE Level-1:</b>'.$t->p_uae_l1.'<br/>
			<b>UAE Level-2:</b>'.$t->p_uae_l2.'<br/>
		</div>
		<div class="col-md-4">
			<b>KSA Final:</b>'.$t->p_ksa.'<br/>
			<b>KSA Level-1:</b>'.$t->p_ksa_l1.'<br/>
			<b>KSA Level-2:</b>'.$t->p_ksa_l2.'<br/>
		</div>';
	if(!empty($t->p_datasheets))
	{
	$html.='<div class="col-md-4">
			<b>Additional Documents:</b><br/>';
		foreach($pdatasheet as $dsheet)
		{
			$ext = pathinfo("uploads/production/datasheets/".$dsheet, PATHINFO_EXTENSION); //$ext will be gif
			if($ext=="jpg" || $ext=="jpeg")
			{
				$html.= '<span>
				<a href="'.base_url("uploads/production/datasheets/").$dsheet.'" download><i class="fa fa-image"></i></a>
				</span>';
			}
			elseif($ext=="pdf")
			{
			$html.= '<span>
			<a href="'.base_url("uploads/production/datasheets/").$dsheet.'" download><i class="fa fa-file-pdf-o"></i></a>
			</span>';
			}
			else{
			$html.= '<span><i class="fa fa-file"></i></span>';
			}
		// echo "<span><i class="fa fa-pdf"></i>
		// <img src='".base_url('uploads/production/datasheets/').$dsheet."' width="150" height="150"></span><br/>";
		}

		$html.='</div>';	
	}
	$html.='</div></div>';
	print_r($html);
	//echo $html;
}

function ajax_load_edit_prd_essentials()
{
	$prd_id=$this->input->post('prd_id');
	$prd_details=$this->tm->get_data('products',array('pid'=>$prd_id));
	 $html='
<input type="hidden" name="prd_id" class="form-control" value="'.$prd_id.'">
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Enter Width</label>
<div class="col-sm-9">
<input type="text" name="prd_width" class="form-control" value="';if(!empty($prd_details[0]->prd_width)){$html.=$prd_details[0]->prd_width;}
$html.='" />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Enter Height</label>
<div class="col-sm-9">
<input type="text" name="prd_height" class="form-control" value="';
if(!empty($prd_details[0]->prd_height)){$html.=$prd_details[0]->prd_height;}
$html.='"/>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Enter Area</label>
<div class="col-sm-9">
<input type="text" name="prd_area" class="form-control" value="';if(!empty($prd_details[0]->p_area)){$html.=$prd_details[0]->p_area;}$html.='"/>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Enter Clamps Required</label>
<div class="col-sm-9">
<input type="text" name="prd_clamps" class="form-control" value="';if(!empty($prd_details[0]->p_clamp)){$html.=$prd_details[0]->p_clamp;}$html.='"/>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Enter Thickness of Aluminium(mm)</label>
<div class="col-sm-9">
<input type="text" name="prd_al_thickness" class="form-control" value="';if(!empty($prd_details[0]->p_al_thickness)){$html.=$prd_details[0]->p_al_thickness;}$html.='" />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Choose Aluminium Type(mm) </label>
<div class="col-sm-9">
	<select name="prd_al_type" class="form-control">
		<option>Choose</option>
		<option value="2mm" ';if(!empty($prd_details[0]->p_al_type)){if($prd_details[0]->p_al_type=="2mm"){$html.="selected";}}$html.='>2mm</option>
		<option value="3mm" ';if(!empty($prd_details[0]->p_al_type)){if($prd_details[0]->p_al_type=="3mm"){$html.="selected";}}$html.='>3mm</option>
	</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Enter price(If Not Exist)</label>
<div class="col-sm-9">
<input type="text" name="prd_selling_price" class="form-control" value="';if(!empty($prd_details[0]->p_selling_price)){$html.=$prd_details[0]->p_selling_price;}$html.='"/>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Purchase price(Add Directly Without Approve)</label>
<div class="col-sm-9">
<input type="text" name="p_purchase_price" class="form-control" value="';if(!empty($prd_details[0]->p_purchase_price)){$html.=$prd_details[0]->p_purchase_price;}$html.='"/>
</div>
</div>


</div>';   
           echo $html;
}


function filter_type()
{
	$name=$this->input->post('type_name');
	$val=$this->input->post('type');
$return_data=	$this->Prod_list($filter_name,$filter_val);
}










}