<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Survey_controller extends CI_Controller {


public function __construct() {
		parent::__construct();
		$this->load->helper(array('session','email','img','gnrl','email_survey'));	
		$this->load->model(array('Third_db_model'=>'tm','Survey_model'=>'srvm'));
	}

function add_survey_data($edit_survey_id=null)
{
	if(logged_in())
	{


$page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='create-survey-data')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {


			$data['products']=$this->tm->get_data('products',array('p_sts'=>'1'));
	$sql="SELECT * FROM sales_customer_entry WHERE sca_cust_company LIKE '%PSD RAK%' OR sca_cust_company LIKE '%Road and Transportation Authority Sharjah%'";
		$qry=$this->db->query($sql);
		$data['customers']=$qry->result();

		if(empty($edit_survey_id))
		{
			$val_item_req=$this->Admin_model->get_data('survey_table',array('st_sts'=>'1'),'','','st_id','DESC');
			if(empty($val_item_req))
			$data['doc_num']='SUR1000';
			else
			{
			$bal_string1=str_replace("SUR", "", $val_item_req[0]->st_survey_no);
			//print_r($bal_string1);
		           $new_id_1=($bal_string1)+1;
		            $data['doc_num']="SUR".$new_id_1;
			}	
			$this->load->view('admin/production/add_survey',$data);
		}
		else
		{
			$data['result']=$this->Admin_model->get_data('survey_table',array('st_sts'=>'1','st_id'=>$edit_survey_id));
				$prd_ids=explode('|#|', $data['result'][0]->st_po_prd_ids);
				 foreach($prd_ids as $pid)
				 {
				 	$data['prds'][]=$this->tm->get_data('products',array('pid'=>$pid));
				 }			
			 $data['prd_set_details']=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$data['result'][0]->st_id));

			foreach($data['prd_set_details'] as $index=>$ppp)
				{
					$prds_id_sets=explode(',',$ppp->psd_prd_id);
					$prd_sets_array[]=$ppp->psd_prd_id;
					$edit_prd_set_data[]=$ppp->psd_id;
						
					foreach($prds_id_sets as $q)
					{
						$data['prd_ids'][$index][]=$this->tm->get_data('products',array('pid'=>$q));
					}
				}
	
			$single_prd_sets=explode(',',$data['result'][0]->st_single_prds);
			$data['single_prds']=$data['result'][0]->st_single_prds;
				foreach($single_prd_sets as $q)
				{
					$data['prd_ids2'][]=$this->tm->get_data('products',array('pid'=>$q));
				}

				if(!empty($prd_sets_array))
				{
				$data['actual_prd_sets']=implode('|$|',$prd_sets_array);
				$data['edit_prd_set_id']=implode(',',$edit_prd_set_data);
				}
				$cust_id_selected=$data['result'][0]->st_customer_id;
				
			$this->load->view('admin/production/add_survey',$data);
		}


		  }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  				
	
	}
}
function check_customer_pricing()
{
	$cust_id=$this->input->post('cust_id');
	$result=$this->Admin_model->get_data('survey_customer_pricing',array('scp_cust_id'=>$cust_id,'scp_sts'=>'1'));
	if(!empty($result))
	{
		$prd_ids=explode('|#|',$result[0]->scp_prd_ids);
		$prd_prices=explode('|#|',$result[0]->scp_prd_price);
		foreach($prd_ids as $pid)
		{
			$prd_data[]=$this->tm->get_data('products',array('pid'=>$pid));
		}

		echo "<select data-plugin-selectTwo class='form-control populate search_product_select_2' name='search_product_cat' onchange='customer_prd_search()'>
				<option></option>";
    foreach($prd_data as $index=>$c)
     	{
     		 $prd_name=explode('|~~|',$c[0]->pname);
        echo "<option value='".$c[0]->pid.":".$prd_prices[$index]."' >".$prd_name[0].' ::  <br/><br/> '.$c[0]->pcode."</option>";
	  	}
 		echo "</select>";
	}
	else
	{
		echo FALSE;
	}
}

function submit_survey_details()
{
	$dept_choosed=$this->input->post('dept_choosed[]');
	$edit_survey_id=$this->input->post('edit_survey_details');
	$edit_prd_set_id=$this->input->post('edit_prd_set_id');
	$suvey_po_prd_ids=$this->input->post('edit_survey_prd_ids');
	$single_prd_ids_edit=$this->input->post('edit_actual_single_prds');

	$po_dpet='';$install_dept='';$date_set_for_installation='';$date_set_for_po='';
	foreach($dept_choosed as $dc)
	{
		if($dc=="p_o")
		{
			$po_dpet="Production";
			if(!empty($this->input->post('st_po_dept_date')))
			{
			$date_set_for_po=$this->input->post('st_po_dept_date');
				$date0=explode('/',$date_set_for_po);
				
				$date1=$date0[0];
				$month1=$date0[1];
				$year1=$date0[2];
				$new_formated_date1=$year1.'-'.$month1.'-'.$date1;
			}
			else
			{
				$new_formated_date1='';
			}
		}
		else
		{
			$install_dept="Installation";
			if(!empty($this->input->post('st_installation_dept_date')))
			{
			$date_set_for_installation=$this->input->post('st_installation_dept_date');
			$date1=explode('/',$date_set_for_installation);
				
				$date2=$date1[0];
				$month2=$date1[1];
				$year2=$date1[2];
				$new_formated_date2=$year2.'-'.$month2.'-'.$date2;
			}
			else
			{
				$new_formated_date2='';
			}
		}
	}
// 	$checkbox_cash_customer=$this->input->post('add_cash_customer');
// 	if($checkbox_cash_customer=='1')
// 	{
// 		if(!empty($this->input->post('st_new_cust_name')))
// 		$custname=$this->input->post('st_new_cust_name');
// 		else
// 			$custname='';

// 		if(!empty($this->input->post('st_new_cust_comp')))
// 		$custcomp=$this->input->post('st_new_cust_comp');
// 		else
// 			$custcomp='';

// 		if(!empty($this->input->post('st_new_cust_email')))
// 		$custemail=$this->input->post('st_new_cust_email');
// 		else
// 			$custemail='';

// 		if(!empty($this->input->post('st_new_cust_mobile')))
// 		$custmob=$this->input->post('st_new_cust_mobile');
// 		else
// 			$custmob='';

// 		if(!empty($this->input->post('st_new_cust_land')))
// 		$custland=$this->input->post('st_new_cust_land');
// 		else
// 			$custland='';	
			
// 		$data_customer_insert=array(
//            	'sca_cust_name'=>$custname,
//            	'sca_cust_country'=>'228',
//              'sca_cust_email'=>$custemail,
//            	'sca_cust_company'=>$custcomp,
//            	'sca_cust_landline'=>$custland,
//            	'sca_cust_mobile'=>$custmob,
//            	'sca_staff_id'=>$this->session->userdata['user']['username'], 
//            	'sca_status'=>'1'
//            ); 	
//         	 if(empty($edit_survey_id))
// 			{
//         	$customer_insert_id=$this->Admin_model->insert_data('sales_customer_entry',$data_customer_insert);
//         	$cust_id="CUST_".str_pad($customer_insert_id, 2, '0', STR_PAD_LEFT);
// 	     		$data1_cust=array('sca_cust_id'=>$cust_id);
// 	     	//$this->Admin_model->update_data('sales_customer_entry',$data1_cust,array('sca_id'=>$customer_insert_id));
// 	     	}		     			
// 	}
// else{
	$cusotmer_details=$this->Admin_model->get_data('sales_customer_entry',array('sca_id'=>$this->input->post('choose_customer')));	
	$custname=$cusotmer_details[0]->sca_cust_name;
	$custcomp=$cusotmer_details[0]->sca_cust_company;
	$custemail=$cusotmer_details[0]->sca_cust_email;
	$custmob=$cusotmer_details[0]->sca_cust_mobile;
	$custland=$cusotmer_details[0]->sca_cust_landline;
	$customer_insert_id=$this->input->post('choose_customer');
//}

if(!empty($single_prd_ids_edit))
{
	$single_prd_ids=$single_prd_ids_edit;
	if(!empty($this->input->post('actual_single_prds')))
	{
		$single_prd_ids=$this->input->post('actual_single_prds');		
	}
}
else
{
	$single_prd_ids=$this->input->post('actual_single_prds');
}
	$data=array(
		'st_survey_no'=>$this->input->post('st_survey_no'),
		'st_start_cordinate'=>$this->input->post('st_start_cordinate'),
		'st_end_cordinate'=>$this->input->post('st_end_cordinate'),
		//'st_customer'=>$this->input->post('st_customer'),
		'st_additional_desc'=>$this->input->post('st_additional_desc'),
		'st_po_dept_date'=>$new_formated_date1,
		'st_installation_dept_date'=>$new_formated_date2,
		'st_dept_po'=>$po_dpet,
		'st_dept_installation'=>$install_dept,
		'st_po_prd_ids'=>$this->input->post('prdids'),
		'st_sts'=>'1',
		'st_user_created'=>$this->session->userdata['user']['username'],
		'st_customer_id'=>$customer_insert_id,
		'st_new_cust_name'=>$custname,
		'st_new_cust_comp'=>$custcomp,
		'st_new_cust_email'=>$custemail,
		'st_new_cust_mobile'=>$custmob,
		'st_new_cust_land'=>$custland,
		'st_clearance'=>$this->input->post('st_clearance'),
		'st_underground_pipe'=>$this->input->post('st_underground_pipe'),
		'st_single_prds'=>$single_prd_ids,
		'st_po_prd_additional_info'=>$this->input->post('prd_additional_info'),	
		'st_survey_type'=>$this->input->post('survey_type_selected'),	
	);
	//print_r($data);
	if(empty($edit_survey_id))
	{
		$insert_id=$this->Admin_model->insert_data('survey_table',$data);
		$survey_id_inserted=$insert_id;

		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'survey created',
			'act_status'=>'new survey created',
			'act_survey_id'=>$survey_id_inserted,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
		);
		  $this->Admin_model->insert_data('activities',$activity_data);
		  send_mail_survey($survey_id_inserted,'new');
	}
	else
	{
		$this->Admin_model->update_data('survey_table',$data,array('st_id'=>$edit_survey_id));
		$survey_id_inserted=$edit_survey_id;
		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'survey edited',
			'act_status'=>'survey details edited',
			'act_survey_id'=>$survey_id_inserted,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$activity_data);
	}
//pre_list($data);
	
	//////////////enter product set data here///////////

if(!empty($this->input->post('actual_prd_sets')))
{
	$prd_sets=array_filter(explode('|$|',$this->input->post('actual_prd_sets')));
	foreach($prd_sets as $ps)
	{
		$data_prd_set=array(
			'psd_survey_id'=>$survey_id_inserted,
			'psd_user_created'=>$this->session->userdata['user']['username'],
			'psd_prd_id'=>$ps,
			'psd_sts'=>'1'
		);
		//pre_list($data_prd_set);
		$insert_id2=$this->Admin_model->insert_data('product_set_data',$data_prd_set);
		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'survey Product set created',
			'act_status'=>'Product set with id '.$insert_id2.' created',
			'act_survey_id'=>$survey_id_inserted,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$activity_data);
	}
}	
if(empty($edit_survey_id))
send_mail_survey($survey_id_inserted,'new');
	else
send_mail_survey($survey_id_inserted,'edit');
	
	if(!empty($insert_id))
	{
		 $this->session->set_flashdata('success', 'Data Successfully inserted');
	 	redirect('show-prd-sets/'.$survey_id_inserted);		
	}	
	elseif(!empty($edit_survey_id))
	{
		$this->session->set_flashdata('success', 'Data Successfully updated');
		 redirect('show-prd-sets/'.$survey_id_inserted);		
	}
	else
	{
		 $this->session->set_flashdata('errors', 'Error in creating survey.Please check again and try later.');
		 redirect('create-survey-data');
	}
	
}

function list_survey_data()
{

  if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-survey-data')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {



	$data['result']=$this->Admin_model->get_data('survey_table',array('st_sts'=>'1'),'','','st_id','DESC');

	foreach($data['result'] as $index1=>$sr)
			{
				$prd_ids_explode=explode('|#|',$sr->st_po_prd_ids);
	$data['installation_table_details'][]=$this->Admin_model->get_data('installation_details',array('insd_survey_id'=>$sr->st_id),'1','','insd_id','DESC');
	$data['installation_table'][]=$this->Admin_model->get_data('installation_dept',array('ins_survey_id'=>$sr->st_id));
				foreach($prd_ids_explode as $q)
				{
					$data['prd_ids'][$index1][$index1][]=$this->tm->get_data('products',array('pid'=>$q));
				}
			}
			//pre_list($data['installation_table_details']);
	$this->load->view('admin/production/list_survey_data',$data);


 }

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 

}

function show_prd_sets($survey_id=null)
{
	if(logged_in())
	{
		$data['survey_id']=$survey_id;
		$data['survey_result']=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));
		$data['survey_result_2']=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$survey_id));
		if(!empty($data['survey_result']))
		{
			foreach($data['survey_result_2'] as $index1=>$sr)
			{  
				$prd_ids_explode=explode(',',$sr->psd_prd_id);
				$data['prd_set_id'][]=$sr->psd_id;
				$data['prd_alignment'][]=$sr->psd_prd_alignment;
				foreach($prd_ids_explode as $q)
				{
					$data['prd_ids'][$index1][]=$this->tm->get_data('products',array('pid'=>$q));
				}
			}
			
			$prd_ids_explode_2=explode(',',$data['survey_result'][0]->st_single_prds);
			foreach($prd_ids_explode_2 as $q)
				{
					$data['prd_ids_singles'][]=$this->tm->get_data('products',array('pid'=>$q));
				}
// print_r($data['survey_result'][0]->st_single_prds);
 //pre_list($data['prd_ids_singles']);
		$this->load->view('admin/production/show_prd_sets',$data);
	 	}
	 	else
	 	{
	 		$this->session->set_flashdata('errors', 'Product Set details unavilable ');
	 			redirect('list-survey-data');
	 	}
	}	
}

function manage_prd_singles($survey_id,$prd_id)
{
	if(logged_in())
	{
		$data['survey_id']=$survey_id;
	$data['survey_result']=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));
	$data['prd_ids']=$this->tm->get_data('products',array('pid'=>$prd_id));			
	$this->load->view('admin/production/manage_prd_singles',$data);
	}
}

function manage_prd_set($prd_set_id)
{
	if(logged_in())
	{

	$data['prd_set_data']=$this->Admin_model->get_data('product_set_data',array('psd_id'=>$prd_set_id));
	$data['survey_result']=$this->Admin_model->get_data('survey_table',array('st_id'=>$data['prd_set_data'][0]->psd_survey_id));

	$prds_id_sets=explode(',',$data['prd_set_data'][0]->psd_prd_id);
	$data['arrange_pos']=$data['prd_set_data'][0]->psd_arrange_position;
	if(!empty($data['arrange_pos']))
	{
	$pos=explode(',',$data['arrange_pos']);
		foreach($prds_id_sets as $index=>$q)
		{
			$data['prd_ids_img'][$pos[$index]]=$this->tm->get_data('products',array('pid'=>$q));
		}
	}
	
	foreach($prds_id_sets as $q)
		{
			$data['prd_ids'][]=$this->tm->get_data('products',array('pid'=>$q));
		}
		$data['count_prd_id']=count($data['prd_ids']);
	////pre_list($data['prd_ids_img']);
	$this->load->view('admin/production/manage_prd_sets',$data);
	}
}

function submit_manage_prd_singles()
{
	$edit_survey_id=$this->input->post('survey_id');
	$edit_prd_id=$this->input->post('prd_id');
	$survey_data=$this->Admin_model->get_data('survey_table',array('st_id'=>$edit_survey_id));

	$prd_ids=explode(',', $survey_data[0]->st_single_prds);
	$prd_qtys=explode(',', $survey_data[0]->st_single_prd_qtys);

	$prd_pipe_qty=explode(',', $survey_data[0]->st_single_pipe_qty);
	$prd_pipe_hgt=explode(',', $survey_data[0]->st_single_pipe_hgt);
	$prd_serial_no=explode(',', $survey_data[0]->st_single_prd_serial_no);
	$prd_map_cordinate=explode('$#$', $survey_data[0]->st_single_prd_map_cordinates);
//pre_list($prd_qtys);
	foreach ($prd_ids as $key => $value) {

		if($edit_prd_id==$value)
		{
			//echo "in if";
			$prd_qtys_new[$key]=$this->input->post('qnty_required');
				$prd_pipe_qty_new[$key]=$this->input->post('pipe_qnty');
				$prd_pipe_hgt_new[$key]=$this->input->post('pipe_hgt');	
				$prd_serial_no[$key]=$this->input->post('psd_serial_number');
				$prd_map_cordinates[$key]=$this->input->post('psd_map_cordinate');	
		}
		else
		{
			//echo "in else";
			if(!empty($prd_qtys[$key]))
			{
				//echo "in if 1";
				$prd_qtys_new[$key]=$prd_qtys[$key];
				$prd_pipe_qty_new[$key]=$prd_pipe_qty[$key];
				$prd_pipe_hgt_new[$key]=$prd_pipe_hgt[$key];
				$prd_serial_no[$key]=$prd_serial_no[$key];
				$prd_map_cordinates[$key]=$prd_map_cordinate[$key];
			}
			else
			{
				//echo "in else 2";
				$prd_qtys_new[$key]='0';
				$prd_pipe_qty_new[$key]='0';
				$prd_pipe_hgt_new[$key]='0';	
				$prd_serial_no[$key]='0';
				$prd_map_cordinates[$key]='0';					
			}
		}
	}

//print_r(implode(',', $prd_qtys_new));	
	$edit_prd_id=$this->input->post('prd_id');
	$data=array(
		'st_single_prd_qtys'=>implode(',', $prd_qtys_new),
		'st_single_pipe_hgt'=>implode(',', $prd_pipe_hgt_new),
		'st_single_pipe_qty'=>implode(',', $prd_pipe_qty_new),
		'st_single_prd_serial_no'=>implode(',', $prd_serial_no),
		'st_single_prd_map_cordinates'=>implode('$#$', $prd_map_cordinates),
		);
$this->Admin_model->update_data('survey_table',$data,array('st_id'=>$edit_survey_id));
	 $activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Survey - Managed Product singles',
			'act_status'=>'Product single with id '.$edit_prd_id.' managed/edited',
			'act_survey_id'=>$edit_survey_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$activity_data);

		if(in_array('0', $prd_qtys_new))
		{
			$this->session->set_flashdata('success', 'Data Successfully updated');
		redirect('show-prd-sets/'.$edit_survey_id);	
		}
		elseif(in_array('', $prd_qtys_new))	
		{
			$this->session->set_flashdata('success', 'Data Successfully updated');
		redirect('show-prd-sets/'.$edit_survey_id);	
		}		
		else
		{
			$sql=$this->db->query("SELECT * FROM `product_set_data` WHERE `psd_prd_alignment` IS NULL AND `psd_survey_id`=".$edit_survey_id." ");
			$prd_with_empty_qty=$sql->result_array();
			if(!empty($prd_with_empty_qty))
			{
				$this->session->set_flashdata('success', 'Data Successfully updated');
				redirect('show-prd-sets/'.$edit_survey_id);		
			}
			else
			{
				redirect('status-page-prd-set/'.$edit_survey_id);/////show this page, only if all the survey product sets hasgot required quantities for each products
			}
		}		
}

function submit_manage_prd_set()
{
	$data=array(
		'psd_prd_alignment'=>$this->input->post('alignment'),
		'psd_arrange_position'=>implode(',',$this->input->post('arrange_position[]')),
		'psd_serial_number'=>$this->input->post('psd_serial_number'),
		'psd_map_cordinate'=>$this->input->post('psd_map_cordinate'),
		'psd_sts'=>'1',
		'psd_user_created'=>$this->session->userdata['user']['username'],
		'psd_prd_qty'=>$this->input->post('qnty_required'),
		'psd_pipe_hgt'=>$this->input->post('pipe_hgt'),
		'psd_pipe_qnty'=>$this->input->post('pipe_qnty'),
		//'is_triangle'=>implode(',',$this->input->post('item_shape[]')),
	);
	 $psd_id=$this->input->post('update_psd_id');
	 $survey_id=$this->input->post('survey_id');
	 $this->Admin_model->update_data('product_set_data',$data,array('psd_id'=>$psd_id));
	 $activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Survey - Managed Product set',
			'act_status'=>'Product set with id '.$psd_id.' managed/edited',
			'act_survey_id'=>$survey_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$activity_data);
	$this->session->set_flashdata('success', 'Data Successfully updated');
	
	$sql=$this->db->query("SELECT * FROM `product_set_data` WHERE `psd_prd_alignment` IS NULL AND `psd_survey_id`=".$survey_id." ");
	$prd_with_empty_qty=$sql->result_array();
	///checking all prds has alinemnt . that is if alinemnt is empty or not, if empty, then cant create production order
	if(!empty($prd_with_empty_qty))
	{
	redirect('show-prd-sets/'.$survey_id);
	}	
	else
	{
		$survey_data_single_prd=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));
		if($survey_data_single_prd[0]->st_single_prds=='')
		{
		redirect('status-page-prd-set/'.$survey_id);/////show this page, only if all the survey product sets hasgot required quantities for each products
		}
		else
		{
			$prd_qtys_single=explode(',',$survey_data_single_prd[0]->st_single_prd_qtys);
			if(in_array('0', $prd_qtys_single))
			{
				redirect('show-prd-sets/'.$survey_id);	
			}
			elseif(in_array('', $prd_qtys_single))
			{
				redirect('show-prd-sets/'.$survey_id);	
			}
			else
			{
			redirect('status-page-prd-set/'.$survey_id);/////show this page, only if all the survey product sets hasgot required quantities for each products
			}

		}
	}
}

function sts_prd_set($prd_set_survey_id)
{
	if(logged_in())
	{
		if(!empty($prd_set_survey_id))
		{
			$data['prd_set_data']=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$prd_set_survey_id));
			
			foreach($data['prd_set_data'] as $index=>$ppp)
			{
				$prds_id_sets=explode(',',$ppp->psd_prd_id);

				foreach($prds_id_sets as $index11=>$q)
				{

					$data['prd_ids'][$index][]=$this->tm->get_data('products',array('pid'=>$q));
					$prd_set_qnty[$q][]=$ppp->psd_prd_qty;
				}
			}
			$data['count_prd_id']=count($data['prd_ids']);

			$data['result']=$this->Admin_model->get_data('survey_table',array('st_id'=>$prd_set_survey_id));
			$prd_ids_explode_2=explode(',',$data['result'][0]->st_single_prds);
			$prd_single_qnty=explode(',',$data['result'][0]->st_single_prd_qtys);
			foreach($prd_ids_explode_2 as $index2=>$q)
				{
					$data['prd_ids_singles'][]=$this->tm->get_data('products',array('pid'=>$q));
					$prd_set_single[$q]=$prd_single_qnty[$index2];
				}

$array_filter_index=[];				
$array_filter_val=[];
foreach($prd_set_qnty as $set_index=>$set_qnty)
{
	$first_array_sum[$set_index]=array_sum($set_qnty);	
	$first_array_keys[]=$set_index;
}

$first_array_count=count($first_array_sum);
$second_array_count=count($prd_set_single);
$combinedAsArray = array();

if($first_array_count > $second_array_count)
{
	foreach($first_array_sum as $kry1=>$ind1)
	{
		 if (array_key_exists($kry1, $prd_set_single))
		 {
       		 $combinedAsArray[$kry1] = array($ind1, $prd_set_single[$kry1]);
        }
	    else
	    {
	        $combinedAsArray[$kry1] = array($ind1, '0');
	    }
	}
}
else
{
	foreach($prd_set_single as $kry1=>$ind1)
	{
		 if (array_key_exists($kry1, $first_array_sum))
		 {
       		 $combinedAsArray[$kry1] = array($ind1, $first_array_sum[$kry1]);
        }
	    else
	    {
	        $combinedAsArray[$kry1] = array($ind1, '0');
	    }
	}
}

foreach($combinedAsArray as $ind2=>$ca)
{
$po_final_array_index[]=$ind2;
$po_final_array_qnty[]=array_sum($ca);
}

$this->Admin_model->update_data('survey_table',array('st_po_prd_ids'=>implode('|#|', $po_final_array_index),'st_po_prd_qtys'=>implode('|#|', $po_final_array_qnty)),array('st_id'=>$prd_set_survey_id));

			$this->load->view('admin/production/show_prod_set_status',$data);
		}
	}
}

function print_prd_sets_status($prd_set_survey_id)
{
	if(logged_in())
	{
		if(!empty($prd_set_survey_id))
		{
			$data['prd_set_data']=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$prd_set_survey_id));
			
			foreach($data['prd_set_data'] as $index=>$ppp)
			{
				$prds_id_sets=explode(',',$ppp->psd_prd_id);

				foreach($prds_id_sets as $index11=>$q)
				{

					$data['prd_ids'][$index][]=$this->tm->get_data('products',array('pid'=>$q));
					$prd_set_qnty[$q][]=$ppp->psd_prd_qty;
				}
			}
			$data['count_prd_id']=count($data['prd_ids']);

			$data['result']=$this->Admin_model->get_data('survey_table',array('st_id'=>$prd_set_survey_id));
			$prd_ids_explode_2=explode(',',$data['result'][0]->st_single_prds);
			$prd_single_qnty=explode(',',$data['result'][0]->st_single_prd_qtys);
			foreach($prd_ids_explode_2 as $index2=>$q)
				{
					$data['prd_ids_singles'][]=$this->tm->get_data('products',array('pid'=>$q));
					$prd_set_single[$q]=$prd_single_qnty[$index2];
				}

$array_filter_index=[];				
$array_filter_val=[];
foreach($prd_set_qnty as $set_index=>$set_qnty)
{
	$first_array_sum[$set_index]=array_sum($set_qnty);	
	$first_array_keys[]=$set_index;
}

$first_array_count=count($first_array_sum);
$second_array_count=count($prd_set_single);
$combinedAsArray = array();

if($first_array_count > $second_array_count)
{
	foreach($first_array_sum as $kry1=>$ind1)
	{
		 if (array_key_exists($kry1, $prd_set_single))
		 {
       		 $combinedAsArray[$kry1] = array($ind1, $prd_set_single[$kry1]);
        }
	    else
	    {
	        $combinedAsArray[$kry1] = array($ind1, '0');
	    }
	}
}
else
{
	foreach($prd_set_single as $kry1=>$ind1)
	{
		 if (array_key_exists($kry1, $first_array_sum))
		 {
       		 $combinedAsArray[$kry1] = array($ind1, $first_array_sum[$kry1]);
        }
	    else
	    {
	        $combinedAsArray[$kry1] = array($ind1, '0');
	    }
	}
}

foreach($combinedAsArray as $ind2=>$ca)
{
$po_final_array_index[]=$ind2;
$po_final_array_qnty[]=array_sum($ca);
}

$this->Admin_model->update_data('survey_table',array('st_po_prd_ids'=>implode('|#|', $po_final_array_index),'st_po_prd_qtys'=>implode('|#|', $po_final_array_qnty)),array('st_id'=>$prd_set_survey_id));

			$this->load->view('admin/production/print_prod_set_status',$data);
		}
	}
}

function generate_po_survey($survey_id,$po_type=null) 
{
	$survey_details=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));
	$prd_set_data=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$survey_id));

if(!empty($survey_details[0]->st_single_prds))
{
	$item_id_prd_set=explode(',',$survey_details[0]->st_single_prds);
	$item_single_prd_qty=explode(',',$survey_details[0]->st_single_prd_qtys);
}

if(!empty($item_id_prd_set))
{
	foreach($item_id_prd_set as $index=>$spq)
	{
		if(!empty($item_single_prd_qty[$index]))
		{
			$item_prd_qty[]=$item_single_prd_qty[$index];
		}
		else
		{
			$item_prd_qty[]='0';
		}
	}
}
	foreach($prd_set_data as $prd_set)
	{
		$prds_id_sets=explode(',',$prd_set->psd_prd_id);
		foreach($prds_id_sets as $index11=>$q)
		{
			$item_id_prd_set[]=$q;
			if(empty($prd_set->psd_prd_qty))
			{
			$item_prd_qty[]='0';	
			}
			else
			{
			$item_prd_qty[]=$prd_set->psd_prd_qty;
			}
		}
	}

	$po_ids_survey=explode('|#|',$survey_details[0]->st_po_prd_ids);
	$additional_info_po=explode('|#|',$survey_details[0]->st_po_prd_additional_info);

	foreach($item_id_prd_set as $final_pid)
	{
		if(in_array($final_pid, $po_ids_survey))
		{
		$po_ids_position=array_search($final_pid, $po_ids_survey);
		$additonal_value_position[]=$additional_info_po[$po_ids_position];
		}
		else
		{
			$additonal_value_position[]='';
		}
	}

	$this->Admin_model->update_data('survey_table',array('st_po_prd_ids'=>implode('|#|',$item_id_prd_set),'st_po_prd_qtys'=>implode('|#|', $item_prd_qty),'st_po_prd_additional_info'=>implode('|#|', $additonal_value_position)),array('st_id'=>$survey_id));
	
if(!in_array('0', $item_prd_qty))
{
$data=array(
	'po_user_id'=>$this->session->userdata['user']['username'],
		'po_sales_person'=>$this->session->userdata['user']['username'],
		'po_date_delivry'=>$survey_details[0]->st_po_dept_date,
		'po_final_delivery_date'=>$survey_details[0]->st_po_dept_date,
		'po_delivery_loc'=>'Dubai Store',
		'po_dept'=>"Traffic Sign",
		'po_prd_name'=>implode('|#|',$item_id_prd_set),
		'po_qnty'=>implode('|#|', $item_prd_qty),
		'po_rmks'=>implode('|#|', $additonal_value_position),
		'po_order_status_adv'=>'1',
		'po_sts'=>"1",
		'po_survey_dept'=>$survey_id,
	);
	//pre_list($data);
	if(!empty($po_type))
	{
		$survey_po=$this->tm->get_data('prd_order',array('po_survey_dept'=>$survey_id));
		$insert_id_po=$survey_po[0]->po_id;
		$activity_sts="Survey details to PO updated for survey number ".$survey_id."";
		$this->tm->update_data('prd_order',$data,array('po_survey_dept'=>$survey_id));
	}
	else
	{
		$activity_sts="Survey details send to PO. PO id ".$insert_id_po."";
		$insert_id_po=$this->tm->insert_data('prd_order',$data);
	}
	
	 $activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Survey - generate PO',
			'act_status'=>$activity_sts,
			'act_survey_id'=>$survey_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$activity_data);

	if(!empty($survey_details[0]->st_dept_installation))
	{
		$data_installation=array(
			'ins_survey_id'=>$survey_id,
			'ins_schedule_date'=>$survey_details[0]->st_installation_dept_date,
			'ins_sts_installation'=>'scheduled',
			'ins_sts'=>'1',
			'ins_po_id'=>$insert_id_po,
			'session_user'=>$this->session->userdata['user']['username'],
		);
		$insert_id_installation=$this->Admin_model->insert_data('installation_dept',$data_installation);

			 $activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Survey - Installation scheduled',
			'act_status'=>'Survey details added to Installation with id '.$insert_id_installation,
			'act_survey_id'=>$survey_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
			);
		$this->Admin_model->insert_data('activities',$activity_data);
	}

	if(!empty($insert_id_po))
	{
		$this->Admin_model->update_data('survey_table',array('po_id'=>$insert_id_po,'po_current_status'=>'1'),array('st_id'=>$survey_id));
	}
	
	$mail_data=array(
				'username'=>'advertising',
				'user_mail'=>'advertising@birigroup.com',
				'department'=>'Traffic Sign',
				'order_number'=>$insert_id_po,
				'order_from'=>$this->session->userdata['user']['username'],
			);
	if(empty($po_type))
	{
		$mail_sts_po=send_user_mail($mail_data);
	}
	else
	{
		$mail_sts_po=send_user_mail($mail_data,'edited');
	}
			
	if(!empty($mail_sts_po))////change this to checking mail data
	{
		$this->session->set_flashdata('success', 'PO generated Successfully ');
		redirect('list-survey-data');
	}
	else
	{
		$this->session->set_flashdata('errors', 'PO mail sending failed ');
		redirect('list-survey-data');
	}
}
else
{
	$this->session->set_flashdata('errors', 'Unable to send for Production. Reason: Zero quantities found.');
	redirect('list-survey-data');
}	

}

function add_survey_prd_quantities($survey_id)
{
	$data['survey_result']=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));
	$data['prd_set_details']=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$survey_id));	
	
	foreach($data['prd_set_details'] as $index1=>$psr)
	{
		$prd_ids_explode=explode(',', $psr->psd_prd_id);
		foreach($prd_ids_explode as $q)
				{
					$data['prd_ids_1'][$index1][]=$this->tm->get_data('products',array('pid'=>$q));
				}
	}
			
	$single_prd_ids=explode(',',$data['survey_result'][0]->st_single_prds);	
	if(!empty($single_prd_ids))
	{
	foreach($single_prd_ids as $q1)
				{
					$data['prd_ids_2'][]=$this->tm->get_data('products',array('pid'=>$q1));
				}
	}
	else
	{
		$data['prd_ids_2']='0';
	}				

	$po_prd_ids=explode('|#|',$data['survey_result'][0]->st_po_prd_ids);	
				foreach($po_prd_ids as $q2)
				{
					$data['prd_ids_3'][]=$this->tm->get_data('products',array('pid'=>$q2));
				}	
	$data['prd_po_qty']=explode('|#|',$data['survey_result'][0]->st_po_prd_qtys);	
		$data['clearance_level']=$data['survey_result'][0]->st_clearance;
			$data['underground_pipe']=$data['survey_result'][0]->st_underground_pipe;
			$data['edit_survey_id']=$survey_id;
			//pre_list($data['underground_pipe']);
$this->load->view('admin/production/edit_survey_quantity',$data);
}

function submit_edit_qty_survey()
{
	$prd_sets_id=$this->input->post('prd_set_ids[]');
	$qnty_prd_sets=$this->input->post('new_quantity_prd_set[]');
	$pipe_sets_heights=$this->input->post('prd_set_pipe_hgt[]');
	
	$edit_survey_id=$this->input->post('edit_survey_id');
	$qty_prd_single=implode(',',$this->input->post('prd_single_quantity_new[]'));
	$pipe_single_height=implode(',',$this->input->post('single_pipe_hgt[]'));

	$this->Admin_model->update_data('survey_table',array('st_single_prd_qtys'=>$qty_prd_single,'st_single_pipe_hgt'=>$pipe_single_height,'st_single_pipe_qty'=>$qty_prd_single),array('st_id'=>$edit_survey_id));
	 $activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Survey - edit quantity',
			'act_status'=>'Survey single products quantity added/edited ',
			'act_survey_id'=>$edit_survey_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
		);
		$this->Admin_model->insert_data('activities',$activity_data);


	foreach($prd_sets_id as $index=>$psd)
	{
	$this->Admin_model->update_data('product_set_data',array('psd_prd_qty'=>$qnty_prd_sets[$index],'psd_pipe_hgt'=>$pipe_sets_heights[$index],'psd_pipe_qnty'=>$qnty_prd_sets[$index]),array('psd_id'=>$psd));

		 $activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Survey product set - edit quantity',
			'act_status'=>'Product set with id '.$psd.' added/edited quantity',
			'act_survey_id'=>$edit_survey_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'

		);
		$this->Admin_model->insert_data('activities',$activity_data);
	}

$this->session->set_flashdata('success', 'Quantity edited for survey successfully ');
		redirect('list-survey-data');

}

function delete_survey($survey_id)
{
	if(logged_in())
	{
		$this->Admin_model->update_data('survey_table',array('st_sts'=>'0'),array('st_id'=>$survey_id));

		$activity_data=array(
			'act_user'=>$this->session->userdata['user']['username'],
			'act_function'=>'Survey - deleted ',
			'act_status'=>'Survey details deleted',
			'act_survey_id'=>$survey_id,
			'act_date'=>get_date(),
			'act_time'=>get_time(),
			'act_date_time'=>get_date_time(),
			'act_notification_sts'=>'1',
			'act_notification_sts_mngmnt'=>'1'
				);
		$this->Admin_model->insert_data('activities',$activity_data);

 		$this->session->set_flashdata('success', 'Survey data removed successfully ');
 		redirect('list-survey-data');
	}
}


function survey_history($survey_id=null)
{
	if(logged_in())
	{
		if(!empty($survey_id))
		{
			$data['result']=$this->Admin_model->get_data('activities',array('act_survey_id'=>$survey_id));
			$data['page']='';
			$this->load->view('admin/production/survey_history',$data);
		}
	}
	
}

function add_customer_pricing($cust_id=null)
{
	if(logged_in())
	{


   $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
			 $cred_count=count($page_cred);


	        for($i=0;$i<$cred_count;$i++)
	        {
	         	if ((($page_cred[$i]=='add-survey-customer-pricing')||($this ->session->userdata['user']['main_dept'])=="Main"))
	         	{
		           $excist=true;
	               $i=$cred_count;
	         	}	

	           else
	            	{$excist=false;}
   
	        }
	       if ($excist) {

	$data['customers']=$this->Admin_model->get_data('sales_customer_entry',array('sca_status'=>'1'));
	$data['products']=$this->tm->get_data('products',array('p_sts'=>'1'));

	if(!empty($cust_id))
	{
		$data['result']=$this->Admin_model->get_data('survey_customer_pricing',array('scp_sts'=>'1','scp_id'=>$cust_id));
		if(!empty($data['result']))
		{
			foreach ($data['result'] as $key => $value) 
			{
				$prd_ids=explode('|#|',$value->scp_prd_ids);
				foreach($prd_ids as $pi)
				{
					$data['prds_edit'][$key][]=$this->tm->get_data('products',array('pid'=>$pi));
				}

				$data['customer_data'][]=$this->Admin_model->get_data('sales_customer_entry',array('sca_id'=>$value->scp_cust_id));
			}
		}
	}
	$this->load->view('admin/production/add_customer_pricing',$data);

 }

      else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		}  


	}
}


function submit_cust_pricing()
{
	$edit_id=$this->input->post('edit_survey_price_id');
	$data=array(
	'scp_cust_id'=>$this->input->post('cust_id'),
	'scp_user_session'=>$this->session->userdata['user']['username'],
	'scp_prd_ids'=>$this->input->post('prdids'),
	'scp_prd_price'=>$this->input->post('prices'),
	'scp_prd_extra_note'=>$this->input->post('extra_detail'),
	'scp_sts'=>'1'
	);
	//pre_list($data);
	if(empty($edit_id))
	{
		$this->Admin_model->insert_data('survey_customer_pricing',$data);	
	$this->session->set_flashdata('success', 'Data Successfully inserted');
	redirect('add-survey-customer-pricing');
	}
	else 
	{
			$this->Admin_model->update_data('survey_customer_pricing',$data,array('scp_id'=>$edit_id));	
	$this->session->set_flashdata('success', 'Data Successfully updated');
	redirect('list-survey-customer-pricing');
	}	
	
}

function delete_cust_pricing($cust_id)
{
$this->Admin_model->update_data('survey_customer_pricing',array('scp_sts'=>'0'),array('scp_id'=>$cust_id));
$this->session->set_flashdata('success', 'Data Successfully removed');
		
	redirect('add-survey-customer-pricing');
}

function list_customer_pricing()
{

	 if(logged_in())
	{
        $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


      for($i=0;$i<$cred_count;$i++)
       {
        if ($page_cred[$i]=='list-survey-customer-pricing')
         {
         	$excist=true;
            $i=$cred_count;
       	}	

         else
          	{$excist=false;}

         }
       if ($excist) {



		$data['result']=$this->Admin_model->get_data('survey_customer_pricing',array('scp_sts'=>'1'));
		if(!empty($data['result']))
		{
			foreach ($data['result'] as $key => $value) 
			{
				$prd_ids=explode('|#|',$value->scp_prd_ids);
				foreach($prd_ids as $pi)
				{
					$data['prds'][$key][]=$this->tm->get_data('products',array('pid'=>$pi));
				}

				$data['customer_data'][]=$this->Admin_model->get_data('sales_customer_entry',array('sca_id'=>$value->scp_cust_id));
			}
		}
$this->load->view('admin/production/list_customer_pricing',$data);


}

else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


function survey_bom()
{



if(logged_in())
	{
  $page_cred=explode(',', $this->session->userdata['user']['pages_permission']);
		$cred_count=count($page_cred);


         for($i=0;$i<$cred_count;$i++)
         {
         	if ($page_cred[$i]=='list-jobs-applied')
         	{
         		$excist=true;
               $i=$cred_count;
         	}	

            else
            	{$excist=false;}

         }
       if ($excist) {

	$data['result']=$this->Admin_model->get_data('survey_table',array('st_sts'=>'1','st_po_prd_qtys !='=>''),'','','st_id','DESC');
	foreach($data['result'] as $index1=>$sr)
			{
				$prd_ids_explode=explode('|#|',$sr->st_po_prd_ids);
				foreach($prd_ids_explode as $q)
				{
					$data['prd_ids'][$index1][$index1][]=$this->tm->get_data('products',array('pid'=>$q));
				}
			}
		//	pre_list($data['prd_ids']);
	$this->load->view('admin/production/list_all_survey_bom',$data);

   }

	else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 


}


else{
			//echo false;
			 $this->session->unset_userdata('user', null);
	        	redirect('login','refersh');
		} 

}


function show_bom_adv($survey_id)
{
	$data['survey_id']=$survey_id;
	$survey_data=$this->Admin_model->get_data('survey_table',array('st_sts'=>'1','st_id'=>$survey_id));
	$prd_ids_explode=explode('|#|',$survey_data[0]->st_po_prd_ids);
	$data['survey_qntys']=explode('|#|', $survey_data[0]->st_po_prd_qtys);
				foreach($prd_ids_explode as $q)
				{
					$prd_ids[]=$this->tm->get_data('products',array('pid'=>$q));
				}

			foreach($prd_ids as $pid)
			{
				$prd_focus_id[]=$pid[0]->prod_id_focus;
				$prd_focus_names[]=$pid[0]->pname;
				$prd_focus_codes[]=$pid[0]->pcode;
				$data['pnames'][]=$pid[0]->pname;
				$data['bom'][]=$this->tm->get_data('bom_data',array('bom_sts'=>'1','bom_focus_id'=>$pid[0]->prod_id_focus,'bom_type'=>'1'));
			}	

			foreach($data['bom'] as $bom)
			{
				if(!empty($bom))
				{
					$data['bom_data'][]=$this->tm->get_bom_prd_data(array('bom_sts'=>'1','bom_parent_id'=>$bom[0]->bom_parent_id));
				}
				else
				{
					$data['bom_data'][]='0';
				}
			}
		
	$this->load->view('admin/production/show_bom_sts_adv',$data);
}

function return_installation_items($survey_id)
{
	$data['survey_details']=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));
	$data['prd_set_details']=$this->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$data['survey_details'][0]->st_id));

		foreach($data['prd_set_details'] as $index1=>$psr)
			{
				$prd_ids_explode=explode(',', $psr->psd_prd_id);
				$arrange_pos=explode(',', $psr->psd_arrange_position);
				foreach($prd_ids_explode as $index11=>$q)
				{
				$data['prd_ids_1'][$index1][$arrange_pos[$index11]]=$this->tm->get_data('products',array('pid'=>$q));
				}
			}
					
			$single_prd_ids=explode(',',$data['survey_details'][0]->st_single_prds);	
			if(!empty($single_prd_ids))
			{
			foreach($single_prd_ids as $q1)
				{
					$data['prd_ids_2'][]=$this->tm->get_data('products',array('pid'=>$q1));
				}
			}
			else
			{
				$data['prd_ids_2']='0';
			}	
	$data['installation_table_details']=$this->Admin_model->get_data('installation_details',array('insd_survey_id'=>$data['survey_details'][0]->st_id),'1','','insd_id','DESC');
	$this->load->view('admin/production/return_installation_items',$data);
}


function submit_return_installation()
{
$survey_id=$this->input->post('edit_survey_id');

$prd_set_ids=$this->input->post('prd_set_ids[]');
$single_prd_ids=$this->input->post('prd_single_id[]');

$prd_set_org_qnty=$this->input->post('prd_set_org_qnty[]');
$prd_set_return_qnty=$this->input->post('return_prd_set_qnty[]');

$prd_single_org_qnty=$this->input->post('single_prd_org_qnty[]');
$prd_single_return_qnty=$this->input->post('return_single_prd_qnty[]');

$installation_table_details=$this->Admin_model->get_data('installation_details',array('insd_survey_id'=>$survey_id),'1','','insd_id','DESC');
if(!empty($installation_table_details))
{
	$installation_detail_id=$installation_table_details[0]->insd_id;
	$prd_set_org_qnty_installetion=explode(',',$installation_table_details[0]->insd_prd_set_org_qnty);
	$prd_set_remiaining_qnty_installetion=explode(',',$installation_table_details[0]->insd_prd_set_remaining_qnty);
	$prd_single_qnty_org_installetion=explode(',',$installation_table_details[0]->insd_prd_single_org_qnty);
	$prd_single_qnty_remaining_installetion=explode(',',$installation_table_details[0]->insd_prd_single_remaining_qnty);
}

////////////*-------------- here starts for updating installation table details--------------------------*/////////////
foreach($prd_set_ids as $index1=>$pid)
{
	if(array_filter($prd_single_qnty_org_installetion))/////only if there is some non-zero values inside the array
	{
		if(!empty($prd_set_return_qnty[$index1]))
		{
			$new_prd_set[$index1][]=$prd_set_org_qnty[$index1]-$prd_set_return_qnty[$index1];
			$new_prd_set_org_qnty_installetion[]=$prd_set_org_qnty_installetion[$index1]-$prd_set_return_qnty[$index1];
			$new_prd_set_remianing_qnty[]=$prd_set_remiaining_qnty_installetion[$index1]-$prd_set_return_qnty[$index1];
		}
		else
		{
			$new_prd_set[$index1][]=$prd_set_org_qnty[$index1];
			$new_prd_set_org_qnty_installetion[]=$prd_set_org_qnty_installetion[$index1];
			$new_prd_set_remianing_qnty[]=$prd_set_remiaining_qnty_installetion[$index1];
		}
	}	
}

foreach($single_prd_ids as $index2=>$sp)
{
	if(array_filter($prd_single_qnty_org_installetion))/////only if there is some non-zero values inside the array
	{
		if(!empty($prd_single_return_qnty[$index2]))
		{
			$new_prd_single_set[$index2][]=$prd_single_org_qnty[$index2]-$prd_single_return_qnty[$index2];
			$new_prd_single_org_qnty_installetion[]=$prd_single_qnty_org_installetion[$index2]-$prd_single_return_qnty[$index2];
			$new_prd_single_remianing_qnty[]=$prd_single_qnty_remaining_installetion[$index2]-$prd_single_return_qnty[$index2];
		}
		else
		{
			$new_prd_single_set[$index2][]=$prd_single_org_qnty[$index2];
			$new_prd_single_org_qnty_installetion[]=$prd_single_qnty_org_installetion[$index2];
			$new_prd_single_remianing_qnty[]=$prd_single_qnty_remaining_installetion[$index2];
		}
	}
}

if(!empty($new_prd_set_org_qnty_installetion))
{
$this->Admin_model->update_data('installation_details',array('insd_prd_set_org_qnty'=>implode(',',$new_prd_set_org_qnty_installetion),'insd_prd_set_remaining_qnty'=>implode(',', $new_prd_set_remianing_qnty)),array('insd_id'=>$installation_detail_id));
}

if(!empty($new_prd_single_org_qnty_installetion))
{
$this->Admin_model->update_data('installation_details',array('insd_prd_single_org_qnty'=>implode(',',$new_prd_single_org_qnty_installetion),'insd_prd_single_remaining_qnty'=>implode(',',$new_prd_single_remianing_qnty)),array('insd_id'=>$installation_detail_id));
}

////////////*-------------- here ends for updating installation table details--------------------------*/////////////
$survey_details=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));

$this->Admin_model->update_data('survey_table',array('st_single_prd_qtys'=>implode(',',$new_prd_single_set[0]),'st_single_pipe_qty'=>implode(',',$new_prd_single_set[0])),array('st_id'=>$survey_details[0]->st_id));

foreach($prd_set_ids as $index1=>$pid)
{
$this->Admin_model->update_data('product_set_data',array('psd_prd_qty'=>$new_prd_set[$index1][0],'psd_pipe_qnty'=>$new_prd_set[$index1][0]),array('psd_id'=>$pid));
}

$data=array(
'ri_org_qnty'=>implode(',',$prd_set_org_qnty),
'ri_return_qnty'=>implode(',',$prd_set_return_qnty),
'ri_single_qty_org'=>implode(',',$prd_single_org_qnty),
'ri_single_qty_return'=>implode(',',$prd_single_return_qnty),
'ri_prd_set_id'=>implode(',',$prd_set_ids),
'ri_prd_single_id'=>implode(',',$single_prd_ids),
'ri_survey_id'=>$survey_id,
'ri_sts'=>'1',
); 
// pre_list($data);
$this->Admin_model->insert_data('return_installation');
$this->session->set_flashdata('success', 'Item Successfully returned');
	redirect('list-installations');
}

function remove_item_prd_set()
{
	$survey_id=$this->input->post('survey_id');
	$prd_set_id=$this->input->post('prd_set_id');
	$item_id=$this->input->post('item_id');

	$prd_set_data=$this->Admin_model->get_data('product_set_data',array('psd_id'=>$prd_set_id,'psd_survey_id'=>$survey_id));
	$prd_set_item_ids=explode(',', $prd_set_data[0]->psd_prd_id);
	if(in_array($item_id, $prd_set_item_ids))
	{
		$array_key_value=array_search($item_id, $prd_set_item_ids);
		unset($prd_set_item_ids[$array_key_value]);
	}

	$this->Admin_model->update_data('product_set_data',array('psd_prd_id'=>implode(',',$prd_set_item_ids)),array('psd_id'=>$prd_set_id,'psd_survey_id'=>$survey_id));
	echo true;
	
}

function remove_prd_set_data()
{
	$survey_id=$this->input->post('survey_id');
	$prd_set_id=$this->input->post('prd_set_id');
	$this->Admin_model->delete_data('product_set_data',array('psd_survey_id'=>$survey_id,'psd_id'=>$prd_set_id));
echo true;
}

function remove_prd_single_data()
{
	$survey_id=$this->input->post('survey_id');
	$prd_single_id=$this->input->post('prd_single_id');

	$survey_details=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));
	$item_ids=explode(',', $survey_details[0]->st_single_prds);

	if(in_array($prd_single_id, $item_ids))
	{
		$array_position=array_search($prd_single_id, $item_ids);

		if(!empty($survey_details[0]->st_single_prd_qtys))
		{
			$quantity_values=explode(',', $survey_details[0]->st_single_prd_qtys);
			unset($quantity_values[$array_position]);
			$final_single_qty=implode(',', $quantity_values);
		}
		else
		{
			$final_single_qty='';
		}

		if(!empty($survey_details[0]->st_single_pipe_hgt))
		{
			$pipe_hgt=explode(',', $survey_details[0]->st_single_pipe_hgt);
			unset($pipe_hgt[$array_position]);
			$final_pipe_hgt=implode(',',$pipe_hgt);
		}
		else
		{
			$final_pipe_hgt='';
		}

		if(!empty($survey_details[0]->st_single_pipe_qty))
		{
			$pipe_qty=explode(',', $survey_details[0]->st_single_pipe_qty);
			unset($pipe_qty[$array_position]);
			$final_pipe_qty=implode(',',$pipe_qty);
		}
		else
		{
			$final_pipe_qty='';
		}

		if(!empty($survey_details[0]->st_single_prd_serial_no))
		{
			$serial_no=explode(',', $survey_details[0]->st_single_prd_serial_no);
			unset($serial_no[$array_position]);
			$final_serial_no=implode(',',$serial_no);
		}
		else
		{
			$final_serial_no='';
		}

		if(!empty($survey_details[0]->st_single_prd_map_cordinates))
		{
			$map_cordinates=explode('$#$', $survey_details[0]->st_single_prd_map_cordinates);
			unset($map_cordinates[$array_position]);
			$final_map_cordinate=implode('$#$',$map_cordinates);
		}
		else
		{
			$final_map_cordinate='';
		}

		unset($item_ids[$array_position]);
		$data_update=array(
			'st_single_prds'=>implode(',',$item_ids),
			'st_single_prd_qtys'=>$final_single_qty,
			'st_single_pipe_hgt'=>$final_pipe_hgt,
			'st_single_pipe_qty'=>$final_pipe_qty,
			'st_single_prd_serial_no'=>$final_serial_no,
			'st_single_prd_map_cordinates'=>$final_map_cordinate,
		);
		$this->Admin_model->update_data('survey_table',$data_update,array('st_id'=>$survey_id) );
		echo true;
	}

}

function create_new_item_sets($req_type,$survey_id)
{
	$data['req_type']=$req_type;
	$data['result']=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));
$prd_ids=explode('|#|',$data['result'][0]->st_po_prd_ids);
$single_itms_created=explode(',',$data['result'][0]->st_single_prds);
if($req_type=='item_single')
{
	foreach($prd_ids as $pid)
	{
		 if(!in_array($pid,$single_itms_created))
		 {
			$data['product_ids'][]=$this->tm->get_data('products',array('pid'=>$pid));
		 }
	}
	if(!empty($data['product_ids']))
	{
		$this->load->view('admin/production/create_new_item_sets',$data);
	}
	else
	{
		$this->session->set_flashdata('errors', 'No single items left to create');
		redirect('show-prd-sets/'.$survey_id);		
	}	 
}
else
{
	foreach($prd_ids as $pid)
	{
		$data['product_ids'][]=$this->tm->get_data('products',array('pid'=>$pid));
	}
$this->load->view('admin/production/create_new_item_sets',$data);
}

}

function submit_create_prd_sets_details()
{
	$survey_id=$this->input->post('survey_id');
	$req_type=$this->input->post('req_type');

	if($req_type=='item_set')
	{
		if(!empty($this->input->post('actual_prd_sets')))
			{
				$prd_sets=array_filter(explode('|$|',$this->input->post('actual_prd_sets')));
				foreach($prd_sets as $ps)
				{
					$data_prd_set=array(
						'psd_survey_id'=>$survey_id,
						'psd_user_created'=>$this->session->userdata['user']['username'],
						'psd_prd_id'=>$ps,
						'psd_sts'=>'1'
					);
					$insert_id2=$this->Admin_model->insert_data('product_set_data',$data_prd_set);
					$activity_data=array(
						'act_user'=>$this->session->userdata['user']['username'],
						'act_function'=>'survey Product set created',
						'act_status'=>'Product set with id '.$insert_id2.' created',
						'act_survey_id'=>$survey_id,
						'act_date'=>get_date(),
						'act_time'=>get_time(),
						'act_date_time'=>get_date_time(),
						'act_notification_sts'=>'1',
						'act_notification_sts_mngmnt'=>'1'
					);
					$this->Admin_model->insert_data('activities',$activity_data);
				}
			}
	$this->session->set_flashdata('success', 'New Product Sets Created Successfully');
		redirect('show-prd-sets/'.$survey_id);		
	}
	else
	{
		$single_prd_ids=explode(',',$this->input->post('actual_single_prds'));
		//print_r($single_prd_ids);
		$array_search = array_search('undefined',$single_prd_ids);
		if($array_search !== FALSE){
		    unset($single_prd_ids[$array_search]);
		}
		$survey_data=$this->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));

		if(!empty($survey_data[0]->st_single_prds))
		{
		$single_itms_created=explode(',',$survey_data[0]->st_single_prds);
		$merged_array=array_merge($single_itms_created, $single_prd_ids);
		$new_single_prds_array=implode(',',$merged_array);
		}
		else
		{
				$new_single_prds_array=implode(',',$single_prd_ids); 
		}
$this->Admin_model->update_data('survey_table',array('st_single_prds'=>$new_single_prds_array),array('st_id'=>$survey_id));
	$this->session->set_flashdata('success', 'New Product Singles Created Successfully');
	 redirect('show-prd-sets/'.$survey_id);		
	}
}




















}