<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 
 include_once APPPATH.'third_party/pdf/mPDF/mpdf.php';
 
class M2_pdf {
 
    public $param;
    public $pdf;
 //'utf-8'
    public function __construct($param = '"utf-8","L","","",10,10,10,10,6,3')
    {
        $this->param =$param;
       	$this->pdf = new mPDF($this->param);
       	 $this->pdf->autoScriptToLang = true;
		$this->pdf->autoLangToFont = true;
        //$this->pdf = new mPDF('c', 'A4-L'); 
    }
	
}
