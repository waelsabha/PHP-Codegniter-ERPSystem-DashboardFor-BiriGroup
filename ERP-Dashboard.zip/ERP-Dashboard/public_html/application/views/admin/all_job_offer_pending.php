<section class="panel">
<header class="panel-heading">

<h2 class="panel-title"><?php echo $this->lang->line('New Job Offer Pending'); ?></h2>
<p class="panel-subtitle">All job offer pending</p>
</header>
<div class="panel-body">

<div class="data_result">

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
  <th ></th>
<th>Recipt Name</th>
<th>Recipt Name Arabic</th>

<th>Branch where wrork</th>
<th>Position Name </th>
<th>Working Hours</th>
<th>Total Salary</th>
<th>probation_period</th>


<th><?php echo $this->lang->line('Action'); ?></th>

</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($pending_offer_list))
{
  foreach($pending_offer_list as $indexr=>$ofrpn)
  {
       
    //$return_date=$rt->pr_date;

//print_r($final_date);

//$prodcode=$ofrpn->pr_prd_code;

//?>
<tr class="gradeX">
      <td width='2%'><?php echo $i++;?></td>
      <td><?php echo $ofrpn->jo_recipt_name;?></td>
      
      <td><?php echo $ofrpn->jo_recipt_name_ar;?></td>
      <td><?php echo $ofrpn->mcomp_name;?></td>
      <td><?php echo $ofrpn->position_name;?></td>
      <td><?php echo $ofrpn->jo_working_hours;?></td>
      <td><?php echo $ofrpn->jo_total_salary;?></td>
      <td><?php echo $ofrpn->probation_period;?></td>
     
       <td>
         
 
       Pending <br/>
       
      <button type="button" class="btn btn-sm btn-primary" onclick="approve_job_offer(<?php echo $ofrpn->job_id;?>)">Aprove Now(fully)</button> 
     <?php
     }
  }

  
  else{
    echo('Error Result');
  }
 ?>

 
   </td>



  </tr>
</tbody>
</table>
</div>


</div>
</section>