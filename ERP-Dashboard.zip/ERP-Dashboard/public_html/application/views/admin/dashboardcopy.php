<!doctype html>
<html class="fixed">


<head>

<?php $this->load->view('admin/head');?>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/morris/morris.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
  .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

  .datetimepicker4{z-index:18000 !important}
</style>
</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Dashboard</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Dashboard</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>


<div class="row">
  
<div class="col-md-12 col-lg-12 col-xl-12" style="padding-bottom: 2%;">

 <div class="btn-group pull-right" >
<button type="button" class="btn btn-primary"  onclick="this_month();">This month</button>
<button type="button" class="btn btn-default" onclick="location.reload();">This Financial Year |</button>
<button type="button" class="btn btn-primary" onclick="this_today();">Today</button>
</div>
</div>


<div class="col-md-12 col-lg-12 col-xl-12" style="padding-bottom: 2%;">
 <div class="btn-group pull-left" >
<p> Select date range. Select start date to end date</p>
<div class="input-daterange input-group" data-plugin-datepicker="">
    <span class="input-group-addon">
    <i class="fa fa-calendar"></i>
    </span>
    <input type="text" class="form-control" name="start_date_rng">
    <span class="input-group-addon">to</span>
    <input type="text" class="form-control" name="end_date_rng">
</div>

<button type="button" class="btn btn-primary"  onclick="this_range();">Submit</button>
</div>

<div class="col-md-12 col-lg-12 col-xl-12" style="padding-bottom: 2%;">
<?php
if(($this ->session->userdata['user']['role'])=="1")
{?>
 <div class="pull-left" >

<a href="<?php echo base_url('list_pending_tx');?>" type="button" class="mb-xs mt-xs mr-xs btn btn-lg btn-danger">Transaction pending for approval : <?php if(!empty($count_pending_tx))
  {echo $count_pending_tx;};?> - Click Here</a>

</div>

<?php
}?>
</div>

</div>
</div>

<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg">Total bank and cash balances 
<?php
$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp); //adjust the object to correct timestamp
// echo $dt->format('Y/m/d H:i:s');
//echo 
?>
    <span id="bank_bal_date">from <?php echo $dt->format('Y').'-01-01';?> to <?php echo $dt->format('Y-m-d');?>  </span></h5>
<div class="row">
<div class="col-md-6 col-xl-6">
<section class="panel">
<div class="panel-body bg-primary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Bank Balance</h4>
<div class="info">
<strong class="amount" id="totl_bnk_bal">
  <!--   number_format((float)$foo, 2, '.', ''); -->
    <?php echo number_format((float)$total_bank_bal, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-6 col-xl-6">
<section class="panel">
<div class="panel-body bg-secondary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Cash Balance</h4>
<div class="info">
<strong class="amount" id="totl_cash_bal"><?php echo 
number_format((float)$total_cash_bal, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>


</div>
</div>

</div>
<?php
if(($this ->session->userdata['user']['role'])=="1")
{?>
<?php $this->load->view('admin/pivot_data',$cash_entire); ?>
<?php
}
?>
<?php $this->load->view('admin/table_data',$cash_entire); ?>

<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
  
<div class="col-md-6 col-lg-6 col-xl-6">
 <h4>Approved/Confirmed<br/><small>As per the transaction that are only approved,excluding expected</small></h4>
     
<div class="row">
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-primary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-primary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">ADIB-BBMS</h4>
<div class="info">
<strong class="amount" id="bbms_approved"><?php echo 
number_format((float)$bbms_result_approved, 2, '.', '');?></strong>

</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-secondary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-secondary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">ADIB-Factory</h4>
<div class="info">
<strong class="amount" id="fact_approved"><?php echo 
number_format((float)$fact_result_approved, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-tertiary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-tertiary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">ENBD</h4>
<div class="info">
<strong class="amount" id="enbd_approved"><?php echo 
number_format((float)$ENBD_approved, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-quartenary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-quartenary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">EI Bank</h4>
<div class="info">
<strong class="amount" id="ei_approved"><?php echo 
number_format((float)$ei_bank_approved, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-primary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-primary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Other Bank</h4>
<div class="info">
<strong class="amount" id="other_bank_approved"><?php echo 
number_format((float)$others_approved, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-secondary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-secondary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Cash Mr.Bachir Book</h4>
<div class="info">
<strong class="amount" id="bachir_approved"><?php echo 
number_format((float)$cash_bachir_approved, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-tertiary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-tertiary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Cash Garhoud</h4>
<div class="info">
<strong class="amount" id="garhoud_approved"><?php echo 
number_format((float)$Garhoud_approved, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-quartenary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-quartenary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Cash Factory</h4>
<div class="info">
<strong class="amount" id="cash_fact_approved"><?php echo 
number_format((float)$cash_fact_approved, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
</div>
</div>

<div class="col-md-6 col-lg-6 col-xl-6">
    <h4>Expected Transcations<br/><small>As per all the transaction entries,including expected</small></h4> 
<div class="row">
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-primary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-primary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">ADIB BBMS</h4>
<div class="info">
<strong class="amount" id="bbms"><?php echo 
number_format((float)$bbms_result, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-secondary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-secondary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">ADIB Factory</h4>
<div class="info">
<strong class="amount" id="fact"><?php echo 
number_format((float)$fact_result, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-tertiary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-tertiary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">ENBD</h4>
<div class="info">
<strong class="amount" id="enbd"><?php echo 
number_format((float)$ENBD, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-quartenary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-quartenary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">EI Bank</h4>
<div class="info">
<strong class="amount" id="ei"><?php echo 
number_format((float)$ei_bank, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-primary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-primary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Other Bank</h4>
<div class="info">
<strong class="amount" id="other_bank"><?php echo 
number_format((float)$others, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-secondary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-secondary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Cash Mr.Bachir Book</h4>
<div class="info">
<strong class="amount" id="bachir"><?php echo 
number_format((float)$cash_bachir, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-tertiary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-tertiary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Cash Garhoud</h4>
<div class="info">
<strong class="amount" id="garhoud"><?php echo 
number_format((float)$Garhoud, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-12 col-lg-6 col-xl-6">
<section class="panel panel-featured-left panel-featured-quartenary">
<div class="panel-body">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon bg-quartenary">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Cash Factory</h4>
<div class="info">
<strong class="amount" id="cash_fact"><?php echo 
number_format((float)$cash_fact, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
</div>
</div>

</div>

</div>
<!--closing row-->

<!-- <div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<div class="panel-body">

<div id="container" style="min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>

</div>
</div>
</div> -->


<div class="row">

<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg">Category based balances <span id="cat_bal_date">from <?php echo $dt->format('Y').'-01-01';?> to <?php echo $dt->format('Y-m-d');?>  </span></h5></h5>

<div class="col-md-12 col-lg-12 col-xl-12">

<div class="panel-body">
    <div class="col-md-12 col-xl-12">
<section class="panel">
<div class="panel-body bg-secondary">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total category balance</h4>
<div class="info">
<strong class="amount" id="total_cat_bal"><?php echo 
number_format((float)$total_cat, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
</div>

</div>

<div class="col-md-12 col-lg-12 col-xl-12">

<div class="panel-body">
<div id="container2" style="min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>
</div>
</div>


<div class="row">

<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-secondary">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Sales</h4>
<div class="info">
<strong class="amount" id="sales"><?php echo 
number_format((float)$sales, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-tertiary">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Shipping</h4>
<div class="info">
<strong class="amount" id="ship"><?php echo 
number_format((float)$shipping, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>

<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-primary">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">General Expenses</h4>
<div class="info">
<strong class="amount" id="gnrl_exp"><?php echo 
number_format((float)$gnrl, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>

<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-quartenary">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Salaries</h4>
<div class="info">
<strong class="amount" id="salary"><?php echo 
number_format((float)$salaries, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>

<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-secondary">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Rent</h4>
<div class="info">
<strong class="amount" id="rent"><?php echo 
number_format((float)$rent, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>

<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-primary">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Others</h4>
<div class="info">
<strong class="amount" id="other_cat"><?php echo 
number_format((float)$other_cat, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>


<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-quartenary">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Raw material purchases</h4>
<div class="info">
<strong class="amount" id="raw_mat"><?php echo 
number_format((float)$raw_mat, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>

<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-tertiary">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Import purchases </h4>
<div class="info">
<strong class="amount" id="import"><?php echo 
number_format((float)$import, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>

<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-secondary">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Personal Accounts</h4>
<div class="info">
<strong class="amount" id="export"><?php echo 
number_format((float)$export, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>



</div>
</div>

</div>
<!--close the row-div here, me added div-->


<!--close the div here, me added div-->



<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Coming Payment (Based on We Spend)</h2>

</header>
<div class="panel-body">
    
     <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default3">
<thead>
<tr>
    <th ></th>
<th>Category</th>
<th>Status</th>
<th>Bank</th>
<th>Date </th>
<th>Current Status</th> 
<th>Amount</th>
<th>Cash Mode </th>
<th>User Type</th>
<th>Description</th>
<!-- <th>Action</th> -->

</tr>
</thead>
<tbody>
<?php
$i=1;
foreach($cash_spend as $sx)
{
    if(!empty($sx->ae_time))
{
$convert=date("g:i A", strtotime($sx->ae_time));
//echo $convert;
}
    ?>
<tr class="gradeX">
<td><?php echo $i++;?></td>
<td><?php echo $sx->ae_cat;?></td>
<td><?php echo $sx->ae_sts;?></td>
<td><?php echo $sx->ae_bank;?></td>
<td><?php echo $sx->ae_date.' '.$convert;?></td>
<td><?php if($sx->ae_status_data=="2"){echo '<span class="pull-right label label-success">Success</span>';}else{echo '<span class="pull-right label label-warning">Pending</span>';};?></td>
<td><?php echo $sx->ae_amount;?></td>
<td><?php echo $sx->ae_cash_type;?></td>
<td><?php echo $sx->ae_user;?></td>
<td><?php echo word_limiter($sx->ae_desc,100);?></td>
<!-- <td></td> -->
</tr>

<?php 
}?>

</tbody>
</table>



</div>
</section>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Coming Cash (Based on We Received)</h2>

</header>
<div class="panel-body">
    
     <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default4">
<thead>
<tr>
    <th></th>
<th>Category</th>
<th>Status</th>
<th>Bank</th>
<th>Date </th>
<th>Current Status</th> 
<th>Amount</th>
<th>Cash Mode </th>
<th>User Type</th>
<th>Description</th>
<!-- <th>Action</th> -->

</tr>
</thead>
<tbody>
<?php
$i=1;
foreach($cash_received as $sx)
{
     if(!empty($sx->ae_time))
{
$convert=date("g:i A", strtotime($sx->ae_time));
//echo $convert;
}
    ?>
<tr class="gradeX">
<td><?php echo $i++;?></td>
<td><?php echo $sx->ae_cat;?></td>
<td><?php echo $sx->ae_sts;?></td>
<td><?php echo $sx->ae_bank;?></td>
<td><?php echo $sx->ae_date.' '.$convert;?></td>
<td><?php if($sx->ae_status_data=="2"){echo '<span class="pull-right label label-success">Success</span>';}else{echo '<span class="pull-right label label-warning">Pending</span>';};?></td>
<td><?php echo $sx->ae_amount;?></td>
<td><?php echo $sx->ae_cash_type;?></td>
<td><?php echo $sx->ae_user;?></td>
<td><?php echo word_limiter($sx->ae_desc,100);?></td>
<!-- <td></td> -->
</tr>

<?php 
}?>

</tbody>
</table>



</div>
</section>

</section>



</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-appear/jquery.appear.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<script type="text/javascript">
   

    $(document).ready(function()
    {
        
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
} );

           $('#datatable-default3').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
         "pageLength": 25,
    responsive: true,
     "scrollX": true,
} );
  $('#datatable-default4').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
         "pageLength": 25,
    responsive: true,
     "scrollX": true,
} );
  $('#datatable-default5').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
         "pageLength": 25,
    responsive: true,
     "scrollX": true,
} );

//          Highcharts.chart('container', {
//     chart: {
//         plotBackgroundColor: null,
//         plotBorderWidth: null,
//         plotShadow: false,
//         type: 'pie'
//     },
//     title: {
//         text: 'Total balance in Bank vs Cash'
//     },
//     tooltip: {
//         pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
//     },
//     plotOptions: {
//         pie: {
//             allowPointSelect: true,
//             cursor: 'pointer',
//             dataLabels: {
//                 enabled: false
//             },
//             showInLegend: true
//         }
//     },
//     series: [{
//         name: 'Total balance',
//         colorByPoint: true,
//         data: [{
//             name: 'Bank',
//             y: parseFloat(Math.abs(<?php echo number_format((float)$total_bank_bal, 2, '.', '');?>)),
//              positive:false
          
//         }, {
//             name: 'Cash',
//             y: parseFloat(Math.abs(<?php echo number_format((float)$total_cash_bal, 2, '.', '');?>)),
//              positive:false
//         }]
//     }]
// });   

             
    });

    $(document).ready(function()
    {
        Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Percentage of balance as per category'
    },
     tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
        
      },
   /* tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },*/
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
               
            },
            showInLegend: true
        }
    },
    series: [{
        name: 'Category',
        colorByPoint: true,
        data: [{
            name: 'Shipping',
            y: parseFloat(Math.abs(<?php echo number_format((float)$shipping, 2, '.', '');?>)),
            positive:false
          
        }, {
            name: 'Salaries',
            y: parseFloat(Math.abs(<?php echo number_format((float)$salaries, 2, '.', '');?>)),
            positive:false
        },{
            name: 'General Expenses',
            y: parseFloat(Math.abs(<?php echo number_format((float)$gnrl, 2, '.', '');?>)),
            positive:false
        }, {
            name: 'Rent',
            y: parseFloat(Math.abs(<?php echo number_format((float)$rent, 2, '.', '');?>)),
            positive:false
        }, {
            name: 'Import Expenses',
            y: parseFloat(Math.abs(<?php echo number_format((float)$import, 2, '.', '');?>)),
            positive:false
        }, {
            name: 'Personal Accounts',
            y: parseFloat(Math.abs(<?php echo number_format((float)$export, 2, '.', '');?>)),
            positive:false
        },
         {
            name: 'Raw material purchase',
            y: parseFloat(Math.abs(<?php echo number_format((float)$raw_mat, 2, '.', '');?>)),
            positive:false
        },{
            name: 'Other expenses',
            y: parseFloat(Math.abs(<?php echo number_format((float)$other_cat, 2, '.', '');?>)),
            positive:false
        }
        ]
    }]
});
    });

 
    function this_month()
    {
        jQuery.ajax({
                     url:"<?php echo base_url().'Dashboard_controller/this_month';?>",
                    type:"post",
                    // data:{"cash_type":cash_type},
                    success:function(result)
                    {
                        //console.log(result);   
                        var returnedData = JSON.parse(result);
                        $('#bbms').html(returnedData.bbms);
                        $('#fact').html(returnedData.factory);   
                        $('#enbd').html(returnedData.ENBD);
                        $('#ei').html(returnedData.ei_bank);
                        $('#other_bank').html(returnedData.other_bank);
                        $('#bachir').html(returnedData.cash_bachir); 
                        $('#garhoud').html(returnedData.Garhoud);
                        $('#cash_fact').html(returnedData.cash_fact);   

                        $('#totl_bnk_bal').html(returnedData.total_bank_bal);
                        $('#totl_cash_bal').html(returnedData.total_cash_bal);

                        $('#bbms_approved').html(returnedData.bbms_approved);
                    $('#fact_approved').html(returnedData.factory_approved);
                     $('#enbd_approved').html(returnedData.ENBD_approved);
                        $('#ei_approved').html(returnedData.ei_bank_approved);
                        $('#other_bank_approved').html(returnedData.other_bank_approved);
                        $('#bachir_approved').html(returnedData.cash_bachir_approved); 
                        $('#garhoud_approved').html(returnedData.Garhoud_approved);
                        $('#cash_fact_approved').html(returnedData.cash_fact_approved);

                        $('#total_cat_bal').html(returnedData.total_cat);

                        $('#sales').html(returnedData.sales); 
                        $('#ship').html(returnedData.shipping);   
                        $('#gnrl_exp').html(returnedData.gnrl);
                        $('#salary').html(returnedData.salary);
                        $('#rent').html(returnedData.rent);
                        $('#other_cat').html(returnedData.other); 
                        $('#raw_mat').html(returnedData.raw_mat);
                        $('#import').html(returnedData.import); 
                        $('#export').html(returnedData.export);
                        $('#bank_bal_date').html(returnedData.bank_date);
                        $('#cat_bal_date').html(returnedData.bank_date);


//                          Highcharts.chart('container', {
//     chart: {
//         plotBackgroundColor: null,
//         plotBorderWidth: null,
//         plotShadow: false,
//         type: 'pie'
//     },
//     title: {
//         text: 'Total balance in Bank vs Cash'
//     },
//     tooltip: {
//         pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
//     },
//     plotOptions: {
//         pie: {
//             allowPointSelect: true,
//             cursor: 'pointer',
//             dataLabels: {
//                 enabled: false
//             },
//             showInLegend: true
//         }
//     },
//     series: [{
//         name: 'Total balance',
//         colorByPoint: true,
//         data: [{
//             name: 'Bank',
//             y: parseFloat(Math.abs(returnedData.total_bank_bal)),
//              positive:false
          
//         }, {
//             name: 'Cash',
//             y: parseFloat(Math.abs(returnedData.total_cash_bal)),
//              positive:false
//         }]
//     }]
// });   

 Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Percentage of balance as per category'
    },
     tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
        
      },
   /* tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },*/
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
               
            },
            showInLegend: true
        }
    },
    series: [{
        name: 'Category',
        colorByPoint: true,
        data: [{
            name: 'Shipping',
            y: parseFloat(Math.abs(returnedData.shipping)),
            positive:false
          
        }, {
            name: 'Salaries',
            y: parseFloat(Math.abs(returnedData.salary)),
            positive:false
        },{
            name: 'General Expenses',
            y: parseFloat(Math.abs(returnedData.gnrl)),
            positive:false
        }, {
            name: 'Rent',
            y: parseFloat(Math.abs(returnedData.rent)),
            positive:false
        }, {
            name: 'Import Expenses',
            y: parseFloat(Math.abs(returnedData.import)),
            positive:false
        }, {
            name: 'Personal Accounts',
            y: parseFloat(Math.abs(returnedData.export)),
            positive:false
        },
         {
            name: 'Raw material purchase',
            y: parseFloat(Math.abs(returnedData.raw_mat)),
            positive:false
        },{
            name: 'Other expenses',
            y: parseFloat(Math.abs(returnedData.other)),
            positive:false
        }
        ]
    }]
});

                    }
                });

       
    }

    function this_today()
    {
       var today = new Date();
        jQuery.ajax({
                     url:"<?php echo base_url().'Dashboard_controller/this_month';?>",
                    type:"post",
                    data:{"date_data":today},
                    success:function(result)
                    {
                      // console.log(result);   
                        var returnedData = JSON.parse(result);
                        $('#bbms').html(returnedData.bbms);
                        $('#fact').html(returnedData.factory);   
                        $('#enbd').html(returnedData.ENBD);
                        $('#ei').html(returnedData.ei_bank);
                        $('#other_bank').html(returnedData.other_bank);
                        $('#bachir').html(returnedData.cash_bachir); 
                        $('#garhoud').html(returnedData.Garhoud); 
                        $('#cash_fact').html(returnedData.cash_fact);    

                        $('#totl_bnk_bal').html(returnedData.total_bank_bal);
                        $('#totl_cash_bal').html(returnedData.total_cash_bal);

                        $('#total_cat_bal').html(returnedData.total_cat);


                    $('#bbms_approved').html(returnedData.bbms_approved);
                    $('#fact_approved').html(returnedData.factory_approved);
                     $('#enbd_approved').html(returnedData.ENBD_approved);
                        $('#ei_approved').html(returnedData.ei_bank_approved);
                        $('#other_bank_approved').html(returnedData.other_bank_approved);
                        $('#bachir_approved').html(returnedData.cash_bachir_approved); 
                        $('#garhoud_approved').html(returnedData.Garhoud_approved);
                        $('#cash_fact_approved').html(returnedData.cash_fact_approved);

                        $('#sales').html(returnedData.sales); 
                        $('#ship').html(returnedData.shipping);   
                        $('#gnrl_exp').html(returnedData.gnrl);
                        $('#salary').html(returnedData.salary);
                        $('#rent').html(returnedData.rent);
                        $('#other_cat').html(returnedData.other); 
                        $('#raw_mat').html(returnedData.raw_mat);
                        $('#import').html(returnedData.import); 
                        $('#export').html(returnedData.export); 
                        $('#bank_bal_date').html(returnedData.bank_date);
                        $('#cat_bal_date').html(returnedData.bank_date);

//                               Highcharts.chart('container', {
//     chart: {
//         plotBackgroundColor: null,
//         plotBorderWidth: null,
//         plotShadow: false,
//         type: 'pie'
//     },
//     title: {
//         text: 'Total balance in Bank vs Cash'
//     },
//     tooltip: {
//         pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
//     },
//     plotOptions: {
//         pie: {
//             allowPointSelect: true,
//             cursor: 'pointer',
//             dataLabels: {
//                 enabled: false
//             },
//             showInLegend: true
//         }
//     },
//     series: [{
//         name: 'Total balance',
//         colorByPoint: true,
//         data: [{
//             name: 'Bank',
//             y: parseFloat(Math.abs(returnedData.total_bank_bal)),
//              positive:false
          
//         }, {
//             name: 'Cash',
//             y: parseFloat(Math.abs(returnedData.total_cash_bal)),
//              positive:false
//         }]
//     }]
// });   

     Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Percentage of balance as per category'
    },
     tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
        
      },
   /* tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },*/
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
               
            },
            showInLegend: true
        }
    },
    series: [{
        name: 'Category',
        colorByPoint: true,
        data: [{
            name: 'Shipping',
            y: parseFloat(Math.abs(returnedData.shipping)),
            positive:false
          
        }, {
            name: 'Salaries',
            y: parseFloat(Math.abs(returnedData.salary)),
            positive:false
        },{
            name: 'General Expenses',
            y: parseFloat(Math.abs(returnedData.gnrl)),
            positive:false
        }, {
            name: 'Rent',
            y: parseFloat(Math.abs(returnedData.rent)),
            positive:false
        }, {
            name: 'Import Expenses',
            y: parseFloat(Math.abs(returnedData.import)),
            positive:false
        }, {
            name: 'Personal Accounts',
            y: parseFloat(Math.abs(returnedData.export)),
            positive:false
        },
         {
            name: 'Raw material purchase',
            y: parseFloat(Math.abs(returnedData.raw_mat)),
            positive:false
        },{
            name: 'Other expenses',
            y: parseFloat(Math.abs(returnedData.other)),
            positive:false
        }
        ]
    }]
});                          

                    }
                });
       
    }

    function this_range()
    {
        var start_date=$('input[name=start_date_rng]').val();
        var end_date=$('input[name=end_date_rng]').val();

          jQuery.ajax({
                     url:"<?php echo base_url().'Dashboard_controller1/this_range_date';?>",
                    type:"post",
                    data:{"start_date_selected":start_date,"end_date_selected":end_date},
                    success:function(result)
                    {

                     // console.log(result);   
                        var returnedData = JSON.parse(result);
                        $('#bbms').html(returnedData.bbms);
                        $('#fact').html(returnedData.factory);   
                        $('#enbd').html(returnedData.ENBD);
                        $('#ei').html(returnedData.ei_bank);
                        $('#other_bank').html(returnedData.other_bank);
                        $('#bachir').html(returnedData.cash_bachir); 
                        $('#garhoud').html(returnedData.Garhoud); 
                        $('#cash_fact').html(returnedData.cash_fact);    

                        $('#totl_bnk_bal').html(returnedData.total_bank_bal);
                        $('#totl_cash_bal').html(returnedData.total_cash_bal);

                          $('#bbms_approved').html(returnedData.bbms_approved);
                    $('#fact_approved').html(returnedData.factory_approved);
                     $('#enbd_approved').html(returnedData.ENBD_approved);
                        $('#ei_approved').html(returnedData.ei_bank_approved);
                        $('#other_bank_approved').html(returnedData.other_bank_approved);
                        $('#bachir_approved').html(returnedData.cash_bachir_approved); 
                        $('#garhoud_approved').html(returnedData.Garhoud_approved);
                        $('#cash_fact_approved').html(returnedData.cash_fact_approved);

                        $('#total_cat_bal').html(returnedData.total_cat);

                        $('#sales').html(returnedData.sales); 
                        $('#ship').html(returnedData.shipping);   
                        $('#gnrl_exp').html(returnedData.gnrl);
                        $('#salary').html(returnedData.salary);
                        $('#rent').html(returnedData.rent);
                        $('#other_cat').html(returnedData.other); 
                        $('#raw_mat').html(returnedData.raw_mat);
                        $('#import').html(returnedData.import); 
                        $('#export').html(returnedData.export);
                        $('#bank_bal_date').html(returnedData.bank_date);
                        $('#cat_bal_date').html(returnedData.bank_date);

//                               Highcharts.chart('container', {
//     chart: {
//         plotBackgroundColor: null,
//         plotBorderWidth: null,
//         plotShadow: false,
//         type: 'pie'
//     },
//     title: {
//         text: 'Total balance in Bank vs Cash'
//     },
//     tooltip: {
//         pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
//     },
//     plotOptions: {
//         pie: {
//             allowPointSelect: true,
//             cursor: 'pointer',
//             dataLabels: {
//                 enabled: false
//             },
//             showInLegend: true
//         }
//     },
//     series: [{
//         name: 'Total balance',
//         colorByPoint: true,
//         data: [{
//             name: 'Bank',
//             y: parseFloat(Math.abs(returnedData.total_bank_bal)),
//              positive:false
          
//         }, {
//             name: 'Cash',
//             y: parseFloat(Math.abs(returnedData.total_cash_bal)),
//              positive:false
//         }]
//     }]
// });   

     Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Percentage of balance as per category'
    },
     tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
        
      },
   /* tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },*/
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
               
            },
            showInLegend: true
        }
    },
    series: [{
        name: 'Category',
        colorByPoint: true,
        data: [{
            name: 'Shipping',
            y: parseFloat(Math.abs(returnedData.shipping)),
            positive:false
          
        }, {
            name: 'Salaries',
            y: parseFloat(Math.abs(returnedData.salary)),
            positive:false
        },{
            name: 'General Expenses',
            y: parseFloat(Math.abs(returnedData.gnrl)),
            positive:false
        }, {
            name: 'Rent',
            y: parseFloat(Math.abs(returnedData.rent)),
            positive:false
        }, {
            name: 'Import Expenses',
            y: parseFloat(Math.abs(returnedData.import)),
            positive:false
        }, {
            name: 'Personal Accounts',
            y: parseFloat(Math.abs(returnedData.export)),
            positive:false
        },
         {
            name: 'Raw material purchase',
            y: parseFloat(Math.abs(returnedData.raw_mat)),
            positive:false
        },{
            name: 'Other expenses',
            y: parseFloat(Math.abs(returnedData.other)),
            positive:false
        }
        ]
    }]
});                          

                    }
                });




    }
</script>
<!-- <script type="text/javascript">
  //$("#datepicker").datepicker({
  //  onSelect: function() { 
  //      var dateObject = $(this).datepicker('getDate'); 
  //      console.log(dateObject);
  //  }
//});
$('#datepicker').datepicker({
    onSelect: function(dateText, inst) {
     console.log($("input[name='start_date_picker']").val(dateText));

    }
});

// $('input[name="start_date_picker"]').on("click",function(){
//   if()
//  console.log($(this).val());
//    });
</script> -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datetimepicker();
            });
        </script>


</body>

</html>