<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>


  
    <!-- jsFiddle will insert css and js -->
<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}

</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Survey Form </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Survey Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Survey # <?php echo $survey_details[0]->st_survey_no;?> - Manage Installation</h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('submit_manage_installation','class="myform" ','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
 <input type="hidden" name="survey_id" value="<?php echo $edit_survey_id;?>">
 <input type="hidden" name="installation_id" value="<?php echo $installation_id;?>">
 <input type="hidden" name="single_prd_ids" value="<?php if(!empty($survey_details[0]->st_single_prds)){echo $survey_details[0]->st_single_prds;};?>">
 <?php
   if(!empty($edit_manage_installation))
  {
    ?>
<input type="hidden" name="update_manage_installation" value="<?php echo $installation_table_details[0]->insd_id;?>">
<input type="hidden" name="old_qnty_prd_set" value="<?php echo $installation_table_details[0]->insd_prd_set_qty_set_for_installation;?>">
<input type="hidden" name="old_qnty_prd_single" value="<?php echo $installation_table_details[0]->insd_prd_single_qty_set_for_installation;?>">
<?php
  }
?>  

   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>


<div class="row">
<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">

  <div class="col-md-3 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Choose Date<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
 <?php
if(!empty($new_installation_date))
{
 $converted_date_delivry1 = date("d/m/Y", strtotime($new_installation_date));
}
elseif(!empty($installation_table_details[0]->insd_date))
{
 $converted_date_delivry1 = date("d/m/Y", strtotime($installation_table_details[0]->insd_date));
}
else
{}
  ?>
  <input type='text' name="schedule_date_installation" class="form-control datetimepicker4"  value="<?php if(!empty($converted_date_delivry1)){echo  $converted_date_delivry1;};?>" required autocomplete="off" />

  <div class="form_error">  <?php echo $this->session->flashdata('schedule_date_installation');?></div>
</div>
</div>
</div>

<?php if(!empty($installation_table_details[0]->insd_labours))
{
  $labours_list=explode(',',$installation_table_details[0]->insd_labours);
}
;?>
<div class="col-md-3 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Labours <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<select data-plugin-selectTwo class='form-control populate' multiple="" name="choose_labour[]" required="">
  
  <?php foreach($labour as $l)
  {
    if(!empty($edit_manage_installation))
    {
?>
 <option value="<?php echo $l['ed_id'];?>" <?php if(!empty($installation_table_details[0]->insd_labours)){if(in_array($l['ed_id'], $labours_list)){echo "selected";}} ;?>><?php echo $l['ed_name'];?></option>
<?php
}
else
{
  ?>
  <option value="<?php echo $l['ed_id'];?>" ><?php echo $l['ed_name'];?></option>
  <?php
}
  }
  ?>
 </select>
 <div class="form_error">  <?php echo $this->session->flashdata('st_start_cordinate');?></div>
</div>
</div>
</div>
<?php if(!empty($installation_table_details[0]->insd_vehicle))
{
  $veh_list=explode(',',$installation_table_details[0]->insd_vehicle);
}
;?>
<div class="col-md-3 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Choose Vehicle<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select name="vehicle_choosed[]" data-plugin-selectTwo class='form-control populate' multiple="" required="">
   
  <?php foreach($vehicle as $v)
  {
      if(!empty($edit_manage_installation))
    {
?>
 <option value="<?php echo $v->veh_id;?>"  <?php if(!empty($installation_table_details[0]->insd_vehicle)){if(in_array($v->veh_id, $veh_list)){echo "selected";}} ;?> ><?php echo $v->veh_plate_no;?></option>
<?php
  }
  else
  {
    ?>
<option value="<?php echo $v->veh_id;?>" ><?php echo $v->veh_plate_no;?></option>
    <?php
  }
}
  ?>
  </select>
  <div class="form_error">  <?php echo $this->session->flashdata('st_end_cordinate');?></div>
</div>
</div>
</div>

<div class="col-md-3 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Choose Tools<abbr class="required">::*::</abbr>
</label>
<?php if(!empty($installation_table_details[0]->insd_tools))
{
  $tools_list=explode(',',$installation_table_details[0]->insd_tools);
}
;?>
<div class="col-md-8">
    <select data-plugin-selectTwo class='form-control populate' multiple="" name="choose_tools[]" class="form-control" required="">
   
  <?php foreach($tools as $t)
  {
     if(!empty($edit_manage_installation))
    {
?>
 <option value="<?php echo $t->tool_id;?>" <?php if(!empty($installation_table_details[0]->insd_tools)){if(in_array($t->tool_id, $tools_list)){echo "selected";}} ;?>><?php echo $t->tool_name;?></option>
<?php
  }
  else
  {
    ?>
<option value="<?php echo $t->tool_id;?>" ><?php echo $t->tool_name;?></option>
    <?php
  }
}
  ?>
  </select>
  <div class="form_error">  <?php echo $this->session->flashdata('choose_tools');?></div>
</div>
</div>
</div>

</div>
<!-----=====================table col-12 ends here===================---->
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for details---->

<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Generate Installation Details</h2>
<?php
 if(!empty($installation_table_details))
  {
    $prd_set_qnty_final_remaining=explode(',',$installation_table_details[0]->prd_set_final_calc_qnty);

    $prd_single_qnty_final_remaining=explode(',',$installation_table_details[0]->prd_single_final_calc_qnty);


    if($installation_table_details[0]->prd_set_final_calc_qnty!='')
    {
      if(array_filter($prd_set_qnty_final_remaining)!=true)
      {
        echo "<h2 style='color:green'>No more product set to install</h2>";
      }
    }

    if($installation_table_details[0]->prd_single_final_calc_qnty!='')
    {
      if(array_filter($prd_single_qnty_final_remaining)!=true)
      {
        echo "<h2 style='color:green'>No more single product to install</h2>";
      }
    }
  }
  ?>

</header>
<div class="panel-body">  
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none">
<thead>
<tr>

<th>Product Sets</th>
<th>Product Singles</th>
<th>PO Reference<br/>(Partially / fully completed PO)</th>

</tr>
</thead>
<tbody>
<tr>
  <td>
    <table class="table table-bordered table-striped mb-none">
      <thead>
        <tr>
          <th>Image</th>
          <th>Original Quantity</th>
         <!--  <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
    <?php
    if(!empty($prd_set_details))
    {
    foreach($prd_ids_1 as $index_p=>$p1)
          {
            $alignment=$prd_set_details[$index_p]->psd_prd_alignment;
            $prod_position=explode(',',$prd_set_details[$index_p]->psd_arrange_position);

            // pre_list($prod_position);
            // pre_list($p1);
            foreach($prod_position as $pd2)
            {
        //  pre_list($pd2);
         //   pre_list($p1[$pd2][0]->pname);
              if(empty($p1[$pd2][0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
                 }
                 $prd_height[$index_p][]=$p1[$pd2][0]->prd_height;
                 $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
                 $prod_sets_image[$index_p][]=$img_path;
                 $prod_sets_alignment[$index_p]=$alignment;
                 $prod_sets_position[$index_p]=$prod_position;
                 $prd_set_id[$index_p]=$prd_set_details[$index_p]->psd_id;

                  $prod_sets_qty_orginal[$index_p]=$prd_set_details[$index_p]->psd_prd_qty;
                  $qty_installed[$index_p]=$prd_set_details[$index_p]->psd_qty_installed;
                  $qty_remaining[$index_p]=$prd_set_details[$index_p]->psd_qty_remaining_installation;
            }
          }          
          $ij=1;
          foreach($prod_sets_alignment as $index=>$align)
          { 
           if(!empty($installation_table_details))
                  {
                    $prd_set_original_qnty_after_installation=explode(',',$installation_table_details[0]->insd_prd_set_org_qnty);
                    $prd_set_qnty_to_install=explode(',',$installation_table_details[0]->insd_prd_set_qty_set_for_installation);
                    $prd_set_qnty_remaining=explode(',',$installation_table_details[0]->insd_prd_set_remaining_qnty);
                    $prd_set_qnty_insatlled=explode(',',$installation_table_details[0]->insd_prd_set_qty_installed);
                    $prd_set_qnty_remaining_after_installed=explode(',',$installation_table_details[0]->insd_prd_set_remaining_after_installation);
                    $prd_set_qnty_final_remaining=explode(',',$installation_table_details[0]->prd_set_final_calc_qnty);
                    $prd_set_start_qnty=explode(',',$installation_table_details[0]->insd_prd_set_start_qty);
                    echo "<input type='hidden' name='installation_table_details' value='1'>";
                  }
                  else
                  {
                      echo "<input type='hidden' name='installation_table_details' value='0'>";
                  }
            if($align=="vertical")
            {
              //pre_list(implode(',',$prod_sets_image[$index]));
              echo "<tr>";
            echo "<td>";
            asort($prod_sets_position[$index]);
            foreach($prod_sets_position[$index]  as $index22=>$ptt)
              {
          
                if(!empty($prod_sets_image[$index][$index22]))
              echo "<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
              else
              echo "";
              }
              echo "</td>";
              echo "<td>";
               if(!empty($installation_table_details))
              {

                if(!empty($edit_manage_installation))
                   {
              echo "Original Quantity: <span class='original_qnty_".$ij."'>".$prd_set_start_qnty[$index]."</span><input type='hidden' name='prd_set_org_qnty[]' value='".$prd_set_start_qnty[$index]."'><br/>";
                  }
                  else
                  {
                 echo "Original Quantity: <span class='original_qnty_".$ij."'>".$prd_set_original_qnty_after_installation[$index]."</span><input type='hidden' name='prd_set_org_qnty[]' value='".$prd_set_original_qnty_after_installation[$index]."'><br/>";
                  }
              }
              else
              {
                echo "Original Quantity: <span class='original_qnty_".$ij."'>".$prod_sets_qty_orginal[$index]."</span><input type='hidden' name='prd_set_org_qnty[]' value='".$prod_sets_qty_orginal[$index]."'><br/>";
              }
              if(!empty($installation_table_details))
              {
                  // if(!empty($prd_set_qnty_remaining[$index]))
                  // {
               // $edit_rmaining_qty=$prd_set_original_qnty[$index]-$prd_set_qnty_insatlled[$index];
                  if(!empty($edit_manage_installation))
                   {
              echo "<br/>
              <b>Quantity to Install: </b><input type='number' max='";
              if(!empty($prd_set_qnty_to_install[$index])){echo $prd_set_qnty_to_install[$index];}
              echo "' autocomplete='off' class='new_quantity_prd_set".$ij."' name='new_quantity_prd_set[]' value='";
              if(!empty($prd_set_qnty_to_install[$index])){echo $prd_set_qnty_to_install[$index];}
                echo "' onkeyup='get_prd_set_qty(".$ij.")'>";
                  }
                  else
                  {
                     echo "<br/><b>Quantity to Install: </b><input type='text' autocomplete='off' class='new_quantity_prd_set".$ij."' name='new_quantity_prd_set[]' value='' onkeyup='get_prd_set_qty(".$ij.")'>";
                  }
              echo "<input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'><br/>
            Remaining Quantity: <span class='dt_prd_set_remaining_qty_".$ij."'>".$prd_set_qnty_remaining[$index]."</span><input type='hidden' class='prd_set_remaining_qty_".$ij."' name='prd_set_remaining_qty[]' value='".$prd_set_qnty_remaining[$index]."'>";
                //}
              }
              else
              {
                echo "<br/><b>Quantity to Install: </b><input type='text' class='new_quantity_prd_set".$ij."' name='new_quantity_prd_set[]' value='' onkeyup='get_prd_set_qty(".$ij.")'>
              <input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'><br/>
              Remaining Quantity: <span class='dt_prd_set_remaining_qty_".$ij."'>0</span><input type='hidden' class='prd_set_remaining_qty_".$ij."' name='prd_set_remaining_qty[]' value='0'>";
              }
           
             if(!empty($installation_table_details))
             {
               echo "<br/><hr/>";
                echo "<h4>Summary of Last Installation</h4>";
              echo "Quantity Set for Installation:";if(empty($prd_set_qnty_to_install[$index])){echo "0";}else{echo $prd_set_qnty_to_install[$index];}; echo"<br/>";     
              echo "Quantity Installed:";if(empty($prd_set_qnty_insatlled[$index])){echo "0";}else{echo $prd_set_qnty_insatlled[$index];};echo "<br/>";
              echo "Remaining Quantity after installation:";if(empty($prd_set_qnty_remaining_after_installed[$index])){echo "0";}else{echo $prd_set_qnty_remaining_after_installed[$index];}; echo"<br/>";
              // echo "<b>Total Remaining for NEXT installation:<span class='qnty_for_next_instaltion_".$ij."'>"; if(empty($prd_set_qnty_final_remaining[$index])){echo "0";}else{echo $prd_set_qnty_final_remaining[$index];}; echo"</span><br/></b>";        
             }
              echo"</td>";
              echo "</tr>";
            }
            else
            {
              echo "<tr>";
              echo "<td>";
              asort($prod_sets_position[$index]);
              foreach($prod_sets_position[$index]  as $index22=>$ptt)
              {
                if(!empty($prod_sets_image[$index][$index22]))
              echo "<img src='".$prod_sets_image[$index][$index22]."' width='80' height='100'>";
              else
              echo "";
              }
              echo "</td>";
              echo "<td>";
               if(!empty($installation_table_details))
              {
                  if(!empty($edit_manage_installation))
                 {
              echo "Original Quantity: <span class='original_qnty_".$ij."'>".$prd_set_start_qnty[$index]."</span><input type='hidden' name='prd_set_org_qnty[]' value='".$prd_set_start_qnty[$index]."'><br/>";
                  }
                  else
                  {
              echo "Original Quantity: <span class='original_qnty_".$ij."'>".$prd_set_original_qnty_after_installation[$index]."</span><input type='hidden' name='prd_set_org_qnty[]' value='".$prd_set_original_qnty_after_installation[$index]."'><br/>";
                  }
              }
              else
              {
                echo "Original Quantity: <span class='original_qnty_".$ij."'>".$prod_sets_qty_orginal[$index]."</span><input type='hidden' name='prd_set_org_qnty[]' value='".$prod_sets_qty_orginal[$index]."'><br/>";
              }
              if(!empty($installation_table_details))
              {
                //pre_list($prd_set_qnty_to_install);
                if(!empty($edit_manage_installation))
                 {
                echo "<br/><b>Quantity to Install: </b><input type='number' max='";
                if(!empty($prd_set_qnty_to_install[$index])){echo $prd_set_qnty_to_install[$index];}
                echo "' autocomplete='off' class='new_quantity_prd_set".$ij."' name='new_quantity_prd_set[]' value='";
                if(!empty($prd_set_qnty_to_install[$index])){echo $prd_set_qnty_to_install[$index];}
                echo "' onkeyup='get_prd_set_qty(".$ij.")'>";
                  }
                  else
                  {
                 echo "<br/><b>Quantity to Install: </b><input type='text' autocomplete='off' class='new_quantity_prd_set".$ij."' name='new_quantity_prd_set[]' value='' onkeyup='get_prd_set_qty(".$ij.")'>";    
                  }
              echo "<input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'> <br/>
          Remaining Quantity: <span class='dt_prd_set_remaining_qty_".$ij."'>".$prd_set_qnty_remaining[$index]."</span><input type='hidden' class='prd_set_remaining_qty_".$ij."' name='prd_set_remaining_qty[]' value='".$prd_set_qnty_remaining[$index]."'>";
                //}
              }
              else
              {
              echo "<br/><b>Quantity to Install:</b> <input type='text' class='new_quantity_prd_set".$ij."' name='new_quantity_prd_set[]' value='' onkeyup='get_prd_set_qty(".$ij.")'>
              <input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'>
              <br/>
              Remaining Quantity: <span class='dt_prd_set_remaining_qty_".$ij."'>0</span><input type='hidden' class='prd_set_remaining_qty_".$ij."' name='prd_set_remaining_qty[]' value='0'>";
              }
               if(!empty($installation_table_details))
             {
               echo "<br/><hr/>";
                echo "<h4>Summary of Last Installation</h4>";
              echo "Quantity Set for Installation:"; if(empty($prd_set_qnty_to_install[$index])){echo "0";}else{echo $prd_set_qnty_to_install[$index];};echo"<br/>";     
              echo "Quantity Installed:"; if(empty($prd_set_qnty_insatlled[$index])){echo "0";}else{echo $prd_set_qnty_insatlled[$index];};echo "<br/>";
              echo "Remaining Quantity after installation:";if(empty($prd_set_qnty_remaining_after_installed[$index])){echo "0";}else{echo $prd_set_qnty_remaining_after_installed[$index];};echo "<br/>";
              // echo "<b>Total Remaining for NEXT installation:<span class='qnty_for_next_instaltion_".$ij."'>";if(empty($prd_set_qnty_final_remaining[$index])){echo "0";}else{echo $prd_set_qnty_final_remaining[$index];};echo "</span><br/></b>";        
             }
              echo"</td>";
              echo "</tr>";               
            }
            $ij++;
          }
        ?>   
    <?php      
    }
    ?>
    </tbody>
    </table>
  </td>
  <td>
    <table class="table table-bordered table-striped mb-none">
      <thead>
        <tr>
          <th>Image</th>
          <th>Original Quantity</th>
          <!-- <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
    <?php
    if(!empty($survey_details[0]->st_single_prds))
    {     

$ik=50;
$org_qty=explode(',',$single_prd_qty);
$edit_qty_installed=explode(',',$survey_details[0]->st_qty_installed);
$edit_qty_remaining=explode(',',$survey_details[0]->st_qty_remaining_installation);
     
if(!empty($installation_table_details))
{
  $prd_single_original_qnty=explode(',',$installation_table_details[0]->insd_prd_single_org_qnty);
  $prd_single_qnty_to_install=explode(',',$installation_table_details[0]->insd_prd_single_qty_set_for_installation);
  $prd_single_qnty_reaminig=explode(',',$installation_table_details[0]->insd_prd_single_remaining_qnty);
  $prd_single_qnty_installed=explode(',',$installation_table_details[0]->insd_prd_single_qty_installed);
  $prd_single_qnty_remaining_after_install=explode(',',$installation_table_details[0]->insd_prd_single_remaining_after_installation);
  $prd_single_qnty_final_remaining=explode(',',$installation_table_details[0]->prd_single_final_calc_qnty);
  $prd_single_start_qnty=explode(',',$installation_table_details[0]->insd_prd_single_start_qty);
echo "<input type='hidden' name='installation_table_details' value='1'>";
}
else
{
  echo "<input type='hidden' name='installation_table_details' value='0'>";
}
      foreach($prd_ids_2 as $index2=>$pd2)
      {
        if(!empty($edit_qty_installed[$index2]))
        $edit_calc_remaining=$org_qty[$index2]-$edit_qty_installed[$index2];
      if(empty($pd2[0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$pd2[0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->p_prd_img;
                 }
      ?>
    <tr>
      <td><img src="<?php echo $img_path;?>"  width='100' height='100'></td>
      <td>
        <?php
        if(!empty($installation_table_details))
            {
              if(!empty($edit_manage_installation))
              {
              ?>
              Original Quantity: <span class='original_qnty_<?php echo $ik;?>'><?php echo $prd_single_start_qnty[$index2];?></span><br/>
                <input type='hidden' name='prd_single_org_qnty[]' value='<?php echo $prd_single_start_qnty[$index2];?>'><br/>
              <?php
              }
              else
              {
              ?>
                 Original Quantity: <span class='original_qnty_<?php echo $ik;?>'><?php echo $prd_single_original_qnty[$index2];?></span><br/>
                <input type='hidden' name='prd_single_org_qnty[]' value='<?php echo $prd_single_original_qnty[$index2];?>'><br/>
              <?php
              }?>  

        <?php 
             }
              else
              {
        ?>        
            Original Quantity: <span class='original_qnty_<?php echo $ik;?>'><?php echo $org_qty[$index2];?></span><br/>
              <input type='hidden' name='prd_single_org_qnty[]' value='<?php echo $org_qty[$index2];?>'><br/>
            
        <?php  }?>
       
     
      <?php
       if(!empty($installation_table_details))
              {
                // if(!empty($prd_set_qnty_remaining[$index]))
                // {
            if(!empty($edit_manage_installation))
            {
             ?>
            <br/><b>Quantity to Install:</b> <input type="number" autocomplete='off' name="prd_single_quantity_new[]" class="new_quantity_prd_set<?php echo $ik;?>" value="<?php if(!empty($prd_single_qnty_to_install[$index2])){echo $prd_single_qnty_to_install[$index2];};?>" max="<?php if(!empty($prd_single_qnty_to_install[$index2])){echo $prd_single_qnty_to_install[$index2];};?>" onkeyup='get_prd_set_qty(<?php echo $ik;?>)'>
            <?php
          }
          else
          {  ?>
            <br/><b>Quantity to Install:</b> <input type="text" autocomplete='off' name="prd_single_quantity_new[]" class="new_quantity_prd_set<?php echo $ik;?>" value="" onkeyup='get_prd_set_qty(<?php echo $ik;?>)'>
          <?php
        }?>
        <br/>Remaining Quantity: 
        <span class='dt_prd_set_remaining_qty_<?php echo $ik;?>'><?php echo $prd_single_qnty_reaminig[$index2];?></span>
        <input type='hidden' name='prd_remaining_qty_single[]' class='prd_set_remaining_qty_<?php echo $ik;?>' value='<?php echo $prd_single_qnty_reaminig[$index2];?>'>          
      <?php
           // }
      }
      else
      {
        ?>
      <br/><b>Quantity to Install:</b> <input type="text" name="prd_single_quantity_new[]" class="new_quantity_prd_set<?php echo $ik;?>" value="" onkeyup='get_prd_set_qty(<?php echo $ik;?>)'>
        <br/>Remaining Quantity: <span class='dt_prd_set_remaining_qty_<?php echo $ik;?>'>0</span>
        <input type='hidden' name='prd_remaining_qty_single[]' class='prd_set_remaining_qty_<?php echo $ik;?>' value='0'>
      
      <?php
    }
     if(!empty($installation_table_details))
             {
              echo "<br/><hr/>";
               echo "<h4>Summary of Last Installation</h4>";
              echo "Quantity Set for Installation:";if(empty($prd_single_qnty_to_install[$index2])){echo "0";}else{echo $prd_single_qnty_to_install[$index2];}; echo"<br/>";     
              echo "Quantity Installed:";if(empty($prd_single_qnty_installed[$index2])){echo "0";}else{echo $prd_single_qnty_installed[$index2];};echo"<br/>";
              echo "Remaining Quantity after installation:";if(empty($prd_single_qnty_remaining_after_install[$index2])){echo "0";}else{echo $prd_single_qnty_remaining_after_install[$index2];};echo"<br/>";
              // echo "<b>Total Remaining for NEXT installation:<span class='qnty_for_next_instaltion_".$ik."'>";if(empty($prd_single_qnty_final_remaining[$index2])){echo "0";}else{echo $prd_single_qnty_final_remaining[$index2];};echo"</span><br/></b>";        
             }
             ?>
      </td>
    </tr>
    <?php
    $ik++;
      }
    }
    ?>
    </tbody>
    </table>
  </td>
  <td>
    <?php
    if(!empty($survey_details[0]->partial_po_tot_qntys))
      {
        ?>
     <table class="table table-bordered table-striped mb-none">
      <thead>
        <tr>
          <th>Image</th>
          <th>Partial Quantity Ready for Delivery </th>
          <!-- <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
      <?php
      if(!empty($prd_ids_po))
      {
        if(!empty($survey_details[0]->partial_po_tot_qntys))
        {
        $po_qntys_ready=explode(',',$survey_details[0]->partial_po_tot_qntys);
      
      foreach($prd_ids_po as $po_index=>$po)
      {
         if(empty($po[0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$po[0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$po[0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$po[0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$po[0]->p_prd_img;
                 }
        ?>
      <tr>
        <td><img src="<?php echo $img_path;?>"  width='100' height='100'></td>
        <td><?php echo $po_qntys_ready[$po_index];?></td>
      </tr>
      <?php
    }
  }
  }
  ?>
    </tbody>
</table>
<?php
}
else
{
?>
<table class="table table-bordered table-striped mb-none">
      <thead>
        <tr>
          <th>Image</th>
          <th>Partial Quantity Ready for Delivery </th>
          <!-- <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
      <?php
      if(!empty($prd_ids_po))
      {
          $po_qntys_ready=explode('|#|',$survey_details[0]->st_po_prd_qtys);

      foreach($prd_ids_po as $po_index=>$po)
      {
         if(empty($po[0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$po[0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$po[0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$po[0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$po[0]->p_prd_img;
                 }
        ?>
      <tr>
        <td><img src="<?php echo $img_path;?>"  width='100' height='100'></td>
        <td><?php echo $po_qntys_ready[$po_index];?></td>
      </tr>
      <?php
    }
  }
  ?>
    </tbody>
</table>
<?php
}?>
  </td>
  
</tr>
<!-----------modal for setting installation date----->
<!---------end installation date---->
</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->


<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
   <script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker({format: 'dd/mm/yyyy' });
            });        
        </script>
 <script type="text/javascript">
          function get_prd_set_qty(ij)
          {
            var original_prd_set_qty=$('.original_qnty_'+ij).html();
        // console.log(original_prd_set_qty);
          var new_prd_set_qty=$('.new_quantity_prd_set'+ij).val();
          //  console.log(new_prd_set_qty);
          var remaining_prd_set= parseFloat(original_prd_set_qty)-parseFloat(new_prd_set_qty);

         // console.log(remaining_prd_set);
             
            if(remaining_prd_set==0)
            {
              $('.dt_prd_set_remaining_qty_'+ij).text('0');
              $('.prd_set_remaining_qty_'+ij).val('0');
            }
            else
            {

              $('.dt_prd_set_remaining_qty_'+ij).text(remaining_prd_set);
              $('.prd_set_remaining_qty_'+ij).val(remaining_prd_set);
              
            }
           // console.log('remaining prd qnty='+remaining_prd_set);
            //$('.pipe_qnty_'+ij).html(prd_set_qty);
          }     
        </script>
</body>

</html>