<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Customer Pricing </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Customer Pricing</span></li>
<li><span>List</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>




<!-----section for lightbox opens here-->
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">List Customer Pricing</h2>
</header>
<div class="panel-body">
  
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th></th>
<th>Company Name </th>
<th>Customer Name</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php
  if(!empty($result))
  {
    $i=1;
    foreach($result as $index=>$t)
    {

  $price=explode('|#|',$t->scp_prd_price);
  $extra_note=explode('|#|',$t->scp_prd_extra_note);
?>
<tr>
  <td><?php echo $i++;?></td>
  <td><?php echo $customer_data[$index][0]->sca_cust_name;?></td>
  <td><?php echo $customer_data[$index][0]->sca_cust_company;?></td>

    <td>
      <div class="dropdown-primary dropdown ">
<button class="btn btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Action</button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">

  <a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalLG<?php echo $t->scp_id;?>"><i class="fa fa-eye"></i>View</a>
<div class="dropdown-divider"></div>
  <a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('edit_cust_pricing/').$t->scp_id;?>"><i class="fa fa-pen"></i>Edit Details
<div class="dropdown-divider"></div>
    <a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('delete_cust_pricing/').$t->scp_id;?>"><i class="fa fa-trash"></i>Delete Details</a>

</div>
</div>
  </td>
</tr>
<div id="modalLG<?php echo $t->scp_id;?>" class="modal-block modal-block-lg modal-header-color modal-block-info mfp-hide" data-backdrop="static" data-keyboard="false">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Pricing details</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
  <div class="col-md-12 col-sm-12">
    <div class="col-md-12" style="margin-bottom: 2%;">
   <b>Created by:</b> <?php echo $t->scp_user_session;?><br/>
        <b>Company:</b> <?php echo $customer_data[$index][0]->sca_cust_name;?><br/>
        <b>Customer :</b> <?php echo $customer_data[$index][0]->sca_cust_company;?><br/>
       </div>
      
  <div class="col-md-12" style="border: 1px solid black;">
    <div class="col-md-12 col-sm-12">  
      <?php
        foreach($prds[$index] as $ind=>$p)
        {
        
          if(empty($p[0]->p_prd_img))
          {
            $filename="https://birigroup.com/uploads/prd_images/".$p[0]->pcode.'.jpeg';
           if (file_exists($filename)) {
            $img_path=$filename;
            } else {
            $img_path="https://birigroup.com/uploads/prd_images/".$p[0]->pcode.'.jpg';
              }
          }
           else
           {
            $first_img_prd=explode(',',$p[0]->p_prd_img);
            if(!empty($first_img_prd[0]))
            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
            else
            $img_path="https://birigroup.com/uploads/prd_images/".$p[0]->p_prd_img;
           }
           echo'<div class="col-md-6 col-sm-6">';
            echo'<img src="'.$img_path.'" width="100" height="100">';
           echo '</div>';
           echo'<div class="col-md-6 col-sm-6">';
        $prd_name_db=explode('|~~|',$p[0]->pname);
            echo '<b>Product Name:</b>'.$prd_name_db[0].'<br/>';
            echo '<b>Code:</b> '.$p[0]->pcode.'<br/>';
            echo '<b>Price:</b> '.$price[$ind].'<br/>';
             echo '<b>Extra Note:</b> '.$extra_note[$ind].'<br/><hr/>';
            echo '</div>';
        }   
          ;?>
     </div>
   </div>
    
  </div>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-default modal-dismiss">Close</button>
</div>
</div>
</footer>
</section>
</div> 

<?php
}
}
?>

</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

</body>

</html>