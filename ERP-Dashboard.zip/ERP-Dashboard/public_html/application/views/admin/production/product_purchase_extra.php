<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Product Extra Details</h2>
</header>
<div class="panel-body">

	<?php
				if(($this->session->userdata['user']['main_dept']=="Main")||($this->session->userdata['user']['log_designation']=="Team-lead"))
				{   	

	echo form_open_multipart('Item_costing/submit_prd_purchase_pricing');
		}
 	  ?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>



<input type="hidden" name="prd_id" value="<?php  if(!empty($products_extra[0]->pid)) echo $products_extra[0]->pid;?>">

<input type="hidden" name="prd_code" value="<?php  if(!empty($products_extra[0]->pcode)) echo $products_extra[0]->pcode;?>">

<input type="hidden" name="variation_label_val">

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<?php
if(!empty($products_extra[0]->pname))
{
$pname=explode('|~~|',$products_extra[0]->pname);
}?>
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Product Name(English)</label>
<div class="col-md-8">

 <input type="text" class="form-control acc_amount"  readonly name="pname_en" value="<?php  if(!empty($pname[0])) echo $pname[0];?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('pname_en');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Product Name(Arabic)</label>
<div class="col-md-8">

 <input type="text"  class="form-control acc_amount"  name="pname_ar"  readonly value="<?php  if(!empty($pname[1])) echo $pname[1];?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('pname_ar');?></div>
</div>
</div>

</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">New Purchase Price<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text"  class="form-control acc_amount"  name="edit_prd_purchase"   value="<?php  if(!empty($products_extra[0]->temp_p_purchase_price)) echo $products_extra[0]->temp_p_purchase_price;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('edit_prd_purchase');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">The Current Purchase Price IS:</label>

<div class="col-md-8">

 <input type="text"  class="form-control acc_amount"  name="previous_prd_purchase" readonly  value="<?php  if(!empty($products_extra[0]->p_purchase_price)) echo $products_extra[0]->p_purchase_price;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('previous_prd_purchase');?></div>
</div>

</div>

</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Country of Origin <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<div class="input-group btn-group">
<select class="form-control populate country_form" name="countries">
		<option></option>
		<?php
		if(!empty($countrys))
		{
			foreach($countrys as $c)
			{
				?>
				<option value="<?php echo $c->country_id;?>" <?php if((!empty($products_extra[0]->p_country))){if($products_extra[0]->p_country==$c->country_id){echo "selected";}};?> > <?php echo $c->name;?></option>;
			<?php
			}
		}
		else
		{}
		?>
	</select>


</div>

<div class="form_error">  <?php echo $this->session->flashdata('countries');?></div>
</div>




</div>

</div>













<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Last Supplier<i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Add Supplier"></i><abbr class="required">::*::</abbr></label>

<div class="col-md-8">

<div class="input-group btn-group">	
<select class="form-control populate supplier_type" name="suppliers">
		<option></option>
		<?php
		if(!empty($suppliers))
		{
			foreach($suppliers as $s)
			{
				?>
				<option value="<?php echo $s->label;?>" <?php if((!empty($products_extra[0]->p_last_supplier))){if($products_extra[0]->p_last_supplier==$s->label){echo "selected";}};?> > <?php echo $s->label;?></option>;
			<?php
			}
				
			
		}
		else
		{}
		?>
</select>

</div>

<div class="form_error">  <?php echo $this->session->flashdata('suppliers');?></div>
</div>

</div>







<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">New Supplier (if Not Exist Above)<i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Add Supplier"></i><abbr class="required">::*::</abbr></label>

<div class="col-md-8">

<div class="input-group btn-group">	
<select class="form-control populate supplier_type" name="newsuppliers">
		<option></option>
		<?php
		if(!empty($newsupplier))
		{
			foreach($newsupplier as $ns)
			{
				?>
				<option value="<?php echo $ns->label;?>" <?php if((!empty($products_extra[0]->p_last_supplier))){if($products_extra[0]->p_last_supplier==$ns->label){echo "selected";}};?> > <?php echo $ns->label;?></option>;
			<?php
			}
				
			
		}
		else
		{}
		?>
</select>
<span class="input-group-addon">
<a class="modal-with-form" href="#modalForm4"><i class="fa fa-plus"></i></a>
</span>
<div id="modalForm4" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Supplier</h2>
</header>
<div class="panel-body">
<div class="form-horizontal mb-lg extra-form" novalidate="novalidate">
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Supplier Name<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="var_name" class="form-control"  />
</div>
</div>


</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary modal-confirm" onclick="variation_form('supp_form');">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
</div>

<div class="form_error">  <?php echo $this->session->flashdata('newsuppliers');?></div>
</div>

</div>

</div>
</div>







<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Product Weight<i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Enter the product weight in kg"></i><abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" class="form-control acc_amount" required="" name="edit_prd_weight" value="<?php  if(!empty($products_extra[0]->p_wgt)) echo $products_extra[0]->p_wgt;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('edit_prd_weight');?></div>
 <small>Product Weight in Kilogram</small>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Packing Sizes <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Enter the packing size. Calculated in cm."></i><abbr class="required">::*::</abbr></label>

<div class="col-md-8">
<section class="form-group-vertical">
<input class="form-control" type="text" name="edit_prd_width" placeholder="Enter Width" value="<?php  if(!empty($products_extra[0]->p_pack_width))echo $products_extra[0]->p_pack_width;?>">
<input class="form-control" type="text" name="edit_prd_height" placeholder="Enter Height" value="<?php  if(!empty($products_extra[0]->p_pack_hgt)) echo   $products_extra[0]->p_pack_hgt;?>">
<input class="form-control last" type="text" name="edit_prd_length" placeholder="Enter Length" value="<?php  if(!empty($products_extra[0]->p_pack_lgth)) echo $products_extra[0]->p_pack_lgth;?>">
</section>
<small>All sizes are in cm</small>
<div class="form_error">  
	<?php echo $this->session->flashdata('edit_prd_width');?>
	<?php echo $this->session->flashdata('edit_prd_height');?>
	<?php echo $this->session->flashdata('edit_prd_length');?>
</div>
</div>

</div>

</div>
</div>




<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary"> Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
<!-- submit_main_form -->

<?php echo form_close();?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>



<script type="text/javascript">
	$(document).ready(function()
	{
		$('.select_variation').hide();

		var variation_sts=$("input[name='variation_status']:checked").val();
		if(variation_sts=="Yes")
		{
			$('.select_variation').show();
		}

		$('.main_cat').on('change', function() {		
		cat_id=$('select[name=cat]').val();
			  jQuery.ajax({
		            url:"<?php echo base_url().'Item_costing/sub_cat_list';?>",
		            type:"post",
		            data:{"cat_id":cat_id},
		            success:function(result)
		            {
		         		 $('.sub_cat_type').html(result);
		          	}
		        });
    		});

		$('.country_type').on('change', function() {		
		country_id=$('select[name=countries]').val();
			  jQuery.ajax({
		            url:"<?php echo base_url().'Item_costing/country_code_val';?>",
		            type:"post",
		            data:{"country_id":country_id},
		            success:function(result)
		            {
		         		 $('.hse_code_val').html(result);
		          	}
		        });
    		});

		$('input:radio').change(function() {
			var variation_type = $("input[name='variation_status']:checked").val();
			if(variation_type=="Yes")
			{
				$('.select_variation').show();
			}
			if(variation_type=="No")
			{
				$('.select_variation').hide();
			}		
  		});

		 $("input[name='selling_price']").change(function() {
			// console.log('insde the fun');
		 	var selling_price=$("input[name='selling_price']").val();
		 	if(selling_price!='')
		 	{
		 		uae_final_l1=$("input[name='uae_final_l1']").val();
		 		uae_final_l2=$("input[name='uae_final_l2']").val();
		 		ksa_final=$("input[name='ksa_final']").val();
		 		ksa_final_l1=$("input[name='ksa_final_l1']").val();
		 		ksa_final_l2=$("input[name='ksa_final_l2']").val();
		 		ksa_final_l3=$("input[name='ksa_final_l3']").val();

			uae_price1=selling_price*parseFloat(0.10);
		 	uae_price2=selling_price*parseFloat(0.25);
			ksa_final=parseFloat(selling_price)+parseFloat(12.5);
		 	ksa_price1=ksa_final*parseFloat(0.10);
		 	ksa_price2=ksa_final*parseFloat(0.20);
		 	ksa_price3=ksa_final*parseFloat(0.50);

		 $(".uae_final").val(parseFloat(selling_price) );
		 $(".uae_final_l1").val(parseFloat(selling_price)+parseFloat(uae_price1) );
		 $(".uae_final_l2").val(parseFloat(selling_price)+parseFloat(uae_price2) );
		 $(".ksa_final").val(ksa_final);
		 $(".ksa_final_l1").val(parseFloat(ksa_final)+parseFloat(ksa_price1) );
		 $(".ksa_final_l2").val(parseFloat(ksa_final)+parseFloat(ksa_price2) );
		 $(".ksa_final_l3").val(parseFloat(ksa_final)+parseFloat(ksa_price3) );
		 	}
		 	else
		 	{}
		 });
		  // $('.submit_main_form').on('click', function(e){
		  //       e.preventDefault();
		  //       $(".product_entry_form").submit();		      
    // 		});
  	});

	function variation_form(type)
	{
		
		test=$("input[name='var_name[]']")
              .map(function(){return $(this).val();}).get().join();
       
        test_val= $("input[name='var_val[]']")
              .map(function(){return $(this).val();}).get().join();

 		var_name=$('input[name=var_name]').val();
 		var_val=$('input[name=var_val]').val();
 		var_type=type;

 		if(var_name=='')
 		{
 			if($('select[name=var_name]').val()!='')
 			var_name=$('select[name=var_name]').val();		
 			else
 			var_name=test;
 		}
 		else{}
 		if(var_val=='')
 		{
 			var_val=test_val;
 		}
 		else{}
 		
		 jQuery.ajax({
            url:"<?php echo base_url().'Item_costing/credinals';?>",
            type:"post",
            data:{"name":var_name,"val":var_val,"type":var_type},
            success:function(result)
            {
            	//console.log(result);
            	 var posts = JSON.parse(result);

            	  if(type=="variation_form")
			        {
			        var group = $('<optgroup label="'+var_name+'" class="'+var_name+'">');
						$(".variation_type").append(group);
						 $.each(posts, function()
						{
						    group.append($('<option></option>').val(this.id).html(this.name));
						});
						// group.append($('</optgroup>'));
			        }

		       $.each(posts, function() {
			      
			        	$('.supp_form').append( $('<option></option>').text(this.name).val(this.id) );
			      
		      	});
         		
  //        		$('.extra-form').find(':input').each(function() {
		//     switch (this.type) {
		//         case 'password':
		//         case 'select-multiple':
  //      			case 'select-one':
		//         case 'text':
		//         case 'textarea':
		//             $(this).val('');
		//             break;
		//         case 'checkbox':
		//         case 'radio':
		//             this.checked = false;
		//     }
		// });
            }
        });
	}
</script>

 <script type="text/javascript">
 	
 $('.myform').submit(function() {
var data=[];
$('.variation_type').find("option:selected").each(function(){
		 // optgroup label
		 var grp_name=[];
		 var grp_val=[];
        var label = $(this).parent().attr("label");  
		data.push(label+'::'+$(this).val());
        //optgroup id
       //console.log('class='+$(this).parent().attr("class"));
		 // values based on each group ??
       /// id = $(this).parent().attr("id");
 
    });
$("input[name='variation_label_val']").val(data.join("|#|"));
  if(data!='')
  	return true;
  else
     return false;
  
 });
 </script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
		tinymce.init({
			selector : '.editors',
			  plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
		});
   </script>



</body>

</html>