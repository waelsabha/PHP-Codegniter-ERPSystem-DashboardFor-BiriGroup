<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>


  
    <!-- jsFiddle will insert css and js -->
<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}

</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Return Installation Items</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Return</span></li>
<li><span> Installation Items</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">

<!-----div starts here for details---->

<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Survey # <?php echo $survey_details[0]->st_survey_no;?> - Return Installation Items</h2>
</header>
<div class="panel-body">  
  <?php echo form_open_multipart('submit_return_installation','class="myform"','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
<input type="hidden" name="edit_survey_id" value="<?php if(!empty($survey_details[0]->st_id)){echo $survey_details[0]->st_id;};?>">
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none">
<thead>
<tr>

<th>Product Sets</th>
<th>Product Singles</th>

</tr>
</thead>
<tbody>
<tr>
  <td>
    <table class="table table-bordered table-striped mb-none">
      <thead>
        <tr>
          <th>Image</th>
            <th>Original Quantity </th>
          <th>Quantity to Return </th>
         <!--  <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
    <?php
    
   
    if(!empty($prd_ids_1))
    {  
    foreach($prd_ids_1 as $index_p=>$p1)
          {
            $alignment=$prd_set_details[$index_p]->psd_prd_alignment;
            $prod_position=explode(',',$prd_set_details[$index_p]->psd_arrange_position);

            // pre_list($prod_position);
            // pre_list($p1);
            foreach($prod_position as $pd2)
            {
            //pre_list($pd2);
            //pre_list($p1[$pd2][0]->pname);
              if(empty($p1[$pd2][0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
                 }
  
                 $prd_height[$index_p][]=$p1[$pd2][0]->prd_height;
                 $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
                 $prod_sets_image[$index_p][]=$img_path;
                 $prod_sets_alignment[$index_p]=$alignment;
                 $prod_sets_position[$index_p]=$prod_position;
                 $prd_set_id[$index_p]=$prd_set_details[$index_p]->psd_id;

                $prod_sets_qty_orginal[$index_p]=$prd_set_details[$index_p]->psd_prd_qty;
                $qty_installed[$index_p]=$prd_set_details[$index_p]->psd_qty_installed;
                $qty_remaining[$index_p]=$prd_set_details[$index_p]->psd_qty_remaining_installation;

            }
          }
          
          $ij=1;
          foreach($prod_sets_alignment as $index=>$align)
          {
        
     if($align=="vertical")
            {
              //pre_list(implode(',',$prod_sets_image[$index]));
              echo "<tr>";
            echo "<td>";
            asort($prod_sets_position[$index]);
            foreach($prod_sets_position[$index]  as $index22=>$ptt)
              {
          
                if(!empty($prod_sets_image[$index][$index22]))
              echo "<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
              else
              echo "";
              }
          echo "<input type='hidden' name='prd_set_ids[]' class='prd_set_ids_".$ij."' value='".$prd_set_id[$index]."'> </td>";
        echo ' <td>
        <input type="text" name="prd_set_org_qnty[]" class="form-control" value="'.$prod_sets_qty_orginal[$index].'">
        </td>
        <td>      
        <input type="text" name="return_prd_set_qnty[]" class="form-control" value="0">
        </td>';
        echo "</tr>";
            }
            else
            {
              echo "<tr>";
              echo "<td>";
              asort($prod_sets_position[$index]);
              foreach($prod_sets_position[$index]  as $index22=>$ptt)
              {
                    if(!empty($prod_sets_image[$index][$index22]))
              echo "<img src='".$prod_sets_image[$index][$index22]."' width='80' height='100'>";
              else
              echo "";
              }
               echo "<input type='hidden' name='prd_set_ids[]' class='prd_set_ids_".$ij."' value='".$prd_set_id[$index]."'> </td>";
        echo ' <td>
        <input type="text" name="prd_set_org_qnty[]" class="form-control" value="'.$prod_sets_qty_orginal[$index].'">
        </td>
        <td>      
        <input type="text" name="return_prd_set_qnty[]" class="form-control" value="0">
        </td>';
              echo "</tr>";               
            }
            $ij++;
          }
        ?>   
    <?php      
    }
    ?>
    </tbody>
    </table>
  </td>
  <td>
    <table class="table table-bordered table-striped mb-none">
      <thead>
        <tr>
          <th>Image</th>
           <th>Original Quantity </th>
          <th>Quantity to Return </th>
          <!-- <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
    <?php
         
$ik=50;
 if(!empty($prd_ids_2))
 {
      foreach($prd_ids_2 as $index2=>$pd2)
      { 
        $single_prd_qnty=explode(',',$survey_details[0]->st_single_pipe_qty);
      if(empty($pd2[0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$pd2[0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->p_prd_img;
                 }
      ?>
    <tr>

      <td><img src="<?php echo $img_path;?>"  width='100' height='100'><input type="hidden" name="prd_single_id[]" class="single_prd_id_<?php echo $ik;?>" value="<?php echo $pd2[0]->pid;?>" name=""></td>
      <td>
        <input type="text" name="single_prd_org_qnty[]" class="form-control" value="<?php echo $single_prd_qnty[$index2];?>">
      </td>
      <td>      
        <input type="text" name="return_single_prd_qnty[]"  class="form-control" value="0">
      </td>
    </tr>
    <?php
    $ik++;
    }
  }
    ?>
    </tbody>
    </table>
  </td>
  
</tr>
<!-----------modal for setting installation date----->
<!---------end installation date---->
</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->
<input type="hidden" name="base_url" value="<?php echo base_url();?>">
<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>


<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
   <script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker().datepicker();
            });
         
        </script>
</body>

</html>