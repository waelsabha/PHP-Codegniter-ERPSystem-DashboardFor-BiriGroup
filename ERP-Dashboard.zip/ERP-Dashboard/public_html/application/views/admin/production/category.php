<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Entries</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Entries</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">List Category
<span><button class="btn btn-primary pull-right modal-with-form" href="#modalForm2">Add category <i class="fa fa-plus"></i></button></span>
</h2>
<div id="modalForm2" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Category</h2>
</header>
<div class="panel-body">

<?php echo form_open('submit_cat','class="form-horizontal mb-lg extra-form"');?>
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Category Name <abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="add_cat_name" class="form-control"  required />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Category Code</label>
<div class="col-sm-9">
<input type="text" name="add_cat_code" class="form-control"  />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Sub-Category Name<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="add_sub_cat[]" class="form-control" required />

<br/>
<span class="new_txt_fld"></span>

<button type="button" onclick="add_text_field();">
 <i class="fa fa-plus-square fa-2x"></i></button>
 <small>Click here to add more sub-categories</small> 
</div>
</div>


</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary" type="submit">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-bordered table-striped mb-none" id="datatable-default">
<thead>
<tr>
	<th style="width: 10%;"></th>

<th>Category Name</th>	
<th>Code </th>	
<th>Subcategory</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
foreach($result as $t)
{

?>
<tr class="gradeX">
			<td><?php echo $i++;?></td>
			<td><?php echo $t->cname;?></td>
			<td><?php echo $t->ccode;?></td>
			<td><?php echo $t->csub_name;?></td>
			
			<td>
				
	<!-- <button onclick="edit_cat(<?php echo $t->cid;?>)" ></button> -->
	<a class="modal-with-form" href="#edit_category_<?php echo $t->cid;?>"><i class="fa fa-pencil"></i></a>

	
				&nbsp;&nbsp;
<a href="delete_category/<?php echo $t->cid;?>" class="delete-row"><i class="fa fa-trash-o"></i></a>
	
			</td>
	</tr>


<div id="edit_category_<?php echo $t->cid;?>" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Edit Category</h2>
</header>
<div class="panel-body">
<!-- <form class="form-horizontal mb-lg extra-form"> -->
<?php echo form_open('edit_cat','class="form-horizontal mb-lg extra-form"');?>
<input type="hidden" name="cat_id" value="<?php echo $t->cid;?>">
<div class="form-group">
<label class="col-sm-3 control-label">Category Name<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="cat_name" class="form-control" value="<?php echo $t->cname;?>" required />
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Category Code<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="cat_code" class="form-control" value="<?php echo $t->ccode;?>" required />
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Sub-Category List<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
	<?php
$sub_cat_list=explode(',',$t->csub_name);
foreach($sub_cat_list as $sc)
	{?>
<input type="text" name="sub_cat[]" value="<?php echo $sc;?>" class="form-control"  />
<?php
}?>
</div>
</div>



</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary" type="submit">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close()?>
</section>
</div>
<?php 
}?>

</tbody>
</table>



</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">

	function add_text_field()
		{
			$('.new_txt_fld').append('<input type="text" name="add_sub_cat[]" class="form-control" style="border-color:black;" value="" />'); 
			return true;
		}
</script>

</body>
</html>