
<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
    .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
    color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Manage Quantity Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Manage Quantity</span></li>
<li><span>Manage Quantity Details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-----section for lightbox opens here-->

         <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
        </div>
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Manage PO Quantity Details</h2>
</header>
<div class="panel-body">
    
     <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <?php
    echo form_open('submit_manage_approve_po');?>
    <input type="hidden" name="po_id" value="<?php if(!empty($po_id)){echo $po_id;};?>">
<div class="col-md-12 col-sm-12">
                    <?php
                    if(!empty($result))
                        {?>
                
                        <table class="table table-responsive" border="1" >
                            <thead>
                                <th>#</th>
                                <th>Item</th>
                                <th>Original Quantity</th>
                                <th>Partially Approved Quantity</th>
                                <th>New Quantity</th>
                                <th>Remaining Quantity</th>
                            </thead>
                            <tbody>
                                <?php
                                $quantityy=explode('|#|',$result[0]->po_qnty);
                                if(!empty($result[0]->new_qnty))
                                    $new_qnty_val=explode(',', $result[0]->new_qnty);
                                else
                                    $new_qnty_val=0;
                                
                                 if(!empty($result[0]->remaining_qnty))
                                    $remain_qnty_val=explode(',', $result[0]->remaining_qnty);
                                else
                                    $remain_qnty_val=0;


                                 if(!empty($result[0]->approved_qnty))
                                    $approved_qnty=explode(',', $result[0]->approved_qnty);
                                else
                                    $approved_qnty=0;


                                                                 
                            $k=1; $p=1;
                                foreach ($prd_data as $key => $value) 
                                {
                                    ?>
                                <tr>
                                    <td ><?php echo $k++;?></td>
                                    <td ><?php echo $value[0]->pname;?><input type="hidden" name=""></td>
                                    <td>Quantity : <span class="org_qnty_<?php echo $p;?>"><?php echo $quantityy[$key];?></span></td>
                                    <td><input type="text" readonly="" name="approved_qnty[]" class="approved_qnty_<?php echo $p;?>" value="<?php if(!empty($approved_qnty)){echo $approved_qnty[$key];}else{echo '0';}?>"></td>
                                    <td><input type="text" class="new_quantity_<?php echo $p;?>" name="new_qnty[]" value="0" onkeyup="get_remaining(<?php echo $p;?>);" <?php if($remain_qnty_val[$key]=='0'){echo "readonly";}?>></td>
                                    <td><input type="text" class="remaining_quantity_<?php echo $p;?>" name="remaining_qnty[]" value="0" <?php if($remain_qnty_val[$key]=='0'){echo "readonly";}?>></td>
                                </tr>
                                <?php
                                $p++;
                               }
                            ?>
                            </tbody>
                        </table>
                        <?php
                            }
                        ?>
        
                </div>



<button type="submit" class="btn btn-primary btn-md">Submit</button>
<?php 
echo form_close();?>

</div>
</section>
<!-----section for lighbox closes here--->

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
    function get_remaining(id) 
    {
        var org_qnty=$('.org_qnty_'+id).text();
       var approved_qnty= $('.approved_qnty_'+id).val();
        var new_qnty=$('.new_quantity_'+id).val();

        if(approved_qnty!='0')
        {
              var remaining=parseFloat(org_qnty)-(parseFloat(approved_qnty)+parseFloat(new_qnty));
        }
        else
        {
              var remaining=parseFloat(org_qnty)-parseFloat(new_qnty);
        }
      

        $('.remaining_quantity_'+id).val(remaining);
    }
</script>

</body>
</html>

