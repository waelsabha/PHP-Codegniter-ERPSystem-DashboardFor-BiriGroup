<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/morris/morris.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/pie_country.css" />

<style type="text/css">
    .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

  .datepicker{z-index:18000 !important}

  /*.load-image{
    position:fixed;
  z-index:10000;
  }*/
  .printable { display: none; }

@media print
{
    .non-printable { display: none; }
    .printable { display: block; }
}
@-webkit-keyframes glowing {
  0% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -webkit-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
}

@-moz-keyframes glowing {
  0% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -moz-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
}

@-o-keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

@keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}
</style>

</head>
<body>
<section class="body">
<div class="non-printable">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Dashboard</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Dashboard</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>



<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg"><?php echo $this->lang->line('PRODUCTION ORDER'); ?>
<div class="row">
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-tertiary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-shopping-cart"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $this->lang->line('NEW ORDERS'); ?></h4>
<div class="info">
<strong>
<?php if(!empty($new_order)){print_r($new_order);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-info">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-thumbs-up"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $this->lang->line('ACCEPTED ORDERS'); ?></h4>
<div class="info">
<strong>
<?php if(!empty($approved_order)){print_r($approved_order);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-warning">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-gears"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $this->lang->line('ON PRODUCTION'); ?></h4>
<div class="info">
<strong>
<?php if(!empty($on_production)){print_r($on_production);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-primary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-truck"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $this->lang->line('READY FOR DELIVERY'); ?></h4>
<div class="info">
<strong>
<?php if(!empty($delivery_ready)){print_r($delivery_ready);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-success">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-check"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $this->lang->line('DELIVERED'); ?></h4>
<div class="info">
<strong>
<?php if(!empty($delivered)){print_r($delivered);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>

<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-danger">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-trash-o"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $this->lang->line('REJECTED ORDERS'); ?></h4>
<div class="info">
<strong>
<?php if(!empty($rejected)){print_r($rejected);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>

</div>
</div>

</div>


<!--closing row-->
  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>



<?php  $this->load->view('admin/production/prd_order/all_pending',$result);?>

<?php  $this->load->view('admin/production/prd_order/all_approved',$result2);?>

<?php  $this->load->view('admin/production/prd_order/all_production',$result3);?>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Delivery Ready</h2>
<p class="panel-subtitle">All Orders which are ready for delivery</p>
</header>
<div class="panel-body">

<div class="data_result">

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default5">
<thead>
<tr>
  <th ></th>
<th><?php echo $this->lang->line('Sales Person'); ?></th> 
<th><?php echo $this->lang->line('Delivery Date'); ?></th>
<th><?php echo $this->lang->line('Last date of delivery'); ?></th>
<th><?php echo $this->lang->line('Delivery Location'); ?></th>
<th>Item Details</th>
<th><?php echo $this->lang->line('Status'); ?></th>
<th><?php echo $this->lang->line('Action'); ?></th>

</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($result4))
{
foreach($result4 as $index1=>$t)
{
  $delivery_date=$t->po_date_delivry;

    if(!empty($t->po_dlvry_days))
    {
     // echo "in if";
       $days_remaining=$t->po_dlvry_days;
       $date_got = strtotime("+".$days_remaining." day", strtotime($delivery_date));
     $final_date=date('Y-m-d',$date_got);
    }
  else{
    //echo " in else";
    $final_date=$delivery_date;
  }

  $lnToday = date("Y-m-d");
$date_diff=strtotime($final_date)-strtotime($lnToday);
$final_date_diff=round($date_diff / (60 * 60 * 24));

if($final_date_diff==2)
{
  // $style_color="#ffc107";//yellow
  $styles="
  background-color: #ffc107;
  color: white;";
}
elseif($final_date_diff<=1)
{
  $styles="
  background-color: #da0606;
  color: white;
  -webkit-animation: glowing 1500ms infinite;
  -moz-animation: glowing 1500ms infinite;
  -o-animation: glowing 1500ms infinite;
  animation: glowing 1500ms infinite;";
  // $style_color="";//red
}
else{
   $styles="
  background-color: darkgreen;
  color: white;";
//  $style_color="darkgreen";//green
}

  $qnty=explode('|#|',$t->po_qnty);
$wgt=explode('|#|',$t->po_wgt);
$req=explode('|#|',$t->po_spcl_rq);  
$rmks=explode('|#|',$t->po_rmks);
 $pckg_type=explode('|#|',$t->po_pck_type);

 if(!empty($t->new_qnty))
$qty_to_show=explode(',',$t->new_qnty);
else
$qty_to_show=explode('|#|',$t->po_qnty);
?>
<tr class="gradeX" >
      <td width='2%'><?php echo $i++;?></td>
      <td><?php echo $t->po_sales_person;?></td>
       <td><?php echo $delivery_date;?></td>
       <?php
       if(!empty($t->po_dlvry_days))
      {?>
      <td>
         <button type="button" style="<?php echo $styles;?>"><?php echo $final_date;?></button>
        <br/>
        <?php echo ' <br/>(includes '.$t->po_dlvry_days.' days of extended days)';?></td>
      <?php
      }
      else{?>
    <td> <button type="button" style="<?php echo $styles;?>"><?php echo $final_date;?></button></td>
        <?php
      }?>
      <td><?php echo $t->po_delivery_loc;?></td>
     <td>
        <table class="table table-bordered">
          <thead>
            <th><?php echo $this->lang->line('Product Name'); ?> </th> 
           <th><?php echo $this->lang->line('Quantity'); ?></th> 
           <?php
           if(!empty($t->new_qnty))
            {?>
            <th> Quantity Ready</th>
            <?php
            }?>
            <th><?php echo $this->lang->line('Weight'); ?></th>
          </thead>
          <tbody>
             <?php
          foreach($prd_data4[$index1] as $index2=>$p)
          {
             $prd_name_db=explode('|~~|',$p['pname']);
             $prod_code=$p['pcode'];
            ?>
            <tr>
              <td><?php
               if(empty($prod_code))
            echo $prd_name_db[0].'<br/>'.$prd_name_db[1];
          else
             echo $prod_code;?></td>

              <td>
                <?php
                if(!empty($t->po_qnty))
                 echo $qnty[$index2];
                 else
                     echo "0"; ?> 
              </td>
               <?php
           if(!empty($t->new_qnty))
            {?>
              <td>
                <?php
                if(!empty($t->approved_qnty))
                {
                  $aprv_qnty=explode(',',$t->approved_qnty);
                  echo $aprv_qnty[$index2];
                }
                else
                     echo "0"; ?> 
              </td>
              <?php
            }?>
              <td>
                <?php
                  if(!empty($wgt[$index2]))
                   echo $wgt[$index2];
                   else
                     echo "0"; ?> 
              </td>
            </tr>
          <?php
          }?>
          </tbody>
        </table>
      </td>
    
 <td>
   <?php 
    $remaining_qnty=explode(',',$t->remaining_qnty);
    if(!empty(array_filter($remaining_qnty)))
  {
    echo "PARTIALLY READY FOR DELIVERY <br/>";
  }
  else
  {
 echo $this->lang->line('READY FOR DELIVERY'); echo "<br/>";
 ?>
 <button type="button" class="btn btn-sm btn-primary" onclick="delivered(<?php echo $t->po_id;?>)">Click when -<?php echo $this->lang->line('DELIVERED');?></button> 
  <?php 
  }
  ?> 
  </td>
      <td>  
      <div class="dropdown-primary dropdown">
<button class="btn btn-sm btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">

<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalLG<?php echo $t->po_id;?>"><i class="fa fa-eye"></i>View</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalsm3<?php echo $t->po_id;?>"><i class="fa fa-pen"></i>Add Delivery Note</a>
<div class="dropdown-divider"></div>
	<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('po_history/'.$t->po_id);?>">Check history</a>
				
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('generate_po_pdf/'.$t->po_id);?>">Generate PDF</a>
<div class="dropdown-divider"></div><br/>
<button type="button" class="btn btn-sm btn-danger" onclick="reject_order(<?php echo $t->po_id;?>);"><?php echo $this->lang->line('REJECTED ORDERS'); ?></button>
</div>
</div> 
      </td>
  </tr>
  
   <!-- Button trigger modal 3 to add delivery notes-->
  <div id="modalsm3<?php echo $t->po_id;?>" class="modal-block modal-block-md modal-header-color modal-block-info mfp-hide" data-backdrop="static" data-keyboard="false" >
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Final Delivery Note</h2>
</header>
<?php echo form_open('submit_po_delivery_note');?>
<input type="hidden" value="<?php echo $t->po_id;?>" name="po_id">
 
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
        
    <div class="form-group">
    <label class="col-md-3 control-label" for="inputSuccess">Enter Delivery Note</label>
    <div class="col-md-6">
    <textarea name="delivery_note" class="form-control">   </textarea>
    </div>
</div>
    
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit" class="btn btn-primary">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!----end modal---> 

<!--------modal to view----------->
<div class="printable">
<div id="modalLG<?php echo $t->po_id;?>" class="modal-block modal-block-lg modal-header-color modal-block-info mfp-hide" data-backdrop="static" data-keyboard="false">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"><?php echo $t->po_id;?>&nbsp;&nbsp;&nbsp;<?php if(!empty($t->po_survey_dept)){echo "PO Linked to survey No. #".$t->po_survey_dept;};?></h2>
<br/><small><p style="color:white;">Date Created: <?php echo $t->po_dt_crt;?></p></small>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
  <div class="col-md-12 col-sm-12">
    <div class="col-md-12" style="margin-bottom: 2%;">
      <div class="col-md-4">
        <b><?php echo $this->lang->line('Sales Person'); ?>:</b><br/> <?php echo $t->po_sales_person;?><br/>       
      </div>

      <div class="col-md-4">
      <b><?php echo $this->lang->line('Delivery Date'); ?>:</b> <?php echo $t->po_date_delivry;?><br/>
        <b><?php echo $this->lang->line('Is expected delivery same as delivery date?'); ?></b><?php 
        if(empty($t->po_dlvry_days))
          {echo "Yes";}
        else{echo "No";}?><br/>
        <?php
        if(!empty($t->po_dlvry_days))
        {
        echo"<b> ".$this->lang->line('Extended Delivery Date')."</b>: ". $t->po_dlvry_days." days<br/>";  
        }
        ?>         
      </div>
      <div class="col-md-4">
        <b><?php echo $this->lang->line('Delivery Location'); ?>:</b><br/> <?php echo $t->po_delivery_loc;?>
      </div>    
    </div>

   <div class="col-md-12 col-sm-12 col-xs-12" style="margin-bottom: 2%;">
       <div class="col-md-6 col-sm-12 col-xs-12" >
      <p><b><?php echo $this->lang->line('Special Customer request:'); ?></b> 
        <?php if(!empty($t->po_specl_customer_req)){ echo $t->po_specl_customer_req;}?></p>
      </div>

       <div class="col-md-6 col-sm-12 col-xs-12" >
      <p><b><?php echo $this->lang->line('Download attachments:'); ?> </b>
      
        <?php if(!empty($t->po_files))
        {
          $files_attached=explode(',',$t->po_files);
          foreach($files_attached as $t)
          {
             $file_parts = pathinfo($t);
            if(($file_parts['extension']=="jpeg")||($file_parts['extension']=="jpg")||($file_parts['extension']=="png")||($file_parts['extension']=="PNG"))
            {
            
              echo "<a href='".base_url('uploads/production/prod_files/'.$t)."' target='_blank'><img src='".base_url('/uploads/production/prod_files/').$t."' width='100' height='100' ></a>";echo "";
            }
            else
            {
           ?>
           <a href="<?php echo base_url('uploads/production/prod_files/'.$t);?>" target="_blank"><?php echo $t;?></a><br/>
           <?php
           }
          }
       }?></p>
      </div>

    </div>


    <div class="col-md-12" style="border: 1px solid black;">
     <?php
         foreach($prd_data4[$index1] as $index2=>$p)
          {
             if(empty($p['p_prd_img']))
            {
              $filename="https://birigroup.com/uploads/prd_images/".$p['pcode'].'.jpeg';
             if (file_exists($filename)) {
              $img_path=$filename;
              } else {
              $img_path="https://birigroup.com/uploads/prd_images/".$p['pcode'].'.jpg';
                }
            }
           else
           {
            $first_img_prd=explode(',',$p['p_prd_img']);
            if(!empty($first_img_prd[0]))
            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
            else
            $img_path="https://birigroup.com/uploads/prd_images/".$p['p_prd_img'];
           }
             echo'<div class="col-md-6 col-sm-6">';
            echo'<img src="'.$img_path.'" width="100" height="100">';
           echo '</div>';
           echo'<div class="col-md-6 col-sm-6">';
            $prd_name_db=explode('|~~|',$p['pname']);
            echo $prd_name_db[0].',';
            echo "<br/>";
            echo '<b>Code :</b>'.$p['pcode'];
            echo "<br/>";
            echo '<b>Quantity :</b>'.$qnty[$index2];
            echo "<br/>";
            echo '<b>Weight :</b>'.$wgt[$index2];
            echo "<br/>";
            echo '<b>Package Type :</b>'.$pckg_type[$index2];
            echo "<br/>";
            echo '<b>Special Request :</b>'.$req[$index2];
            echo "<br/>";
            echo '<b>Remarks :</b>'.$rmks[$index2];echo "<br/><hr/>";
             echo '</div>';
          }
          ?>
    </div>
    
  </div>


</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-default modal-dismiss">Close</button>
</div>
</div>
</footer>
</section>
</div> 
</div>

<?php 
}
}?>

</tbody>
</table>
</div>


</div>
</section>


</section>


</div>

</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-appear/jquery.appear.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>


<script type="text/javascript">
 $(document).ready(function()
    {
      $('.choose_other_dlvry_date').hide();
       $(".load-image").hide();
    
   var days_delivery=$("input[name='exact_dlvry_date']:checked").val();
    if(days_delivery=="no")
    {
      $('.choose_other_dlvry_date').show();
    }
    else{
       $('.choose_other_dlvry_date').hide();
    }

    $('input:radio').change(function() {
      var delivery_days = $("input[name='exact_dlvry_date']:checked").val();
      if(delivery_days=="no")
      {
        $('.choose_other_dlvry_date').show();
      }
      if(delivery_days=="yes")
      {
        $('.choose_other_dlvry_date').hide();
      }   
      });

        
         $('#datatable-default2').DataTable( {//////pending table
              rowReorder: {
            selector: 'td:nth-child(2)'
              },
                 "pageLength": 50,
          responsive: true,
           "scrollX": true,
        });

         $('#datatable-default3').DataTable( {///approved table
              rowReorder: {
            selector: 'td:nth-child(2)'
              },
                 "pageLength": 50,
          responsive: true,
           "scrollX": true,
        });

         $('#datatable-default4').DataTable( {////on_prod table
              rowReorder: {
            selector: 'td:nth-child(2)'
              },
                "pageLength": 50,
          responsive: true,
           "scrollX": true,
        });

         $('#datatable-default5').DataTable( {///ready_delivery table
              rowReorder: {
            selector: 'td:nth-child(2)'
              },
                 "pageLength": 50,
          responsive: true,
           "scrollX": true,
        });

        //  $('#datatable-default6').DataTable( {////delivered
        //       rowReorder: {
        //     selector: 'td:nth-child(2)'
        //       },
        //   responsive: true,
        //    "scrollX": true,
        // });
});


 function approve_order(id)
 {
    jQuery.ajax({
             url:"<?php echo base_url().'Admin_PO/approve_order';?>",
                type:"post",
                data:{"po_id":id},
                beforeSend: function(){
                 $(".load-image").show();
               },
               complete: function(){
                 $(".load-image").hide();
               },
                success:function(result)
                {
                  if(result==1)
                    location.reload();
                  else
                  {
                    new PNotify({
                      title: 'Error',
                      text: 'Unable to send email.Please try again.',
                      type: 'error'
                    });
                  }
                  //console.log(result);
                }
            });
 }

 function on_production(id,type)
 {
    jQuery.ajax({
             url:"<?php echo base_url().'Admin_PO/on_production';?>",
                type:"post",
                data:{"po_id":id,"po_type":type},
                success:function(result)
                {
                  if(result==1)
                    location.reload();
                  //console.log(result);
                }
            });
 }

 function dlvry_ready(id,type)
 {
    jQuery.ajax({
             url:"<?php echo base_url().'Admin_PO/dlvry_ready';?>",
                type:"post",
                data:{"po_id":id,"po_type":type},
                success:function(result)
                {
                  if(result==1)
                    location.reload();
                  //console.log(result);
                }
            });
 }

 function delivered(id)
 {
    jQuery.ajax({
             url:"<?php echo base_url().'Admin_PO/delivered';?>",
                type:"post",
                data:{"po_id":id},
                success:function(result)
                {
                  if(result==1)
                    location.reload();
                  //console.log(result);
                }
            });
 }

 function reject_order(id)
 {
    jQuery.ajax({
             url:"<?php echo base_url().'Admin_PO/rejected';?>",
                type:"post",
                data:{"po_id":id},
                success:function(result)
                {
                  if(result==1)
                    location.reload();
                  //console.log(result);
                }
            });
 }

 function approve_var(){
    var data=[];
    var table_count=$(".num_items").text();
  $('select[name="variation_select[]"]').find("option:selected").each(function(){
    //console.log($('select[name="variation_select[]"]').val());
    // var label = $(this).parent().attr("label");  
        data.push($(this).val()+'\n');
          // values based on each group ??
       /// id = $(this).parent().attr("id");
    });
   $('.var_selected'+table_count).text(data.join(""));
   $('.var_selected'+table_count).append($('input[name="variation_selected_val"]').val(data.join("|#|")));

  }
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker();
            });
        </script>

</body>

</html>