<section class="panel">
<header class="panel-heading">

<h2 class="panel-title"> <?php echo $this->lang->line('ON PRODUCTION'); ?> </h2>
<p class="panel-subtitle">All Orders under production</p>
</header>
<div class="panel-body">

<div class="data_result">

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default4">
<thead>
<tr>
  <th ></th>
<th><?php echo $this->lang->line('Sales Person'); ?></th> 
<th><?php echo $this->lang->line('Delivery Date'); ?></th>
<th><?php echo $this->lang->line('Last date of delivery'); ?></th>
<th><?php echo $this->lang->line('Delivery Location'); ?></th>
<th>Item Details</th>
<th><?php echo $this->lang->line('Status'); ?></th>
<th><?php echo $this->lang->line('Action'); ?></th>
</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($result3))
{
foreach($result3 as $index1=>$t)
{
  $delivery_date=$t->po_date_delivry;

    if(!empty($t->po_dlvry_days))
    {
     // echo "in if";
       $days_remaining=$t->po_dlvry_days;
       $date_got = strtotime("+".$days_remaining." day", strtotime($delivery_date));
     $final_date=date('Y-m-d',$date_got);
    }
  else{
    //echo " in else";
    $final_date=$delivery_date;
  }

  $lnToday = date("Y-m-d");
$date_diff=strtotime($final_date)-strtotime($lnToday);
$final_date_diff=round($date_diff / (60 * 60 * 24));

if($final_date_diff==2)
{
  // $style_color="#ffc107";//yellow
  $styles="
  background-color: #ffc107;
  color: white;";
}
elseif($final_date_diff<=1)
{
  $styles="
  background-color: #da0606;
  color: white;
  -webkit-animation: glowing 1500ms infinite;
  -moz-animation: glowing 1500ms infinite;
  -o-animation: glowing 1500ms infinite;
  animation: glowing 1500ms infinite;";
  // $style_color="";//red
}
else{
   $styles="
  background-color: darkgreen;
  color: white;";
//  $style_color="darkgreen";//green
}

  $qnty=explode('|#|',$t->po_qnty);
$wgt=explode('|#|',$t->po_wgt);
$req=explode('|#|',$t->po_spcl_rq);  
$rmks=explode('|#|',$t->po_rmks);
$pckg_type=explode('|#|',$t->po_pck_type);

if(!empty($t->new_qnty))
$qty_to_show=explode(',',$t->new_qnty);
else
$qty_to_show=explode('|#|',$t->po_qnty);
?>
<tr class="gradeX">
      <td width='2%'><?php echo $i++;?></td>
      <td><?php echo $t->po_sales_person;?></td>
       <td><?php echo $delivery_date;?></td>
       <?php
       if(!empty($t->po_dlvry_days))
      {?>
      <td>
         <button type="button" style="<?php echo $styles;?>"><?php echo $final_date;?></button>
        <br/>
        <?php echo '(includes '.$t->po_dlvry_days.' days of extended days)';?></td>
      <?php
      }
      else{?>
    <td> <button type="button" style="<?php echo $styles;?>"><?php echo $final_date;?></button></td>
        <?php
      }?>
      <td><?php echo $t->po_delivery_loc;?></td>
      <td>
        <table class="table table-bordered">
          <thead>
            <th><?php echo $this->lang->line('Product Name'); ?> </th> 
           <?php
            if(!empty($t->new_qnty))
              {?>
            <th>Partial Quantity</th>
            <?php
              }
              else
              {
              ?>
               <th><?php echo $this->lang->line('Quantity'); ?></th> 
              <?php
              }?>
            <th><?php echo $this->lang->line('Weight'); ?></th>
          </thead>
          <tbody>
             <?php
          foreach($prd_data3[$index1] as $index2=>$p)
          {
             $prd_name_db=explode('|~~|',$p['pname']);
             $prod_code=$p['pcode'];
            ?>
            <tr>
              <td><?php
               if(empty($prod_code))
            echo $prd_name_db[0].'<br/>'.$prd_name_db[1];
          else
             echo $prod_code;?></td>
              <td>
                <?php
                if(!empty($qty_to_show[$index2]))
                 echo $qty_to_show[$index2];
                 else
                     echo "0"; ?> 
              </td>
              <td>
                <?php
                  if(!empty($wgt[$index2]))
                   echo $wgt[$index2];
                   else
                     echo "0"; ?> 
               </td>
            </tr>
          <?php
          }?>
          </tbody>
        </table>
      </td>
       
    
 <td>
    <?php 
   $remaining_qnty=explode(',',$t->remaining_qnty);
    if(!empty(array_filter($remaining_qnty)))
  {
    
    echo "PARTIALLY ON PRODUCTION <br/>";
  ?>
      
     <button type="button" class="btn btn-sm btn-primary" onclick="dlvry_ready(<?php echo $t->po_id;?>,'partially')">Click when -Ready for delivery</button>
    <?php      
  }
    else
  {     
  echo $this->lang->line('ON PRODUCTION'); echo "<br/>";
    ?>
       <button type="button" class="btn btn-sm btn-primary" onclick="dlvry_ready(<?php echo $t->po_id;?>,'fully')">Click when -Ready for delivery</button>
      <?php
   }
?>

<!--<a class="mb-xs mt-xs mr-xs btn btn-default pull-right" data-toggle="modal" data-target="#modalBootstrap"> Ready for Delivery</a>-->

 
   </td>

   <div class="modal fade" id="modalBootstrap" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
<h4 class="modal-title" id="myModalLabel">Product Components data</h4>
</div>
<div class="modal-body">

  <div class="tabs">
<ul class="nav nav-tabs nav-justified">
<li class="active">
<a href="#popular10" data-toggle="tab" class="text-center"><i class="fa fa-star"></i> Components Used</a>
</li>
<li>
<a href="#recent10" data-toggle="tab" class="text-center">Machinery Used</a>
</li>
</ul>
<div class="tab-content">
<div id="popular10" class="tab-pane active">


<?php
 foreach($prd_data3[$index1] as $index2=>$prd_tab)
{
    $prd_name_db=explode('|~~|',$prd_tab['pname']);
$prd_component=explode(',',$prd_tab['prc_comp_name']);
  $prd_qty=explode(',',$prd_tab['prc_qnty']);
  $prd_unit=explode(',',$prd_tab['prc_unit']);
  ?>
  <h4><?php echo $prd_name_db[0];?> </h4>
<div class="row">
<div class="col-md-12">

<div class="col-lg-4 col-md-4 col-sm-12">
  <p>Component Name : <span></span> </p> 
</div>
<div class="col-lg-4 col-md-4 col-sm-12">
  <p>Component Quantity : <span></span> </p> 
</div>
<div class="col-lg-4 col-md-4 col-sm-12">
  <p>Component Unit : <span></span> </p> 
</div>

</div> 

<div class="col-md-12">
<?php 
foreach($prd_component as $key_pc=>$pc)
{
?>
  <div class="col-md-12">
<div class="col-lg-4 col-md-4 col-sm-12">
  <p><?php echo $pc;?></p> 
</div>
<div class="col-lg-4 col-md-4 col-sm-12">
 <input type="text" value="<?php echo $prd_qty[$key_pc];?>" name="">
</div>
<div class="col-lg-4 col-md-4 col-sm-12">
 <p> <?php echo $prd_unit[$key_pc];?></p>

</div>
</div>
<?php
}?>
</div> 
</div>
<?php
}
?>

</div>
<div id="recent10" class="tab-pane">
<p>Machinery Used </p>

<?php
 foreach($prd_data3[$index1] as $index2=>$prd_tab)
{
    $prd_name_db=explode('|~~|',$prd_tab['pname']);
$mc_name=explode(',',$prd_tab['mc_name']);
  $mc_sub_name=explode('#',$prd_tab['mc_sub_name']);
 
  ?>
  <h4><?php echo $prd_name_db[0];?> - <span><?php echo $prd_tab['pcode'];?></span></h4>
<div class="row">


<div class="col-md-12">
<?php 
foreach($mc_name as $key_mc=>$mc)
{
   $mc_sub_name_1=$mc_sub_name[$key_mc];
 $mc_sub_name_2=explode(',',$mc_sub_name_1);
?>
  
<div class="col-lg-12 col-md-12 col-sm-12">
  <p><b>Machine Category :<?php echo $mc;?></b></p> 
</div>


<?php
foreach($mc_sub_name_2 as $key_mc=>$mc2)
  {
    ?>
<div class="col-lg-12 col-md-12 col-sm-12">
    <p><b>Machine Name :<?php echo $mc2;?></b></p> 
</div>

<div class="col-lg-6 col-md-4 col-sm-12">
<input type="text" value="" name="" placeholder="hours used">
</div>

<div class="col-lg-6 col-md-4 col-sm-12">
<input type="text" value="" name="" placeholder="minutes used">
</div>


<?php
}?>


<?php
}?>
</div> 
</div>
<?php
}
?>
</div>
</div>
</div>
  
 

</div>
<div class="modal-footer">

<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>

      <td>  
         <div class="dropdown-primary dropdown">
<button class="btn btn-sm btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">

<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalLG<?php echo $t->po_id;?>"><i class="fa fa-eye"></i>View</a>
<div class="dropdown-divider"></div>
	<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('po_history/'.$t->po_id);?>">Check history</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('generate_po_pdf/'.$t->po_id);?>">Generate PDF</a>
<div class="dropdown-divider"></div><br/>
<button type="button" class="btn btn-sm btn-danger" onclick="reject_order(<?php echo $t->po_id;?>);">Reject Order</button>
</div>
</div>
      </td>
  </tr>
  
<!--------modal to view----------->
<div class="printable">
<div id="modalLG<?php echo $t->po_id;?>" class="modal-block modal-block-lg modal-header-color modal-block-info mfp-hide" data-backdrop="static" data-keyboard="false">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"><?php echo $t->po_id;?>&nbsp;&nbsp;&nbsp;<?php if(!empty($t->po_survey_dept)){echo "PO Linked to survey No. #".$t->po_survey_dept;};?></h2>
<br/><small><p style="color:white;">Date Created: <?php echo $t->po_dt_crt;?></p></small>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
  <div class="col-md-12 col-sm-12">
    <div class="col-md-12" style="margin-bottom: 2%;">
      <div class="col-md-4">
        <b><?php echo $this->lang->line('Sales Person'); ?>:</b><br/> <?php echo $t->po_sales_person;?><br/>       
      </div>

      <div class="col-md-4">
      <b><?php echo $this->lang->line('Delivery Date'); ?>:</b> <?php echo $t->po_date_delivry;?><br/>
        <b><?php echo $this->lang->line('Is expected delivery same as delivery date?'); ?></b><?php 
        if(empty($t->po_dlvry_days))
          {echo "Yes";}
        else{echo "No";}?><br/>
        <?php
        if(!empty($t->po_dlvry_days))
        {
        echo"<b>".$this->lang->line('Extended Delivery Date')." </b>: ". $t->po_dlvry_days." days<br/>";  
        }
        ?>         
      </div>
      <div class="col-md-4">
        <b><?php echo $this->lang->line('Delivery Location'); ?>:</b><br/> <?php echo $t->po_delivery_loc;?>
      </div>    
    </div>

   <div class="col-md-12 col-sm-12 col-xs-12" style="margin-bottom: 2%;">
       <div class="col-md-6 col-sm-12 col-xs-12" >
      <p><b><?php echo $this->lang->line('Special Customer request:'); ?> </b>
        <?php if(!empty($t->po_specl_customer_req)){ echo $t->po_specl_customer_req;}?></p>
      </div>

       <div class="col-md-6 col-sm-12 col-xs-12" >
      <p><b><?php echo $this->lang->line('Download attachments:'); ?></b>
      
        <?php if(!empty($t->po_files))
        {
          $files_attached=explode(',',$t->po_files);
          foreach($files_attached as $t)
          {
             $file_parts = pathinfo($t);
            if(($file_parts['extension']=="jpeg")||($file_parts['extension']=="jpg")||($file_parts['extension']=="png")||($file_parts['extension']=="PNG"))
            {
            
              echo "<a href='".base_url('uploads/production/prod_files/'.$t)."' target='_blank'><img src='".base_url('/uploads/production/prod_files/').$t."' width='100' height='100' ></a>";echo "";
            }
            else
            {
           ?>
           <a href="<?php echo base_url('uploads/production/prod_files/'.$t);?>" target="_blank"><?php echo $t;?></a><br/>
           <?php
           }
          }
       }?></p>
      </div>

    </div>


    <div class="col-md-12" style="border: 1px solid black;">
         <?php
         foreach($prd_data3[$index1] as $index2=>$p)
          {
             if(empty($p['p_prd_img']))
            {
              $filename="https://birigroup.com/uploads/prd_images/".$p['pcode'].'.jpeg';
             if (file_exists($filename)) {
              $img_path=$filename;
              } else {
              $img_path="https://birigroup.com/uploads/prd_images/".$p['pcode'].'.jpg';
                }
            }
           else
           {
            $first_img_prd=explode(',',$p['p_prd_img']);
            if(!empty($first_img_prd[0]))
            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
            else
            $img_path="https://birigroup.com/uploads/prd_images/".$p['p_prd_img'];
           }
             echo'<div class="col-md-6 col-sm-6">';
            echo'<img src="'.$img_path.'" width="100" height="100">';
           echo '</div>';
           echo'<div class="col-md-6 col-sm-6">';
            $prd_name_db=explode('|~~|',$p['pname']);
            echo $prd_name_db[0].',';
            echo "<br/>";
            echo '<b>Code :</b>'.$p['pcode'];
            echo "<br/>";
            echo '<b>Quantity :</b>'.$qnty[$index2];
            echo "<br/>";
            echo '<b>Weight :</b>'.$wgt[$index2];
            echo "<br/>";
            echo '<b>Package Type :</b>'.$pckg_type[$index2];
            echo "<br/>";
            echo '<b>Special Request :</b>'.$req[$index2];
            echo "<br/>";
            echo '<b>Remarks :</b>'.$rmks[$index2];echo "<br/><hr/>";
             echo '</div>';
          }
          ?>
     
    </div>
    
  </div>


</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-default modal-dismiss">Close</button>
</div>
</div>
</footer>
</section>
</div> 
</div>


<?php 
}
}?>

</tbody>
</table>
</div>


</div>
</section>