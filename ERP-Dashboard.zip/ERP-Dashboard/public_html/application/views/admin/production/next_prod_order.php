<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Order Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Order Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<?php
echo form_open('update_variations');?>
<input type="hidden" name="order_id" value="<?php echo $prd_order[0]->po_id;?>">
<?php
foreach($prd_data as $t)
{
	$prd_name=explode('|~~|',$t[0]->pname);
	$var_names=explode(',',$t[0]->p_variation);
	$var_vals=explode(',',$t[0]->p_variation_types);
	//print_r($t[0]->pname);
	?>
<section class="panel panel-featured panel-featured-primary">
<header>
	<h2 class="panel-title"><?php echo $prd_name[0] ;?></h2>
</header>
<div class="panel-body">
<!-- 	<form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->

<h4>Available Variations: Based on <?php echo $t[0]->p_variation;?></h4>
<div class="row">

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Values<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<select multiple data-plugin-selectTwo class="form-control populate variation_type" name="variation_select[]">
	<?php
				//$var_val=$v->v_val;
				$var_val=explode(',', $v->v_val);

				foreach($var_vals as $val)
				{
					?>
				<option value="<?php echo $val;?>"> <?php echo $val;?></option>;
			<?php
			}		
		?>
</select>


<div class="form_error">  <?php echo $this->session->flashdata('sales_person');?></div>
</div>
</div>
</div>

</div>



</div>
</section>
<?php
}?>


<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary"> Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
<!-- submit_main_form -->
<?php
echo form_close();?>
</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>


<script type="text/javascript">
	$(document).ready(function()
	{
		$('.search_product_select').hide()
		$("input[name='search_product']").on("keyup", function(e) {
       		 var key_code = e.which || e.keyCode;
   			if(key_code=="32")	
   			{
   				var to_search=$("input[name='search_product']").val();
   				 jQuery.ajax({
                     url:"<?php echo base_url().'Product_order/search_product';?>",
                    type:"post",
                     data:{"to_search":to_search},
                    success:function(result)
                    {
                    	//$('.search_product_input').hide();
                    	$('.search_product_select').show();
                    	$('.search_product_select').html(result);
console.log(result);
                    }
                });
   			}
		});

		$('.search_product_select').on("change",function(e)
		{
			var prd_name=$('.search_product_select :selected').text();
			//$('.prd_name').html(prd_name);
		var table_data=$('.new_rows').length;
		var i=table_data;
		var new_quantity='0';
		
var search_prd_id=$('.search_product_select :selected').val();
		
		    var markup = "<tr>"+
		    "<td><input type='hidden' name='prd_id[]' value='"+search_prd_id+"'><input type='hidden' name='prdids'>" + prd_name + "</td><td><input type='hidden' name='qntys'>"+
		    "<input type='number' class='qnty_val' name='qnty[]'></td>"+
		     "<td><input type='hidden' name='wgts'> <input type='number' name='wgt[]'></td><td><input type='hidden' name='pck_types'><input type='text' value='Standard Packaging' name='pck_size[]' ></td>"+
		      "<td><input type='hidden' name='spcl_rqts'><input type='text' name='spcl_req[]'></td><td><input type='hidden' name='remark'><input type='text' name='remarks[]'></td>"+
		    "</tr>";
            $("table tbody").append(markup);
		 var rowcount = $('table tbody tr').length;
		 $(".num_items").html(rowcount);
//init the array products
// arrprd=[];
//  arrprd.push(search_prd_id);
//  $("input[name='prd_id[]']").val(arrp);
		
			//if()
		});
		// $('input[name="qnty[]"]').on("change paste keyup",function(e)
		// {
		// 	alert("on change");
		// 	console.log('in qnty val');
		//  var inital_quantity=$("input[name='qnty[]']").val();
		//  console.log(inital_quantity);
		//  var new_quantity=parseInt(new_quantity)+parseInt(inital_quantity);
		//  $(".num_qnty").html(new_quantity);
		// console.log(new_quantity);
		// });

  	});

$('.myform').submit(function() {
	
var rowcount = $('table tbody tr').length;
var quantity=$('table tbody tr td input[name="qnty[]"]').map(function(){return $(this).val();}).get().join('|#|');  

var weight=$('table tbody tr td input[name="wgt[]"]').map(function(){return $(this).val();}).get().join('|#|');

var spcl_req=$('table tbody tr td input[name="spcl_req[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var package_size=$('table tbody tr td input[name="pck_size[]"]').map(function(){return $(this).val();}).get().join('|#|');

var product_id=$('table tbody tr td input[name="prd_id[]"]').map(function(){return $(this).val();}).get().join('|#|');

var remarks=$('table tbody tr td input[name="remarks[]"]').map(function(){return $(this).val();}).get().join('|#|');

console.log(quantity+' '+package_size+' '+product_id);

$("input[name='prdids']").val(product_id);
$("input[name='qntys']").val(quantity);
$("input[name='wgts']").val(weight);
$("input[name='pck_types']").val(package_size);
if(spcl_req=="")
	$("input[name='spcl_rqts']").val(spcl_req);
else
	$("input[name='spcl_rqts']").val(spcl_req);

if(remarks=="")
	$("input[name='remark']").val();
else
	$("input[name='remark']").val(remarks);


	$('table tbody tr td').each(function() {
    var cellText = $(this).html(); 
    console.log(cellText);  
    $('.myform').append(cellText); 
});

//console.log($("input[name='prdids']").val());
 if(cellText=='')
 	return false;
  else
	 return true;
  // your code here
});
	
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
		tinymce.init({
			selector : '.editors',
			  plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
		});
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('#datetimepicker4').datetimepicker();
            });
        </script>

</body>

</html>