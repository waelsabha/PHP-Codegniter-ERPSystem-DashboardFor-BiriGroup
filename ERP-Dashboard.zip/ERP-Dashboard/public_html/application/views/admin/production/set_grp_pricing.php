<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Set Product Grpous Price </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Set Price</span></li>

</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<section class="panel">
<header class="panel-heading">

<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Products Standard Pricing</h2>
<small>Here you will be creating products groups for standard pricing</small>
</header>
<div class="panel-body">

<?php echo form_open('Item_costing/submit_set_pricing','class="form-horizontal mb-lg extra-form"');?>
 
 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>


<div class="row">

<!-----=====================table col-12 starts here===================---->
<h4>Group 1:BASE</h4>
<div class="form-group">
	<?php
	$a=1;
		if(!empty($base))
			{
    		foreach($base as $index=>$b)
    		{
    			?>
    		
    		<input type="hidden" name="edit_prd_id[]" value="<?php if(!empty($result[$index])){if($result[$index]->pps_prd_id==$b->gc_id){echo $result[$index]->pps_id;}};?>">

<div class="col-md-12 col-sm-12 table-rows-border">
	<div class="col-md-2">
	<div class="form-group base_name">
		<?php echo $b->gc_grp_sub_name;?>
		
	<input type="hidden" name="base_name_prd[]" value="<?php echo $b->gc_grp_sub_name;?>">
	<input type="hidden" name="prd_id[]" value="<?php echo $b->gc_id;?>">


	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Width (in cm) <abbr class="required">::*::</abbr></label>
		

		  <input type="text" name="width_base[]" class="form-control base_width_<?php echo $a;?>"  value="<?php if(!empty($result[$index])){if($result[$index]->pps_prd_id==$b->gc_id){echo $result[$index]->pps_width;}}else{echo "0";};?>" >
 
	</div>
	</div>

	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Length (in cm) <abbr class="required">::*::</abbr></label>
		
		 <input type="text" name="length_base[]" class="form-control base_len_<?php echo $a;?>"  value="<?php if(!empty($result[$index])){if($result[$index]->pps_prd_id==$b->gc_id){echo $result[$index]->pps_length;}}else{echo "0";};?>"  class="form-control">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Unit Price <abbr class="required">::*::</abbr></label>
	


              <input type="text" name="unit_price_base[]" value="<?php if(!empty($result[$index])){if($result[$index]->pps_prd_id==$b->gc_id){echo $result[$index]->pps_unit_price;}}else{echo "0";};?>" onkeyup="base_unit_price(<?php echo $a;?>)" class="form-control price_base_<?php echo $a;?>">


		 	</div>
	</div>
	
	<div class="col-md-2">			
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Price / SQM<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price/(wid*len))</small>-->
		
         <input type="text" name="price_base[]" readonly=""  value="<?php if(!empty($result[$index])){if($result[$index]->pps_prd_id==$b->gc_id){echo $result[$index]->pps_price;}}else{echo "0";};?>" class="form-control base_final_price_<?php echo $a;?>">

		 	</div>
	</div>



	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Add Percentage<abbr class="required">::*::</abbr></label>

	
		 	 <input type="text" name="percenatge_base[]" value="<?php if(!empty($result[$index])){if($result[$index]->pps_prd_id==$b->gc_id){echo $result[$index]->pps_added_per;}}else{echo "0";};?>"  class="form-control base_per_<?php echo $a;?>" onkeyup="base_percentage(<?php echo $a;?>)">
		 
	</div>
	</div>

	<div class="col-md-2">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Final Price<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price*% added)</small>-->
		

		  <input type="text" name="final_base[]" readonly="" value="<?php if(!empty($result[$index])){if($result[$index]->pps_prd_id==$b->gc_id){echo $result[$index]->pps_final_price;}}else{echo "0";};?>" class="form-control final_base_<?php echo $a;?>">
		 
	</div>
	</div>


			
</div>
	<?php
	$a++;
    		}
    	}?>
</div><hr/>
<!-----=====================table col-12 ends here===================---->

<!-----=====================table col-12 starts here===================---->
<h4>Group 2:REFLECTIVE</h4>
<div class="form-group">
	<?php
	$j=1;
$new_index_1=$index+1;
			if(!empty($reflective))
			{
				foreach($reflective as $index_r=>$r)
				{

			?>
	<input type="hidden" name="edit_refl_id[]" value="<?php if(!empty($result_reflective[$index_r])){if($result_reflective[$index_r]->pps_prd_id==$r->gc_id){echo $result_reflective[$index_r]->pps_id;}};?>">

<div class="col-md-12 col-sm-12 table-rows-border">
	<div class="col-md-2">
	<div class="form-group">
	<?php echo $r->gc_grp_sub_name;?>
	<input type="hidden" name="reflective[]" value="<?php echo $r->gc_grp_sub_name;?>">
	<input type="hidden" name="reflective_id[]" value="<?php echo $r->gc_id;?>">
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Width (in cm) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="width_reflective[]" class="form-control refl_width_<?php echo $j;?>"  value="<?php if(!empty($result_reflective[$index_r])){if($result_reflective[$index_r]->pps_prd_id==$r->gc_id){echo $result_reflective[$index_r]->pps_width;}}else{echo "0";};?>"  class="form-control">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Length (in cm) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="length_reflective[]" class="form-control refl_len_<?php echo $j;?>"  value="<?php if(!empty($result_reflective[$index_r])){if($result_reflective[$index_r]->pps_prd_id==$r->gc_id){echo $result_reflective[$index_r]->pps_length;}}else{echo "0";};?>"  class="form-control">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Unit Price <abbr class="required">::*::</abbr></label>
		 <input type="text" name="unit_price_reflective[]" value="<?php if(!empty($result_reflective[$index_r])){if($result_reflective[$index_r]->pps_prd_id==$r->gc_id){echo $result_reflective[$index_r]->pps_unit_price;}}else{echo "0";};?>" onkeyup="reflective_unit_price(<?php echo $j;?>)" class="form-control price_refl_<?php echo $j;?>">
		 
	</div>
	</div>
	
	<div class="col-md-2">			
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Price / SQM<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price/(wid*len))</small>-->
		 <input type="text" name="price_reflective[]" readonly=""  value="<?php if(!empty($result_reflective[$index_r])){if($result_reflective[$index_r]->pps_prd_id==$r->gc_id){echo $result_reflective[$index_r]->pps_price;}}else{echo "0";};?>" class="form-control refl_final_price_<?php echo $j;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Add Percentage<abbr class="required">::*::</abbr></label>
		 <input type="text" name="percenatge_reflective[]" value="<?php if(!empty($result_reflective[$index_r])){if($result_reflective[$index_r]->pps_prd_id==$r->gc_id){echo $result_reflective[$index_r]->pps_added_per;}}else{echo "0";};?>" onkeyup="reflective_percentage(<?php echo $j;?>)"  class="form-control refl_per_<?php echo $j;?>">
		 
	</div>
	</div>

	<div class="col-md-2">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Final Price<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price*% added)</small>-->
		 <input type="text" name="final_reflective[]" readonly="" value="<?php if(!empty($result_reflective[$index_r])){if($result_reflective[$index_r]->pps_prd_id==$r->gc_id){echo $result_reflective[$index_r]->pps_final_price;}}else{echo "0";};?>" class="form-control final_reflective_<?php echo $j;?>">
		 
	</div>
	</div>
			
</div>
<?php
			$j++;	$new_index_1++; }
			}
			?>
</div><hr/>
<!-----=====================table col-12 ends here===================---->


<!-----=====================table col-12 starts here===================---->
<h4>Group 3:PRINTING</h4>
<div class="form-group">
	<?php
	$k=1;
	$new_index_2=$new_index_1;

			if(!empty($printing))
			{
				foreach($printing as $index_pr=>$pr)
				{
					?>
<input type="hidden" name="edit_print_id[]" value="<?php if(!empty($result_print[$index_pr])){if($result_print[$index_pr]->pps_prd_id==$pr->gc_id){echo $result_print[$index_pr]->pps_id;}};?>">	

<div class="col-md-12 col-sm-12 table-rows-border">
	<div class="col-md-2">
	<div class="form-group">
		<?php echo $pr->gc_grp_sub_name;?>
		<input type="hidden" name="printing[]" value="<?php echo $pr->gc_grp_sub_name;?>">
			<input type="hidden" name="print_id[]" value="<?php echo $pr->gc_id;?>">
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Width (in cm) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="width_printing[]"  value="<?php if(!empty($result_print[$index_pr])){if($result_print[$index_pr]->pps_prd_id==$pr->gc_id){echo $result_print[$index_pr]->pps_width;}}else{echo "0";};?>"  class="form-control print_width_<?php echo $k;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Length (in cm) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="length_printing[]"  value="<?php if(!empty($result_print[$index_pr])){if($result_print[$index_pr]->pps_prd_id==$pr->gc_id){echo $result_print[$index_pr]->pps_length;}}else{echo "0";};?>"  class="form-control print_len_<?php echo $k;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Unit Price <abbr class="required">::*::</abbr></label>
		 <input type="text" name="unit_price_printing[]" value="<?php if(!empty($result_print[$index_pr])){if($result_print[$index_pr]->pps_prd_id==$pr->gc_id){echo $result_print[$index_pr]->pps_unit_price;}}else{echo "0";};?>"  class="form-control price_print_<?php echo $k;?>" onkeyup="printing_unit_price(<?php echo $k;?>)">
		 
	</div>
	</div>
	
	<div class="col-md-2">			
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Price / SQM<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price/(wid*len))</small>-->
		 <input type="text" name="price_print[]" readonly=""  value="<?php if(!empty($result_print[$index_pr])){if($result_print[$index_pr]->pps_prd_id==$pr->gc_id){echo $result_print[$index_pr]->pps_price;}}else{echo "0";};?>" class="form-control print_final_price_<?php echo $k;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Add Percentage<abbr class="required">::*::</abbr></label>
		 <input type="text" name="percenatge_printing[]" value="<?php if(!empty($result_print[$index_pr])){if($result_print[$index_pr]->pps_prd_id==$pr->gc_id){echo $result_print[$index_pr]->pps_added_per;}}else{echo "0";};?>"  class="form-control print_per_<?php echo $k;?>" onkeyup="printing_percentage(<?php echo $k;?>)" >
		 
	</div>
	</div>

	<div class="col-md-2">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Final Price<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price*% added)</small>-->
		 <input type="text" name="final_print[]" readonly="" value="<?php if(!empty($result_print[$index_pr])){if($result_print[$index_pr]->pps_prd_id==$pr->gc_id){echo $result_print[$index_pr]->pps_final_price;}}else{echo "0";};?>"  class="form-control final_print_<?php echo $k;?>">
		 
	</div>
	</div>
			
</div>
<?php
			$k++;	$new_index_2++;}
			}
			?>
</div><hr/>
<!-----=====================table col-12 ends here===================---->

<!-----=====================table col-12 starts here===================---->
<h4>Group 4:CHANNEL</h4>
<div class="form-group">

	<?php
	$p=1;
	$new_index_3=$new_index_2;
			if(!empty($channels))
			{
				foreach($channels as $index_ch=>$ch)
				{
					?>
<input type="hidden" name="edit_channel_id[]" value="<?php if(!empty($result_channel[$index_ch])){if($result_channel[$index_ch]->pps_prd_id==$ch->gc_id){echo $result_channel[$index_ch]->pps_id;}};?>">	

		<div class="col-md-12 col-sm-12 table-rows-border">			
	<div class="col-md-2">
	<div class="form-group">
				<?php echo $ch->gc_grp_sub_name;?>
				<input type="hidden" name="channel[]" value="<?php echo $ch->gc_grp_sub_name;?>">
			<input type="hidden" name="channel_id[]" value="<?php echo $ch->gc_id;?>">
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Width (in cm) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="width_channel[]"  value="<?php if(!empty($result_channel[$index_ch])){if($result_channel[$index_ch]->pps_prd_id==$ch->gc_id){echo $result_channel[$index_ch]->pps_width;}}else{echo "0";};?>"  class="form-control channel_width_<?php echo $p;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Length (in cm) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="length_channel[]"  value="<?php if(!empty($result_channel[$index_ch])){if($result_channel[$index_ch]->pps_prd_id==$ch->gc_id){echo $result_channel[$index_ch]->pps_length;}}else{echo "0";};?>"  class="form-control channel_len_<?php echo $p;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Unit Price <abbr class="required">::*::</abbr></label>
		 <input type="text" name="unit_price_channel[]" value="<?php if(!empty($result_channel[$index_ch])){if($result_channel[$index_ch]->pps_prd_id==$ch->gc_id){echo $result_channel[$index_ch]->pps_unit_price;}}else{echo "0";};?>"  class="form-control price_channel_<?php echo $p;?> " onkeyup="channel_unit_price(<?php echo $p;?>)">
		 
	</div>
	</div>
	
	<div class="col-md-2">			
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Price / SQM<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price/(wid*len))</small>-->
		 <input type="text" name="price_channel[]" readonly=""  value="<?php if(!empty($result_channel[$index_ch])){if($result_channel[$index_ch]->pps_prd_id==$ch->gc_id){echo $result_channel[$index_ch]->pps_price;}}else{echo "0";};?>"  class="form-control channel_final_price_<?php echo $p;?>" >
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Add Percentage<abbr class="required">::*::</abbr></label>
		 <input type="text" name="percenatge_channel[]" value="<?php if(!empty($result_channel[$index_ch])){if($result_channel[$index_ch]->pps_prd_id==$ch->gc_id){echo $result_channel[$index_ch]->pps_added_per;}}else{echo "0";};?>"  class="form-control channel_per_<?php echo $p;?>" onkeyup="channel_percentage(<?php echo $p;?>)">
		 
	</div>
	</div>

	<div class="col-md-2">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Final Price<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price*% added)</small>-->
		 <input type="text" name="final_channel[]" readonly="" value="<?php if(!empty($result_channel[$index_ch])){if($result_channel[$index_ch]->pps_prd_id==$ch->gc_id){echo $result_channel[$index_ch]->pps_final_price;}}else{echo "0";};?>"  class="form-control final_channel_<?php echo $p;?>" >
		 
	</div>
	</div>
	</div>
	<?php
			$p++;	$new_index_3++; }
			}
			?>
			

</div><hr/>
<!-----=====================table col-12 ends here===================---->
<!-----=====================table col-12 starts here===================---->
<h4>Group 5:PAINTING</h4>
<div class="form-group">

	
	<?php
	$s=1;
	$new_index_4=$new_index_3;
			if(!empty($painting))
			{
				foreach($painting as $index_pa=>$pa)
				{?>
	<input type="hidden" name="edit_paint_id[]" value="<?php if(!empty($result_paint[$index_pa])){if($result_paint[$index_pa]->pps_prd_id==$pa->gc_id){echo $result_paint[$index_pa]->pps_id;}};?>">	
					
	<div class="col-md-12 col-sm-12 table-rows-border">				
	<div class="col-md-2">
	<div class="form-group">
				<?php echo $pa->gc_grp_sub_name;?><br/>
				<input type="hidden" name="painting[]" value="<?php echo $pa->gc_grp_sub_name;?>">
				<input type="hidden" name="painting_id[]" value="<?php echo $pa->gc_id;?>">
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Width (in cm) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="width_painting[]"  value="<?php if(!empty($result_paint[$index_pa])){if($result_paint[$index_pa]->pps_prd_id==$pa->gc_id){echo $result_paint[$index_pa]->pps_width;}}else{echo "0";};?>"  class="form-control paint_width_<?php echo $s;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Length (in cm) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="length_painting[]"  value="<?php if(!empty($result_paint[$index_pa])){if($result_paint[$index_pa]->pps_prd_id==$pa->gc_id){echo $result_paint[$index_pa]->pps_length;}}else{echo "0";};?>"  class="form-control paint_len_<?php echo $s;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Unit Price <abbr class="required">::*::</abbr></label>
		 <input type="text" name="unit_price_painting[]" value="<?php if(!empty($result_paint[$index_pa])){if($result_paint[$index_pa]->pps_prd_id==$pa->gc_id){echo $result_paint[$index_pa]->pps_unit_price;}}else{echo "0";};?>"  class="form-control price_paint_<?php echo $s;?>" onkeyup="paint_unit_price(<?php echo $s;?>)">
		 
	</div>
	</div>
	
	<div class="col-md-2">			
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Price / SQM<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price/(wid*len))</small>-->
		 <input type="text" name="price_painting[]" readonly=""  value="<?php if(!empty($result_paint[$index_pa])){if($result_paint[$index_pa]->pps_prd_id==$pa->gc_id){echo $result_paint[$index_pa]->pps_price;}}else{echo "0";};?>" class="form-control paint_final_price_<?php echo $s;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Add Percentage<abbr class="required">::*::</abbr></label>
		 <input type="text" name="percenatge_painting[]" value="<?php if(!empty($result_paint[$index_pa])){if($result_paint[$index_pa]->pps_prd_id==$pa->gc_id){echo $result_paint[$index_pa]->pps_added_per;}}else{echo "0";};?>"  class="form-control paint_per_<?php echo $s;?>" onkeyup="paint_percentage(<?php echo $s;?>)">
		 
	</div>
	</div>

	<div class="col-md-2">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Final Price<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price*% added)</small>-->
		 <input type="text" name="final_painting[]" readonly="" value="<?php if(!empty($result_paint[$index_pa])){if($result_paint[$index_pa]->pps_prd_id==$pa->gc_id){echo $result_paint[$index_pa]->pps_final_price;}}else{echo "0";};?>" class="form-control final_paint_<?php echo $s;?>" >
		 
	</div>
	</div>
		</div>	
		<?php
	$s++; $new_index_4++; }
}?>
</div><hr/>
<!-----=====================table col-12 ends here===================---->


<!-----=====================table col-12 starts here===================---->
<h4>Group 5:POWDER COATING</h4>
<div class="form-group">

	
	<?php
	$w=1;
	$new_index_5=$new_index_4;
			if(!empty($powder_coating))
			{
				foreach($powder_coating as $index_pow=>$pow)
				{?>
	<input type="hidden" name="edit_pow_id[]" value="<?php if(!empty($result_pow[$index_pow])){if($result_pow[$index_pow]->pps_prd_id==$pow->gc_id){echo $result_pow[$index_pow]->pps_id;}};?>">	
					
	<div class="col-md-12 col-sm-12 table-rows-border">				
	<div class="col-md-2">
	<div class="form-group">
				<?php echo $pow->gc_grp_sub_name;?><br/>
				<input type="hidden" name="pow[]" value="<?php echo $pow->gc_grp_sub_name;?>">
				<input type="hidden" name="pow_id[]" value="<?php echo $pow->gc_id;?>">
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Width (in cm) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="width_pow[]"  value="<?php if(!empty($result_pow[$index_pow])){if($result_pow[$index_pow]->pps_prd_id==$pow->gc_id){echo $result_pow[$index_pow]->pps_width;}}else{echo "0";};?>"  class="form-control pow_width_<?php echo $w;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Length (in cm) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="length_pow[]"  value="<?php if(!empty($result_pow[$index_pow])){if($result_pow[$index_pow]->pps_prd_id==$pow->gc_id){echo $result_pow[$index_pow]->pps_length;}}else{echo "0";};?>"  class="form-control pow_len_<?php echo $w;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Unit Price <abbr class="required">::*::</abbr></label>
		 <input type="text" name="unit_price_pow[]" value="<?php if(!empty($result_pow[$index_pow])){if($result_pow[$index_pow]->pps_prd_id==$pow->gc_id){echo $result_pow[$index_pow]->pps_unit_price;}}else{echo "0";};?>"  class="form-control price_pow_<?php echo $w;?>" onkeyup="pow_unit_price(<?php echo $w;?>)">
		 
	</div>
	</div>
	
	<div class="col-md-2">			
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Price / SQM<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price/(wid*len))</small>-->
		 <input type="text" name="price_pow[]" readonly=""  value="<?php if(!empty($result_pow[$index_pow])){if($result_pow[$index_pow]->pps_prd_id==$pow->gc_id){echo $result_pow[$index_pow]->pps_price;}}else{echo "0";};?>" class="form-control pow_final_price_<?php echo $w;?>">
		 
	</div>
	</div>
	
	<div class="col-md-1">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Add Percentage<abbr class="required">::*::</abbr></label>
		 <input type="text" name="percenatge_pow[]" value="<?php if(!empty($result_pow[$index_pow])){if($result_pow[$index_pow]->pps_prd_id==$pow->gc_id){echo $result_pow[$index_pow]->pps_added_per;}}else{echo "0";};?>"  class="form-control pow_per_<?php echo $w;?>" onkeyup="pow_percentage(<?php echo $w;?>)">
		 
	</div>
	</div>

	<div class="col-md-2">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Final Price<abbr class="required">::*::</abbr></label>
		<!--<small>for calculation : use (price*% added)</small>-->
		 <input type="text" name="final_pow[]" readonly="" value="<?php if(!empty($result_pow[$index_pow])){if($result_pow[$index_pow]->pps_prd_id==$pow->gc_id){echo $result_pow[$index_pow]->pps_final_price;}}else{echo "0";};?>" class="form-control final_pow_<?php echo $w;?>" >
		 
	</div>
	</div>
		</div>	
		<?php
	$w++; $new_index_5++; }
}?>
</div><hr/>
<!-----=====================table col-12 ends here===================---->
</div>	

</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<!-- 	<button class="btn btn-warning" type="button" onclick="calculate_price();">Calculate Price</button> -->
<button class="btn btn-primary" type="submit">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>

</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">


	function base_unit_price(id)
	{
		var width_base=$('.base_width_'+id).val();
		var length_base=$('.base_len_'+id).val();
		var unit_price_base=$('.price_base_'+id).val();
		var wid_len_base=parseFloat(width_base)*parseFloat(length_base).toFixed(2); 
		var callc1=parseFloat(unit_price_base)/(parseFloat(wid_len_base)/10000);
		$('.base_final_price_'+id).val(callc1.toFixed(2));///use 10000 for meter to sqm

		/////if base percewntage found////
		var price_base=$('.base_final_price_'+id).val();
			var added_per_base=$('.base_per_'+id).val();
		var callc2=parseFloat(price_base*added_per_base)/100;
		$(".final_base_"+id).val(callc2.toFixed(2));
		////////////////end of base found////
	}

	function base_percentage(id)
	{
		var price_base=$('.base_final_price_'+id).val();
		var added_per_base=$('.base_per_'+id).val();
		var callc2=parseFloat(price_base*added_per_base)/100;
		$(".final_base_"+id).val(callc2.toFixed(2));
	}
/////////////////////////////////////for reflective///////////////////////////////////////////////////
	function reflective_unit_price(id)
	{
		var ref_width=$('.refl_width_'+id).val();
		var ref_len=$('.refl_len_'+id).val();
		var ref_price=$('.price_refl_'+id).val();
		
		var wid_len_base=parseFloat(ref_width)*parseFloat(ref_len).toFixed(2); 
		var callc1=parseFloat(ref_price)/(parseFloat(wid_len_base)/10000);
		$('.refl_final_price_'+id).val(callc1.toFixed(2));///use 10000 for meter to sqm

		/////if reflective percentage is found///
		var ref_final_per=$('.refl_final_price_'+id).val();
		var ref_per=$('.refl_per_'+id).val();

		var callc2=parseFloat(ref_final_per*ref_per)/100;
		$(".final_reflective_"+id).val(callc2.toFixed(2));
		////////end of found/////////
	}

	function reflective_percentage(id)
	{
		var ref_final_per=$('.refl_final_price_'+id).val();
		var ref_per=$('.refl_per_'+id).val();

		var callc2=parseFloat(ref_final_per*ref_per)/100;
		$(".final_reflective_"+id).val(callc2.toFixed(2));
	} 
/////////////////////////////////////end of reflective///////////////////////////////////////////////////

/////////////////////////////////////for printing///////////////////////////////////////////////////
function printing_unit_price(id)
	{
		var print_width=$('.print_width_'+id).val();
		var print_len=$('.print_len_'+id).val();
		var print_price=$('.price_print_'+id).val();
		
		var wid_len_base=parseFloat(print_width)*parseFloat(print_len).toFixed(2); 
		var callc1=parseFloat(print_price)/(parseFloat(wid_len_base)/10000);
		$('.print_final_price_'+id).val(callc1.toFixed(2));///use 10000 for meter to sqm

		//////if printing base is founc/////
		var print_final_per=$('.print_final_price_'+id).val();
		var print_per=$('.print_per_'+id).val();

		var callc2=parseFloat(print_final_per*print_per)/100;
		$('.final_print_'+id).val(callc2.toFixed(2));
		//////end of found///////
	}

	function printing_percentage(id)
	{
		var print_final_per=$('.print_final_price_'+id).val();
		var print_per=$('.print_per_'+id).val();

		var callc2=parseFloat(print_final_per*print_per)/100;
		$('.final_print_'+id).val(callc2.toFixed(2));
	} 
/////////////////////////////////////end of printing///////////////////////////////////////////////////

/////////////////////////////////////for channel///////////////////////////////////////////////////
function channel_unit_price(id)
	{
		var channel_width=$('.channel_width_'+id).val();
		var channel_len=$('.channel_len_'+id).val();
		var channel_price=$('.price_channel_'+id).val();
		
	var wid_len_base=parseFloat(channel_width)*parseFloat(channel_len).toFixed(2); 
		var callc1=parseFloat(channel_price)/(parseFloat(wid_len_base)/10000);
		$('.channel_final_price_'+id).val(callc1.toFixed(2));///use 10000 for meter to sqm

		//////////////if channnel per is found////
			var channel_final_per=$('.channel_final_price_'+id).val();
		var channel_per=$('.channel_per_'+id).val();

		var callc2=parseFloat(channel_final_per*channel_per)/100;
		$(".final_channel_"+id).val(callc2.toFixed(2));
		/////end of channel/////////
	}

	function channel_percentage(id)
	{
		var channel_final_per=$('.channel_final_price_'+id).val();
		var channel_per=$('.channel_per_'+id).val();

		var callc2=parseFloat(channel_final_per*channel_per)/100;
		$(".final_channel_"+id).val(callc2.toFixed(2));
	} 
/////////////////////////////////////end of channl///////////////////////////////////////////////////

/////////////////////////////////////for painting///////////////////////////////////////////////////
function paint_unit_price(id)
	{
		var paint_width=$('.paint_width_'+id).val();
		var paint_len=$('.paint_len_'+id).val();
		var paint_price=$('.price_paint_'+id).val();
		
		var wid_len_base=parseFloat(paint_width)*parseFloat(paint_len).toFixed(2); 
		var callc1=parseFloat(paint_price)/(parseFloat(wid_len_base)/10000);
		$('.paint_final_price_'+id).val(callc1.toFixed(2));///use 10000 for meter to sqm

		/////////////if found paint per//////
		var paint_final_per=$('.paint_final_price_'+id).val();
		var paint_per=$('.paint_per_'+id).val();

		var callc2=parseFloat(paint_final_per*paint_per)/100;
		$(".final_paint_"+id).val(callc2.toFixed(2));
		///////end of per///////////////////
	}

	function paint_percentage(id)
	{
		var paint_final_per=$('.paint_final_price_'+id).val();
		var paint_per=$('.paint_per_'+id).val();

		var callc2=parseFloat(paint_final_per*paint_per)/100;
		$(".final_paint_"+id).val(callc2.toFixed(2));
	} 
/////////////////////////////////////end of painting///////////////////////////////////////////////////
	
/////////////////////////////////////for painting///////////////////////////////////////////////////
function pow_unit_price(id)
	{
		var pow_width=$('.pow_width_'+id).val();
		var pow_len=$('.pow_len_'+id).val();
		var pow_price=$('.price_pow_'+id).val();
		
		var wid_len_base=parseFloat(pow_width)*parseFloat(pow_len).toFixed(2); 
		var callc1=parseFloat(pow_price)/(parseFloat(wid_len_base)/10000);
		$('.pow_final_price_'+id).val(callc1.toFixed(2));///use 10000 for meter to sqm

		/////////////if found paint per//////
		var pow_final_per=$('.pow_final_price_'+id).val();
		var pow_per=$('.pow_per_'+id).val();

		var callc2=parseFloat(pow_final_per*pow_per)/100;
		$(".final_pow_"+id).val(callc2.toFixed(2));
		///////end of per///////////////////
	}

	function pow_percentage(id)
	{
		var pow_final_per=$('.pow_final_price_'+id).val();
		var pow_per=$('.pow_per_'+id).val();

		var callc2=parseFloat(pow_final_per*pow_per)/100;
		$(".final_pow_"+id).val(callc2.toFixed(2));
	} 
/////////////////////////////////////end of painting///////////////////////////////////////////////////

</script>

</body>
</html>