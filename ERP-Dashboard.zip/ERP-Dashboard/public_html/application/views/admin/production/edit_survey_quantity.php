<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Edit Quantity Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Edit Quantity</span></li>
<li><span>Edit Quantity Details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-----section for lightbox opens here-->

		 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
	    </div>
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Edit Survey Quantity Details</h2>
</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <?php
    echo form_open('submit_edit_qty_survey');?>
    <input type="hidden" name="edit_survey_id" value="<?php echo $edit_survey_id;?>">
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none">
<thead>
<tr>

<th>Product Sets</th>
<th>Product Singles</th>
<th>Product PO (for quantity reference)</th>

</tr>
</thead>
<tbody>
<tr>
	<td>
		<table class="table table-bordered table-striped mb-none">
			<thead>
				<tr>
					<th>Image</th>
					<th>Quantity</th>
				</tr>
			</thead>
		<tbody>
		<?php
		if(!empty($prd_set_details))
		{
			 if(!empty($clearance_level))
								 	$clearance=$clearance_level;
								 else
								 		$clearance=0;

								 if(!empty($underground_pipe))	
								 	$undergrnd_hgt=$underground_pipe;
								 else
								 	$undergrnd_hgt=0;

								 $sum_road_hgt=$clearance+$undergrnd_hgt;

		foreach($prd_ids_1 as $index_p=>$p1)
					{
						$alignment=$prd_set_details[$index_p]->psd_prd_alignment;
						
						$prd_set_pipe_quantity[$index_p]=$prd_set_details[$index_p]->psd_pipe_qnty;
						$prd_set_quantity[$index_p]=$prd_set_details[$index_p]->psd_prd_qty;

						$prod_position=explode(',',$prd_set_details[$index_p]->psd_arrange_position);
						
						// pre_list($prod_position);
						// pre_list($p1);
						foreach($prod_position as $pd2)
						{
							if(empty($p1[$pd2][0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
								 }
 	
								 $prd_height[$index_p][]=$p1[$pd2][0]->prd_height;
								 $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
								 $prod_sets_image[$index_p][]=$img_path;
								 $prod_sets_alignment[$index_p]=$alignment;
								 $prod_sets_position[$index_p]=$prod_position;
								 $prd_set_id[$index_p]=$prd_set_details[$index_p]->psd_id;
						}
					}

					$ij=1;
					foreach($prod_sets_alignment as $index=>$align)
					{
						if($align=="vertical")
						{
							$sum_ary1=max($prd_height[$index]);
							$sum_vertical=$sum_ary1+$sum_road_hgt;
							//pre_list(implode(',',$prod_sets_image[$index]));
							echo "<tr>";
						echo "<td>";
						foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
								
								if(!empty($prod_sets_image[$index][$index22]))
							echo "<img src='".$prod_sets_image[$index][$index22]."' width='40' height='80'>";
							else
							echo "";
							}

							echo "</td>";
							if(!empty($prd_set_quantity[$index])){
							echo "<td><input type='text' class='prd_set_qty_".$ij."' name='new_quantity_prd_set[]' onkeyup='get_prd_set_qty(".$ij.")' value='".$prd_set_quantity[$index]."'>
							<input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'>
							</td>";
							}
							else
							{
							echo "<td><input type='text' class='prd_set_qty_".$ij."' name='new_quantity_prd_set[]' onkeyup='get_prd_set_qty(".$ij.")'>
							<input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'>
							</td>";
								}
							if(!empty($prd_set_pipe_quantity[$index])){
								echo "<td>Pipe Quantity: <span class='pipe_qnty_".$ij."'>".$prd_set_pipe_quantity[$index]."</span></td>";
							}
							else
							{
								echo "<td>Pipe Quantity: <span class='pipe_qnty_".$ij."'></span></td>";
							}
							echo "<td>Pipe Height:<span>".(ceil($sum_vertical / 10) * 10)." cm</span><input type='hidden' name='prd_set_pipe_hgt[]' value='".(ceil($sum_vertical / 10) * 10)."'></td>";
							echo "</tr>";
						}
						else
						{
							echo "<tr>";
							echo "<td>";
							$sum_ary2=array_sum($prd_height[$index]);
							$sum_horizontal=$sum_ary2+$sum_road_hgt;
							foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
										if(!empty($prod_sets_image[$index][$index22]))
							echo "<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
							else
							echo "";
							}
							echo "</td>";
							if(!empty($prd_set_quantity[$index])){
								echo "<td><input type='text' class='prd_set_qty_".$ij."' name='new_quantity_prd_set[]' onkeyup='get_prd_set_qty(".$ij.")' value='".$prd_set_quantity[$index]."'> 
							<input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'></td>";
							}
							else
							{
								echo "<td><input type='text' class='prd_set_qty_".$ij."' name='new_quantity_prd_set[]' onkeyup='get_prd_set_qty(".$ij.")'>
							<input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'></td>";
							}
							
							if(!empty($prd_set_pipe_quantity[$index])){
								echo "<td>Pipe Quantity: <span class='pipe_qnty_".$ij."'>".$prd_set_pipe_quantity[$index]."</span></td>";
							}
							else
							{
								echo "<td>Pipe Quantity: <span class='pipe_qnty_".$ij."'></span></td>";
							}
							
							echo "<td>Pipe Height:<span>".(ceil($sum_vertical / 10) * 10)." cm </span><input type='hidden' name='prd_set_pipe_hgt[]' value='".(ceil($sum_vertical / 10) * 10)."'></td>";
							echo "</tr>";
								
						}
						$ij++;
					}
				?>
		
		<?php
			
		}
		?>
		</tbody>
		</table>
	</td>
	<td>
	<?php
	if(!empty($survey_result[0]->st_single_prds))
		{?>
		<table class="table table-bordered table-striped mb-none">
			<thead>
				<tr>
					<th>Image</th>
					<th>Quantity</th>
				</tr>
			</thead>
		<tbody>
		<?php
		
					if(!empty($clearance_level))
								 	$clearance=$clearance_level;
								 else
								 		$clearance=0;

								 if(!empty($underground_pipe))	
								 	$undergrnd_hgt=$underground_pipe;
								 else
								 	$undergrnd_hgt=0;

								 $sum_road_hgt=$clearance+$undergrnd_hgt;
$ik=50;
$singl_prd_qty=explode(',',$survey_result[0]->st_single_prd_qtys);
$single_pipe_qty=explode(',',$survey_result[0]->st_single_pipe_qty);
			foreach($prd_ids_2 as $index2=>$pd2)
			{
				$heiht_sum=$sum_road_hgt+$pd2[0]->prd_height;
//pre_list($singl_prd_qty[$index2]);

				if(empty($pd2[0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$pd2[0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->p_prd_img;
								 }
								//  $prd_height=$pd3[0]->prd_height;
					 
			?>
		<tr>
			<td><img src="<?php echo $img_path;?>"  width='100' height='100'></td>
			<?php
			if(empty($singl_prd_qty[$index2]))
				{?>
			<td><input type="text" name="prd_single_quantity_new[]" class="prd_set_qty_<?php echo $ik;?>" onkeyup='get_prd_set_qty(<?php echo $ik;?>)'>
			</td>
			<td>Pipe Quantity:<span class='pipe_qnty_<?php echo $ik;?>'></span></td>
			<?php
			}
			else
			{?>
			<td><input type="text" name="prd_single_quantity_new[]" class="prd_set_qty_<?php echo $ik;?>" onkeyup='get_prd_set_qty(<?php echo $ik;?>)' value="<?php echo $singl_prd_qty[$index2];?>">
			</td>
			<td>Pipe Quantity:<span class='pipe_qnty_<?php echo $ik;?>'><?php echo $single_pipe_qty[$index2];?></span></td>
			<?php
			}?>
			
			<td>Pipe Height:<span><?php echo (ceil($heiht_sum / 10) * 10);?> cm</span><input type="hidden" value="<?php echo (ceil($heiht_sum / 10) * 10);?>" name="single_pipe_hgt[]"></td>
		</tr>
		<?php
		$ik++;
			}

		
		?>
		</tbody>
		</table>
		<?php
		}?>
	</td>
	<td>
		<table class="table table-bordered table-striped mb-none">
			<thead>
				<tr>
					<th>Image</th>
					<th>Quantity</th>
				</tr>
			</thead>
		<tbody>
		<?php
		if(!empty($prd_ids_3))
		{

			foreach($prd_ids_3 as $indeex=>$pd3)
			{
				if(empty($pd3[0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$pd3[0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$pd3[0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$pd3[0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$pd3[0]->p_prd_img;
								 }		
			?>
		<tr>
			<td><img src="<?php echo $img_path;?>"  width='100' height='100'></td>
			<td><?php echo $prd_po_qty[$indeex];?></td>
		</tr>
		<?php
			}
		}
		?>
		</tbody>
		</table>
	</td>
</tr>
<!-----------modal for setting installation date----->
<!---------end installation date---->


</tbody>
</table>

<button type="submit" class="btn btn-primary btn-md">Submit</button>
<?php 
echo form_close();?>
</div>
</div>
</section>
<!-----section for lighbox closes here--->

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	 $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
   <script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker().datepicker();
            });
        </script>
        <script type="text/javascript">
        	function get_prd_set_qty(ij)
        	{
        		var prd_set_qty=$('.prd_set_qty_'+ij).val();
        		$('.pipe_qnty_'+ij).html(prd_set_qty);
        	}

        
        </script>
</body>
</html>