<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2> List Pricing Amazon UK </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>UK</span></li>
<li><span>Pricing</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<section class="panel">
<header class="panel-heading">



<div class="panel-body">
	<p>NOTE: The Base values is coming from the product table in UK Website (make sure for your entry)</p>
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-bordered table-striped mb-none" id="datatable-default">
<thead>
<tr>
<th>image</th>
<th>Product Name</th>	
<th>SKU/Code </th>
<th>Web Price</th>
<th>Amazon FBA</th>
<th>Amazon FBM</th>

</tr>
</thead>
<tbody>
<?php
$i=1;
foreach($test as $index11=>$t)
{   


	$image=$t['thumbnail_img'];
if(!empty($image) )
{
  $path = "https://birigroup.co.uk/public/".$image;//this is the image path
  

}
else{
  $path = "https://birigroup.com/uploads/prd_images/no_image.jpg";//this is the image path



} 

$type = pathinfo($path, PATHINFO_EXTENSION);
  $data = file_get_contents($path);
  $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
		


?>
<tr class="gradeX">
			     <td><img class="img-fluid" src="<?php echo $base64;  ?>" style="max-height:100px;"></td>
            <td><?php echo $t['name'];?></td>
			<td><?php echo $t['sku'];?></td>	
			<td><?php echo $t['webprice_GBP'];?></td>	
			<td><?php echo $t['Amazon_fba'] ;?> <br> <a class="mb-xs mt-xs mr-xs modal-sizes modal-basic btn btn-success" href="#modalfba_<?php echo $t['id'];?>">New Fees</a> </td>	
		    <td><?php echo $t['Amazon_fbm'] ;?>  <br> <a class="mb-xs mt-xs mr-xs modal-sizes modal-basic btn btn-success" href="#modalfbm_<?php echo $t['id'];?>">New Fees</a> </td>

		    
		
	</tr>
	<!-----------modal for adding sub-group name----->
<div id="modalfba_<?php echo $t['id'];?>" class="modal-block  modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">FBA Fees</h2>
</header>
<div class="panel-body">
	<?php 
	echo form_open('Item_costing/submit_fba_fees_uk')?>
	<input type="hidden" name="main_prd_id" value="<?php echo $t['id'];?>">
	<input type="hidden" name="main_prd_code" value="<?php echo $t['sku'];?>">
<div class="modal-wrapper">
<label>FBA Fees</label>
<div class="modal-text">
<input type='text' name="fba_fees_amazon" class="form-control" value="<?php echo $t['fba_fees'];?>"  autocomplete="off" />
</div>
</div>






</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
	
<button class="btn btn-primary" type="submit">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
<?php 
echo form_close()?>
</div>
</div>
</footer>
</section>
</div>
<!---------end installation date---->

<!-----------modal for adding sub-group name----->
<div id="modalfbm_<?php echo $t['id'];?>" class="modal-block  modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add FBM Fees </h2>
</header>
<div class="panel-body">
	<?php 
	echo form_open('Item_costing/submit_fbm_fees_uk')?>
		<input type="hidden" name="main_prd_id" value="<?php echo $t['id'];?>">
	<input type="hidden" name="main_prd_code" value="<?php echo $t['sku'];?>">
<div class="modal-wrapper">
<label>FBM Fees</label>
<div class="modal-text">
<input type='text' name="fbm_fees_amazon" class="form-control" value="<?php echo $t['fbm_fees'];?>"  autocomplete="off" />
</div>
</div>


<div class="modal-wrapper">
<label>Amazon Shipping</label>
<div class="modal-text">
<input type='text' name="shipping_amazon" class="form-control" value="<?php echo $t['amazon_shipping'];?>"  autocomplete="off" />
</div>
</div>


<div class="modal-wrapper">
<label>Our Shipping</label>
<div class="modal-text">
<input type='text' name="shipping_our" class="form-control" value="<?php echo $t['our_shipping'];?>"  autocomplete="off" />
</div>
</div>






</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
	
<button class="btn btn-primary" type="submit">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
<?php 
echo form_close()?>
</div>
</div>
</footer>
</section>
</div>
<!---------end installation date---->
<?php 
}?>
</tbody>
</table>

</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">

	function add_text_field()
		{
			$('.new_txt_fld').append('<input type="text" name="add_sub_cat[]" class="form-control" style="border-color:black;" value="" />'); 
			return true;
		}
</script>

</body>
</html>