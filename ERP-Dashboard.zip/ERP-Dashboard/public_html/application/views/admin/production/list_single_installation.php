<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Single Installation Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Single Installation Details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-----section for lightbox opens here-->
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">List Single Installation Details</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th class="action_class">Action</th>

<th>Project Name</th>
<th>Installation Location</th>
<th>Date</th>
<th>Installation Type</th>
</tr>
</thead>
<tbody>
<?php
	if(!empty($result))
	{
		$i=1;
	foreach($result as $index=>$q)
	{		
?>
<tr>
<td class="action_class">
			<div class="dropdown-primary dropdown ">
<button class="btn btn-primary dropdown-toggle waves-effect waves-light" type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" onclick="increase_width()">Action </button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">
	<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalLG<?php echo $q->si_id;?>" ><i class="fa fa-eye"></i>View</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('single-installation/'.$q->si_id);?>"><i class="fa fa-pencil"></i>Edit Details</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="#modalsm2<?php echo $q->si_id;?>"><i class="fa fa-trash-o"></i>Delete </a>

</div>
	</td>
	
	<td><?php echo $q->si_prj_name;?></td>
	<td><?php echo $q->si_ins_loc;?> </td>
	<td><?php echo $q->si_ins_date;?></td>
	<td><?php 
	if($q->si_ins_type=='1')
	{
		echo "PO Based Installation";
	}
	elseif($q->si_ins_type=='2')
	{
		echo "Quotation Based Installation";
	}
	else
	{
		echo "New Installation";
	};?></td>
	

		
</tr>

<!-- Button trigger modal 3-->
 <div id="modalsm2<?php echo $q->si_id;?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Are You Sure?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<p>Are you sure, you want to delete this installation details permanently?
		</p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<a href="<?php echo base_url('delete_single_installation/'.$q->si_id);?>"  class="btn btn-primary">Confirm</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!----end modal--->

<div id="modalLG<?php echo $q->si_id;?>" class="modal-block modal-block-lg modal-header-color modal-block-info mfp-hide" data-backdrop="static" data-keyboard="false">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Project name :<?php echo $q->si_prj_name;?></h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
	<div class="col-md-12 col-sm-12">
		<div class="col-md-12" style="margin-bottom: 2%;">

			<div class="col-md-4">
				<b>Created by:</b><br/> <?php echo $q->si_user_name;?><br/>
				<b>Installation Date:</b><br/> <?php echo $q->si_ins_date;?><br/>
				<b>Installation Location:</b><br/> <?php echo $q->si_ins_loc;?><br/>
				
			</div>
		<div class="col-md-4">
				<p>Customer Company:<?php echo $q->si_cust_comp;?></p>
			<p>Customer Name:<?php echo $q->si_cust_name;?></p>
			
			<p>Customer Email:<?php echo $q->si_cust_email;?></p>
			<p>Customer Mobile:<?php echo $q->si_cust_mob;?></p>
			<p>Customer landline:<?php echo $q->si_cust_landline;?></p>
			</div>	
			<div class="col-md-4">
					<?php $labour_used=explode(',',$q->si_labour);?>
					<?php $vehicle_used=explode(',',$q->si_vehicle);?>
					<?php $tools_used=explode(',',$q->si_tools);?>

			<b>Vehicle's Used :</b> <br/>
			<?php 
			foreach($vehicle as $vh)
			{
				if(in_array($vh->veh_id,$vehicle_used))
				{
					echo $vh->veh_plate_no;
					echo "<br/>";
				}
			}?>
			<br/>
			<b>Labour Details:</b><br/>
			<?php 
			foreach($labour as $lb)
			{
				if(in_array($lb['ed_id'],$labour_used))
				{
					echo $lb['ed_name'];
					echo "<br/>";
				}
			}?><br/>
			<b>Tools Used:</b> <br/>
			<?php 
			foreach($tools as $tl)
			{
				if(in_array($tl->tool_id,$tools_used))
				{
					echo $tl->tool_name;
					echo "<br/>";
				}
			}?><br/>
					
			</div>
		</div>

		<div class="col-md-12 col-sm-12">
			<h2>Attachments</h2>
			<?php if(!empty($q->si_attachments))
			{
				$img_data=explode(',',$q->si_attachments);
				foreach ($img_data as $key => $value) {
					?>
					<a href="<?php echo base_url('uploads/single_installation/'.$value);?>" target="_blank"><?php echo $value;?></a>
					<br/>
					<?php
				}
			}
			?>
		</div>	

		<div class="col-md-12 col-sm-12">
			
			<p>Installation type: 
				<?php 
	if($q->si_ins_type=='1')
	{
		echo "PO Based Installation";
	}
	elseif($q->si_ins_type=='2')
	{
		echo "Quotation Based Installation";
	}
	else
	{
		echo "New Installation";
	};?>
			</p><br>
				<?php if($q->si_ins_type!='3')
				{
					if($q->si_ins_type=='1')
					{
					?>
					<p>Project Name: PO #<?php echo $q->si_item_choosed;?></p>
					<?php
				}
				else
					{
						foreach($quot_details as $qd)
						{
							$quot_id[]=$qd->q_id;
							$quot_name[]=$qd->q_sub;
						}
						?>
						<?php
						if(in_array($q->si_item_choosed, $quot_id))	
						{
							$index_quot_id=key($quot_id);
							?>
						
						<p>Project Name: <?php echo $quot_name[$index_quot_id];?></p>
						<?php
					}
					}?>
			<br/><btn class="btn btn-primary" onclick="get_item_details(<?php echo $q->si_id;?>,<?php echo $q->si_ins_type;?>)"> Click to see Item Details</btn><br/>
			<div class="type_data_result"></div>
			<?php
		}?>

		</div>			
	</div>
	


</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-default modal-dismiss">Close</button>
</div>
</div>
</footer>
</section>
</div> 
<?php
}
}
?>

</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	 $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );

	function get_item_details(id,type)
	{
		if(type!='3')
		{
			jQuery.ajax({
                     url:"<?php echo base_url().'Single_installation/get_type_details';?>",
                    type:"post",
                     data:{"inst_id":id,"instal_type":type},
                    success:function(result)
                    {
                    	$('.type_data_result').html(result);
                    }
                });
		}
		

	}
</script>

</body>
</html>