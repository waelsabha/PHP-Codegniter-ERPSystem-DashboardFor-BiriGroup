<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Product Entry Form</h2>
</header>
<div class="panel-body">
	<?php echo form_open_multipart('Production_entry/submit_prd');?>
		
 	
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

<input type="hidden" name="uae_final_l1" value="<?php echo $final_val[0]->pv_uae1;?>">
<input type="hidden" name="uae_final_l2" value="<?php echo $final_val[0]->pv_uae2;?>">

<input type="hidden" name="ksa_final" value="<?php echo $final_val[0]->pv_ksa;?>">
<input type="hidden" name="ksa_final_l1" value="<?php echo $final_val[0]->pv_ksa1;?>">
<input type="hidden" name="ksa_final_l2" value="<?php echo $final_val[0]->pv_ksa2;?>">

<input type="hidden" name="prd_id" value="<?php  if(!empty($result[0]->pid)) echo $result[0]->pid;?>">

<input type="hidden" name="prd_img" value="<?php  if(!empty($result[0]->p_prd_img)) echo $result[0]->p_prd_img;?>">

<input type="hidden" name="prd_datasheet" value="<?php  if(!empty($result[0]->p_datasheets)) echo $result[0]->p_datasheets;?>">

<input type="hidden" name="variation_label_val">

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<?php
if(!empty($result[0]->pname))
{
$pname=explode('|~~|',$result[0]->pname);
}?>
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Product Name(English)<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" class="form-control acc_amount" required="" name="pname_en" value="<?php  if(!empty($pname[0])) echo $pname[0];?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('pname_en');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Product Name(Arabic)<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" class="form-control acc_amount" required="" name="pname_ar" value="<?php  if(!empty($pname[1])) echo $pname[1];?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('pname_ar');?></div>
</div>
</div>

</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Product Type<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<select class="form-control populate" name="prd_type">
	<option value=""></option>
	<option value="Raw Material" <?php if((!empty($result[0]->ptype))){if($result[0]->ptype=="Raw Material"){echo "selected";}} ?> >Raw Material</option>
	<option value="Finished Good" <?php if((!empty($result[0]->ptype))){if($result[0]->ptype=="Finished Good"){echo "selected";}} ?>>Finished Good</option>
	<option value="Service Product" <?php if((!empty($result[0]->ptype))){if($result[0]->ptype=="Service Product"){echo "selected";}} ?>>Service Product</option>
</select>

 <div class="form_error">  <?php echo $this->session->flashdata('prd_type');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Brand<abbr class="required"></abbr></label>

<div class="col-md-8">


<div class="input-group btn-group">
<select class="form-control populate brand_type" name="brand">
		<option></option>
		<?php
		if(!empty($brands))
		{
			foreach($brands as $b)
			{
				?>
				<option value="<?php echo $b->bid;?>" <?php if((!empty($result[0]->pbrand))){if($result[0]->pbrand==$b->bid){echo "selected";}};?> > <?php echo $b->bname;?></option>;
			<?php
			}
		}
		else
		{}
		?>
	</select>
	<span class="input-group-addon">
<a class="modal-with-form" href="#modalForm1"><i class="fa fa-plus"></i></a>
</span>
<div id="modalForm1" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Brand</h2>
</header>
<div class="panel-body">
<div class="form-horizontal mb-lg" novalidate="novalidate">
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Brand Name<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="var_name" class="form-control"  />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Short Description</label>
<div class="col-sm-9">
<input type="text" name="var_val" class="form-control"  />
</div>
</div>

</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary modal-confirm" onclick="variation_form('brand');">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>


</div>	

<div class="form_error">  <?php echo $this->session->flashdata('brand');?></div>
</div>

</div>

</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Category <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<div class="input-group btn-group">
<select class="form-control populate main_cat" name="cat">
		<option></option>
		<?php
		if(!empty($cat))
		{
			foreach($cat as $c)
			{
				?>
				<option value="<?php echo $c->cid;?>" <?php if((!empty($result[0]->pcat))){if($result[0]->pcat==$c->cname){echo "selected";}};?> > <?php echo $c->cname;?></option>;
			<?php
			}
		}
		else
		{}
		?>
	</select>
	<span class="input-group-addon">
<a class="modal-with-form" href="#modalForm2"><i class="fa fa-plus"></i></a>
</span>
<div id="modalForm2" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Category</h2>
</header>
<div class="panel-body">
<div class="form-horizontal mb-lg extra-form" novalidate="novalidate">
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Category Name <abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="var_name" class="form-control"  />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Category Code</label>
<div class="col-sm-9">
<input type="text" name="var_val" class="form-control"  />
</div>
</div>

</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary modal-confirm" onclick="variation_form('main-cat');">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
</div>

 <div class="form_error">  <?php echo $this->session->flashdata('cat');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Sub-Category<abbr class="required">::*::</abbr></label>

<div class="col-md-8">

<div class="input-group btn-group">
<select class="form-control populate sub_cat_type" name="sub_cat">
		<?php
		if(!empty($result[0]->pcat_sub))
		{
			echo "<option value=".$result[0]->pcat_sub.">".$result[0]->pcat_sub."</option>";
		}
		else{}
		?>
	</select>
<span class="input-group-addon">
<a class="modal-with-form" href="#modalForm3"><i class="fa fa-plus"></i></a>
</span>
<div id="modalForm3" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Sub-Category</h2>
</header>
<div class="panel-body">
<div class="form-horizontal mb-lg extra-form" novalidate="novalidate">
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Select Parent Category<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
	<select class="form-control main_cat" name="var_name">
		<option></option>
		<?php
		if(!empty($cat))
		{
			foreach($cat as $c)
			{
				echo "<option value='".$c->cid."'>".$c->cname."</option>";
			}
			
		}
		else
		{}
		?>
	</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Sub-Category Name<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="var_val" class="form-control"  />
</div>
</div>

</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary modal-confirm" onclick="variation_form('sub-cat');">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
</div>

<div class="form_error">  <?php echo $this->session->flashdata('sub_cat');?></div>
</div>

</div>

</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
	<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Item Code<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" class="form-control" required="" name="itm_code" value="<?php  if(!empty($result[0]->pcode)) echo $result[0]->pcode;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('itm_code');?></div>
</div>
</div>

</div>

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">SKU<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" class="form-control" required="" name="sku" value="<?php  if(!empty($result[0]->psku)) echo $result[0]->psku;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('sku');?></div>
</div>
</div>

</div>

</div>


<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Bin Capacity <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Enter the maximum stock of the product for showing the alert"></i><abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" class="form-control" required="" name="bin_amt"  value="<?php if(!empty($result[0]->pbin_capacity)) echo $result[0]->pbin_capacity;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('bin_amt');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Alert Quantity <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Enter the minimum stock of the product for showing the alert"></i><abbr class="required">::*::</abbr></label>

<div class="col-md-8">

 <input type="text" class="form-control" required="" name="alrt_amt" value="<?php if(!empty($result[0]->palert_qnty)) echo $result[0]->palert_qnty;?>"> 
<div class="form_error">  <?php echo $this->session->flashdata('alrt_amt');?></div>
</div>

</div>

</div>
</div>


<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Product Weight<i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Enter the product weight in kg"></i><abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" class="form-control acc_amount" required="" name="prd_wgt" value="<?php  if(!empty($result[0]->p_wgt)) echo $result[0]->p_wgt;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('prd_wgt');?></div>
 <small>Product Weight in Kilogram</small>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Packing Sizes <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Enter the packing size. Calculated in cm."></i><abbr class="required">::*::</abbr></label>

<div class="col-md-8">
<section class="form-group-vertical">
<input class="form-control" type="text" name="pack_wdt" placeholder="Enter Width" value="<?php  if(!empty($result[0]->p_pack_width)) echo $result[0]->p_pack_width;?>">
<input class="form-control" type="text" name="pack_hgt" placeholder="Enter Height" value="<?php  if(!empty($result[0]->p_pack_hgt)) echo $result[0]->p_pack_hgt;?>">
<input class="form-control last" type="text" name="pack_lgt" placeholder="Enter Length" value="<?php  if(!empty($result[0]->p_pack_lgth)) echo $result[0]->p_pack_lgth;?>">
</section>
<small>All sizes are in cm</small>
<div class="form_error">  
	<?php echo $this->session->flashdata('pack_wdt');?>
	<?php echo $this->session->flashdata('pack_hgt');?>
	<?php echo $this->session->flashdata('pack_lgt');?>
</div>
</div>

</div>

</div>
</div>


<div class="row">
<div class="col-md-12 table-rows-border">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Is Variation available? <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="A variation is a value in which the product differs either in terms of color, size or material.Eg: A same product might be available in different colors like red,blue,green,etc. If there is any variation choose yes, else choose no."></i> <abbr class="required">::*::</abbr></label>
<div class="col-md-8">


 <label class="radio-inline">
		<input type="radio" name="variation_status" value="Yes"<?php if((!empty($result[0]->p_variation))){echo "checked";}?> > Yes
			</label>
			<label class="checkbox-inline">
			<input type="radio" name="variation_status" value="No" <?php if((empty($result[0]->p_variation))){echo "checked";}?> > No
</label>
 <div class="form_error">  <?php echo $this->session->flashdata('variation_status');?></div>
</div>
</div>

</div>
</div>
<div class="row">

<div class="col-md-12 table-rows-border">


<div class="form-group select_variation" >
<label class="col-md-4 control-label" for="inputPlaceholder">Select variations <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Select all available variations as per the data entered.You can choose multiple values."></i><abbr class="required">::*::</abbr>
	<small>Press 'Ctrl' key to select multiple items.(ctrl+click)</small>
</label>

<div class="col-md-8">
<div class="input-group btn-group">

<select class="form-control variation_type" name="variation_select[]" multiple="multiple" size="10%">
	<option></option>
	<?php
		if(!empty($variations))
		{
			foreach($variations as $main=>$v)
			{
				echo "
		<optgroup label='".$v->vname."' class='".$v->vname."'>";
				//$var_val=$v->v_val;
				$var_val=explode(',', $v->v_val);

				foreach($var_val as $main2=>$val)
				{
				if(!empty($result[0]->p_variation))
				{
					$var_name_table=$result[0]->p_variation;
					$new_var_names=explode('##',$var_name_table);
					$var_table=$result[0]->p_variation_types;
					$new_var_types=explode('##',$var_table);
					foreach($new_var_names as $index=>$new )
					{
						if($new==$v->vname)
						{
							$values_var=trim($new_var_types[$index],',');
						$values_variation=explode(',',$values_var);
						}
					}
				
					?>
				<option value="<?php echo $val;?>" 
			<?php if(isset($values_variation[$main2]))	
				{if($val==$values_variation[$main2])
			{echo "selected";}} ?> > <?php echo $val;?></option> 
				<?php
					
				}
				else
				{
					
					?>
				<option value="<?php echo $val;?>" <?php if((!empty($result[0]->p_variation_types))){if($result[0]->p_variation_types==$val){echo "selected";}};?> > <?php echo $val;?></option>;
				<?php	
				}
				?>
			<?php
			}
				
				echo "</optgroup>";
			}
			
		}
		else
		{}
		?>	
</select>
<span class="input-group-addon">
<a class="modal-with-form" href="#modalForm5"><i class="fa fa-plus"></i></a>
</span>
<div id="modalForm5" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add variations</h2>
</header>
<div class="panel-body">
<div class="form-horizontal mb-lg extra-form" novalidate="novalidate">
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Variation Name<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="var_name" class="form-control"  />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Variation Values
</label>

<div class="col-sm-9">
<input type="text" name="var_val" class="form-control"  />

<small>Please add Comma-seperated values only</small>
</div>
</div>

</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary modal-confirm" onclick="variation_form('variation_form');">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
</div>

<div class="form_error"> <?php echo $this->session->flashdata('variation_select');?></div>
</div>

</div>

</div>





<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Selling Price <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Selling Price is used for calculating the price of different levels of UAE and KSA pricing."></i><abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" class="form-control" required="" name="selling_price" value="<?php  if(!empty($result[0]->p_selling_price)) echo $result[0]->p_selling_price;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('selling_price');?></div>
</div>
</div>

</div>

<div class="col-md-6 col-sm-12">

<div class="col-md-6 col-sm-6">
<div class="form-group">
<label class="control-label">UAE Final</label>
<input type="text" name="uae_final" class="form-control uae_final"  value="<?php  if(!empty($result[0]->p_uae_final)) echo $result[0]->p_uae_final;?>">
 <div class="form_error">  <?php echo $this->session->flashdata('uae_final');?></div>
</div>
</div>  
<div class="col-md-6 col-sm-6">
<div class="form-group">
<label class="control-label">KSA Final</label>
<input type="text" name="ksa_final" class="form-control ksa_final" value="<?php  if(!empty($result[0]->p_ksa)) echo $result[0]->p_ksa;?>">
<div class="form_error">  <?php echo $this->session->flashdata('ksa_final');?></div>
</div>
</div> 

<div class="col-md-6 col-sm-6">
<div class="form-group">
<label class="control-label">UAE Level-1</label>
<input type="text" name="uae_final_l1" class="form-control uae_final_l1" value="<?php  if(!empty($result[0]->p_uae_l1)) echo $result[0]->p_uae_l1;?>">
<div class="form_error">  <?php echo $this->session->flashdata('uae_final_l1');?></div>
</div>
</div>  
<div class="col-md-6 col-sm-6">
<div class="form-group">
<label class="control-label">KSA Reg#1</label>
<input type="text" name="ksa_final_l1" class="form-control ksa_final_l1" value="<?php  if(!empty($result[0]->p_ksa_reg_1)) echo $result[0]->p_ksa_reg_1;?>">
<div class="form_error">  <?php echo $this->session->flashdata('ksa_final_l1');?></div>
</div>
</div> 

<div class="col-md-6 col-sm-6">
<div class="form-group">
<label class="control-label">UAE Level-2</label>
<input type="text" name="uae_final_l2" class="form-control uae_final_l2" value="<?php  if(!empty($result[0]->p_uae_l2)) echo $result[0]->p_uae_l2;?>">
 <div class="form_error">  <?php echo $this->session->flashdata('uae_final_l2');?></div>
</div>
</div>  
<div class="col-md-6 col-sm-6">
<div class="form-group">
<label class="control-label">KSA Companies</label>
<input type="text" name="ksa_final_l2" class="form-control ksa_final_l2" value="<?php  if(!empty($result[0]->p_ksa_comp_2)) echo $result[0]->p_ksa_comp_2;?>">
<div class="form_error">  <?php echo $this->session->flashdata('ksa_final_l2');?></div>
</div>
</div>
<div class="col-md-6 col-sm-6">

</div>  
<div class="col-md-6 col-sm-6">
<div class="form-group">
<label class="control-label">KSA Retails</label>
<input type="text" name="ksa_final_l3" class="form-control ksa_final_l3" value="<?php  if(!empty($result[0]->p_ksa_retail_3)) echo $result[0]->p_ksa_retail_3;?>">
<div class="form_error">  <?php echo $this->session->flashdata('ksa_final_l3');?></div>
</div>
</div>

</div>


</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Unit<i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Add unit"></i><abbr class="required">::*::</abbr></label>

<div class="col-md-8">

<div class="input-group btn-group">	
<select class="form-control populate unit_type" name="units">
		<option></option>
		<?php
		if(!empty($units))
		{
			foreach($units as $u)
			{
				?>
				<option value="<?php echo $u->uid;?>" <?php if((!empty($result[0]->punit))){if($result[0]->punit==$u->uid){echo "selected";}};?> > <?php echo $u->uname;?></option>;
			<?php
			}
				
			
		}
		else
		{}
		?>
</select>
<span class="input-group-addon">
<a class="modal-with-form" href="#modalForm4"><i class="fa fa-plus"></i></a>
</span>
<div id="modalForm4" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Unit</h2>
</header>
<div class="panel-body">
<div class="form-horizontal mb-lg extra-form" novalidate="novalidate">
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Unit Name<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="var_name" class="form-control"  />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Short Name<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="var_val" class="form-control"  />
</div>
</div>

</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary modal-confirm" onclick="variation_form('unit_form');">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
</div>

<div class="form_error">  <?php echo $this->session->flashdata('units');?></div>
</div>

</div>

</div>

<div class="col-md-6 col-sm-6">
	<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">VAT Percentage <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Enter the VAT percentage for the product.Enter the numeric percentage value only.No need to put the % value or sign."></i><abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="number" class="form-control" required="" name="vat" value="<?php  if(!empty($result[0]->p_vat_perc)) echo $result[0]->p_vat_perc;?>" > 
 <div class="form_error">  <?php echo $this->session->flashdata('vat');?></div>
 <small>VAT in percentage</small>
</div>
</div>
</div>

</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Purchase Price <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Purchase Price is the final product price."></i></label>
<div class="col-md-8">

 <input type="text" class="form-control" name="pur_price" value="<?php  if(!empty($result[0]->p_purchase_price)) echo $result[0]->p_purchase_price;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('pur_price');?></div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Country of orgin<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select data-plugin-selectTwo class="form-control populate" name="country">
		<option></option>
		<?php
		foreach($country as $c)
			{
				?>
		<option value="<?php echo $c->country_id;?>" <?php if((!empty($result[0]->p_country))){if($result[0]->p_country==$c->country_id){echo "selected";}} ?> ><?php echo $c->name;?></option>
		<?php
	}?>
	</select>
	 <div class="form_error">  <?php echo $this->session->flashdata('country');?></div>
</div>
</div>	
</div>
</div>


<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">HS Code<i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="HS Code of product"></i><abbr class="required">::*::</abbr></label>

<div class="col-md-8">

<div class="input-group btn-group">	
<select class="form-control populate hse_type" name="hse_code">
		<option></option>
		<?php
		if(!empty($hse_code))
		{
			foreach($hse_code as $h)
			{
				$name=explode('|~~|',$h->hse_name);

				?>
				<option value="<?php echo $h->hse_id;?>" <?php if((!empty($result[0]->p_hse_id))){if($result[0]->p_hse_id==$h->hse_id){echo "selected";}};?> > <?php echo $name[0].':'.$name[1];?></option>;
			<?php
			}	
		}
		else
		{}
		?>
</select>
<span class="input-group-addon">
<a class="modal-with-form" href="#modalForm6"><i class="fa fa-plus"></i></a>
</span>
<div id="modalForm6" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add HS Code</h2>
</header>
<div class="panel-body">
<div class="form-horizontal mb-lg extra-form" novalidate="novalidate">
<div class="form-group mt-lg">
<label class="col-sm-3 control-label"> English Name<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="var_name[]" class="form-control" />
</div>
</div>
<div class="form-group mt-lg">
<label class="col-sm-3 control-label"> Arabic Name<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="var_name[]" class="form-control"  />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">HS Code Value<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="var_val[]" class="form-control" />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Add recommendations / notes</label>
<div class="col-sm-9">
<input type="text" name="var_val[]" class="form-control" />
</div>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary modal-confirm" onclick="variation_form('hse_form');">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
</div>

<div class="form_error">  <?php echo $this->session->flashdata('hse_code');?></div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Hse Code<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<?php
	if((!empty($result[0]->p_hse_id)))
	{
		echo $result[0]->hse_code;	
	}
	?>
	<p class="hse_code_val"></p>
	
</div>
</div>	
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
	<label class="control-label">Product Description <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Product Description."></i><abbr class="required">::*::</abbr></label>
<textarea rows="5" class="form-control editors" name="prd_desc" placeholder=""><?php if(!empty($result[0]->p_desc)) echo $result[0]->p_desc;?></textarea>
</div>
<div class="form_error">  <?php echo $this->session->flashdata('prd_desc');?></div>
</div>	


<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Attach Product Image <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Attach the product image here.Choose multiple images,if any."></i><abbr class="required">::*::</abbr></label>

<div class="col-md-8">

 <input type="file" class="form-control" required="" name="prd_img[]" multiple=""> 
 <small>Please enter only jpg format.maximum upload size is 1MB.</small>
 <?php
 if(!empty($result[0]->p_prd_img))
 {

 	$pimage=explode(',',$result[0]->p_prd_img);
 	foreach($pimage as $img)
 	{
 	echo "<img src='".base_url('uploads/production/prds/').$img."' width='50' height='50'>";
 	}
 }
 ?>

<div class="form_error">  <?php echo $this->session->flashdata('prd_image');?></div>
</div>

</div>

</div>
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Attach Datasheets <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Attach the product datasheet here.Allowed extensions: pdf,jpeg"></i></label>

<div class="col-md-8">

<input type="file" class="form-control" name="datasheets[]" multiple=""> 
<small>Please enter only jpg and pdf formats.maximum upload size is 3MB.</small>
<?php
 if(!empty($result[0]->p_datasheets))
 {
 $pdatasheet=explode(',', $result[0]->p_datasheets);
 foreach($pdatasheet as $dsheet)
	{
	$ext = pathinfo('uploads/production/datasheets/'.$dsheet, PATHINFO_EXTENSION); //$ext will be gif
		if($ext=="jpg" || $ext=="jpeg")
		{
			echo "<img src='".base_url('uploads/production/datasheets/').$dsheet."' width='50' height='50'>";
		}
		elseif($ext=="pdf")
		{
			echo "<span>
			<a href=".base_url('uploads/production/datasheets/').$dsheet." download><i class='fa fa-file-pdf-o fa-3x'></i></a>
			</span>";
		}
		else{
			echo "<span><i class='fa fa-file'></i></span>";
		}	

	}
 }
 ?>
<div class="form_error">  <?php echo $this->session->flashdata('datasheets');?></div>
</div>

</div>

</div>
</div>

</div>



<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary"> Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
<!-- submit_main_form -->

<?php echo form_close();?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>


<script type="text/javascript">
	$(document).ready(function()
	{
		$('.select_variation').hide();

		var variation_sts=$("input[name='variation_status']:checked").val();
		if(variation_sts=="Yes")
		{
			$('.select_variation').show();
		}

		$('.main_cat').on('change', function() {		
		cat_id=$('select[name=cat]').val();
			  jQuery.ajax({
		            url:"<?php echo base_url().'Production_entry/sub_cat_list';?>",
		            type:"post",
		            data:{"cat_id":cat_id},
		            success:function(result)
		            {
		         		 $('.sub_cat_type').html(result);
		          	}
		        });
    		});

		$('.hse_type').on('change', function() {		
		hse_id=$('select[name=hse_code]').val();
			  jQuery.ajax({
		            url:"<?php echo base_url().'Production_entry/hse_code_val';?>",
		            type:"post",
		            data:{"hse_id":hse_id},
		            success:function(result)
		            {
		         		 $('.hse_code_val').html(result);
		          	}
		        });
    		});

		$('input:radio').change(function() {
			var variation_type = $("input[name='variation_status']:checked").val();
			if(variation_type=="Yes")
			{
				$('.select_variation').show();
			}
			if(variation_type=="No")
			{
				$('.select_variation').hide();
			}		
  		});

		 $("input[name='selling_price']").change(function() {
			// console.log('insde the fun');
		 	var selling_price=$("input[name='selling_price']").val();
		 	if(selling_price!='')
		 	{
		 		uae_final_l1=$("input[name='uae_final_l1']").val();
		 		uae_final_l2=$("input[name='uae_final_l2']").val();
		 		ksa_final=$("input[name='ksa_final']").val();
		 		ksa_final_l1=$("input[name='ksa_final_l1']").val();
		 		ksa_final_l2=$("input[name='ksa_final_l2']").val();
		 		ksa_final_l3=$("input[name='ksa_final_l3']").val();

			uae_price1=selling_price*parseFloat(0.10);
		 	uae_price2=selling_price*parseFloat(0.25);
			ksa_final=parseFloat(selling_price)+parseFloat(12.5);
		 	ksa_price1=ksa_final*parseFloat(0.10);
		 	ksa_price2=ksa_final*parseFloat(0.20);
		 	ksa_price3=ksa_final*parseFloat(0.50);

		 $(".uae_final").val(parseFloat(selling_price) );
		 $(".uae_final_l1").val(parseFloat(selling_price)+parseFloat(uae_price1) );
		 $(".uae_final_l2").val(parseFloat(selling_price)+parseFloat(uae_price2) );
		 $(".ksa_final").val(ksa_final);
		 $(".ksa_final_l1").val(parseFloat(ksa_final)+parseFloat(ksa_price1) );
		 $(".ksa_final_l2").val(parseFloat(ksa_final)+parseFloat(ksa_price2) );
		 $(".ksa_final_l3").val(parseFloat(ksa_final)+parseFloat(ksa_price3) );
		 	}
		 	else
		 	{}
		 });
		  // $('.submit_main_form').on('click', function(e){
		  //       e.preventDefault();
		  //       $(".product_entry_form").submit();		      
    // 		});
  	});

	function variation_form(type)
	{
		
		test=$("input[name='var_name[]']")
              .map(function(){return $(this).val();}).get().join();
       
        test_val= $("input[name='var_val[]']")
              .map(function(){return $(this).val();}).get().join();

 		var_name=$('input[name=var_name]').val();
 		var_val=$('input[name=var_val]').val();
 		var_type=type;

 		if(var_name=='')
 		{
 			if($('select[name=var_name]').val()!='')
 			var_name=$('select[name=var_name]').val();		
 			else
 			var_name=test;
 		}
 		else{}
 		if(var_val=='')
 		{
 			var_val=test_val;
 		}
 		else{}
 		
		 jQuery.ajax({
            url:"<?php echo base_url().'Production_entry/credinals';?>",
            type:"post",
            data:{"name":var_name,"val":var_val,"type":var_type},
            success:function(result)
            {
            	//console.log(result);
            	 var posts = JSON.parse(result);

            	  if(type=="variation_form")
			        {
			        var group = $('<optgroup label="'+var_name+'" class="'+var_name+'">');
						$(".variation_type").append(group);
						 $.each(posts, function()
						{
						    group.append($('<option></option>').val(this.id).html(this.name));
						});
						// group.append($('</optgroup>'));
			        }

		       $.each(posts, function() {
			       	if(type=="brand")
			        {   
			        	$('.brand_type').append( $('<option></option>').text(this.name).val(this.id) );
			 		}
			        else if(type=="main-cat")
			        {
			        	$('.main_cat').append( $('<option></option>').text(this.name).val(this.id) );
			        }
			        else if(type=="unit_form")
			        {
			        	$('.unit_type').append( $('<option></option>').text(this.name).val(this.id) );
			        }
			        else if(type=="sub-cat")
			        {
			        	$('.sub_cat_type').append( $('<option></option>').text(this.name).val(this.name) );
			        }
			        else if(type=="hse_form")
			        {
			        	$('.hse_type').append( $('<option></option>').text(this.name_en+':'+this.name_ar).val(this.id) );
			        	$('.hse_code_val').html(this.code);
			        }

			        else{}
		      	});
         		
  //        		$('.extra-form').find(':input').each(function() {
		//     switch (this.type) {
		//         case 'password':
		//         case 'select-multiple':
  //      			case 'select-one':
		//         case 'text':
		//         case 'textarea':
		//             $(this).val('');
		//             break;
		//         case 'checkbox':
		//         case 'radio':
		//             this.checked = false;
		//     }
		// });
            }
        });
	}
</script>

 <script type="text/javascript">
 	
 $('.myform').submit(function() {
var data=[];
$('.variation_type').find("option:selected").each(function(){
		 // optgroup label
		 var grp_name=[];
		 var grp_val=[];
        var label = $(this).parent().attr("label");  
		data.push(label+'::'+$(this).val());
        //optgroup id
       //console.log('class='+$(this).parent().attr("class"));
		 // values based on each group ??
       /// id = $(this).parent().attr("id");
 
    });
$("input[name='variation_label_val']").val(data.join("|#|"));
  if(data!='')
  	return true;
  else
     return false;
  
 });
 </script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
		tinymce.init({
			selector : '.editors',
			  plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
		});
   </script>



</body>

</html>