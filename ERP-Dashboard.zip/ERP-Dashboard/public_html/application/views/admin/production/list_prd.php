<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Entries</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Entries</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<!-- <div class="col-md-6">
	<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Filter Based on Product Type</h2>
</header>
<div class="panel-body">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Choose Product Type</label>

<select class="form-control populate" name="prd_type">
	<option value="">Choose</option>
	<option value="Raw Material">Raw Material</option>
	<option value="Finished Good">Finished Good</option>
	<option value="Service Product">Service Product</option>
</select>

	</div>
	<button type="button" class="btn btn-primary" onclick="filter_type('prd_type')">Submit</button>
</div>

</section>
</div> -->
<div class="col-md-12">
	<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Filter Based on Category</h2>
</header>
<div class="panel-body">
	
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Choose Category</label>	
		<select class="form-control searchBycat" name="cat" id="filter_cat">
			<option value="">Choose</option>
			<?php
			if(!empty($cat))
			{
				foreach($cat as $c)
				{
					?>
					<option value="<?php echo $c->cid;?>"> <?php echo $c->cname;?></option>;
				<?php
				}
			}
			?>
		</select>
					   		
	
	</div>
<!-- <button type="button" id="filter" class="btn btn-primary"  >Submit</button>  -->
</div>
</section>
</div>

</div>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">List Products</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result">
<table class="table table-bordered table-striped mb-none" id="memListTable">
<thead>
<tr>
	<th></th>
<th style="width: 50%;">Item - Name</th>	
<th>Item Code</th>
<th>Selling Price</th>	
<th>Purchase Price</th>	
<th>Category</th>
<th>Action</th>
</tr>
</thead>
<tbody>

</tbody>
</table>
</div>

<input type="hidden" name="selected_cat_text">

<script type="text/javascript">
	function view_prd_data(pid)
	{
		 $.ajax({
        url : "<?php echo site_url('Product_order_sample/ajax_load_view_prd/')?>",
        type: "POST",
        data: {"prd_id":pid},
        success: function(data)
        {
        	$('.view_data_modal').html(data);
            $('#modalsm2_view_data').modal('show'); // show bootstrap modal when complete loaded
          },
   		 });
	}
</script>
<!-------------------modal view quotation------------>
<div class="modal fade" id="modalsm2_view_data" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">View data</h3>
            </div>
            <div class="modal-body form ">
            	<div class="row view_data_modal" ></div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!------------modal view quotation ends----------->

<script type="text/javascript">
	function edit_add_hgt(pid)
	{
		$.ajax({
        url : "<?php echo site_url('Product_order_sample/ajax_load_edit_prd_essentials/')?>",
        type: "POST",
        data: {"prd_id":pid},
        success: function(data)
        {
        	$('.load_content_essentials').html(data);
            $('#modalsm2_add_edit_hgt').modal('show'); // show bootstrap modal when complete loaded
          },
   		 });
	}
</script>

<!-----------modal issue performa---->
<div class="modal fade" id="modalsm2_add_edit_hgt" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
        	
        	<div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Add/ Edit Width,Height,Area,Clamp Details Form</h3>
            </div>
            <div class="modal-body form">
            <?php echo form_open("Production_entry/edit_prd_width_heigth",'class="form"');?>
            <div class="load_content_essentials"></div>
        	</div>
        	<div class="modal-footer">
               <button type="submit" class="btn btn-primary">Confirm</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
            <?php echo form_close();?>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!-----------------modal performa endss-------->


</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script type="text/javascript">
         $(function () {
                $('.datetimepicker4').datepicker().datepicker("setDate", new Date());
            });
         
  $(document).ready(function() {
  	fill_datatable();

  function fill_datatable(filter_val= '')
  {
   var dataTable = $('#memListTable').DataTable({
    "processing" : true,
    "serverSide" : true,
    "order" : [],
    "searching" : true,
    "ajax" : {
     url:"<?php echo base_url('Product_order_sample/Prod_list'); ?>",
     type:"POST",
     data:{
      filter_val:filter_val
     }
    },
    "pageLength": 25,
    responsive: true,
      "columnDefs": [{ 
            "targets": [0],
            "orderable": false,
        }],
   });
  }

  $('#filter_cat').on('change',function(){
   var type_val = $('#filter_cat option:selected').text();
    if(type_val != '')
   {
    $('#memListTable').DataTable().destroy();
    fill_datatable(type_val);
   }
   else
   {
    $('#memListTable').DataTable().destroy();
    fill_datatable();
   }
  }); 
     });
 </script>


</body>
</html>