<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Installation Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Generate</span></li>
<li><span>Installation Details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-----section for lightbox opens here-->

		 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
	    </div>
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Generate Installation Details</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <?php
    echo form_open('submit_edit_qty_installation');?>
    <input type="hidden" name="edit_survey_id" value="<?php echo $edit_survey_id;?>">
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none">
<thead>
<tr>

<th>Product Sets</th>
<th>Product Singles</th>

</tr>
</thead>
<tbody>
<tr>
	<td>
		<table class="table table-bordered table-striped mb-none">
			<thead>
				<tr>
					<th>Image</th>
					<th>Original Quantity</th>
					<th>Installed Quantity</th>
				</tr>
			</thead>
		<tbody>
		<?php
		if(!empty($prd_set_details))
		{
		
		foreach($prd_ids_1 as $index_p=>$p1)
					{
						$alignment=$prd_set_details[$index_p]->psd_prd_alignment;
						$prod_position=explode(',',$prd_set_details[$index_p]->psd_arrange_position);

						// pre_list($prod_position);
						// pre_list($p1);
						foreach($prod_position as $pd2)
						{
						//pre_list($pd2);
						//pre_list($p1[$pd2][0]->pname);
							if(empty($p1[$pd2][0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
								 }
 	
								 $prd_height[$index_p][]=$p1[$pd2][0]->prd_height;
								 $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
								 $prod_sets_image[$index_p][]=$img_path;
								 $prod_sets_alignment[$index_p]=$alignment;
								 $prod_sets_position[$index_p]=$prod_position;
								 $prd_set_id[$index_p]=$prd_set_details[$index_p]->psd_id;

								  $prod_sets_qty_orginal[$index_p]=$prd_set_details[$index_p]->psd_prd_qty;
								  $qty_installed[$index_p]=$prd_set_details[$index_p]->psd_qty_installed;
								  $qty_remaining[$index_p]=$prd_set_details[$index_p]->psd_qty_remaining_installation;
						}
					}
					
					$ij=1;
					foreach($prod_sets_alignment as $index=>$align)
					{
					
						if($align=="vertical")
						{
							//pre_list(implode(',',$prod_sets_image[$index]));
							echo "<tr>";
						echo "<td>";
						asort($prod_sets_position[$index]);
						foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
					
								if(!empty($prod_sets_image[$index][$index22]))
							echo "<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
							else
							echo "";
							}
							echo "</td>";
							echo "<td>Original Quantity: <span class='original_qnty_".$ij."'>".$prod_sets_qty_orginal[$index]."</span></td>";
							if(!empty($qty_installed[$index]))
							{
								$edit_rmaining_qty=$prod_sets_qty_orginal[$index]-$qty_installed[$index];
							echo "<td><input type='text' class='new_quantity_prd_set".$ij."' name='new_quantity_prd_set[]' value='".$qty_installed[$index]."' onkeyup='get_prd_set_qty(".$ij.")'>
							<input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'><br/>
							Remaining Quantity: <span class='dt_prd_set_remaining_qty_".$ij."'>".$edit_rmaining_qty."</span><input type='hidden' class='prd_set_remaining_qty_".$ij."' name='prd_set_remaining_qty[]' value='".$edit_rmaining_qty."'></td>";
							}
							else
							{
								echo "<td><input type='text' class='new_quantity_prd_set".$ij."' name='new_quantity_prd_set[]' value='0' onkeyup='get_prd_set_qty(".$ij.")'>
							<input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'><br/>
							Remaining Quantity: <span class='dt_prd_set_remaining_qty_".$ij."'>0</span><input type='hidden' class='prd_set_remaining_qty_".$ij."' name='prd_set_remaining_qty[]' value='0'></td>";
							}

							echo "</tr>";
						}
						else
						{
							echo "<tr>";
							echo "<td>";
							asort($prod_sets_position[$index]);
							foreach($prod_sets_position[$index]  as $index22=>$ptt)
							{
										if(!empty($prod_sets_image[$index][$index22]))
							echo "<img src='".$prod_sets_image[$index][$index22]."' width='80' height='100'>";
							else
							echo "";
							}
							echo "</td>";
							echo "<td>Original Quantity: <span class='original_qnty_".$ij."'>".$prod_sets_qty_orginal[$index]."</span></td>";
							if(!empty($qty_installed[$index]))
							{
								$edit_rmaining_qty=$prod_sets_qty_orginal[$index]-$qty_installed[$index];
									echo "<td><input type='text' class='new_quantity_prd_set".$ij."' name='new_quantity_prd_set[]' value='".$qty_installed[$index]."' onkeyup='get_prd_set_qty(".$ij.")'>
							<input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'><br/>
							Remaining Quantity: <span class='dt_prd_set_remaining_qty_".$ij."'>".$edit_rmaining_qty."</span><input type='hidden' class='prd_set_remaining_qty_".$ij."' name='prd_set_remaining_qty[]' value='".$edit_rmaining_qty."'></td>";
							}
							else
							{
							echo "<td><input type='text' class='new_quantity_prd_set".$ij."' name='new_quantity_prd_set[]' value='0' onkeyup='get_prd_set_qty(".$ij.")'>
							<input type='hidden' name='prd_set_ids[]' value='".$prd_set_id[$index]."'><br/>
							Remaining Quantity: <span class='dt_prd_set_remaining_qty_".$ij."'>0</span><input type='hidden' class='prd_set_remaining_qty_".$ij."' name='prd_set_remaining_qty[]' value='0'></td>";
							}
							echo "</tr>";
								
						}
						$ij++;
					}
				?>
		
		<?php
			
		}
		?>
		</tbody>
		</table>
	</td>
	<td>
		<table class="table table-bordered table-striped mb-none">
			<thead>
				<tr>
					<th>Image</th>
					<th>Original Quantity</th>
					<th>Installed Quantity</th>
				</tr>
			</thead>
		<tbody>
		<?php
		if(!empty($survey_result[0]->st_single_prds))
		{
				
$ik=50;
$org_qty=explode(',',$single_prd_qty);
$edit_qty_installed=explode(',',$survey_result[0]->st_qty_installed);
$edit_qty_remaining=explode(',',$survey_result[0]->st_qty_remaining_installation);
			foreach($prd_ids_2 as $index2=>$pd2)
			{
				if(!empty($edit_qty_installed[$index2]))
				$edit_calc_remaining=$org_qty[$index2]-$edit_qty_installed[$index2];
			if(empty($pd2[0]->p_prd_img))
								{
									$filename="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpeg';
								 if (file_exists($filename)) {
								 	$img_path=$filename;
									} else {
									$img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpg';
								    }
								}
								 else
								 {
								 	$first_img_prd=explode(',',$pd2[0]->p_prd_img);
								 	if(!empty($first_img_prd[0]))
								 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
								 	else
								 	$img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->p_prd_img;
								 }
								//  $prd_height=$pd3[0]->prd_height;					 
			?>
		<tr>
			<td><img src="<?php echo $img_path;?>"  width='100' height='100'></td>
			<td>Original Quantity: <span class='original_qnty_<?php echo $ik;?>'><?php echo $org_qty[$index2];?></span></td>
			<?php
			if(!empty($edit_qty_installed[$index2]))
			{
				?>
			<td><input type="text" name="prd_single_quantity_new[]" class="new_quantity_prd_set<?php echo $ik;?>" value="<?php echo $edit_qty_installed[$index2];?>" onkeyup='get_prd_set_qty(<?php echo $ik;?>)'>
				<br/>Remaining Quantity: <span class='dt_prd_set_remaining_qty_<?php echo $ik;?>'><?php echo $edit_calc_remaining;?></span>
				<input type='hidden' name='prd_remaining_qty_single[]' class='prd_set_remaining_qty_<?php echo $ik;?>' value='<?php echo $edit_calc_remaining;?>'>
			</td>
			<?php
			}
			else
			{?>
			<td><input type="text" name="prd_single_quantity_new[]" class="new_quantity_prd_set<?php echo $ik;?>" value="0" onkeyup='get_prd_set_qty(<?php echo $ik;?>)'>
				<br/>Remaining Quantity: <span class='dt_prd_set_remaining_qty_<?php echo $ik;?>'>0</span>
				<input type='hidden' name='prd_remaining_qty_single[]' class='prd_set_remaining_qty_<?php echo $ik;?>' value='0'>
			</td>
			<?php
		}?>
			
		</tr>
		<?php
		$ik++;
			}

		}
		?>
		</tbody>
		</table>
	</td>
	
</tr>
<!-----------modal for setting installation date----->
<!---------end installation date---->


</tbody>
</table>

<button type="submit" class="btn btn-primary btn-md">Submit</button>
<?php 
echo form_close();?>
</div>
</div>
</section>
<!-----section for lighbox closes here--->

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	 $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
   <script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker().datepicker();
            });
        </script>
       <script type="text/javascript">
        	function get_prd_set_qty(ij)
        	{
        		var original_prd_set_qty=$('.original_qnty_'+ij).html();
        		//console.log(original_prd_set_qty);
        		var new_prd_set_qty=$('.new_quantity_prd_set'+ij).val();
        		//console.log(new_prd_set_qty);
        		var remaining_prd_set= parseFloat(original_prd_set_qty)-parseFloat(new_prd_set_qty);
        		//console.log(remaining_prd_set);
        		if(remaining_prd_set==0)
        		{
        			$('.dt_prd_set_remaining_qty_'+ij).text('0');
        			$('.prd_set_remaining_qty_'+ij).val('0');
        		}
        		else
        		{
        			$('.dt_prd_set_remaining_qty_'+ij).text(remaining_prd_set);
        			$('.prd_set_remaining_qty_'+ij).val(remaining_prd_set);
        		}
        		//console.log(remaining_prd_set);
        		
        		
        		//$('.pipe_qnty_'+ij).html(prd_set_qty);
        	} 

        
        </script>
</body>
</html>