<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>


  
    <!-- jsFiddle will insert css and js -->
<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}

</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Installation Details </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Installation Details</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">
  
<h2 class="panel-title">Survey -Installation Details</h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('submit_installation_details','class="myform" ','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
    <input type="hidden" name="installation_details_id" value="<?php echo $edit_instalation_detail_id;?>">

   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fields marked as '::*::' are required fields</p>


<div class="row">

<!-----=====================table col-12 starts here===================---->
<div class="col-md-12" style="margin-bottom: 2%;">
      <div class="col-md-4">
        <h4>Labour List</h4>
        <ul>
          <?php
          if(!empty($emp_details))
          {
            foreach($emp_details as $ed)
            {
          ?>
          <li><?php if(!empty($ed[0]->ed_name)){echo $ed[0]->ed_name;}?></li>
          <?php
           }
        }?>
        </ul>
      </div>  
      <div class="col-md-4">
        <h4>Tool List</h4>
        <ul>
          <?php
          if(!empty($tools_details))
          {
            foreach($tools_details as $td)
            {
          ?>
          <li><?php if(!empty($td[0]->tool_name)){echo $td[0]->tool_name;}?></li>
          <?php
            }
        }?>
        </ul>
      </div>
      <div class="col-md-4">
        <h4> Vehicle </h4>
        <ul>
          <?php
          if(!empty($veh_details))
          {
            foreach($veh_details as $vd)
            {
           ?>
          <li>Plate No.- <?php if(!empty($vd[0]->veh_plate_no)){echo $vd[0]->veh_plate_no;}?></li>
          <?php
            }
        }?>
        </ul>
      </div>
      
    </div>
<!-----=====================table col-12 ends here===================---->
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for details---->

<section class="panel">
<header class="panel-heading">

<h2 class="panel-title"> Installation Details</h2>
<?php
 if(!empty($instalation_details))
  {
    $prd_set_remaining_qnty=explode(',',$instalation_details[0]->insd_prd_set_remaining_qnty);
    $prd_single_remaining_qnty=explode(',',$instalation_details[0]->insd_prd_single_remaining_qnty);

    $prd_set_qnty_for_installation=explode(',',$instalation_details[0]->insd_prd_set_qty_set_for_installation);
    $prd_single_qnty_for_installation=explode(',',$instalation_details[0]->insd_prd_single_qty_set_for_installation);
   
    if(array_filter($prd_set_remaining_qnty)!=true && array_filter($prd_set_qnty_for_installation)!=true)
    {
      echo "<h2 style='color:green'>No more product set to install</h2>";
    }
    elseif(array_filter($prd_set_remaining_qnty)==true && array_filter($prd_set_qnty_for_installation)!=true)
    {
      echo "<h2 style='color:red'>Wait for product quantity to set for installation</h2>";
    }
    else{}

    if(array_filter( $prd_single_remaining_qnty)!=true && array_filter($prd_single_qnty_for_installation)!=true)
    {
      echo "<h2 style='color:green'>No more single product to install</h2>";
    }
     elseif(array_filter($prd_single_remaining_qnty)==true && array_filter($prd_single_qnty_for_installation)!=true)
    {
       echo "<h2 style='color:red'>Wait for single products quantity to set for installation</h2>";
    }
    else{}   
  }
  ?>
</header>
<div class="panel-body">  
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th>Product Sets</th>
<th>Product Singles</th>
</tr>
</thead>
<tbody>
<tr>
  <td>
    <table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
      <thead>
        <tr>
          <th>Image</th>
          <th>Quantity Set for Installation</th>
            <th>Installated Quantity</th>
             <th>Remaining Quantity after installation</th>
         <!--  <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
    <?php
    if(!empty($prd_set_result[0]))
    {
    foreach($prd_ids_1 as $index_p=>$p1)
          {
            $alignment=$prd_set_result[$index_p][0]->psd_prd_alignment;
            $prod_position=explode(',',$prd_set_result[$index_p][0]->psd_arrange_position);

            $prd_qnty_to_install=explode(',',$instalation_details[0]->insd_prd_set_qty_set_for_installation);
            $prd_set_id_installation_details=explode(',',$instalation_details[0]->insd_prd_set_ids);

             foreach($prod_position as $pd2)
            {
              if(empty($p1[$pd2][0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
                 }
  
                 $prd_height[$index_p][]=$p1[$pd2][0]->prd_height;
                 $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
                 $prod_sets_image[$index_p][]=$img_path;
                 $prod_sets_alignment[$index_p]=$alignment;
                 $prod_sets_position[$index_p]=$prod_position;
                 $prd_set_id[$index_p]=$prd_set_result[$index_p][0]->psd_id;

                $prd_set_for_installation[$index_p]=$prd_qnty_to_install[$index_p];
                $prd_set_id_installation[$index_p]=$prd_set_id_installation_details[$index_p];
            }
          }
          
          $ij=1;
          foreach($prod_sets_alignment as $index=>$align)
          {
          if($align=="vertical")
            {
              //pre_list(implode(',',$prod_sets_image[$index]));
              echo "<tr>";
            echo "<td>";
            asort($prod_sets_position[$index]);
            foreach($prod_sets_position[$index]  as $index22=>$ptt)
              {
                if(!empty($prod_sets_image[$index][$index22]))
              echo "<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
              else
              echo "";
              }
              echo "<input type='hidden' name='prd_set_id[]' value='".$prd_set_id_installation[$index]."'></td>";
              echo "<td><span class='original_qnty_".$ij."'>";
              echo $prd_set_for_installation[$index];
              echo "</span></td>";

              echo "<td><input type='text' name='prd_set_qnty_installed[]' value='0' class='new_quantity_prd_set_".$ij."' onkeyup='get_prd_set_qty(".$ij.")'";
              if(empty($prd_set_for_installation[$index])){
                echo "readonly";
              }
              echo "></td>";
              echo "<td><span class='prd_remaining_qnty_".$ij."'>".$prd_set_for_installation[$index]."</span>";
              if(!empty($prd_set_for_installation[$index]))
              {
              echo"<input type='hidden' name='remaining_after_install_prd_set[]' class='input_prd_remaining_qnty_".$ij."' value='".$prd_set_for_installation[$index]."'></td>";
              }
              else
              {
                 echo"<input type='hidden' name='remaining_after_install_prd_set[]' class='input_prd_remaining_qnty_".$ij."' value='0'></td>";
              }

              echo "</tr>";
            }
            else
            {
              echo "<tr>";
              echo "<td>";
              asort($prod_sets_position[$index]);
              foreach($prod_sets_position[$index]  as $index22=>$ptt)
              {
                    if(!empty($prod_sets_image[$index][$index22]))
              echo "<img src='".$prod_sets_image[$index][$index22]."' width='80' height='100'>";
              else
              echo "";
              }
              echo "<input type='hidden' name='prd_set_id[]' value='".$prd_set_id_installation[$index]."'></td>";
              echo "<td><span class='original_qnty_".$ij."'>";
              echo $prd_set_for_installation[$index];
              echo "</span></td>";
              echo "<td><input type='text' name='prd_set_qnty_installed[]' value='0' class='new_quantity_prd_set_".$ij."' onkeyup='get_prd_set_qty(".$ij.")' ";
              if(empty($prd_set_for_installation[$index])){
                echo "readonly";
              }
              echo "></td>";
              echo "<td><span class='prd_remaining_qnty_".$ij."'>".$prd_set_for_installation[$index]."</span>";
               if(!empty($prd_set_for_installation[$index]))
              {
              echo"<input type='hidden' name='remaining_after_install_prd_set[]' class='input_prd_remaining_qnty_".$ij."' value='".$prd_set_for_installation[$index]."'></td>";
              }
              else
              {
                 echo"<input type='hidden' name='remaining_after_install_prd_set[]' class='input_prd_remaining_qnty_".$ij."' value='0'></td>";
              }
             

              echo "</tr>";
                
            }
            $ij++;
          }
        ?>
    
    <?php
      
    }
    ?>
    </tbody>
    </table>
  </td>
  <td>
    <table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
      <thead>
        <tr>
          <th>Image</th>
          <th>Quantity Set for Installation</th>
            <th>Installated Quantity</th>
             <th>Remaining Quantity after installation</th>
          <!-- <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
    <?php
    if(!empty($prd_ids_2))
    {
       $prd_single_qnty_to_install=explode(',',$instalation_details[0]->insd_prd_single_qty_set_for_installation);
       $prd_single_id_installtion_details=explode(',',$instalation_details[0]->insd_prd_single_ids);
        $ik=50;
      foreach($prd_ids_2 as $index2=>$pd2)
      {
        if(empty($pd2[0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$pd2[0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->p_prd_img;
                 }
                //  $prd_height=$pd3[0]->prd_height;           
      ?>
    <tr>
      <td><img src="<?php echo $img_path;?>"  width='100' height='100'>
      <input type="hidden" name="prd_single_id[]" value="<?php echo $prd_single_id_installtion_details[$index2];?>"></td>
      <td><span class="original_qnty_<?php echo $ik;?>"><?php echo $prd_single_qnty_to_install[$index2];?></span></td>
      <td><input type='text' name='prd_single_qnty_installed[]' class="new_quantity_prd_set_<?php echo $ik;?>" value='0' onkeyup='get_prd_set_qty("<?php echo $ik;?>")' <?php if(empty($prd_single_qnty_to_install[$index2])){echo "readonly";}?>></td>
                <td><span class="prd_remaining_qnty_<?php echo $ik;?>"><?php echo $prd_single_qnty_to_install[$index2];?></span> 
        <?php
         if(!empty($prd_single_qnty_to_install[$index2]))
              {
                ?>
      <input type='hidden' name='remaining_after_install_prd_single[]' class='input_prd_remaining_qnty_<?php echo $ik;?>' value='<?php echo $prd_single_qnty_to_install[$index2];?>'></td>
          <?php     
        }
       else
        {
          ?>
          <input type='hidden' name='remaining_after_install_prd_single[]' class='input_prd_remaining_qnty_<?php echo $ik;?>' value='0'></td>
       <?php 
     }     ?>     
                

    </tr>
    <?php
    $ik++;
      }

    }
    ?>
    </tbody>
    </table>
  </td>

  
</tr>
<!-----------modal for setting installation date----->
<!---------end installation date---->


</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->
<div class="cell_text_data">
  <input type="hidden" name="single_prd_ids">
  <input type="hidden" name="prd_set_prd_ids">
  <input type="hidden" name="single_prd_installed_no">
   <input type="hidden" name="prd_set_installed_no">
   <input type="hidden" name="single_prd_remaining_no">
   <input type="hidden" name="prd_set_remaining_no">
</div>
<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script type="text/javascript">
   $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
   <script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker().datepicker();
            });
         
        </script>
 <script type="text/javascript">
          function get_prd_set_qty(ij)
          {
           var original_prd_set_qty=$('.original_qnty_'+ij).html();
       // console.log(original_prd_set_qty);
            var new_prd_set_qty=$('.new_quantity_prd_set_'+ij).val();
       // console.log(new_prd_set_qty);
            var remaining_prd_set= parseFloat(original_prd_set_qty)-parseFloat(new_prd_set_qty);
      //  console.log(remaining_prd_set);
            if(remaining_prd_set==0)
            {
              $('.prd_remaining_qnty_'+ij).text('0');
               $('.input_prd_remaining_qnty_'+ij).val('0');
            }
            else
            {

              $('.prd_remaining_qnty_'+ij).text(remaining_prd_set);
              $('.input_prd_remaining_qnty_'+ij).val(remaining_prd_set);
             }
            //console.log(remaining_prd_set);
            
            
            //$('.pipe_qnty_'+ij).html(prd_set_qty);
          } 

        
        </script>

        <script>
        $('.myform').submit(function(e) {
$('input[name="single_prd_ids"]').val($('table tbody tr td input[name="prd_single_id[]"]').map(function(){return $(this).val()}).get().join(','));
$('input[name="single_prd_installed_no"]').val($('table tbody tr td input[name="prd_single_qnty_installed[]"]').map(function(){return $(this).val()}).get().join(','));
$('input[name="prd_set_prd_ids"]').val($('table tbody tr td input[name="prd_set_id[]"]').map(function(){return $(this).val()}).get().join(','));
$('input[name="prd_set_installed_no"]').val($('table tbody tr td input[name="prd_set_qnty_installed[]"]').map(function(){return $(this).val()}).get().join(','));
$('input[name="prd_set_remaining_no"]').val($('table tbody tr td input[name="remaining_after_install_prd_set[]"]').map(function(){return $(this).val()}).get().join(','));
$('input[name="single_prd_remaining_no"]').val($('table tbody tr td input[name="remaining_after_install_prd_single[]"]').map(function(){return $(this).val()}).get().join(','));
  //e.preventDefault();
  return true;
        });
        </script>
</body>

</html>