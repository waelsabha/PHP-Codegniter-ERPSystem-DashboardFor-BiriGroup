<!doctype html>
<html class="fixed">
<head>
<?php $this->load->view('admin/head');?>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Product Pricing Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>edit</span></li>
<li><span>Product Pricing Details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>



<?php 
if($this->session->userdata['user']['main_dept']=="Main")
{?>
<?php $this->load->view('admin/production/prd_purchase_pending',$resulttoapprove);?>


<?php
}
?>



<section class="panel">
<header class="panel-heading">

<h2 class="panel-title red">List Of Product</h2>

<div class="panel-body">
	<p>NOTE: Please Make Sure That Details From Last MRN  </p>
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>




      <!-- the problem here in this table -->


  <table class="table table-bordered table-striped mb-none" id="datatable-default">
<thead>


<tr>
	
<th>Image</th>
<th>Product Name</th>	
<th>SKU/Code </th>
<th>P Width</th>
<th>P Height</th>
<th>P Length</th>
<th>P Weight</th>
<!-- <th>Country of Origin</th> -->
<!-- <th>Last Supplier</th> -->
<th>Purchase Price (AED)</th>
<!-- <th>Web Price</th> -->
<th>Action</th> 
</tr>
</thead>
<tbody>
<?php
//$i=1;
foreach($products_list_pur as $index11=>$t)
{   
//$image=$t->p_prd_img;
// $image=$t->p_prd_img;
// 	$pname=$t->pname;
// 	$pcode=$t->pcode;

//     if(empty($pname)) 
// 	{
// 		$pname='null';
// 	}
// 	else{
// 		$pname=$t->pname;

// 	}
// 	 if(empty($t->pcode)) 
// 	{
// 		$pcode='null';
// 	}
// 	else{
// 		$pcode=$t->pcode;

// 	}
// 	 if(empty($t->p_pack_width)) 
// 	{
// 		$p_pack_width='null';
// 	}
// 	else{
// 		$p_pack_width=$t->p_pack_width;

// 	}
// 	 if(empty($t->p_pack_hgt)) 
// 	{
// 		$p_pack_hgt='null';
// 	}
// 	else{
// 		$p_pack_hgt=$t->pnamp_pack_hgte;

// 	}
// 	 if(empty($t->p_pack_lgth)) 
// 	{
// 		$p_pack_lgth='null';
// 	}
// 	else{
// 		$p_pack_lgth=$t->p_pack_lgth;

// 	}
// 	 if(empty($t->p_wgt)) 
// 	{
// 		$p_wgt='null';
// 	}
// 	else{
// 		$p_wgt=$t->p_wgt;

// 	}
// 	 if(empty($t->p_purchase_price)) 
// 	{
// 		$p_purchase_price='null';
// 	}
// 	else{
// 		$p_purchase_price=$t->p_purchase_price;

// 	}
// 	$pid=$products_list_pur[$index11]->pid;

// 		 if(empty($pid)) 
// 	{
// 		$pid='1';
// 	}
// 	else{
// 		$pid=$t->pid;

// 	}
// 	$temp_p_purchase_price=$products_list_pur[$index11]->temp_p_purchase_price;

// 		 if(empty($temp_p_purchase_price)) 
// 	{
// 		$temp_p_purchase_price='0';
// 	}
// 	else{
// 		$temp_p_purchase_price=$t->pid;

// 	}

	

// 		$purchase_date=$products_list_pur[$index11]->purchase_date;

// 		 if(empty($purchase_date)) 
// 	{
// 		$purchase_date='00-00-0000';
// 	}
// 	else{
// 		$purchase_date=$t->purchase_date;

// 	}


// 			$p_country=$products_list_pur[$index11]->p_country;

// 		 if(empty($p_country)) 
// 	{
// 		$p_country='220';
// 	}
// 	else{
// 		$p_country=$t->purchase_date;

// 	}

// 			$p_last_supplier=$products_list_pur[$index11]->p_last_supplier;

// 		 if(empty($p_last_supplier)) 
// 	{
// 		$p_last_supplier='0';
// 	}
// 	else{
// 		$p_last_supplier=$t->p_last_supplier;

// 	}
// if(!empty($image) )
// {
//   $path = "https://birigroup.com/uploads/prd_images/".$image;//this is the image path
  

// }
// else{
//   $path = "https://birigroup.com/uploads/prd_images/no_image.jpg";//this is the image path



// } 

// $type = pathinfo($path, PATHINFO_EXTENSION);
//   $data = file_get_contents($path);
//   $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);



?>
<tr class="gradeX">
		
			<td ><img class="img-fluid" src=  "https://birigroup.com/uploads/prd_images/<?php echo $t->p_prd_img;?>"  style="max-height:100px;"></td>
			
            <td><?php echo $t->pname;?></td>
			<td><?php echo $t->pcode;?></td>	
			<td><?php echo $t->p_pack_width;?></td>	
			<td><?php echo $t->p_pack_hgt;?></td>	
			<td><?php echo $t->p_pack_lgth;?></td>	
			<td><?php echo $t->p_wgt; ?></td>	
	
		
			<td><?php echo $t->p_purchase_price;?> </td>	
		   
		
			<td>				
	            <a class="mb-xs mt-xs mr-xs  btn btn-success" href="<?php echo base_url('Item_costing/product_purchase_extra/'.$t->pid);?>">New Details</a>
				
                <?php
                         $current_date=date('m/d/Y');
  					$date_diff=strtotime($current_date)-strtotime($t->purchase_date);
			        $final_date_diff=round($date_diff / (60 * 60 * 24));
					    if($final_date_diff>30)
					     {
						$glow_val='style="background-color: #da0606;
					  color: white;
					  -webkit-animation: glowing 1500ms infinite;
					  -moz-animation: glowing 1500ms infinite;
					  -o-animation: glowing 1500ms infinite;
					  animation: glowing 1500ms infinite;"';
					  echo '<button class="label label-lg " '.$glow_val.'  >Its Not Changed From Long Time</button>';
						}
						else
						{
							$glow_val='';
						}

						 
						?>
	     
			</td>
</tr>


<?php  }?>



</tbody>

</table>
<!--Problem end here -->








	

</div>
</section> 

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>




<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>



<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>





<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>



<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>







<script type="text/javascript">

	function add_text_field()
		{
			$('.new_txt_fld').append('<input type="text" name="add_sub_cat[]" class="form-control" style="border-color:black;" value="" />'); 
			return true;
		}
</script>


<script type="text/javascript">
	$(document).ready(function()
	{
		$('.select_variation').hide();

		var variation_sts=$("input[name='variation_status']:checked").val();
		if(variation_sts=="Yes")
		{
			$('.select_variation').show();
		}

		$('.main_cat').on('change', function() {		
		cat_id=$('select[name=cat]').val();
			  jQuery.ajax({
		            url:"<?php echo base_url().'Item_costing/sub_cat_list';?>",
		            type:"post",
		            data:{"cat_id":cat_id},
		            success:function(result)
		            {
		         		 $('.sub_cat_type').html(result);
		          	}
		        });
    		});

		$('.country_type').on('change', function() {		
		country_id=$('select[name=countries]').val();
			  jQuery.ajax({
		            url:"<?php echo base_url().'Item_costing/country_code_val';?>",
		            type:"post",
		            data:{"country_id":country_id},
		            success:function(result)
		            {
		         		 $('.hse_code_val').html(result);
		          	}
		        });
    		});

		$('input:radio').change(function() {
			var variation_type = $("input[name='variation_status']:checked").val();
			if(variation_type=="Yes")
			{
				$('.select_variation').show();
			}
			if(variation_type=="No")
			{
				$('.select_variation').hide();
			}		
  		});

		 $("input[name='selling_price']").change(function() {
			// console.log('insde the fun');
		 	var selling_price=$("input[name='selling_price']").val();
		 	if(selling_price!='')
		 	{
		 		uae_final_l1=$("input[name='uae_final_l1']").val();
		 		uae_final_l2=$("input[name='uae_final_l2']").val();
		 		ksa_final=$("input[name='ksa_final']").val();
		 		ksa_final_l1=$("input[name='ksa_final_l1']").val();
		 		ksa_final_l2=$("input[name='ksa_final_l2']").val();
		 		ksa_final_l3=$("input[name='ksa_final_l3']").val();

			uae_price1=selling_price*parseFloat(0.10);
		 	uae_price2=selling_price*parseFloat(0.25);
			ksa_final=parseFloat(selling_price)+parseFloat(12.5);
		 	ksa_price1=ksa_final*parseFloat(0.10);
		 	ksa_price2=ksa_final*parseFloat(0.20);
		 	ksa_price3=ksa_final*parseFloat(0.50);

		 $(".uae_final").val(parseFloat(selling_price) );
		 $(".uae_final_l1").val(parseFloat(selling_price)+parseFloat(uae_price1) );
		 $(".uae_final_l2").val(parseFloat(selling_price)+parseFloat(uae_price2) );
		 $(".ksa_final").val(ksa_final);
		 $(".ksa_final_l1").val(parseFloat(ksa_final)+parseFloat(ksa_price1) );
		 $(".ksa_final_l2").val(parseFloat(ksa_final)+parseFloat(ksa_price2) );
		 $(".ksa_final_l3").val(parseFloat(ksa_final)+parseFloat(ksa_price3) );
		 	}
		 	else
		 	{}
		 });
		  // $('.submit_main_form').on('click', function(e){
		  //       e.preventDefault();
		  //       $(".product_entry_form").submit();		      
    // 		});
  	});

	function variation_form(type)
	{
		
		test=$("input[name='var_name[]']")
              .map(function(){return $(this).val();}).get().join();
       
        test_val= $("input[name='var_val[]']")
              .map(function(){return $(this).val();}).get().join();

 		var_name=$('input[name=var_name]').val();
 		var_val=$('input[name=var_val]').val();
 		var_type=type;

 		if(var_name=='')
 		{
 			if($('select[name=var_name]').val()!='')
 			var_name=$('select[name=var_name]').val();		
 			else
 			var_name=test;
 		}
 		else{}
 		if(var_val=='')
 		{
 			var_val=test_val;
 		}
 		else{}
 		
		 jQuery.ajax({
            url:"<?php echo base_url().'Item_costing/credinals';?>",
            type:"post",
            data:{"name":var_name,"val":var_val,"type":var_type},
            success:function(result)
            {
            	//console.log(result);
            	 var posts = JSON.parse(result);

            	  if(type=="variation_form")
			        {
			        var group = $('<optgroup label="'+var_name+'" class="'+var_name+'">');
						$(".variation_type").append(group);
						 $.each(posts, function()
						{
						    group.append($('<option></option>').val(this.id).html(this.name));
						});
						// group.append($('</optgroup>'));
			        }

		       $.each(posts, function() {
			       	if(type=="brand")
			        {   
			        	$('.brand_type').append( $('<option></option>').text(this.name).val(this.id) );
			 		}
			        else if(type=="main-cat")
			        {
			        	$('.main_cat').append( $('<option></option>').text(this.name).val(this.id) );
			        }
			        else if(type=="country_form")
			        {
			        	$('.country_type').append( $('<option></option>').text(this.name).val(this.id) );
			        }
			        else if(type=="supplier_form")
			        {
			        	$('.suppliert_type').append( $('<option></option>').text(this.name).val(this.name) );
			        }
			        else if(type=="hse_form")
			        {
			        	$('.hse_type').append( $('<option></option>').text(this.name_en+':'+this.name_ar).val(this.id) );
			        	$('.hse_code_val').html(this.code);
			        }

			        else{}
		      	});
         		
  //        		$('.extra-form').find(':input').each(function() {
		//     switch (this.type) {
		//         case 'password':
		//         case 'select-multiple':
  //      			case 'select-one':
		//         case 'text':
		//         case 'textarea':
		//             $(this).val('');
		//             break;
		//         case 'checkbox':
		//         case 'radio':
		//             this.checked = false;
		//     }
		// });
            }
        });
	}
</script>

</body>
</html>