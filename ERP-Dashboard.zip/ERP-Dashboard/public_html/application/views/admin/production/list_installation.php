<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
.dropdown-divider
{
	border-bottom: 1px solid #08c;
}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Installation Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Installation Details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-----section for lightbox opens here-->
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">List Installation Details</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors"> <b> <?php echo $this->session->flashdata('errors');?></b></p>
            <p class="success"><b><?php echo $this->session->flashdata('success');?></b></p>
    </div>
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th>Action</th>
<th>Survey No</th>
<th>Customer Details</th>
<th>Cordinates</th>
<th>Installation Date</th>

<th>Current Status</th>
<th>PO status</th>
<th style="display: none;">Item Details</th>
<th></th>
</tr>
</thead>
<tbody>
<?php

	if(!empty($result))
	{
			$i=1;
	foreach($result as $index=>$q)
	{		
		if($q->st_id==$q->ins_survey_id)
		{	
?>
<tr>
	<td>
			<div class="dropdown-primary dropdown ">
<button class="btn btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Action</button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">
<!-- <a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalLg_<?php echo $q->ins_id;?>"><i class="fa fa-eye"></i>View</a> -->
<!-- <?php
	///if(($q->po_current_status >='4') || ($q->partial_po_status >='4'))/////if ready for delivery or partiall-ready for delivery
{
	?> -->
<div class="dropdown-divider"></div>
<!-- <a class="dropdown-item waves-light waves-effect" href=""><i class="fa fa-pencil"></i>Edit Details</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href=""><i class="fa fa-trash-o"></i>Delete </a>
<div class="dropdown-divider"></div> -->
<?php
if($q->ins_sts_installation!="completed")
{
?>
 <?php
 if(($this->session->userdata['user']['main_dept']=="Project Department") || ($this->session->userdata['user']['main_dept']=="Main"))
    	{?>
<!-- <a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('manage_installation/'.$q->ins_id);?>">Manage Installations</a>
<div class="dropdown-divider"></div> -->

<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes modal-basic" href="#modalSm_manage_installation_<?php echo $q->ins_id;?>">Manage Installations</a>
<div class="dropdown-divider"></div>
<?php
}?>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('list_scheduled/'.$q->ins_id);?>">List Scheduled Installations</a>
<div class="dropdown-divider"></div>
<!-- <a class="dropdown-item" href="<?php echo base_url('view_set_installation/'.$q->ins_id);?>">View Set Installation Data 
</a> -->
<?php
}?>

<?php
if($q->ins_sts_installation=="completed")
{
?>
<div class="dropdown-divider"></div>
	<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('generate_pdf_installation/'.$q->ins_id);?>">Generate PDF Installation</a>
<?php
}?>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('installation-history/'.$q->ins_id);?>"><i class="fa fa-history"></i>Check Installation History</a>
 <?php
 if(($this->session->userdata['user']['main_dept']=="Project Department") || ($this->session->userdata['user']['main_dept']=="Main"))
{?>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('return-installation-items/'.$q->ins_survey_id);?>"><i class="fa fa-pencil"></i>Return Installation Items</a>
<?php
}?>
<!-- <?php
}
?> -->
</div>
</div>			
		</td>
	<td><?php echo $q->st_survey_no;?></td>
	<td><?php echo $q->st_new_cust_name;?><br/><?php echo $q->st_new_cust_comp;?></td>
	<td><b>Start Cordinate:</b><br/><?php echo $q->st_start_cordinate;?><br/><b>End Cordinate:</b> <br/><?php echo $q->st_end_cordinate;?></td>
	<td><b>Installation Date Scheduled:</b> <br/><?php echo $q->ins_schedule_date;?>
	<br/><b>Installation Date Set:</b> <br/><?php if(!empty($q->ins_date_set_installation)){echo $q->ins_date_set_installation;}?></td>
	<td>
		<?php
			$color='';
			switch($q->ins_sts_installation)
			{
			case 'scheduled':
			$color='#f50057';
			break;
			
			case 'started':
			$color='#1567a0';
			break;

			case 'completed':
			$color='#00cc00';
			break;

			default:
			break;
			}
			?>
		<div class="btn-group">
  <button type="button" class="btn btn-sm" style="background-color:<?php echo $color;?>;color:white;"><?php echo $q->ins_sts_installation;?></button>

  <button type="button" class="btn btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color:<?php echo $color;?>;color:white;">
    <span class="fa fa-caret-down"></span>
  </button>
   <div class="dropdown-menu">
   	<?php
   	//if(($q->po_current_status >='4') || ($q->partial_po_status >='4'))/////if ready for delivery or partiall-ready for delivery
   		//{
   			if($q->ins_sts_installation=="scheduled")
   			{
 if( ($this->session->userdata['user']['main_dept']=="Project Department") || ($this->session->userdata['user']['main_dept']=="Main") )
    	{
   			?>
    <a class="dropdown-item" href="<?php echo base_url('change_sts_installation/'.$q->ins_id.'/started');?>">Started</a>
     <div class="dropdown-divider"></div>
    <?php
}
		}
		else{
			if($q->ins_sts_installation=="completed")
   			{
			?>	    			
 <!--    <div class="dropdown-divider"></div>
<a class="dropdown-item" href="<?php //echo base_url('complete_installation_details/'.$q->ins_id);?>">Complete Installation Details</a> -->
    	<div class="dropdown-divider"></div>
 <div class="dropdown-divider"></div>
 <?php
 if(($this->session->userdata['user']['main_dept']=="Project Department") || ($this->session->userdata['user']['main_dept']=="Main"))
    	{?>
    	<a class="dropdown-item mb-xs mt-xs mr-xs modal-sizes" href="#modalFullColorPrimary_<?php echo $q->ins_id;?>">Send mail customer</a>
    	<div class="dropdown-divider"></div>
    		<a class="dropdown-item" href="<?php echo base_url('installation_report/'.$q->ins_id);?>">View Installation Report</a>
    		<div class="dropdown-divider"></div>
    	<?php
    }?>
    	<?php
    		}
    		else
    	{
    		?>
    		<?php
    	
    		if(!empty($instalation_detail))
    			{
    				if($this->session->userdata['user']['main_dept']=="Factory Staff")
    			 {
    				if(!empty($emp_details[$index]))
    				{
    					foreach($emp_details[$index] as $ed)
    					{
    					//	pre_list($ed);
    						if($ed[0]->ed_pos=="FOREMAN")
    						{
    						$prd_set_final_calc_qnty=explode(',',$instalation_detail[$index][$index][0][0]->prd_set_final_calc_qnty);
    							if(array_filter($prd_set_final_calc_qnty)==false)
    							{
    		?>
 <div class="dropdown-divider"></div>
    	<a class="dropdown-item" href="<?php echo base_url('change_sts_installation/'.$q->ins_id.'/completed');?>">Completed</a><div class="dropdown-divider"></div>
    			<?php
    							}
    						
    					}
    				}
    			}
    		}
    		
    		}
    		else
    		{}
    	}
    	?>
    	<?php
    }
	//}
	//else
	//{
		?>
	<!-- <span class="label label-warning"><?php echo $q->ins_sts_installation;?></span><br/> -->
		<?php
	//}
	?>
  </div>
</div>	
<br/>
		<!-- <?php
		if($q->ins_sts_installation=="scheduled")
		{
			if(empty($q->ins_date_set_installation))
			{
			?>
		 <a class="mb-xs mt-xs mr-xs modal-sizes modal-basic btn btn-success" href="#modalSm_<?php echo $q->ins_id;?>">Click to set Installation date</a>
		<?php
			}
		}
		?> -->
	</td>
	<td><?php
	$po_sts='';
	switch ($q->po_current_status) {
		case '1':
			$po_sts="Pending";
			break;
			case '2':
			$po_sts="Approved";
			break;
			case '3':
			$po_sts="On Production";
			break;
			case '4':
			$po_sts="Ready for delivery";
			break;
			case '5':
			$po_sts="Delivered";
			break;
			case '0':
			$po_sts="Rejected";
			break;
		
		default:
			# code...
			break;
	}
	echo $po_sts;
	?>
	
	</td>
		<td>
			<table class="table table-bordered">
			<thead>
				<th>Item Name</th>
				<th>Quantity</th>
			</thead>
			<tbody>
		<?php  
$quantities=explode('|#|',$q->st_po_prd_qtys);
$remarks=explode('|#|',$q->st_po_prd_additional_info);
	foreach($prd_ids[$index] as $pid)
	{
		
		foreach($pid as $inndex=>$ppid)
		{
		$pname=explode('|~~|',$ppid[0]->pname);
			echo "<tr>";
			echo "<td>".$pname[0].'<br/> ('.$ppid[0]->pcode.')'."</td>";
			if(!empty($quantities[$inndex]))
			echo "<td>".$quantities[$inndex]." </td>";
				else
			echo "<td> 0 </td>";
		echo "</tr>";
		}
		
	//$prds=explode(',',$q->st_po_prd_ids);
	}
	?>
	</tbody>
		</table>
		</td>
		<td style="display: none;"><?php echo $i++;?></td>
</tr>

<!-- Button trigger modal 3-->
 <div id="modalSm_manage_installation_<?php echo $q->ins_id;?>" class="modal-block  modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Schedule Installation Date</h2>
</header>
<?php echo form_open('submit_set_installation_date');?>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-icon">
<i class="fa fa-calendar"></i>
</div>
<div class="modal-text">
<h4> Schedule Installation Date</h4>
<p>Please choose an installation date for next installation.</p>
<input type="hidden" name="installation_id" value="<?php echo $q->ins_id;?>">
<input type='text' name="mange_installation_date" class="form-control datetimepicker4" value=""  autocomplete="off" />
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-default" type="submit">Confirm</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!----end modal--->


<!-----------modal for view------>
<div id="modalLg_<?php echo $q->ins_id;?>" class="modal-block  modal-block-lg modal-header-color modal-block-info  mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">View Installation Details</h2>
</header>
<div class="panel-body">
		<div class="col-md-12" style="margin-bottom: 2%;">
			<div class="col-md-4">
				<b>Survey No. :</b><?php echo $q->st_survey_no;?><br/>
				<b>Installation Schedule Date:</b> <?php echo $q->ins_schedule_date;?><br/>
				<b>New installation Set Date:</b><?php if(!empty($q->ins_date_set_installation)){echo $q->ins_date_set_installation;}?><br/>
				<b>Cordinates:</b>Start Cordinate:<?php echo $q->st_start_cordinate;?><br/>End Cordinate: <?php echo $q->st_end_cordinate;?><br/>
				<b>Installation created by:</b><?php echo $q->st_user_created;?><br/>
				<b>Installation Status:</b><?php echo $q->ins_sts_installation;?><br/>
			</div>
		<div class="col-md-4">
				<p>Company: <?php echo $q->st_new_cust_comp;?></p>
				<p>Customer: <?php echo $q->st_new_cust_name;?></p>			
		
		</div>	
		<div class="col-md-4">					
				<p>Additional Description</p><br/>
				<?php echo $q->st_additional_desc;?>
		</div>
				
		</div>
		
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-default modal-dismiss">Close</button>
</div>
</div>
</footer>
</section>
</div>
<!-------end modal for view----->


<!-- Button trigger modal 3-->
 <div id="modalSm_<?php echo $q->ins_id;?>" class="modal-block  modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Are you sure?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-icon">
<i class="fa fa-question-circle"></i>
</div>
<div class="modal-text">
<h4>Schedule Installation Date</h4>
<p>Are you sure , you want to send this installation details as email to customer?</p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
	<a href="<?php echo base_url('send_installation_mail_customer/'.$q->ins_id);?>" class="btn btn-primary">Confirm</a>

<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal--->

<!------permission for sending customer email---->

<div id="modalFullColorPrimary_<?php echo $q->ins_id;?>" class="modal-block  modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Are you sure?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-icon">
<i class="fa fa-question-circle"></i>
</div>
<div class="modal-text">
<h4>Send email to customer</h4>
<p>Are you sure , you want to send this installation details as email to customer?</p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
	<a href="<?php echo base_url('send_installation_mail_customer/'.$q->ins_id);?>" class="btn btn-primary">Confirm</a>

<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<!-------end customer email----->
<?php
}
}
}
?>

</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	 $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
   <script type="text/javascript">
         $(function () {
              $('.datetimepicker4').datepicker({format: 'dd/mm/yyyy' });
             // $(".datetimepicker4").datepicker();
              //  $('.datetimepicker4').datepicker({ dateFormat: 'dd/mm/yyyy' }).datepicker();
            });
        </script>
</body>
</html>