<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>


  
    <!-- jsFiddle will insert css and js -->
<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}

</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Complete Installation Details for current Installation</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Complete</span></li>
<li><span>Installation Details</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">

<!-----div starts here for details---->

<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Survey # <?php echo $survey_details[0]->st_survey_no;?> - Complete Installation Details for current Installation</h2>
</header>
<div class="panel-body">  
  <?php echo form_open_multipart('submit_complete_installation','class="myform"','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
<input type="hidden" name="installation_id" value="<?php echo $installation_detail_id;?>">
<input type="hidden" name="edit_survey_id" value="<?php if(!empty($survey_details[0]->st_id)){echo $survey_details[0]->st_id;};?>">

<input type="hidden" name="prd_set_ids" value="<?php if(!empty($result[0]->insd_prd_set_ids)){echo $result[0]->insd_prd_set_ids;};?>">
<input type="hidden" name="single_prd_ids" value="<?php if(!empty($survey_details[0]->st_single_prds)){echo $survey_details[0]->st_single_prds;};?>">

   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>
<!----any additonal notes-->
<div class="row">
  <div class="col-md-12 table-rows-border">

    <div class="col-md-6 col-sm-12>
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Actual Start Date of this Installation </label>

<div class="col-md-8">
<div class="input-group">
  <input class="form-control datetimepicker4" name="actual_start_date_installation" >
</div>
 
 <div class="form_error">  <?php echo $this->session->flashdata('actual_start_date_installation');?></div>
</div> 
</div>

<div class="col-md-6 col-sm-12>
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Actual End Date of this Installation </label>

<div class="col-md-8">
<div class="input-group">
  <input class="form-control datetimepicker4" name="actual_end_date_installation" >
</div>
 
 <div class="form_error">  <?php echo $this->session->flashdata('actual_end_date_installation');?></div>
</div> 
</div>

<div class="col-md-6 col-sm-12>
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Total working hours </label>

<div class="col-md-8">
<div class="input-group">
  <input class="form-control " name="total_working_hours" >
</div>
 
 <div class="form_error">  <?php echo $this->session->flashdata('total_working_hours');?></div>
</div> 
</div>

</div>
</div>
     <!------end of add notes--->

    <!---labour performance---->
<div class="row">
     <h2>Workers Analysis section</h2>

<div class="col-md-12 table-rows-border">
<h4> Attendance Analysis section</h4>

    <?php foreach($labour_info as $la)
    {
      if(!empty($la))
      {
      ?>
       <div class="col-md-6 col-sm-12 table-rows-border" >
    <div class="form-group">
        <label class="col-md-4 control-label" for="inputPlaceholder">Was <?php echo $la[0]->ed_name;?> avaialable on the day of installation?<abbr class="required">::*::</abbr></label>
         <div class="col-md-8">
          <input type="hidden" name="inst_workers_id[]" value="<?php echo $la[0]->ed_id;?>">   
          <input type="hidden" name="workers_final_id_<?php echo $la[0]->ed_id;?>" value="<?php echo $la[0]->ed_id;?>">      
            <input type="radio" name="attedance_<?php echo $la[0]->ed_id;?>" value="Yes" onclick="show_extras(<?php echo $la[0]->ed_id;?>,'yes');">Yes
            <input type="radio" name="attedance_<?php echo $la[0]->ed_id;?>" value="No" onclick="show_extras(<?php echo $la[0]->ed_id;?>,'no');"> No
       <div class="open_for_no_<?php echo $la[0]->ed_id;?>" style="display: none;">     
              <label class="col-md-12 control-label" for="inputPlaceholder">If "No", mention the reason:</label>
         <textarea class="form-control" name="attedance_is_no_<?php echo $la[0]->ed_id;?>"></textarea>
               <label class="col-md-12 control-label" for="inputPlaceholder">Select the labour replaced with:</label>
         <select class="form-control" name="labour_replaced_<?php echo $la[0]->ed_id;?>" onchange="labour_replaced(<?php echo $la[0]->ed_id;?>);">
          <option value="">Choose</option>
           <?php
           foreach($labour as $lb)
           {
            ?>
            <option value="<?php echo $lb['ed_id'];?>"><?php echo $lb['ed_name'];?></option>
            <?php
           }
            ?>
         </select>
       </div>
             <div class="form_error">  </div>
        </div>
    </div>
  </div>
    <?php
  }
  }?>
  </div>
   
  <div class="col-md-12 table-rows-border">
<h4> Performance Analysis section</h4>
    <?php foreach($labour_info as $la)
    {
      if(!empty($la))
      {
      ?>
       <div class="col-md-6 col-sm-12 table-rows-border" >
    <div class="form-group">
        <label class="col-md-4 control-label" for="inputPlaceholder">Work quality of <span class="labour_name_<?php echo $la[0]->ed_id;?>"><?php echo $la[0]->ed_name;?></span><abbr class="required">::*::</abbr></label>
         <div class="col-md-8">
            <input type="radio" name="work_quality_<?php echo $la[0]->ed_id;?>" value="Excellent">Excellent<br>
            <input type="radio" name="work_quality_<?php echo $la[0]->ed_id;?>" value="Good"> Good<br>
            <input type="radio" name="work_quality_<?php echo $la[0]->ed_id;?>" value="Satisfactory"> Satisfactory<br>
            <input type="radio" name="work_quality_<?php echo $la[0]->ed_id;?>" value="Poor"> Poor<br>
            <input type="radio" name="work_quality_<?php echo $la[0]->ed_id;?>" value="Very Poor"> Very Poor<br>

              <div class="form_error">  </div>
              
             <div class="form_error">  </div>
        </div>
    </div>
  </div>
    <?php
  }
  }?>
  </div>
  <div class="col-md-12 table-rows-border">
<h4> Work Analysis section</h4>
    <?php foreach($labour_info as $la)
    {
      if(!empty($la))
      {
      ?>
       <div class="col-md-6 col-sm-12 table-rows-border" >
    <div class="form-group">
        <label class="col-md-4 control-label" for="inputPlaceholder">Number of Pipe Installed by <span class="labour_name_<?php echo $la[0]->ed_id;?>"><?php echo $la[0]->ed_name;?></span><abbr class="required">::*::</abbr></label>
         <div class="col-md-8">
            <input type="text" name="pipe_installed_<?php echo $la[0]->ed_id;?>" value=""><br>
            <div class="form_error">  </div>
        </div>
    </div>
  </div>
    <?php
  }
  }?>
  </div>
</div>
     <!---end labour performance---->

   <!----vehicle usage-->
<div class="row">
     <h2>Vehicle Analysis section</h2>
  <div class="col-md-12 table-rows-border">
 <div class="form-group">

<?php foreach($veh_info as $vh)
    {
      if(!empty($vh))
      {
      ?>
<div class="col-md-8">
 <div class="form-group">
        <label class="col-md-4 control-label" for="inputPlaceholder">Was vehicle plate numbered <?php echo $vh[0]->veh_plate_no;?> avaialable on the day of installation? <abbr class="required">::*::</abbr></label>
         <div class="col-md-8">
          <input type="hidden" name="veh_id_installation[]" value="<?php echo $vh[0]->veh_id;?>">
            <input type="radio" name="veh_used_<?php echo $vh[0]->veh_id;?>" value="Yes">Yes
            <input type="radio" name="veh_used_<?php echo $vh[0]->veh_id;?>" value="No"> No
              <label class="col-md-12 control-label" for="inputPlaceholder">If "No", mention the replacement vehicle details:</label>
         <textarea class="form-control" name="veh_used_is_no_<?php echo $vh[0]->veh_id;?>"></textarea>
             
             <div class="form_error">  </div>
        </div>
    </div>
</div> 
<?php
}
}
?>
</div>

</div>
</div>

     <!------end of veh usage--->

      <!----tools usage-->
<div class="row">
     <h2>Tools Analysis section</h2>
  <div class="col-md-12 table-rows-border">
  <div class="form-group">

<?php foreach($tool_info as $ta)
    {
      if(!empty($ta))
      {
      ?>
<div class="col-md-8">
 <div class="form-group">
        <label class="col-md-4 control-label" for="inputPlaceholder">Was <?php echo $ta[0]->tool_name;?> used on the day of installation?<abbr class="required">::*::</abbr></label>
         <div class="col-md-8">
          <input type="hidden" name="tools_id_installation[]" value="<?php echo $ta[0]->tool_id;?>">
            <input type="radio" name="tool_used_<?php echo $ta[0]->tool_id;?>" value="Yes">Yes
            <input type="radio" name="tool_used_<?php echo $ta[0]->tool_id;?>" value="No"> No
              <label class="col-md-12 control-label" for="inputPlaceholder">If "No", mention the reason:</label>
         <textarea class="form-control" name="tool_used_is_no_<?php echo $ta[0]->tool_id;?>"></textarea>
             
             <div class="form_error">  </div>
        </div>
    </div>
</div> 
<?php
}
}
?>
</div>

</div>
</div>
     <!------end of tools usage--->

     <!----any additonal notes-->
<div class="row">
  <div class="col-md-12 table-rows-border">
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Additional Notes</label>

<div class="col-md-8">
<div class="input-group">
  <textarea class="form-control editors" name="add_notes"><?php if(!empty($result[0]->q_add_notes)){echo $result[0]->q_add_notes;};?></textarea>
</div>
 
 <div class="form_error">  <?php echo $this->session->flashdata('add_notes');?></div>
</div> 
</div>

</div>
</div>
     <!------end of add notes--->
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>

<th>Product Sets</th>
<th>Product Singles</th>

</tr>
</thead>
<tbody>
<tr>
  <td>
    <table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
      <thead>
        <tr>
          <th>Image</th>
            <th>Add Final Cordinates </th>
            <th>Upload Images </th>
         <!--  <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
    <?php
    $prd_set_ids=$result[0]->insd_prd_set_ids;

    if(!empty($prd_set_ids)){
      $prd_set_qnty_installated=$result[0]->insd_prd_set_qty_installed;
    }
    if(!empty($prd_ids_1))
    {  
    foreach($prd_ids_1 as $index_p=>$p1)
          {
            $alignment=$prd_set_details[$index_p]->psd_prd_alignment;
            $prod_position=explode(',',$prd_set_details[$index_p]->psd_arrange_position);

            // pre_list($prod_position);
            // pre_list($p1);
            foreach($prod_position as $pd2)
            {
            //pre_list($pd2);
            //pre_list($p1[$pd2][0]->pname);
              if(empty($p1[$pd2][0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
                 }
  
                 $prd_height[$index_p][]=$p1[$pd2][0]->prd_height;
                 $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
                 $prod_sets_image[$index_p][]=$img_path;
                 $prod_sets_alignment[$index_p]=$alignment;
                 $prod_sets_position[$index_p]=$prod_position;
                 $prd_set_id[$index_p]=$prd_set_details[$index_p]->psd_id;

                $prod_sets_qty_orginal[$index_p]=$prd_set_details[$index_p]->psd_prd_qty;
                $qty_installed[$index_p]=$prd_set_details[$index_p]->psd_qty_installed;
                $qty_remaining[$index_p]=$prd_set_details[$index_p]->psd_qty_remaining_installation;

            }
          }
          
          $ij=1;
          foreach($prod_sets_alignment as $index=>$align)
          {
            //pre_list($index);
           if(!empty($result))
                  {
                    $prd_set_qnty_to_install=explode(',',$result[0]->insd_prd_set_qty_set_for_installation);
                    $prd_set_qnty_remaining=explode(',',$result[0]->insd_prd_set_remaining_qnty);
                    $prd_set_qnty_insatlled=explode(',',$result[0]->insd_prd_set_qty_installed);
                    $prd_set_qnty_remaining_after_installed=explode(',',$result[0]->insd_prd_set_remaining_after_installation);
                    $prd_set_qnty_final_remaining=explode(',',$result[0]->prd_set_final_calc_qnty);
                  }
                  // pre_list($prd_set_qnty_insatlled[$index]);
     if($align=="vertical")
            {
              //pre_list(implode(',',$prod_sets_image[$index]));
              echo "<tr>";
            echo "<td>";
            asort($prod_sets_position[$index]);
            foreach($prod_sets_position[$index]  as $index22=>$ptt)
              {
          
                if(!empty($prod_sets_image[$index][$index22]))
              echo "<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
              else
              echo "";
              }
              echo "<input type='hidden' name='prd_set_id_with_data[]' class='prd_set_ids_".$ij."' value='".$prd_set_id[$index]."'>
              <input type='hidden' name='prd_set_qnty_installed_with_data[]' value='".$prd_set_qnty_insatlled[$index]."'>
               </td>";
       echo ' <td> <b>Total Quantity Installed :'.$prd_set_qnty_insatlled[$index].'</b><br/>';
    for($kl=$prd_set_qnty_insatlled[$index];$kl>0;$kl--)
     { 
       echo  'Sign Cordinate:<input type="text" class="form-control" name="prd_set_start_cordinate[]" pattern="([0-9.-]+).+?([0-9.-]+)"><br/>';
     }
     echo '</td>';
       echo '<td> <b>Total Quantity Installed :'.$prd_set_qnty_insatlled[$index].'</b><br/>'; 
      for($kl=$prd_set_qnty_insatlled[$index];$kl>0;$kl--)
     {      
      echo '<input type="file" class="form-control single_prd_file_'.$ij.'_'.$kl.'" onchange="readURL('.$ij.','.$kl.');" ><br/>
        <input type="hidden" name="prd_set_img_uploaded[]" class="prd_set_img_uploaded_'.$ij.'_'.$kl.'">
       <small style="color: red"> Only choose image size less than 1MB.</small><br/>
        
        <img src="" class="inital_preview_'.$ij.'_'.$kl.'" img_inital_preview" width="150" height="180" style="display: none;">
        <div class="preview_single_prd_'.$ij.'_'.$kl.'"></div>

        <button class="btn btn-sm btn-primary img_upload_button_'.$ij.'_'.$kl.'" type="button" onclick="prd_set_file_upload('.$ij.','.$kl.');" style="display:none;">Click here to Upload</button><br/><hr/>';
      }
      echo '</td>';
        echo "</tr>";
            }
            else
            {
              echo "<tr>";
              echo "<td>";
              asort($prod_sets_position[$index]);
              foreach($prod_sets_position[$index]  as $index22=>$ptt)
              {
                    if(!empty($prod_sets_image[$index][$index22]))
              echo "<img src='".$prod_sets_image[$index][$index22]."' width='80' height='100'>";
              else
              echo "";
              }
               echo "<input type='hidden' name='prd_set_id_with_data[]' class='prd_set_ids_".$ij."' value='".$prd_set_id[$index]."'> 
                <input type='hidden' name='prd_set_qnty_installed_with_data[]' value='".$prd_set_qnty_insatlled[$index]."'>
               </td>";
              echo '<td>
              <b>Total Quantity Installed :'.$prd_set_qnty_insatlled[$index].'</b><br/>';
     for($kl=$prd_set_qnty_insatlled[$index];$kl>0;$kl--)
    {           
    echo 'Sign Cordinate:<input type="text" class="form-control" name="prd_set_start_cordinate[]" pattern="([0-9.-]+).+?([0-9.-]+)"><br/>';
    }
    echo'</td>';
     echo'<td>
        <b>Total Quantity Installed :'.$prd_set_qnty_insatlled[$index].'</b><br/>';  
    for($kl=$prd_set_qnty_insatlled[$index];$kl>0;$kl--)
    {  
       echo '<input type="file" class="form-control single_prd_file_'.$ij.'_'.$kl.'" onchange="readURL('.$ij.','.$kl.');" ><br/>
        <input type="hidden" name="prd_set_img_uploaded[]" class="prd_set_img_uploaded_'.$ij.'_'.$kl.'">
       <small style="color: red"> Only choose image size less than 1MB.</small><br/>
        
        <img src="" class="inital_preview_'.$ij.'_'.$kl.'" img_inital_preview" width="150" height="180" style="display: none;">
        <div class="preview_single_prd_'.$ij.'_'.$kl.'"></div>

        <button class="btn btn-sm btn-primary img_upload_button_'.$ij.'_'.$kl.'" type="button" onclick="prd_set_file_upload('.$ij.','.$kl.');" style="display:none;">Click here to Upload</button><br/><hr/>';
    }    
     echo'</td>';
        
              echo "</tr>";               
            }
            $ij++;
          }
        ?>   
    <?php      
    }
    ?>
    </tbody>
    </table>
  </td>
  <td>
    <table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
      <thead>
        <tr>
          <th>Image</th>
           <th>Add Final Cordinates </th>
            <th>Upload Images </th>
          <!-- <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
    <?php
         
$ik=50;
 if(!empty($prd_ids_2))
 {
  $prd_single_installed=explode(',',$result[0]->insd_prd_single_qty_installed);
  $filtered_installed_values=array_values(array_filter($prd_single_installed));
      foreach($prd_ids_2 as $index2=>$pd2)
      { 
       if(empty($pd2[0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$pd2[0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->p_prd_img;
                 }
      ?>
    <tr>

      <td><img src="<?php echo $img_path;?>"  width='100' height='100'>
      <input type="hidden" name="prd_single_id_with_data[]" class="single_prd_id_<?php echo $ik;?>" value="<?php echo $pd2[0]->pid;?>" name="">
 <input type='hidden' name='prd_single_qnty_installed_with_data[]'  value='<?php echo $filtered_installed_values[$index2];?>'>
    </td>
      <td>
         <b>Total Quantity Installed : <?php echo $filtered_installed_values[$index2];?> </b><br/>
        <?php
        for($kl=$filtered_installed_values[$index2];$kl>0;$kl--)
        {
        ?>    
         Sign Cordinate:<input type="text" class="form-control" name="single_prd_start_cordinate[]" pattern="([0-9.-]+).+?([0-9.-]+)"><br/>
         <?php
        }
       ?>
      </td>
      <td>
          <b>Total Quantity Installed : <?php echo $filtered_installed_values[$index2];?> </b><br/>
      <?php
        for($kl=$filtered_installed_values[$index2];$kl>0;$kl--)
        {
        ?>  
        <input type="file" class="form-control single_prd_file_<?php echo $ik;?>_<?php echo $kl;?>" onchange="readURL('<?php echo $ik;?>','<?php echo $kl;?>')" ><br/>
        <input type="hidden" name="single_prd_img_uploaded[]" class="single_prd_img_uploaded_<?php echo $ik;?>_<?php echo $kl;?>">
       <small style="color: red"> Only choose image size less than 1MB.</small><br/>
        
        <img src="" class="inital_preview_<?php echo $ik;?>_<?php echo $kl;?> img_inital_preview" width="150" height="180" style="display: none;">
        <div class="preview_single_prd_<?php echo $ik;?>_<?php echo $kl;?>"></div>

        <button class="btn btn-sm btn-primary img_upload_button_<?php echo $ik;?>_<?php echo $kl;?>" type="button" onclick="single_prd_file_upload('<?php echo $ik;?>','<?php echo $kl;?>')" style="display: none;">Click here to Upload</button><br/><hr/>
        <?php
        }
      ?>
      </td>
    </tr>
    <?php
    $ik++;
    }
  }
    ?>
    </tbody>
    </table>
  </td>
  
</tr>
<!-----------modal for setting installation date----->
<!---------end installation date---->
</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->
<input type="hidden" name="base_url" value="<?php echo base_url();?>">
<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script type="text/javascript">
   $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );
</script>


<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
   <script type="text/javascript">
          $(function () {
               $('.datetimepicker4').datepicker({format: 'dd/mm/yyyy' });
            });
         
        </script>
 
   <script type="text/javascript">

     function readURL(id,qnty_index) {
       console.log(qnty_index);
    var file_data = $('.single_prd_file_'+id+'_'+qnty_index).prop('files')[0];
    var reader = new FileReader();
    
    reader.onload = function(e) {
       console.log(qnty_index);
       $('.inital_preview_'+id+'_'+qnty_index).attr('src', e.target.result);
      $('.inital_preview_'+id+'_'+qnty_index).show();
      $('.img_upload_button_'+id+'_'+qnty_index).show();
    }   
    reader.readAsDataURL(file_data); // convert to base64 string
  }
     function single_prd_file_upload(id,qnty_index)
     {
      console.log(qnty_index);
      var base_url=$('input[name="base_url"]').val();   
      var file_data = $('.single_prd_file_'+id+'_'+qnty_index).prop('files')[0];
      var form_data = new FormData();
        form_data.append('instlation_img_single', file_data);       
      $.ajax({
              url:"<?php echo base_url().'Installation_controller/single_prd_img_upload';?>",
              data:form_data,
              processData: false,
              contentType: false,
              type: 'post',
              success:function(result)
              {
                if(result)
                {
                alert('upload successful');
                $(".single_prd_img_uploaded_"+id+'_'+qnty_index).val(result);
                var picture = '<img src="'+base_url+'uploads/installation/'+result+'" style="width:150px;height:200px;">';
                $('.inital_preview_'+id+'_'+qnty_index).hide();
                $(".preview_single_prd_"+id+'_'+qnty_index).empty().append(picture);
                }
              }
        });
     }

     function prd_set_file_upload(id,qnty_index)
     {
        console.log(qnty_index);
      var base_url=$('input[name="base_url"]').val();
    
      var file_data = $('.single_prd_file_'+id+'_'+qnty_index).prop('files')[0];
      var form_data = new FormData();
        form_data.append('instlation_img_single', file_data);

      $.ajax({
              url:"<?php echo base_url().'Installation_controller/prd_set_img_upload';?>",
              data:form_data,
              processData: false,
              contentType: false,
              type: 'post',
              success:function(result)
              {
                if(result)
                {
                  alert('upload successful');
                
                $(".prd_set_img_uploaded_"+id+'_'+qnty_index).val(result);
                var picture = '<img src="'+base_url+'uploads/installation/'+result+'" style="width:150px;height:200px;">';
                $('.inital_preview_'+id+'_'+qnty_index).hide();
                $(".preview_single_prd_"+id+'_'+qnty_index).empty().append(picture);
                }
              }
     });
    }
   </script>   
   <script type="text/javascript">
    function show_extras(id,option_selected)
    {
      if(option_selected=='yes')
      {
        $('.open_for_no_'+id).hide();
        }
      else
      {
         $('.open_for_no_'+id).show();
      }
    }

     function labour_replaced(current_lab_id)
     {  
        var new_lab_selected_id=$('select[name="labour_replaced_'+current_lab_id+'"] option:selected').val();
         var new_lab_selected_name=$('select[name="labour_replaced_'+current_lab_id+'"] option:selected').text();
         $('.labour_name_'+current_lab_id).html(new_lab_selected_name);
         $('input[name="workers_final_id_'+current_lab_id+'"]').val(new_lab_selected_id);
       
     }
   </script>  
</body>

</html>