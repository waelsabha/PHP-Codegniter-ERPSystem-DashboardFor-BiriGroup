<!doctype html>
<html class="fixed">


<head>

<?php $this->load->view('admin/head');?>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/morris/morris.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/pie_country.css" />

<style type="text/css">
  img {
    max-width: 100%;
    max-height: 100%;
}

.portrait {
    height: 80px;
    width: 30px;
}

.landscape {
    height: 30px;
    width: 80px;
}

.square {
    max-width: 100%;
    max-height: 100%;
}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Dashboard</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Dashboard</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>
<!----------------div for po main factory-------->
<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">

 <!--------here starts introduction of the whole thing------------------------>
<p>
<a class="btn btn-primary " data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
  Click for System Introduction
  </a></p>
<div class="collapse" id="collapseExample">
  <section class="panel">
<div class="panel-body">
 
 <!------div row started------>
<div class="row">
 <div class="col-md-6"  data-intro="Create Survey" data-step="1" data-hint="Create a sruvey to start!">
  <span class="badge" style="background: red;">1</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Create Survey</h2>
</header>
<div class="panel-body">
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
<p>Start with creating survey. For creating survey, choose customer (if customer not found, then add as a new customer).
        Add map-cordinates, height requirements and choose items which needed to use in the survey. </p>    
<div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/1.png');?>" class="img-fluid card-img-top" >
</div>
</div>
</div>
</div>
</section>
</div>

<div class="col-md-6"  data-intro="Add Items for Survey" data-step="2" data-hint="Here you will be selecting items for survey.">
    <span class="badge" style="background: red;">2</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Add Items for Survey</h2>
</header>
<div class="panel-body">

<p>Search for items which need to be installed in the survey and add them . Details entered in the column "Additional Description" is send to Production Order Department(which needed to be done on-production). </p>   
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/2.png');?>" class="img-fluid card-img-top" >
</div>

</div>
</section>
</div>

<div class="col-md-6"  data-intro="Create Product Sets" data-step="3" data-hint="Assign items as product sets">
    <span class="badge" style="background: red;">3</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Create Product Sets</h2>
</header>
<div class="panel-body">
<p><b>Create product sets</b> For creating product set, choose which all item consist in one set. Then click on "Click to create product set".When you first assign a group of items and create it as a set, #ProductSet-1 is created. Repeat the same process , till you finish all needed product sets are created.</p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/3.png');?>" class="img-fluid card-img-top" >
</div>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/4.png');?>" class="img-fluid card-img-top" >
</div>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/5.png');?>" class="img-fluid card-img-top" >
</div>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/6.png');?>" class="img-fluid card-img-top" >
</div>

</div>
</section>
</div>

<div class="col-md-6"  data-intro="Create Product Singles" data-step="4" data-hint="Assign items as product Singles">
    <span class="badge" style="background: red;">4</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Create Product Singles</h2>
</header>
<div class="panel-body">
 <p><b>Create product singles</b> For creating product singles, choose which all item consist needs to be installed as single items. Choose all the single items in one single time. Once you select the items for single sets, you cannot keep selecting other items as single again. Once items are selected click on "Click to create single set". Submit the form, which will create your survey a mail will be send with the details of the survey.</p>
<div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/7.png');?>" class="img-fluid card-img-top" >
</div>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/8.png');?>" class="img-fluid card-img-top" >
</div>

</div>
</section>
</div>

</div>


<div class="row">
<div class="col-md-6"  data-intro="List Survey" data-step="5" data-hint="Full list of all surveys created">
    <span class="badge" style="background: red;">5</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">List Survey</h2>
</header>
<div class="panel-body">
  <p> Go to "LIST SURVEY", to see the survey created. Here you can edit the details of the created survey(do it before sending for Production). 
Click on "Manage Products ". Add quantity, Pipe height, Serial Number, and map-cordinates(map-cordinate of the item where it need to be installed) for each of the sets/singles.  "Pipe Height " will be calculated as per the height of the item along with height data entred when the survey was created. </p>
<p>You have the option to remove any product item set or product single item, in the "Manage Product Set".</p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/9.png');?>" class="img-fluid card-img-top" >
</div>

</div>
</section>
</div>

<div class="col-md-6" data-intro="Manage Product Sets" data-step="6" data-hint="Manage Product Sets/Singles, add quantity information">
    <span class="badge" style="background: red;">6</span>
<section class="panel panel-featured" >
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Manage Product Sets</h2>
</header>
<div class="panel-body">
  <p>Manage Product Sets: Here you can manage the product set you created . Here you can a choose the alignment of the item (horizontal or vertical) . The order in which items will be aligned (position). See the "Preview Image" to see how the final output will be.  </p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/10.png');?>" class="img-fluid card-img-top" >
</div>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/11.png');?>" class="img-fluid card-img-top" >
</div>

</div>
</section>
</div>

<div class="col-md-6" data-intro="Manage Product Singles" data-step="7" data-hint="Manage Product Sets/Singles, add quantity information">
    <span class="badge" style="background: red;">7</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Manage Product Singles</h2>
</header>
<div class="panel-body">
  <p> Manage Product Singles : Manage each single items by entering the map cordinate, serial number , quantity details. </p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/12.png');?>" class="img-fluid card-img-top" >
</div>

</div>
</section>
</div>

<div class="col-md-6" data-intro="Survey Successfully Created" data-step="8" data-hint="Success page after successful creation of survey">
    <span class="badge" style="background: red;">8</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Status Page</h2>
</header>
<div class="panel-body">
  <p>Once all the items are managed and status is "DONE". You can send it for Production. The quantity of each item send for production is calculated as per the quantity entered in the "Manage product set".</p>
<p>A success page will be displayed with all the details added in the "Manage Product Set".</p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/13.png');?>" class="img-fluid card-img-top" >
</div>

<p>After sending for "Production", wait for production and when the status from the production is "Ready for Delivery", you can set the "Installation Details".(The production can be started, even if production is not "Ready for Delivery")</p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/14.png');?>" class="img-fluid card-img-top" >
</div>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/15.png');?>" class="img-fluid card-img-top" >
</div>
</div>
</section>
</div>

</div>

<div class="row">
<div class="col-md-6" data-intro="List Installation" data-step="9" data-hint="List of all surveys assigned for installation">
    <span class="badge" style="background: red;">9</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">List Installation</h2>
</header>
<div class="panel-body">
  <p> Go to "List Installation" , Set "Installation Schedule Date".</p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/16.png');?>" class="img-fluid card-img-top" >
</div>

<p>Choose options under "Action" button.</p>

 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/18.png');?>" class="img-fluid card-img-top" >
</div>


</div>
</section>
</div>

<div class="col-md-6" data-intro="Manage Installation" data-step="10" data-hint="Assign all the requirements needed to start the installation">
    <span class="badge" style="background: red;">10</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Manage Installation</h2>
</header>
<div class="panel-body">
  <p>Manage Installation : Here you can assign the quantity needed to be installed for each installation. Assign vehicle, Tools and Labours who need to go for the installation.</p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/19.png');?>" class="img-fluid card-img-top" >
</div>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/20.png');?>" class="img-fluid card-img-top" >
</div>
<p>Once it is done, for editing the details of manage installation, go to "View Installation Set" and edit details.</p>
<p>Change Installation status from "Scheduled" to "Started". Also, you can download the PDF for the current installation created.</p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/21.png');?>" class="img-fluid card-img-top" >
</div>

</div>
</section>
</div>

</div>

<div class="row">
<div class="col-md-6" data-intro="Login : FOREMAN" data-step="11" data-hint="Foreman will take care of installation">
    <span class="badge" style="background: red;">11</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Login as Foreman</h2>
</header>
<div class="panel-body">
  <p>Installation Login: Only the FOREMAN can change the installation assigned data. Foreman can login to his account, where he can see the installation assigned by Project Engineer under 'List Installation'. </p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/22.png');?>" class="img-fluid card-img-top" >
</div>

<p>After logged in, he can go to "View set installation data", where he need to manage the installed items.</p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/23.png');?>" class="img-fluid card-img-top" >
</div>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/24.png');?>" class="img-fluid card-img-top" >
</div>

<p>Out of all the assigned quantity for installation, FOREMAN can enter, who much was acutally installed. So the remianing will be calculated by the system. The remaining will get added to the remaining products waiting for installation. </p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/25.png');?>" class="img-fluid card-img-top" >
</div>

</div>
</section>
</div>

<div class="col-md-6" data-intro="Important Step in Installation" data-step="12" data-hint="Important Step in installation">
    <span class="badge" style="background: red;">12</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Survey Installation Details</h2>
</header>
<div class="panel-body">
  <p>After FOREMAN submit the details of the installed quantity, he need to enter actuall Map-Cordinates of each item,along with one image of the installed item.</p>
<p>NOTE: A installation submitted is considered successful, only when he reaches the page where he can enter the map-cordinate and upload the image.Else, go back to the page and re-submit the data of installed quantity again.</p>

 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/26.png');?>" class="img-fluid card-img-top" >
</div>

<p>NOTE: After choosing image of installed item, make sure you "click UPLOAD" button , to upload the image.  Else, you will never upload the image to server. When you choose an image, you are watching the image preview only. </p> 
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/27.png');?>" class="img-fluid card-img-top" >
</div>


</div>
</section>
</div>

<div class="col-md-6" data-intro="Repeat Process" data-step="13" data-hint="Continue the same till no more quantities left">
    <span class="badge" style="background: red;">13</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Repeat Process</h2>
</header>
<div class="panel-body">
  <p>When the current installation is done, wait from the survey for more installation to be assigned. </p>
<p>Repeate the process of assiging installation and completing the assigned. Until all the remaining quantity to be installed in the survey is zero.</p>
<div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/29.png');?>" class="img-fluid card-img-top" >
</div>


</div>
</section>
</div>

</div>

<div class="row">

<div class="col-md-12" data-intro="Final" data-step="14" data-hint="Finally , Its Done !!!!!!!">
    <span class="badge" style="background: red;">14</span>
<section class="panel panel-featured">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Complete Survey</h2>
</header>
<div class="panel-body">
  <p>Once the survey is completed, the FOREMAN, can change the status of the installation to "COMPLETED". </p>
<p>On completion, a "complete survey report" can be viewed. Also, there is an option to generate "View Installation Report" as PDF.</p>
 <div class="square">
<img src="<?php echo base_url('admin_assets/survey_flow/28.png');?>" class="img-fluid card-img-top" >
<img src="<?php echo base_url('admin_assets/survey_flow/30.png');?>" class="img-fluid card-img-top" >
</div>
</div>
</section>
</div>



</div>
<!-----end of row div--->

</div>
</section>
 
</div>
  <!------end of introduction ------------------------>

<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg"> Survey Details
<div class="row">
  <!--------this 3rd div-->
<div class="col-md-4 col-xl-4">
<section class="panel">
<a href="<?php echo base_url('list-survey-data');?>">
<div class="panel-body bg-primary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-users"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Survey </h4>
<div class="info">
<strong>
  <?php if(!empty($total_survey)){echo $total_survey;}?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</a>
</section>
</div>
<!--------this 3rd div-->
<!-----end of 3rd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<a href="<?php echo base_url('list-survey-data');?>">
<div class="panel-body bg-tertiary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Scheduled  </h4>
<div class="info">
<strong>
    <?php if(!empty($total_on_scheduled_projects)){echo $total_on_scheduled_projects;}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</a>
</section>
</div>
<!--------this 3rd div-->
<!-----end of 3rd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<a href="<?php echo base_url('list-survey-data');?>">
<div class="panel-body bg-quartenary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total On-going </h4>
<div class="info">
<strong>
    <?php if(!empty($total_on_going_projects)){echo $total_on_going_projects;}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</a>
</section>
</div>
<!-----end of 3rd div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<a href="<?php echo base_url('list-survey-data');?>">
<div class="panel-body bg-warning">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Completed </h4>
<div class="info">
<strong>
   <?php if(!empty($total_completed_survey)){echo $total_completed_survey;}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</a>
</section>
</div>
<!-----end of 4th div--->

<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<a href="<?php echo base_url('list-survey-data');?>">
<div class="panel-body bg-secondary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Cancelled </h4>
<div class="info">
<strong>
    <?php if(!empty($total_cancelled)){echo $total_cancelled;}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</a>
</section>
</div>
<!-----end of 4th div--->

<!--------this 3rd div-->
<!-----end of 3rd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<a href="<?php echo base_url('prd-order-list');?>">
<div class="panel-body bg-primary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total waiting for Production Order to complete</h4>
<div class="info">
<strong>
    <?php if(!empty($total_waiting_for_production)){echo $total_waiting_for_production;}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</a>
</section>
</div>
<!-----end of 3rd div--->
<!------this is 4th div----->

<!-----end of 4th div--->
</div>
</div>

</div>
<!--closing row for po request-->

<!----------------div for po request-------->
<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg">Production Sets / Singles
<div class="row">
   <!--------this 3rd div-->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-primary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-users"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Product Sets </h4>
<div class="info">
<strong>
  <?php if(!empty($total_product_sets)){echo $total_product_sets[0]->total_bal;}?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!--------this 3rd div-->
<!-----end of 3rd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-tertiary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Product Singles </h4>
<div class="info">
<strong>
    <?php if(!empty($total_product_singles)){echo $total_product_singles;}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!--------this 3rd div-->
<!-----end of 3rd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-quartenary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Product Sets Installed </h4>
<div class="info">
<strong>
    <?php if(!empty($total_installed_product_sets)){echo $total_installed_product_sets;}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 3rd div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-warning">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Product Singles Installed</h4>
<div class="info">
<strong>
   <?php if(!empty($total_installed_prd_singles)){echo $total_installed_prd_singles;}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 4th div--->
<!------this is 4th div----->

<!-----end of 4th div--->
<!------this is 4th div----->

<!-----end of 4th div--->
</div>
</div>

</div>
<!--closing row for po request-->


<!----------------div for item request-------->

<!--closing row for item request-->
</section>



</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-appear/jquery.appear.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>


</body>

</html>