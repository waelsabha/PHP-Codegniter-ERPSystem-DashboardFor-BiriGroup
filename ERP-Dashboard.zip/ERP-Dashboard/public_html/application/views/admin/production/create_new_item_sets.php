<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Survey Form </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Survey Form</span></li>
<li><span>Create Extra Item</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">

<div class="panel-body">
 <?php echo form_open_multipart('submit_create_prd_sets_details','class="myform" ','');?>
  
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

<input type="hidden" name="req_type" value="<?php echo $req_type;?>">
<input type="hidden" name="survey_id" value="<?php echo $result[0]->st_id;?>">
<div class="row">
  

<!-----div starts here for details---->
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Create Extra Item Set/Singles </h2>
</header>
<div class="panel-body">

	<!-----=====================table col-12 starts here===================---->
	<div class="row">
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive">  
<table class="table table-bordered mb-none">
  <thead>
    <tr>
        <th>#</th>  
      <th>Product Image</th> 
      <th>Product Name</th>     
     
 <th>Additional Info.</th> 
       <th></th>
    </tr>
  </thead>
  <tbody class="new_rows">
  <?php
  if(!empty($product_ids))
  {
  $i=1;
foreach($product_ids as $index=>$q)
{
   if(empty($q[0]->p_prd_img))
        {
          $filename="https://birigroup.com/uploads/prd_images/".$q[0]->pcode.'.jpeg';
         if (file_exists($filename)) {
          $img_path=$filename;
          } else {
          $img_path="https://birigroup.com/uploads/prd_images/".$q[0]->pcode.'.jpg';
            }
        }
         else
         {
          $first_img_prd=explode(',',$q[0]->p_prd_img);
          if(!empty($first_img_prd[0]))
          $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
          else
          $img_path="https://birigroup.com/uploads/prd_images/".$q[0]->p_prd_img;
         }

  $pname=explode('|~~|',$q[0]->pname); 
    $qnty=explode('|#|',$result[0]->st_po_prd_qtys);
$rmks=explode('|#|',$result[0]->st_po_prd_additional_info);
$price=explode('|#|',$result[0]->st_po_prd_price);
    ?>
<tr class='table<?php echo $i;?>'>
  <td><input type='checkbox' name='chk[]' onclick="get_checkbox_value(<?php echo $i;?>)" class='checkbox_value<?php echo $i;?>' value='<?php echo $q[0]->pid;?>'></td>
 <td><img src='<?php echo $img_path;?>' class='p_img<?php echo $i;?>' width='100' height='100'></td>

 <td><input type='hidden' name='prd_id[]' value='<?php echo $q[0]->pid;?>'>
  <input type='hidden' name='prdids'><span class='prd_en<?php echo $i;?>'><?php echo $q[0]->pname;?></span>
    <br/>CODE: <span class='prd_code<?php echo $i;?>'><?php echo $q[0]->pcode;?></span></td>

<td width='5%'><input type='hidden' name='prd_additional_info' size='5'>
      <textarea name='additional_info[]' class='prd_additional_info<?php echo $i;?>'><?php if(!empty($rmks[$index])){echo $rmks[$index];}?></textarea></td>

<td></td>
</tr>
<?php
$i++;

}
  }
  ?>
  </tbody>
</table>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder"></label>
<div class="col-md-8">
  <?php
  if($req_type=="item_set")
    {?>
  <button onclick="add_prd_grps();" type="button">Click to create Product Groups/Sets</button>
  <?php
  }
  else
    {?>
  <button onclick="add_prd_single();" type="button">Click to create Single Products </button>
  <?php
  }?>
</div>
</div>

<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
<div class="col-md-8">
  <span class="num_items">
    <?php
  if(!empty($result[0]->st_po_prd_ids))
  {
    $p_ids=explode('|#|',$result[0]->st_po_prd_ids);
    echo count($p_ids);
  }?>
  </span>
</div>
</div>
<!----------end col-md-12----------------------------->
<!-------start col-md-12------------------->
<div class='col-md-12 col-sm-12 table-rows-border'>
      <?php
  if(!empty($result[0]))
  {    
    if(!empty($prd_set_details))
    {
       echo "<div class='col-md-6 col-sm-6'>";
      $ik=1;
      foreach($prd_set_details as $index_111=>$pp)
      {
        $prod_id_sets=$prd_ids[$index_111];
      
      echo "<h4>Product Groups Created</h4>";
      echo "<h5 style='color: green;'>Product Set #".$ik."</h5>";

        foreach($prd_ids[$index_111] as $prd)
        {
        
           echo "<b style='color: blue;'>".$prd[0]->pcode.",</b>";
          
        }  
      echo "<p>Total product sets created:".$ik."</p>";
      $ik++;
      }
      echo "</div>";
    }

    if(!empty($prd_ids2))
    {
   echo" <div class='col-md-6 col-sm-6 table-rows-border'>";
    echo "<h4>Product Single Sets Created</h4>";
    foreach($prd_ids2 as $p2)
        {
         // pre_list($prod_id_sets[$position][0]);
            echo "<b style='color: blue;'>".$p2[0]->pcode.",</b>";
        }  
    echo"</div>";
    }

    ?>
  </div>
    <?php
  }
    ?>
<div class="col-md-12 col-sm-12 table-rows-border">
  <h4>Product Groups Created</h4>
      <h5 class="prd_grps_created" style="color: green;"></h5>
      <b style="color: blue;"><p class="codes_prd_sets"></p></b>
  <p>Total product sets created:<span class="tot_prd_grps">0</span></p>
  </div>
   
		
<!----------end col-md-12----------------------------->	
</div>
<!-----=====================table col-12 ends here===================---->
</div>

</section>

<input type="hidden" name="store_value_prd_grps">
    <input type="hidden" name="actual_prd_sets" value="">
    <input type="hidden" name="store_code_prd_grps">

    <input type="hidden" name="actual_single_prds">

<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script type="text/javascript">
    function valueChanged()
    {
        if($('.instaltion_dept').is(":checked"))   
            $(".date_instalation").show();
        else
            $(".date_instalation").hide();
    }
</script>

<script type="text/javascript">
  function select_customer_price()
  {
    var customer_id=$('select[name="choose_customer"]').val();
    $.post('<?php echo base_url('check_customer_pricing');?>',{"cust_id":customer_id}, function(data){
      if(data!=0)
      {
        $('.org_prd_list').hide();
        $('.new_prd_list').html(data);
      }
    });
  }
</script>

<script type="text/javascript">
  $(document).ready(function()
  {
     var edit_customer_selected=$('select[name="choose_customer"]').val();
     if(edit_customer_selected != '')
     {
      select_customer_price();
     }

    $('input[name="add_cash_customer"]').on("click",function(){
    if($(this).is(':checked'))
    {
      $('input[name="add_cash_customer"]').val('1');
  //console.log('checked box');
    $('.cash_cusotmer_details').show();
    }
    else
    {
      //console.log('unchecked box');
      $('.cash_cusotmer_details').hide();
    }
    });
    ///$('.search_product_select').hide()
    var production_id=$("input[name='ordr_id']").val();   
    $('.exact_delivery_date').hide();
   
    $('input:radio').change(function() {
      var ir_delivery_type = $("input[name='ir_delivery_type']:checked").val();
      if(ir_delivery_type=="Sold")
      {
        $('.exact_delivery_date').show();
      }
      if(ir_delivery_type=="Stock")
      {
        $('.exact_delivery_date').hide();
      }   
      });
 
$('.search_product_select').on("change",function(e)
{
  var prd_name=$('.search_product_select :selected').text();
var search_prd_id=$('.search_product_select :selected').val();
var tablecount = $('table tbody tr').length;
  if(tablecount=="0")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }
  jQuery.ajax({
                url:"<?php echo base_url().'Product_order/search_product_id_survey';?>",
                type:"post",
                data:{"search_prd_id":search_prd_id},
                success:function(result)
                    {
                      //console.log(result);
                    var returndata = JSON.parse(result);
                   $('.prd_en'+table_id).text(returndata.prd_name_en);
                   $('.prd_ar'+table_id).text(returndata.prd_name_ar);
                    $('.prd_code'+table_id).text(returndata.prd_code);
                    $('.checkbox_value'+table_id).val(returndata.prd_ids);
                     $('.p_img'+table_id).attr("src",returndata.prd_img);
                    }
            });

  $('.prd_name_selected').text(prd_name);
    //$('.prd_name').html(prd_name);
    var table_data=$('.new_rows').length;
    var i=table_data;
    var new_quantity='0';
    
        var markup = "<tr class='table"+table_id+"'>"+
        "<td><input type='checkbox' name='chk[]' onclick=get_checkbox_value("+table_id+") class='checkbox_value"+table_id+"' value=''></td>"+
         "<td><img src='' class='p_img"+table_id+"' width='100' height='100'></td>"+
        "<td ><input type='hidden' name='prd_id[]' value='"+search_prd_id+"'><input type='hidden' name='prdids'><span class='prd_en"+table_id+"'></span><br/><span class='prd_ar"+table_id+"'></span>"+
       "<br/>CODE: <span class='prd_code"+table_id+"'></span>"+
        "</td>"+
    
         "<td width='5%'><input type='hidden' name='prd_additional_info' size='5'>"+
      "<textarea name='additional_info[]' class='prd_additional_info"+table_id+"'></textarea></td>"+
         "<td><button type='button' onclick=table("+table_id+")>X</button></td>"+
        "</tr>";
            $("table tbody").append(markup);
     var rowcount = $('table tbody tr').length;
     $(".num_items").html(rowcount);
    });
});

function customer_prd_search()
{
  var prd_name=$('.search_product_select_2 :selected').text();
var search_prd_id=$('.search_product_select_2 :selected').val();
var splited_string=search_prd_id.split(':');
var price_prd_cust=splited_string[1];
var tablecount = $('table tbody tr').length;
  if(tablecount=="0")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }
  jQuery.ajax({
                url:"<?php echo base_url().'Product_order/search_product_id_survey';?>",
                type:"post",
                data:{"search_prd_id":search_prd_id},
                success:function(result)
                    {
                      //console.log(result);
                    var returndata = JSON.parse(result);
                   $('.prd_en'+table_id).text(returndata.prd_name_en);
                   $('.prd_ar'+table_id).text(returndata.prd_name_ar);
                    $('.prd_code'+table_id).text(returndata.prd_code);
                    $('.checkbox_value'+table_id).val(returndata.prd_ids);
                     $('.p_img'+table_id).attr("src",returndata.prd_img);
                    }
            });

  $('.prd_name_selected').text(prd_name);
    //$('.prd_name').html(prd_name);
    var table_data=$('.new_rows').length;
    var i=table_data;
    var new_quantity='0';
    
        var markup = "<tr class='table"+table_id+"'>"+
        "<td><input type='checkbox' name='chk[]' onclick=get_checkbox_value("+table_id+",'cust_price') class='checkbox_value"+table_id+"' value=''></td>"+
         "<td><img src='' class='p_img"+table_id+"' width='100' height='100'></td>"+
        "<td ><input type='hidden' name='prd_id[]' value='"+search_prd_id+"'><input type='hidden' name='prdids'><span class='prd_en"+table_id+"'></span><br/><span class='prd_ar"+table_id+"'></span>"+
       "<br/>CODE: <span class='prd_code"+table_id+"'></span>"+
        "</td>"+
    
         "<td width='5%'><input type='hidden' name='prd_additional_info' size='5'>"+
      "<textarea name='additional_info[]' class='prd_additional_info"+table_id+"'></textarea></td>"+
         "<td><button type='button' onclick=table("+table_id+")>X</button></td>"+
        "</tr>";
            $("table tbody").append(markup);
     var rowcount = $('table tbody tr').length;
     $(".num_items").html(rowcount);
}

function calc_qnty_price(table_id)
{
 var cust_qnty= $('.cust_qnty'+table_id).val();
  var price_cust=$('.set_price_qnty'+table_id).html();
 var calc_price=(parseFloat(price_cust)*parseFloat(cust_qnty));
  $('.new_price_qnty'+table_id).html(calc_price.toFixed(2));
}

  function add_extra_cordinate()
  {
    $('.any_additional_cordinate').append('<br/><input type="text" name="extra_cordinate[]" value=""  class="form-control">'); 
      return true;    
  }

  function get_checkbox_value(table_id,$select_type=null)
  {
  $('input[name="chk[]"]').change(function() {
          var cbChecked = new Array();
          var cbUnchecked = new Array();
        $("input[name='chk[]']:checked").each(function() {
          cbChecked[cbChecked.length] = this.value;                     
        });
        $('input[name="store_value_prd_grps"]').val(cbChecked.join());
   });
  var previous_code=$('input[name="store_code_prd_grps"]').val(); 
  var code_prd=$('.prd_code'+table_id).text();
  if(previous_code=='')
  {
     $('input[name="store_code_prd_grps"]').val(code_prd+',');
  }
  else
  {
    $('input[name="store_code_prd_grps"]').val($('input[name="store_code_prd_grps"]').val() + code_prd+',');
  }  
//    var checkbox_value=$('.checkbox_value'+table_id).val();
//    if ($('input[name="chk[]"]').is(":checked"))  
//    {
//      console.log(checkbox_value);
//      console.log('chceked');
//    } 
//    else
//    {
// console.log(checkbox_value);
//      console.log('un-chceked');
//    } 
  }
            
  function table(id)
  {
    $('table tbody .table'+id).remove();
    var rowcount = $('table tbody tr').length;
    $(".num_items").html(rowcount);
  }

  function add_prd_grps()
  {
    $('input[name="chk[]"]').prop('checked', false);
    var prd_ids_input=$('input[name="store_value_prd_grps"]').val();
    if(prd_ids_input!='')
    {
       if($('input[name="actual_prd_sets"]').val()=='')
       {
        $('input[name="actual_prd_sets"]').val(prd_ids_input+'|$|');
       }
       else
        $('input[name="actual_prd_sets"]').val($('input[name="actual_prd_sets"]').val()+prd_ids_input+'|$|');

        var prd_grps_count=parseInt($(".tot_prd_grps").text())+1;
        $(".tot_prd_grps").text(prd_grps_count);
        $('.prd_grps_created').text("Product Set "+prd_grps_count+" is created");
        var store_code_prd_grps=$('input[name="store_code_prd_grps"]').val();
        $('.codes_prd_sets').text("Codes for product sets are :"+store_code_prd_grps);
        $('input[name="store_code_prd_grps"]').val('');       
    }
    else
    {
      alert('Choose products first');
    }
  }
  function add_prd_single()
  {
    $('input[name="chk[]"]').prop('checked', false);
    var prd_ids_input=$('input[name="store_value_prd_grps"]').val();
    if(prd_ids_input!='')
    {
       if($('input[name="actual_single_prds"]').val()=='')
       {
        if($('input[name="edit_actual_single_prds"]').val()!='')
        {
           var edit_single_prd_id_vals=$('input[name="edit_actual_single_prds"]').val();
          $('input[name="actual_single_prds"]').val(edit_single_prd_id_vals+','+prd_ids_input);
        }
        else
        {
           $('input[name="actual_single_prds"]').val(prd_ids_input);
        }
       $('.prd_grps_created').text("Single product's are created");
        var store_code_prd_grps=$('input[name="store_code_prd_grps"]').val();
        $('.codes_prd_sets').text("Codes for product sets are :"+store_code_prd_grps);
        $('input[name="store_code_prd_grps"]').val('');
       }
        else
       {
        alert("single products already created");
       }    
    }
    else
    {
      alert('Choose products first');
    }
  }

$('.myform').submit(function() {
 //e.preventDefault();
var rowcount = $('table tbody tr').length;
var product_id=$('table tbody tr td input[name="prd_id[]"]').map(function(){return $(this).val();}).get().join('|#|');
var prd_additional_info=$('table tbody tr td textarea[name="additional_info[]"]').map(function(){return $(this).val();}).get().join('|#|');
//console.log(quantity+' '+package_size+' '+product_id);
$("input[name='prdids']").val(product_id);
$("input[name='prd_additional_info']").val(prd_additional_info);
var ij=0;
$('table tbody tr td').each(function() {  
var cellText = $(this).html(); 
 $('.cell_text_data').append(cellText).hide();
});
var table_row_added=$('.new_rows').html();

 if ($('.new_rows tr').length == 0) 
 {
  alert('Please choose items to add and submit');
  return false;
 }
 else
 {
  return true;
 }    
 // if(cellText=='')
 //  return false;
 //  else
 //   return true;

  //return false;
  // your code here
});
</script>


<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
   <script type="text/javascript">
          $(function () {
              $('.datetimepicker4').datepicker({format: 'dd/mm/yyyy' });
             // $(".datetimepicker4").datepicker();
              //  $('.datetimepicker4').datepicker({ dateFormat: 'dd/mm/yyyy' }).datepicker();
            });
        </script>
</body>

</html>