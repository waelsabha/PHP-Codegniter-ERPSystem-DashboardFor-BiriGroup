<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>


  
    <!-- jsFiddle will insert css and js -->
<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}

</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Complete Installation Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Complete</span></li>
<li><span>Installation Details</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">

<!-----div starts here for details---->

<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Survey # <?php echo $survey_details[0]->st_survey_no;?> - Complete Installation Details</h2>
<a href="<?php echo base_url('print-complete-installation-report/'.$installation_details[0]->insd_installation_id.'/print_this');?>" 
class="btn btn-primary btn-md pull-right">Print this</a>
</header>
<div class="panel-body">  


 
 <div class="row">
  <div class="col-md-12">
  <div class="col-md-12 col-sm-12">
    <div class="col-md-6">
    <h3>Survey Details</h3>
    <p><b>Survey Number:</b><?php echo $survey_details[0]->st_survey_no;?></p>
    <p><b>Installation Date Set:</b><?php echo $result[0]->ins_date_set_installation;?></p>
   
  
    <p><b>Start Cordinate:</b><?php echo $survey_details[0]->st_start_cordinate;?> <br/> End Cordinate: <?php echo $survey_details[0]->st_end_cordinate;?></p>
    <p><b>Road Clearance Height:</b><?php echo $survey_details[0]->st_clearance;?></p>
    <p><b>Underground Pipe Height:</b><?php echo $survey_details[0]->st_underground_pipe;?></p>
    <p><b>Additional Details:</b><?php echo $survey_details[0]->st_additional_desc;?></p>
    </div>
     <div class="col-md-6">
      <h3>Client Details</h3>
       <p><b>Client Representative:</b><?php echo $survey_details[0]->st_new_cust_name;?> </p>
    <p><b>Company Name:</b><?php echo $survey_details[0]->st_new_cust_comp;?></p>
    <p><b>Email:</b><?php echo $survey_details[0]->st_new_cust_email;?></p>
    <p><b>Phone:</b><?php echo $survey_details[0]->st_new_cust_mobile;?></p>
     </div>
  </div>

    <!-- <div class="col-md-3">
      <h4>Date &amp; Time </h4>
      <?php
      if(!empty($installation_details))
      {
        foreach($installation_details as $id)
        {
          echo "Installation Date and Time : ".$id->insd_date.' '.$id->insd_time;
          echo "<br/>";
        }
      }
      ?>
    </div> -->
    <div class="col-md-4">
       <h4>Labour List</h4>
        <ul>
          <?php
          if(!empty($emp_details))
          {
            foreach($emp_details as $ed)
            {
          ?>
          <li><?php if(!empty($ed[0]->ed_name)){echo $ed[0]->ed_name;}?></li>
          <?php
           }
        }?>
        </ul>
     
    </div>

    <div class="col-md-4">
    <h4>Tool List</h4>
        <ul>
          <?php
          if(!empty($tools_details))
          {
            foreach($tools_details as $td)
            {
          ?>
          <li><?php if(!empty($td[0]->tool_name)){echo $td[0]->tool_name;}?></li>
          <?php
            }
        }?>
        </ul>
    </div>

    <div class="col-md-4">
    <h4> Vehicle </h4>
        <ul>
          <?php
          if(!empty($veh_details))
          {
            foreach($veh_details as $vd)
            {
           ?>
          <li>Plate No.- <?php if(!empty($vd[0]->veh_plate_no)){echo $vd[0]->veh_plate_no;}?></li>
          <?php
            }
        }?>
        </ul>
    </div>

  </div>
 </div>


<div class="data_result">


    <table class="table table-bordered table-striped mb-none">
      <thead>
        <tr>
          <th>Image</th>
           
            <th>Quantity Details</th>
            <th>Installation Images &amp; Cordinates </th>
         <!--  <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
    <?php
    if(!empty($prd_set_details))
    {
    
    foreach($prd_ids_1 as $index_p=>$p1)
          {
            $alignment=$prd_set_details[$index_p]->psd_prd_alignment;
            $prod_position=explode(',',$prd_set_details[$index_p]->psd_arrange_position);

            // pre_list($prod_position);
            // pre_list($p1);
            foreach($prod_position as $pd2)
            {
            //pre_list($pd2);
            //pre_list($p1[$pd2][0]->pname);
              if(empty($p1[$pd2][0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$p1[$pd2][0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$p1[$pd2][0]->p_prd_img;
                 }
  
                 $prod_sets_code[$index_p][]=$p1[$pd2][0]->pcode;
                 $prod_sets_image[$index_p][]=$img_path;
                 $prod_sets_alignment[$index_p]=$alignment;
                 $prod_sets_position[$index_p]=$prod_position;
                 $prd_set_id[$index_p]=$prd_set_details[$index_p]->psd_id;

                  $prd_set_images[$index_p]=$prd_set_details[$index_p]->prd_set_image;
                  $prd_set_final_cordinate[$index_p]=$prd_set_details[$index_p]->prd_set_final_cordinate;

                  $prod_sets_qty_orginal[$index_p]=$prd_set_details[$index_p]->psd_prd_qty;
                  $qty_installed[$index_p]=$prd_set_details[$index_p]->psd_qty_installed;
                  $qty_remaining[$index_p]=$prd_set_details[$index_p]->psd_qty_remaining_installation;

               }
          }
          
          $ij=1;
          foreach($prod_sets_alignment as $index=>$align)
          {
          $final_cordinate=explode('##',$prd_set_final_cordinate[$index]);

     if($align=="vertical")
            {
              //pre_list(implode(',',$prod_sets_image[$index]));
              echo "<tr>";
            echo "<td>";
            asort($prod_sets_position[$index]);
            foreach($prod_sets_position[$index]  as $index22=>$ptt)
              {
          
                if(!empty($prod_sets_image[$index][$index22]))
              echo "<img src='".$prod_sets_image[$index][$index22]."' width='100' height='100'><br/>";
              else
              echo "";
              }
              echo "<input type='hidden' name='prd_set_id[]' class='prd_set_ids_".$ij."' value='".$prd_set_id[$index]."'> </td>";
               echo ' <td>
               <b>Original Quantity : '.$prod_sets_qty_orginal[$index].'</b>
              <table  border="1">
              <thead>
              <th>Date</th>
              <th>Quantity set for Installation</th>
              <th>Installed Quantity</th>
              <th>Remaining Quantity after installation</th>
                <th>Final Remaining Quantity </th>
              </thead>
              <tbody>';
              foreach($installation_details as $id)
              {
                $prd_set_qty_set_for_installation=explode(',',$id->insd_prd_set_qty_set_for_installation);
                 $prd_set_installed_qnty=explode(',',$id->insd_prd_set_qty_installed);
                  $set_remaining_after_installation=explode(',',$id->insd_prd_set_remaining_after_installation);
                  $final_remaining_qnty=explode(',',$id->prd_set_final_calc_qnty);
              echo'<tr>
                <td>'.$id->insd_date.' '.$id->insd_time.'</td>
                <td>'.$prd_set_qty_set_for_installation[$index].'</td>
                <td>'.$prd_set_installed_qnty[$index].'</td>
                <td>'.$set_remaining_after_installation[$index].'</td>
                <td>'.$final_remaining_qnty[$index].'</td>
              </tr>';
            }
              echo'</tbody>
              </table>
              </td>';
                echo '<td>
              <table border="1">
              <thead>
               <th>Sign Cordinate </th>
              <th>Final Installation Image</th>
              </thead>
              <tbody>';
             foreach($installation_details as $id)
              {
                $prd_set_installation_cordinates=explode('|##|',$id->prd_set_final_cordinate);
                 $prd_set_installation_image=explode('|##|',$id->prd_set_image);
                 $prd_set_cordinate_final=explode('##',$prd_set_installation_cordinates[$index]) ;
              if(!empty($prd_set_installation_cordinates[$index]) || !empty($prd_set_installation_image[$index]))
              {   
                 echo'<tr>';
                if(!empty($prd_set_installation_cordinates[$index]))
                 {
                  echo'<td>'.str_replace('##', ',', $prd_set_installation_cordinates[$index]).'</td>';
                 }
                 else
                  {
                     echo'<td></td>';
                  }
                if(!empty($prd_set_installation_image[$index]))
                  echo'<td> 
                 <a href="'.base_url("uploads/installation/".$prd_set_installation_image[$index]).'" target="_blank"> <img src='.base_url("uploads/installation/".$prd_set_installation_image[$index]).' width="100" height="100" /></a>
                </td>';
                else
                   echo'<td> <img src='.base_url("no_image.png").' width="100" height="100"></td>';
                 echo'</tr>';
              }  
            }
              echo'</tbody>
              </table>
              </td>';
        echo "</tr>";
            }
            else
            {
              echo "<tr>";
              echo "<td>";
              asort($prod_sets_position[$index]);
              foreach($prod_sets_position[$index]  as $index22=>$ptt)
              {
                    if(!empty($prod_sets_image[$index][$index22]))
              echo "<img src='".$prod_sets_image[$index][$index22]."' width='80' height='100'>";
              else
              echo "";
              }
               echo "<input type='hidden' name='prd_set_id[]' class='prd_set_ids_".$ij."' value='".$prd_set_id[$index]."'> </td>";
             
              echo ' <td>
               <b>Original Quantity : '.$prod_sets_qty_orginal[$index].'</b>
              <table border="1">
              <thead>
               <th>Date</th>
               <th>Quantity set for Installation</th>
              <th>Installed Quantity</th>
              <th>Remaining Quantity after installation</th>
                <th>Final Remaining Quantity </th>
              </thead>
              <tbody>';
              foreach($installation_details as $id)
              {
                $prd_set_qty_set_for_installation=explode(',',$id->insd_prd_set_qty_set_for_installation);
                 $prd_set_installed_qnty=explode(',',$id->insd_prd_set_qty_installed);
                  $set_remaining_after_installation=explode(',',$id->insd_prd_set_remaining_after_installation);
                  $final_remaining_qnty=explode(',',$id->prd_set_final_calc_qnty);
              echo'<tr>
               <td>'.$id->insd_date.' '.$id->insd_time.'</td>
                <td>'.$prd_set_qty_set_for_installation[$index].'</td>
                <td>'.$prd_set_installed_qnty[$index].'</td>
                <td>'.$set_remaining_after_installation[$index].'</td>
                <td>'.$final_remaining_qnty[$index].'</td>
              </tr>';
            }
              echo'</tbody>
              </table>
              </td>';
              echo '<td>
              <table border="1">
              <thead>
              <th>Sign Cordinate </th>
              <th>Final Installation Image</th>
              </thead>
              <tbody>';
              $ghf=101;
               foreach($installation_details as $id)
              {
                 $prd_set_installation_cordinates=explode('|##|',$id->prd_set_final_cordinate);
                 $prd_set_installation_image=explode('|##|',$id->prd_set_image);
                 $prd_set_cordinate_final=explode('##',$prd_set_installation_cordinates[$index]) ;
                 if(!empty($prd_set_installation_cordinates[$index]) || !empty($prd_set_installation_image[$index]))
                 {
                      echo'<tr>';
                       if(!empty($prd_set_installation_cordinates[$index]))
                      {
                        echo'<td>'.str_replace('##', ',', $prd_set_installation_cordinates[$index]).'</td>';
                      }
                      else
                      {
                         echo'<td></td>';
                      }
                          if(!empty($prd_set_installation_image[$index]))
                        echo'<td> 
                          <a href="'.base_url("uploads/installation/".$prd_set_installation_image[$index]).'" target="_blank">  <img src='.base_url("uploads/installation/".$prd_set_installation_image[$index]).' width="100" height="100" ></a>
                       </td>';
                      else
                         echo'<td> <img src='.base_url("no_image.png").' width="100" height="100"></td>';
                       echo' </tr>';
                  }     
                }
                      echo'</tbody>
                      </table>
                      </td>';
                echo "</tr>";               
            }
            $ij++;
          }
        ?>   
    <?php      
    }
    ?>
    </tbody>
    </table>
  
  
    <table class="table table-bordered table-striped mb-none">
      <thead>
        <tr>
          <th>Image</th>
            <th>Quantity Details</th>
            <th>Installation Images &amp;  Final Cordinates </th>
         <!--  <th>Installed Quantity</th> -->
        </tr>
      </thead>
    <tbody>
    <?php
    if(!empty($survey_details[0]->st_single_prds))
    {        
$ik=50;
$edit_qty_installed=explode(',',$survey_details[0]->st_qty_installed);
$edit_qty_remaining=explode(',',$survey_details[0]->st_qty_remaining_installation);
$single_prd_qntys=explode(',',$survey_details[0]->st_single_prd_qtys);
$final_cordinate_1=explode('|#|',$survey_details[0]->single_prd_final_cordinate);
$img_final_1=explode('|#|',$survey_details[0]->single_prd_img);
      foreach($prd_ids_2 as $index2=>$pd2)
      {
       
      if(empty($pd2[0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$pd2[0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->p_prd_img;
                 }
      ?>
    <tr>
      <td><img src="<?php echo $img_path;?>"  width='100' height='100'><input type="hidden" class="single_prd_id_<?php echo $ik;?>" value="<?php echo $pd2[0]->pid;?>" name=""></td>
     
      <td>
      <b>Original Quantity : <?php echo $single_prd_qntys[$index2];?></b>
              <table border="1">
              <thead>
                <th>Date</th>
              <th>Quantity set for Installation</th>
              <th>Installed Quantity</th>
              <th>Remaining Quantity after installation</th>
                <th>Final Remaining Quantity </th>
              </thead>
              <tbody>
                <?php
                foreach($installation_details as $id)
              {
                $prd_set_qty_set_for_installation=explode(',',$id->insd_prd_single_qty_set_for_installation);
                 $prd_set_installed_qnty=explode(',',$id->insd_prd_single_qty_installed);
                  $set_remaining_after_installation=explode(',',$id->insd_prd_single_remaining_after_installation);
                  $final_remaining_qnty=explode(',',$id->prd_single_final_calc_qnty);
                  ?>
              <tr>
                  <td><?php echo $id->insd_date.' '.$id->insd_time;?></td>
                <td><?php echo $prd_set_qty_set_for_installation[$index2];?></td>
                <td><?php echo $prd_set_installed_qnty[$index2];?></td>
                <td><?php echo $set_remaining_after_installation[$index2];?></td>
                <td><?php echo $final_remaining_qnty[$index2];?></td>
              </tr>
              <?php
            }
            ?>
            </tbody>
            </table>
      <td>
           <table border="1">
              <thead>
               <th>Sign Cordinate </th>
              <th>Final Installation Image</th>
              </thead>
              <tbody>
              <?php
              $abc=1000;
              foreach($installation_details as $id)
              {
                $prd_single_installation_cordinates=explode('|##|',$id->single_prd_final_cordinate);
                $prd_single_installation_image=explode('|##|',$id->single_prd_img);
                if(!empty($prd_single_installation_cordinates[$index2]) || !empty($prd_single_installation_image[$index2]))
                {
              ?>
                  <tr>
                    <?php
                    if(!empty($prd_single_installation_cordinates[$index2]))
                    {
                      ?>
                    <td><?php echo str_replace('##', ',', $prd_single_installation_cordinates[$index2]);?></td>
                    <?php
                    }else{?>
                        <td></td>
                       <?php
                    }?>
                    <?php
                    if(!empty($prd_single_installation_image[$index2]))
                      {?>
                    <td>  
                      <a href="<?php echo base_url("uploads/installation/".$prd_single_installation_image[$index2]);?>" target="_blank"> 
                      <img src='<?php echo base_url("uploads/installation/".$prd_single_installation_image[$index2]);?>' id="imageresource_<?php echo $abc;?>" width="100" height="100">
                    </a>
                    </td>
                    <?php
                  }else
                  {
                    ?>
                  <td>  <img src='<?php echo base_url("no_image.png");?>' width="100" height="100"></td>
                    <?php
                  }
                  ?>
                  </tr>
            <?php
              }
              $abc++;
            }
            ?>
            </tbody>
            </table>
     
       </td>
    </tr>
    <?php
    $ik++;
      }
    }
    ?>
    </tbody>
    </table>
  
<!-----------modal for setting installation date----->


<!---------end installation date---->
</div>
</div>
</section>
<!-----section for lighbox closes here--->
</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>
 
</body>

</html>