<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Order Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Order Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Product Order Form</h2>
</header>
<div class="panel-body">
	<?php echo form_open_multipart('submit_prd_order','class="myform" ');?>
<!-- 	<form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
	
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>


<input type="hidden" name="ordr_id" value="<?php if(!empty($result[0]->po_id)){echo $result[0]->po_id;};?>">
<input type="hidden" name="wp_images" value="<?php if(!empty($result[0]->po_files)) {echo $result[0]->po_files;}?>">
<input type="hidden" name="approve_ksa" value="<?php if(!empty($result[0])){echo $result[0]->po_approve_ksa;};?>">
<input type="hidden" name="edit_user_created" value="<?php if(!empty($result[0])){echo $result[0]->po_user_id;};?>">

<!-- <input type='hidden' name='prd_id_update[]' value="<?php if(!empty($result[0]->po_prd_name)){echo $result[0]->po_prd_name;};?>">
 -->
<input type='hidden' name='variation_selected_val'>

<div class="row">

	<div class="col-md-12 col-sm-12 table-rows-border">
	
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Delivery Location<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control" name="dlvry_loc">

		<option value="">Choose</option>
		<?php
		foreach($delivery_location as $dl)
		{
			?>
		<option value="<?php echo $dl->mw_name;?>" <?php if((!empty($result[0]->po_delivery_loc))){if($result[0]->po_delivery_loc==$dl->mw_name){echo "selected";}} ?> ><?php echo $dl->mw_name;?> </option>	
			<?php
		}
		?>
	</select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('dlvry_loc');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Delivery Date<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
	<?php
	if(!empty($result[0]->po_date_delivry))
	$converted_date_delivry = date("m/d/Y", strtotime($result[0]->po_date_delivry));
	?>

 <input type='text' name="date" class="form-control" id='datetimepicker4' value="<?php if(!empty($converted_date_delivry)){echo $converted_date_delivry;} ;?>" required />
  <div class="form_error">  <?php echo $this->session->flashdata('date');?></div>

  <p><span>Is this an exact date of delivery?</span><br/>
<input type="radio" value="yes" <?php if(!empty($result[0]->po_dlvry_days)){echo "checked";} ;?> name="exact_dlvry_date" >Yes
<input type="radio" value="no" name="exact_dlvry_date">No
  </p>
</div>
</div>

</div>

</div>

<div class="col-md-12 col-sm-12 table-rows-border choose_other_dlvry_date">
	<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose the expected number of days from the selected delivery date<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control" name="dlvry_days_expct">
		<option value="">Choose</option>
		<option value="2" <?php if((!empty($result[0]->po_dlvry_days))){if($result[0]->po_dlvry_days=="2"){echo "selected";}} ?>>2 days</option>

		<option value="5" <?php if((!empty($result[0]->po_dlvry_days))){if($result[0]->po_dlvry_days=="5"){echo "selected";}} ?>>5 days</option>

		<option value="7" <?php if((!empty($result[0]->po_dlvry_days))){if($result[0]->po_dlvry_days=="7"){echo "selected";}} ?>>7 days</option>
	</select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('dlvry_loc');?></div>
	</div>
  </div>
</div>


<div class="col-md-12 col-sm-12 table-rows-border">
	

<div class="col-md-6 col-sm-12">


<div class="form-group">

<label class="col-md-4 control-label" for="inputPlaceholder">Department<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<?php
if(!empty($result[0]->po_dept))
$dept=explode(',',$result[0]->po_dept);
?>
<label class="radio-inline">
  <input type="radio" name="dept[]" value="Traffic Sign"<?php if(!empty($dept[0])){
    if($dept[0]=="Traffic Sign"){echo "checked";}}
    elseif(!empty($dept[1]))
      {if($dept[1]=="Traffic Sign"){echo "checked";}}
    else{}
    ?> > Traffic Sign/Advertising
   </label>
   <label class="checkbox-inline">
   <input type="radio" name="dept[]" value="Main factory" <?php if(!empty($dept[0])){
    if($dept[0]=="Main factory"){echo "checked";}}
    elseif(!empty($dept[1]))
      {if($dept[1]=="Main factory"){echo "checked";}}
    else{}
    ?>> Main Factory
</label>
  <div class="form_error">  <?php echo $this->session->flashdata('notes');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<!--<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose category<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control" name="choose_category">

		<option value="">Choose</option>
		<?php
		foreach($class_data as $cd)
		{
			?>
		<option value="<?php echo $cd->cname;?>" <?php if((!empty($result[0]->po_delivery_loc))){if($result[0]->po_delivery_loc==$cd->cname){echo "selected";}} ?> ><?php echo $cd->cname;?> </option>	
			<?php
		}
		?>
	</select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('dlvry_loc');?></div>
</div>
</div>-->

</div>

</div>

<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="col-md-6">
<div class="form-group">

<label class="col-md-4 control-label" for="inputPlaceholder">Upload Files(customer logo/data sheets/any files. )<abbr class="required">Not mandatory</abbr></label>
<div class="col-md-8"><small>Please upload only jpeg,jpg,png,pdf files</small>
<input type="file" name="label_upload[]">
<input type="file" name="label_upload[]">
<input type="file" name="label_upload[]">
<input type="file" name="label_upload[]">
<input type="file" name="label_upload[]">
  <div class="form_error">  <?php echo $this->session->flashdata('notes');?></div>
</div>
</div>
</div>

  <div class="col-md-6">
    <p><b>Attachments </b>
      
        <?php if(!empty($result[0]->po_files))
        {
         echo "<br/>";
          $files_attached=explode(',',$result[0]->po_files);
          foreach($files_attached as $t)
          {
             $file_parts = pathinfo($t);
            if(($file_parts['extension']=="jpeg")||($file_parts['extension']=="jpg")||($file_parts['extension']=="png")||($file_parts['extension']=="PNG"))
            {
           
              echo "<img src='".base_url('/uploads/production/prod_files/').$t."' width='100' height='100' >";echo "<br/>";
            }
           ?>
           <a href="<?php echo base_url('uploads/production/prod_files/'.$t);?>" target="_blank"><?php echo $t;?></a><br/>
           <?php
          }
       }?></p>
  </div>

</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Special Order request from customer(if any)<abbr class="required">Not mandatory</abbr></label>
<div class="col-md-8">
<textarea name="specl_customer_req" class="form-control editors"><?php if(!empty($result[0]->po_specl_customer_req)){echo $result[0]->po_specl_customer_req;};?></textarea>

  <div class="form_error">  <?php echo $this->session->flashdata('specl_customer_req');?></div>
</div>
</div>
</div>

</div>

<div class="cell_text_data"></div>
<!-- submit_main_form -->

</div>
</section>

<section class="panel panel-featured panel-featured-primary">

<div class="panel-body">
<!-- 	<form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
	
<div class="row">

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Search Product<abbr class="required">::*::</abbr></label>
<div class="col-md-8">


<select data-plugin-selectTwo class='form-control populate search_product_select' name='search_product_cat'>
<option></option>
<?php
		foreach($products as $c)
			{
				$prd_name=explode('|~~|',$c->pname);
				?>
		<option value="<?php echo $c->pid;?>" ><?php echo $prd_name[0].' '.$prd_name[1].' ::  <br/><br/> '.$c->pcode;?></option>
		<?php
	}?>
	</select>


<div class="form_error">  <?php echo $this->session->flashdata('sales_person');?></div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive">	
<table class="table table-bordered mb-none">
	<thead>
		<tr>
			<!--  <th>#</th>  -->
			<th></th>
			<th width="30%">Product Name</th>
			<th width="5%">Quantity</th>
			<th width="5%">Weight (KG)</th>
			
			<th width="5%">Packaging Type</th>
			<th width="10%">Special Request</th>
			<th width="5%">Remarks</th>
			<th width="2%"></th>
		</tr>
	</thead>
	<tbody class="new_rows">
	<?php
	if(!empty($result[0]->po_prd_name))
	{
	$i=1;

foreach($prd_data as $index=>$p)
{
	
	foreach($p as $indx2=>$q)
	{
		
	$pname=explode('|~~|',$q->pname);
	
		$qnty=explode('|#|',$result[0]->po_qnty);
$wgt=explode('|#|',$result[0]->po_wgt);
$pckg_type=explode('|#|',$result[0]->po_pck_type);
$variation=explode('|#|',$result[0]->po_variations);
$req=explode('|#|',$result[0]->po_spcl_rq);
$rmks=explode('|#|',$result[0]->po_rmks);
		?>
<tr>
	<td><?php echo $i;?></td>
<td>
<input type="hidden" name="prd_id[]" value="<?php echo $q->pid;?>">
<input type="hidden" name="prdids">
<?php echo $pname[0].'<br/>'.$pname[1];?>
<?php echo $q->pcode;?>
</td>

<td>
	<input type='hidden' name='qntys' size='5'>
	<input type='number' name='qnty[]' size='5' value="<?php echo $qnty[$index];?>"></td>
<td>
	<input type='hidden' name='wgts' size='5'>
<input type='number' name='wgt[]' size='5' value="<?php echo $wgt[$index];?>"></td>

<td>
	<input type='hidden' name='pck_types' size='10'>
<input type='text' name='pck_size[]' value="<?php echo $pckg_type[$index];?>"></td>
<td>
	<input type='hidden' name='spcl_rqts'>
	<input type='text' name='spcl_req[]' value="<?php echo $req[$index];?>"></td>
<td>
	<input type='hidden' name='remark'>
	<input type='text' name='remarks[]' value="<?php echo $rmks[$index];?>"></td>
<td>
	<button type="button" onclick="remove_item_po(<?php echo $result[0]->po_id;?>,<?php echo $index;?>)" class="btn btn-default">X</button>
	</td>
	
</tr>
<?php
$i++;
}
}
	}
	?>

	</tbody>
</table>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">

<label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
<div class="col-md-8">
	<span class="num_items">
		<?php
	if(!empty($result[0]->po_prd_name))
	{
		$p_ids=explode('|#|',$result[0]->po_prd_name);
		echo count($p_ids);
	}?>
	</span>
</div>



</div>



</div>




<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
<!-- submit_main_form -->

<?php echo form_close();?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>


<script type="text/javascript">
	$(document).ready(function()
	{
		///$('.search_product_select').hide()

		var production_id=$("input[name='ordr_id']").val();
		if(production_id=='')
		{
			$('.approve_btn').hide();
		}
		else{
			$('.approve_btn').show();
		$('select[name="variation_select[]"]').on("change",function(){

			var class_name=$(this).attr('class');

			var ret = class_name.split(" ");
			var variation_name=ret[1];
			var table_row_id=ret[2];
			var var_class_name=variation_name.replace('print_var','');
			
			});
		
		}
		$('.choose_other_dlvry_date').hide();

		var days_delivery=$("input[name='exact_dlvry_date']:checked").val();
		if(days_delivery=="no")
		{
			$('.choose_other_dlvry_date').show();
		}

		$('input:radio').change(function() {
			var delivery_days = $("input[name='exact_dlvry_date']:checked").val();
			if(delivery_days=="no")
			{
				$('.choose_other_dlvry_date').show();
			}
			if(delivery_days=="yes")
			{
				$('.choose_other_dlvry_date').hide();
			}		
  		});

  		$("select[name='choose_category']").change(function() {
  				$('select[name="search_product_cat"]').html('');
				var category_selected=$("select[name='choose_category']").val();
  			jQuery.ajax({
                     url:"<?php echo base_url().'Product_order/choose_category';?>",
                    type:"post",
                     data:{"category_selected":category_selected},
                    success:function(result)
                    {
                    var returndata = JSON.parse(result);
                     $('select[name="search_product_cat"]').append("<option>Choose Value</option>");
                    $.each(returndata, function(key2,val2)
						{
							var product_full=val2['pname'].split('|~~|');
							$('select[name="search_product_cat"]').append("<option value="+val2['pid']+">"+product_full[0]+" "+product_full[1]+" ::  <br/><br/> "+val2['pcode']+"</option>");
						});
                    }
                });
  		});

		$("input[name='search_product']").on("keyup", function(e) {
       		 var key_code = e.which || e.keyCode;
   			if(key_code=="32")	
   			{
   				var to_search=$("input[name='search_product']").val();
   				var category_selected=$("select[name='choose_category']").val();
   				console.log(category_selected);
   				 jQuery.ajax({
                     url:"<?php echo base_url().'Product_order/search_product';?>",
                    type:"post",
                     data:{"to_search":to_search,"category_selected":category_selected},
                    success:function(result)
                    {
                    	
                    	//$('.search_product_input').hide();
                    	$('.search_product_select').show();

                    	$('.search_product_select').html(
                    		'<option value="">Choose Values</option>'+
                    		result);
                    }
                });
   			}
		});

$('.search_product_select').on("change",function(e)
{
"min  hour;"	
"0	15;"
	$(".div_var").html('');
	$(".update_variation").html('');
	var prd_name=$('.search_product_select :selected').text();
var search_prd_id=$('.search_product_select :selected').val();
var category_selected=$("select[name='choose_category']").val();

	var tablecount = $('table tbody tr').length;
	if(tablecount=="0" || tablecount=="")
	{
		var table_id="1";	
	}
	else
	{
		var table_id=parseInt($(".num_items").text())+1;
	}
	jQuery.ajax({
                url:"<?php echo base_url().'Product_order/search_product_id';?>",
                type:"post",
                data:{"search_prd_id":search_prd_id,"category_selected":category_selected},
                success:function(result)
                    {
                    	//console.log(result);
                    var returndata = JSON.parse(result);
                    $('.prd_weight'+table_id).val(returndata.wgt);
                   $('.prd_en'+table_id).text(returndata.prd_name_en);
                   $('.prd_ar'+table_id).text(returndata.prd_name_ar);
                    $('.prd_code'+table_id).text(returndata.prd_code);
                    var select_data; 

                   
                $.each(returndata.values, function(key,val)
				{
	$(".div_var").append('<span><b>'+key+'</b></span><br/><select class="form-control print_var'+key.replace(/ /g,'')+'" name="variation_select[]"><option></option>');
			var comma_replaced=val.replace(/(^,)|(,$)/g, "");
			var array_vals = comma_replaced.split(",");
					
						$.each(array_vals, function(key2,val2)
							{
						$(".print_var"+key.replace(/ /g,'')).append($('<option value="'+key+'::'+val2+'">'+val2+'</option>') );
							});
						
						$(".div_var").append('<br/>');
					});

					$('.approve_btn').show();
                    
                    }
            });

	$('.prd_name_selected').text(prd_name);
		//$('.prd_name').html(prd_name);
		var table_data=$('.new_rows').length;
		var i=table_data;
		var new_quantity='0';
		//var rowcount = $('table tbody tr').length;	
		// var tablecount = $('table tbody tr').length;
		// if(tablecount=="0")
		// {
		// 	var table_id="1";	
		// }
		// else
		// {
		// 	var table_id=parseInt($(".num_items").text())+1;
		// }
		
		    var markup = "<tr class='table"+table_id+"'>"+
		    "<td width='1%'><button type='button' onclick=table("+table_id+")>X</button></td>"+
		    "<td style='width:25% important;'><input type='hidden' name='prd_id[]' value='"+search_prd_id+"' class='prd_id_selected_"+table_id+"'><input type='hidden' name='prdids'><span class='prd_en"+table_id+"'></span><br/><span class='prd_ar"+table_id+"'></span><br/><span class='prd_code"+table_id+"'></span></td><td width='5%'><input type='hidden' name='qntys' size='5'>"+
		    "<input type='number' class='qnty_val' name='qnty[]' size='5' style='width:50px;'></td>"+
		     "<td width='5%'><input type='hidden' name='wgts' size='5'> <input type='number' step='0.1' min='0' name='wgt[]' size='5' style='width:50px;' class='prd_weight"+table_id+"'></td>"+
		   
		     "<td width='5%'><input type='hidden' name='pck_types' size='10'><input type='text' value='Standard Packaging' name='pck_size[]' size='10' style='width:100px;'></td>"+
		      "<td width='5%'><input type='hidden' name='spcl_rqts'><input type='text' name='spcl_req[]' style='width:100px;'></td><td width='5%'><input type='hidden' name='remark'><input type='text' name='remarks[]' style='width:100px;'></td>"+
		      "<td><button type='button' onclick='copy_text("+table_id+")'>Copy</td>"+
		    "</tr>";
            $("table tbody").append(markup);
		 var rowcount = $('table tbody tr').length;
		// $(".num_items").html(rowcount);
		if(tablecount=="0" || tablecount=="")
		{
			$(".num_items").text('1');
		}
		else
		{
			$(".num_items").html((parseInt($(".num_items").text())+1));
		}
		
//init the array products
// arrprd=[];
//  arrprd.push(search_prd_id);
//  $("input[name='prd_id[]']").val(arrp);
	
		// $('.search_product_select').prop('selected', false);
		});
		// $('input[name="qnty[]"]').on("change paste keyup",function(e)
		// {
		// 	alert("on change");
		// 	console.log('in qnty val');
		//  var inital_quantity=$("input[name='qnty[]']").val();
		//  console.log(inital_quantity);
		//  var new_quantity=parseInt(new_quantity)+parseInt(inital_quantity);
		//  $(".num_qnty").html(new_quantity);
		// console.log(new_quantity);
		// });

  	});

function copy_text(t_id)
{
	var table_id=parseInt($(".num_items").text())+1;
	var table_prd_id_selected=$('.prd_id_selected_'+t_id).val();
	var prd_name_en=$('.prd_en'+t_id).html();
	var prd_name_ar=$('.prd_ar'+t_id).html();
	  var prd_name_code=$('.prd_code'+t_id).html();
	  
	var markup = "<tr class='table"+table_id+"'>"+
		    "<td width='1%'><button type='button' onclick=table("+table_id+")>X</button></td>"+
		    "<td style='width:25% important;'><input type='hidden' name='prd_id[]' value='"+table_prd_id_selected+"'><input type='hidden' name='prdids'><span class='prd_en"+table_id+"'>"+prd_name_en+"</span><br/><span class='prd_ar"+table_id+"'>"+prd_name_ar+"</span><br/><span class='prd_code"+table_id+"'>"+prd_name_code+"</span></td><td width='5%'><input type='hidden' name='qntys' size='5'>"+
		    "<input type='number' class='qnty_val' name='qnty[]' size='5' style='width:50px;'></td>"+
		     "<td width='5%'><input type='hidden' name='wgts' size='5'> <input type='number' step='0.1' min='0' name='wgt[]' size='5' style='width:50px;' class='prd_weight"+table_id+"'></td>"+
		   
		     "<td width='5%'><input type='hidden' name='pck_types' size='10'><input type='text' value='Standard Packaging' name='pck_size[]' size='10' style='width:100px;'></td>"+
		      "<td width='5%'><input type='hidden' name='spcl_rqts'><input type='text' name='spcl_req[]' style='width:100px;'></td><td width='5%'><input type='hidden' name='remark'><input type='text' name='remarks[]' style='width:100px;'></td>"+
		      "<td><button type='button' onclick='copy_text("+t_id+")'>Copy</td>"
		    "</tr>";
            $("table tbody").append(markup);
		 var rowcount = $('table tbody tr').length;
		 $(".num_items").html(rowcount);
}
	function approve_var(){
		alert('approve clicked');
		var data=[];
		var table_count=$(".num_items").text();
	$('select[name="variation_select[]"]').find("option:selected").each(function(){
		//console.log($('select[name="variation_select[]"]').val());
		// var label = $(this).parent().attr("label");  
        data.push($(this).val()+'\n');
      		// values based on each group ??
       /// id = $(this).parent().attr("id");
 		});
	 $('.var_selected'+table_count).text(data.join(""));
   $('.var_selected'+table_count).append($('input[name="variation_selected_val"]').val(data.join("|#|")));
	}

	function table(id)
	{
		$('table tbody .table'+id).remove();
		var rowcount = $('table tbody tr').length;
		//$(".num_items").html(rowcount);
		$(".num_items").html(parseInt($(".num_items").text())+1);
	}
  	 	

$('.myform').submit(function() {
	//e.preventDefault();
var rowcount = $('table tbody tr').length;
var quantity=$('table tbody tr td input[name="qnty[]"]').map(function(){return $(this).val();}).get().join('|#|');  

var weight=$('table tbody tr td input[name="wgt[]"]').map(function(){return $(this).val();}).get().join('|#|');

var spcl_req=$('table tbody tr td input[name="spcl_req[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var package_size=$('table tbody tr td input[name="pck_size[]"]').map(function(){return $(this).val();}).get().join('|#|');

var product_id=$('table tbody tr td input[name="prd_id[]"]').map(function(){return $(this).val();}).get().join('|#|');

var remarks=$('table tbody tr td input[name="remarks[]"]').map(function(){return $(this).val();}).get().join('|#|');

//console.log(quantity+' '+package_size+' '+product_id);

$("input[name='prdids']").val(product_id);
$("input[name='qntys']").val(quantity);
$("input[name='wgts']").val(weight);
$("input[name='pck_types']").val(package_size);
if(spcl_req=="")
	$("input[name='spcl_rqts']").val(spcl_req);
else
	$("input[name='spcl_rqts']").val(spcl_req);

if(remarks=="")
	$("input[name='remark']").val();
else
	$("input[name='remark']").val(remarks);



var ij=0;
var data_var=[];

$('table tbody tr td').each(function() {	
var cellText = $(this).html(); 
   // console.log(cellText);  
    $('.cell_text_data').append(cellText).hide();
});

$('table tbody tr').each(function() {
		 ij++;
var val_variations=$('.var_selected'+ij).text();
	data_var.push(val_variations);	
});	 

$('.cell_text_data').append($("input[name='variation_selected_val']").val(data_var.join("|#|")));

//console.log($("input[name='prdids']").val());
 //console.log($("input[name='variation_selected_val']").val());
var table_row_added=$('.new_rows').html();

 if ($('.new_rows tr').length == 0) 
 {
 	alert('Please choose items to add and submit');
	return false;
 }
 else
 {
 	return true;
 }	 
		
	//return false;
  // your code here
});
	
</script>

<script type="text/javascript">
	function remove_item_po(po_id,prd_index_position)
	{
		jQuery.ajax({
                url:"<?php echo base_url().'Product_order/remove_prod_index';?>",
                type:"post",
                data:{"po_id_table":po_id,"prod_index":prd_index_position},
                success:function(result)
                    {
                    	//console.log(result);
                    	if(result)
                    	{
                    		console.log(result);
                 		window.location.reload();
                    	}
                    }
                });    
	}
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
		tinymce.init({
			selector : '.editors',
			  plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
		});
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('#datetimepicker4').datetimepicker();
            });
        </script>

</body>

</html>