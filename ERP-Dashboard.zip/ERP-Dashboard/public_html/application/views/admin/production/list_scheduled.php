<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
.dropdown-divider
{

}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Scheduled Installation Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Scheduled Installation Details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-----section for lightbox opens here-->
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">List Scheduled Installation Details</h2>
</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors"> <b> <?php echo $this->session->flashdata('errors');?></b></p>
            <p class="success"><b><?php echo $this->session->flashdata('success');?></b></p>
    </div>
    <?php
if(!empty($last_scheduled_data))
{
  $remaining_qty_prd_set=explode(',',$last_scheduled_data[0]->insd_prd_set_remaining_qnty);
  $remaining_qty_prd_singles=explode(',',$last_scheduled_data[0]->insd_prd_single_remaining_qnty);

  if(!empty($remaining_qty_prd_set) && !empty($remaining_qty_prd_singles))
  {
    if(array_filter($remaining_qty_prd_set)==false && array_filter($remaining_qty_prd_singles)==false)
    {
      echo "<p style='color:red;'>No more quantity left for installation</p>";
    }
  }
  elseif(!empty($remaining_qty_prd_set) && empty($remaining_qty_prd_singles))
  {
    if(array_filter($remaining_qty_prd_set)==false)
    {
  echo "<p style='color:red;'>No more quantity left for installation</p>";
    }
  }
  elseif(empty($remaining_qty_prd_set) && !empty($remaining_qty_prd_singles))
  {
    if(array_filter($remaining_qty_prd_singles)==false)
    {
  echo "<p style='color:red;'>No more quantity left for installation</p>";
    }
  }  
}
    ?>

<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th></th>
<th>Date</th>
<th>Labour Assigned</th>
<th>Vehicle</th>
<th>Tools</th>
<th>Total Scheduled </th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php
		$i=1;
	foreach($instalation_details as $index=>$q)
	{	
		 $prd_set_scheduled=explode(',',$q->insd_prd_set_qty_set_for_installation);
		 $prd_single_scheduled=explode(',',$q->insd_prd_single_qty_set_for_installation);
		 $total_qnty=array_sum($prd_set_scheduled)+array_sum($prd_single_scheduled);
    
$lnToday = date("Y-m-d");
$date_diff=strtotime($q->insd_date)-strtotime($lnToday);
$final_date_diff=round($date_diff / (60 * 60 * 24));   
if($final_date_diff == 2)
{
   $styles="
  background-color: #ffc107;
  color: white;";
}
elseif($final_date_diff <=1)
{
  $styles="
  background-color: #da0606;
  color: white;
  -webkit-animation: glowing 1500ms infinite;
  -moz-animation: glowing 1500ms infinite;
  -o-animation: glowing 1500ms infinite;
  animation: glowing 1500ms infinite;";
  // $style_color="";//red
}
else{ $styles='';}
?>
<tr>
<td ><?php echo $i++;?></td>
<td>  <button type="button" style="<?php if(!empty($styles)){echo $styles;}?>"><?php echo  date("d/m/Y", strtotime($q->insd_date));?></button></td>
<td><?php 
foreach($emp_details[$index][$index] as $emp_dt)
{
echo $emp_dt[0]->ed_name;
echo ",";
}
?></td>
<td><?php echo $veh_details[$index][$index][0][0]->veh_plate_no;?></td>
<td>
	<?php 
foreach($tools_details[$index][$index] as $tool_dt)
{
echo $tool_dt[0]->tool_name;
echo ",";
}
?>
</td>

<td>
	<?php echo $total_qnty;?>
</td>
<td>
    <?php
if($this->session->userdata['user']['main_dept']=="Factory Staff")
    {
         ?>
   <a href="<?php echo base_url('view_set_installation/'.$q->insd_id);?>" class="delete-row" 
        <?php if($final_date_diff > 2){echo "style='pointer-events: none;cursor: default;'";};?> >View</a>  <br/>

       
                &nbsp;&nbsp;  
   <?php
   }
   else
   {
    if($q->installation_sts!='1')
      {
    ?>     
<a href="<?php echo base_url('edit_manage_installation/'.$q->insd_id);?>" class="delete-row"><i class="fa fa-pencil"></i></a><br/>			
				&nbsp;&nbsp;
        <?php
        if(!end($instalation_details))
          {
            ?>
<a class="mb-xs mt-xs mr-xs modal-sizes modal-basic btn btn-danger btn-sm" href="#modalSm_<?php echo $q->insd_id;?>" class="delete-row"><i class="fa fa-trash-o"></i></a>	&nbsp;&nbsp;
        <?php
        }?>
<?php
    }
}
if($q->installation_sts=='1')
  {
    ?>
<span class="label label-success">Installation Completed</span>
<br/><a class="waves-light waves-effect" title="Download as PDF" href="<?php echo base_url('Installation_controller/generate_daily_report_pdf/'.$q->insd_id);?>">Generate Daily Report PDF<i class="fa fa-file-pdf-o"></i></a>  &nbsp;&nbsp;
  <?php
  }
  else
  {
  ?>
    
 <br/><a class="waves-light waves-effect" title="Download as PDF" href="<?php echo base_url('generate_pdf_current_installation/'.$q->insd_id);?>"><i class="fa fa-file-pdf-o"></i></a>  &nbsp;&nbsp;
 <br/><a class="waves-light waves-effect" title="Download as Excel" href="<?php echo base_url('generate_installation_excel/'.$q->insd_id);?>"><i class="fa fa-file-excel-o"></i></a>
 <?php
}?></td>
</tr>
<!-- Button trigger modal 3-->
 <div id="modalSm_<?php echo $q->insd_id;?>" class="modal-block  modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Are you sure?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-icon">
<i class="fa fa-question-circle"></i>
</div>
<div class="modal-text">
<h4>Date Scheduled Installation </h4>
<p>Are you sure , you want to delete this installation details ? You can't undo this action if done.</p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
  <a href="<?php echo base_url('delete_manage_installation/'.$q->insd_id);?>" class="btn btn-primary">Confirm</a>

<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal--->
<?php
}
?>

</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	 $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
   <script type="text/javascript">
          $(function () {
                 $('.datetimepicker4').datepicker({format: 'dd/mm/yyyy' });
            });
        </script>
</body>
</html>