<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Excel Upload Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Excel Upload Form</span></li>
<li><span>Upload</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Excel Upload Form-test prduct update</h2>
</header>
<div class="panel-body">
	<?php echo form_open_multipart('Excel_production/submit_production_excel_new','class="form-horizontal form-bordered"');?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

    <div class="form-group">
<label class="col-md-3 control-label" for="inputPlaceholder">File name</label>
<div class="col-md-6">

 <input type="text" class="form-control"  name="dwnload_title" > 
 <div class="form_error">  <?php echo $this->session->flashdata('dwnload_title');?></div>
</div>
</div>


<div class="form-group">
	<label class="col-md-3 control-label">File Upload</label>
	<div class="col-md-6">
	<div class="fileupload fileupload-new" data-provides="fileupload">
	<div class="input-append">
	<div class="uneditable-input">
	<i class="fa fa-file fileupload-exists"></i>
	<span class="fileupload-preview"></span>
	</div>
	<span class="btn btn-default btn-file">
	<span class="fileupload-exists">Change</span>
	<span class="fileupload-new">Select file</span>
	<input type="file" name="userfile">
	</span>
	<a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
	</div>
	</div>
	</div>
</div>

 



<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>


<?php echo form_close();?>
</div>
</section>

</div>
</div>


<div class="row">

<div class="col-md-12">
<section class="panel">
<header class="panel-heading">

<!-- <h2 class="panel-title">Download the sample excel file</h2> -->
<h2 class="panel-title">Details for the excel file</h2>
</header>
<div class="panel-body">

	<h4>Please read the below details before filling the excel file :</h4>
		<table class="table table-bordered">
			<tr>
				<td>Product Name-English</td>
				<td>Enter the name in english</td>
			</tr>

			<tr>
				<td>Product Name-Arabic</td>
				<td>Enter the name in arabic</td>
			</tr>
			<tr>
				<td>Product Type</td>
				<td>Enter the product type:<small>Choose from the below data:</small><br/>
				<ul>
					<li>Raw Material</li>
					<li>Finished Good</li>
					<li>Service Product</li>
				</ul>
				</td>
			</tr>
			<tr>
				<td>Item Code</td>
				<td>Enter the item code of the product</td>
			</tr>
			<tr>
				<td>Product Weight</td>
				<td>Enter the weight of product in (kg)</td>
			</tr>
			<tr>
				<td>Selling Price</td>
				<td>Selling price of product from which will be the KSA final and Dubai final rates will be calculated.</td>
			</tr>
			<tr>
				<td>Product Description</td>
				<td>Description about the product</td>
			</tr>


		</table>

	

</div>
</section>
</div>

</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>


</html>