<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Survey Status</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Pages</span></li>
<li><span>Survey Created </span></li>
</ol>
<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
</div>
</header>
<div id="modalFullColorPrimary" class="modal-block  modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Are you sure?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-icon">
<i class="fa fa-question-circle"></i>
</div>
<div class="modal-text">
<h4>Confirm Product Quantity</h4>
<p>Check the product quantity generated as per the Manage Product data. </p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
	<a href="<?php echo base_url('generate_po_survey/');?>" class="btn btn-primary">Confirm</a>

<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<section class="panel">
<div class="panel-body">
<div class="invoice">
<header class="clearfix">
<div class="row">
<div class="col-sm-6 mt-md">
<h2 class="h2 mt-none mb-sm text-dark text-bold">Survey Number</h2>
<h4 class="h4 m-none text-dark text-bold">#<?php echo $result[0]->st_survey_no;?></h4>
</div>

</div>
</header>
<div class="col-md-12 col-sm-12">
	<h2 class="error-code text-dark text-center text-semibold m-none">Success <i class="fa fa-thumbs-up"></i></h2>
	</div>
<div class="bill-info">
<div class="row">
<div class="col-md-6">
<div class="bill-to">
<p class="h5 mb-xs text-dark text-semibold">Survey Status: <h4>Created</h4></p>
<p>Departments working in this survey <br/>
	<ul>
		<?php 
		if(!empty($result[0]->st_dept_po))
			{?>
		<li>Production Department</li>
		<?php
			}
		if(!empty($result[0]->st_dept_installation))
		{
			?>
		<li>Installation Department(*The order will be send for installation, only when the Po is delivery ready*)</li>
		<?php
			}?>
	
</ul>
</p>
</div>
</div>
<div class="col-md-6">
<div class="bill-data text-right">
<p class="mb-none">
<span class="text-dark">Date:</span>
<span class="value"><?php echo date('Y-m-d');?></span>
</p>
<p>
	<span class="text-dark">Created by:</span>
	<span class="value"><?php echo $result[0]->st_user_created;?></span>
</p>

<?php 
$pipe_height=$result[0]->st_clearance+$result[0]->st_underground_pipe;?>

</div>
</div>

<div class="col-md-12 col-sm-12">

</div>
</div>
</div>
<h4>Items choosed for creating production order</h4>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
		<th ></th>
	<th>Product Sets</th>
	<th >Item Details</th>
	<th > Quantity</th>
	<th >Pipe Height</th>
	
</tr>
</thead>
<tbody>
	<?php
	$i=1;$ij=1;
foreach($prd_set_data as $index=>$p)
{
	$items_qty=explode(',',$p->psd_prd_qty);
	$items_extra_desc=explode(',',$p->psd_extra_info_prd);
	$alignment=$p->psd_prd_alignment;
	$prod_position=explode(',',$p->psd_arrange_position);
	$prod_sets_image=array();
	foreach($prod_position as $pos_Index=>$pd2)
            {
           // pre_list($prd_ids[$index][$pos_Index]);
            //pre_list($p1[$pd2][0]->pname);
              if(empty($prd_ids[$index][$pos_Index][0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$prd_ids[$index][$pos_Index][0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$prd_ids[$index][$pos_Index][0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$prd_ids[$index][$pos_Index][0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$prd_ids[$index][$pos_Index][0]->p_prd_img;
                 }
                  $prod_sets_image[$pos_Index][]=$img_path;
             }
	?>
<tr>
	<td> <?php echo $ij++;?></td>
	<td>
	<?php
	 	if($p->psd_prd_alignment=='vertical')
          	{

          		////asort($prod_position);//dont use it, now array is correct///
          		foreach($prod_position as $index22=>$ptt)
              {
              	 echo "<img src='".$prod_sets_image[$index22][0]."' width='100' height='100'><br/>";
          	?>
	<!-- <td>Product Set <?php echo $i++;?></td> -->
	<?php
		}
		echo $p->psd_prd_alignment;
	}
		else
		{
			//////asort($prod_position);//dont use it, now array is correct///
			foreach($prod_position as $index22=>$ptt)
              {
              	//pre_list($prod_sets_image[$index22]);
              	echo "<img src='".$prod_sets_image[$index22][0]."' width='50' height='50'>";

			?>
			<?php
		}
		echo $p->psd_prd_alignment;
		}
	?>
	<td>
	<table>
		<thead>
			<tr>
				<th>Item Name</th>
			</tr>
		</thead>
		<tbody>
	<?php
	foreach($prd_ids[$index] as $indx2=>$q)
	{
	
	
	// echo "<pre>";
	// print_r($indx2);
	// echo "</pre>";
		?>
		<tr>
<td><?php echo $q[0]->pname;?></td>
</tr>
<?php
}
?>
</tbody>
</table>
</td>
<td>Item Quantity: <?php echo $p->psd_prd_qty;?><br/>Pipe Quantity: <?php echo $p->psd_pipe_qnty;?></td>
<td><?php echo $p->psd_pipe_hgt;?> meter
<small>(Clearance level <?php if(!empty($result[0]->st_underground_pipe))
{
	echo "+ Underground Pipe height";
};?>)</small>
</td>

</tr>
<?php
}
if(!empty($prd_ids_singles))
{
	$v=1;$av=1;
	$single_qty=explode(',',$result[0]->st_single_prd_qtys);
	$single_pipe_qty=explode(',',$result[0]->st_single_pipe_qty);
	$single_pipe_hgt=explode(',',$result[0]->st_single_pipe_hgt);

	foreach ($prd_ids_singles as $key => $value) 
	{
		if(empty($value[0]->p_prd_img))
                {
                  $filename="https://birigroup.com/uploads/prd_images/".$value[0]->pcode.'.jpeg';
                 if (file_exists($filename)) {
                  $img_path=$filename;
                  } else {
                  $img_path="https://birigroup.com/uploads/prd_images/".$value[0]->pcode.'.jpg';
                    }
                }
                 else
                 {
                  $first_img_prd=explode(',',$value[0]->p_prd_img);
                  if(!empty($first_img_prd[0]))
                  $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                  else
                  $img_path="https://birigroup.com/uploads/prd_images/".$value[0]->p_prd_img;
                 }
	?>
<tr>
	<td> <?php echo $av++;?></td>
	<td>
		<img src="<?php echo $img_path;?>"  width='100' height='100'>
	</td>
	<td>
	<table>
		<thead>
			<tr>
				<th>Item Name</th>
			</tr>
		</thead>
		<tbody>
		<tr>
<td><?php echo $value[0]->pname;?></td>
</tr>
</tbody>
</table>
</td>
<td>Item Quantity: <?php if(empty($single_qty[$key])){echo "<span style='color:red';>0</span>";}else{echo $single_qty[$key];}?><br/>
Pipe Quantity: <?php if(empty($single_pipe_qty[$key])){echo "<span style='color:red';>0</span>";}else{ echo $single_pipe_qty[$key]; };?>
</td>
<td><?php if(empty($single_pipe_hgt[$key])){echo "<span style='color:red';>0</span>";}else{ echo $single_pipe_hgt[$key]; };?> meter
<small>(Clearance level <?php if(!empty($result[0]->st_underground_pipe))
{
	echo "+ Underground Pipe height";
};?>)</small>
</td>
</tr>
	<?php
	}
}
?>
</tbody>
</table>
</div>

<div style="text-align: center;">
	<a href="<?php echo base_url('print-prd-sets-status/'.$result[0]->st_id);?>" class="btn bg-success btn-md">Print this</a>
	<a href="<?php echo base_url('show-prd-sets/'.$result[0]->st_id);?>" class="btn bg-tertiary btn-md">Manage Quantity</a>
	<a href="<?php echo base_url('list-survey-data');?>" class="btn bg-info btn-md">List All Survey</a>
<?php
if($result[0]->st_po_prd_qtys !='' || !empty($result[0]->st_po_prd_qtys) || $result[0]->st_po_prd_qtys!=null )
	{
		if($result[0]->po_current_status < '3') ////if on production current survey, dont allow to send new orders to po
		{
		?>
<a href="<?php echo base_url('generate_po_survey/'.$result[0]->st_id.'/updated');?>" class="btn btn-primary btn-md " >Send for Production </a>
<?php
	}
}?>
</div>
</div>

</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

</body>
</html>