<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Survey Form </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Survey Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12 col-md-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Survey Form</h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('submit_manage_prd_singles','class="myform" ','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
  <input type="hidden" name="survey_id" value="<?php echo $survey_id;?>">
  <input type="hidden" name="prd_id" value="<?php echo $prd_ids[0]->pid;?>">
 
  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>


<div class="row">

<?php
if(!empty($survey_result[0]->st_single_prds))
{
  $prd_id_array=explode(',', $survey_result[0]->st_single_prds);
  $prd_qntys=explode(',', $survey_result[0]->st_single_prd_qtys);
  $prd_pipe_heights=explode(',', $survey_result[0]->st_single_pipe_hgt);
  $prd_pipe_qnty=explode(',', $survey_result[0]->st_single_pipe_qty);
  $prd_serial_no=explode(',', $survey_result[0]->st_single_prd_serial_no);
  $prd_cordiante=explode('$#$', $survey_result[0]->st_single_prd_map_cordinates);

  foreach($prd_id_array as $key=>$pr)
  {
     if($prd_ids[0]->pid==$pr)
     {
     $prdd_qnty=$prd_qntys[$key];
     $pipe_hgt=$prd_pipe_heights[$key];
     $pipe_qnty=$prd_pipe_qnty[$key];
     $serail_no=$prd_serial_no[$key];
     $map_cordinate=$prd_cordiante[$key];
     }
  }
 
}
;?>
<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Serial No.<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type="text" name="psd_serial_number" value="<?php if(!empty($serail_no)){echo $serail_no;};?>"  class="form-control" required="">
 <div class="form_error">  <?php echo $this->session->flashdata('psd_serial_number');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Map Cordinates<abbr class="required">::*::</abbr>
  <small>Please enter the cordinate values in the given format . Format : 25.2470676,55.3475439</small>
</label>
<div class="col-md-8">
 <input type='text' name="psd_map_cordinate"  class="form-control"  value="<?php if(!empty($map_cordinate)){echo $map_cordinate;};?>"  pattern="([0-9.-]+).+?([0-9.-]+)" />
  <div class="form_error">  <?php echo $this->session->flashdata('psd_map_cordinate');?></div>
</div>
</div><!--(\-?\d+(\.\d+))(,\s*(\-?\d+(\.\d+)))*-->
</div>
</div>
<!-----=====================table col-12 ends here===================---->
<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">


<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Quantity Required<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type='text' name="qnty_required"  class="form-control"  value="<?php if(!empty($prdd_qnty)){echo $prdd_qnty;};?>" onkeyup="prd_set_hgt()"  required="" />
 <div class="form_error">  <?php echo $this->session->flashdata('qnty_required');?></div>
</div>
</div>
</div>

</div>
<!-----=====================table col-12 ends here===================---->
<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Pipe Quantity <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type='text' name="pipe_qnty"  class="form-control"  value="<?php if(!empty($pipe_qnty)){echo $pipe_qnty;};?>"   />
 <div class="form_error">  <?php echo $this->session->flashdata('pipe_qnty');?></div>
</div>
</div>
</div>


<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Pipe Height <abbr class="required">::*::</abbr></label>
<div class="col-md-8">                 
<?php
$hgt_calc=$survey_result[0]->st_clearance+$survey_result[0]->st_underground_pipe+$prd_ids[0]->prd_height*0.001;
//print_r($hgt_calc);echo '<br/>';
//print_r(ceil(44.1));
$new_number_calc=my_round($hgt_calc);

//$ttt=round(ceil(3.124*100)/100,2);

?>          
<?php
function my_round($number) {
    $inumber = ceil($number);
    $mod_10 = $inumber % 10;
    $mod_5 = $inumber % 5;  
  
    if ($mod_10 < 5) {
        return $inumber + 5 - $mod_5;
    }

    if ($mod_10 > 5) {
        return $inumber + 10 - $mod_10;
    }

    return $inumber;
}
?>
<input type="hidden" name="pipe_basic_hgt" value="<?php echo $survey_result[0]->st_clearance+$survey_result[0]->st_underground_pipe;?>">                                           
<input type='text' name="pipe_hgt"  class="form-control"  value="<?php echo round(ceil($hgt_calc*100)/100,2);?>"   />
<small>NOTE: If you want to enter pipe height manually, replace the current value and enter the new value then just submit the form.</small>
 <div class="form_error">  <?php echo $this->session->flashdata('pipe_hgt');?></div>
</div>
</div>
</div>


</div>
<!-----=====================table col-12 ends here===================---->

<input type="hidden" class="store_value_prd_grps" name="store_value_prd_grps" >
<input type="hidden" class="store_value_prd_grps" name="psd_prd_arrangment" >
<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="table-responsive">  
<table class="table table-bordered mb-none">
  <thead>
    <tr>
      <!--  <th>#</th>  -->
      <th></th>
       <th>Product Name</th> 
       <th>Product Code</th> 
      <th>Product Shape</th>  
    </tr>
  </thead>
  <tbody class="new_rows">
  <?php  
   if(empty($prd_ids[0]->p_prd_img))
        {
          $filename="https://birigroup.com/uploads/prd_images/".$prd_ids[0]->pcode.'.jpeg';
         if (file_exists($filename)) {
          $img_path=$filename;
          } else {
          $img_path="https://birigroup.com/uploads/prd_images/".$prd_ids[0]->pcode.'.jpg';
            }
        }
         else
         {
          $first_img_prd=explode(',',$prd_ids[0]->p_prd_img);
          if(!empty($first_img_prd[0]))
          $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
          else
          $img_path="https://birigroup.com/uploads/prd_images/".$prd_ids[0]->p_prd_img;
         }       
?>
<tr>
 <!--  <td><button type="button" onclick="remove_item_single()">X</button></td> -->
 <td><img src="<?php echo $img_path;?>" width="100" height='100'></td>
  <td ><input type="hidden" name="prd_img_data" class="" value="<?php echo $img_path;?>"><?php echo $prd_ids[0]->pname;?></td>
  <td><?php echo $prd_ids[0]->pcode;?></td>
 <td>
 <!-- <p>Triangle Sign ?
  <span>Yes <input class="shaape" type="radio" name="item_shape" value="yes" ></span> 
  <span>No <input class="shaape" type="radio" name="item_shape" value="no" checked="" ></span></p>
<br/>
<!-- <div class="show_div_size_<?php echo $index;?> show_choose_size">
  <select class="show_choose_size_<?php echo $index;?>" >
    <option>Choose Triangle Size</option>
    <option value="75">75 cm</option>
    <option value="40">40 cm</option>
    <option value="60">60 cm</option>
    <option value="80">80 cm</option> 
    <option value="90">90 cm</option>
    <option value="120">120 cm</option>
    <option value="150">150 cm</option>
    <option value="1200">1200 cm</option>
  </select>
</div> -->

<p>Product Height: <span class="product_current_height"><?php echo $prd_ids[0]->prd_height*0.001;?></span></p>
<input type="hidden" name="default_height" value="<?php echo $prd_ids[0]->prd_height*0.001;?>">
</td>
</tr>

</tbody>
</table>
</div>
<!-----=====================table col-12 ends here===================---->
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for details---->

<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>


</section>
</div>

</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script type="text/javascript">
  function prd_set_hgt()
  {
   var quantity= $('input[name="qnty_required"]').val();
   $('input[name="pipe_qnty"]').val(quantity);
   var aligment_value=$('input[name=alignment]:checked').val();
  }

</script>
<script type="text/javascript">
$('input[name="item_shape"]').on('change',function(){
  var value=$(this).val();
  if(value=='yes')
  {
    var prod_height=$('.product_current_height').text();
    var new_product_height=parseFloat(prod_height)*0.86; 
    $('.product_current_height').html(new_product_height.toFixed(2));
       var total_prd_height=parseFloat($('input[name="pipe_basic_hgt"]').val())+parseFloat(new_product_height);
      $('input[name="pipe_hgt"]').val(my_round(total_prd_height));
  //$(".show_div_size_"+id_val+"").show();
  }
  else
  {
    var prod_height=$('input[name="default_height"]').val();
    $('.product_current_height').html(prod_height);
    var total_prd_height=parseFloat($('input[name="pipe_basic_hgt"]').val())+parseFloat(prod_height);
    $('input[name="pipe_hgt"]').val(my_round(total_prd_height)); 
     // $(".show_div_size_"+id_val+"").hide();
  }
});

  function my_round(number) {
    var inumber = Math.ceil(number);

    var mod_10 = inumber % 10;
    var mod_5 = inumber % 5;

    if (mod_10 < 5) {
        return inumber + 5 - mod_5;
    }

    if (mod_10 > 5) {
        return inumber + 10 - mod_10;
    }

    return inumber;
}
</script>
</body>

</html>