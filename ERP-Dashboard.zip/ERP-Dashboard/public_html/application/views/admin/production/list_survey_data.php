<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Survey Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Survey Details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-----section for lightbox opens here-->
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">List Survey Details</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th>Survey No</th>
<th>Customer Details</th>
<th>Departments &amp; Date</th>
<th>Cordinates</th>
<th>Items </th>
<th width="1%">Status</th>
<th class="action_class">Action</th>
</tr>
</thead>
<tbody>
<?php
	if(!empty($result))
	{
		$i=1;
	foreach($result as $index=>$q)
	{		
?>
<tr>
	<td><?php echo $q->st_survey_no;?></td>
	<td><?php echo '<b>Customer Name:</b> '.$q->st_new_cust_name .' <br/> <b>Company: </b> '.$q->st_new_cust_comp;?></td>
	<td><?php echo '<b>'.$q->st_dept_po.'</b>';?> <br/>
		PO Delivery Date: <?php echo $q->st_po_dept_date;?>
	<br/> 
	<?php if(!empty($q->st_dept_installation)){
		echo '<b>'.$q->st_dept_installation.'</b>';
		?>
		<br/>Installation Date:<?php if(!empty($q->st_installation_dept_date)){echo $q->st_installation_dept_date;}?>
		<?php
	}?>
	</td>
	<td><b>Start Cordinate:</b><?php echo $q->st_start_cordinate;?><br/><b>End Cordinate:</b> <?php echo $q->st_end_cordinate;?></td>
	<td>
		<table class="table table-bordered">
			<thead>
				<th>Product Name</th>
				<th>Quantity</th>
			</thead>
			<tbody>
		<?php  
$quantities=explode('|#|',$q->st_po_prd_qtys);
$remarks=explode('|#|',$q->st_po_prd_additional_info);
$total_sum_qnty=0;
	foreach($prd_ids[$index] as $pid)
	{
		
		foreach($pid as $inndex=>$ppid)
		{
			echo "<tr>";
			echo "<td>".$ppid[0]->pname.' ('.$ppid[0]->pcode.')'."</td>";
			if(!empty($quantities[$inndex]))
			echo "<td>".$quantities[$inndex]." </td>";
				else
			echo "<td> 0 </td>";
			$total_sum_qnty=$total_sum_qnty+$quantities[$inndex];
		echo "</tr>";
		}
		
	//$prds=explode(',',$q->st_po_prd_ids);
	}
	?>
	</tbody>
		</table>
</td>

		<td width="1%">
		<p><b>Total Quantity:</b><?php echo $total_sum_qnty;?></p>
			<?php
			if(empty($q->po_id))
				{?>
			<span class='label label-warning'>Not send for PO</span>
			 <a class="mb-xs mt-xs mr-xs modal-sizes modal-basic btn btn-success" href="#modalFullColorPrimary_<?php echo $q->st_id;?>">Generate PO</a>
			<?php
			}
			else
			{
				$flag_sts_survey=0;
				if(!empty($installation_table_details[$index][0]))
				{
	$prd_set_qnty=explode(',',$installation_table_details[$index][0]->prd_set_final_calc_qnty);
					$prd_single_qnty=explode(',',$installation_table_details[$index][0]->prd_single_final_calc_qnty);

					if(!empty($installation_table_details[$index][0]->prd_set_final_calc_qnty) && !empty($installation_table_details[$index][0]->prd_single_final_calc_qnty))
					{
						if((array_filter($prd_set_qnty)==false) && (array_filter($prd_single_qnty)==false))
						{
							$survey_sts[$index]='completed';
							echo "<span class='label label-success'>Survey Completed</span>";
						}
						else
						{
							echo "<span class='label label-warning'>Under Installation</span>";
							$flag_sts_survey=1;
						}
					}
					elseif(!empty($installation_table_details[$index][0]->prd_set_final_calc_qnty) )
					{
						if(array_filter($prd_set_qnty)==false)
						{
							$survey_sts[$index]='completed';
								echo "<span class='label label-success'>Survey Completed</span>";
						}
						else
						{
							echo "<span class='label label-warning'>Under Installation</span>";
							$flag_sts_survey=1;
						}
					}
					elseif(!empty($installation_table_details[$index][0]->prd_single_final_calc_qnty) )
					{
						if(array_filter($prd_single_qnty)==false)
						{
							$survey_sts[$index]='completed';
								echo "<span class='label label-success'>Survey Completed</span>";
						}
						else
						{
							echo "<span class='label label-warning'>Under Installation</span>";
							$flag_sts_survey=1;
						}
					}
					elseif($installation_table[$index][0]->ins_sts_installation=="completed")
					{
							$survey_sts[$index]='completed';
							echo "<span class='label label-success'>Survey Completed</span>";
					}
					else
					{
						echo "<span class='label label-warning'>Under Installation</span>";
						$flag_sts_survey=1;
					}
				}
				else
				{
					echo "<span class='label label-success'>Send for PO</span>";
				}
				?>
			<?php
			}
			?>
			<br/><br/>
			<span class='label label-info'><?php echo $q->st_survey_type;?></span>
		</td>
<td class="action_class">
			<div class="dropdown-primary dropdown ">
<button class="btn btn-primary dropdown-toggle waves-effect waves-light" type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" onclick="increase_width()">Action </button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">
<?php
if(!empty($survey_sts[$index]))
{
?>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('generate_pdf_installation/'.$installation_table[$index][0]->ins_id);?>">Generate PDF Installation</a>
<?php
}
else
{
	if($flag_sts_survey!=1)
	{
?>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('edit_survey_details/'.$q->st_id);?>"><i class="fa fa-pencil"></i>Edit Details</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('show-prd-sets/'.$q->st_id);?>"><i class="fa fa-pencil"></i>Manage Products</a>
<div class="dropdown-divider"></div>
<?php
	}?>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('delete_survey/'.$q->st_id);?>"><i class="fa fa-trash-o"></i>Delete </a>
<?php
}
?>
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('survey-history/'.$q->st_id);?>"><i class="fa fa-history"></i> Survey History</a>
</div>
</div>
	</td>		
</tr>
<div id="modalFullColorPrimary_<?php echo $q->st_id;?>" class="modal-block  modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Are you sure?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-icon">
<i class="fa fa-question-circle"></i>
</div>
<div class="modal-text">
<h4>Send for Production Order</h4>
<p>Are you sure that you want to send this product set for creating Production Order?</p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
	<a href="<?php echo base_url('generate_po_survey/'.$q->st_id);?>" class="btn btn-primary">Confirm</a>

<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<?php
}
}
?>

</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	 $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );

	
</script>

</body>
</html>