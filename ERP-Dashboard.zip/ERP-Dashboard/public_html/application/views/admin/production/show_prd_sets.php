<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Manage Product Set</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Manage </span></li>
<li><span>Product Set</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-----section for lightbox opens here-->

<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Manage Products Sets

<span class="pull-right">
	<span><a href="<?php echo base_url('create_new_item_sets/item_set/'.$survey_id);?>" class="btn btn-primary">Create new Item Sets</a></span> 
	<span><a href="<?php echo base_url('create_new_item_sets/item_single/'.$survey_id);?>" class="btn btn-primary">Create new Single Item</a>  </span>
</span>
</h2>
</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result">
<table class="table table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th>Set</th>
<th style="width: 50%;">Item Details</th>	
<th>Current Status</th>
<th>Action</th>
<th></th>
</tr>
</thead>
<tbody>
<?php
	if(!empty($prd_ids))
	{
		$a=1;
		foreach($prd_ids as $index=>$pdd)
		{
			?>
<tr class="gradeX">
			<td>Product Set #<?php echo $a++;?><br/>
				<?php if(!empty($survey_result_2[$index]->psd_prd_qty)){ echo "<b>Quantity :</b> " .$survey_result_2[$index]->psd_prd_qty.'<br/>';};?>
				<?php if(!empty($survey_result_2[$index]->psd_pipe_hgt)){ echo "<b>Pipe Height :</b> " .$survey_result_2[$index]->psd_pipe_hgt.'<br/>';};?>
			</td>
			<td>
				<table>
					<thead>
						<th>Image</th>
						<th>Item Name</th>
						<th>Code</th>
					</thead>
					<tbody>
				
	<?php
	foreach($pdd as $pd2)
	{
		if(empty($pd2[0]->p_prd_img))
				{
					$filename="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpeg';
				 if (file_exists($filename)) {
				 	$img_path=$filename;
					} else {
					$img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->pcode.'.jpg';
				    }
				}
				 else
				 {
				 	$first_img_prd=explode(',',$pd2[0]->p_prd_img);
				 	if(!empty($first_img_prd[0]))
				 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
				 	else
				 	$img_path="https://birigroup.com/uploads/prd_images/".$pd2[0]->p_prd_img;
				 }
		?>
		<tr>
				<td><img src="<?php echo $img_path;?>" width="100" height="100"></td>
			<td><?php echo $pd2[0]->pname;?></td>
			<td><?php echo $pd2[0]->pcode;?></td>
		</tr>
			<?php
		}
		?>
			</tbody>
				</table>

		</td>
		<td><?php 
		if(is_null($prd_alignment[$index]))
		{
			echo "<span class='label label-warning'>Need Updates</span>";
		}
		else
		{
			echo "<span class='label label-success'>Done</span>";
		}
		;?></td>
		<td><a href="<?php echo base_url('manage_prd_set/'.$prd_set_id[$index]);?>" class="btn btn-sm label-primary" style="opacity: unset;">Manage Product Set</a></td>
		<td><button type="button" class="btn btn-danger" onclick="remove_prd_set_data(<?php echo $survey_id;?>,<?php echo $prd_set_id[$index];?>);">X</button></td>
	</tr>

<?php
	}
}
?>
</tbody>
</table>
<table class="table table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th>Set</th>
<th style="width: 50%;">Item Details</th>	
<th>Current Status</th>
<th>Action</th>
<th></th>
</tr>
</thead>
<tbody>

<?php
if(!empty($prd_ids_singles[0]))
{

	$b=1;
	foreach($prd_ids_singles as $index2=>$pdd)
	{
		$single_qty=explode(',',$survey_result[0]->st_single_prd_qtys);
		$single_pipe_qty=explode(',',$survey_result[0]->st_single_pipe_qty);
		$single_pipe_hgt=explode(',', $survey_result[0]->st_single_pipe_hgt);
		$single_serial_no=explode(',',$survey_result[0]->st_single_prd_serial_no);
		?>
<tr class="gradeX">
			<td>Single Product #<?php echo $b++;?><br/>
			<?php if(!empty($single_qty[$index2])){ echo "<b>Quantity :</b> " .$single_qty[$index2].'<br/>';};?>
				<?php if(!empty($single_pipe_hgt[$index2])){ echo "<b>Pipe Height :</b> " .$single_pipe_hgt[$index2].'<br/>';};?>
			</td>
			<td>
				<table>
					<thead>
						<th>Image</th>
						<th>Item Name</th>
						<th>Code</th>
					</thead>
					<tbody>
				
	<?php
		if(empty($pdd[0]->p_prd_img))
				{
					$filename="https://birigroup.com/uploads/prd_images/".$pdd[0]->pcode.'.jpeg';
				 if (file_exists($filename)) {
				 	$img_path=$filename;
					} else {
					$img_path="https://birigroup.com/uploads/prd_images/".$pdd[0]->pcode.'.jpg';
				    }
				}
				 else
				 {
				 	$first_img_prd=explode(',',$pdd[0]->p_prd_img);
				 	if(!empty($first_img_prd[0]))
				 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
				 	else
				 	$img_path="https://birigroup.com/uploads/prd_images/".$pdd[0]->p_prd_img;
				 }
		?>
		<tr>
				<td><img src="<?php echo $img_path;?>" width="100" height="100"></td>
			<td><?php echo $pdd[0]->pname;?></td>
			<td><?php echo $pdd[0]->pcode;?></td>
		</tr>

			</tbody>
				</table>

		</td>
		<td><?php 
		if(empty($single_qty[$index2]))
		{
			echo "<span class='label label-warning'>Need Updates</span>";
		}
		else
		{
			echo "<span class='label label-success'>Done</span>";
		}
		;?></td>
		<td><a href="<?php echo base_url('manage_prd_singles/'.$survey_id.'/'.$pdd[0]->pid);?>" class="btn btn-sm label-primary" style="opacity: unset;">Manage Product Single</a></td>
		<td>
			<button type="button" class="btn btn-danger" onclick="remove_prd_single_data(<?php echo $survey_id;?>,<?php echo $pdd[0]->pid;?>);">X</button></td>
	</tr>
		<?php
	}
}
?>
</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script type="text/javascript">
   $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );
</script>
<script type="text/javascript">
	function remove_prd_set_data(survey_id,prd_set_id) {
		 if (confirm('Are you sure you want to delete this ? Please Note: This cannot be undone later.')) 
          {
             jQuery.ajax({
                url:"<?php echo base_url().'Survey_controller/remove_prd_set_data';?>",
                type:"post",
                data:{'prd_set_id':prd_set_id,'survey_id':survey_id},
                success:function(result)
                    {
                      if(result)
                      {
                      	location.reload();
                       }
                    }
              });
             return true;
          } 
        else 
          {
           return false; 
          }
	}

	function remove_prd_single_data(survey_id,prd_single_id) {
		 if (confirm('Are you sure you want to delete this ? Please Note: This cannot be undone later.')) 
          {
             jQuery.ajax({
                url:"<?php echo base_url().'Survey_controller/remove_prd_single_data';?>",
                type:"post",
                data:{'prd_single_id':prd_single_id,'survey_id':survey_id},
                success:function(result)
                    {
                      if(result)
                      {
                      	location.reload();
                       }
                    }
              });
             return true;
          } 
        else 
          {
           return false; 
          }
	}
</script>

</body>
</html>