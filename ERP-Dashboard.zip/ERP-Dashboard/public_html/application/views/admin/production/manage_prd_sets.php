<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Survey Form </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Survey Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-9 col-md-9">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Survey Form</h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('submit_manage_prd_set','class="myform" ','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
  <input type="hidden" name="survey_id" value="<?php echo $prd_set_data[0]->psd_survey_id;?>">
  <input type="hidden" name="update_psd_id" value="<?php echo $prd_set_data[0]->psd_id;?>">
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

<div class="row">

<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Serial No.<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type="text" name="psd_serial_number" value="<?php if(!empty($prd_set_data[0]->psd_serial_number)){echo $prd_set_data[0]->psd_serial_number;};?>"  class="form-control" required="">
 <div class="form_error">  <?php echo $this->session->flashdata('psd_serial_number');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Map Cordinates<abbr class="required">::*::</abbr>
  <small>Please enter the cordinate values in the given format . Format : 25.2470676,55.3475439</small>
</label>
<div class="col-md-8">
 <input type='text' name="psd_map_cordinate"  class="form-control"  value="<?php if(!empty($prd_set_data[0]->psd_map_cordinate)){echo $prd_set_data[0]->psd_map_cordinate;};?>"  pattern="([0-9.-]+).+?([0-9.-]+)" />
  <div class="form_error">  <?php echo $this->session->flashdata('psd_map_cordinate');?></div>
</div>
</div><!--(\-?\d+(\.\d+))(,\s*(\-?\d+(\.\d+)))*-->
</div>
</div>
<!-----=====================table col-12 ends here===================---->
<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Aligment  <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type="radio"  value="horizontal" name="alignment" <?php if(!empty($prd_set_data[0]->psd_prd_alignment=="horizontal")){echo "checked";};?> required="" >Horizontal(back to back)<br/>
<input type="radio"  value="vertical" name="alignment" <?php if(!empty($prd_set_data[0]->psd_prd_alignment=="vertical")){echo "checked";};?> required="">Vertical(top to bottom)
 <div class="form_error">  <?php echo $this->session->flashdata('alignment');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Quantity Required<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type='text' name="qnty_required"  class="form-control"  value="<?php if(!empty($prd_set_data[0]->psd_prd_qty)){echo $prd_set_data[0]->psd_prd_qty;};?>" onkeyup="prd_set_hgt()"  required="" />
 <div class="form_error">  <?php echo $this->session->flashdata('qnty_required');?></div>
</div>
</div>
</div>

</div>
<!-----=====================table col-12 ends here===================---->
<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Pipe Quantity <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type='text' name="pipe_qnty"  class="form-control"  value="<?php if(!empty($prd_set_data[0]->psd_pipe_qnty)){echo $prd_set_data[0]->psd_pipe_qnty;};?>"   />
 <div class="form_error">  <?php echo $this->session->flashdata('pipe_qnty');?></div>
</div>
</div>
</div>
<?php 
if(!empty($survey_result[0]->st_clearance))
{
  $clearance_data=$survey_result[0]->st_clearance;
}
else
{
  $clearance_data='0';
}

if(!empty($survey_result[0]->st_underground_pipe))
{
$underground_pipe_hgt=$survey_result[0]->st_underground_pipe;
}
else
{
$underground_pipe_hgt='0';
}
$pipe_hgt_data=$underground_pipe_hgt+$clearance_data;

echo "<input name='hgt_data_survey' type='hidden' value='".$pipe_hgt_data."'>";
?>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Pipe Height <small>(In Meter)</small> <abbr class="required">::*::</abbr></label>
<div class="col-md-8">                                                                            
<input type='text' name="pipe_hgt"  class="form-control"  value="<?php if(!empty($prd_set_data[0]->psd_pipe_hgt)){echo $prd_set_data[0]->psd_pipe_hgt;};?>"   />
<small>NOTE: If you want to enter pipe height, then no need to click on "PREVIEW SIGN NOW" button. Just submit the form. If you want the system to do it, then you use "Preview button"</small>
 <div class="form_error">  <?php echo $this->session->flashdata('pipe_hgt');?></div>
</div>
</div>
</div>
</div>
<!-----=====================table col-12 ends here===================---->
<input type="hidden" class="store_value_prd_grps" name="store_value_prd_grps" >
<input type="hidden" class="store_value_prd_grps" name="psd_prd_arrangment" >
<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="table-responsive">  
<table class="table table-bordered mb-none">
  <thead>
    <tr>
      <!--  <th>#</th>  -->
      <th></th>
      <th>Image</th>
       <th>Product Name</th> 
       <th>Product Code</th> 
       <th>Arrange as per position</th> 
       <th>Product Shape</th>  
    </tr>
  </thead>
  <tbody class="new_rows">
  <?php 
  if(!empty($prd_set_data[0]->psd_arrange_position))

  $prd_arrange_pos= explode(',',$prd_set_data[0]->psd_arrange_position);
  foreach($prd_ids as $index=>$pid)
  {
    //pre_list($pid[0]->pid);
$height_array[]=$pid[0]->prd_height*0.001;/////////for converting mm to meter ///////
echo "<input type='hidden' name='height_array[]' value='".$pid[0]->prd_height*0.001."'>";

   if(empty($pid[0]->p_prd_img))
        {
          $filename="https://birigroup.com/uploads/prd_images/".$pid[0]->pcode.'.jpeg';
         if (file_exists($filename)) {
          $img_path=$filename;
          } else {
          $img_path="https://birigroup.com/uploads/prd_images/".$pid[0]->pcode.'.jpg';
            }
        }
       else
       {
        $first_img_prd=explode(',',$pid[0]->p_prd_img);
        if(!empty($first_img_prd[0]))
        $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
        else
        $img_path="https://birigroup.com/uploads/prd_images/".$pid[0]->p_prd_img;
       }      
?>
<tr class="table_row_<?php echo $index;?>">
  <td><button type="button" onclick="remove_item(<?php echo $index;?>)">X</button><input type="hidden" name="item_id_<?php echo $index;?>" value="<?php echo $pid[0]->pid;?>" class="form-control"></td>
  <td><img src="<?php echo $img_path;?>" width="100" height='100'></td>
  <td ><input type="hidden" name="prd_img_data" class="prd_img_<?php echo $index;?>" value="<?php echo $img_path;?>"><?php echo $pid[0]->pname;?></td>
  <td><?php echo $pid[0]->pcode;?><input type="hidden" class="prd_height_<?php echo $index;?>" name="prd_height" value="<?php echo $pid[0]->prd_height*0.001;?>">
  </td>
 <td>
  <select name="arrange_position[]" class="form-control arrange_position" >

   <?php
// if(empty($prd_set_data[0]->psd_arrange_position))
// {
   $ij=1;
  for($k=0;$k<$count_prd_id;$k++)
  {
//pre_list($prd_arrange_pos[$k]);
    ?>
<option value="<?php echo $k;?>" <?php if(!empty($prd_set_data[0]->psd_arrange_position)){if($prd_arrange_pos[$index]==$k){echo "selected";}} ;?>><?php echo $ij++;?></option>
   <?php
}
//}
 //     ?>
</select>
</td>
<td>
 <!-- <p>Triangle Sign ?
  <span>Yes <input class="shaape" type="radio" name="item_shape_<?php echo $index;?>[]" value="yes" <?php if(!empty($prd_set_data[0]->is_triangle)){if($prd_set_data[0]->is_triangle=='yes'){echo 'checked';}};?> onclick="item_shape(<?php echo $index;?>,'yes')"></span> 
  <span>No <input class="shaape" type="radio" name="item_shape_<?php echo $index;?>[]" value="no" <?php if(!empty($prd_set_data[0]->is_triangle)){if($prd_set_data[0]->is_triangle=='no'){echo 'checked';}}else{ echo 'checked';};?> onclick="item_shape(<?php echo $index;?>,'no')"></span></p>
<br/>
<!-- <div class="show_div_size_<?php echo $index;?> show_choose_size">
  <select class="show_choose_size_<?php echo $index;?>" >
    <option>Choose Triangle Size</option>
    <option value="75">75 cm</option>
    <option value="40">40 cm</option>
    <option value="60">60 cm</option>
    <option value="80">80 cm</option> 
    <option value="90">90 cm</option>
    <option value="120">120 cm</option>
    <option value="150">150 cm</option>
    <option value="1200">1200 cm</option>
  </select>
</div> -->
<p>Product Height: <span class="product_current_height_<?php echo $index;?>"><?php echo $pid[0]->prd_height*0.001;?></span></p>

<input type='hidden' value='' name='is_triangle[]'>
</td>
</tr>
<?php
  }
 
 echo "<input type='hidden' name='max_height_vertical' value='".array_sum($height_array)."'>";
echo "<input type='hidden' name='max_height_horizontal' value='".max($height_array)."'>";
 ?> 
</tbody>
</table>
<p style="color: green" class="success_text"></p>
</div>
<!-----=====================table col-12 ends here===================---->
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for details---->

<div class="col-sm-9 col-sm-offset-3">
<button type="button" class="btn btn-warning" onclick="preview_image()">Preview Sign Now</button><br/><br/>
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div>

<div class="col-lg-3 col-md-3">
  <h4>Preview goes here</h4>
  <section class="panel">
    <div class="col-md-12">
<div class="panel-body bg-primary">
  <?php 
  if(empty($prd_set_data[0]->psd_arrange_position))
  {
  foreach($prd_ids as $index=>$pid)
  {
?>
<div class="preview_<?php echo $index;?>" style="text-align: center;"></div>
<?php
  }
}
else
{ 
 echo '<div style="text-align: center;">';
 asort($prd_arrange_pos);
foreach( $prd_arrange_pos as $index11=>$pap)
  {
    if(empty($prd_ids_img[$pap][0]->p_prd_img))
        {
          $filename="https://birigroup.com/uploads/prd_images/".$prd_ids_img[$pap][0]->pcode.'.jpeg';
         if (file_exists($filename)) {
          $img_path=$filename;
          } else {
          $img_path="https://birigroup.com/uploads/prd_images/".$prd_ids_img[$pap][0]->pcode.'.jpg';
            }
        }
         else
         {
          $first_img_prd=explode(',',$prd_ids_img[$pap][0]->p_prd_img);
          if(!empty($first_img_prd[0]))
          $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
          else
          $img_path="https://birigroup.com/uploads/prd_images/".$prd_ids_img[$pap][0]->p_prd_img;
         }
    if($prd_set_data[0]->psd_prd_alignment=="vertical")
    {
     
?>
<img src="<?php echo $img_path;?>" width="100" height='100'><br/>
<?php
    }
    else
    {
      ?>
<img src="<?php echo $img_path;?>" width="80" height='100'>
      <?php
    }
  }
    echo '</div >';
}
  ?>

 
</div>
</div>
<div class="col-md-12">
 <div style="text-align: center;" class="img_pipe"><img src="<?php echo base_url('Pole.png');?>" style="text-align: center;"></div>
  </div>
</section>
</div>

</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script type="text/javascript">
//  $(document).ready(function(){
// $('.show_choose_size').hide();
//  });
function item_shape(id_val,value)
{
  if(value=='yes')
  {
    var prod_height=$('.prd_height_'+id_val).val();
    var new_product_height=parseFloat(prod_height)*0.86; 
    $('.product_current_height_'+id_val).html(new_product_height.toFixed(2));
       height_array_value=  $("input[name='height_array[]']").map(function(){return $(this).val();}).get();
       var array_sum='0';
       var new_array=[];
      $.each(height_array_value, function(key2,val2)
            {
              if(key2==id_val)
              {
                new_array.push(new_product_height.toFixed(2));
              }
              else
              {
                new_array.push(val2);
              }
            });

         $.each(new_array, function(key2,val2)
            {
             array_sum=parseFloat(array_sum)+parseFloat(val2);
            });
       var maximum_value_in_array=Math.max.apply(Math,new_array);
        $("input[name='max_height_horizontal']").val(maximum_value_in_array);        
        $("input[name='max_height_vertical']").val(array_sum);
$("input[name='is_triangle[]']").val(id_val+':'+value);
  //$(".show_div_size_"+id_val+"").show();
  }
  else
  {
  // $(".show_div_size_"+id_val+"").hide();
  }
}
</script>

<script type="text/javascript">

 function preview_image()
  {
    var aligment_value=$('input[name=alignment]:checked').val();
    var selectedValues = $('.arrange_position').map(function() {
        return $(this).val();
       }).get();
    $.each(selectedValues, function(key, value) 
    {
          if (aligment_value == 'horizontal') 
          {
           // console.log('hori');
            $('.preview_'+value).html('<img src="'+$('.prd_img_'+key).val()+'"width="100" height="100" style="float:left;text-align: center;">');
            $('.img_pipe').css('float','none');
           var hgt_calc=parseFloat($("input[name='hgt_data_survey']").val())+parseFloat($("input[name='max_height_horizontal']").val());
         // console.log( (Math.round(hgt_calc*100)/100).toFixed(2));
            $("input[name='pipe_hgt']").val((Math.round(hgt_calc*100)/100).toFixed(2));
          }
          else 
          {
            $('.preview_'+value).html('<img src="'+$('.prd_img_'+key).val()+'"width="80" height="100" style="float:none;">');
            $('.img_pipe').css('float','none');
             var hgt_calc=parseFloat($("input[name='hgt_data_survey']").val())+parseFloat($("input[name='max_height_vertical']").val());
             //console.log($("input[name='hgt_data_survey']").val());
             //console.log($("input[name='max_height_vertical']").val());
             //console.log( (Math.round(hgt_calc*100)/100).toFixed(2));
            $("input[name='pipe_hgt']").val((Math.round(hgt_calc*100)/100).toFixed(2));
          }     
    });
    //console.log($('.store_value_prd_grps').val());
  }

  function my_round(number) {
    var inumber = Math.ceil(number);

    var mod_10 = inumber % 10;
    var mod_5 = inumber % 5;

    if (mod_10 < 5) {
        return inumber + 5 - mod_5;
    }

    if (mod_10 > 5) {
        return inumber + 10 - mod_10;
    }

    return inumber;
}

  function prd_set_hgt()
  {
   var quantity= $('input[name="qnty_required"]').val();
   $('input[name="pipe_qnty"]').val(quantity);
    var aligment_value=$('input[name=alignment]:checked').val();
  }

  function remove_item(indx)
  {
    var survey_id=$('input[name="survey_id"]').val();
    var prd_set_id=$('input[name="update_psd_id"]').val();
    var item_id=$('input[name="item_id_'+indx+'"]').val();
    
    if (confirm('Are you sure you want to delete this ? Please Note: This cannot be undone later.')) 
          {
             jQuery.ajax({
                url:"<?php echo base_url().'Survey_controller/remove_item_prd_set';?>",
                type:"post",
                data:{"item_id":item_id,'prd_set_id':prd_set_id,'survey_id':survey_id},
                success:function(result)
                    {
                      if(result)
                      {
                        $('.table_row_'+indx).remove();
                        $('.success_text').html('Item removed successfully');
                      }
                    }
              });
             return true;
          } 
        else 
          {
           return false; 
          }
  }
</script>


</body>

</html>