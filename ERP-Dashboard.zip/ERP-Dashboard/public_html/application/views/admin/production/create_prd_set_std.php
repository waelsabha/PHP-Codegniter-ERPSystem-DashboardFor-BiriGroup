<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Check Standard Pricing</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Check</span></li>
<li><span>Standard Pricing</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<section class="panel">
<header class="panel-heading">

<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

    <?php

    foreach($result as $r)
    {
    	if($r->pps_grp_ids=='1')
    	{
    		$base_array['name'][]=$r->pps_name;
    		$base_array['per'][]=$r->pps_final_price;
    	}
    	elseif($r->pps_grp_ids=='2')
    	{
    		$refl_array['name'][]=$r->pps_name;
    		$refl_array['per'][]=$r->pps_final_price;
    	}
    	elseif($r->pps_grp_ids=='3')
    	{
    		$print_array['name'][]=$r->pps_name;
    		$print_array['per'][]=$r->pps_final_price;
    	}
    	elseif($r->pps_grp_ids=='4')
    	{
    		$channel_array['name'][]=$r->pps_name;	
    		$channel_array['per'][]=$r->pps_final_price;
    	}
    	else
    	{
    		$paint_array['name'][]=$r->pps_name;
    		$paint_array['per'][]=$r->pps_final_price;
    	}
    }
    ?>

 <!--    <?php
    $refl_count=count($refl_array);

    	foreach($base_array['name'] as $index=>$b)
    	{
    		pre_list($b.'*****'.$base_array['per'][$index]);
    		// for($i=0;$i<$refl_count;$i++)
    		// {
    		// 	//pre_list($b.'-'.$refl_array['name'][$i]);
    		// }
    	}
    ?>  -->

   <!--- <?php
    $refl_count=count($refl_array);
    $print_count=count($print_array);
    	foreach($base_array['name'] as $b)
    	{
    		
    		for($i=0;$i<$refl_count;$i++)
    		{
    			for($j=0;$j<$print_count;$j++)
	    		{
	    			pre_list($b.'-'.$refl_array['name'][$i].'*'.$print_array['name'][$j]);
	    		}
    			
    		}
    	}
    ?>

     <?php
    $refl_count=count($refl_array);
    $print_count=count($print_array);
    $channel_count=count($channel_array);
    	foreach($base_array['name'] as $b)
    	{
    		
    		for($i=0;$i<$refl_count;$i++)
    		{
    			for($j=0;$j<$print_count;$j++)
	    		{
	    			for($k=0;$k<=$channel_count;$k++)
	    		{
	    			pre_list($b.'-'.$refl_array['name'][$i].'*'.$print_array['name'][$j].'%'.$channel_array['name'][$k]);
	    		}

	    		}
    			
    		}
    	}
    ?>
 -->
      <?php
      $actual_name_array=array();
      $actual_array_price=array();
    $refl_count=count($refl_array['name']);
    $print_count=count($print_array['name']);
    $channel_count=count($channel_array['name']);
    $paint_count=count($paint_array['name']);
    	foreach($base_array['name'] as $index=>$b)
    	{
    		
    		for($i=0;$i<=$refl_count;$i++)
    		{
    			for($j=0;$j<=$print_count;$j++)
	    		{
	    			for($k=0;$k<=$channel_count;$k++)
		    		{
		    			for($l=0;$l<=$paint_count;$l++)
		    			{
			    			if(!empty($paint_array['name'][$l]))
			    			{
			    				if(!in_array($b.' '.$refl_array['name'][$i].' '.$print_array['name'][$j].' '.$channel_array['name'][$k].' '.$paint_array['name'][$l], $actual_name_array))
			    				{
	 								$actual_name_array[]=$b.' '.$refl_array['name'][$i].' '.$print_array['name'][$j].' '.$channel_array['name'][$k].' '.$paint_array['name'][$l];
	 								$actual_array_price[]=$base_array['per'][$index].' '.$refl_array['per'][$i].' '.$print_array['per'][$j].' '.$channel_array['per'][$k].' '.$paint_array['per'][$l];
			    				}
			    			}
		    			
		    			if(!empty($channel_array['name'][$k]))
		    			{
			    			if(!in_array($b.' '.$refl_array['name'][$i].' '.$print_array['name'][$j].' '.$channel_array['name'][$k], $actual_name_array))
			    			{
			    				$actual_name_array[]=$b.' '.$refl_array['name'][$i].' '.$print_array['name'][$j].' '.$channel_array['name'][$k];
			    				$actual_array_price[]=$base_array['per'][$index].' '.$refl_array['per'][$i].' '.$print_array['per'][$j].' '.$channel_array['per'][$k];
			    			}
		    			}
		    		
		    			if(!empty($print_array['name'][$j]))
		    			{
		    				if(!in_array($b.' '.$refl_array['name'][$i].' '.$print_array['name'][$j], $actual_name_array))
		    				{
		    					$actual_name_array[]=$b.' '.$refl_array['name'][$i].' '.$print_array['name'][$j];
		    					$actual_array_price[]=$base_array['per'][$index].' '.$refl_array['per'][$i].' '.$print_array['per'][$j];
		    				}
		    			}
		    			
		    			if(!empty($refl_array['name'][$i]))
		    			{
		    				if(!in_array($b.' '.$refl_array['name'][$i], $actual_name_array))
		    				{
		    					$actual_name_array[]=$b.' '.$refl_array['name'][$i];
		    					$actual_array_price[]=$base_array['per'][$index].' '.$refl_array['per'][$i];
		    				}
		    			}
		    		
		    			if(!empty($refl_array['name'][$i]))
		    			{
		    				if(!in_array($b, $actual_name_array))
		    				{
		    					$actual_name_array[]=$b;
		    					$actual_array_price[]=$base_array['per'][$index];
		    				}
		    			}
		    		}
		    		}
		    	}
		    }		
    	}
    ?>



    <table class="table table-bordered table-striped mb-none">
    	<thead>
    		<tr>
    			<th>Product Name</th>
    			<th>Width</th>
    			<th>Length</th>
    			<th>Total Size</th>
    			<th>Total Price</th>
    		</tr>
    	</thead>
    	<tbody>
    		 <?php
    		 $c=1;
    		foreach($actual_name_array as $index=>$ab)
    		{
    			?>
    		<tr>
    			<td class=""><?php echo $ab;?></td>
    			<td class=""><input type="text" name="" class="form-control user_width_<?php echo $c;?>" ></td>
    			<td class=""><input type="text" name="" class="form-control user_length_<?php echo $c;?>"></td>
    			<td>
    				<span class="total_size_<?php echo $c;?>"></span><br/>
    				<span class="label label-success" onclick="show_price(<?php echo $c;?>)">Show Price</span>
    			</td>
    			<td>
    				<span class="total_price_<?php echo $c;?>"></span><br/>
    				<?php $sum=explode(' ',$actual_array_price[$index]);?>
    				<input type="hidden" name="price_final" class="price_final_<?php echo $c;?>" value="<?php echo array_sum($sum);?>">   				
    			</td>
    		</tr>
    		<?php
    		$c++;
    		}?> 
    	</tbody>		

    </table>

   

</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	
	function  show_price(id) {
		var user_width=$('.user_width_'+id).val();
		var user_length=$('.user_length_'+id).val();
		var total_width_len=parseFloat(user_width)*parseFloat(user_length);
		$('.total_size_'+id).html(total_width_len);
		var price_final=$('.price_final_'+id).val();
		var final_calc=parseFloat(total_width_len)*parseFloat(price_final);
		$('.total_price_'+id).html(final_calc.toFixed(2));
	}
</script>
</body>
</html>