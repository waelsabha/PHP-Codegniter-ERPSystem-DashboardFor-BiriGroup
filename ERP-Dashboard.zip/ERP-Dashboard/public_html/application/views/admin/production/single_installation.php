<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Single Installation Form </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Single Installation</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Single Installation Form</h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('Single_installation/submit_single_inst','class="myform" ','');?>

<input type="hidden" name="inst_id" value="<?php if(!empty($result[0]->si_id)){echo $result[0]->si_id;};?>">
<input type="hidden" name="edit_img" value="<?php if(!empty($result[0]->si_attachments)) {echo $result[0]->si_attachments;}?>">

   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>


<div class="row">
<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Project Name<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
<input type="text" name="prj_name" class="form-control" value="<?php if(!empty($result)){echo $result[0]->si_prj_name;};?>">
  <div class="form_error">  <?php echo $this->session->flashdata('schedule_date_installation');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Installation Type<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <select class="form-control" name="inst_type">
	<option>Choose</option>
	<option value="1" <?php if(!empty($result)){if($result[0]->si_ins_type=="1"){echo "selected=selected";}};?>">PO Based</option>
	<option value="2" <?php if(!empty($result)){if($result[0]->si_ins_type=="2"){echo "selected=selected";}};?>">Quotation Based</option>
	<option value="3" <?php if(!empty($result)){if($result[0]->si_ins_type=="3"){echo "selected=selected";}};?>">New Installation</option>
	
</select>
</div>
</div>
</div>
</div>
</div>
<!-----=====================table col-12 ends here===================---->

<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Installation Location<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type="text" name="inst_loc" class="form-control" value="<?php if(!empty($result)){echo $result[0]->si_ins_loc;};?>"">
 <div class="form_error">  <?php echo $this->session->flashdata('inst_loc');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Installation Date<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
 <?php
  if(!empty($result[0]->si_ins_date))
  $converted_date_delivry1 = date("d/m/Y", strtotime($result[0]->si_ins_date));
  ?>
  <input type='text' name="schedule_date_installation" class="form-control datetimepicker4"  value="<?php if(!empty($converted_date_delivry1)){echo  $converted_date_delivry1;};?>" required autocomplete="off" />

  <div class="form_error">  <?php echo $this->session->flashdata('schedule_date_installation');?></div>
</div>
</div>
</div>


</div>
<!-----=====================table col-12 ends here===================---->
<!-----=====================table col-12 starts here===================---->
 <div class="col-md-12 col-sm-12 table-rows-border">
 <div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Customer company<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <select data-plugin-selectTwo class='form-control populate' name="choose_customer" required="">

  <option value="">Choose</option>
  <?php
  foreach($customers as $cd)
  {
   ?>
  <option value="<?php echo $cd->sca_id;?>" <?php if((!empty($result[0]->si_cust_id))){if($result[0]->si_cust_id ==$cd->sca_id){echo "selected";}} ?> ><?php echo $cd->sca_cust_company;?> </option> 
   <?php
  }
  ?>
 </select>
 <div class="form_error">  <?php echo $this->session->flashdata('choose_customer');?></div>
</div>
</div>
</div>
 <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Customer not found? Click here</label>
<div class="col-md-8">
<label class="checkbox-inline">
   <input type="checkbox" name="add_cash_customer" value="1" <?php if(!empty($result)){if((empty($result[0]->st_customer_id))){echo "checked";}} ?>> Click to add customer
</label>
 <div class="form_error">  <?php echo $this->session->flashdata('add_cash_customer');?></div>
</div>
</div>


<div class="cash_cusotmer_details" <?php if(!empty($result)){ ?>style="display: show;"<?php }else{?>style="display: none;" <?php }?>>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Name <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type="text" class="form-control" value="<?php if(!empty($result[0]->si_cust_name)){echo $result[0]->si_cust_name;};?>" name="st_new_cust_name">
 <div class="form_error">  <?php echo $this->session->flashdata('st_new_cust_name');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Company <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type="text" class="form-control" value="<?php if(!empty($result[0]->si_cust_comp)){echo $result[0]->si_cust_comp;};?>" name="st_new_cust_comp">
 <div class="form_error">  <?php echo $this->session->flashdata('st_new_cust_comp');?></div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Mobile <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type="text" class="form-control" value="<?php if(!empty($result[0]->si_cust_mob)){echo $result[0]->si_cust_mob;};?>" name="st_new_cust_mobile">
 <div class="form_error">  <?php echo $this->session->flashdata('st_new_cust_mobile');?></div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Email <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type="text" class="form-control" value="<?php if(!empty($result[0]->si_cust_email)){echo $result[0]->si_cust_email;};?>" name="st_new_cust_email">
 <div class="form_error">  <?php echo $this->session->flashdata('st_new_cust_email');?></div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Landline</label>
<div class="col-md-8">
<input type="text" class="form-control" value="<?php if(!empty($result[0]->si_cust_landline)){echo $result[0]->si_cust_landline;};?>" name="st_new_cust_land">
 <div class="form_error">  <?php echo $this->session->flashdata('st_new_cust_land');?></div>
</div>
</div>
</div>

</div>

</div> 
<!-----=====================table col-12 ends here===================---->
<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">
<?php if(!empty($result[0]->si_labour))
{
  $labours_list=explode(',',$result[0]->si_labour);
}
;?>
<div class="col-md-4 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Labours <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<select data-plugin-selectTwo class='form-control populate' multiple="" name="choose_labour[]" required="">
  <option value="">Choose</option>
  <?php foreach($labour as $l)
  {
    if(!empty($result[0]->si_labour))
    {
?>
 <option value="<?php echo $l['ed_id'];?>" <?php if(!empty($result[0]->si_labour)){if(in_array($l['ed_id'], $labours_list)){echo "selected";}} ;?>><?php echo $l['ed_name'];?></option>
<?php
}
else
{
  ?>
  <option value="<?php echo $l['ed_id'];?>" ><?php echo $l['ed_name'];?></option>
  <?php
}
  }
  ?>
 </select>
 <div class="form_error">  <?php echo $this->session->flashdata('st_start_cordinate');?></div>
</div>
</div>
</div>
<?php if(!empty($result[0]->si_vehicle))
{
  $veh_list=explode(',',$result[0]->si_vehicle);
}
;?>
<div class="col-md-4 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Choose Vehicle<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select name="vehicle_choosed[]" data-plugin-selectTwo class='form-control populate' multiple="" required="">
    <option value="">Choose</option>
  <?php foreach($vehicle as $v)
  {
      if(!empty($result[0]->si_vehicle))
    {
?>
 <option value="<?php echo $v->veh_id;?>"  <?php if(!empty($result[0]->si_vehicle)){if(in_array($v->veh_id, $veh_list)){echo "selected";}} ;?> ><?php echo $v->veh_plate_no;?></option>
<?php
  }
  else
  {
    ?>
<option value="<?php echo $v->veh_id;?>" ><?php echo $v->veh_plate_no;?></option>
    <?php
  }
}
  ?>
  </select>
  <div class="form_error">  <?php echo $this->session->flashdata('st_end_cordinate');?></div>
</div>
</div>
</div>

<div class="col-md-4 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Choose Tools<abbr class="required">::*::</abbr>
</label>
<?php if(!empty($result[0]->si_tools))
{
  $tools_list=explode(',',$result[0]->si_tools);
}
;?>
<div class="col-md-8">
    <select data-plugin-selectTwo class='form-control populate' multiple="" name="choose_tools[]" class="form-control" required="">
    <option value="">Choose</option>
  <?php foreach($tools as $t)
  {
     if(!empty($result[0]->si_tools))
    {
?>
 <option value="<?php echo $t->tool_id;?>" <?php if(!empty($result[0]->si_tools)){if(in_array($t->tool_id, $tools_list)){echo "selected=selected";}} ;?>><?php echo $t->tool_name;?></option>
<?php
  }
  else
  {
    ?>
<option value="<?php echo $t->tool_id;?>" ><?php echo $t->tool_name;?></option>
    <?php
  }
}
  ?>
  </select>
  <div class="form_error">  <?php echo $this->session->flashdata('choose_tools');?></div>
</div>
</div>
</div>
</div>
<!-----=====================table col-12 ends here===================---->


<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Extra details/notes<abbr class="required">Not mandatory</abbr></label>
<div class="col-md-8">
<textarea name="st_additional_desc" class="form-control editors"><?php if(!empty($result[0]->si_notes)){echo $result[0]->si_notes;};?></textarea>

  <div class="form_error">  <?php echo $this->session->flashdata('st_additional_desc');?></div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="col-md-6">
<div class="form-group">

<label class="col-md-4 control-label" for="inputPlaceholder">Upload Files(customer logo/data sheets/any files. )<abbr class="required">Not mandatory</abbr></label>
<div class="col-md-8"><small>Please upload only jpeg,jpg,png,pdf files</small>
<input type="file" name="label_upload[]">
<input type="file" name="label_upload[]">
<input type="file" name="label_upload[]">
<input type="file" name="label_upload[]">
<input type="file" name="label_upload[]">
  <div class="form_error">  <?php echo $this->session->flashdata('notes');?></div>
</div>
</div>
</div>

  <div class="col-md-6">
    <p><b>Attachments </b>
      
        <?php if(!empty($result[0]->si_attachments))
        {
         echo "<br/>";
          $files_attached=explode(',',$result[0]->si_attachments);
          foreach($files_attached as $t)
          {
             $file_parts = pathinfo($t);
            if(($file_parts['extension']=="jpeg")||($file_parts['extension']=="jpg")||($file_parts['extension']=="png")||($file_parts['extension']=="PNG"))
            {
           
              echo "<img src='".base_url('/uploads/single_installation/').$t."' width='100' height='100' >";echo "<br/>";
            }
           ?>
           <a href="<?php echo base_url('uploads/single_installation/'.$t);?>" target="_blank"><?php echo $t;?></a><br/>
           <?php
          }
       }?></p>
  </div>

</div>
<div class="cell_text_data"></div>
<!-----=====================table col-12 ends here===================---->
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for details---->
<section class="panel panel-featured panel-featured-primary search_reuslt_type">
<header class="panel-heading">
<h2 class="panel-title">Choose Item</h2>
</header>
<div class="panel-body">

	<!-----=====================table col-12 starts here===================---->
	<div class="row">
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Search <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<small>Type a word or letter then press 'space' key</small>
<select data-plugin-selectTwo class='form-control populate' 
name='search_type_result'>
<option></option>
<?php
if(!empty($result[0]->si_ins_type) && ($result[0]->si_ins_type != '3'))
{
  if($result[0]->si_ins_type=='1')
  {
  foreach($main_result as $mr)
  {

    ?>
    <option value="<?php echo $mr->po_id;?>" <?php if($mr->po_id==$result[0]->si_item_choosed){echo "selected";}?>>PO Number #<?php echo $mr->po_id;?></option>
    <?php
  }
}
else
{
  foreach($main_result as $mr)
  {

    ?>
    <option value="<?php echo $mr->q_id;?>" <?php if($mr->q_id==$result[0]->si_item_choosed) {echo "selected";}?>><?php echo $mr->q_id;?> :: <?php echo $mr->q_sub;?></option>
    <?php
  }
}
  ?>

  <?php
}
?>
</select>
<div class="form_error">  <?php echo $this->session->flashdata('search_product_cat');?></div>
</div>
</div>
</div>

</div>
<!-----=====================table col-12 ends here===================---->

<!-------col-md-12------------------------>
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive"> 

</div>
</div>
<!-------end col-md-12----->
</div>

</section>


<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script type="text/javascript">
    function valueChanged()
    {
        if($('.instaltion_dept').is(":checked"))   
            $(".date_instalation").show();
        else
            $(".date_instalation").hide();
    }

</script>

<script type="text/javascript">
$(document).ready(function()
 {
 	  $("select[name='choose_customer']").change(function(){
    var cust_id=$(this).val();
      jQuery.ajax({
                     url:"<?php echo base_url().'Quotation_controller/get_customer_details';?>",
                    type:"post",
                     data:{"customer_id":cust_id},
                    success:function(result)
                    {
                      if(result)
                      {
                   var returndata = JSON.parse(result);
                        $('input[name="st_new_cust_name"]').val(returndata.sca_cust_name); 
                        $('input[name="st_new_cust_comp"]').val(returndata.sca_cust_company);  
                        $('input[name="st_new_cust_mobile"]').val(returndata.sca_cust_mobile);  
                        $('input[name="st_new_cust_email"]').val(returndata.sca_cust_email);  
                        $('input[name="st_new_cust_land"]').val(returndata.sca_cust_landline);   
                        $('.cash_cusotmer_details').show();
                      }
                    }
                 });        
  });

 	  $('input[name="add_cash_customer"]').on("click",function(){
  if($(this).is(':checked'))
  {
    $('input[name="add_cash_customer"]').val('1');
//console.log('checked box');
$('.cash_cusotmer_details').show();

  }
  else
  {
    //console.log('unchecked box');
    $('.cash_cusotmer_details').hide();
  }

});


   $("select[name='inst_type']").change(function(){
    var inst_type_id=$(this).val();
    if(inst_type_id==3)
    {
$('.search_reuslt_type').hide();
    }
    else
    {
    	$('.search_reuslt_type').show();
     jQuery.ajax({
                     url:"<?php echo base_url().'Single_installation/get_installation_type';?>",
                    type:"post",
                     data:{"instal_type":inst_type_id},
                    success:function(result)
                    {
                      if(result)
                      {
            var returndata = JSON.parse(result);
  $('select[name="search_type_result"]').empty().append("<option>Choose Value</option>");    
  if(inst_type_id==1)
      		{
       //console.log(val2); 
    $.each(returndata, function(key2,val2)
      {  
    $('select[name="search_type_result"]').append("<option value="+val2['po_id']+">"+"PO Number #"+val2['po_id']+"</option>");
     });
  			}
  			else if(inst_type_id==2)
  			{
  				 $('select[name="search_type_result"]').empty().append("<option>Choose Value</option>");    
  	$.each(returndata, function(key2,val2)
      {  		
  			//	alert('inside 12');				
  	$('select[name="search_type_result"]').append("<option value="+val2['q_id']+">#"+val2['q_id']+"::"+val2['q_sub']+"</option>");
  	});
  			}
  			else
  			{
  				$('.search_reuslt_type').hide();
  			}
     
                      }
                    }
                 }); 
         }       
 	});


    $("select[name='search_type_result']").change(function(){
    var result_type_id=$(this).val();
    var value_type=$("select[name='inst_type']").val();
      jQuery.ajax({
                     url:"<?php echo base_url().'Single_installation/get_items_details';?>",
                    type:"post",
                     data:{"result_type_id":result_type_id,"value_type":value_type},
                    success:function(result)
                    {
                      if(result)
                      {
                     // 	console.log(result);
            $('.table-responsive').html(result);
                      }
                    }
                 });        
 		 });


  });  
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
   <script type="text/javascript">
          $(function () {
              $('.datetimepicker4').datepicker({format: 'dd/mm/yyyy' });
             // $(".datetimepicker4").datepicker();
              //  $('.datetimepicker4').datepicker({ dateFormat: 'dd/mm/yyyy' }).datepicker();
            });
        </script>
</body>

</html>