<section class="panel">
<header class="panel-heading">
<h2 class="panel-title" style="color: red;">List Need Approve</h2>
</header>

<div class="panel-body">
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
	<th>Product Name</th>	
	<th>SKU/Code</th>	
	<th>Purchase Price(Old)</th>
	<th>Purchase Price(NEW)</th>

	
	 <th>Old added value</th>
	<th>NEW added value</th>
	<th>Old Shipping Value</th>
	<th>NEW Shipping Value</th>
	<th>OLD Suggusted Web Price</th>
	<th>NEW Suggusted Web Price</th> 
	<th>Action</th>
</tr>
</thead>
<tbody class="data_item_req">
<?php

$i=1;
foreach($resulttoapprove as $index1=>$t)
{

?>

			
			<td><?php echo $t['pname'];?></td>
			<td><?php echo $t['pcode'];?><br/></td>
			<td><?php echo $t['old_purchase_price'];?> AED</td>
			<td><?php echo $t['new_purchase_price'];?> AED</td>
			<td><?php echo $t['added_calc_val_old'];?> AED</td>
			<td><?php echo $t['added_calc_val_new'];?> AED</td>
			<td><?php echo $t['shipping_calc_val_old'];?> AED</td>
			<td><?php echo $t['shipping_calc_val_new'];?> AED</td>
		
			<td><?php echo $t['webprice_aed_old'];?> (AED) <br/><b>  </b> <?php echo $t['webprice_GBP_old'];?> (GBP)</td>

		<td><?php echo $t['webprice_aed_new'];?> (AED) <br/><b>  </b> <?php echo $t['webprice_GBP_new'];?> (GBP)</td>
			



			<td>


				<?php
				if(($this->session->userdata['user']['main_dept']=="Main")||($this->session->userdata['user']['log_designation']=="Team-lead"))
				{   	
  ?>	
<div class="dropdown-primary dropdown">
<button class="btn btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >Action</button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">
 

 

<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('Item_costing/product_purchase_approve/'.$t['pid']);?>" ><i class="fa fa-star"></i>Accept</a>
<div class="dropdown-divider"></div>

<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('Item_costing/product_purchase_decline/'.$t['pid']);?>"><i class="fa fa-trash"></i>Reject</a>
<div class="dropdown-divider"></div>




</div>
</div>
<?php }?>

</td>

</tr>
<!-- Button trigger modal 2-->


<!------------modal view quotation ends----------->


<?php 
}

?>



</tbody>
</table>
</div>
<!------------closing the section-panel here------------->
</div>
</section>