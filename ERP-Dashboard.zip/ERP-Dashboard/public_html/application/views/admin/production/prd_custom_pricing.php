<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Customize Price </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Customize Price</span></li>
<li><span>Price</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<section class="panel">
<header class="panel-heading">

<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Products Customize Pricing</h2>
<small>Here you will be Customize pricing as per the options you need</small>
</header>
<div class="panel-body">

<div class="row">

<!-----=====================table col-12 starts here===================---->
<h4>Choose from groups</h4>
<div class="form-group">
	  

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6">
	<div class="form-group base_name">
		<label class="col-md-4 control-label" for="inputPlaceholder">Choose Base Name: </label>
		<div class="col-md-8">
		<select name="select_prd" class="form-control">
			<option value=""></option>
			<?php
			foreach($base as $index=>$b)
    		{
    		//	pre_list($b);
    			?>
    			<option value="<?php echo $b->pps_final_price;?>"><?php echo $b->pps_name;?></option>
    			<?php
    		}
    		?>
		</select>
	</div>
	</div>
</div>

<div class="col-md-6">
	<div class="form-group">
		<label class="col-md-4 control-label" for="inputPlaceholder">Choose Reflective Name: </label>
		<div class="col-md-8">
	<select name="select_reflective" class="form-control">
			<option value=""></option>
			<?php
			foreach($reflective as $index=>$r)
    		{
    			?>
    			<option value="<?php echo $r->pps_final_price;?>"><?php echo $r->pps_name;?></option>
    			<?php
    		}
    		?>
		</select>
	</div>
	</div>
</div>

<div class="col-md-6">
	<div class="form-group">
		<label class="col-md-4 control-label" for="inputPlaceholder">Choose Printing Name: </label>
		<div class="col-md-8">
	<select name="select_printing" class="form-control">
			<option value=""></option>
			<?php
			foreach($printing as $index=>$pr)
    		{
    			?>
    			<option value="<?php echo $pr->pps_final_price;?>"><?php echo $pr->pps_name;?></option>
    			<?php
    		}
    		?>
		</select>
	</div>
	</div>
</div>

<div class="col-md-6">
	<div class="form-group">
		<label class="col-md-4 control-label" for="inputPlaceholder">Choose Channel Name: </label>
		<div class="col-md-8">
	<select name="select_channel" class="form-control">
			<option value=""></option>
			<?php
			foreach($channels as $index=>$ch)
    		{
    			?>
    			<option value="<?php echo $ch->pps_final_price;?>"><?php echo $ch->pps_name;?></option>
    			<?php
    		}
    		?>
		</select>
	</div>
	</div>
</div>

<div class="col-md-6">
	<div class="form-group">
		<label class="col-md-4 control-label" for="inputPlaceholder">Choose Paint Name: </label>
		<div class="col-md-8">
			<select name="select_painting" class="form-control">
			<option value=""></option>
			<?php
			foreach($painting as $index=>$paint)
    		{
    			?>
    			<option value="<?php echo $paint->pps_final_price;?>"><?php echo $paint->pps_name;?></option>
    			<?php
    		}
    		?>
		</select>
	</div>
	</div>
</div>

<div class="col-md-6">
	<div class="form-group">
		<label class="col-md-4 control-label" for="inputPlaceholder">Choose Powder Coating Name: </label>
		<div class="col-md-8">
			<select name="select_powder_coating" class="form-control">
			<option value=""></option>
			<?php
			foreach($powder_coating as $index=>$pow)
    		{
    			?>
    			<option value="<?php echo $pow->pps_final_price;?>"><?php echo $pow->pps_name;?></option>
    			<?php
    		}
    		?>
		</select>
	</div>
	</div>
</div>
	

</div>

</div><hr/>
<!-----=====================table col-12 ends here===================---->

<!-----=====================table col-12 starts here===================---->
<h4>Group Created</h4>
<div class="form-group">
					
	<div class="col-md-12 col-sm-12 table-rows-border">				
	
	<div class="col-md-4">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Product Name <abbr class="required">::*::</abbr></label><br/>
		<span class="grp_name"></span>
		 
	</div>
	</div>
	
	<div class="col-md-2">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Width (in meter) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="width_user"  class="form-control ">
		 
	</div>
	</div>
	
	<div class="col-md-2">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Length (in meter) <abbr class="required">::*::</abbr></label>
		 <input type="text" name="length_user"  value=""  class="form-control">
		 
	</div>
	</div>
	
	<div class="col-md-2">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Total Size <abbr class="required">::*::</abbr></label><br/>
		<b> <span class="total_size"></span></b>
	</div>
	</div>

	<div class="col-md-2">
	<div class="form-group">
		<label class="control-label" for="inputPlaceholder">Final Price<abbr class="required">::*::</abbr></label><br/>
		<!--<small>for calculation : use (price*% added)</small>-->
		<b> <span class="final_price"></span></b>
		 
	</div>
	</div>
		</div>	

			

			
</div><hr/>
<div class="col-md-12 col-sm-12 table-rows-border" style="text-align: center;">		
	<button onclick="get_custom_pricing()" type="button" class="btn btn-sm btn-info"> Get customized pricing</button>
</div>
<!-----=====================table col-12 ends here===================---->
</div>	

</div>

</section>

</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
$(document).ready(function(){

	$('select[name="select_prd"]').on('change',function(){
		console.log($(this).find("option:selected").text());
		console.log($(this).find("option:selected").val());
	});

	$('select[name="select_reflective"]').on('change',function(){
		console.log($(this).find("option:selected").text());
		console.log($(this).find("option:selected").val());

	});

	$('select[name="select_printing"]').on('change',function(){
		console.log($(this).find("option:selected").text());
		console.log($(this).find("option:selected").val());

	});

	$('select[name="select_channel"]').on('change',function(){
		console.log($(this).find("option:selected").text());
		console.log($(this).find("option:selected").val());

	});

	$('select[name="select_painting"]').on('change',function(){
		console.log($(this).find("option:selected").text());
		console.log($(this).find("option:selected").val());

	});

		$('select[name="select_powder_coating"]').on('change',function(){
		console.log($(this).find("option:selected").text());
		console.log($(this).find("option:selected").val());

	});

});

function get_custom_pricing()
{
	if($('select[name="select_prd"]').find("option:selected").text()!='')
		{
			var prd_name=$('select[name="select_prd"]').find("option:selected").text();
			var prd_price=$('select[name="select_prd"]').find("option:selected").val();
		}
	else
	{
		var prd_name='';var prd_price='0';
	}

	if($('select[name="select_reflective"]').find("option:selected").text()!='')
	{
		var ref_name=$('select[name="select_reflective"]').find("option:selected").text();
		var ref_price=$('select[name="select_reflective"]').find("option:selected").val();
	}
	else
	{
		var ref_name='';var ref_price='0';
	}
	
	if($('select[name="select_printing"]').find("option:selected").text()!='')
	{
		var print_name=$('select[name="select_printing"]').find("option:selected").text();
		var print_price=$('select[name="select_printing"]').find("option:selected").val();
	}
	else
	{
		var print_name='';var print_price='0';
	}

	if($('select[name="select_channel"]').find("option:selected").text()!='')
	{
		var ch_name=$('select[name="select_channel"]').find("option:selected").text();
		var ch_price=$('select[name="select_channel"]').find("option:selected").val();
	}
	else
	{
		var ch_name='';var ch_price='0';
	}

	if($('select[name="select_painting"]').find("option:selected").text()!='')
	{
		var  paint_name=$('select[name="select_painting"]').find("option:selected").text();
		var paint_price=$('select[name="select_painting"]').find("option:selected").val();
	}
	else
	{
		var paint_name='';var paint_price='0';
	}

	if($('select[name="select_powder_coating"]').find("option:selected").text()!='')
	{
		var  pow_name=$('select[name="select_powder_coating"]').find("option:selected").text();
		var pow_price=$('select[name="select_powder_coating"]').find("option:selected").val();
	}
	else
	{
		var pow_name='';var pow_price='0';
	}


	

	$('.grp_name').html(prd_name+' '+ref_name+' '+print_name+' '+ch_name+' '+paint_name+' '+pow_name);
	
	var width_user=$('input[name="width_user"]').val();
	var length_user=$('input[name="length_user"]').val();

	var total_size=parseFloat(width_user)*parseFloat(length_user);
	$('.total_size').html(total_size);

	var prices_total=parseFloat(prd_price)+parseFloat(ref_price)+parseFloat(print_price)+parseFloat(ch_price)+parseFloat(paint_price)+parseFloat(pow_price);

	var total_price=parseFloat(prices_total)*parseFloat(total_size);

	$('.final_price').html(total_price.toFixed(2));

}

</script>

</body>
</html>