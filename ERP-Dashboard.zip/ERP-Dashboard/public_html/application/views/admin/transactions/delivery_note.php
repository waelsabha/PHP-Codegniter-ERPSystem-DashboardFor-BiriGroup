<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" 
type="text/css"/>
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" 
type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
table input.form-control {
  width: auto;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">
<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Transactions </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Sales</span></li>
<li><span>Delivery Note</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Issue Delivery Note </h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('Delivery_note/submit_delivery_note','class="myform" novalidate','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
 <input type="hidden" name="inv_id" value="<?php if(!empty($result[0]->dn_id)){echo $result[0]->dn_id;};?>">
  <input type="hidden" name="files_added" value="<?php if(!empty($result[0]->dn_attachments)){echo $result[0]->dn_attachments;};?>">
<input type="hidden" name="page_type" value="<?php if(!empty($page_type)){echo $page_type;};?>">

   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

<div class="row">

 <div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Doc No <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<input type="text" name="dn_doc_no" value="<?php if(!empty($result)){if(!empty($result[0]->dn_doc_no)){echo $result[0]->dn_doc_no;}}else{echo $doc_num;}?>" readonly class="form-control">
  <input type="hidden" name="sales_inv_id" >
 <div class="form_error">  <?php echo $this->session->flashdata('si_doc_no');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Date<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
   <?php
  if(!empty($result[0]->dn_date))
  $converted_date = date("m/d/Y", strtotime($result[0]->dn_date));
  ?>
 <input type='text' readonly="" name="dn_date" class="form-control datetimepicker4" value="<?php if(!empty($result[0]->dn_date)){echo $converted_date;}else{ echo date('m/d/Y');} ;?>" required />
  <div class="form_error">  <?php echo $this->session->flashdata('dn_date');?></div>

</div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Customer<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="dn_customer_acc_id" required="">
  <option value="">Choose</option>
 <?php
foreach($customers as $cb)
{
//pre_list($cb);
?>
<option value="<?php echo $cb->id;?>" <?php if(!empty($result[0]->dn_customer_acc_id)){if($result[0]->dn_customer_acc_id==$cb->id){echo "selected";}};?> ><?php echo $cb->label;?></option>
<?php
}
?>
 </select>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
  <div class="form-group">
<a type="button" class="btn btn-warning pull-left mb-xs mt-xs mr-xs modal-sizes" onclick="load_sales_inv();" href="#modalmd_sinv">Load all sales Invoice</a>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Warehouse<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
    <select data-plugin-selectTwo  class="form-control populate" name="dn_warehouse" required="">
  <option value="">Choose</option>
 <?php
foreach($warehouse_data as $wd)
{
//pre_list($cb);
?>
<option value="<?php echo $wd->mw_id;?>" <?php if(!empty($result[0]->dn_warehouse)){if($result[0]->dn_warehouse==$wd->mw_id){echo "selected";}};?> ><?php echo $wd->mw_name;?></option>
 
<?php
}
?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('dn_warehouse');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12 ">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Salesman<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="dn_salesman" required="">
  <option value="">Choose</option>
  <?php
$data_salesman=array_filter($salesman);
foreach($data_salesman as $sm)
{
  ?>
   <option value="<?php echo $sm[0]->ed_id;?>" <?php if(!empty($result[0]->dn_salesman)){if($result[0]->dn_salesman==$sm[0]->ed_id){echo "selected";}};?>> <?php echo $sm[0]->ed_name;?> </option> 
  <?php
}
?>
 </select>
 
  <div class="form_error">  <?php echo $this->session->flashdata('dn_salesman');?></div>
</div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Narration
</label>
<div class="col-md-8">
  <textarea class="form-control" name="dn_narration" required=""><?php if(!empty($result[0]->dn_narration)){echo $result[0]->dn_narration;};?></textarea>
  <div class="form_error">  <?php echo $this->session->flashdata('dn_narration');?></div>
</div>
</div>
</div>


<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Payment Type<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="dn_payment_type">
  <option value="">Choose</option>
 <?php
 foreach($payment_method as $pm)
 {?>
  <option value="<?php echo $pm->mpm_id;?>" <?php if(!empty($result[0]->dn_payment_type)){if($result[0]->dn_payment_type==$pm->mpm_id){echo "selected";}};?>> <?php echo $pm->mpm_name;?></option> 
  <?php
}?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('dn_payment_type');?></div>
</div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Ship Contact
</label>
<div class="col-md-8">
 <input type='text' name="dn_shipping_contact"  class="form-control" value="<?php if(!empty($result[0]->dn_shipping_contact)){echo $result[0]->dn_shipping_contact;};?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('dn_shipping_contact');?></div>
</div>
</div>
</div>

<!-- <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Project
</label>
<div class="col-md-8">
 <input type='text' name="date_ref" class="form-control" value=""  />
  <div class="form_error">  <?php echo $this->session->flashdata('date_ref');?></div>
</div>
</div>
</div>
 -->
<div class="col-md-6 col-sm-12 ">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Delivery Address
</label>
<div class="col-md-8">
 <input type='text' name="dn_delivery_address"  class="form-control" value="<?php if(!empty($result[0]->dn_delivery_address)){echo $result[0]->dn_delivery_address;};?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('dn_delivery_address');?></div>
</div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Mark
</label>
<div class="col-md-8">
 <input type='text' name="dn_mark"  class="form-control" value="<?php if(!empty($result[0]->dn_mark)){echo $result[0]->dn_mark;};?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('dn_mark');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12 ">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Customer Contact<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
 <input type='text' name="dn_contact" class="form-control" value="<?php if(!empty($result[0]->dn_contact)){echo $result[0]->dn_contact;};?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('dn_contact');?></div>
</div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12 ">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> LPO Number<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
  <input type='text' name="dn_lpo_no" class="form-control" value="<?php if(!empty($result[0]->dn_lpo_no)){echo $result[0]->dn_lpo_no;};?>"  />
 <div class="form_error">  <?php echo $this->session->flashdata('dn_lpo_no');?></div>

</div>
</div>
</div>

<div class="col-md-6 col-sm-12 ">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Bill No<abbr class="required">::*::</abbr>
<!----same as the invoice number,should appear here -->
</label>
<div class="col-md-8">
  <input type='text' name="dn_bill_no" class="form-control" value="<?php if(!empty($result[0]->dn_bill_no)){echo $result[0]->dn_bill_no;};?>"  />
 <div class="form_error">  <?php echo $this->session->flashdata('dn_bill_no');?></div>

</div>
</div>
</div>


</div>

<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Place of Supply
</label>
<div class="col-md-8">
   <select data-plugin-selectTwo  class="form-control populate" name="dn_plc_supply">
  <option value="">Choose</option>
 <?php
 foreach($place_supply as $ps)
 {?>
  <option value="<?php echo $ps->mw_id;?>" <?php if(!empty($result[0]->dn_plc_supply)){if($result[0]->dn_plc_supply==$ps->mw_id){echo "selected";}};?>> <?php echo $ps->mps_name;?></option> 
  <?php
}?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('dn_plc_supply');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Jurisdiction
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="dn_jurisdiction">
  <option value="">Choose</option>
 <?php
 foreach($place_supply as $ps)
 {?>
  <option value="<?php echo $ps->mw_id;?>" <?php if(!empty($result[0]->dn_jurisdiction)){if($result[0]->dn_jurisdiction==$ps->mw_id){echo "selected";}};?> > <?php echo $ps->mps_name;?></option> 
  <?php
}?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('dn_jurisdiction');?></div>
</div>
</div>
</div>

</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Currency Name<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="dn_currency">
  <option value="">Choose</option>
   <?php
  foreach($currency_convt as $cv)
  {
    ?>
 <option value="<?php echo $cv->currency_name;?>" <?php if(!empty($result[0]->dn_currency)){if($result[0]->dn_currency==$cv->currency_name){echo "selected";}}else{if($page_type=='ksa'){if($cv->currency_name=="SAR"){echo "selected";}} else{if($cv->currency_name=="AED"){echo "selected";}} };?>> <?php echo $cv->currency_name;?> </option> 
    <?php
  }
  ?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('dn_currency');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12" >
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Currenct Conv.<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
 <input type='text' name="dn_conv_value" readonly="" class="form-control" value="<?php if(!empty($result[0]->dn_conv_value)){echo $result[0]->dn_conv_value;}else{echo "1";};?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('dn_conv_value');?></div>
</div>
</div>
</div>

</div>
<!-- 
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
  <p>Upload files here.Make sure the file size is less than 2MB.</p>
 <input class="form-control" name="files[]" type="file"  multiple  required />
 <div class="form_error">  <?php echo $this->session->flashdata('files[]');?></div>
</div> 
</div>
<?php
if(!empty($result[0]->dn_attachments))
{
  echo "<h4> FILES UPLOADED :</h4>";
  $files_are=explode(',',$result[0]->dn_attachments);
  foreach($files_are as $fr)
  {
    echo "<a href='".base_url("uploads/sales_invoice/".$fr)."' target='_blank'>".$fr."</a><br/>";
  }
}
else{}  
?>
  -->
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive">
<table class="table table-border table-rows-border">
  <thead>
    <th>Item</th>
       <th>Units</th>
      <th>Quantity</th>
       <th>Link-1</th>
       <th>Rate</th>
        <th>Gross</th>
         <th>Addl. Charges</th>
         <th>FNet</th>
        <!--  <th>Cogs</th> -->
         <th>Vat</th>
        <!--  <th>Delivery Date</th>        
         <th>Tax Code</th> -->
         <th></th>
  </thead>
  <tbody class="new_rows all_table_rows" >
   
     <?php
    if(!empty($result[0]))/////used in update value
    {
      $prd_added=explode('|#|',$result[0]->dn_product);

       $prd_units=explode('|#|',$result[0]->dn_units);

      $qnty_added =explode('|#|',$result[0]->si_qnt_to_deliver);
      $sum_qnty=array_sum($qnty_added);

      $rate_added=explode('|#|',$result[0]->si_rate);
         $sum_rate=array_sum($rate_added);

      $gross_added=explode('|#|',$result[0]->dn_gross);
         $sum_gross=array_sum($gross_added);

      $add_charges_added=explode('|#|',$result[0]->dn_add_charges);
         $sum_add_charges=array_sum($add_charges_added);

       $fnet_added=explode('|#|',$result[0]->dn_fnet);
       $sum_fnet=array_sum($fnet_added);

       // $cogs_added=explode('|#|',$result[0]->dn_cogs);

      $vat_added=explode('|#|',$result[0]->dn_vat);
         $sum_vat=array_sum($vat_added);

      // $delivery_date_added=explode('|#|',$result[0]->dn_delivery_date);
      // $taxcode_added=explode('|#|',$result[0]->dn_tax_code);
       $total_count_rows=count($prd_added);
       $ik=1;
   foreach($prd_added as $ca_index=>$pa)
      {
?>
<tr>
  <td>
    <input type="text" name="dn_product[]"  value="<?php if(!empty($pa)){echo $pa;}else{echo "0";};?>"  step="any"  class="form-control qnyt_dt qnty<?php echo $ik;?>"> 
  </td>
  <td><input type="text" name="dn_units[]"  value="<?php if(!empty($prd_units[$ca_index])){echo $prd_units[$ca_index];}else{echo "0";};?>"  step="any"  class="form-control qnyt_dt qnty<?php echo $ik;?>"> </td>

     <td><input type="number" name="dn_qnty[]" onchange="calc_gross(<?php echo $ik;?>);" onkeyup="calc_gross(<?php echo $ik;?>);" value="<?php if(!empty($qnty_added[$ca_index])){echo $qnty_added[$ca_index];}else{echo "0";};?>"  step="any"  class="form-control qnyt_dt qnty<?php echo $ik;?>"> </td>



      <td><input type="number" name="dn_label[]" value="<?php if(!empty($qnty_added[$ca_index])){echo $qnty_added[$ca_index];}else{echo "0";};?>"  step="any"  class="form-control qnyt_dt qnty<?php echo $ik;?>"> </td>

    <td><input type="number" name="dn_rate[]" onchange="calc_gross(<?php echo $ik;?>)" onkeyup="calc_gross(<?php echo $ik;?>)"  value="<?php if(!empty($rate_added[$ca_index])){echo $rate_added[$ca_index];}else{echo "0";};?>" step="any"  class="form-control rate_dt rate<?php echo $ik;?>"> </td>

    <td><input type="number" name="dn_gross[]" value="<?php if(!empty($gross_added[$ca_index])){echo $gross_added[$ca_index];}else{echo "0";};?>" step="any"  readonly="" class="form-control gross_dt gross<?php echo $ik;?>"></td>

    <td><input type="number"  name="dn_add_charges[]" value="<?php if(!empty($add_charges_added[$ca_index])){echo $add_charges_added[$ca_index];}else{echo "0";};?>"  onchange="calc_gross(<?php echo $ik;?>)" onkeyup="calc_gross(<?php echo $ik;?>)" step="any"  class="form-control add_charges_dt addchrg<?php echo $ik;?>"> 
    </td>

    <td><input type="number" name="dn_fnet[]"  value="<?php if(!empty($fnet_added[$ca_index])){echo $fnet_added[$ca_index];}else{echo "0";};?>"  step="any"  readonly="" class="form-control fnet_dt fnet<?php echo $ik;?>"></td>
    <td>
      <?php
     $fent_with_vat=$fnet_added[$ca_index]*($vat_added[$ca_index]/100);
    $tot_fnet_vat=$fent_with_vat+$fnet_added[$ca_index];
      ?>
      <!------hidden field--->
       <input type="hidden" name="vat_fnet_val[]"  value="<?php if(!empty($tot_fnet_vat)){echo $tot_fnet_vat;};?>" class="form-control vat_fnet_val<?php echo $ik;?>"> 
        <input type="hidden" name="vat_each_prd[]"  value="0" class="form-control vat_each_prd_val<?php echo $ik;?>">
         <!------hidden field--->

    <!--   <input type="number" name="dn_cogs[]" value="<?php if(!empty($cogs_added[$ca_index])){echo $cogs_added[$ca_index];}else{echo "0";};?>"  step="any" readonly="" class="form-control vat_dt vat<?php echo $ik;?>"> </td> -->
     
      <td><input type="text"  name="dn_vat[]" class="form-control datetimepicker5" value="<?php if(!empty($vat_added[$ca_index])){echo $vat_added[$ca_index];}else{echo "0";};?>"> </td>

      <?php
 if(!empty($delivery_date_added[$ca_index]))
  $converted_dlvry_date = date("m/d/Y", strtotime($delivery_date_added[$ca_index]));
?>
   <!--  <td><input type="text"  name="dn_delivery_date[]" class="form-control datetimepicker5" value="<?php if(!empty($delivery_date_added[$ca_index])){echo $converted_dlvry_date;};?>"> </td>

    <td><input type="text"  name="dn_tax_code[]" readonly="" value="<?php if(!empty($taxcode_added[$ca_index])){echo $taxcode_added[$ca_index];};?>" class="form-control"> </td> -->
    <td></td>


    </tr>
<?php
   $ik++;
      }
  }
  else////for adding new , for new inovices///////////////
  {
    ?>
        
   <!--  <tr>
  <td>
    <input type="text" name="dn_product[]" class="form-control">
    </td>
  <td><input type="number" name="dn_units[]"  value="0"  step="any"  class="form-control qnyt_dt qnty1"> </td>
    <td><input type="number" name="dn_qnty[]" onchange="calc_gross('1');" onkeyup="calc_gross('1');" value="0"  step="any"  class="form-control qnyt_dt qnty1"> </td>
     <td><input type="number" name="dn_link_1[]" value="0"  step="any"  class="form-control qnyt_dt qnty1"> </td>
     <td><input type="number" name="dn_rate[]" onchange="calc_gross('1')" onkeyup="calc_gross('1')"  value="0" step="any"  class="form-control rate_dt rate1"> </td>
    <td><input type="number" name="dn_gross[]" value="0" step="any"  readonly="" class="form-control gross_dt gross1"></td>

    <td><input type="number"  name="dn_add_charges[]" value="0"  onchange="calc_gross('1')" onkeyup="calc_gross('1')" step="any"  class="form-control add_charges_dt addchrg1"> </td>

    <td><input type="number" name="dn_fnet[]"  value="0"  step="any"  readonly="" class="form-control fnet_dt fnet1"></td>
    <td><input type="number" name="dn_cogs[]"  value="0"  step="any"  readonly="" class="form-control fnet_dt fnet1"></td>

    <td>
       <input type="hidden" name="vat_fnet_val[]"  value="0" class="form-control vat_fnet_val1">
      <input type="hidden" name="vat_each_prd[]"  value ="0" class="form-control vat_each_prd_val1">
      <input type="number" name="dn_vat[]" value="5"  step="any" readonly="" class="form-control vat_dt vat1"> </td>

    <td><input type="text"  name="dn_delivery_date[]" class="form-control datetimepicker5"> </td>
     <td><input type="text"  name="dn_tax_code[]" readonly="" value="0" class="form-control"> </td>
    <td></td>
    </tr> -->
   
    <?php
  }?>
  
<!--  <button type="button" class="btn btn-primary pull-right" onclick="add_more_row();">Add More</button>  -->
  </tbody>
</table>
<p style="color: red;"  class="error_result"></p>
</div>
</div>

   <!-----for input tyype hidden fields------------->
    <input type="hidden" name="hi_prd_id" class="form-control"> 
     <input type="hidden" name="hi_unit" class="form-control"> 
      <input type="hidden" name="hi_label" class="form-control"> 
    <input type="hidden" name="hi_qnty"  value="0"  class="form-control"> 
    <input type="hidden" name="hi_rate"   value="0" class="form-control"> 
    <input type="hidden" name="hi_gross"  value="0"  class="form-control">  
    <input type="hidden" name="hi_add_charges" value="0"  class="form-control">
 
    <input type="hidden" name="hi_fnet"  value="0" class="form-control"> 
     <!--  <input type="hidden" name="hi_cogs"  value="0" class="form-control">  -->
    <input type="hidden" name="hi_vat"  value="0" class="form-control"> 
<!--    <input type="hidden" name="hi_delivery_date" class="form-control datetimepicker5"> 
   <input type="hidden" name="hi_tax_code"  value="0" class="form-control">  -->

    <!---------end for input type hidden--->

<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
<div class="col-md-8">
  <span class="num_items">
    <?php
if(!empty($result[0]))
 {
     if(!empty($total_count_rows))
      {
        echo $total_count_rows;
      }
     else
    {
      echo "1";
    }
}
  else
  {
    echo "1";
  }
  ?>
  </span>
</div>
</div>
<!----------end col-md-12----------------------------->

<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12 ">
  <label class="col-md-4 control-label" for="inputPlaceholder">Total Quantity:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="qnty_tot_button" name="dn_tot_qnty" required="required" value="<?php if(!empty($sum_qnty)){echo $sum_qnty;}else{echo "0";};?>">
</div>
</div>
<!----------end col-md-12----------------------------->
<!-------start col-md-12------------------->
<div class="col-md-6 col-sm-12 ">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total Gross:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="gross_tot_button" name="dn_tot_gross" required="required" value="<?php if(!empty($sum_gross)){echo $sum_gross;}else{echo "0";};?>">
</div>
</div>
</div>
<!----------end col-md-12----------------------------->
<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total Additional Charges:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="add_charges_tot_button" name="dn_tot_add_charges" required="required" value="<?php if(!empty($sum_add_charges)){echo $sum_add_charges;}else{echo "0";};?>">
</div>
</div>
<!----------end col-md-12----------------------------->


<!-------start col-md-12------------------->
<div class="col-md-6 col-sm-12 ">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total Fnet:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="fnet_tot_button" name="dn_tot_fnet" required="required" value="<?php if(!empty($sum_fnet)){echo $sum_fnet;}else{echo "0";};?>">
</div>
</div>
</div>
<!----------end col-md-12----------------------------->
<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<!-------start col-md-12------------------->
<!-- <div class="col-md-6 col-sm-12 ">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total Cogs:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="cogs_tot_button" name="dn_tot_cogs" required="required" value="<?php if(!empty($sum_fnet)){echo $sum_fnet;}else{echo "0";};?>">
</div>
</div> -->
<!---------end col-md-12----------------------------->
<!-------start col-md-12------------------->
<div class="col-md-6 col-sm-12 table-rows-border">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total VAT Charges:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="vat_tot_button" name="dn_tot_vat" required="required" value="<?php if(!empty($si_tot_vat_amount)){echo $si_tot_vat_amount;}else{echo "0";};?>">
</div>
</div>
</div>
<!----------end col-md-12----------------------------->
<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
    <button class="btn btn-primary" type="button" onclick="get_amount_total()">Click to - Calculate total quantity</button>
  <br/> 
  <label class="col-md-4 control-label amount_text" for="inputPlaceholder">Amount Total:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="amount_tot_button" name="dn_tot_amount" required="required" value="<?php if(!empty($result[0]->si_tot_amount)){echo $result[0]->si_tot_amount;}else{echo "0";};?>">
  <small>Amount as per the currency rate selected</small>
</div>
</div>
<!----------end col-md-12----------------------------->

<!-----div starts here for non-inquiry--->
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for non-inquiry--->
<!-----div starts here for non-inquiry--->
 <!-- Button trigger modal for sales invoice-->
 <div id="modalmd_sinv" class="modal-block modal-block-lg mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">All Invoices </h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text modal_content_sinv">
   
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button"   class="btn btn-primary confirm_btn_modal">Confirm</button>
<button class="btn btn-default modal-dismiss modal-close-btn">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal--->
<!----div closes here--->
<div class="cell_text_data"></div>

<div class="col-sm-9 col-sm-offset-3">
  
<button type="submit" class="submit_btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default" onclick="check_for_reset()">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>


</section>
</div>
</section>


<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
<a href="#" class="mobile-close visible-xs">
Collapse <i class="fa fa-chevron-right"></i>
</a>
<div class="sidebar-right-wrapper">

<div class="sidebar-widget widget-friends ">

<div class="chat_window">
<?php $this->load->view('admin/master_essential/chat_data',$chat);?>

</div>
</div>



</div>
</div>
</div>
</aside>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
 <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript">
  </script>

  <script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

  
  <script>
            $(document).on('ready', function () {
              $('input').attr('autocomplete','off');
                $("#file-1").fileinput();
                });
                  </script>
   
 <script>
    tinymce.init({
      selector : '.editors',
        plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
    });
   </script>
   
<script type="text/javascript">
 

  function table(id)
  {
    $('table tbody .table'+id).remove();
    var rowcount = $('table tbody tr').length;
    $(".num_items").html(rowcount);
  }

</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker();
            });

           $(function () {
            var date2 = $('.datetimepicker4').datepicker('getDate', '+1d'); 
  date2.setDate(date2.getDate()+1); 
                $('.datetimepicker5').datepicker().datepicker("setDate", date2);
            });
          
$(document).on('ready', function() 
{
  $('select[name="si_currency"]').on('change',function(){
     jQuery.ajax({
               url:"<?php echo base_url().'Receipt_Master/get_currency_conv_val';?>",
                data:{"currecny_selected":$(this).val()},
              type:"post",
               success:function(result)
              {
                if(result)
                {
                $("input[name='si_conv_value']").val(result);
                }
              }
               }); 
  });

  $('.menu_name_fun').on('click',function(){
          if (confirm("Are you sure, You want to exit this page?")) {
                  location.href = $(this).attr('href');
            } 
            else {
              return false;
            }

          });

  $('select[name="dn_plc_supply"]').on("change",function(){
        var selected_val=$(this).val();
        $('select[name="dn_jurisdiction"]').val(selected_val).trigger('change');
     });
}); 

function load_sales_inv()
{
  var page_type=$("input[name='page_type']").val();
    var cust_id=$('select[name="dn_customer_acc_id"]').find('option:selected').val();
  jQuery.ajax({
       url:"<?php echo base_url().'Delivery_note/get_cust_sales_inv';?>",
        data:{"cust_id":cust_id,'page_type':page_type},
      type:"post",
       success:function(result)
        {
          if(result)
          {
        //console.log(result);
          $('.modal_content_sinv').html(result);
           $('#datatable-default2').DataTable();
          }
        }
       }); 
}

$('.confirm_btn_modal').on('click',function()
{
  console.log('inside the confirm button');
  var page_type=$("input[name='page_type']").val();
  console.log(page_type);
    $('input[name="choose_inv"]:checked').each(function() {
        jQuery.ajax({///////////this ajax for getting the form filled/////////////////
       url:"<?php echo base_url().'Delivery_note/get_inv_details_checked';?>",
        data:{"checked_inv":this.value,'page_type':page_type},
      type:"post",
       success:function(result)
        {
          if(result)
          {
         var returndata = JSON.parse(result);
         console.log(returndata);
          $('select[name="dn_company"] ').val(returndata['comp_name']).trigger('change');
          $('select[name="dn_salesman"]').val(returndata['salesman']).trigger('change');
          $('select[name="dn_payment_type"]').val(returndata['payment']).trigger('change');
          $('select[name="dn_plc_supply"]').val(returndata['pls_sup']).trigger('change');
          $('select[name="dn_jurisdiction"]').val(returndata['jurisdiction']).trigger('change');
          $('select[name="dn_warehouse"]').val(returndata['warehouse']).trigger('change');
        
          $('input[name="dn_mark"]').val(returndata['mark']);
          $('input[name="dn_delivery_address"]').val(returndata['delivery_addresss']);
          $('input[name="dn_lpo_no"]').val(returndata['lpo_no']);
          $('input[name="dn_bill_no"]').val(returndata['bill_no']);
          $('textarea[name="dn_narration"]').val(returndata['narration']);
          $('input[name="dn_shipping_contact"]').val(returndata['ship_contact']);
          $('input[name="dn_contact"]').val(returndata['customer_contact']);
         //  $('input[name="dn_tot_vat"]').val(returndata['tot_vat']);
         // $('input[name="dn_tot_amount"]').val(returndata['tot_net']);
          $('input[name="sales_inv_id"]').val(returndata['sales_invoice_id']);
         
             if(returndata['currency_val']!=null)
              {
               $('select[name="dn_currency"]').val(returndata['currency_val']).trigger('change');
               if(returndata['currency_val']!=null)
               $('input[name="dn_conv_value"]').val(returndata['currency_val']);
               else
                 $('input[name="dn_conv_value"]').val('1');
             }
             else
             {
                $('select[name="dn_currency"]').val('1').trigger('change');
                $('input[name="dn_conv_value"]').val('1');
             }
          //$('.modal_content_sinv').html(result);
          // $('#datatable-default2').DataTable();
          }
        }
       }); 

        jQuery.ajax({////////this ajax for printing the table with data//////////////////
       url:"<?php echo base_url().'Delivery_note/get_inv_table_checked';?>",
        data:{"checked_inv":this.value,'page_type':page_type},
      type:"post",
       success:function(result)
        {
           //console.log(result);
          if(result)
          {
         // $('table tbody .all_table_rows').html(result);
               var returndata = JSON.parse(result);
              $(returndata['html_result']).each(function(key,val) { 
               $('table .all_table_rows').append(val);
             });
               
              $('.error_result').append(returndata['error_result']);
               
              $('.modal-close-btn').click();     
              //console.log($(returndata['error_result'][selector])); 
               ///alert($(returndata['error_result']));
          }
          else
          {}
        }
       }); 

  });
});

///////////////////////modal functions page/////////////////////////////////////////////////

function get_amount_total()
{
  var amountss1='0';
$('table tbody tr td input[name="dn_qnty[]"]').each(function(){
amountss1= parseFloat(amountss1)+parseFloat($(this).val());
}); 
$('.qnty_tot_button').val(parseFloat(amountss1.toFixed(2)));
/////////for gross tot_calc//////////

var amountss_3='0';
$('table tbody tr td input[name="dn_gross[]"]').each(function(){
amountss_3= parseFloat(amountss_3)+parseFloat($(this).val());
}); 
$('.gross_tot_button').val(parseFloat(amountss_3.toFixed(2)));

//////////for add charges tot calc field///////
 var amountss_6='0';
$('table tbody tr td input[name="dn_add_charges[]"]').each(function(){
amountss_6= parseFloat(amountss_6)+parseFloat($(this).val());
}); 
$('.add_charges_tot_button').val(parseFloat(amountss_6.toFixed(2)));

///////for fnet tot calc field///////////
  var amountss_7='0';
$('table tbody tr td input[name="dn_fnet[]"]').each(function(){
amountss_7= parseFloat(amountss_7)+parseFloat($(this).val());
}); 
$('.fnet_tot_button').val(parseFloat(amountss_7.toFixed(2)));

////////////for vat tot calc field//////

  var amountss_8='0';
$('table tbody tr td input[name="each_vat_total[]"]').each(function(){
amountss_8= parseFloat(amountss_8)+parseFloat($(this).val());
}); 
$('.vat_tot_button').val(parseFloat(amountss_8.toFixed(2)));

var final_val='0';
$('.amount_tot_button').val(parseFloat(amountss_8.toFixed(2)) + parseFloat(amountss_7.toFixed(2))  );


//  var amountss_8='0';
// $('table tbody tr td input[name="si_vat[]"]').each(function(){
// amountss_8= parseFloat(amountss_8)+parseFloat($(this).val());
// }); 
// $('.vat_tot_button').val(parseFloat(amountss_8));

//////////show total amount///////////


}

/////////////////////end of modal functions////////////////////////////////////

function check_for_reset()
{
  if (confirm("Are you sure, You want to reset this form?")) {
                 $('.myform').trigger("reset");
            } 
            else {
              return false;
            }
}


 $('.myform').submit(function() {
 //e.preventDefault();

var rowcount = $('.new_rows tr').length;


var prd_ids=$('table tbody tr td input[name="each_prd[]"]').map(function(){return $(this).val();}).get().join('|#|');  

var p_units=$('table tbody tr td input[name="dn_units[]"]').map(function(){return $(this).val();}).get().join('|#|');  

var qnty_nos=$('table tbody tr td input[name="dn_qnty[]"]').map(function(){return $(this).val();}).get().join('|#|');
var labels=$('table tbody tr td input[name="dn_label[]"]').map(function(){return $(this).val();}).get().join('|#|');  
var rate_nos=$('table tbody tr td input[name="dn_rate[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var gross_nos=$('table tbody tr td input[name="dn_gross[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var add_charges_nos=$('table tbody tr td input[name="dn_add_charges[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var fent_nos=$('table tbody tr td input[name="dn_fnet[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

//var p_cogs=$('table tbody tr td input[name="dn_cogs[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var vat_nos=$('table tbody tr td input[name="dn_vat[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

//var delivery_date_nos=$('table tbody tr td input[name="dn_delivery_date[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

//var tax_code_nos=$('table tbody tr td input[name="dn_tax_code[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

//console.log(quantity+' '+package_size+' '+product_id);

$("input[name='hi_prd_id']").val(prd_ids);
$("input[name='hi_unit']").val(p_units);
$("input[name='hi_label']").val(labels);
$("input[name='hi_qnty']").val(qnty_nos);
$("input[name='hi_rate']").val(rate_nos);
$("input[name='hi_gross']").val(gross_nos);
$("input[name='hi_add_charges']").val(add_charges_nos);
$("input[name='hi_fnet']").val(fent_nos);
//$("input[name='hi_cogs']").val(p_cogs);
$("input[name='hi_vat']").val(vat_nos);
//$("input[name='hi_delivery_date']").val(delivery_date_nos);
//$("input[name='hi_tax_code']").val(tax_code_nos);

var ij=0;
var data_var=[];

$('.new_rows tr td').each(function() { 
var cellText = $(this).html(); 
 //  console.log(cellText);  
    $('.cell_text_data').append(cellText).hide(); 
});

 // console.log($("input[name='hi_prd_id']").val());
 //  console.log($("input[name='hi_unit']").val());
 //   console.log($("input[name='hi_qnty']").val());
 //      console.log($("input[name='hi_vat']").val());
//console.log(cellText);
/// console.log($("input[name='hid_salesman']").val());
// console.log($("input[name='hid_customer']").val());
// console.log($("input[name='hid_amounts']").val());
// console.log($("input[name='hid_remark']").val());
//  console.log($("input[name='hid_ref']").val());
//var table_row_added=$('.new_rows').html();

 if ($('.new_rows tr').length == 0) 
 {
  alert('Please choose items to add and submit');
  return false;
 }
 else
 { 
  return true;
 }
 //return false;
  // your code here
});
 // }
        </script>

</body>

</html>