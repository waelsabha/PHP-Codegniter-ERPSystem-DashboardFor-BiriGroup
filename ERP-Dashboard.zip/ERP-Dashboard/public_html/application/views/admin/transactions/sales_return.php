<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" 
type="text/css"/>
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" 
type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
table input.form-control {
  width: auto;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">
<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Transactions </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Sales</span></li>
<li><span>Sales Return </span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Issue Sales Return </h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('Sales_return/submit_sales_return','class="myform" novalidate','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
 <input type="hidden" name="inv_id" value="<?php if(!empty($result[0]->srt_id)){echo $result[0]->srt_id;};?>">
  <input type="hidden" name="files_added" value="<?php if(!empty($result[0]->srt_attachments)){echo $result[0]->srt_attachments;};?>">
 <input type="hidden" name="page_type" value="">
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>



<div class="row">

 <div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Doc No <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<input type="text" name="srt_doc_no" value="<?php if(!empty($result)){if(!empty($result[0]->srt_doc_no)){echo $result[0]->srt_doc_no;}}else{echo $doc_num;}?>" readonly class="form-control">
  <input type="hidden" name="sales_inv_id" > <input type="hidden" name="dl_id" >
 <div class="form_error">  <?php echo $this->session->flashdata('si_doc_no');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Date<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
   <?php
  if(!empty($result[0]->srt_date))
  $converted_date = date("m/d/Y", strtotime($result[0]->srt_date));
  ?>
 <input type='text' readonly="" name="srt_date" class="form-control datetimepicker4" value="<?php if(!empty($result[0]->srt_date)){echo $converted_date;}else{ echo date('m/d/Y');} ;?>" required />
  <div class="form_error">  <?php echo $this->session->flashdata('srt_date');?></div>

</div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">



<div class="col-md-6 col-sm-12 ">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Company<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="srt_company" required="" >
  <option value="">Choose</option>

  <?php
foreach($company_masters as $cm)
{
 // pre_list($cm);
  ?>
   <option value="<?php echo $cm->mcomp_id;?>" <?php if(!empty($result[0]->srt_company)){if($result[0]->srt_company==$cm->mcomp_id){echo "selected";}};?>> <?php echo $cm->mcomp_name;?> </option> 
  <?php
}
?>
 </select>
 
  <div class="form_error">  <?php echo $this->session->flashdata('srt_company');?></div>
</div>
</div>


</div>


<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Customer<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="srt_customer_acc_id" required="">
  <option value="">Choose</option>
  <?php
  foreach($customers as $cs)
  {
?>
  <option value="<?php echo $cs['id'];?>" <?php if(!empty($result[0]->srt_customer_acc_id)){if($result[0]->srt_customer_acc_id==$cs['id']){echo "selected";}};?>> <?php echo $cs['label'];?> </option> 
  <?php
  }?>
 </select>
   <div class="form_error">  <?php echo $this->session->flashdata('srt_customer_acc_id');?></div>
</div>
</div>
</div>







</div>



<div class="col-md-12 col-sm-12 table-rows-border">

  <div class="col-md-6 col-sm-12">
  <div class="form-group">
<a type="button" class="btn btn-warning pull-right mb-xs mt-xs mr-xs modal-sizes" onclick="load_sales_inv();" href="#modalmd_sinv">Load all Deliver Note</a>
</div>
</div>

</div>




<div class="col-md-12 col-sm-12 table-rows-border">

  <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Sales Account<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="srt_sales_acc_id" required="">
  <option value="">Choose</option>
    <?php
  foreach($sales_accont as $cs)
  {
?>
  <option value="<?php echo $cs['id'];?>" <?php if(!empty($result[0]->srt_sales_acc_id)){if($result[0]->srt_sales_acc_id==$cs['id']){echo "selected";}};?>> <?php echo $cs['label'];?> </option> 
  <?php
  }?>
 </select>
</div>
</div>
</div> 

</div> 



<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12 ">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Project
</label>
<div class="col-md-8">
 <select data-plugin-selectTwo  class="form-control populate" name="srt_project" >
  
 <?php
 foreach($project as $pj)
 {?>
  <option value="<?php echo $pj->mpj_id;?>" <?php if(!empty($result[0]->srt_project)){if($result[0]->srt_project==$pj->mpj_id){echo "selected";}}else{if($pj->mpj_id=='1'){echo "selected";}};?> > <?php echo $pj->mpj_name;?></option> 
  <?php
}?>

 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('srt_project');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Warehouse<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
    <select data-plugin-selectTwo  class="form-control populate" name="srt_warehouse" required="">
  <option value="">Choose</option>
 <?php
foreach($warehouse_data as $wd)
{
?>
<option value="<?php echo $wd->mw_id;?>" <?php if(!empty($result[0]->srt_warehouse)){if($result[0]->srt_warehouse==$wd->mw_id){echo "selected";}};?> ><?php echo $wd->mw_name;?></option>
<?php
}
?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('srt_warehouse');?></div>
</div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Shipping
</label>
<div class="col-md-8">
  <textarea class="form-control" name="srt_mark" required=""><?php if(!empty($result[0]->srt_mark)){echo $result[0]->srt_mark;};?></textarea>
  <div class="form_error">  <?php echo $this->session->flashdata('srt_mark');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12 ">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Salesman<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="srt_salesman" required="">
  <option value="">Choose</option>
  <?php
$data_salesman=array_filter($salesman);
foreach($data_salesman as $sm)
{
  ?>
   <option value="<?php echo $sm[0]->ed_id;?>" <?php if(!empty($result[0]->srt_salesman)){if($result[0]->srt_salesman==$sm[0]->ed_id){echo "selected";}};?>> <?php echo $sm[0]->ed_name;?> </option> 
  <?php
}
?>
 </select>
 
  <div class="form_error">  <?php echo $this->session->flashdata('srt_salesman');?></div>
</div>
</div>
</div>


</div>

<div class="col-md-12 col-sm-12 table-rows-border">

  <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Narration
</label>
<div class="col-md-8">
  <textarea class="form-control" name="srt_narration" required=""><?php if(!empty($result[0]->srt_narration)){echo $result[0]->srt_narration;};?></textarea>
  <div class="form_error">  <?php echo $this->session->flashdata('srt_narration');?></div>
</div>
</div>
</div>


  <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Payment Terms<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="srt_payment_type">
  <option value="">Choose</option>
 <?php
 foreach($payment_method as $pm)
 {?>
  <option value="<?php echo $pm->mpm_id;?>" <?php if(!empty($result[0]->srt_payment_type)){if($result[0]->srt_payment_type==$pm->mpm_id){echo "selected";}};?>> <?php echo $pm->mpm_name;?></option> 
  <?php
}?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('srt_payment_type');?></div>
</div>
</div>
</div>

<!-- <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Project
</label>
<div class="col-md-8">
 <input type='text' name="date_ref" class="form-control" value=""  />
  <div class="form_error">  <?php echo $this->session->flashdata('date_ref');?></div>
</div>
</div>
</div>
 -->

</div>




<div class="col-md-12 col-sm-12 table-rows-border">

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Delivery Terms
</label>
<div class="col-md-8">
 <input type='text' name="srt_dlvry_terms"  class="form-control" value="<?php if(!empty($result[0]->srt_dlvry_terms)){echo $result[0]->srt_dlvry_terms;};?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('srt_dlvry_terms');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Place of Supply
</label>
<div class="col-md-8">
   <select data-plugin-selectTwo  class="form-control populate" name="srt_plc_supply">
  <option value="">Choose</option>
 <?php
 foreach($place_supply as $ps)
 {?>
  <option value="<?php echo $ps->mw_id;?>" <?php if(!empty($result[0]->srt_plc_supply)){if($result[0]->srt_plc_supply==$ps->mw_id){echo "selected";}};?>> <?php echo $ps->mps_name;?></option> 
  <?php
}?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('srt_plc_supply');?></div>
</div>
</div>
</div>


</div>

<div class="col-md-12 col-sm-12 table-rows-border">

  <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Jurisdiction
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="srt_jurisdiction">
  <option value="">Choose</option>
 <?php
 foreach($place_supply as $ps)
 {?>
  <option value="<?php echo $ps->mw_id;?>" <?php if(!empty($result[0]->srt_jurisdiction)){if($result[0]->srt_jurisdiction==$ps->mw_id){echo "selected";}};?> > <?php echo $ps->mps_name;?></option> 
  <?php
}?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('srt_jurisdiction');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Currency Name<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="srt_currency">
  <option value="">Choose</option>
  <?php
  foreach($currency_convt as $cv)
  {
    ?>
 <option value="<?php echo $cv->currency_name;?>" <?php if(!empty($result[0]->srt_currency)){if($result[0]->srt_currency==$cv->currency_name){echo "selected";}}else{if($cv->currency_name=="AED"){echo "selected";}};?>> <?php echo $cv->currency_name;?> </option> 
    <?php
  }
  ?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('srt_currency');?></div>
</div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12" >
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Currenct Conv.<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
 <input type='text' name="srt_conv_value" readonly="" class="form-control" value="<?php if(!empty($result[0]->srt_conv_value)){echo $result[0]->srt_conv_value;}else{echo "1";};?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('srt_conv_value');?></div>
</div>
</div>
</div>
</div>


<!-- <div class="col-md-12 col-sm-12 table-rows-border">

<div class="form-group">
  <p>Upload files here.Make sure the file size is less than 2MB.</p>
 <input class="form-control" name="files[]" type="file"  multiple  required />
 <div class="form_error">  <?php echo $this->session->flashdata('files[]');?></div>
</div> 
</div>
<?php
if(!empty($result[0]->srt_attachments))
{
  echo "<h4> FILES UPLOADED :</h4>";
  $files_are=explode(',',$result[0]->srt_attachments);
  foreach($files_are as $fr)
  {
    echo "<a href='".base_url("uploads/sales_invoice/".$fr)."' target='_blank'>".$fr."</a><br/>";
  }
}
else{}  
?> -->
 
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive">
<table class="table table-border table-rows-border">
  <thead>
    <th>Item</th>
     <th>DEscription</th>
       <th>Units</th>
      <th>Quantity</th>
       <th>Link-1</th>
       <th>Rate</th>
        <th>Gross</th>
        <th>Discount %</th>
         <th>Discount Amount</th>
         <th>Addl. Charges</th>
         <th>Vat</th>
         <th>FNet</th>

        <!--  <th>Cogs</th> -->
         
        <!--  <th>Delivery Date</th>        
         <th>Tax Code</th> -->
         <th></th>
  </thead>
  <tbody class="new_rows all_table_rows" >
   
     <?php
    if(!empty($result[0]))/////used in update value
    {
      $prd_added=explode('|#|',$result[0]->srt_product);
      $prd_desc=explode('|#|',$result[0]->srt_desc);
       $prd_units=explode('|#|',$result[0]->srt_units);

      $qnty_added =explode('|#|',$result[0]->si_qnty);
      $sum_qnty=array_sum($qnty_added);

      $rate_added=explode('|#|',$result[0]->si_rate);
         $sum_rate=array_sum($rate_added);

      $gross_added=explode('|#|',$result[0]->srt_gross);
         $sum_gross=array_sum($gross_added);

$discount_percentage=explode('|#|',$result[0]->srt_dis_per);
$discount_amount=explode('|#|',$result[0]->srt_dis_amount);
      $add_charges_added=explode('|#|',$result[0]->srt_add_charges);
         $sum_add_charges=array_sum($add_charges_added);

       $fnet_added=explode('|#|',$result[0]->srt_fnet);
       $sum_fnet=array_sum($fnet_added);

       // $cogs_added=explode('|#|',$result[0]->srt_cogs);

      $vat_added=explode('|#|',$result[0]->srt_vat);
         $sum_vat=array_sum($vat_added);

      // $delivery_date_added=explode('|#|',$result[0]->srt_delivery_date);
      // $taxcode_added=explode('|#|',$result[0]->srt_tax_code);
       $total_count_rows=count($prd_added);
       $ik=1;
   foreach($prd_added as $ca_index=>$pa)
      {
?>
<tr>
  <td>
   <input type="text" name="srt_product[]"  value="<?php if(!empty($pa)){echo $pa;}else{echo "0";};?>"  step="any"  class="form-control qnyt_dt qnty<?php echo $ik;?>"> </td>
     <td>
   <input type="text" name="srt_desc[]"  value="<?php if(!empty($pa)){echo $pa;}else{echo "0";};?>"  step="any"  class="form-control qnyt_dt qnty<?php echo $ik;?>"> </td>
  <td><input type="text" name="srt_units[]"  value="<?php if(!empty($prd_units[$ca_index])){echo $prd_units[$ca_index];}else{echo "0";};?>"  step="any"  class="form-control qnyt_dt qnty<?php echo $ik;?>"> </td>

     <td><input type="number" name="srt_qnty[]" onchange="calc_gross(<?php echo $ik;?>);" onkeyup="calc_gross(<?php echo $ik;?>);" value="<?php if(!empty($qnty_added[$ca_index])){echo $qnty_added[$ca_index];}else{echo "0";};?>"  step="any"  class="form-control qnyt_dt qnty<?php echo $ik;?>"> </td>

      <td><input type="number" name="srt_link[]" value="<?php if(!empty($qnty_added[$ca_index])){echo $qnty_added[$ca_index];}else{echo "0";};?>"  step="any"  class="form-control qnyt_dt qnty<?php echo $ik;?>"> </td>

    <td><input type="number" name="srt_rate[]" onchange="calc_gross(<?php echo $ik;?>)" onkeyup="calc_gross(<?php echo $ik;?>)"  value="<?php if(!empty($rate_added[$ca_index])){echo $rate_added[$ca_index];}else{echo "0";};?>" step="any"  class="form-control rate_dt rate<?php echo $ik;?>"> </td>

    <td><input type="number" name="srt_gross[]" value="<?php if(!empty($gross_added[$ca_index])){echo $gross_added[$ca_index];}else{echo "0";};?>" step="any"  readonly="" class="form-control gross_dt gross<?php echo $ik;?>"></td>

    <td><input type="number"  name="srt_add_charges[]" value="<?php if(!empty($add_charges_added[$ca_index])){echo $add_charges_added[$ca_index];}else{echo "0";};?>"  onchange="calc_gross(<?php echo $ik;?>)" onkeyup="calc_gross(<?php echo $ik;?>)" step="any"  class="form-control add_charges_dt addchrg<?php echo $ik;?>"> 
    </td>

    <td><input type="number" name="srt_fnet[]"  value="<?php if(!empty($fnet_added[$ca_index])){echo $fnet_added[$ca_index];}else{echo "0";};?>"  step="any"  readonly="" class="form-control fnet_dt fnet<?php echo $ik;?>"></td>
    <td>
      <?php
     $fent_with_vat=$fnet_added[$ca_index]*($vat_added[$ca_index]/100);
    $tot_fnet_vat=$fent_with_vat+$fnet_added[$ca_index];
      ?>
      <!------hidden field--->
       <input type="hidden" name="vat_fnet_val[]"  value="<?php if(!empty($tot_fnet_vat)){echo $tot_fnet_vat;};?>" class="form-control vat_fnet_val<?php echo $ik;?>"> 
        <input type="hidden" name="vat_each_prd[]"  value="0" class="form-control vat_each_prd_val<?php echo $ik;?>">
         <!------hidden field--->

    <!--   <input type="number" name="srt_cogs[]" value="<?php if(!empty($cogs_added[$ca_index])){echo $cogs_added[$ca_index];}else{echo "0";};?>"  step="any" readonly="" class="form-control vat_dt vat<?php echo $ik;?>"> </td> -->
     
      <td><input type="text"  name="srt_vat[]" class="form-control datetimepicker5" value="<?php if(!empty($vat_added[$ca_index])){echo $vat_added[$ca_index];}else{echo "0";};?>"> </td>

      <?php
 if(!empty($delivery_date_added[$ca_index]))
  $converted_dlvry_date = date("m/d/Y", strtotime($delivery_date_added[$ca_index]));
?>
   <!--  <td><input type="text"  name="srt_delivery_date[]" class="form-control datetimepicker5" value="<?php if(!empty($delivery_date_added[$ca_index])){echo $converted_dlvry_date;};?>"> </td>

    <td><input type="text"  name="srt_tax_code[]" readonly="" value="<?php if(!empty($taxcode_added[$ca_index])){echo $taxcode_added[$ca_index];};?>" class="form-control"> </td> -->
    <td></td>


    </tr>
<?php
   $ik++;
      }
  }
  else////for adding new , for new inovices///////////////
  {
    ?>
        
   <!--  <tr>
  <td>
    <input type="text" name="srt_product[]" class="form-control">
    </td>
  <td><input type="number" name="srt_units[]"  value="0"  step="any"  class="form-control qnyt_dt qnty1"> </td>
    <td><input type="number" name="srt_qnty[]" onchange="calc_gross('1');" onkeyup="calc_gross('1');" value="0"  step="any"  class="form-control qnyt_dt qnty1"> </td>
     <td><input type="number" name="srt_link_1[]" value="0"  step="any"  class="form-control qnyt_dt qnty1"> </td>
     <td><input type="number" name="srt_rate[]" onchange="calc_gross('1')" onkeyup="calc_gross('1')"  value="0" step="any"  class="form-control rate_dt rate1"> </td>
    <td><input type="number" name="srt_gross[]" value="0" step="any"  readonly="" class="form-control gross_dt gross1"></td>

    <td><input type="number"  name="srt_add_charges[]" value="0"  onchange="calc_gross('1')" onkeyup="calc_gross('1')" step="any"  class="form-control add_charges_dt addchrg1"> </td>

    <td><input type="number" name="srt_fnet[]"  value="0"  step="any"  readonly="" class="form-control fnet_dt fnet1"></td>
    <td><input type="number" name="srt_cogs[]"  value="0"  step="any"  readonly="" class="form-control fnet_dt fnet1"></td>

    <td>
       <input type="hidden" name="vat_fnet_val[]"  value="0" class="form-control vat_fnet_val1">
      <input type="hidden" name="vat_each_prd[]"  value ="0" class="form-control vat_each_prd_val1">
      <input type="number" name="srt_vat[]" value="5"  step="any" readonly="" class="form-control vat_dt vat1"> </td>

    <td><input type="text"  name="srt_delivery_date[]" class="form-control datetimepicker5"> </td>
     <td><input type="text"  name="srt_tax_code[]" readonly="" value="0" class="form-control"> </td>
    <td></td>
    </tr> -->
   
    <?php
  }?>
  
<!--  <button type="button" class="btn btn-primary pull-right" onclick="add_more_row();">Add More</button>  -->
  </tbody>
</table>
</div>
</div>

   <!-----for input tyype hidden fields------------->
    <input type="hidden" name="hi_prd_id" class="form-control"> 
     <input type="hidden" name="hi_prd_desc" class="form-control"> 
     <input type="hidden" name="hi_aray_index_pos" class="form-control">  
     <input type="hidden" name="hi_unit" class="form-control"> 
    <input type="hidden" name="hi_label" class="form-control"> 
    <input type="hidden" name="hi_qnty"  value="0"  class="form-control"> 
    <input type="hidden" name="hi_rate"   value="0" class="form-control"> 
    <input type="hidden" name="hi_gross"  value="0"  class="form-control">  
    <input type="hidden" name="hi_add_charges" value="0"  class="form-control">
    <input type="hidden" name="hi_disc_per" value="0"  class="form-control">
    <input type="hidden" name="hi_disc_charges" value="0"  class="form-control">

    <input type="hidden" name="hi_array_pos" value="0" class="form-control">

    <input type="hidden" name="hi_fnet"  value="0" class="form-control"> 
     <!--  <input type="hidden" name="hi_cogs"  value="0" class="form-control">  -->
    <input type="hidden" name="hi_vat"  value="0" class="form-control"> 
<!--    <input type="hidden" name="hi_delivery_date" class="form-control datetimepicker5"> 
   <input type="hidden" name="hi_tax_code"  value="0" class="form-control">  -->


<input type="hidden" name="ref_sales_inv_cust_id">
  <input type="hidden" name="ref_sales_inv_id">
    <input type="hidden" name="ref_sales_inv_amount">
  <input type="hidden" name="ref_sales_inv_amount_paid">
  <input type="hidden" name="ref_sales_doc_num">

    <!---------end for input type hidden--->

<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
<div class="col-md-8">
  <span class="num_items">
    <?php
if(!empty($result[0]))
 {
     if(!empty($total_count_rows))
      {
        echo $total_count_rows;
      }
     else
    {
      echo "1";
    }
}
  else
  {
    echo "1";
  }
  ?>
  </span>
</div>
</div>
<!----------end col-md-12----------------------------->

<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12 ">
  <label class="col-md-4 control-label" for="inputPlaceholder">Total Quantity:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="qnty_tot_button" name="srt_tot_qnty" required="required" value="<?php if(!empty($sum_qnty)){echo $sum_qnty;}else{echo "0";};?>">
</div>
</div>
<!----------end col-md-12----------------------------->
<!-------start col-md-12------------------->
<div class="col-md-6 col-sm-12 ">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total Gross:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="gross_tot_button" name="srt_tot_gross" required="required" value="<?php if(!empty($sum_gross)){echo $sum_gross;}else{echo "0";};?>">
</div>
</div>
</div>
<!----------end col-md-12----------------------------->

<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total Discount Percentage :<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="dis_per_tot_button" name="srt_tot_dis_per" required="required" value="<?php if(!empty($sum_add_charges)){echo $sum_add_charges;}else{echo "0";};?>">
</div>
</div>
<!----------end col-md-12----------------------------->


<!-------start col-md-12------------------->
<div class="col-md-6 col-sm-12">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total Discount Amount:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="dis_amount_tot_button" name="srt_tot_dis_amount" required="required" value="<?php if(!empty($sum_add_charges)){echo $sum_add_charges;}else{echo "0";};?>">
</div>
</div>
</div>
<!----------end col-md-12----------------------------->


<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total Additional Charges:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="add_charges_tot_button" name="srt_tot_add_charges" required="required" value="<?php if(!empty($sum_add_charges)){echo $sum_add_charges;}else{echo "0";};?>">
</div>
</div>
<!----------end col-md-12----------------------------->


<!-------start col-md-12------------------->
<div class="col-md-6 col-sm-12 ">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total Fnet:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="fnet_tot_button" name="srt_tot_fnet" required="required" value="<?php if(!empty($sum_fnet)){echo $sum_fnet;}else{echo "0";};?>">
</div>
</div>
</div>
<!----------end col-md-12----------------------------->
<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<!-------start col-md-12------------------->
<!-- <div class="col-md-6 col-sm-12 ">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total Cogs:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="cogs_tot_button" name="srt_tot_cogs" required="required" value="<?php if(!empty($sum_fnet)){echo $sum_fnet;}else{echo "0";};?>">
</div>
</div> -->
<!---------end col-md-12----------------------------->
<!-------start col-md-12------------------->
<div class="col-md-6 col-sm-12 table-rows-border">
  <label class="col-md-4 control-label" for="inputPlaceholder"> Total VAT Charges:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="vat_tot_button" name="srt_tot_vat" required="required" value="<?php if(!empty($srt_tot_vat)){echo $srt_tot_vat;}else{echo "0";};?>">
</div>
</div>
</div>
<!----------end col-md-12----------------------------->
<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
    <button class="btn btn-primary" type="button" onclick="get_amount_total()">Click to - Calculate total quantity</button>
  <br/> 
  <label class="col-md-4 control-label amount_text" for="inputPlaceholder">Amount Total:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="amount_tot_button" name="srt_tot_amount" required="required" value="<?php if(!empty($result[0]->srt_tot_amount)){echo $result[0]->srt_tot_amount;}else{echo "0";};?>">
  <small>Amount as per the currency rate selected</small>
</div>
</div>
<!----------end col-md-12----------------------------->

<!-----div starts here for non-inquiry--->
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for non-inquiry--->
<!-----div starts here for non-inquiry--->
 <!-- Button trigger modal for sales invoice-->
 <div id="modalmd_sinv" class="modal-block modal-block-lg mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">All Delivery Note for : <span class="cust_name_val"></span> </h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text modal_content_sinv">
   
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button"   class="btn btn-primary confirm_btn_modal">Confirm</button>
<button class="btn btn-default modal-dismiss modal-close-btn">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal--->
<!----div closes here--->
<div class="cell_text_data"></div>

<div class="col-sm-9 col-sm-offset-3">
  
   <?php
   if(!empty($result_ac_tx))
   {
   //pre_list($result_ac_tx[$ca_index]->atx_id);
  ?>
 <a  class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes sales_invoice_modal_a" onclick="get_inv_content(<?php echo $result_ac_tx[0]->atx_id;?>);" href="#modalmd_sinv"><i class="fa fa-trash-o"></i>Pop-up Invoice </a>
 <?php
  }
  else{?>
<a type="button" class="btn btn-primary mb-xs mt-xs mr-xs modal-sizes" href="#modalmd_popup" onclick="get_cust_sales_inv()">Save</a>
<?php
  }
  ?>
  <button style="display: none;" type="submit" class="submit_btn"></button>
<button type="reset" class="btn btn-default" onclick="check_for_reset()">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>

</section>
</div>
</section>


 <!-- Button trigger modal for sales invoice-->
 <div id="modalmd_popup" class="modal-block modal-block-lg mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">References </h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text modal_content_popup">
   
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button" onclick="submit_sales_inv_amount()"  class="btn btn-primary ">Confirm</button>
<button class="btn btn-default modal-dismiss modal-close-btn">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal--->

<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
<a href="#" class="mobile-close visible-xs">
Collapse <i class="fa fa-chevron-right"></i>
</a>
<div class="sidebar-right-wrapper">

<div class="sidebar-widget widget-friends ">

<div class="chat_window">
<?php $this->load->view('admin/master_essential/chat_data',$chat);?>

</div>
</div>

</div>
</div>
</div>
</aside>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
 <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript">
  </script>

  <script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

  
  <script>
  $(document).on('ready', function () {
    $('input').attr('autocomplete','off');
      $("#file-1").fileinput();
      });
 </script>

 <script>
    tinymce.init({
      selector : '.editors',
        plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
    });
   </script>
   
<script type="text/javascript">
  function table(id)
  {
    $('table tbody .table'+id).remove();
    var rowcount = $('table tbody tr').length;
    $(".num_items").html(rowcount);
  }
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  



     <script>
  function maxLengthCheck(object) {
    if (object.value.length > object.max.length)
      object.value = object.value.slice(0, object.max.length)
  }
    
  function isNumeric (evt) {
    var theEvent = evt || window.event;
    var key = theEvent.keyCode || theEvent.which;
    key = String.fromCharCode (key);
    var regex = /[0-9]|\./;
    if ( !regex.test(key) ) {
      theEvent.returnValue = false;
      if(theEvent.preventDefault) theEvent.preventDefault();
    }
  }
</script>
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker();
            });

           $(function () {
            var date2 = $('.datetimepicker4').datepicker('getDate', '+1d'); 
  date2.setDate(date2.getDate()+1); 
                $('.datetimepicker5').datepicker().datepicker("setDate", date2);
            });
          
$(document).on('ready', function() 
{
  $('select[name="si_currency"]').on('change',function(){
     jQuery.ajax({
               url:"<?php echo base_url().'Receipt_Master/get_currency_conv_val';?>",
                data:{"currecny_selected":$(this).val()},
              type:"post",
               success:function(result)
              {
                if(result)
                {
                $("input[name='si_conv_value']").val(result);
                }
              }
               }); 
  });

  $('.menu_name_fun').on('click',function(){
          if (confirm("Are you sure, You want to exit this page?")) {
                  location.href = $(this).attr('href');
            } 
            else {
              return false;
            }
          });

  $('select[name="srt_company"]').on('change',function(){
    var company_selected=$("select[name='srt_company']").find('option:selected').text();
      if(company_selected.includes("KSA")==true)
      {
        $('input[name="page_type"]').val('ksa');
      }
      else if(company_selected.includes("Dragon"))
      {
         $('input[name="page_type"]').val('dragon');
      }
      else if(company_selected.includes("UAE"))
      {
         $('input[name="page_type"]').val('uae');
      }
      else
      { }
  });

   $('select[name="srt_plc_supply"]').on("change",function(){
        var selected_val=$(this).val();
        $('select[name="srt_jurisdiction"]').val(selected_val).trigger('change');
     });

}); 

function load_sales_inv()
{
     var cust_id=$('select[name="srt_customer_acc_id"]').find('option:selected').val();
     var cust_name=$('select[name="srt_customer_acc_id"]').find('option:selected').text();
    var company_selected=$("select[name='srt_company']").find('option:selected').text();
    if(company_selected.includes("KSA")==true)
    {
     var page_type='ksa';
    }
    else if(company_selected.includes("Dragon"))
    {
      var page_type='dragon';
    }
    else if(company_selected.includes("UAE"))
    {
      var page_type='uae';
    }
    else
    { }

  jQuery.ajax({
       url:"<?php echo base_url().'Sales_return/get_cust_sales_inv';?>",
        data:{"cust_id":cust_id,'page_type':page_type},
      type:"post",
       success:function(result)
        {
          if(result)
          {
          $('.modal_content_sinv').html(result);
          $('.cust_name_val').html(cust_name);
           $('#datatable-default2').DataTable();
          }
        }
       }); 
}

function get_cust_sales_inv()
{
   var cust_id=$('select[name="srt_customer_acc_id"]').find('option:selected').val();
     var cust_amount_paid=$('.amount_tot_button').val();
  jQuery.ajax({
               url:"<?php echo base_url().'Sales_return/get_cust_pop_up_ref';?>",
                data:{"cust_id":cust_id,'cust_amount_paid':cust_amount_paid},
              type:"post",
               success:function(result)
              {
               //console.log(result);
                $('.modal_content_popup').html(result);
                 $('#datatable-default2').DataTable();
               }
            });
}


function submit_sales_inv_amount()
{
  var issue_text_data=$('.text_data_issue').html();
  var to_be_adjust= $('.to_be_adjust').html();
   var refrence_names='';
if(to_be_adjust=='0')
{

   $('.class_checkbox').each(function() {
   if ( $(this).is(':checked') )
   {    
  //    console.log(sales_doc_num);

   var sales_inv_ids=$('table tbody tr td input[name="inv_id_modal[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var sales_inv_amount=$('table tbody tr td input[name="sales_inv_amount_modal[]"]').map(function(){return $(this).val();}).get().join('|#|');
//console.log(sales_inv_ids); 
var sales_inv_amount_paid=$('table tbody tr td input[name="paid_amount_modal[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var sales_inv_doc_num=$('table tbody tr td input[name="inv_doc_numbers_modal[]"]').map(function(){return $(this).val();}).get().join('|#|');
    
$("input[name='ref_sales_inv_id']").val(sales_inv_ids);
$("input[name='ref_sales_inv_amount']").val(sales_inv_amount);
$("input[name='ref_sales_inv_amount_paid']").val(sales_inv_amount_paid);
$("input[name='ref_sales_doc_num']").val(sales_inv_doc_num); 
 // $('.confirm_btn_modal').hide();
      } 
    else{}  
    }); 
      $('.submit_btn').trigger('click');
      $('.modal-close-btn').trigger('click');

    }
    else
    {
       // $('.modal-close-btn').trigger('click');
      alert('Error in paid amount');
    }
}

/////////////////////end of modal functions////////////////////////////////////
function reset_fields()
{
  var amount_tot=$('.amount_to_adj').html();
  $("input[name='paid_amount_modal[]']").val('0');
  $("input[name='refrence']").val('0');
  $('.amount_adjusted').html('0');
  $('.to_be_adjust').html('0');
}

//////modal functions page/////////////////////////////////////////////////

function get_pick_amount(ij_val=null)
{
  var param_data=pass_param();
  var param_val=param_data.split("##");
  var ij=param_val[0];
  var ref_doc_num= param_val[1];

 var form_input_amount=$('input[name="srt_tot_amount"]').val();
  var  to_be_adjust= $('.to_be_adjust').html();
   var  amount_adjusted_till_now= $('.amount_adjusted').html();

   if(amount_adjusted_till_now=='')
     var amount_picked=0;
   else
    var amount_picked=parseFloat(amount_adjusted_till_now);

if(to_be_adjust=='')
   var amount_adjusted=0;
 else
  var amount_adjusted=parseFloat(to_be_adjust);

 if(ij!='')
  {
     console.log('ij '+ij);
  if($('.inv_selected_'+ij).is(':checked'))
  {   
    var total_amount_in_ref=$('.tot_sales_amount_'+ij).val();
    var amount_paid= $('.tot_sales_amount_paid_'+ij).val();
    if(amount_paid=='' || amount_paid=='0')
    { 
         console.log('in if 1');
   $('input[name="refrence"]').val('0');
  // console.log(total_amount_in_ref);
      if(parseFloat(total_amount_in_ref) > parseFloat(form_input_amount))
      { 
         console.log('in if 11');
         if(parseFloat(amount_adjusted)=='0' || parseFloat(amount_adjusted)=='' || parseFloat(amount_adjusted)=='0.00')
        {
           console.log('in if 12');
         var new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(form_input_amount);
         $('.tot_sales_amount_paid_'+ij).val(form_input_amount);
          amount_picked=parseFloat(form_input_amount);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
        }
        else
        {

          console.log('in else 12');
          var new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(amount_adjusted);
         $('.tot_sales_amount_paid_'+ij).val(amount_adjusted);
          amount_picked=parseFloat(amount_picked)+parseFloat(amount_adjusted);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
             
        }
      }
      else if(parseFloat(total_amount_in_ref) < parseFloat(form_input_amount))
      {
           console.log('in if 11.elseif'); 
           if(parseFloat(amount_adjusted)=='0' || parseFloat(amount_adjusted)=='' || parseFloat(amount_adjusted)=='0.00')
          {            
            console.log('in if 12.elseif');
            var new_amount_adjusted=parseFloat(form_input_amount)-parseFloat(total_amount_in_ref);
            $('.tot_sales_amount_paid_'+ij).val(total_amount_in_ref);
            amount_picked=parseFloat(amount_adjusted_till_now)+parseFloat(total_amount_in_ref);
            amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);            
          }         
          else
          {
            console.log('in else 12.elseif');
            var new_amount_adjusted=parseFloat(amount_adjusted)-parseFloat(total_amount_in_ref);
            console.log(new_amount_adjusted);
           $('.tot_sales_amount_paid_'+ij).val(total_amount_in_ref);
            amount_picked=parseFloat(amount_adjusted_till_now)+parseFloat(total_amount_in_ref);
           amount_adjusted=parseFloat(new_amount_adjusted);
          }
       
      }
      else
      { 
        if(amount_adjusted!='0')
          {
             console.log('in else 1.11'+amount_adjusted);
              var new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(amount_adjusted);
                $('.tot_sales_amount_paid_'+ij).val(amount_adjusted);
           amount_picked=parseFloat(amount_picked)+parseFloat(amount_adjusted);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked); 

          }
          else{
         console.log('in else 11');
             if($('input[name="refrence"]').val()=='0')
             {
              console.log('in else 11 - in if 11');
              var new_ref_value=$('input[name="refrence"]').val();
               amount_picked=parseFloat(amount_picked)-parseFloat(new_ref_value);
                amount_adjusted=parseFloat(amount_adjusted)-parseFloat(new_ref_value);
             }
             else
             {
              console.log('in else 11- in else 11');
              $('.tot_sales_amount_paid_'+ij).val(total_amount_in_ref);
              amount_picked=parseFloat(amount_picked)+parseFloat(total_amount_in_ref);
              amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
              }
            }
       }
     }
    else
    { 
     console.log('in else 1- '+ to_be_adjust);
       if( (to_be_adjust!='0.00') )
      {
        if(to_be_adjust!='0')
        {
          console.log('in else 1.1.1');
           var new_ref_val=$('input[name="refrence"]').val();
             $('input[name="refrence"]').val(parseFloat(new_ref_val)+parseFloat(to_be_adjust));
              amount_picked=parseFloat(amount_adjusted_till_now)+parseFloat(to_be_adjust);
              amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);

          
        }
      }
      else
      {
          console.log('in else 1.1.2');
           $('input[name="refrence"]').val($('input[name="refrence"]').val());
      }
    }  
    
  }
  else
  {
    console.log('in else printing to new_ref');
    console.log(form_input_amount);
     $('input[name="refrence"]').val(form_input_amount);
  }
}
else
{
   $('.confirm_btn_modal').show();
   if(to_be_adjust!='0.00')
   {
    $('input[name="refrence"]').val(form_input_amount);
      if( (amount_adjusted_till_now!='') && (amount_adjusted_till_now!='0') )
      {
        amount_picked=amount_adjusted_till_now;
        amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);   
      }
      else
      {
        amount_picked=form_input_amount;
        amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);   
      }  
    }
    else {}
}

  $('.amount_to_adj').html(form_input_amount);
   $('.amount_adjusted').html(amount_picked);
    $('.to_be_adjust').html(amount_adjusted);

    // $('.form_input_ref_'+table_id).val($('.form_input_ref_'+table_id).val() + ref_doc_num+'|#|');
  //   $('.modal-close-btn').trigger('click');
}


function pass_param()
{
  var checked_val=[]; var ref_number_correspond='';var unchecked_val=[];
  $('.class_checkbox').each(function() {
   if ( $(this).is(':checked') )
   {
      if(checked_val=='')
        {
            checked_val=$(this).val();
        }
        else if(jQuery.inArray($(this).val(), checked_val) !== -1)
         {
            checked_val=$(this).val();
         }
         else
          {
            if($(this).val()!=checked_val)///maybe from the unchceked value
            {
              if( $('.tot_sales_amount_paid_'+$(this).val() ).val()=='0' )
              {
                 checked_val=$(this).val();
              }
            }
          }    
    }
 else{
   unchecked_val=$(this).val();  
    $('.confirm_btn_modal').show();
   if(jQuery.inArray($(this).val(), checked_val) == -1)
         {
            checked_val = $.grep(checked_val, function(value) {
              return value != unchecked_val;
            });
         }
    var picked_adjusted_amount= $('.tot_sales_amount_paid_'+unchecked_val).val();
 $('.tot_sales_amount_paid_'+unchecked_val).val('0');
 var amount_adjusted=$('.amount_adjusted').html();
 var to_adjust=$('.to_be_adjust').html();
 var newly_adjusted=parseFloat(amount_adjusted)-parseFloat(picked_adjusted_amount);
$('.amount_adjusted').html(newly_adjusted);
 var new_to_adjust=parseFloat(to_adjust)+parseFloat(picked_adjusted_amount);
$('.to_be_adjust').html(new_to_adjust);

 }
     });
    ref_number_correspond=$('.ref_doc_numbers_'+checked_val).val();
 return checked_val+'##'+ref_number_correspond;
}


function check_val_less_than_amount(ij)
{

  var tot_amount=$('.tot_sales_amount_'+ij).val();
  var paid_amount=$('.tot_sales_amount_paid_'+ij).val();

  var balnce_amount=parseFloat(tot_amount)-parseFloat(paid_amount);
  $('.tot_sales_bal_amount_'+ij).val(balnce_amount.toFixed(2));

  if(parseFloat(paid_amount) > parseFloat(tot_amount))
  {
    $('.amount_overdue_'+ij).html('Paid amount exceeds total amount');
    $('.confirm_btn_modal').hide();
  }
  else
  {
     $('.amount_overdue_'+ij).html('');
    $('.confirm_btn_modal').show();
  }
}

$('.confirm_btn_modal').on('click',function()
{

    $('input[name="choose_inv"]:checked').each(function() {
      var company_selected=$("select[name='srt_company']").find('option:selected').text();
    if(company_selected.includes("KSA")==true)
    {
     var page_type='ksa';
    }
    else if(company_selected.includes("Dragon"))
    {
      var page_type='dragon';
    }
    else if(company_selected.includes("UAE"))
    {
      var page_type='uae';
    }
    else
    { }
        jQuery.ajax({///////////this ajax for getting the form filled/////////////////
       url:"<?php echo base_url().'Sales_return/get_inv_details_checked';?>",
        data:{"checked_inv":this.value,"page_type":page_type},
      type:"post",
       success:function(result)
        {
       //   console.log(result);
          if(result)
          {
         var returndata = JSON.parse(result);
      //  console.log(returndata);
          $('select[name="srt_company"] ').val(returndata['company']).trigger('change');
          $('select[name="srt_salesman"]').val(returndata['salesman']).trigger('change');
          $('select[name="srt_payment_type"]').val(returndata['payment']).trigger('change');
          $('select[name="srt_plc_supply"]').val(returndata['pls_sup']).trigger('change');
          $('select[name="srt_jurisdiction"]').val(returndata['jurisdiction']).trigger('change');
          $('select[name="srt_warehouse"]').val(returndata['warehouse']).trigger('change');
          $('select[name="srt_sales_acc_id"]').val(returndata['sales_ac_id']).trigger('change');
          $('select[name="srt_comp_id"]').val(returndata['company']).trigger('change');
        
          $('input[name="srt_mark"]').val(returndata['mark']);
          $('input[name="srt_delivery_address"]').val(returndata['delivery_addresss']);
          $('input[name="srt_lpo_no"]').val(returndata['lpo_no']);
          $('input[name="srt_bill_no"]').val(returndata['bill_no']);
          $('textarea[name="srt_narration"]').val(returndata['narration']);
          $('input[name="srt_shipping_contact"]').val(returndata['ship_contact']);
          $('input[name="srt_contact"]').val(returndata['customer_contact']);
        //  $('input[name="srt_tot_vat"]').val(returndata['tot_vat']);
         // $('input[name="srt_tot_amount"]').val(returndata['tot_net']);
          $('input[name="sales_inv_id"]').val(returndata['sales_invoice_id']);
          $('input[name="dl_id"]').val(returndata['delivery_note_id']);
         
             if(returndata['currency_val']!=null)
              {
               $('select[name="srt_currency"]').val(returndata['currency']).trigger('change');
               if(returndata['currency_val']!=null)
               $('input[name="srt_conv_value"]').val(returndata['currency_val']);
               else
                 $('input[name="srt_conv_value"]').val('1');
             }
             else
             {
                $('select[name="srt_currency"]').val('AED').trigger('change');
                $('input[name="srt_conv_value"]').val('1');
             }
          //$('.modal_content_sinv').html(result);
          // $('#datatable-default2').DataTable();
          }
        }
       }); 

        jQuery.ajax({////////this ajax for printing the table with data//////////////////
       url:"<?php echo base_url().'Sales_return/get_inv_table_checked';?>",
        data:{"checked_inv":this.value,"page_type":page_type},
      type:"post",
       success:function(result)
        {
          if(result)
          {
           //  console.log(result);
         // $('table tbody .all_table_rows').html(result);
               var returndata = JSON.parse(result);
            //   console.log(returndata);
              $(returndata['html_result']).each(function(key,val) { 
               $('table .all_table_rows').append(val);
             });
              $('.modal-close-btn').click();      
          }
        }
       }); 
  });
});


function get_new_qnty_val(table_id)
{ 
  //console.log(table_id);
  var qnty=$('.qnty'+table_id).val();
  var rate=$('.rate'+table_id).val();
  var current_gross=$('.gross'+table_id).val();

  var tot_gross=parseFloat(qnty)*parseFloat(rate);
//  console.log(tot_gross);
  $('.gross'+table_id).val(tot_gross);

    var dis_per_tbl=$('.dis_per'+table_id).val();

  var dis_amnt_tbl=$('.dis_amount'+table_id).val();
  var add_charge_tbl=$('.add_charges'+table_id).val();

  var tot_dis_per_amont=(parseFloat(dis_per_tbl)/parseFloat(100))*parseFloat(tot_gross);

  $('.dis_per_each_prd'+table_id).val(tot_dis_per_amont);

var tot_fnet_calc=parseFloat(tot_gross)-parseFloat(tot_dis_per_amont)-parseFloat(dis_amnt_tbl)+parseFloat(add_charge_tbl);

  $('.fnet'+table_id).val(tot_fnet_calc);
  var vat_tbl=$('.vat'+table_id).val();

var fent_with_vat=parseFloat(tot_fnet_calc)*(parseFloat(vat_tbl)/parseFloat(100));
$('.vat_each_prd_val'+table_id).val(fent_with_vat);
var tot_fnet_vat=parseFloat(fent_with_vat)+parseFloat(tot_fnet_calc);
  $('.vat_fnet_val'+table_id).val(tot_fnet_vat);

}

///////////////////////modal functions page/////////////////////////////////////////////////

function get_amount_total()
{
  var amountss1='0';
$('table tbody tr td input[name="srt_qnty[]"]').each(function(){
amountss1= parseFloat(amountss1)+parseFloat($(this).val());
}); 
$('.qnty_tot_button').val(parseFloat(amountss1.toFixed(2)));
/////////for gross tot_calc//////////

var amountss_3='0';
$('table tbody tr td input[name="srt_gross[]"]').each(function(){
amountss_3= parseFloat(amountss_3)+parseFloat($(this).val());
}); 
$('.gross_tot_button').val(parseFloat(amountss_3.toFixed(2)));

//////////for dis_per charges tot calc field///////
 var amountss_4='0';
$('table tbody tr td input[name="each_disc_per_amount[]"]').each(function(){
amountss_4= parseFloat(amountss_4)+parseFloat($(this).val());
}); 
$('.dis_per_tot_button').val(parseFloat(amountss_4.toFixed(2)));

//////////for dis_amount charges tot calc field///////
 var amountss_5='0';
$('table tbody tr td input[name="srt_dis_amount[]"]').each(function(){
amountss_5= parseFloat(amountss_5)+parseFloat($(this).val());
}); 
$('.dis_amount_tot_button').val(parseFloat(amountss_5.toFixed(2)));

//////////for add charges tot calc field///////
 var amountss_6='0';
$('table tbody tr td input[name="srt_add_charges[]"]').each(function(){
amountss_6= parseFloat(amountss_6)+parseFloat($(this).val());
}); 
$('.add_charges_tot_button').val(parseFloat(amountss_6.toFixed(2)));

///////for fnet tot calc field///////////
  var amountss_7='0';
$('table tbody tr td input[name="srt_fnet[]"]').each(function(){
amountss_7= parseFloat(amountss_7)+parseFloat($(this).val());
}); 
$('.fnet_tot_button').val(parseFloat(amountss_7.toFixed(2)));

////////////for vat tot calc field//////

  var amountss_8='0';
$('table tbody tr td input[name="each_vat_total[]"]').each(function(){
amountss_8= parseFloat(amountss_8)+parseFloat($(this).val());
}); 
$('.vat_tot_button').val(parseFloat(amountss_8.toFixed(2)));

var final_val='0';
$('.amount_tot_button').val(parseFloat(amountss_8.toFixed(2)) + parseFloat(amountss_7.toFixed(2))  );

//  var amountss_8='0';
// $('table tbody tr td input[name="si_vat[]"]').each(function(){
// amountss_8= parseFloat(amountss_8)+parseFloat($(this).val());
// }); 
// $('.vat_tot_button').val(parseFloat(amountss_8));

//////////show total amount///////////
}

/////////////////////end of modal functions////////////////////////////////////

function check_for_reset()
{
  if (confirm("Are you sure, You want to reset this form?")) {
                 $('.myform').trigger("reset");
            } 
            else {
              return false;
            }
}


 $('.myform').submit(function() {
 //e.preventDefault();

var rowcount = $('.new_rows tr').length;

var prd_ids=$('table tbody tr td input[name="each_prd[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var aray_index_pos=$('table tbody tr td input[name="prd_index_position[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var p_desc=$('table tbody tr td input[name="srt_desc[]"]').map(function(){return $(this).val();}).get().join('|#|');  
var p_units=$('table tbody tr td input[name="srt_units[]"]').map(function(){return $(this).val();}).get().join('|#|');  
var qnty_nos=$('table tbody tr td input[name="srt_qnty[]"]').map(function(){return $(this).val();}).get().join('|#|');
var labels=$('table tbody tr td input[name="srt_label[]"]').map(function(){return $(this).val();}).get().join('|#|');  
var rate_nos=$('table tbody tr td input[name="srt_rate[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var gross_nos=$('table tbody tr td input[name="srt_gross[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var add_charges_nos=$('table tbody tr td input[name="srt_add_charges[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var dis_amount=$('table tbody tr td input[name="srt_dis_amount[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var dis_per=$('table tbody tr td input[name="srt_dis_per[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var fent_nos=$('table tbody tr td input[name="srt_fnet[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
//var p_cogs=$('table tbody tr td input[name="srt_cogs[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var vat_nos=$('table tbody tr td input[name="srt_vat[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

//var delivery_date_nos=$('table tbody tr td input[name="srt_delivery_date[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

//var tax_code_nos=$('table tbody tr td input[name="srt_tax_code[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

//console.log(quantity+' '+package_size+' '+product_id);

$("input[name='hi_prd_id']").val(prd_ids);
$("input[name='hi_prd_desc']").val(p_desc);
$("input[name='hi_aray_index_pos']").val(aray_index_pos);
$("input[name='hi_unit']").val(p_units);
$("input[name='hi_label']").val(labels);
$("input[name='hi_qnty']").val(qnty_nos);
$("input[name='hi_rate']").val(rate_nos);
$("input[name='hi_gross']").val(gross_nos);
$("input[name='hi_add_charges']").val(add_charges_nos);
$("input[name='hi_fnet']").val(fent_nos);
//$("input[name='hi_cogs']").val(p_cogs);
$("input[name='hi_vat']").val(vat_nos);
//$("input[name='hi_delivery_date']").val(delivery_date_nos);
//$("input[name='hi_tax_code']").val(tax_code_nos);

var ij=0;
var data_var=[];

$('.new_rows tr td').each(function() { 
var cellText = $(this).html(); 
 //  console.log(cellText);  
    $('.cell_text_data').append(cellText).hide(); 
});

 // console.log($("input[name='hi_prd_id']").val());
 //  console.log($("input[name='hi_unit']").val());
 //   console.log($("input[name='hi_qnty']").val());
 //      console.log($("input[name='hi_vat']").val());
//console.log(cellText);
/// console.log($("input[name='hid_salesman']").val());
// console.log($("input[name='hid_customer']").val());
// console.log($("input[name='hid_amounts']").val());
// console.log($("input[name='hid_remark']").val());
//  console.log($("input[name='hid_ref']").val());
//var table_row_added=$('.new_rows').html();

 if ($('.new_rows tr').length == 0) 
 {
  alert('Please choose items to add and submit');
  return false;
 }
 else
 { 
  return true;
 }
 //return false;
  // your code here
});
 // }
        </script>

</body>

</html>