<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2><?php echo $this->lang->line('List_Sales_invoice'); ?></h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span><?php echo $this->lang->line('List'); ?></span></li>
<li><span><?php echo $this->lang->line('List_Sales_invoice'); ?></span></li>
</ol>
<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
</div>
</header>

<!-----section for lightbox opens here-->
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title"><?php echo $this->lang->line('List_Sales_invoice'); ?><span class="pull-right"><a href="<?php echo base_url('sales-invoice/'.$page_type);?>" class="btn btn-primary"><?php echo $this->lang->line('Click_to_create'); ?></a></span></h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
	<?php echo form_open_multipart('list-sales-invoice/'.$page_type,'class="myform" id="formInv"','');?>
							<select name="sortBy" id="sortBy">
								<option value="" <?php if($sort_by == ''){ echo 'selected'; } ?>><?php echo $this->lang->line('Sort_by_payment'); ?></option>
								<option value="paid" <?php if($sort_by == 'paid'){ echo 'selected'; } ?>><?php echo $this->lang->line('Paid'); ?></option>
								<option value="partially_paid" <?php if($sort_by == 'partially_paid'){ echo 'selected'; } ?>><?php echo $this->lang->line('Partially_Paid'); ?></option>
								<option value="not_paid" <?php if($sort_by == 'not_paid'){ echo 'selected'; } ?>><?php echo $this->lang->line('Not_paid'); ?></option>								
							</select>
						<?php echo form_close();?>
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th class="action_class"><?php echo $this->lang->line('Action'); ?></th>

<th><?php echo $this->lang->line('Doc_No'); ?></th>
<th><?php echo $this->lang->line('Date'); ?></th>
<th><?php echo $this->lang->line('Company'); ?></th>
<th><?php echo $this->lang->line('Customer'); ?> </th>
<th><?php echo $this->lang->line('Narration'); ?></th>
<th><?php echo $this->lang->line('Due_Amount'); ?></th>
<th><?php echo $this->lang->line('Total_Amount'); ?></th>
<th><?php echo $this->lang->line('Delivery_Status'); ?></th>
<th><?php echo $this->lang->line('Status'); ?></th>
</tr>
</thead>
<tbody>
<?php
if(!empty($result))
{
	$i=1;
foreach($result as $t)
{
	
	?>
<tr>
<td class="action_class">
			<div class="dropdown-primary dropdown " <?php if($i==1){echo "style='display:contents';";};?>>
<button class="btn btn-primary dropdown-toggle waves-effect waves-light" type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" ><?php echo $this->lang->line('Action'); ?> </button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">
	<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalmd_sinv" onclick="get_doc_details(<?php echo $t['si_id'];?>,'<?php echo $page_type;?>');"><i class="fa fa-eye"></i><?php echo $this->lang->line('View'); ?></a>
<?php
if($this->session->userdata['user']['role'] !='1'||$this->session->userdata['user']['main_dept']=="Main")
{
if($t['si_current_sts']=="not-paid"||"partially_paid")
{?>
<div class="dropdown-divider"></div>

<a class="dropdown-item waves-light waves-effect modalmd_edit" href="<?php echo base_url('Sales_invoice/sales_invoice_page/'.$page_type.'/'.$t['si_id']);?>"  ><i class="fa fa-pencil"></i><?php echo $this->lang->line('Edit_Details'); ?></a>
<?php } ?>
<a class="dropdown-item waves-light waves-effect modalmd_edit"  style="display: none;" ><i class="fa fa-pencil"></i><?php echo $this->lang->line('Open_edit_modal'); ?></a>

<?php

}
else
{
	if($t['si_delivery_sts']!='delivered')
{
	
	
	?>
<div class="dropdown-divider"></div>

<a class="dropdown-item waves-light waves-effect modalmd_edit" href="<?php echo base_url('Sales_invoice/sales_invoice_page/'.$page_type.'/'.$t['si_id']);?>"  ><i class="fa fa-pencil"></i><?php echo $this->lang->line('Edit_Details'); ?></a>
<a class="dropdown-item waves-light waves-effect modalmd_edit"  style="display: none;" ><i class="fa fa-pencil"></i><?php echo $this->lang->line('Open_edit_modal'); ?> </a>

<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalsm2<?php echo $t['si_id'];?>"><i class="fa fa-trash-o"></i><?php echo $this->lang->line('Delete'); ?> </a>
<?php
}
else{}
}?>	
<div class="dropdown-divider"></div>
<!-- <a class="dropdown-item waves-light waves-effect" href=""><i class="fa fa-pdf"></i>Generate PDF </a> -->
<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalsm_pdf<?php echo $t['si_id'];?>"><i class="fa fa-pdf"></i><?php echo $this->lang->line('Generate_Pdf'); ?></a>
</div>
	</td>	
	<td><?php echo $t['si_doc_no'];?></td>
	<td><?php echo $t['si_date'];?> </td>
	<td><?php echo $t['mcomp_name'];?> </td>	
	<td><?php echo $t['cust_acc'];?></td>		
	<td><?php echo $t['si_narration'];?></td>	
	<td><?php echo round($t['atx_bal_amount'],2); ?></td>
	<td><?php echo round($t['si_tot_amount'],2); ?></td>
	<td>
		<?php if($t['si_delivery_sts']=="not_delivered")
			{
				?>
			<span class="label label-danger"><?php echo $this->lang->line('Not_Delivered'); ?></span>
			<?php
			}

              else if($t['si_delivery_sts']=="fully_returned")
			{
				?>
			<span class="label label-warning"><?php echo $this->lang->line('Returened_All'); ?></span>
			<?php
			}
			else if($t['si_delivery_sts']=="partially_returned")
			{
				?>
			<span class="label label-warning"><?php echo $this->lang->line('partially_Returened'); ?></span>
			<?php
			}
				else if($t['si_delivery_sts']=="partially_delivered")
			{
				?>
			<span class="label label-warning"><?php echo $this->lang->line('Partially_Delivered'); ?></span>
			<?php
			}
       else if($t['si_delivery_sts']=="wrong_deliverd")
			{
				?>
			<span class="label label-warning"><?php echo $this->lang->line('Wrong_Delivered'); ?></span>
			<?php
			}
			else if($t['si_delivery_sts']=="delivered")
			{
				?>
				<span class="label label-success"><?php echo $this->lang->line('Delivered'); ?></span>
		
				<?php
			}
			?>
	</td> 
 <td>	
		<?php if($t['si_current_sts']=="not-paid")
		{
			?>
		<span class="label label-danger"><?php echo $this->lang->line('Not_paid'); ?></span>
		<?php
		}
		elseif($t['si_current_sts']=="fully-paid")
		{
			?>
	<span class="label label-success"><?php echo $this->lang->line('Paid'); ?></span>	
			<?php
		}
		else
		{
			?>
			<span class="label label-warning"><?php echo $this->lang->line('Partially_Paid'); ?></span>
	
			<?php
		}
		?>
	</td> 	 
</tr>

<!-- Button trigger modal 3-->
 <div id="modalsm2<?php echo $t['si_id'];?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"><?php echo $this->lang->line('Are You Sure?'); ?></h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<p>  <?php echo $this->lang->line('Are you sure, you want to delete this payment details permanently?'); ?>
			<small style="color: red"><?php echo $this->lang->line('This action cannot be undone?'); ?>.</small>
		</p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<a href="<?php echo base_url('Sales_invoice/delete_invoice/'.$page_type.'/'.$t['si_id']);?>"  class="btn btn-primary"><?php echo $this->lang->line('Confirm'); ?></a>
<button class="btn btn-default modal-dismiss"><?php echo $this->lang->line('Cancel'); ?></button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!----end modal--->
<!-- Button trigger modal 3-->
 <div id="modalsm_pdf<?php echo $t['si_id'];?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"><?php echo $this->lang->line('Generate PDF'); ?></h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
	<?php echo form_open('Sales_invoice/generate_invoice_pdf/'.$page_type);?>
		<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"><?php echo $this->lang->line('Choose option to print Invoice as'); ?><abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
	<input type="hidden" name="sales_inv_id" value="<?php echo $t['si_id'];?>">
 <input type='radio' name="pdf-print-option" value="1" ><?php echo $this->lang->line('With Letter-head'); ?><br/>
 <input type='radio' name="pdf-print-option" value="2" ><?php echo $this->lang->line('Without Letter-head'); ?><br/>
</div>
</div>

</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit" class="btn btn-primary"><?php echo $this->lang->line('Confirm'); ?></button>
<button class="btn btn-default modal-dismiss"><?php echo $this->lang->line('Cancel'); ?></button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!----end modal--->

<?php
$i++;
}
}?>
</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->
<!-- Button trigger modal for sales invoice-->
 <div id="modalmd_sinv" class="modal-block modal-block-lg mfp-hide" style="width: 100%;">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Reference Details </h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text modal_content_sinv">
   
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<!-- <button type="button" onclick="submit_sales_inv_amount()"  class="btn btn-primary confirm_btn_modal">Confirm</button> -->
<button class="btn btn-default modal-dismiss modal-close-btn">Close</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal--->
</section>
</div>

</section>


<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
<a href="#" class="mobile-close visible-xs">
Collapse <i class="fa fa-chevron-right"></i>
</a>
<div class="sidebar-right-wrapper">

<div class="sidebar-widget widget-friends ">

<div class="chat_window">
<?php $this->load->view('admin/master_essential/chat_data',$chat);?>

</div>
</div>
</div>
</div>
</div>
</aside>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	 $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 10,
    responsive: true,
     "scrollX": true,
     } );
} );

	    function get_doc_details(cbr_id,page_name)
 	{
 		 jQuery.ajax({
               url:"<?php echo base_url().'Sales_invoice/get_doc_details';?>",
                data:{"main_id":cbr_id,"page_name":page_name},
              type:"post",
               success:function(result)
              {
                if(result)
                {
               //console.log(result);
                	$('.modal_content_sinv').html(result);
                	  $('#datatable-default2').DataTable( {
              "scrollX": true,
        "pageLength": 10,
    responsive: true,
    
     } );
              //  $("input[name='cbr_rate_currency']").val(result);
                }
              }
               });
 	}

 	function check_edit(cbr_id,page_name)
 	{
 		 jQuery.ajax({
               url:"<?php echo base_url().'Receipt_Master/check_edit';?>",
                data:{"main_id":cbr_id,'type':'Sales_Invoice',"page_name":page_name},
              type:"post",
               success:function(result)
              {
                if(result)
                {
                	  var href = $('.modalmd_edit').attr('href');
      				window.location.href = href;
                 }
                else
                {
                	alert('Edit is suspended .');
                }
              }
               });
 	}
	 $('#sortBy').on('change', function() {
			$('#formInv').submit();
		});
</script>

 

</body>
</html>