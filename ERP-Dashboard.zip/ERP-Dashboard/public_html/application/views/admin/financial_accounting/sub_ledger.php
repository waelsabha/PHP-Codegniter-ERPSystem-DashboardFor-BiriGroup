<!doctype html>
<html class="fixed">

<head>

<?php
$html='Account Statement for ';
if(!empty($result)){
	$html.=$account_name[0]->label;
	}
$html.=' FROM ';
if(!empty($form_input))
	{
		$html.=$form_input['start_date'];
	}
$html.=' TO ';
if(!empty($form_input))
	{
		$html.= $form_input['end_date'];
	}
	$header_data['data']=$html;

	if(!empty($header_data))
		$this->load->view('admin/head',$header_data);
	else
		$this->load->view('admin/head');
?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2> Sub Ledger</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Sub Ledger</span></li>
</ol>
<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
</div>
</header>

<!-----section for lightbox opens here-->
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Choose Data </h2>

</header>
<div class="panel-body">
	<?php echo form_open_multipart('Ledger/submit_sub_ledger','class="form-horizontal form-bordered ledger_form_class"');?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
	<div class="row">
  <div class="col-sm-12 table-rows-border" align="center">
  		<div class="form-group">
		<label class="col-md-4 control-label" for="inputPlaceholder">Account Master<abbr class="required">::*::</abbr>

		</label>
		<div class="col-md-8">
		 <select data-plugin-selectTwo  class="form-control populate" name="acc_master_id">
		 	 <option value="">Choose</option>
		 	<?php
		 	foreach($acc as $ac)
		 	{
		 		?>
			  <option value="<?php echo $ac->id;?>" <?php if(!empty($form_input)){if($form_input['acc_master_id']==$ac->id){echo "selected";}else{}};?>><?php echo $ac->label;?></option>
		 	<?php
		 	}?>
		</select>
		  <div class="form_error">  <?php echo $this->session->flashdata('cbr_due_date');?></div>
		</div>
		</div>
	</div>
</div>

<div class="row" style="margin-top: 2%">
	<div class="col-sm-12 table-rows-border" align="center">
		<div class="form-group">
		<label class="col-md-4 control-label" for="inputPlaceholder">Start Date<abbr class="required">::*::</abbr>
		</label>
		<div class="col-md-8">
		 <input type='text' name="start_date" class="form-control datetimepicker4" value="<?php if(!empty($form_input)){echo $form_input['start_date'];}else{ echo date('01/01/Y');};?>" required />
		  <div class="form_error">  <?php echo $this->session->flashdata('cbr_due_date');?></div>

		</div>
		</div>
	</div>
</div>

<div class="row" style="margin-top: 2%">
	<div class="col-sm-12 table-rows-border" align="center">
		<div class="form-group">
		<label class="col-md-4 control-label" for="inputPlaceholder">End Date<abbr class="required">::*::</abbr>
		</label>
		<div class="col-md-8">
		 <input type='text' name="end_date" class="form-control datetimepicker4" value="<?php if(!empty($form_input)){echo $form_input['end_date'];}else{echo date('m/d/Y');};?>" required />
		  <div class="form_error">  <?php echo $this->session->flashdata('cbr_due_date');?></div>

		</div>
	</div>
</div>
</div>

<div class="row" style="margin-top: 2%">
	<div class="col-sm-12 table-rows-border" align="center">
		<div class="form-group">
		<label class="col-md-4 control-label" for="inputPlaceholder">Type<abbr class="required">::*::</abbr>

		</label>
		<div class="col-md-8">
		  <select class="form-control populate" name="type">
		 	 <option value="all" <?php if(!empty($form_input)){if($form_input['type']=="all"){echo "selected";}else{}};?>>All Transactions</option>
		 	  <option value="credit" <?php if(!empty($form_input)){if($form_input['type']=="credit"){echo "selected";}else{}};?>>Credit Transactions</option>
		 	   <option value="debit" <?php if(!empty($form_input)){if($form_input['type']=="debit"){echo "selected";}else{}};?>>Debit Transactions</option>	 	
		</select>
		  <div class="form_error">  <?php echo $this->session->flashdata('type');?></div>
		</div>
	</div>
</div>
</div>

<div class="row" style="margin-top: 2%">
	<div class="col-sm-12 table-rows-border" align="center">
		<div class="form-group">
		<label class="col-md-4 control-label" for="inputPlaceholder">Sub-ledger Type<abbr class="required">::*::</abbr>

		</label>
		<div class="col-md-8">
		  <select class="form-control populate" name="s_type">


              <option value="org" <?php if(!empty($form_input)){if($form_input['s_type']=="org"){echo "selected";}else{}};?>>Original Currency Type
		 	  </option>
		 	 <option value="std" <?php if(!empty($form_input)){if($form_input['s_type']=="std"){echo "selected";}else{}};?>>Standard Format</option>
		 	
		 	  
		</select>
		  <div class="form_error">  <?php echo $this->session->flashdata('s_type');?></div>
		</div>
	</div>
</div>
</div>

<div class="row" style="margin-top: 2%;">
<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
</div>
<?php echo form_close();?>
</div>
	</section>
	
	<section class="panel" >
		<header class="panel-heading">

<h2 class="panel-title">Account Statement for <span style="color: blue;?>"><?php if(!empty($result)){echo $account_name[0]->label;}?></span> from <span style="color: blue;?>"><?php if(!empty($form_input)){echo $form_input['start_date'];};?></span> to <span style="color: blue;?>"><?php if(!empty($form_input)){echo $form_input['end_date'];};?></span> </h2>

</header>
	<div class="panel-body">
		
<div class="data_result">
<?php 
if(!empty($old_result))
{
	$old_bal= number_format((float)$old_result, 2, '.', '');
}
else
{
		$old_bal= '0';
}
$credit_sum=0;
$debit_sum=0;
?>
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default-2">
<thead>
<tr>
<th>Date</th>
<th>Due Date</th>
<th>Voucher No.</th>
<th>Account Name</th>
<th>Narration</th>

<th>Cheque No</th>
<th>Bill No</th>

<th>Debit</th>
<th>Credit</th>
<th>Balance</th>
</tr>
</thead>
<tbody>
	<tr>
	
	<td> </td>
			<td></td>
			<td></td>
			<td>Opening Balance</td>
			<td></td>
			<td></td>
			<td></td>
			<td><?php if($old_bal>0){echo $old_bal; 
			$debit_sum=$old_bal;}?></td>
			<td><?php if($old_bal<0){echo $old_bal; 
			$credit_sum=abs($old_bal);}?></td>
	<td><b><?php 
if(!empty($old_result))
{
	echo number_format((float)$old_result, 2, '.', '');
}
else
{
	echo '0';
}
?></b></td>
	
</tr>
<?php
if(!empty($old_result))
{
	$amount_balance=number_format((float)$old_result, 2, '.', '');
}
else
{
$amount_balance=0;
}

$total_bal_sum=0;
foreach($result as $indx=>$r)
{
	if($r['atx_tranfer_type']=="journal")
	{
		$jrn_qry=$this->db->query("SELECT * from cash_bank_journals where cbr_id=".$r['atx_main_id']." ");
		$jrn_result=$jrn_qry->result_array();

		$jrn_cust=explode('|#|',$jrn_result[0]['cbr_customer_acc']);
		$jrn_debits=explode('|#|',$jrn_result[0]['cbr_debit']);
		$jrn_credits=explode('|#|',$jrn_result[0]['cbr_credit']);
		$jrn_vats=explode('|#|',$jrn_result[0]['cbr_vat']);

			if(in_array($r['atx_acc_id'], $jrn_cust))
					{
						$cust_key=array_search($r['atx_acc_id'], $jrn_cust);
						$vat_val_cust=$jrn_vats[$cust_key];
						if(!empty($vat_val_cust))///the amount has vat, so reduce it from the total
						{
							$total_to_use_for_customer=$r['atx_tot_amount']*$r['atx_currency_value'];
						}
						else{
							$total_to_use_for_customer=$r['atx_tot_amount']*$r['atx_currency_value']+$r['atx_vat_amount']*$r['atx_currency_value'];
						}	
					}
			elseif(in_array($r['atx_cust_id'], $jrn_cust))
				{
					$cust_key=array_search($r['atx_cust_id'], $jrn_cust);
						$vat_val_cust=$jrn_vats[$cust_key];
						if(!empty($vat_val_cust))///the amount has vat, so reduce it from the total
						{
							$total_to_use_for_customer=$r['atx_tot_amount']*$r['atx_currency_value'];
						}
						else{
							$total_to_use_for_customer=$r['atx_tot_amount']*$r['atx_currency_value']+$r['atx_vat_amount']*$r['atx_currency_value'];
						}	
				}
				else{
					$total_to_use_for_customer=0;
				}
					
	}
	elseif($r['atx_type_tx']=="Sales_Invoice")
	{
//echo "type is si";
			if($form_input['acc_master_id']==$r['atx_acc_id'])
			{
				if(!empty($r['atx_vat_amount']))///the amount has vat, so reduce it from the total
				{
					$total_to_use_for_customer=$r['atx_tot_amount']*$r['atx_currency_value']-$r['atx_vat_amount']*$r['atx_currency_value'];
				}
				else
				{
					$total_to_use_for_customer=$r['atx_tot_amount']*$r['atx_currency_value'];
				}	
			}
			else
			{
				//echo $r['atx_currency_value'];echo "<br/>";
				$total_to_use_for_customer=$r['atx_tot_amount']*$r['atx_currency_value'];
				//echo $total_to_use_for_customer;
			}
	}
	elseif($r['atx_type_tx']=="Sales_Return")
	{
//echo "type is si";
			if($form_input['acc_master_id']==$r['atx_acc_id'])
			{
				if(!empty($r['atx_vat_amount']))///the amount has vat, so reduce it from the total
				{
					$total_to_use_for_customer=$r['atx_tot_amount']*$r['atx_currency_value']-$r['atx_vat_amount']*$r['atx_currency_value'];
				}
				else
				{
					$total_to_use_for_customer=$r['atx_tot_amount']*$r['atx_currency_value'];
				}	
			}
			else
			{
				//echo $r['atx_currency_value'];echo "<br/>";
				$total_to_use_for_customer=$r['atx_tot_amount']*$r['atx_currency_value'];
				//echo $total_to_use_for_customer;
			}
	}
	else{}
	if($form_input['acc_master_id']==$r['atx_acc_id'])////means its an account bank or sales accont
	{
		//echo "its a main account";echo "<br/>";
		if($r['atx_acc_id']=='1014' )////making sure the account is not a vat account
		{
			if($r['atx_amount_type']=="Expense")
			{
				//$amount_balance=$amount_balance-$r['atx_tot_amount'];
				$amount_balance=$amount_balance+$r['atx_tot_amount']*$r['atx_currency_value'];
					$debit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
				$debit_sum=$debit_sum+$debit_amount;
				$total_bal_sum=$total_bal_sum+$amount_balance;
				$credit_amount='0';
			}
			else
			{
				 $amount_balance=$amount_balance-$r['atx_tot_amount']*$r['atx_currency_value'];
					$credit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
				//$amount_balance=$amount_balance+$r['atx_tot_amount'];
				$credit_sum=$credit_sum+$credit_amount;
				$total_bal_sum=$total_bal_sum+$amount_balance;
				$debit_amount='0';
			}
		// $amount_balance=0;
		}
		elseif($r['atx_acc_id']=='1016' )////making sure the account is not a vat account
		{
			if($r['atx_amount_type']=="Expense")
			{
				$amount_balance=$amount_balance+$r['atx_tot_amount']*$r['atx_currency_value'];
					$debit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
				//$amount_balance=$amount_balance-$r['atx_tot_amount'];
				$debit_sum=$debit_sum+$debit_amount;
				$total_bal_sum=$total_bal_sum+$amount_balance;
				$credit_amount='0';
			}
			else
			{
				 $amount_balance=$amount_balance-$r['atx_tot_amount']*$r['atx_currency_value'];
					$credit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
				//$amount_balance=$amount_balance+$r['atx_tot_amount'];
				$credit_sum=$credit_sum+$credit_amount;
				$total_bal_sum=$total_bal_sum+$amount_balance;
				$debit_amount='0';
			}
		// $amount_balance=0;
		}
		elseif($r['atx_acc_id']=='1013')
		{
			if($r['atx_amount_type']=="Expense")
			{
				$amount_balance=$amount_balance+$r['atx_tot_amount']*$r['atx_currency_value'];
					$debit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
				//$amount_balance=$amount_balance-$r['atx_tot_amount'];
				$debit_sum=$debit_sum+$debit_amount;
				$total_bal_sum=$total_bal_sum+$amount_balance;
				 $credit_amount='0';
			}
			else
			{
				 $amount_balance=$amount_balance-$r['atx_tot_amount']*$r['atx_currency_value'];
					$credit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
				//$amount_balance=$amount_balance+$r['atx_tot_amount'];
				$credit_sum=$credit_sum+$credit_amount;
				$total_bal_sum=$total_bal_sum+$amount_balance;
				  $debit_amount='0';
			}
		}
		elseif($r['atx_acc_id']=='759')
		{
		//	echo "its a main account-ksa vat account";echo "<br/>";
			if($r['atx_amount_type']=="Expense")
			{
					$amount_balance=$amount_balance+$r['atx_tot_amount']*$r['atx_currency_value'];
					$debit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 					
				//$amount_balance=$amount_balance-$r['atx_tot_amount'];
				$debit_sum=$debit_sum+$debit_amount;
				$total_bal_sum=$total_bal_sum+$amount_balance;
				 $credit_amount='0';
			}
			else
			{				
					$amount_balance=$amount_balance-$r['atx_tot_amount']*$r['atx_currency_value'];
					$credit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
					
				//$amount_balance=$amount_balance+$r['atx_tot_amount'];
				$credit_sum=$credit_sum+$credit_amount;
				$total_bal_sum=$total_bal_sum+$amount_balance;
				  $debit_amount='0';
			}
		}
		else
		{
			if($r['atx_amount_type']=="Expense")
			{
				//echo"in expense";
				if(!empty($r['atx_vat_amount']))
				{	
					echo"in expense-with vat";

					if(!empty($total_to_use_for_customer))
					{
						 $amount_balance=$amount_balance+$total_to_use_for_customer;
						 $debit_amount=$total_to_use_for_customer;
					}
					else
					{
							$amount_balance=$amount_balance+($r['atx_tot_amount']*$r['atx_currency_value'] + $r['atx_vat_amount']*$r['atx_currency_value']);
							 $debit_amount=$r['atx_tot_amount']*$r['atx_currency_value']-$r['atx_vat_amount']*$r['atx_currency_value'];////reduce vat from total if present 
					}
				 	 //$amount_balance=$amount_balance-$r['atx_tot_amount']-$r['atx_vat_amount'];///old way of calc
					// $amount_balance=$amount_balance+($r['atx_tot_amount']+$r['atx_vat_amount']);
					 //$debit_amount=$r['atx_tot_amount']-$r['atx_vat_amount'];
					 	$debit_sum=$debit_sum+$debit_amount;
						$total_bal_sum=$total_bal_sum+$amount_balance;
				}
				else
				{
					//echo"in expense-without vat";
					  $amount_balance=$amount_balance+$r['atx_tot_amount']*$r['atx_currency_value'];
									 $debit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total  
					//$amount_balance=$amount_balance-$r['atx_tot_amount'];///old way of calc
					
					 	$debit_sum=$debit_sum+$debit_amount;
						$total_bal_sum=$total_bal_sum+$amount_balance;
				}
				 $credit_amount='0';
			}
			else
			{
			//	echo"in income";
				if(!empty($r['atx_vat_amount']))
				{
				//	echo"in income-with vat";
					if(!empty($total_to_use_for_customer))
					{
						 $amount_balance=$amount_balance+$total_to_use_for_customer;
						 $credit_amount=$total_to_use_for_customer;
					}
					else
					{
						$amount_balance=$amount_balance-($r['atx_tot_amount']*$r['atx_currency_value']+$r['atx_vat_amount']*$r['atx_currency_value']);
								 $credit_amount=$r['atx_tot_amount']*$r['atx_currency_value']+$r['atx_vat_amount']*$r['atx_currency_value'];////reduce vat from total if present 
					}
					//$amount_balance=$amount_balance+$r['atx_tot_amount']-$r['atx_vat_amount'];///old way of calc
				 	 //$amount_balance=$amount_balance-($r['atx_tot_amount']-$r['atx_vat_amount']);
					// $credit_amount=$r['atx_tot_amount']-$r['atx_vat_amount'];////reduce vat from total if present 
					 $credit_sum=$credit_sum+$credit_amount;
									$total_bal_sum=$total_bal_sum+$amount_balance;
				}
				else
				{
					//	echo"in income-without vat";
					//$amount_balance=$amount_balance+$r['atx_tot_amount'];///old way of calc
						$amount_balance=$amount_balance-$r['atx_tot_amount']*$r['atx_currency_value'];
									$credit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];////else show full total 
					
					$credit_sum=$credit_sum+$credit_amount;
									$total_bal_sum=$total_bal_sum+$amount_balance;
				}
				  $debit_amount='0';
			}
		}
	}
	else
	{
		//pre_list($r);
		//echo "in expense 2";echo "<br/>";
			if($r['atx_amount_type']=="Expense")
			{
				//echo "its an exp";echo "<br/>";
				// $amount_balance=$amount_balance+$r['atx_tot_amount'];//old order
				if(!empty($total_to_use_for_customer))
					{
						 $amount_balance=$amount_balance+$total_to_use_for_customer;
						 $debit_amount=$total_to_use_for_customer;
					}
					else
					{
					 $amount_balance=$amount_balance+$r['atx_tot_amount']*$r['atx_currency_value'];
						$debit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];
					}
							
				 $amount_balance=$amount_balance-$r['atx_tot_amount']*$r['atx_currency_value'];
				 $credit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];
				$credit_sum=$credit_sum+$credit_amount;
									$total_bal_sum=$total_bal_sum+$amount_balance;
				$debit_amount='0';
			}
			else
			{
				//echo "its an income";echo "<br/>";
				// $amount_balance=$amount_balance-$r['atx_tot_amount'];//old order
					if(!empty($total_to_use_for_customer))
					{
						 $amount_balance=$amount_balance+$total_to_use_for_customer;
						 $debit_amount=$total_to_use_for_customer;
					}
					else
					{
								 $amount_balance=$amount_balance+$r['atx_tot_amount']*$r['atx_currency_value'];
								 $debit_amount=$r['atx_tot_amount']*$r['atx_currency_value'];
					}			 
							
				$debit_sum=$debit_sum+$debit_amount;
						$total_bal_sum=$total_bal_sum+$amount_balance;
				$credit_amount='0';
			}
			
		// $amount_balance=0;
	}

?>	
<tr>
	<td><?php echo $r['atx_date'];?></td>
	 <td><!--<?php echo $r['mact_due_date'];?>--></td> 
	<td><a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes sales_invoice_modal_a" href="#modalmd_sinv" onclick="get_doc_details(<?php echo $r['atx_id'];?>,'<?php echo $r['atx_region'];?>');"><?php echo $r['atx_doc_no'];?></a></td>
	<td><?php
	if($r['acc_name_bank_sales']==$account_name[0]->label)
	{
		echo $r['cust_acc_name'];
	}
	else
	{
		echo $r['acc_name_bank_sales'];
	}
	?></td>
	<td><?php echo $r['atx_narration'];?></td>
	
	<td> <?php echo $r['atx_cheque_no'];?></td>
	<td><?php echo $r['atx_bill_no'];?></td>

		<td><?php if(!empty($debit_amount)){echo number_format((float)$debit_amount, 2, '.', '');}else{echo "0";}?></td>
	<td><?php if(!empty($credit_amount)){echo number_format((float)$credit_amount, 2, '.', '');}else{echo "0";}?></td>
	<td> <?php 
	 echo number_format((float)$amount_balance, 2, '.', '');
    ?>
</td>
</tr>
<?php
}?>


<?php
if(!empty($amount_balance))
{
	$amount_balance22=$amount_balance;
}
else
{
	$amount_balance22=0;
}
if(!empty($result2))
{
foreach($result2 as $indx=>$r)
{
	if(!empty($r['atx_id']))
	{
	//echo "in result 2";
	if($form_input['acc_master_id']==$r['atx_acc_id'])////means its an account bank or sales accont
	{
		if($r['atx_acc_id']=='1014' )////making sure the account is not a vat account
		{
			if($r['atx_amount_type']=="Expense")
			{
				//$amount_balance=$amount_balance-$r['atx_tot_amount'];
				$amount_balance22=$amount_balance22+$r['atx_tot_amount']*$r['atx_currency_value'];
				$debit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
					$debit_sum=$debit_sum+$debit_amount22;
						$total_bal_sum=$total_bal_sum+$amount_balance22;
				$credit_amount22='0';
			}
			else
			{
				 
				//$amount_balance=$amount_balance+$r['atx_tot_amount'];
				$amount_balance22=$amount_balance22-$r['atx_tot_amount']*$r['atx_currency_value'];
				$credit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];////else show full total 
				$credit_sum=$credit_sum+$credit_amount22;
									$total_bal_sum=$total_bal_sum+$amount_balance22;
				$debit_amount22='0';
			}
		// $amount_balance=0;
		}
		if($r['atx_acc_id']=='1016' )////making sure the account is not a vat account
		{
			if($r['atx_amount_type']=="Expense")
			{
				//$amount_balance=$amount_balance-$r['atx_tot_amount'];
				$amount_balance22=$amount_balance22+$r['atx_tot_amount']*$r['atx_currency_value'];
				$debit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
					$debit_sum=$debit_sum+$debit_amount22;
						$total_bal_sum=$total_bal_sum+$amount_balance22;
				$credit_amount22='0';
			}
			else
			{
				 
				//$amount_balance=$amount_balance+$r['atx_tot_amount'];
				$amount_balance22=$amount_balance22-$r['atx_tot_amount']*$r['atx_currency_value'];
				$credit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];////else show full total 
				$credit_sum=$credit_sum+$credit_amount22;
									$total_bal_sum=$total_bal_sum+$amount_balance22;
				$debit_amount22='0';
			}
		// $amount_balance=0;
		}
		elseif($r['atx_acc_id']=='1013')
		{
			if($r['atx_amount_type']=="Expense")
			{
				//$amount_balance=$amount_balance-$r['atx_tot_amount'];
				 $amount_balance22=$amount_balance22+$r['atx_tot_amount']*$r['atx_currency_value'];
				$debit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
				$debit_sum=$debit_sum+$debit_amount22;
						$total_bal_sum=$total_bal_sum+$amount_balance22;
				 $credit_amount22='0';
			}
			else
			{
			//$amount_balance=$amount_balance+$r['atx_tot_amount'];
					$amount_balance22=$amount_balance22-$r['atx_tot_amount']*$r['atx_currency_value'];
					$credit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];////else show full total 
						$credit_sum=$credit_sum+$credit_amount22;
									$total_bal_sum=$total_bal_sum+$amount_balance22;
				  $debit_amount22='0';
			}
		}
		elseif($r['atx_acc_id']=='759')
		{
			if($r['atx_amount_type']=="Expense")
			{
				//$amount_balance=$amount_balance-$r['atx_tot_amount'];
				 $amount_balance22=$amount_balance22+$r['atx_tot_amount']*$r['atx_currency_value'];
				$debit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
				$debit_sum=$debit_sum+$debit_amount22;
						$total_bal_sum=$total_bal_sum+$amount_balance22;
				 $credit_amount22='0';
			}
			else
			{
			//$amount_balance=$amount_balance+$r['atx_tot_amount'];
					$amount_balance22=$amount_balance22-$r['atx_tot_amount']*$r['atx_currency_value'];
					$credit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];////else show full total 
						$credit_sum=$credit_sum+$credit_amount22;
									$total_bal_sum=$total_bal_sum+$amount_balance22;
				  $debit_amount22='0';
			}
		}
		else
		{
			if($r['atx_amount_type']=="Expense")
			{
				if(!empty($r['atx_vat_amount']))
				{
				 	 //$amount_balance=$amount_balance-$r['atx_tot_amount']-$r['atx_vat_amount'];///old way of calc
					 $amount_balance22=$amount_balance22+($r['atx_tot_amount']*$r['atx_currency_value']-$r['atx_vat_amount']*$r['atx_currency_value']);
					 $debit_amount22=$r['atx_tot_amount']*$r['atx_currency_value']-$r['atx_vat_amount']*$r['atx_currency_value'];////reduce vat from total if present 
					 $debit_sum=$debit_sum+$debit_amount22;
						$total_bal_sum=$total_bal_sum+$amount_balance22;
				}
				else
				{
					//$amount_balance=$amount_balance-$r['atx_tot_amount'];///old way of calc
					 $amount_balance22=$amount_balance22+$r['atx_tot_amount']*$r['atx_currency_value'];
					 $debit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];	////else show full total 
					 $debit_sum=$debit_sum+$debit_amount22;
						$total_bal_sum=$total_bal_sum+$amount_balance22;
				}
				 $credit_amount22='0';
			}
			else
			{
				 
				if(!empty($r['atx_vat_amount']))
				{
					//$amount_balance=$amount_balance+$r['atx_tot_amount']-$r['atx_vat_amount'];///old way of calc
				 	 $amount_balance22=$amount_balance22-($r['atx_tot_amount']*$r['atx_currency_value']-$r['atx_vat_amount']*$r['atx_currency_value']);
					 $credit_amount22=$r['atx_tot_amount']*$r['atx_currency_value']-$r['atx_vat_amount']*$r['atx_currency_value'];////reduce vat from total if present 
					 	$credit_sum=$credit_sum+$credit_amount22;
									$total_bal_sum=$total_bal_sum+$amount_balance22;
				}
				else
				{
					//$amount_balance=$amount_balance+$r['atx_tot_amount'];///old way of calc
					$amount_balance22=$amount_balance22-$r['atx_tot_amount']*$r['atx_currency_value'];
					$credit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];////else show full total 
						$credit_sum=$credit_sum+$credit_amount22;
									$total_bal_sum=$total_bal_sum+$amount_balance22;
				}
				  $debit_amount22='0';
			}
		}
	}
	else
	{
		//pre_list($r);
		
			if($r['atx_amount_type']=="Expense")
			{
				// $amount_balance=$amount_balance+$r['atx_tot_amount'];//old order
				 $amount_balance22=$amount_balance22-$r['atx_tot_amount']*$r['atx_currency_value'];
				 $credit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];
				 	$credit_sum=$credit_sum+$credit_amount22;
									$total_bal_sum=$total_bal_sum+$amount_balance22;
				
				$debit_amount22='0';
			}
			else
			{
				// $amount_balance=$amount_balance-$r['atx_tot_amount'];//old order
				
				 $amount_balance22=$amount_balance22+$r['atx_tot_amount']*$r['atx_currency_value'];
				 $debit_amount22=$r['atx_tot_amount']*$r['atx_currency_value'];
				 $debit_sum=$debit_sum+$debit_amount22;
						$total_bal_sum=$total_bal_sum+$amount_balance22;
				$credit_amount22='0';
			}
			
		// $amount_balance=0;
	}

?>	
<tr>
	<td><?php echo $r['atx_date'];?></td>
	 <td><!--<?php echo $r['mact_due_date'];?>--></td> 
	<td><a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes sales_invoice_modal_a" href="#modalmd_sinv" onclick="get_doc_details(<?php echo $r['atx_id'];?>,'<?php echo $r['atx_region'];?>');"><?php echo $r['atx_doc_no'];?></a></td>
	<td><?php
	if($r['acc_name_bank_sales']==$account_name[0]->label)
	{
		echo $r['cust_acc_name'];
	}
	else
	{
		echo $r['acc_name_bank_sales'];
	}
	?></td>
	<td><?php echo $r['atx_narration'];?></td>
	
	<td> <?php echo $r['atx_cheque_no'];?></td>
	<td><?php echo $r['atx_bill_no'];?></td>

		<td><?php if(!empty($debit_amount22)){echo number_format((float)$debit_amount22, 2, '.', '');}else{echo "0";}?></td>
	<td><?php if(!empty($credit_amount22)){echo number_format((float)$credit_amount22, 2, '.', '');}else{echo "0";}?></td>
	<td> <?php 
	 echo number_format((float)$amount_balance22, 2, '.', '');
    ?>
</td>
</tr>
<?php
}
}
}?>
<tfoot>
	<tr>
		<td colspan="7" align="center">TOTALS:</td>
		
		<td><?php echo number_format((float)$debit_sum, 2, '.', '') ;?></td>
		<td><?php echo number_format((float)$credit_sum, 2, '.', '') ;?></td>
		<td><?php echo number_format((float)$debit_sum, 2, '.', '')-number_format((float)$credit_sum, 2, '.', '');?></td>
		
	</tr>
</tfoot>
</tbody>

</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->

<!-- Button trigger modal for sales invoice-->
 <div id="modalmd_sinv" class="modal-block modal-block-lg mfp-hide" style="width: 100%;">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Reference Details </h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text modal_content_sinv">
   
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<!-- <button type="button" onclick="submit_sales_inv_amount()"  class="btn btn-primary confirm_btn_modal">Confirm</button> -->
<button class="btn btn-default modal-dismiss modal-close-btn">Close</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal--->

</section>
</div>

<input type="hidden" name="base_url" value="<?php echo base_url();?>">
</section>


<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
<a href="#" class="mobile-close visible-xs">
Collapse <i class="fa fa-chevron-right"></i>
</a>
<div class="sidebar-right-wrapper">

<div class="sidebar-widget widget-friends ">

<!-- <div class="chat_window">
<?php $this->load->view('admin/master_essential/chat_data',$chat);?>

</div> -->
</div>



</div>
</div>
</div>
</aside>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker();
            });

           $(function () {
             $('.datetimepicker4').datepicker({setDate: new Date() });
            });
         </script> 
         
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>


<script type="text/javascript">


	 $(document).ready(function()
    {      
    	$('input').attr('autocomplete','off'); 
          $('#datatable-default-2').DataTable( {
        dom: 'Bfrtip',
        buttons: [
         { extend: 'excelHtml5',footer: true },
        {
            extend: 'pdfHtml5',
            text: 'PDF',
			  orientation: 'landscape',
                pageSize: 'LEGAL',
                
               
                     footer: true 
                
 		}
        ],
         "pageLength":50,
		
		
    } );

          $('select[name="s_type"]').on('change',function(){
          	//console.log($(this).val());
          	if($(this).val()=="std")
          	{
          			$('.ledger_form_class').attr('action', "<?php echo base_url();?>Ledger/submit_sub_ledger");
          	}
          	else
          	{
          		 $('.ledger_form_class').attr('action', "<?php echo base_url();?>Ledger2/submit_sub_ledger_org");
          	}
          });
} );
</script>
 

 <script type="text/javascript">
 	function get_doc_details(master_acc_id,region)
 	{

 	 jQuery.ajax({
               url:"<?php echo base_url().'Ledger/get_doc_details';?>",
                data:{"master_acc_id":master_acc_id,"region":region},
              type:"post",
               success:function(result)
              {
                if(result)
                {
                	//console.log(result);
                	$('.modal_content_sinv').html(result);
                	  $('#datatable-default2').DataTable( {
              "scrollX": true,
        "pageLength": 50,
    responsive: true,
    
     } );
              //  $("input[name='cbr_rate_currency']").val(result);
                }
              }
               });
 	}
 </script>

</body>
</html>