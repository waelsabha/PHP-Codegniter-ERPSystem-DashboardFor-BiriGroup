<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<style type="text/css">
.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Dashboard</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Dashboard</span></li>
<li><span>Sales User Data</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>
 

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Sales Data comparison</h2>
</header>
<div class="panel-body">

<div id="container1" style="min-width: 100%; height: 400px; margin: 0 auto"></div>

</div>
</section>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Product Sales per Category(for current year and previous year)</h2>
</header>
<div class="panel-body">

<div id="container6" style="min-width: 100%; height: 400px; margin: 0 auto"></div>

</div>
</section>



<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Top to least selling products </h2>
</header>
<div class="panel-body">

<div id="container3" style="min-width: 100%; height: 400px; margin: 0 auto"></div>

</div>
</section>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Top 20 Potential Customers</h2>
</header>
<div class="panel-body">
<table class="table table-responsive table-bordered table-striped mb-none ">
<thead>
<th>Customer Name</th>
<th>Quantity Purchased</th>
</thead>
<tbody>

<?php
arsort($narration_data);
$ij=0;
foreach($narration_data as $index_nd=>$nd)
{
	foreach($nd as $index_nd2=>$nd2)
	{
		if($ij<=20)
		{	
?>
<tr>
<td><?php echo $nd2->sbr_narration;?></td>
<td><?php echo $nd2->total_qnty;?></td>
</tr>
<?php
					
		}
	}
	$ij++;
}
?>
</tbody>
</table>
</div>
</section>


</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>


<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript">
</script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<script type="text/javascript">

$(document).ready(function()
    {
      $('#datatable-default3').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
         "pageLength": 25,
    responsive: true,
     "scrollX": true,
} );

      $month_selected=$('input[name="month_selected"]').val();
      $date_end=$('input[name="end_date_rng"]').val();
      $date_strt=$('input[name="start_date_rng"]').val();

      // if($month_selected=='' && $date_end=='' && $date_strt=='')
      // {
      //  window.location.href = 'sales-book-dashboard';
      // }

    } );
      
Highcharts.chart('container1', {
chart: {
type: 'column'
},
title: {
text: 'Last year and this year comparison'
},

xAxis: {
categories: [
    'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug',
    'Sep','Oct','Nov','Dec'
],
crosshair: true
},
yAxis: {
min: 0,
title: {
    text: 'Sales Income'
}
},
tooltip: {
headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    '<td style="padding:0"><b>{point.y:.1f} AED</b></td></tr>',
footerFormat: '</table>',
shared: true,
useHTML: true
},
plotOptions: {
column: {
    pointPadding: 0.2,
    borderWidth: 0
}
},
series: [
{
name: '<?php print_r($last_previous_year);?>',
data: [
<?php 
   foreach($months_last_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($previous_year);?>',
data: [
<?php 
   foreach($months_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

}, {
name: '<?php print_r($current_year);?>',
data: [
  <?php 
   foreach($months_curnt as $mc)
   {
    if(empty($mc))
      echo '0';
    else
      echo number_format((float)$mc, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>]//12 data,for all months

}]
});

Highcharts.chart('container6', {
chart: {
type: 'column'
},
title: {
text: 'Last year and this year comparison as per category'
},

xAxis: {
categories: [
<?php
foreach($all_category_comparison as $ac)
{
  if(!empty($ac))
  {
  //echo "'".$ac->sbp_ar_category."'";
  echo "'".$ac."'";
  echo ',';
  }
}
  ?>  
],
crosshair: true
},
yAxis: {
min: 0,
title: {
    text: 'Category Sales Income'
}
},
tooltip: {
headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    '<td style="padding:0"><b>{point.y:.1f} AED</b></td></tr>',
footerFormat: '</table>',
shared: true,
useHTML: true
},
plotOptions: {
column: {
    pointPadding: 0.2,
    borderWidth: 0
}
},
series: [
{
name: '<?php print_r($last_previous_year);?>',
data: [

<?php 
   foreach($cat_amount_last_prev as $indx1=>$mp)
   {
      
    if(empty($mp[0]->sbp_ar_category))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_gross_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($previous_year);?>',
data: [

<?php 
   foreach($cat_amount_prev as $indx1=>$mp)
   {
      
    if(empty($mp[0]->sbp_ar_category))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_gross_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

}, {
name: '<?php print_r($current_year);?>',
data: [
  <?php 
   foreach($cat_amount_curnt as $indx2=>$mc)
   {
   $sum_cat2=array_sum($mc);
    foreach($all_category as $indx2=>$ac)
  {
    if($ac->sbp_ar_category==$indx2)
    {
    if(empty($mc))
      echo '0';
    else
      echo number_format((float)$sum_cat2, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
    }
   }
?>]//12 data,for all months

}]
});
</script>


<script>
Highcharts.chart('container3', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Based on products sales'
    },
    subtitle: {
        text: 'Garph showing top to least'
    },
    xAxis: {
        type: 'category',
        labels: {
            rotation: -45,
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Quantity'
        }
    },
    legend: {
        enabled: false
    },
    tooltip: {
        pointFormat: 'Product quantity sold: <b>{point.y:.1f} </b>'
    },
    series: [{
        name: 'Sales',
        data: [
        <?php 
        foreach($sp_prd as $indx4=>$val_cat)
        {
      $sort_array=arsort($val_cat);
        foreach($val_cat as $kj)
        {
        
         ?>
            ['<?php echo $kj["prd_code"];?>', <?php echo $kj['prd_qnty'];?>],
        
            <?php
            }
            }?>
        ],
        dataLabels: {
            enabled: false,
           
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y:.1f}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    }]
});
</script>

</html>