<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" 
type="text/css"/>
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" 
type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
table input.form-control {
  width: auto;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">
<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2><?php echo $this->lang->line('Custody'); ?> </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span><?php echo $this->lang->line('Custody'); ?></span></li>
<li><span><?php echo $this->lang->line('Employee Custody'); ?></span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title"><?php echo $this->lang->line('add cutody to employee'); ?> </h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('Manage_assets/submit_custody','class="myform" novalidate','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->

   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"><?php echo $this->lang->line('Fileds marked as'); ?> </p>

<div class="row">

 

<div class="col-md-6 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"><?php echo $this->lang->line('Employee'); ?><abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="si_customer_acc_id" required="required">
  <option value=""><?php echo $this->lang->line('Choose'); ?></option>
 <?php
foreach($employee as $cb)
{
//pre_list($cb);
?>
<option value="<?php echo $cb->et_id;?>" <?php if(!empty($result[0]->si_customer_acc_id)){if($result[0]->si_customer_acc_id==$cb->id){echo "selected";}};?> ><?php echo $cb->et_name;?></option>
 
<?php
}
?>
 </select>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12 table-rows-border">
<div class="form-group">

</div>
</div>
</div>













<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive">
<table class="table table-border table-rows-border">
  <thead>
   <th><?php echo $this->lang->line('custody name and serial'); ?></th>
   
     <th><?php echo $this->lang->line('custody type'); ?></th>
      
      <th><?php echo $this->lang->line('custody parent'); ?></th>
       <th><?php echo $this->lang->line('custody condition'); ?></th>
        <th><?php echo $this->lang->line('previous custody'); ?></th>
         

  </thead>
  <tbody class="new_rows">
     <?php
    if(!empty($result[0]))/////used in update value
    {
      $warehouse_added=explode('|#|',$result[0]->si_warehouse);
      $prd_added=explode('|#|',$result[0]->si_product);

      $qnty_added =explode('|#|',$result[0]->si_qnty);
      $sum_qnty=array_sum($qnty_added);

      $rate_added=explode('|#|',$result[0]->si_rate);
         $sum_rate=array_sum($rate_added);

      $gross_added=explode('|#|',$result[0]->si_gross);
         $sum_gross=array_sum($gross_added);

       $disper_added=explode('|#|',$result[0]->si_dis_per);
          $sum_disper=array_sum($disper_added);

      $disamnt_added=explode('|#|',$result[0]->si_dis_amount);
         $sum_disamnt=array_sum($disamnt_added);

      $add_charges_added=explode('|#|',$result[0]->si_add_charges);
         $sum_add_charges=array_sum($add_charges_added);

       $fnet_added=explode('|#|',$result[0]->si_fnet);
       $sum_fnet=array_sum($fnet_added);

      $vat_added=explode('|#|',$result[0]->si_vat);
         $sum_vat=array_sum($vat_added);

      $delivery_date_added=explode('|#|',$result[0]->si_delivery_date);
       $remark_added=explode('|#|',$result[0]->si_remrk);
      $taxcode_added=explode('|#|',$result[0]->si_tax_code);
       $total_count_rows=count($prd_added);
       $ik=1;
   foreach($prd_added as $ca_index=>$pa)
      {
?>
<tr class="edit_remove_<?php echo $ca_index;?>">
      <td> 
        <select data-plugin-selectTwo  class="form-control populate" name="si_warehouse[]">
  <option value=""><?php echo $this->lang->line('Choose'); ?></option>
<?php
foreach($assets_list as $wd)
{
  ?>
   <option value="<?php echo $wd->mw_id;?>" <?php if(!empty($warehouse_added[$ca_index])){if($warehouse_added[$ca_index]==$wd->mw_id){echo "selected";}};?>> <?php echo $wd->mw_name;?> </option> 
  <?php
}
?>
 </select>
</td>
<td><img src="" width="100" height="100" class="img-responsive img<?php echo $ik;?>"></td>
  <td>
    <select data-plugin-selectTwo  class="form-control populate product_<?php echo $ik;?>"
     name="si_product[]" onchange="get_product_details()">
  <option value=""><?php echo $this->lang->line('Choose'); ?></option>
<?php
foreach($products_list as $prd)
{
  ?>
   <option value="<?php echo $prd->pid;?>" <?php if(!empty($pa)){if($pa==$prd->pid){echo "selected";}};?> > <?php echo str_replace('|~~|', ',', $prd->pname);?> ::<br/> <?php echo $prd->pcode;?> </option> 
  <?php
}
?>
 </select></td>
  
    <td><input type="number" name="si_qnty[]" onchange="calc_gross(<?php echo $ik;?>);" onkeyup="calc_gross(<?php echo $ik;?>);" value="<?php if(!empty($qnty_added[$ca_index])){echo $qnty_added[$ca_index];}else{echo "0";};?>"  step="any"  class="form-control qnyt_dt qnty<?php echo $ik;?>"> </td>

    <td><input type="number" name="si_rate[]" onchange="calc_gross(<?php echo $ik;?>)" onkeyup="calc_gross(<?php echo $ik;?>)"  value="<?php if(!empty($rate_added[$ca_index])){echo $rate_added[$ca_index];}else{echo "0";};?>" step="any"  class="form-control rate_dt rate<?php echo $ik;?>"> </td>

    <td><input type="number" name="si_gross[]" value="<?php if(!empty($gross_added[$ca_index])){echo $gross_added[$ca_index];}else{echo "0";};?>" step="any"  readonly="" class="form-control gross_dt gross<?php echo $ik;?>"></td>

    <td>
       <input type="hidden" name="dis_per_each_prd[]"  value="0" class="form-control dis_per_each_prd<?php echo $ik;?>">
      <input type="number" name="si_dis_per[]"  value="<?php if(!empty($disper_added[$ca_index])){echo $disper_added[$ca_index];}else{echo "0";};?>" onchange="calc_gross(<?php echo $ik;?>)" onkeyup="calc_gross(<?php echo $ik;?>)" step="any"   class="form-control disc_per_dt disperc<?php echo $ik;?>"> </td>

    <td><input type="number" name="si_dis_amount[]" value="<?php if(!empty($disamnt_added[$ca_index])){echo $disamnt_added[$ca_index];}else{echo "0";};?>"  onchange="calc_gross(<?php echo $ik;?>)" onkeyup="calc_gross(<?php echo $ik;?>)" step="any"   class="form-control disc_amount_dt disamnt<?php echo $ik;?>"> </td>

    <td><input type="number"  name="si_add_charges[]" value="<?php if(!empty($add_charges_added[$ca_index])){echo $add_charges_added[$ca_index];}else{echo "0";};?>"  onchange="calc_gross(<?php echo $ik;?>)" onkeyup="calc_gross(<?php echo $ik;?>)" step="any"  class="form-control add_charges_dt addchrg<?php echo $ik;?>"> 
    </td>

    <td><input type="number" name="si_fnet[]"  value="<?php if(!empty($fnet_added[$ca_index])){echo $fnet_added[$ca_index];}else{echo "0";};?>"  step="any"  readonly="" class="form-control fnet_dt fnet<?php echo $ik;?>"></td>
    <td>
      <?php
     $fent_with_vat=$fnet_added[$ca_index]*($vat_added[$ca_index]/100);
    $tot_fnet_vat=$fent_with_vat+$fnet_added[$ca_index];
      ?>
       <input type="hidden" name="vat_fnet_val[]"  value="<?php if(!empty($tot_fnet_vat)){echo $tot_fnet_vat;};?>" class="form-control vat_fnet_val<?php echo $ik;?>"> 

        <input type="hidden" name="vat_each_prd[]"  value="0" class="form-control vat_each_prd_val<?php echo $ik;?>">

      <input type="number" name="si_vat[]" value="<?php if(!empty($vat_added[$ca_index])){echo $vat_added[$ca_index];}else{echo "0";};?>"  step="any" readonly="" class="form-control vat_dt vat<?php echo $ik;?>"> </td>
      <?php
 if(!empty($delivery_date_added[$ca_index]))
  $converted_dlvry_date = date("m/d/Y", strtotime($delivery_date_added[$ca_index]));
?>
    <td><input type="text"  name="si_delivery_date[]" class="form-control datetimepicker5" value="<?php if(!empty($delivery_date_added[$ca_index])){echo $converted_dlvry_date;};?>"> </td>

    <td><input type="text" name="si_remrk[]" value="<?php if(!empty($remark_added[$ca_index])){echo $remark_added[$ca_index];};?>"  class="form-control"> </td>
 <?php
  if(!empty($page_type))
   { 
    if($page_type=="uae"||$page_type=="dragon"||$page_type=="ksa"||$page_type=="KSAamazon")
    {
?>
    <td><input type="text"  name="si_tax_code[]" readonly="" value="<?php if(!empty($taxcode_added[$ca_index])){echo $taxcode_added[$ca_index];};?>" class="form-control"> </td>
     <td><button type='button'   onclick="table_edit('<?php echo $ca_index;?>')">X</button></td>
     <?php
  }
}?>
    <td></td>
    <!-----for input tyype hidden fields------------->
    <input type="hidden"name="hi_warehouse"  class="form-control"> 

    <!---------end for input type hidden--->
    </tr>
<?php
   $ik++;
      }
  }
  else////for adding new , for new inovices///////////////
  {
        ?>
    <tr>
  <td>
    <select data-plugin-selectTwo  class="form-control populate product_1"
     name="si_product[]" onchange="get_product_details('1')">
  <option value=""><?php echo $this->lang->line('Choose'); ?></option>
<?php
foreach($assets_list as $prd)
{
  ?>
   <option value="<?php echo $prd->al_id;?>" > <?php
    echo str_replace('|~~|', ',', $prd->al_description);?> ::<br/> <?php echo $prd->al_serial_number;?> </option> 
  <?php
}
?>
 </select></td>
  
    <td><input type="text" name="c_type[]" value="-"   readonly="" class="form-control qnyt_dt ctype1"> </td>
    <td><input type="text" name="c_parent[]"  value="-"  readonly=""  class="form-control rate_dt cparent1"> </td>
    <td><input type="text" name="c_condition[]" value="-"   readonly="" class="form-control gross_dt ccon1"></td>
    <td><input type="text" name="c_prev_cus[]" value="-"  readonly="" class="form-control disc_amount_dt cprevcus1"></td>
    
    <!-----for input tyype hidden fields------------->
     <input type="hidden"name="hi_warehouse"  class="form-control"> 
    


    <!---------end for input type hidden--->

    </tr>
    <?php
  }?>
 <button type="button" class="btn btn-primary pull-right" onclick="add_more_row();"><?php echo $this->lang->line('Add More'); ?></button> 
  </tbody>
</table>
</div>
</div>



<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder"><?php echo $this->lang->line('Total Number of items'); ?>:</label>
<div class="col-md-8">
  <span class="num_items">
    <?php
if(!empty($result[0]))
 {
     if(!empty($total_count_rows))
      {
        echo $total_count_rows;
      }
     else
    {
      echo "1";
    }
}
  else
  {
    echo "1";
  }
  ?>
  </span>
</div>
</div>
<!----------end col-md-12----------------------------->

<!-------start col-md-12------------------->

<!----------end col-md-12----------------------------->

<!-------start col-md-12------------------->

<!----------end col-md-12----------------------------->

<!-----div starts here for non-inquiry--->
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for non-inquiry--->
<input type="hidden" name="sales_inv_cust_id">
  <input type="hidden" name="sales_inv_id">
    <input type="hidden" name="sales_inv_amount">
  <input type="hidden" name="sales_inv_amount_paid">
  <input type="hidden" name="sales_doc_num">

<!-----div starts here for non-inquiry--->
 <!-- Button trigger modal for sales invoice-->
 <div id="modalmd_sinv" class="modal-block modal-block-lg mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"><?php echo $this->lang->line('References'); ?> </h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text modal_content_sinv">
   
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button" onclick="submit_sales_inv_amount()"  class="btn btn-primary confirm_btn_modal"><?php echo $this->lang->line('Confirm'); ?></button>
<button class="btn btn-default modal-dismiss modal-close-btn"><?php echo $this->lang->line('Cancel'); ?></button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal--->
<!----div closes here--->

<button class="btn btn-primary " >Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>

<?php echo form_close();?>
</div>
</div>


</section>
</div>
</section>


<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
<a href="#" class="mobile-close visible-xs">
Collapse <i class="fa fa-chevron-right"></i>
</a>
<div class="sidebar-right-wrapper">

<div class="sidebar-widget widget-friends ">

<div class="chat_window">
<?php $this->load->view('admin/master_essential/chat_data',$chat);?>

</div>
</div>



</div>
</div>
</div>
</aside>
<?php $this->load->view('admin/sales/script_arabic_word');?>
<script src="<?php echo base_url('admin_assets/');?>tafqit.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
 <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript">
  </script>

  <script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

  
  <script>
            $(document).on('ready', function () {
              $('input').attr('autocomplete','off');
                $("#file-1").fileinput();
                });
                  </script>
   
 <script>
    tinymce.init({
      selector : '.editors',
        plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
    });
   </script>
 <script type="text/javascript">
 function add_more_row()
{
var tablecount = $('table tbody tr').length;
  if(tablecount=="0")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }
  var prev_table_row=parseFloat(table_id)-1;
var warehouse_selected_prev=$('.warehouse_'+prev_table_row).find('option:selected').val();
   var markup='<tr class="table'+table_id+'">'+
  
 ' <td class="select_prd_list_'+table_id+'">';
    jQuery.ajax({
                     url:"<?php echo base_url().'Manage_assets/get_details_prd';?>",
                      data:{"table_id":table_id},
                    type:"post",
                    success:function(result)
                    {
                      if(result)
                      {
               $('.select_prd_list_'+table_id).html(result);
              $('select[name="si_product[]"]').select2();  
                      }
                    }
                 });  








  markup+=  '</td>'+
  '<td><input type="text" name="c_type[]" value="-"   readonly="" class="form-control qnyt_dt ctype'+table_id+'"> </td>'+
    '<td><input type="text" name="c_parent[]"  value="-"  readonly=""  class="form-control rate_dt cparent'+table_id+'"> </td>'+
   '<td><input type="text" name="c_condition[]" value="-"   readonly="" class="form-control gross_dt ccon'+table_id+'"></td>'+
    '<td><input type="text" name="c_prev_cus[]" value="-"  readonly="" class="form-control disc_amount_dt cprevcus'+table_id+'"></td>'+

     ' <td><button type="button" class="btn btn-danger" style="cursor: pointer" onclick=table('+table_id+')>X</button></td>'+

      '</tr>';
   
            $(".new_rows").append(markup);
             var rowcount = $('table tbody tr').length;
     $(".num_items").html(rowcount);
     $('select[name="si_product[]"]').select2();
       $('select[name="si_warehouse[]"]').select2();
 $('input[name="si_delivery_date[]"]').datepicker();
}

  function table(id)
  {
    $('table tbody .table'+id).remove();
    var rowcount = $('table tbody tr').length;
    $(".num_items").html(rowcount);
  }

      function table_edit(id)
 {
 $('.edit_remove_'+id).remove();
 
   $(this).closest("tr").remove();
    $(this).parent().remove();
  //var rowcount = $('table tbody tr').length;
  //$(".num_items").html(rowcount);
 } 

</script>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker();
            });

           $(function () {
            var date2 = $('.datetimepicker4').datepicker('getDate', '+1d'); 
  date2.setDate(date2.getDate()+1); 
                $('.datetimepicker5').datepicker().datepicker("setDate", date2);
            });
          
$(document).on('ready', function () 
{
  $('select[name="si_currency"]').on('change',function(){
    
     jQuery.ajax({
               url:"<?php echo base_url().'Receipt_Master/get_currency_conv_val';?>",
                data:{"currecny_selected":$(this).val()},
              type:"post",
               success:function(result)
              {
                if(result)
                {
                $("input[name='si_conv_value']").val(result);
                }
              }
               }); 
  });

  $('select[name="si_vat_type"]').on('change',function(){
    var choose_page_type=$("input[name='page_type']").val();
    var vat_choosed=$(this).val();
    if(vat_choosed=="2")
    {
      $('input[name="si_vat[]"]').val('0');
       $('input[name="si_tax_code[]"]').val('ZR');
    }
    else
    {
      if(choose_page_type=="uae")
       $('input[name="si_vat[]"]').val('5');
     else if(choose_page_type=="UK")
       $('input[name="si_vat[]"]').val('20');
     else if(choose_page_type=="ksa"||$choose_page_type=="KSAamazon")
       $('input[name="si_vat[]"]').val('15');
     else if(choose_page_type=="dragon")
       $('input[name="si_vat[]"]').val('5');
     else{}
       // $('input[name="si_tax_code[]"]').val('SR');
    }

     if(choose_page_type=="uae"||choose_page_type=="dragon"||choose_page_type=="UAEAmazon")
       {$('input[name="si_tax_code[]"]').val('AE');

       }
       else if (choose_page_type=="ksa"||choose_page_type=="KSAamazon"){
         $('input[name="si_tax_code[]"]').val('SR');

       }
      
         else if(choose_page_type=="UK")
         {
            $('input[name="si_tax_code[]"]').val('GBP');
         }
 }); 

    $('select[name="si_plc_supply"]').on("change",function(){
        var selected_val=$(this).val();
        $('select[name="si_jurisdiction"]').val(selected_val).trigger('change');
     });

  $('.menu_name_fun').on('click',function(){
          if (confirm("Are you sure, You want to exit this page?")) {
                  location.href = $(this).attr('href');
            } 
            else {
              return false;
            }

          });

$('select[name="si_customer_acc_id"]').on("change",function(){
   if($(this).val()=="606")
                    {
                $('select[name="si_company"] ').val('5').trigger('change');

               //$('select[name="si_salesman"]').val(returndata[0]['macd_salesman_id']).trigger('change');
                $('select[name="si_country"]').val('82').trigger('change');
                $('select[name="si_pc_level"]').val('3').trigger('change');
                $('select[name="si_plc_supply"]').val('8').trigger('change');
                $('select[name="si_jurisdiction"]').val('8').trigger('change');
               $('select[name="si_sales_acc_id"]').val('618').trigger('change');
                    }
                    else
                    {
  jQuery.ajax({
               url:"<?php echo base_url().'Sales_invoice/get_cust_full_details';?>",
                data:{"cust_id":$(this).val()},
              type:"post",
               success:function(result)
              {
                console.log(result);
                if(result)
                {
                  
                var returndata = JSON.parse(result);
             $('select[name="si_company"] ').val(returndata[0]['macd_company_id']).trigger('change');
         $('select[name="si_salesman"]').val(returndata[0]['macd_salesman_id']).trigger('change');
          $('select[name="si_country"]').val(returndata[0]['country']).trigger('change');
          $('select[name="si_payment_type"]').val(returndata[0]['macd_payment_type_id']).trigger('change');
          $('select[name="si_pc_level"]').val(returndata[0]['macd_price_level_id']).trigger('change');
          $('select[name="si_plc_supply"]').val(returndata[0]['macd_place_supply_id']).trigger('change');
          $('select[name="si_jurisdiction"]').val(returndata[0]['macd_jurisdication_id']).trigger('change');
       $('select[name="si_sales_acc_id"]').val(returndata[0]['macd_sales_acc_id']).trigger('change');
       
                if(returndata[0]['macd_currency_value']!=null)
                {
                 $('select[name="si_currency"]').val(returndata[0]['macd_currency_value']).trigger('change');
                   if(returndata[0]['currency_val']!=null)
                   $('input[name="si_conv_value"]').val(returndata[0]['currency_val']);
                   else
                     $('input[name="si_conv_value"]').val('1');
               }
               else
               {
                if($('input[name="page_type"]').val()=="ksa")
                {
                  $('select[name="si_currency"]').val('SAR').trigger('change');
                  $('input[name="si_conv_value"]').val('0.975');
                }
                else
                {
                  $('select[name="si_currency"]').val('AED').trigger('change');
                  $('input[name="si_conv_value"]').val('1');
                }
                  
               }

           if(returndata[0]['phone']!=null)
           $('input[name="si_contact"]').val(returndata[0]['phone']);
         else
             $('input[name="si_contact"]').val(returndata[0]['mobile_phone']);

             if(returndata[0]['address']!=null)
           $('input[name="si_delivery_address"]').val(returndata[0]['address']);
          // console.log(returndata[0]);
                  
              }
                
            }
               }); 
          }///closed else////
          });
}); 

function get_product_details(table_id)
{
    var prd_selected=$('.product_'+table_id).find('option:selected').val();
  
    
    jQuery.ajax({
               url:"<?php echo base_url().'Manage_assets/get_assets_details';?>",
                data:{"asset_id":prd_selected},
              type:"post",
               success:function(result)
              {
                 if(result)
                {
                  var returndata = JSON.parse(result);
                 
                  $('.cparent'+table_id).val(returndata['cparent']);
                   $('.ctype'+table_id).val(returndata['ctype']);
                  $('.ccon'+table_id).val(returndata['ccon']);
                  $('.cprevcus'+table_id).val(returndata['cprevcus']);
                }
              }
            });
}






function calc_gross(table_id)
{
  var qnty_tbl=$('.qnty'+table_id).val();
  var rate_tbl=$('.rate'+table_id).val();
  var tot_gross=parseFloat(qnty_tbl)*parseFloat(rate_tbl);

   $('.gross'+table_id).val(tot_gross);

  var dis_per_tbl=$('.disperc'+table_id).val();

  var dis_amnt_tbl=$('.disamnt'+table_id).val();
  var add_charge_tbl=$('.addchrg'+table_id).val();

  var tot_dis_per_amont=(parseFloat(dis_per_tbl)/parseFloat(100))*parseFloat(tot_gross);

  $('.dis_per_each_prd'+table_id).val(tot_dis_per_amont);

var tot_fnet_calc=parseFloat(tot_gross)-parseFloat(tot_dis_per_amont)-parseFloat(dis_amnt_tbl)+parseFloat(add_charge_tbl);

  $('.fnet'+table_id).val(tot_fnet_calc);
  var vat_tbl=$('.vat'+table_id).val();

var fent_with_vat=parseFloat(tot_fnet_calc)*(parseFloat(vat_tbl)/parseFloat(100));
$('.vat_each_prd_val'+table_id).val(fent_with_vat);
var tot_fnet_vat=parseFloat(fent_with_vat)+parseFloat(tot_fnet_calc);
  $('.vat_fnet_val'+table_id).val(tot_fnet_vat);

}

function get_amount_total()
{
  var amountss1='0';
$('table tbody tr td input[name="si_qnty[]"]').each(function(){
amountss1= parseFloat(amountss1)+parseFloat($(this).val());
}); 
$('.qnty_tot_button').val(parseFloat(amountss1.toFixed(2)));

//////for rate tot calc//////
var amountss_2='0';
$('table tbody tr td input[name="si_rate[]"]').each(function(){
amountss_2= parseFloat(amountss_2)+parseFloat($(this).val());
}); 
$('.rate_tot_button').val(parseFloat(amountss_2.toFixed(2)));

/////////for gross tot_calc//////////

var amountss_3='0';
$('table tbody tr td input[name="si_gross[]"]').each(function(){
amountss_3= parseFloat(amountss_3)+parseFloat($(this).val());
}); 
$('.gross_tot_button').val(parseFloat(amountss_3.toFixed(2)));

///////for dis per tot calc field/////////
//  var amountss_4='0';
// $('table tbody tr td input[name="si_dis_per[]"]').each(function(){
// amountss_4= parseFloat(amountss_4)+parseFloat($(this).val());
// }); 
// $('.disc_per_tot_button').val(parseFloat(amountss_4));

///////for dis per tot calc field/////////
 var amountss_4_1='0';
$('table tbody tr td input[name="dis_per_each_prd[]"]').each(function(){
amountss_4_1= parseFloat(amountss_4_1)+parseFloat($(this).val());
}); 
$('.disc_per_tot_button').val(parseFloat(amountss_4_1.toFixed(2)));

//////for dis amount tot calc field/////////
var amountss_5='0';
$('table tbody tr td input[name="si_dis_amount[]"]').each(function(){
amountss_5= parseFloat(amountss_5)+parseFloat($(this).val());
}); 
$('.disc_amount_tot_button').val(parseFloat(amountss_5.toFixed(2)));

//////////for add charges tot calc field///////
 var amountss_6='0';
$('table tbody tr td input[name="si_add_charges[]"]').each(function(){
amountss_6= parseFloat(amountss_6)+parseFloat($(this).val());
}); 
$('.add_charges_tot_button').val(parseFloat(amountss_6.toFixed(2)));

///////for fnet tot calc field///////////
  var amountss_7='0';
$('table tbody tr td input[name="si_fnet[]"]').each(function(){
amountss_7= parseFloat(amountss_7)+parseFloat($(this).val());
}); 
$('.fnet_tot_button').val(parseFloat(amountss_7.toFixed(2)));

////////////for vat tot calc field//////
//  var amountss_8='0';
// $('table tbody tr td input[name="si_vat[]"]').each(function(){
// amountss_8= parseFloat(amountss_8)+parseFloat($(this).val());
// }); 
// $('.vat_tot_button').val(parseFloat(amountss_8));

////////////for vat tot calc field//////
 var amountss_8_1='0';
$('table tbody tr td input[name="vat_each_prd[]"]').each(function(){
amountss_8_1= parseFloat(amountss_8_1)+parseFloat($(this).val());
}); 
$('.vat_tot_button').val(parseFloat(amountss_8_1.toFixed(2)));

//////////show total amount///////////
if(amountss_8_1 != null)////vat  is present
{
    var amountss_9='0';
  $('table tbody tr td input[name="vat_fnet_val[]"]').each(function(){
  amountss_9= parseFloat(amountss_9)+parseFloat($(this).val());
  }); 
   var coverted_arabic=tafqit(Math.round(amountss_9.toFixed(2)));
   console.log(coverted_arabic);
   $('input[name="converted_ar"]').val(coverted_arabic);

  $('.amount_tot_button').val(parseFloat(amountss_9.toFixed(2)));
}
else
{
   var coverted_arabic=tafqit(Math.round(amountss_7.toFixed(2))); 
   console.log(coverted_arabic);
   $('input[name="converted_ar"]').val(coverted_arabic);

$('.amount_tot_button').val(parseFloat(amountss_7.toFixed(2)));
}

}

function get_inv_content(ac_tx_id)
{
    var cust_amount_paid=$('.amount_tot_button').val();
  jQuery.ajax({
               url:"<?php echo base_url().'Sales_invoice/get_cust_sales_inv';?>",
                data:{"ac_tx_id":ac_tx_id,'cust_amount_paid':cust_amount_paid},
              type:"post",
               success:function(result)
                {
                  if(result)
                  {
                //console.log(result);
                 $('.modal_content_sinv').html(result);
                 $('.sales_invoice_modal_a').show();
                 $('#datatable-default2').DataTable();
                  }
                }
               }); 
}

function get_cust_sales_inv()
{
   var cust_id=$('select[name="si_customer_acc_id"]').find('option:selected').val();
     var cust_amount_paid=$('.amount_tot_button').val();
  jQuery.ajax({
               url:"<?php echo base_url().'Sales_invoice/get_cust_sales_inv';?>",
                data:{"cust_id":cust_id,'cust_amount_paid':cust_amount_paid},
              type:"post",
               success:function(result)
              {
               //console.log(result);
                $('.modal_content_sinv').html(result);
                 $('#datatable-default2').DataTable();
               }
            });
}
///////////////////////modal functions page/////////////////////////////////////////////////

function get_pick_amount(ij_val=null)
{
  var param_data=pass_param();
  var param_val=param_data.split("##");
  var ij=param_val[0];
  var ref_doc_num= param_val[1];

 var form_input_amount=$('input[name="si_tot_amount"]').val();
  var  to_be_adjust= $('.to_be_adjust').html();
   var  amount_adjusted_till_now= $('.amount_adjusted').html();

   if(amount_adjusted_till_now=='')
     var amount_picked=0;
   else
    var amount_picked=parseFloat(amount_adjusted_till_now);

if(to_be_adjust=='')
   var amount_adjusted=0;
 else
  var amount_adjusted=parseFloat(to_be_adjust);

 if(ij!='')
  {
     console.log('ij '+ij);
  if($('.inv_selected_'+ij).is(':checked'))
  {   
    var total_amount_in_ref=$('.tot_sales_amount_'+ij).val();
    var amount_paid= $('.tot_sales_amount_paid_'+ij).val();
    if(amount_paid=='' || amount_paid=='0')
    { 
         console.log('in if 1');
   $('input[name="refrence"]').val('0');
  // console.log(total_amount_in_ref);
      if(parseFloat(total_amount_in_ref) > parseFloat(form_input_amount))
      { 
         console.log('in if 11');
         if(parseFloat(amount_adjusted)=='0' || parseFloat(amount_adjusted)=='' || parseFloat(amount_adjusted)=='0.00')
        {
           console.log('in if 12');
         var new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(form_input_amount);
         $('.tot_sales_amount_paid_'+ij).val(form_input_amount);
          amount_picked=parseFloat(form_input_amount);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
        }
        else
        {

          console.log('in else 12');
          var new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(amount_adjusted);
         $('.tot_sales_amount_paid_'+ij).val(amount_adjusted);
          amount_picked=parseFloat(amount_picked)+parseFloat(amount_adjusted);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
             
        }
      }
      else if(parseFloat(total_amount_in_ref) < parseFloat(form_input_amount))
      {
           console.log('in if 11.elseif'); 
           if(parseFloat(amount_adjusted)=='0' || parseFloat(amount_adjusted)=='' || parseFloat(amount_adjusted)=='0.00')
          {            
            console.log('in if 12.elseif');
            var new_amount_adjusted=parseFloat(form_input_amount)-parseFloat(total_amount_in_ref);
            $('.tot_sales_amount_paid_'+ij).val(total_amount_in_ref);
            amount_picked=parseFloat(amount_adjusted_till_now)+parseFloat(total_amount_in_ref);
            amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);            
          }         
          else
          {
            console.log('in else 12.elseif');
            var new_amount_adjusted=parseFloat(amount_adjusted)-parseFloat(total_amount_in_ref);
            console.log(new_amount_adjusted);
           $('.tot_sales_amount_paid_'+ij).val(total_amount_in_ref);
            amount_picked=parseFloat(amount_adjusted_till_now)+parseFloat(total_amount_in_ref);
           amount_adjusted=parseFloat(new_amount_adjusted);
          }
       
      }
      else
      { 
        if(amount_adjusted!='0')
          {
             console.log('in else 1.11'+amount_adjusted);
              var new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(amount_adjusted);
                $('.tot_sales_amount_paid_'+ij).val(amount_adjusted);
           amount_picked=parseFloat(amount_picked)+parseFloat(amount_adjusted);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked); 

          }
          else{
         console.log('in else 11');
             if($('input[name="refrence"]').val()=='0')
             {
              console.log('in else 11 - in if 11');
              var new_ref_value=$('input[name="refrence"]').val();
               amount_picked=parseFloat(amount_picked)-parseFloat(new_ref_value);
                amount_adjusted=parseFloat(amount_adjusted)-parseFloat(new_ref_value);
             }
             else
             {
              console.log('in else 11- in else 11');
              $('.tot_sales_amount_paid_'+ij).val(total_amount_in_ref);
              amount_picked=parseFloat(amount_picked)+parseFloat(total_amount_in_ref);
              amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
              }
            }
       }
     }
    else
    { 
     console.log('in else 1- '+ to_be_adjust);
       if( (to_be_adjust!='0.00') )
      {
        if(to_be_adjust!='0')
        {
          console.log('in else 1.1.1');
           var new_ref_val=$('input[name="refrence"]').val();
             $('input[name="refrence"]').val(parseFloat(new_ref_val)+parseFloat(to_be_adjust));
              amount_picked=parseFloat(amount_adjusted_till_now)+parseFloat(to_be_adjust);
              amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);

          
        }
      }
      else
      {
          console.log('in else 1.1.2');
           $('input[name="refrence"]').val($('input[name="refrence"]').val());
      }
    }  
    
  }
  else
  {
    console.log('in else printing to new_ref');
    console.log(form_input_amount);
     $('input[name="refrence"]').val(form_input_amount);
  }
}
else
{
   $('.confirm_btn_modal').show();
   if(to_be_adjust!='0.00')
   {
    $('input[name="refrence"]').val(form_input_amount);
      if( (amount_adjusted_till_now!='') && (amount_adjusted_till_now!='0') )
      {
        amount_picked=amount_adjusted_till_now;
        amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);   
      }
      else
      {
        amount_picked=form_input_amount;
        amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);   
      }  
    }
    else {}
}

  $('.amount_to_adj').html(form_input_amount);
   $('.amount_adjusted').html(amount_picked);
    $('.to_be_adjust').html(amount_adjusted);

    // $('.form_input_ref_'+table_id).val($('.form_input_ref_'+table_id).val() + ref_doc_num+'|#|');
  //   $('.modal-close-btn').trigger('click');
}


function pass_param()
{
  var checked_val=[]; var ref_number_correspond='';var unchecked_val=[];
  $('.class_checkbox').each(function() {
   if ( $(this).is(':checked') )
   {
      if(checked_val=='')
        {
            checked_val=$(this).val();
        }
        else if(jQuery.inArray($(this).val(), checked_val) !== -1)
         {
            checked_val=$(this).val();
         }
         else
          {
            if($(this).val()!=checked_val)///maybe from the unchceked value
            {
              if( $('.tot_sales_amount_paid_'+$(this).val() ).val()=='0' )
              {
                 checked_val=$(this).val();
              }
            }
          }    
    }
 else{
   unchecked_val=$(this).val();  
    $('.confirm_btn_modal').show();
   if(jQuery.inArray($(this).val(), checked_val) == -1)
         {
            checked_val = $.grep(checked_val, function(value) {
              return value != unchecked_val;
            });
         }
    var picked_adjusted_amount= $('.tot_sales_amount_paid_'+unchecked_val).val();
 $('.tot_sales_amount_paid_'+unchecked_val).val('0');
 var amount_adjusted=$('.amount_adjusted').html();
 var to_adjust=$('.to_be_adjust').html();
 var newly_adjusted=parseFloat(amount_adjusted)-parseFloat(picked_adjusted_amount);
$('.amount_adjusted').html(newly_adjusted);
 var new_to_adjust=parseFloat(to_adjust)+parseFloat(picked_adjusted_amount);
$('.to_be_adjust').html(new_to_adjust);

 }
     });
    ref_number_correspond=$('.ref_doc_numbers_'+checked_val).val();
 return checked_val+'##'+ref_number_correspond;
}


function check_val_less_than_amount(ij)
{

  var tot_amount=$('.tot_sales_amount_'+ij).val();
  var paid_amount=$('.tot_sales_amount_paid_'+ij).val();

  var balnce_amount=parseFloat(tot_amount)-parseFloat(paid_amount);
  $('.tot_sales_bal_amount_'+ij).val(balnce_amount.toFixed(2));

  if(parseFloat(paid_amount) > parseFloat(tot_amount))
  {
    $('.amount_overdue_'+ij).html('Paid amount exceeds total amount');
    $('.confirm_btn_modal').hide();
  }
  else
  {
     $('.amount_overdue_'+ij).html('');
    $('.confirm_btn_modal').show();
  }
}


function get_checked_count(ij)
{
    var amounts=0;
  if($('.inv_selected_'+ij).is(':checked'))
  {   
    amounts=parseFloat($('input[name="total_invs_edited"]').val())+parseFloat($('.tot_sales_amount_'+ij).val());
    $('input[name="total_invs_edited"]').val(amounts);
    //$('input[name="add_cash_customer"]').val('1');
//console.log('checked box');
//$('.cash_cusotmer_details').show();

  }
  else
  {
 var amounts=1;
   amounts=parseFloat($('input[name="total_invs_edited"]').val())-parseFloat($('.tot_sales_amount_'+ij).val());
    $('input[name="total_invs_edited"]').val(amounts);
  }
}


function submit_sales_inv_amount()
{
  var issue_text_data=$('.text_data_issue').html();
  var to_be_adjust= $('.to_be_adjust').html();
   var refrence_names='';
if(to_be_adjust=='0')
{

   $('.class_checkbox').each(function() {
   if ( $(this).is(':checked') )
   {    
  //    console.log(sales_doc_num);

   var sales_inv_ids=$('table tbody tr td input[name="inv_id_modal[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var sales_inv_amount=$('table tbody tr td input[name="sales_inv_amount_modal[]"]').map(function(){return $(this).val();}).get().join('|#|');
//console.log(sales_inv_ids); 
var sales_inv_amount_paid=$('table tbody tr td input[name="paid_amount_modal[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var sales_inv_doc_num=$('table tbody tr td input[name="inv_doc_numbers_modal[]"]').map(function(){return $(this).val();}).get().join('|#|');
    
$("input[name='sales_inv_id']").val(sales_inv_ids);
$("input[name='sales_inv_amount']").val(sales_inv_amount);
$("input[name='sales_inv_amount_paid']").val(sales_inv_amount_paid);
$("input[name='sales_doc_num']").val(sales_inv_doc_num); 
 // $('.confirm_btn_modal').hide();
      } 
    else{}  
    }); 
      $('.submit_btn').trigger('click');
      $('.modal-close-btn').trigger('click');

    }
    else
    {
       // $('.modal-close-btn').trigger('click');
      alert('Error in paid amount');
    }
}

/////////////////////end of modal functions////////////////////////////////////
function reset_fields()
{
  var amount_tot=$('.amount_to_adj').html();
  $("input[name='paid_amount_modal[]']").val('0');
  $("input[name='refrence']").val('0');
  $('.amount_adjusted').html('0');
  $('.to_be_adjust').html('0');
}

function check_for_reset()
{
  if (confirm("Are you sure, You want to reset this form?")) {
                 $('.myform').trigger("reset");
            } 
            else {
              return false;
            }
}


 $('.myform').submit(function() {
// e.preventDefault();

var rowcount = $('.new_rows tr').length;

var warehouse_ids=$('table tbody tr td select[name="si_warehouse[]"]').map(function(){return $(this).find('option:selected').val();}).get().join('|#|');  

var prd_ids=$('table tbody tr td select[name="si_product[]"]').map(function(){return $(this).find('option:selected').val();}).get().join('|#|');  

var qnty_nos=$('table tbody tr td input[name="si_qnty[]"]').map(function(){return $(this).val();}).get().join('|#|');

var rate_nos=$('table tbody tr td input[name="si_rate[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var gross_nos=$('table tbody tr td input[name="si_gross[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

 var disc_per_nos=$('table tbody tr td input[name="si_dis_per[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var disc_amount_nos=$('table tbody tr td input[name="si_dis_amount[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var add_charges_nos=$('table tbody tr td input[name="si_add_charges[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var fent_nos=$('table tbody tr td input[name="si_fnet[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var vat_nos=$('table tbody tr td input[name="si_vat[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var delivery_date_nos=$('table tbody tr td input[name="si_delivery_date[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var remark_nos=$('table tbody tr td input[name="si_remrk[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var tax_code_nos=$('table tbody tr td input[name="si_tax_code[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var qnty_deliverd=$('table tbody tr td input[name="si_qnty[]"]').map(function(){return $(this).val()-$(this).val(); }).get().join('|#|');
//console.log(quantity+' '+package_size+' '+product_id);

$("input[name='hi_warehouse']").val(warehouse_ids);
$("input[name='hi_prd_id']").val(prd_ids);
$("input[name='hi_qnty']").val(qnty_nos);
$("input[name='hi_rate']").val(rate_nos);
$("input[name='hi_gross']").val(gross_nos);
$("input[name='hi_dis_per']").val(disc_per_nos);
$("input[name='hi_dis_amount']").val(disc_amount_nos);
$("input[name='hi_add_charges']").val(add_charges_nos);
$("input[name='hi_fnet']").val(fent_nos);
$("input[name='hi_vat']").val(vat_nos);
$("input[name='hi_delivery_date']").val(delivery_date_nos);
$("input[name='hi_remrk']").val(remark_nos);
$("input[name='hi_tax_code']").val(tax_code_nos);
$("input[name='hid_date']").val($("input[name='si_date']").val());

$("input[name='hi_deliverd']").val(qnty_deliverd);
var ij=0;
var data_var=[];

$('.new_rows tr td').each(function() { 
var cellText = $(this).html(); 
 //  console.log(cellText);  
    $('.cell_text_data').append(cellText).hide(); 
});

//console.log(cellText);
// console.log($("input[name='hid_salesman']").val());
// console.log($("input[name='hid_customer']").val());
// console.log($("input[name='hid_amounts']").val());
// console.log($("input[name='hid_remark']").val());
//  console.log($("input[name='hid_ref']").val());
//var table_row_added=$('.new_rows').html();

 if ($('.new_rows tr').length == 0) 
 {
  alert('Please choose items to add and submit');
  return false;
 }
 else
 {
  
  return true;

 }
 //return false;
  // your code here
});
 // }
        </script>

</body>

</html>