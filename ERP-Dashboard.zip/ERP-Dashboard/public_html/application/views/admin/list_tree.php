<!doctype html>
<html class="fixed">

<head>

    <?php $this->load->view('admin/head'); ?>
    <?php
    if (!empty($this->session->userdata('bal_update'))) {
        //	print_r($this->session->userdata['bal_update']['bank_name_updated']);
        update_bank_bal();
    }

    ?>

    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-datepicker/css/datepicker3.css" />

    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/select2/select2.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/pnotify/pnotify.custom.css" />

    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/theme.css" />

    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/skins/default.css" />

    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/theme-custom.css">

  
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
    
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/bootstrap-treeview.min.css" />
 
    <style type="text/css">
        .form_error {
            font-size: 13px;
            font-family: Arial;
            color: red;
            font-style: italic
        }

        .form_error p .errors {
            color: red;
        }

        .errors {
            font-size: 13px;
            font-family: Arial;
            color: red;
            font-style: italic
        }

        .success {
            font-size: 13px;
            font-family: Arial;
            color: green;
            font-style: italic
        }
        ol.trees {
	padding: 0 0 0 30px;
	
}
li { 
	position: relative; 
	margin-left: -15px;
	list-style: none;
}      
li input {
	position: absolute;
	left: 0;
	margin-left: 0;
	opacity: 0;
	z-index: 2;
	cursor: pointer;
	height: 1em;
	width: 1em;
	top: 0;
}
li input + ol {
	background: url(images/toggle-small-expand.png) 40px 0 no-repeat;
	margin: -1.600em 0px 8px -44px; 
	height: 1em;
}
li input + ol > li { 
	display: none; 
	margin-left: -14px !important; 
	padding-left: 1px; 
}
.folder {
	background: url(images/folder.png) 15px 1px no-repeat;
	cursor: pointer;
	/* display: block; */
	padding-left: 37px;
}
.file {
	background: url(images/file.png) 15px 1px no-repeat;
	cursor: pointer;
	/* display: block; */
    /* display: inline-block; */
	padding-left: 37px;
}
li input:checked + ol {
	background: url(images/toggle-small.png) 40px 5px no-repeat;
	margin: -1.96em 0 0 -44px; 
	padding: 1.563em 0 0 80px;
	height: auto;
}
li input:checked + ol > li { 
	display: block; 
	margin: 8px 0px 0px 0.125em;
}
li input:checked + ol > li:last-child { 
	margin: 8px 0 0.063em;
}




    </style>

</head>

<body>
    <section class="body">


        <?php $this->load->view('admin/header'); ?>

        <div class="inner-wrapper">

            <?php $this->load->view('admin/aside'); ?>

            <section role="main" class="content-body">
                <header class="page-header">
                    <h2>List Tree</h2>
                    <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="#">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li><span>List</span></li>
                            <li><span>Account Entries</span></li>
                        </ol>
                        <a class="sidebar-right-toggle"></a>
                    </div>
                </header>
                <?php
                $url = $this->uri->segment(1);
                echo "<input type='hidden' name='url_segment' value='" . $url . "'>";
                ?>
                <div class="form_error">
                        <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
                        <p class="success"><?php echo $this->session->flashdata('success');?></p>
                </div>
      
                <!-- <div class="scroll">         -->
                
                    
                        
                    
                  
                    <div class="container">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                            <h1></h1>
                                <div class="row">
                                <div class="col-md-6">
                                    <button class="btn btn-success" onclick="addAccount()">Add Account</button>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="input-disable-node" class="sr-only">Search Tree:</label>
                                        <input type="input" class="form-control" id="input-search" placeholder="Search">
                                    </div>
                                </div>
                                </div>
                            </div>
                           
                            <div class="panel-body">
                            <div class="col-sm-8" id="treeview_json">
                            </div>
                            </div>
                        </div>
                    </div>
               

            </section>
        </div>
 
    </section>
   


<div class="modal fade" id="myModalAdd" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-lock"></span> Select an action</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
          <div class="row">
          <div class="col-md-12 col-sm-12">
		
		<div class="row">
            <div class="col-md-6">
               <button onclick="addSubcategory()" class="btn"><i class="fa fa-pencil"> Add Folder</i></button>
            </div>
            
            <div class="col-md-6">
                <button onclick="addFile()" class="btn"><i class="fa fa-pencil"> Add Account</i></button>
            </div>
        </div>	
        <?php 
        echo form_open('submit_add_subcategory');?>
		<div class="row mt-3" id="addSubcategory" style="display: none;">
            <p style="margin-top:10px;"><b>Add Sub Category</b></p>
            
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">Folder name <abbr class="required">::*::</abbr></label>
                <div class="col-md-8">
                    <input type="text" name="folder_name"  class="form-control" required>
                <div class="form_error">  </div>
                </div>
            </div>
            <input type="hidden" id="SubcategoryFile" name="file"  value="0">
            <input type="hidden" id="SubcategoryParent" name="parent" >
            <div class="col-md-12 col-md-offset-10">
            <button class="btn btn-primary ">Submit</button>
            </div>
        </div>
        <?php
        echo form_close();?>
        <?php 
        echo form_open('submit_add_file');?>
		<div class="row mt-3" id="addFile" style="display: none;">
            <p style="margin-top:10px;"><b>Add account data</b></p>
            
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">Account name <abbr class="required">::*::</abbr></label>
                <div class="col-md-8">
                    <input type="text" name="file_name"  class="form-control" required>
                <div class="form_error">  </div>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">Email <abbr class="required">::*::</abbr></label>
                <div class="col-md-8">
                    <input type="email" name="email"  class="form-control" required>
                <div class="form_error">  </div>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">TRN<abbr class="required">::*::</abbr></label>
                <div class="col-md-8">
                    <input type="text" name="vat_no"  class="form-control" required>
                <div class="form_error">  </div>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">Mobile <abbr class="required">::*::</abbr></label>
                <div class="col-md-8">
                    <input type="text" name="mobile_phone"  class="form-control" required>
                <div class="form_error">  </div>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">Phone <abbr class="required"></abbr></label>
                <div class="col-md-8">
                    <input type="text" name="phone"  class="form-control" >
                <div class="form_error">  </div>
                </div>
            </div>
            
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">Contact Person <abbr class="required"></abbr></label>
                <div class="col-md-8">
                    <input type="text" name="contact_person"  class="form-control" >
                <div class="form_error">  </div>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">Address<abbr class="required"></abbr></label>
                <div class="col-md-8">
                    <input type="text" name="address"  class="form-control" >
                <div class="form_error">  </div>
                </div>
            </div>
            
            <input type="hidden" name="file"  value="1">
            <input type="hidden" id="FileParent" name="parent" >
            <div class="col-md-12 col-md-offset-10">
            <button class="btn btn-primary ">Submit</button>
            </div>
        </div>
        <?php
        echo form_close();?>        
	</div>

          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger btn-default pull-right" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
         
        </div>
      </div>
      
    </div>
  </div> 


<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-lock"></span> Select an action</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
          <div class="row">
              <div class="col-md-4">
                <button class="btn btn-default" onclick="move()">Move</button>
              </div>
              <div class="col-md-4">
              <button class="btn btn-default" onclick="viewData()">View</button>
              </div>
              <div class="col-md-4">
              <button class="btn btn-default" onclick="editData()">Edit</button>
              </div>

          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger btn-default pull-right" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
         
        </div>
      </div>
      
    </div>
  </div> 

  <div class="modal fade" id="myModalViewData" role="dialog">
 
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">View</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body" id="viewData">
          
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  
  </div> 


    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery/jquery.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>vendor/select2/select2.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.custom.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.init.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

    
   
    
  <script type="text/javascript" charset="utf8" src="<?php echo base_url('admin_assets/'); ?>javascripts/bootstrap-treeview.min.js"></script>
    <script type="text/javascript">
        var ids = new Array();
        var expand_count = new Array();
        // $('.tree').treegrid();
       
        // $('.tree').treegrid('collapseAll');
       
        $('#input-search').on('keyup',function(){
            console.log('here');
            
          var pattern = $('#input-search').val();
          console.log(pattern);
          var options = {
            ignoreCase: true,     // case insensitive
            exactMatch: false,    // like or equals
            revealResults: true,  // reveal matching nodes
          };
          var results = $('#tree').treeview('search', [ pattern, options ]);
          console.log(results.length);
        //   var output = '<p>' + results.length + ' matches found</p>';
        //   $.each(results, function (index, result) {
        //     output += '<p>- ' + result.text + '</p>';
        //   });
        //   $('#search-output').html(output);
        
      
            //var results = $searchableTree.treeview('search', [ pattern, options ]);
        });

        $(document).ready(function(){
            window.move_enabled = 0;
  var treeData;
  
  $.ajax({
       type: "GET",  
       url: "<?php echo site_url('getItem/')?>",
       dataType: "json",       
       success: function(response)  
       {
          initTree(response)
       }   
 });

   
 function initTree(treeData) {
     
     
   $('#treeview_json').treeview({
       data: treeData,
       
       enableLinks:true,
       tags: ['available'],
       showTags:true,
    });
   $('#treeview_json').on('nodeSelected ', function(event, data) {
        window.treeId = data.id;
        console.log(data);
        if(move_enabled === 0)
        {
            $('#SubcategoryParent').val(data.id);
       
            $('#FileParent').val(data.id);
            if(data.file === '1')
            {
                $("#myModal").modal();
            }
            else
            {
                $("#myModalAdd").modal();
            }
        }
        else
        {
            $.ajax({
                type: "POST",  
                url: "<?php echo site_url('accountsMove/')?>",
                data:{"selected_id":treeId, "move_id":move_treeId},
                // dataType: "json",       
                success: function(response)  
                {
                    window.move_enabled = 0;
                    console.log(response);
                    location.reload();
                }   
            });
        }
       
        // $('#modalLG').modal('toggle');
        // $('#modalLG').modal('show');
    });
 }
  
});

       
        function showModal(id)
        {
            $('#SubcategoryParent').val(id);
            $('#nameTree').html();
            $('#FileParent').val(id);
            console.log(id);
            
        }
        

        
        function addSubcategory()
        {
            var file = document.getElementById("addFile");
            file.style.display = "none";
            var cat = document.getElementById("addSubcategory");
            cat.style.display = "block";

        }
        function addFile()
        {
            var cat = document.getElementById("addSubcategory");
            cat.style.display = "none";
            var file = document.getElementById("addFile");
            file.style.display = "block";

        }
        function addAccount()
        {
            $("#myModalAdd").modal();
            addFile();
            $('#SubcategoryParent').val('0');

            $('#FileParent').val('0');
        }
        function move()
        {
            window.move_enabled = 1;
            window.move_treeId = treeId;
            $("#myModal").modal('hide');
            console.log(treeId);
        }

        function viewData()
        {
            $("#myModal").modal('hide');
            console.log(treeId);
            $.ajax({
                type: "POST",  
                url: "<?php echo site_url('accountsTreeView/')?>",
                data:{"id":treeId},
                // dataType: "json",       
                success: function(response)  
                {
                    $('#viewData').html(response);
                    console.log(response);
                }   
            });
            $("#myModalViewData").modal();
            
        }
        function editData()
        {  
            window.location.href = "<?php echo site_url('editData/'); ?>"+treeId;
        }
    </script>

</body>

</html>