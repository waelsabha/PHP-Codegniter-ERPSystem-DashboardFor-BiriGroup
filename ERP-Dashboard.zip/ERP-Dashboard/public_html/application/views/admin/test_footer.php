
<script type="text/javascript">
	$(".nav-parent").on("click", function(){
	
   $(this).removeClass("nav-parent").addClass("nav-parent nav-expanded nav-active");
   // $(this).addClass("active");
});
</script>