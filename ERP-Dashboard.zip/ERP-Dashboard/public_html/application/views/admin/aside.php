<aside id="sidebar-left" class="sidebar-left">

<div class="input-group input-search">
<input type="text" class="form-control" value="" id="mySearch" placeholder="Search...">
<span class="input-group-btn">
<button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
</span>
</div>
<div class="sidebar-header">

<div class="sidebar-title" style="color: white;">
<?php echo $this->lang->line('Navigation'); ?>
</div>

<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
</div>

</div>
<div class="nano">
<div class="nano-content">
<nav id="menu" class="nav-main" role="navigation">
<ul class="nav nav-main myMenu">
<li <?php if(strpos($_SERVER['REQUEST_URI'],'accounts-head') || (strpos($_SERVER['REQUEST_URI'],'add-customers')) || (strpos($_SERVER['REQUEST_URI'],'add-suppliers')) || (strpos($_SERVER['REQUEST_URI'],'incoming-payment')) || (strpos($_SERVER['REQUEST_URI'],'outgoing-payment')) || strpos($_SERVER['REQUEST_URI'],'production-entry') || (strpos($_SERVER['REQUEST_URI'],'list-production')) || (strpos($_SERVER['REQUEST_URI'],'prd_extra_details_excel')) || (strpos($_SERVER['REQUEST_URI'],'upload-production-excel')) || (strpos($_SERVER['REQUEST_URI'],'prd-category')) || (strpos($_SERVER['REQUEST_URI'],'prd-brands')) || (strpos($_SERVER['REQUEST_URI'],'prd-units')) || (strpos($_SERVER['REQUEST_URI'],'prd-variations')) || (strpos($_SERVER['REQUEST_URI'],'prd-hse-codes')) || (strpos($_SERVER['REQUEST_URI'],'prd-final-values')) || strpos($_SERVER['REQUEST_URI'],'manage_assets/vehicle') || (strpos($_SERVER['REQUEST_URI'],'manage_assets/tools'))  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a >
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Company'); ?></span>
</a>
<ul class="nav nav-children myMenu" >

<?php
if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts"))
{
	?>
	<li >
	<a class="menu_name_fun" href="<?php echo base_url('master-db-backup');?>">
	<i class="fa fa-home" aria-hidden="true"></i>
	<span><?php echo $this->lang->line('Backup'); ?></span>
	</a>
	</li>
	<li >
	<a class="menu_name_fun">
	<i class="fa fa-home" aria-hidden="true"></i>
	<span><?php echo $this->lang->line('Setting'); ?></span>
	</a>
	</li>
    <?php
if(  (($this ->session->userdata['user']['role'])=="1") )
{?>

<li <?php if(strpos($_SERVER['REQUEST_URI'],'create-prd-grps-pricing') || (strpos($_SERVER['REQUEST_URI'],'set-prd-grps-pricing')) || (strpos($_SERVER['REQUEST_URI'],'check-standard-pricing')) || (strpos($_SERVER['REQUEST_URI'],'check-customized-pricing')) ||(strpos($_SERVER['REQUEST_URI'],'pricing-uk')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-list-alt" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Costing'); ?> </span>
</a>
<ul class="nav nav-children myMenu">

	<li  <?php if((strpos($_SERVER['REQUEST_URI'],'create-prd-grps-pricing')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('create-prd-grps-pricing');?>"><?php echo $this->lang->line('Create Groups'); ?> </a></li>
	<li  <?php if((strpos($_SERVER['REQUEST_URI'],'set-prd-grps-pricing')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('set-prd-grps-pricing');?>"><?php echo $this->lang->line('Set Group Pricing'); ?></a></li>

	<li  <?php if((strpos($_SERVER['REQUEST_URI'],'pricing-uk')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('pricing-uk');?>"><?php echo $this->lang->line('Product Pricing UK'); ?></a></li>
</ul>
</li>
<?php
}
?>



	<?php
}?>

	<li <?php if( strpos($_SERVER['REQUEST_URI'],'accounts-head') || (strpos($_SERVER['REQUEST_URI'],'list_tree')) || (strpos($_SERVER['REQUEST_URI'],'master-accounts-tree')) || (strpos($_SERVER['REQUEST_URI'],'incoming-payment')) || (strpos($_SERVER['REQUEST_URI'],'outgoing-payment')) || strpos($_SERVER['REQUEST_URI'],'production-entry') || (strpos($_SERVER['REQUEST_URI'],'list-production')) || (strpos($_SERVER['REQUEST_URI'],'prd_extra_details_excel')) || (strpos($_SERVER['REQUEST_URI'],'upload-production-excel')) || (strpos($_SERVER['REQUEST_URI'],'prd-category')) || (strpos($_SERVER['REQUEST_URI'],'prd-brands')) || (strpos($_SERVER['REQUEST_URI'],'prd-units')) || (strpos($_SERVER['REQUEST_URI'],'prd-variations')) || (strpos($_SERVER['REQUEST_URI'],'prd-hse-codes')) || (strpos($_SERVER['REQUEST_URI'],'prd-final-values'))   ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
	<a>
	<i class="fa fa-home" aria-hidden="true"></i>
	<span><?php echo $this->lang->line('Masters'); ?></span>
	</a>
	<ul class="nav nav-children myMenu">
		<?php
		if( (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") )
			{?>
			
			<li  <?php if((strpos($_SERVER['REQUEST_URI'],'list_tree')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('list_tree');?>">
				 	<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Account Tree Master'); ?> </span>
				
				</a>
				</li>

				
						<?php
					}?>


       <!--this is new addition to positions-->

    
			<?php
			$pages=$this ->session->userdata['user']['pages_permission'];
			$page_compare=explode(',',$pages);

	if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Sales") || (in_array('list-positions',$page_compare)) || (in_array('list_terms',$page_compare))  )
			{
			?>
			<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-positions') || (strpos($_SERVER['REQUEST_URI'],'list_terms')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Position Management'); ?></span>
			</a>
				<ul class="nav nav-children myMenu">
			
				<li   <?php if((strpos($_SERVER['REQUEST_URI'],'list_positions')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('list_positions');?>">
				 	<i class="fa fa-home" aria-hidden="true"></i>
			      <span><?php echo $this->lang->line('Positions Manager'); ?></span>
				
				</a>
				</li>
		
				
			
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'list_terms')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('list_terms');?>">
				 	<i class="fa fa-home" aria-hidden="true"></i>
		        	<span><?php echo $this->lang->line('Terms of Contract'); ?></span>
				</a>
				</li>

                  		<li  <?php if((strpos($_SERVER['REQUEST_URI'],'list_salary_structure')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('list_salary_structure');?>">
				 	<i class="fa fa-home" aria-hidden="true"></i>
		        	<span><?php echo $this->lang->line('Salary Structure'); ?>  </span>
				</a>
				</li>

				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'job_offer_sts_list')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('job_offer_sts_list');?>">
				 	
		        	<span> <?php echo $this->lang->line('Job Offer Requests'); ?> </span>
				</a>
				</li>
				



				
				</ul>
			</li>
			<?php
			}?>






    



			<?php
			$pages=$this ->session->userdata['user']['pages_permission'];
			$page_compare=explode(',',$pages);


			if(   (($this ->session->userdata['user']['role'])=="1") || (in_array('list-production',$page_compare)) || (in_array('production-entry',$page_compare)) || (in_array('prd-brands',$page_compare)) || (in_array('upload-production-excel',$page_compare)) || (in_array('prd-category',$page_compare)) || (in_array('prd-units',$page_compare)) || (in_array('prd-variations',$page_compare)) || (in_array('prd-hse-codes',$page_compare)) || (in_array('prd-final-values',$page_compare)) )
			{
			?>
			<li <?php if(strpos($_SERVER['REQUEST_URI'],'production-entry') || (strpos($_SERVER['REQUEST_URI'],'list-production')) || (strpos($_SERVER['REQUEST_URI'],'prd_extra_details_excel')) || (strpos($_SERVER['REQUEST_URI'],'upload-production-excel')) || (strpos($_SERVER['REQUEST_URI'],'prd-category')) || (strpos($_SERVER['REQUEST_URI'],'prd-brands')) || (strpos($_SERVER['REQUEST_URI'],'prd-units')) || (strpos($_SERVER['REQUEST_URI'],'prd-variations')) || (strpos($_SERVER['REQUEST_URI'],'prd-hse-codes')) || (strpos($_SERVER['REQUEST_URI'],'prd-final-values'))  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Product Tree'); ?></span>
			</a>
				<ul class="nav nav-children myMenu">
			<?php	if(   (($this ->session->userdata['user']['role'])=="1") )
				{?>
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'product-master')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('product-master');?>">
				 	<i class="fa fa-home" aria-hidden="true"></i>
			<span> <?php echo $this->lang->line('Product Tree Master'); ?></span>
				
				</a>
				</li>
				<?php
				}?>
				<?php
				if((in_array('production-entry',$page_compare)))
				{
				?>
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'production-entry')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('production-entry');?>">
				<?php echo $this->lang->line('Add Products'); ?> 
				</a>
				</li>
				<?php
				}
				if((in_array('list-production',$page_compare)))
				{
				?>
				
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'list-production')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('list-production');?>">
				<?php echo $this->lang->line('Product List'); ?>  
				</a>
				</li>
				
				 <li  <?php if((strpos($_SERVER['REQUEST_URI'],'prd_extra_details_excel')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('prd_extra_details_excel');?>">
				<?php echo $this->lang->line('Upload Product Extra Details Excel Sheet'); ?>  
				</a>
				</li> 
			         <?php
			         }
			         if((in_array('upload-production-excel',$page_compare)))
				{
			         ?>
				 <li  <?php if((strpos($_SERVER['REQUEST_URI'],'upload-production-excel')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('upload-production-excel');?>">
				 <?php echo $this->lang->line('Upload Product Excel Sheet'); ?> 
				</a>
				</li> 
				<?php
				}
				if((in_array('prd-category',$page_compare)))
				{
				?>
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'prd-category')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('prd-category');?>">
				 <?php echo $this->lang->line('Category'); ?> 
				</a>
				</li>
				<?php
				}
				if((in_array('prd-brands',$page_compare)))
				{
				?>
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'prd-brands')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('prd-brands');?>">
				 <?php echo $this->lang->line('Brands'); ?>
				</a>
				</li>
				<?php
				}
				if((in_array('prd-units',$page_compare)))
				{
				?>
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'prd-units')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('prd-units');?>">
				<?php echo $this->lang->line('Units'); ?>
				</a>
				</li>
				<?php
				}
				if((in_array('prd-variations',$page_compare)))
				{
				?>
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'prd-variations')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('prd-variations');?>">
				<?php echo $this->lang->line('Variations'); ?>
				</a>
				</li>
				<?php
				}
				if((in_array('prd-hse-codes',$page_compare)))
				{
				?>
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'prd-hse-codes')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('prd-hse-codes');?>">
				<?php echo $this->lang->line('HS Codes'); ?>
				</a>
				</li>
				<?php
				}
				if((in_array('prd-final-values',$page_compare)))
				{
				?>
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'prd-final-values')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('prd-final-values');?>">
				<?php echo $this->lang->line('UAE & KSA Percentages'); ?> 
				</a>
				</li>
				<?php
				}
				
				?>	
				</ul>
			</li>
			<?php
			}?>
			<?php
if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") )
{?>
				<li >
			<a class="menu_name_fun" href="<?php echo base_url('master-company');?>">
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Company'); ?></span>
			</a>
			</li>

			<li >
			<a class="menu_name_fun" href="<?php echo base_url('master-currency-converter');?>">
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Currency Conv.'); ?></span>
			</a>
			</li>

			<li >
			<a href="<?php echo base_url('master-warehouse');?>">
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Warehouse'); ?></span>
			</a>
			</li>

            	<li >
			<a href="<?php echo base_url('master-place-supply');?>">
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Place of Supply'); ?></span>
			</a>
			</li>

			<li >
			<a href="<?php echo base_url('master-price-level');?>">
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Pricelevel'); ?></span>
			</a>
			</li>
			<li >
			<a href="<?php echo base_url('master-project');?>">
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Projects'); ?></span>
			</a>
			</li>
			<li >
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Salesman'); ?></span>
			</a>
			</li>

			<li >
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Department'); ?></span>
			</a>
			</li>

			<li >
			<a href="<?php echo base_url('master-payment-methods-master');?>">
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Payment Method'); ?></span>
			</a>
			</li>
<?php
}?>
			
			<?php
			if(  (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") )
			{?> 
			<li <?php if(strpos($_SERVER['REQUEST_URI'],'manage_assets/vehicle') || (strpos($_SERVER['REQUEST_URI'],'manage_assets/tools'))  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-list-alt" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Company Assets'); ?> </span>
			</a>
			<ul class="nav nav-children myMenu">

				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'manage_assets/vehicle')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('manage_assets/vehicle');?>"><?php echo $this->lang->line('Vehicle Assets'); ?></a>
				</li>
				<li  <?php if((strpos($_SERVER['REQUEST_URI'],'manage_assets/tools')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('manage_assets/tools');?>"><?php echo $this->lang->line('Tools Assets'); ?></a>
				</li>
			</ul>
			</li>
			
			<?php
			}?>
			<?php
		if( (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") )
			{?>
			
			<li  <?php if((strpos($_SERVER['REQUEST_URI'],'fixed-asset-tree')) ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('fixed-asset-tree');?>">
				 	<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Fixed Asset Tree Master'); ?> </span>
				
				</a>
				</li>
					<?php
					}?>
			
<?php
if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") )
{?>
			<li>
			<a href="<?php echo base_url('master-region');?>">
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Region'); ?></span>
			</a>
			</li>

			<li >
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Port of load/dock'); ?></span>
			</a>
			</li>


			<li>
			<a>
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Bin'); ?></span>
			</a>
			</li>

			<li>
			<a href="<?php echo base_url('shopify-price-test/uae');?>">
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Shopify_test_price_uae'); ?></span>
			</a>
			</li>
			<?php
		}?>
	</ul>
	</li>
	<?php
if(   (($this ->session->userdata['user']['role'])=="1"))
{?>
	<li >
	<a >
	<i class="fa fa-home" aria-hidden="true"></i>
	<span><?php echo $this->lang->line('Security'); ?></span>
	</a>
	</li>
	<!--	<li >
	<a class="menu_name_fun" href="<?php echo base_url('dashboard-calender');?>">
	<i class="fa fa-home" aria-hidden="true"></i>
	<span><?php echo $this->lang->line('Google Calender'); ?></span>
	
	</a>
	</li>-->


		<li >
	<a href="<?php echo base_url('task-schedule');?>" >
	<i class="fa fa-home" aria-hidden="true"></i>
	<span><?php echo $this->lang->line('Task Scheduler'); ?></span>
	</a>
	</li>
	<?php
}?>
</ul>
</li>	

<li <?php if(strpos($_SERVER['REQUEST_URI'],'product-order') || (strpos($_SERVER['REQUEST_URI'],'prd-order-list')) || (strpos($_SERVER['REQUEST_URI'],'prd-order-sts'))
 || strpos($_SERVER['REQUEST_URI'],'add_item_request') ||strpos($_SERVER['REQUEST_URI'],'add_item_request_ksa') ||strpos($_SERVER['REQUEST_URI'],'add_item_request_uk')||strpos($_SERVER['REQUEST_URI'],'add_item_request_ca')  || (strpos($_SERVER['REQUEST_URI'],'list-item-request')) 
 || (strpos($_SERVER['REQUEST_URI'],'generate-shipment-item-request'))||  (strpos($_SERVER['REQUEST_URI'],'list-generate-shipment'))
  || strpos($_SERVER['REQUEST_URI'],'add-quotation') || (strpos($_SERVER['REQUEST_URI'],'list-quotation')) || (strpos($_SERVER['REQUEST_URI'],'list-porforma')) 
  || (strpos($_SERVER['REQUEST_URI'],'add-signature')) || (strpos($_SERVER['REQUEST_URI'],'price-list')) || (strpos($_SERVER['REQUEST_URI'],'update-product-stock-1'))
   || (strpos($_SERVER['REQUEST_URI'],'list-stock')) || strpos($_SERVER['REQUEST_URI'],'list-receipt') || (strpos($_SERVER['REQUEST_URI'],'list-payments'))
    || (strpos($_SERVER['REQUEST_URI'],'list-petty-cash')) || (strpos($_SERVER['REQUEST_URI'],'list-pdr')) || (strpos($_SERVER['REQUEST_URI'],'list-pdp'))
	||  (strpos($_SERVER['REQUEST_URI'],'list-completed-item-request')) ||  (strpos($_SERVER['REQUEST_URI'],'list-rejected-item-request')) ||
	 (strpos($_SERVER['REQUEST_URI'],'opening-stock')) || (strpos($_SERVER['REQUEST_URI'],'list-opening-stock')) || 
	 (strpos($_SERVER['REQUEST_URI'],'stock-excess')) ||  (strpos($_SERVER['REQUEST_URI'],'list-excess-stock')) || 
	 (strpos($_SERVER['REQUEST_URI'],'stock-shortage')) ||  (strpos($_SERVER['REQUEST_URI'],'list-shortage-stock')) ||
	  (strpos($_SERVER['REQUEST_URI'],'stock-adjustment')) || (strpos($_SERVER['REQUEST_URI'],'list-adjustment-stock'))
	  || (strpos($_SERVER['REQUEST_URI'],'stock-transfer')) || (strpos($_SERVER['REQUEST_URI'],'list-transfer-stock')) || (strpos($_SERVER['REQUEST_URI'],'delivery-note'))
       || (strpos($_SERVER['REQUEST_URI'],'list-delivery-note')) || strpos($_SERVER['REQUEST_URI'],'list-sales-return') || strpos($_SERVER['REQUEST_URI'],'sales-return')
	   || strpos($_SERVER['REQUEST_URI'],'list-sales-invoice') || strpos($_SERVER['REQUEST_URI'],'sales-invoice') 
	   || (strpos($_SERVER['REQUEST_URI'],'list-current-stock')) || (strpos($_SERVER['REQUEST_URI'],'stock-delivery-report')) || 
	   strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uae') || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/ksa')) || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/dragon')) 
	   ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Transactions'); ?></span>
</a>
<ul class="nav nav-children myMenu">
	<?php
if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts")  ||($this ->session->userdata['user']['main_dept']=="Sales")    )
{?>
		<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-receipt') || (strpos($_SERVER['REQUEST_URI'],'list-payments')) || (strpos($_SERVER['REQUEST_URI'],'list-petty-cash')) || (strpos($_SERVER['REQUEST_URI'],'list-pdr')) || (strpos($_SERVER['REQUEST_URI'],'list-pdp'))   ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Cash & Bank'); ?></span>
			</a>
			<ul class="nav nav-children">
				<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-receipt')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-receipt');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Receipt'); ?></span>
					</a>
				</li>
				<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-payments')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-payments');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Payments'); ?></span>
					</a>
				</li>
				<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-petty-cash')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-petty-cash');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Petty Cash'); ?></span>
					</a>
				</li>
				<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-pdr')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-pdr');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Post-Dated Cheque Receipts'); ?> </span>
					</a>
				</li>
				<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-pdp')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-pdp');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Post-Dated Cheque Payments'); ?> </span>
					</a>
				</li>


				

			    	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-pdp')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-cheque');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Cheque-Follow-Up'); ?> </span>
					</a>
				</li>

			</ul>
		</li>
		<?php
	}?>
		<li <?php if(strpos($_SERVER['REQUEST_URI'],'product-order') || (strpos($_SERVER['REQUEST_URI'],'prd-order-list')) 
		|| (strpos($_SERVER['REQUEST_URI'],'prd-order-sts')) || strpos($_SERVER['REQUEST_URI'],'add_item_request') || strpos($_SERVER['REQUEST_URI'],'add_item_request_ksa')  || strpos($_SERVER['REQUEST_URI'],'add_item_request_uk') || strpos($_SERVER['REQUEST_URI'],'add_item_request_ca')  ||
		 (strpos($_SERVER['REQUEST_URI'],'list-item-request'))||  ($this ->session->userdata['user']['main_dept']=="Sales"  && $this->session->userdata['user']['sub_dept']=="ksa"  )         || (strpos($_SERVER['REQUEST_URI'],'generate-shipment-item-request'))|| 
		  (strpos($_SERVER['REQUEST_URI'],'list-generate-shipment'))||  (strpos($_SERVER['REQUEST_URI'],'list-completed-item-request'))
		   ||  (strpos($_SERVER['REQUEST_URI'],'list-rejected-item-request'))    ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Purchases'); ?></span>
			</a>
			<ul class="nav nav-children myMenu">
				<?php
				$pages=$this ->session->userdata['user']['pages_permission'];
				$page_compare=explode(',',$pages);
				if( (in_array("product-order",$page_compare)) || (in_array('prd-order-list',$page_compare)) ||(in_array('prd-order-sts',$page_compare)) )
				{?>
				<li <?php if(strpos($_SERVER['REQUEST_URI'],'product-order') || (strpos($_SERVER['REQUEST_URI'],'prd-order-list'))|| 
				(strpos($_SERVER['REQUEST_URI'],'prd-order-sts'))   ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
				<a>
				<i class="fa fa-tasks" aria-hidden="true"></i>
				<span><?php echo $this->lang->line('Production Order'); ?></span>
				</a>
				<ul class="nav nav-children myMenu">
					<?php
					if(in_array('product-order',$page_compare))
					{?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'product-order')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('product-order');?>">
					<?php echo $this->lang->line('Add Production Order'); ?> 
					</a>
					</li>
					<?php
					}if(in_array('prd-order-list',$page_compare))
					{
					?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'prd-order-list')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('prd-order-list');?>">
					<?php echo $this->lang->line('List Production Order'); ?>
					</a>
					</li>
					<?php
					}if(in_array('prd-order-sts',$page_compare))
					{?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'prd-order-sts')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('prd-order-sts');?>">
					<?php echo $this->lang->line('Check production status'); ?>	
					</a>
					</li>
					<?php
					}?>
				</ul>	
				</li>
				<?php
				}?>

				<?php
				$pages=$this ->session->userdata['user']['pages_permission'];
				$page_compare=explode(',',$pages);
				if( (($this ->session->userdata['user']['role'])=="1") ||(in_array('add_item_request',$page_compare)) ||(in_array('add_item_request_ksa',$page_compare))||(in_array('add_item_request_uk',$page_compare))||(in_array('add_item_request_ca',$page_compare)) || (in_array('list-item-request',$page_compare))
				|| (in_array('list-rejected-item-request',$page_compare)) || (in_array('list-completed-item-request',$page_compare)) )
				{
				?>
				<li <?php if(strpos($_SERVER['REQUEST_URI'],'add_item_request') ||strpos($_SERVER['REQUEST_URI'],'add_item_request_ksa') ||strpos($_SERVER['REQUEST_URI'],'add_item_request_uk') ||strpos($_SERVER['REQUEST_URI'],'add_item_request_ca')   || (strpos($_SERVER['REQUEST_URI'],'list-item-request')) 
				|| (strpos($_SERVER['REQUEST_URI'],'generate-shipment-item-request'))||  (strpos($_SERVER['REQUEST_URI'],'list-generate-shipment')) 
				||  (strpos($_SERVER['REQUEST_URI'],'list-completed-item-request')) ||(strpos($_SERVER['REQUEST_URI'],'list-product-costing'))||  (strpos($_SERVER['REQUEST_URI'],'list-rejected-item-request'))
				 ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
				<a>
				<i class="fa fa-tasks" aria-hidden="true"></i>
				<span><?php echo $this->lang->line('Item Request'); ?></span>
				</a>
				<ul class="nav nav-children myMenu">
					<?php

                        if( (($this ->session->userdata['user']['role'])=="1"))
                      {

                       ?>
							 <li <?php if((strpos($_SERVER['REQUEST_URI'],'add_item_request')) ){echo 'class="nav-active"';};?>>
							<a class="menu_name_fun" href="<?php echo base_url('add_item_request');?>">
						<?php echo $this->lang->line('Create Item Request'); ?>		
							</a>
							</li>

						<li <?php if((strpos($_SERVER['REQUEST_URI'],'add_item_request_ksa')) ){echo 'class="nav-active"';};?>>
						<a class="menu_name_fun" href="<?php echo base_url('add_item_request_ksa');?>">
						<?php echo $this->lang->line('Create Item Request KSA'); ?>	
						</a>
						</li>

						<li <?php if((strpos($_SERVER['REQUEST_URI'],'add_item_request_uk')) ){echo 'class="nav-active"';};?>>
						<a class="menu_name_fun" href="<?php echo base_url('add_item_request_uk');?>">
						<?php echo $this->lang->line('Create Item Request UK'); ?>	
						</a>
						</li>
						<li <?php if((strpos($_SERVER['REQUEST_URI'],'add_item_request_ca')) ){echo 'class="nav-active"';};?>>
						<a class="menu_name_fun" href="<?php echo base_url('add_item_request_ca');?>">
						<?php echo $this->lang->line('Create Item Request CA'); ?>	
						</a>
						</li>
					<?php
					}











					 
					else if((in_array('add_item_request',$page_compare)))
					{
					?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'add_item_request')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('add_item_request');?>">
					<?php echo $this->lang->line('Create Item Request'); ?>	
					</a>
					</li>
					<?php
					}

					else if((in_array('add_item_request_ksa',$page_compare)) )
					{

					?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'add_item_request_ksa')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('add_item_request_ksa');?>">
					<?php echo $this->lang->line('Create Item Request KSA'); ?>	
					</a>
					</li>
					<?php
					}
						else if((in_array('add_item_request_uk',$page_compare)) )
					{

					?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'add_item_request_uk')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('add_item_request_uk');?>">
					<?php echo $this->lang->line('Create Item Request UK'); ?>	
					</a>
					</li>
					<?php
					}
						else if((in_array('add_item_request_ca',$page_compare)) )
					{

					?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'add_item_request_ca')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('add_item_request_ca');?>">
					<?php echo $this->lang->line('Create Item Request CA'); ?>	
					</a>
					</li>
					<?php
					}
					
					if((in_array('list-item-request',$page_compare)))
					{
					?>
					<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-item-request') || (strpos($_SERVER['REQUEST_URI'],'list-completed-item-request')) || (strpos($_SERVER['REQUEST_URI'],'list-rejected-item-request')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?> >
					<a>
						<i class="fa fa-tasks" aria-hidden="true"></i>
						<span><?php echo $this->lang->line('List Item Request'); ?></span>
					</a>
						<ul class="nav nav-children myMenu">
							<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-item-request')) ){echo 'class="nav-active"';};?>>
							<a class="menu_name_fun" href="<?php echo base_url('list-item-request');?>">
							<?php echo $this->lang->line('List All Item Request'); ?>
							</a>
							</li>
              
              	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-item-request-ksa')) ){echo 'class="nav-active"';};?>>
							<a class="menu_name_fun" href="<?php echo base_url('list-item-request-ksa');?>">
							<?php echo $this->lang->line('List All Item Request ksa'); ?>
							</a>
							</li>
              	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-item-request-uk')) ){echo 'class="nav-active"';};?>>
							<a class="menu_name_fun" href="<?php echo base_url('list-item-request-uk');?>">
							<?php echo $this->lang->line('List All Item Request uk'); ?>
							</a>
							</li>
              	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-item-request-ca')) ){echo 'class="nav-active"';};?>>
							<a class="menu_name_fun" href="<?php echo base_url('list-item-request-ca');?>">
							<?php echo $this->lang->line('List All Item Request ca'); ?>
							</a>
							</li>

							<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-completed-item-request')) ){echo 'class="nav-active"';};?>>
							<a class="menu_name_fun" href="<?php echo base_url('list-completed-item-request');?>">
							<?php echo $this->lang->line('List Completed Item Request'); ?>
							</a>
							</li>

							<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-rejected-item-request')) ){echo 'class="nav-active"';};?>>
							<a class="menu_name_fun" href="<?php echo base_url('list-rejected-item-request');?>">
						<?php echo $this->lang->line('List Rejected Item Request'); ?>
							</a>
							</li>
						</ul>	
					</li>
					<?php
					}
					if((in_array('generate-shipment-item-request',$page_compare)))
					{
					?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'generate-shipment-item-request')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('generate-shipment-item-request');?>">
					<?php echo $this->lang->line('Generate Shipment'); ?>
					</a>
					</li>
					<?php
					}
					if((in_array('list-generate-shipment',$page_compare)))
					{
					?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-generate-shipment')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-generate-shipment');?>">
					<?php echo $this->lang->line('List Generate Shipment'); ?>
					</a>
					</li>
					<?php
					}	
					?>	
				</ul>
				</li>
				<?php
				}?>
		<?php
		if( (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") ||($this ->session->userdata['user']['main_dept']=="Purchase")|| (strpos($_SERVER['REQUEST_URI'], 'purchase-mrn')) ||(strpos($_SERVER['REQUEST_URI'],'list-product-costing')))
		{?>		
		<li >
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Request for Quotation'); ?></span>
			</a>
		</li>

		<li >
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Purchase Order'); ?></span>
			</a>
		</li>

		<?php
			if ((($this->session->userdata['user']['role']) == "1") || ($this->session->userdata['user']['main_dept'] == "Accounts")) {
		?>
			<li>
				<a href="<?php echo base_url('list-purchase-mrn'); ?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Material Receipt Note'); ?></span>
				</a>
			</li>
		<?php
		} ?>
		<?php
		if ((($this->session->userdata['user']['role']) == "1") || ($this->session->userdata['user']['main_dept'] == "Accounts")) {
		?>
			<li>
				<a href="<?php echo base_url('list-purchase-invoice'); ?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Purchase Invoice'); ?></span>
				</a>
			</li>
		<?php
		} ?>

		<li >
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Purchase Return'); ?></span>
			</a>
		</li>


		<?php

		if ((($this->session->userdata['user']['role']) == "1") || ($this->session->userdata['user']['main_dept'] == "Purchase") ||(strpos($_SERVER['REQUEST_URI'],'list-product-costing'))) {
		?>
			<li>
				<a href="<?php echo base_url('list-product-costing-details'); ?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Product Costing&Details'); ?></span>
				</a>
			</li>
		<?php
		} ?>

		<?php
		}?>
			</ul>
		</li>

		<li <?php if( strpos($_SERVER['REQUEST_URI'],'add-quotation') || (strpos($_SERVER['REQUEST_URI'],'list-quotation'))
		 || (strpos($_SERVER['REQUEST_URI'],'list-porforma')) || (strpos($_SERVER['REQUEST_URI'],'add-signature')) 
		 || (strpos($_SERVER['REQUEST_URI'],'price-list')) || (strpos($_SERVER['REQUEST_URI'],'update-product-stock-1')) 
		 || (strpos($_SERVER['REQUEST_URI'],'list-stock')) || strpos($_SERVER['REQUEST_URI'],'list-sales-return') || 
		 strpos($_SERVER['REQUEST_URI'],'sales-return')  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Sales'); ?></span>
			</a>

			<ul class="nav nav-children myMenu">
				<?php
if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") || (in_array("list-sales-invoice/uae",$page_compare)) || (in_array('list-sales-invoice/ksa',$page_compare)) || (in_array('list-sales-invoice/dragon',$page_compare)) || (in_array('list-sales-invoice/export',$page_compare)) )
{
	?>
				<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uae') || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/ksa')) || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/dragon'))|| 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/export'))
				){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-list-alt" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Sales_Invoice'); ?></span>
			</a>
			<ul class="nav nav-children myMenu">
				<?php
				if(in_array("list-sales-invoice/uae",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uae') ){echo "class='nav-active'";};?> >
				<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/uae');?>"><?php echo $this->lang->line('UAE_Sales_Invoice'); ?></a>
				</li>
				<?php
					}?>
				<?php
				if(in_array("list-sales-invoice/ksa",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/ksa') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/ksa');?>"><?php echo $this->lang->line('KSA_Sales_Invoice'); ?></a>
				</li>
				<?php
					}?>
				<?php
				if(in_array("list-sales-invoice/dragon",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/dragon') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/dragon');?>"><?php echo $this->lang->line('Dragon_Sales_Invoice'); ?></a>
				</li>
				<?php
					}?>
					
				<?php
				if(in_array("list-sales-invoice/export",$page_compare))
					{?>
                    
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/export') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/export');?>"><?php echo $this->lang->line('Export_Sales_Invoice'); ?></a>
				</li>
				<?php
					}?>

          




			</ul>
			</li>
				<?php
			}?>

<!--- return to here for sales invoice online-->

		<?php
if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") || (in_array("list-sales-invoice/uae-online",$page_compare)) || (in_array('list-sales-invoice/ksa-online',$page_compare)) || (in_array('list-sales-invoice/uk-online',$page_compare))  )
{
	?>
				<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uae-online') || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/ksa-online')) || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uk-online'))
				){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-list-alt" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Sales_Invoice_online_shop'); ?></span>
			</a>
			<ul class="nav nav-children myMenu">


                   <?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/UK') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/UK');?>"><?php echo $this->lang->line('UK_Sales_Invoice'); ?></a>
				</li>
				<?php
					}?>


                  		<?php
				if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uae-online') ){echo "class='nav-active'";};?> >
				<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/uae-online');?>"><?php echo $this->lang->line('UAE_Sales_Invoice_Online'); ?></a>
				</li>
				<?php
					}?>
				<?php
				if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/ksa-online') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/ksa-online');?>"><?php echo $this->lang->line('KSA_Sales_Invoice_Online'); ?></a>
				</li>
				<?php
					}?>
				<?php
				if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uk-online') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/uk-online');?>"><?php echo $this->lang->line('UK_Sales_Invoice_Online'); ?></a>
				</li>
				<?php
					}?>

			</ul>
			</li>
				<?php
			}?>

 <!-- now for Amazon Sales Invoice --> 
	<?php
if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") || (in_array("list-sales-invoice/uae-online",$page_compare)) || (in_array('list-sales-invoice/ksa-online',$page_compare)) || (in_array('list-sales-invoice/uk-online',$page_compare))  )
{
	?>
				<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uae-online') || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/ksa-online')) || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uk-online'))
				){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-list-alt" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Amazon_Sales_Invoice'); ?></span>
			</a>
			<ul class="nav nav-children myMenu">


   
                  <?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/UAEAmazon') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/UAEAmazon');?>"><?php echo $this->lang->line('UAE Amazon-Sales Invoice'); ?></a>
				</li>
				<?php
					}?>

                <?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/KSAamazon') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/KSAamazon');?>"><?php echo $this->lang->line('KSA Amazon-Sales Invoice'); ?></a>
				</li>
				<?php
					}?>

                  <?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/UKamazon') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-sales-invoice/ukamazon');?>"><?php echo $this->lang->line('UK Amazon-Sales Invoice'); ?></a>
				</li>
				<?php
					}?>    

			</ul>
			</li>
				<?php
			}?>
<!--for Order List -->
	<?php
if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") || (in_array("list-sales-invoice/uae-online",$page_compare)) || (in_array('list-sales-invoice/ksa-online',$page_compare)) || (in_array('list-sales-invoice/uk-online',$page_compare))  )
{
	?>
				<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uae-online') || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/ksa-online')) || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uk-online'))
				){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-list-alt" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Incoming_Orders'); ?></span>
			</a>
			<ul class="nav nav-children myMenu">


   
                  <?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/UAE') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-incoming-invoice-online/uae');?>"><?php echo $this->lang->line('List_Incoming_Orders-UAE'); ?></a>
				</li>
				<?php
					}?>

					<?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/KSA') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-incoming-invoice-online/ksa');?>"><?php echo $this->lang->line('List_Incoming_Orders-KSA'); ?></a>
				</li>
				<?php
					}?>

							<?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/UK') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-incoming-invoice-online/uk');?>"><?php echo $this->lang->line('List_Incoming_Orders-UK'); ?></a>
				</li>
				<?php
					}?>

							<?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/Canada') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-incoming-invoice-online/canda');?>"><?php echo $this->lang->line('List_Incoming_Orders-Canada'); ?></a>
				</li>
				<?php
					}?>

							<?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/Amazon') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-incoming-invoice-online/amazonuk');?>"><?php echo $this->lang->line('List_Incoming_Orders-Amazon'); ?></a>
				</li>
				<?php
					}?>
          		<?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/Amazon') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-incoming-invoice-online/amazonuae');?>"><?php echo $this->lang->line('List_Incoming_Orders-Amazon-UAE'); ?></a>
				</li>
				<?php
					}?>



        
         

			</ul>
			</li>
				<?php
			}?>




	<?php
if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") || (in_array("list-sales-invoice/uae-online",$page_compare)) || (in_array('list-sales-invoice/ksa-online',$page_compare)) || (in_array('list-sales-invoice/uk-online',$page_compare))  )
{
	?>
				<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uae-online') || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/ksa-online')) || 
				(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/uk-online'))
				){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-list-alt" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Import_Amazon'); ?></span>
			</a>
			<ul class="nav nav-children myMenu">


                <?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/KSAamazon') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-amazon-upload-uk');?>"><?php echo $this->lang->line('Import_Amazon_Orders_UK'); ?></a>
				</li>
				<?php
					}?>

					     <?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/KSAamazon') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-amazon-upload-uae');?>"><?php echo $this->lang->line('Import_Amazon_Orders_UAE'); ?></a>
				</li>
				<?php
					}?>
						     <?php
                   if(in_array("list-sales-invoice/export",$page_compare))
					{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-invoice/KSAamazon') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('update_amazon_payment');?>"><?php echo $this->lang->line('Update_amazon_Payment'); ?></a>
				</li>
				<?php
					}?>

         

			</ul>
			</li>
				<?php
			}?>




















				<?php
				$pages=$this ->session->userdata['user']['pages_permission'];
				$page_compare=explode(',',$pages);
				if( (($this ->session->userdata['user']['role'])=="1") ||(in_array('add-quotation',$page_compare)) || (in_array('list-quotation',$page_compare)) 
				|| (in_array('add-signature',$page_compare)) || ((in_array('price-list',$page_compare)))  )
				{
				?>
				<li <?php if(strpos($_SERVER['REQUEST_URI'],'add-quotation') || (strpos($_SERVER['REQUEST_URI'],'list-quotation')) || (strpos($_SERVER['REQUEST_URI'],'list-porforma')) || (strpos($_SERVER['REQUEST_URI'],'add-signature')) || (strpos($_SERVER['REQUEST_URI'],'price-list')) || (strpos($_SERVER['REQUEST_URI'],'update-product-stock-1')) || (strpos($_SERVER['REQUEST_URI'],'list-stock')) || (strpos($_SERVER['REQUEST_URI'],'check-customized-pricing'))  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
				<a>
				<i class="fa fa-tasks" aria-hidden="true"></i>
				<span><?php echo $this->lang->line('Sales Quotation'); ?></span>
				</a>
				<ul class="nav nav-children myMenu">
					<?php
					if((in_array('add-quotation',$page_compare)))
					{
					?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'add-quotation')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('add-quotation');?>">
					<?php echo $this->lang->line('Create Quotation'); ?>
					</a>
					</li>
					<?php
					}
					if((in_array('list-quotation',$page_compare)) || (in_array('list-quotation/rta',$page_compare)) || (in_array('list-quotation/pwr',$page_compare))  )
					{
					?>
					<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-quotation')||(strpos($_SERVER['REQUEST_URI'],'list-quotation/rta'))||(strpos($_SERVER['REQUEST_URI'],'list-quotation/pwr'))){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
				<a>
				<i class="fa fa-tasks" aria-hidden="true"></i>
				<span><?php echo $this->lang->line('Quotation - Lists'); ?></span>
				</a>
				<ul class="nav nav-children myMenu">
				<?php
				if((in_array('list-quotation',$page_compare)))
					{?>
						<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-quotation')) ){echo 'class="nav-active"';};?>>
						<a class="menu_name_fun" href="<?php echo base_url('list-quotation');?>">
						<?php echo $this->lang->line('List Quotation'); ?>
						</a>
						</li>
						<?php
					}
				if((in_array('list-quotation/rta',$page_compare))  )
					{?>
						<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-quotation/rta')) ){echo 'class="nav-active"';};?>>
						<a class="menu_name_fun" href="<?php echo base_url('list-quotation/rta');?>">
						<?php echo $this->lang->line('List Quotation-RTA Sharjah'); ?>
						</a>
						</li>
						<?php
					}
				if((in_array('list-quotation/pwr',$page_compare))   )
					{?>
						<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-quotation/pwr')) ){echo 'class="nav-active"';};?>>
						<a class="menu_name_fun" href="<?php echo base_url('list-quotation/pwr');?>">
						<?php echo $this->lang->line('List Quotation-PWRak'); ?>
						</a>
						</li>
						<?php
					}?>
					</ul>
				</li>	
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-porforma')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-porforma');?>">
					<?php echo $this->lang->line('List Porforma Invoice'); ?>
					</a>
					</li>
					<li  <?php if((strpos($_SERVER['REQUEST_URI'],'check-customized-pricing')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('check-customized-pricing');?>"><?php echo $this->lang->line('Signs - Price Calculation'); ?> 
					</a>
					</li>
					<?php
					}
					if((in_array('add-signature',$page_compare)))
					{
					?>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'add-signature')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('add-signature');?>">
					<?php echo $this->lang->line('Add stamp & Signature'); ?>
					</a>
					</li>
					<?php
					}
					if((in_array('price-list',$page_compare)))
					{?>
				
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'update-product-stock-1')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('update-product-stock-1');?>">
					<?php echo $this->lang->line('Update Product Stock'); ?>	
					</a>
					</li>
					<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-stock')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-stock');?>">
						<?php echo $this->lang->line('List Stock'); ?>
					</a>
					</li>
					
					<?php
					}?>

					
				</ul>
				</li>
				<?php
				}?>
				<?php
				$pages=$this ->session->userdata['user']['pages_permission'];
				$page_compare=explode(',',$pages);
				if( (($this ->session->userdata['user']['role'])=="1") || ((in_array('price-list',$page_compare)))  )
				{
				?>
				<li <?php if((strpos($_SERVER['REQUEST_URI'],'price-list')) ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('price-list');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Item Price Check'); ?></span>
					</a>
					</li>
					<?php
				}?>
				<?php
if(   (($this ->session->userdata['user']['role'])=="1") || (in_array("list-delivery-note/uae",$page_compare)) || (in_array('list-delivery-note/ksa',$page_compare)) || (in_array('list-delivery-note/dragon',$page_compare)) || (in_array('list-delivery-note/export',$page_compare))  ||(in_array('list-delivery-note/amazonuk',$page_compare))       || (in_array("list-sales-return",$page_compare))||(in_array("list-Amazon-price-uk",$page_compare))|| (in_array("list-check-new-price",$page_compare)) )
{
	?>		
	<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-delivery-note/uae') || (strpos($_SERVER['REQUEST_URI'],'list-delivery-note/ksa')) || (strpos($_SERVER['REQUEST_URI'],'list-delivery-note/dragon')) || (strpos($_SERVER['REQUEST_URI'],'list-delivery-note/export')) || (strpos($_SERVER['REQUEST_URI'],'list-delivery-note/amazonuk'))|| (strpos($_SERVER['REQUEST_URI'],'list-check-new-price'))  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-list-alt" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Delivery Note'); ?></span>
			</a>
			<ul class="nav nav-children myMenu">
				<?php
				if(in_array("list-delivery-note/uae",$page_compare))
				{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-delivery-note/uae') ){echo "class='nav-active'";};?> >
				<a class="menu_name_fun" href="<?php echo base_url('list-delivery-note/uae');?>"><?php echo $this->lang->line('UAE-Delivery Note'); ?></a>
				</li>
				<?php
					}?>
				<?php
				if(in_array("list-delivery-note/ksa",$page_compare))
				{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-delivery-note/ksa') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-delivery-note/ksa');?>"><?php echo $this->lang->line('KSA-Delivery Note'); ?></a>
				</li>
				<?php
					}?>
				<?php
				if(in_array("list-delivery-note/dragon",$page_compare))
				{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-delivery-note/dragon') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-delivery-note/dragon');?>"><?php echo $this->lang->line('Dragon-Delivery Note'); ?></a>
				</li>
				<?php
					}?>
				<?php
				if(in_array("list-delivery-note/export",$page_compare))
				{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-delivery-note/export') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-delivery-note/export');?>"><?php echo $this->lang->line('Export-Delivery Note'); ?></a>
				</li>
				<?php
					}?>

							<?php
				if(in_array("list-delivery-note/amazonuk",$page_compare))
				{?>
				<li  <?php if(strpos($_SERVER['REQUEST_URI'],'list-delivery-note/amazonuk') ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-delivery-note/amazonuk');?>"><?php echo $this->lang->line('Amazon-UK-Delivery Note'); ?></a>
				</li>
				<?php
					}?>
			</ul>
			</li>
			<?php
				if(in_array("list-sales-return",$page_compare))
				{?>
		<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-sales-return') ){echo "class='nav-active'";} ?>>
			<a class="menu_name_fun" href="<?php echo base_url('list-sales-return');?>"><i class="fa fa-list-alt" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Sales Return'); ?></span></a>
			</li>
			<?php
				}?>

							<?php
				if(in_array("list-Amazon-price-uk",$page_compare))
				{?>
		<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-Amazon-price-uk') ){echo "class='nav-active'";} ?>>
			<a class="menu_name_fun" href="<?php echo base_url('list-price-amazon-uk');?>"><i class="fa fa-list-alt" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Price List Amazon (UK)'); ?></span></a>
			</li>
			<?php
				}?>


					<?php
				if(in_array("list-check-new-price",$page_compare))
				{?>
		<li <?php if(strpos($_SERVER['REQUEST_URI'],'list-check-new-price') ){echo "class='nav-active'";} ?>>
			<a class="menu_name_fun" href="<?php echo base_url('list-check-new-price');?>"><i class="fa fa-list-alt" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Check New Price'); ?></span></a>
			</li>
			<?php
				}?>
				
<?php
}?>
			</ul>
		
		</li>
<?php
if(   (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") )
{
	?>
		<li >
			<a href="<?php echo base_url('list-journal-entries');?>">
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Journals'); ?></span>
			</a>
			<ul class="nav nav-children myMenu">
				<li >
					<a >
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Journal Enteries'); ?></span>
					</a>
				</li>
				<li >
					<a >
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Debit Note'); ?> </span>
					</a>
				</li>
				<li >
					<a >
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Credit Note'); ?>  </span>
					</a>
				</li>
				<li >
					<a >
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Opening Balances'); ?></span>
					</a>
				</li>
			</ul>
		</li>
		<?php
	}?>
<?php
if(   (($this ->session->userdata['user']['role'])=="1") ||($this ->session->userdata['user']['main_dept']=="Sales") )
{
	?>
		<li <?php if(strpos($_SERVER['REQUEST_URI'],'opening-stock') || (strpos($_SERVER['REQUEST_URI'],'list-opening-stock')) 
		|| (strpos($_SERVER['REQUEST_URI'],'stock-excess')) || (strpos($_SERVER['REQUEST_URI'],'list-excess-stock')) 
		|| (strpos($_SERVER['REQUEST_URI'],'stock-shortage')) || (strpos($_SERVER['REQUEST_URI'],'list-shortage-stock')) 
		|| (strpos($_SERVER['REQUEST_URI'],'stock-adjustment')) || (strpos($_SERVER['REQUEST_URI'],'list-adjustment-stock'))
		|| (strpos($_SERVER['REQUEST_URI'],'stock-transfer')) || (strpos($_SERVER['REQUEST_URI'],'list-transfer-stock')) ||
		 (strpos($_SERVER['REQUEST_URI'],'list-current-stock')) || (strpos($_SERVER['REQUEST_URI'],'stock-delivery-report')) 
		  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Stocks'); ?></span>
			</a>
			<ul class="nav nav-children">
				<li <?php if( (strpos($_SERVER['REQUEST_URI'],'stock-shortage')) || (strpos($_SERVER['REQUEST_URI'],'list-shortage-stock'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-shortage-stock');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Stock Adjustments -'); ?> </span>
					</a>
				</li>
				<li <?php if( (strpos($_SERVER['REQUEST_URI'],'stock-excess')) || (strpos($_SERVER['REQUEST_URI'],'list-excess-stock'))   ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-excess-stock');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Stock Adjustments +'); ?></span>
					</a>
				</li>
				<li <?php if( (strpos($_SERVER['REQUEST_URI'],'stock-transfer')) || (strpos($_SERVER['REQUEST_URI'],'list-transfer-stock'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-transfer-stock');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Stock Transfers'); ?>  </span>
					</a>
				</li>
				<li <?php if( (strpos($_SERVER['REQUEST_URI'],'opening-stock')) || (strpos($_SERVER['REQUEST_URI'],'list-opening-stock'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-opening-stock');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Opening Stocks'); ?>  </span>
					</a>
				</li>
				<li <?php if( (strpos($_SERVER['REQUEST_URI'],'list-current-stock'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-current-stock');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Current Stock'); ?>  </span>
					</a>
				</li>

				<li <?php if( (strpos($_SERVER['REQUEST_URI'],'list-current-stock'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('list-Low-stock');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Low Inventories'); ?></span>
					</a>
				</li>
			<li  <?php if(strpos($_SERVER['REQUEST_URI'],'stock-delivery-report/uae') || strpos($_SERVER['REQUEST_URI'],'stock-delivery-report/ksa') || strpos($_SERVER['REQUEST_URI'],'stock-delivery-report/dragon') || strpos($_SERVER['REQUEST_URI'],'stock-delivery-report/export') ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';};?>>
			<a >
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Stock delivery report'); ?></span>
			</a>
			<ul class="nav nav-children myMenu">
					<li <?php if( (strpos($_SERVER['REQUEST_URI'],'stock-delivery-report/uae'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('stock-delivery-report/uae');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span> <?php echo $this->lang->line('UAE Stock delivery report'); ?></span>
					</a>
					</li>
					<li <?php if( (strpos($_SERVER['REQUEST_URI'],'stock-delivery-report/ksa'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('stock-delivery-report/ksa');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span> <?php echo $this->lang->line('KSA Stock delivery report'); ?></span>
					</a>
					</li>
					<li <?php if( (strpos($_SERVER['REQUEST_URI'],'stock-delivery-report/dragon'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('stock-delivery-report/dragon');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Dragon Stock delivery report'); ?> </span>
					</a>
					</li>
					<li <?php if( (strpos($_SERVER['REQUEST_URI'],'stock-delivery-report/export'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('stock-delivery-report/export');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span> <?php echo $this->lang->line('Export Stock delivery report'); ?></span>
					</a>
					</li>
                   
				    
						<li <?php if( (strpos($_SERVER['REQUEST_URI'],'study-stock-qnty'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('study-stock-qnty');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span> <?php echo $this->lang->line('Stock wharehouse yearly'); ?></span>
					</a>
					</li>

							<li <?php if( (strpos($_SERVER['REQUEST_URI'],'study-suggestion-stock'))  ){echo 'class="nav-active"';};?>>
					<a class="menu_name_fun" href="<?php echo base_url('study-suggestion-stock');?>">
					<i class="fa fa-home" aria-hidden="true"></i>
					<span><?php echo $this->lang->line('Update Product Suggestion Stock'); ?> </span>
					</a>
					</li>




			</ul>
		</li>	
			</ul>
		</li>
<?php
}?>



</ul>
</li>

<?php
			if(  (($this ->session->userdata['user']['role'])=="1") || ($this ->session->userdata['user']['main_dept']=="Accounts") || ( $this ->session->userdata['user']['main_dept']=="Sales"  && $this->session->userdata['user']['sub_dept']=="ksa"  )   )
			{?> 
		<li <?php if(strpos($_SERVER['REQUEST_URI'],'sub-ledger')   ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-list-alt" aria-hidden="true"></i>
			<span> <?php echo $this->lang->line('Financial Accounting'); ?> </span>
			</a>
			<ul class="nav nav-children myMenu">

				<li  <?php if( (strpos($_SERVER['REQUEST_URI'],'sub-ledger'))  ){echo 'class="nav-active"';};?>>
				<a class="menu_name_fun" href="<?php echo base_url('sub-ledger');?>">  <?php echo $this->lang->line('Sub-Ledger'); ?></a>
				</li>

				<li  <?php if( (strpos($_SERVER['REQUEST_URI'],'sub-ledger'))  ){echo 'class="nav-active"';};?>>

				<a class="menu_name_fun" href="<?php echo base_url('manage-assets');?>">  <?php echo $this->lang->line('manage-assets'); ?></a>

				</li>


			    </ul>
			</li>

			<?php
			}?>

<?php

if(  (($this ->session->userdata['user']['role'])=="1") && (($this ->session->userdata['user']['main_dept'])=="Main")  )
{?>
<li  <?php if(strpos($_SERVER['REQUEST_URI'],'dashboard') || (strpos($_SERVER['REQUEST_URI'],'account_masters_data')) || (strpos($_SERVER['REQUEST_URI'],'accounts_report_graph')) || (strpos($_SERVER['REQUEST_URI'],'tx_funds_approve'))  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Accounts Reports'); ?></span>
</a>
<ul class="nav nav-children myMenu">

<li <?php if(strpos($_SERVER['REQUEST_URI'],'dashboard'))
{echo "class='nav-active'";} ?>>
<a class="menu_name_fun" href="<?php echo base_url('dashboard');?>">

<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Dashboard'); ?></span>
</a>
</li>

<li  <?php if((strpos($_SERVER['REQUEST_URI'],'account_masters_data')) || (strpos($_SERVER['REQUEST_URI'],'accounts_report_graph'))){echo "class='nav-parent nav-expanded nav-active'";}else{echo 'class="nav-parent"';};?>>
<a> 
<i class="fa fa-list-alt" aria-hidden="true"></i>	
<span><?php echo $this->lang->line('Reports'); ?></span></a>
<ul class="nav nav-children">
<li <?php if(strpos($_SERVER['REQUEST_URI'],'account_masters_data'))
{echo "class='nav-active'";} ?>>
<a class="menu_name_fun" href="<?php echo base_url('account_masters_data');?>"><?php echo $this->lang->line('Accounts Operations Report'); ?></a>
</li>

<li <?php if(strpos($_SERVER['REQUEST_URI'],'accounts_report_graph'))
{echo "class='nav-active'";} ?>>
<a class="menu_name_fun" href="<?php echo base_url('accounts_report_graph');?>"><?php echo $this->lang->line('Graphical data'); ?></a>
</li>
</ul>
</li>

<li <?php if((strpos($_SERVER['REQUEST_URI'],'tx_funds_approve'))){echo "class='nav-parent nav-expanded nav-active'";}else{echo 'class="nav-parent"';};?>>
<a>
<i class="fa fa-tasks" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Fund Transfer'); ?></span>
</a>
	<ul class="nav nav-children myMenu">
	<li <?php if(strpos($_SERVER['REQUEST_URI'],'tx_funds_approve'))
{echo "class='nav-active'";} ?>>
	<a class="menu_name_fun" href="<?php echo base_url('tx_funds_approve');?>">
	<?php echo $this->lang->line('Approve Transfers Now'); ?> 
	</a>
	</li>

	
	</ul>
</li>

</ul>
</li>

<?php
}?>
<?php
$pages=$this ->session->userdata['user']['pages_permission'];
$page_compare=explode(',',$pages);
if(  (($this ->session->userdata['user']['role'])=="1") || (in_array("sales-book",$page_compare)) || (in_array("sales-book-dashboard",$page_compare)) )
{?>
<li <?php if(strpos($_SERVER['REQUEST_URI'],'sales-book') || (strpos($_SERVER['REQUEST_URI'],'sales-book-dashboard')) || (strpos($_SERVER['REQUEST_URI'],'season-sales'))  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-list-alt" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Sales Book'); ?> </span>
</a>
<ul class="nav nav-children myMenu">

<?php
if( (($this ->session->userdata['user']['role'])=="1") || (in_array("sales-book",$page_compare) && $this->session->userdata['user']['sub_dept']!="ksa"))
{?>
	<li <?php if(strpos($_SERVER['REQUEST_URI'],'sales-book')){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('sales-book');?>">
	<?php echo $this->lang->line('Sales Book Excel upload'); ?> 
	</a>
	</li>
<?php
}?>	

<?php
if( (($this ->session->userdata['user']['role'])=="1") || in_array("sales-book-dashboard",$page_compare))
{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'sales-book-dashboard')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('sales-book-dashboard');?>">
	<?php echo $this->lang->line('Total Sales Book'); ?>  
	</a>
	</li>
<?php
}?>	


<?php
if( (($this ->session->userdata['user']['role'])=="1") || in_array("sales-book-country-dashboard",$page_compare))
{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'sales-book-dashboard-country')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('sales-book-dashboard-country');?>">
	 <?php echo $this->lang->line('Country Wise Sales'); ?> 
	</a>
	</li>
<?php
}?>	
<?php
if( (($this ->session->userdata['user']['role'])=="1") || in_array("season-sales",$page_compare))
{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'season-sales')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('season-sales');?>">
      <?php echo $this->lang->line('Season Sales'); ?> 	
	</a>
	</li>
<?php
}?>
</ul>
</li>
<?php
}?>
<?php
$pages=$this ->session->userdata['user']['pages_permission'];
$page_compare=explode(',',$pages);
if(  (($this ->session->userdata['user']['role'])=="1") || (in_array("sales-book",$page_compare)) || (in_array("sales-book-dashboard",$page_compare)) )
{?>
<li <?php if(strpos($_SERVER['REQUEST_URI'],'purchase-book-excel') || (strpos($_SERVER['REQUEST_URI'],'purchase-book-dashboard')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-list-alt" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Purchase Book'); ?></span>
</a>
<ul class="nav nav-children myMenu">

<?php
if( (($this ->session->userdata['user']['role'])=="1") || in_array("purchase-book-excel",$page_compare))
{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'purchase-book-excel')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('purchase-book-excel');?>">
	<?php echo $this->lang->line('Purchase Book Excel upload'); ?> 
	</a>
	</li>
<?php
}?>	

<?php
if( (($this ->session->userdata['user']['role'])=="1") || in_array("purchase-book-dashboard",$page_compare))
{?>
	
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'purchase-book-dashboard')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('purchase-book-dashboard');?>">
	<?php echo $this->lang->line('Total Purchase Book'); ?> 
	</a>
	</li>
<?php
}?>	
</ul>
</li>
<?php
}?>
<?php

if( ( (($this ->session->userdata['user']['role'])=="1") && (($this ->session->userdata['user']['main_dept'])=="Main") ) || in_array('gulf-trading-visitors',$page_compare) )
{?>
<li <?php if(strpos($_SERVER['REQUEST_URI'],'marketing-dashboard') ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Marketing Reports'); ?></span>
</a>
<ul class="nav nav-children myMenu">
<?php
	if(in_array('marketing-dashboard',$page_compare))
	{
	?>	
<li <?php if((strpos($_SERVER['REQUEST_URI'],'marketing-dashboard')) ){echo 'class="nav-active"';};?>>
<a class="menu_name_fun" href="<?php echo base_url('marketing-dashboard');?>">
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Dashboard'); ?></span>
</a>
</li>
<?php
}?>

	<li <?php if(strpos($_SERVER['REQUEST_URI'],'gulf-trading-visitors') || strpos($_SERVER['REQUEST_URI'],'gulf-trading-visitors-list')  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('VISITORS FORM'); ?></span>
</a>
<ul class="nav nav-children myMenu">
	 <?php
	if(in_array('gulf-trading-visitors',$page_compare))
	{
	?> 
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'gulf-trading-visitors')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('gulf-trading-visitors');?>">
	<i class="fa fa-home" aria-hidden="true"></i>
	<span><?php echo $this->lang->line('Gulf Trading Visitors Form'); ?></span>
	</a>
	</li>
	 <?php
	}?>
	<?php
	if(in_array('gulf-trading-visitors-list',$page_compare))
	{
	?> 
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'gulf-trading-visitors-list')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('gulf-trading-visitors-list');?>">
	<i class="fa fa-home" aria-hidden="true"></i>
	<span><?php echo $this->lang->line('List Visitors'); ?></span>
	</a>
	</li>
	<?php
	}?>

</ul>
</li>

</ul>
</li>

<?php
}
?>


<?php
$pages=$this ->session->userdata['user']['pages_permission'];
$page_compare=explode(',',$pages);

if( ( (($this ->session->userdata['user']['role'])=="1") && (($this ->session->userdata['user']['main_dept'])=="Main") ) || (in_array("add-users",$page_compare)) || (in_array("list-users",$page_compare)) )
{?>

	

<li <?php if(strpos($_SERVER['REQUEST_URI'],'add-users') || (strpos($_SERVER['REQUEST_URI'],'list-users')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('User Managment'); ?></span>
</a>
<ul class="nav nav-children myMenu">
<?php
	if(in_array('add-users',$page_compare))
	{
	?>	
<li <?php if((strpos($_SERVER['REQUEST_URI'],'add-users')) ){echo 'class="nav-active"';};?>>
<a class="menu_name_fun" href="<?php echo base_url('add-users');?>">
<span><?php echo $this->lang->line('Add Users'); ?></span>
</a>
</li>
<?php
}
	if(in_array('list-users',$page_compare))
	{
	?>	
<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-users')) ){echo 'class="nav-active"';};?>>
<a class="menu_name_fun" href="<?php echo base_url('list-users');?>">
<span><?php echo $this->lang->line('List Users'); ?></span>
</a>
</li>
<?php
}?>

</ul>
</li>

<?php
}?>




<?php
if( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Accounts"))
{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'dashboard')) ){echo 'class="nav-active"';};?>>
<a class="menu_name_fun" href="<?php echo base_url('dashboard');?>">
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Dashboard'); ?></span>
</a>
</li>
<?php
}?>

<!-- <?php

$pages=$this ->session->userdata['user']['pages_permission'];
$page_compare=explode(',',$pages);
// $accounts_array=array('add_account_entry','list_account_entry','acc_excel_upload','tx_funds','list_txs');

if( ( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Accounts") ) || (in_array('add_account_entry',$page_compare)) || in_array('list_account_entry',$page_compare) || in_array('acc_excel_upload', $page_compare) || in_array('reconcile_entries',$page_compare) )
{?>


<li <?php if(strpos($_SERVER['REQUEST_URI'],'add_account_entry') || (strpos($_SERVER['REQUEST_URI'],'list_account_entry')) || (strpos($_SERVER['REQUEST_URI'],'list_opening_bal')) || (strpos($_SERVER['REQUEST_URI'],'reconcile_entries')) 
|| (strpos($_SERVER['REQUEST_URI'],'acc_excel_upload')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-list-alt" aria-hidden="true"></i>
<span>Accounts</span>
</a>
	<ul class="nav nav-children myMenu">
	<?php
	if(in_array('add_account_entry',$page_compare))
	{
	?>	
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'add_account_entry')) ){echo 'class="nav-active"';};?>>
	<a href="<?php echo base_url('add_account_entry');?>">
	Add Account Entries
	</a>
	</li>
	<?php
	}
	if(in_array('list_account_entry',$page_compare))
	{
	?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list_account_entry')) ){echo 'class="nav-active"';};?>>
	<a href="<?php echo base_url('list_account_entry');?>">
	List Account Entries
	</a>
	</li>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list_opening_bal')) ){echo 'class="nav-active"';};?>>
	<a href="<?php echo base_url('list_opening_bal');?>">
	List all opening balances
	</a>
	</li>
	<?php
	}
	if(in_array('reconcile_entries',$page_compare))
	{
	?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'reconcile_entries')) ){echo 'class="nav-active"';};?>>
	<a href="<?php echo base_url('reconcile_entries');?>">
	Reconcile entry
	</a>
	</li>
	
	<?php
	}
	if(in_array('acc_excel_upload',$page_compare))
	{
	?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'acc_excel_upload')) ){echo 'class="nav-active"';};?>>
	<a href="<?php echo base_url('acc_excel_upload');?>">
	Upload Excel
	</a>
	</li>
	<?php
	}?>
	</ul>
</li>
<?php
}?> -->

<?php
$pages=$this ->session->userdata['user']['pages_permission'];
$page_compare=explode(',',$pages);
// $accounts_array=array('add_account_entry','list_account_entry','acc_excel_upload','tx_funds','list_txs');

if( ( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Accounts") )|| in_array('tx_funds', $page_compare) || in_array('list_txs', $page_compare) )
{?>
	
<li <?php if(strpos($_SERVER['REQUEST_URI'],'tx_funds') || (strpos($_SERVER['REQUEST_URI'],'list_txs')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?> >
<a>
<i class="fa fa-tasks" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Fund Transfer'); ?> </span>
</a>
	<ul class="nav nav-children myMenu">
	<?php
	
	if(in_array('tx_funds',$page_compare))
	{
	?>	
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'tx_funds')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('tx_funds');?>">
	 <?php echo $this->lang->line('Transfer Funds'); ?> 
	</a>
	</li>
	<?php
	}
	if(in_array('list_txs',$page_compare))
	{
	?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list_txs')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('list_txs');?>">
      <?php echo $this->lang->line('List Transfers'); ?>	
	</a>
	</li>
	<?php
	}	
	?>
	</ul>
</li>
	


<?php
}
if( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Sales") )
{?>
	
<li <?php if((strpos($_SERVER['REQUEST_URI'],'marketing-dashboard')) ){echo 'class="nav-active"';};?>>
<a class="menu_name_fun" href="<?php echo base_url('marketing-dashboard');?>">
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Dashboard'); ?></span>
</a>
</li>
<?php
}?>

<?php
$pages=$this ->session->userdata['user']['pages_permission'];
$page_compare=explode(',',$pages);
$sales_array=array('add-customer-details');

if(  ( (($this ->session->userdata['user']['role'])=="2") && (($this ->session->userdata['user']['main_dept'])=="Sales") ) || (in_array('add-customer-details',$page_compare)) || (in_array('list-customer-details',$page_compare)) || (in_array('add-sales-target',$page_compare)) || (in_array('list-sales-target',$page_compare)) )
{
?>

<li <?php if(strpos($_SERVER['REQUEST_URI'],'add-customer-details') || (strpos($_SERVER['REQUEST_URI'],'list-customer-details')) || (strpos($_SERVER['REQUEST_URI'],'customer-excel-upload')) || (strpos($_SERVER['REQUEST_URI'],'add-sales-target')) || (strpos($_SERVER['REQUEST_URI'],'list-sales-target'))  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?> >
<a>
<i class="fa fa-tasks" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Sales Master'); ?></span>
</a>
	<ul class="nav nav-children myMenu">
	<?php
	if(in_array('add-customer-details',$page_compare))
	{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'add-customer-details')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('add-customer-details');?>">
	<?php echo $this->lang->line('Add Customer Details'); ?> 
	</a>
	</li>
	<?php
	}
	if(in_array('list-customer-details',$page_compare))
	{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-customer-details')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('list-customer-details');?>">
	<?php echo $this->lang->line('List Customer Details'); ?> 
	</a>
	</li>
	<?php
	}
	if(in_array('customer-excel-upload',$page_compare))
	{
	?>	
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'customer-excel-upload')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('customer-excel-upload');?>">
		<i class="fa fa-list" aria-hidden="true"></i>
	<span><?php echo $this->lang->line('Excel upload Customer Details'); ?></span>
		</a>
		</li>
	<?php
	}?>
	
	<?php
	if(in_array('add-sales-target',$page_compare))
	{
	?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'add-sales-target')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('add-sales-target');?>">
	<?php echo $this->lang->line('Add Sales Target'); ?>
	</a>
	</li>
	<?php
	}
	if(in_array('list-sales-target',$page_compare))
	{
	?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-sales-target')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('list-sales-target');?>">
	<?php echo $this->lang->line('List Sales Target'); ?> 
	</a>
	</li>
	<?php
	}?>
	
	</ul>
</li>

<?php

}
if(in_array('add-files',$page_compare))
	{
?>

<li <?php if(strpos($_SERVER['REQUEST_URI'],'add-files') ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?> >
<a>
<i class="fa fa-tasks" aria-hidden="true"></i>
<span><?php echo $this->lang->line('File Manager'); ?></span>
</a>
	<ul class="nav nav-children myMenu">
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'add-files')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('add-files');?>">
	<?php echo $this->lang->line('Add Files'); ?>
	</a>
	</li>
	
	
	</ul>
</li>
<?php
}
?>

<?php
$pages=$this ->session->userdata['user']['pages_permission'];
$page_compare=explode(',',$pages);
if( ( (($this ->session->userdata['user']['role'])=="1") ||
 in_array('add-employees', $page_compare) ||
 in_array('employee-tree', $page_compare) ||
  in_array('list-employees', $page_compare) || in_array('list-jobs-applied',$page_compare) || in_array('add-jobs', $page_compare) || in_array('list-jobs', $page_compare) ||in_array('job-offer', $page_compare) || in_array('add-leave', $page_compare) || in_array('list-leave', $page_compare) || in_array('list-user-files',$page_compare) ) )
{
?>
<li <?php if(strpos($_SERVER['REQUEST_URI'],'employee-tree') || (strpos($_SERVER['REQUEST_URI'],'list-employee-tree'))  || (strpos($_SERVER['REQUEST_URI'],'list-jobs-applied')) || (strpos($_SERVER['REQUEST_URI'],'add-jobs')) || (strpos($_SERVER['REQUEST_URI'],'list-jobs')) ||(strpos($_SERVER['REQUEST_URI'],'job-offer')) ||(strpos($_SERVER['REQUEST_URI'],'add-leave')) || (strpos($_SERVER['REQUEST_URI'],'list-leave')) || (strpos($_SERVER['REQUEST_URI'],'list-user-files')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?> >
<a>
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('HR Management'); ?></span>
</a>
<ul class="nav nav-children myMenu">
	
	<?php
	if(in_array('employee-tree', $page_compare))
	{
	?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'employee-tree')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('employee-tree');?>">
	<?php echo $this->lang->line('Add Employee To Tree'); ?> 
	</a>
	</li>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-employee-tree')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('list-employee-tree');?>">
	<?php echo $this->lang->line('List Employee Tree'); ?>
	</a>
	</li>

	<?php
	}
	
	
	if(in_array('list-jobs-applied', $page_compare))
	{
	?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-jobs-applied')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('list-jobs-applied');?>">
	<?php echo $this->lang->line('List Jobs Applied'); ?>
	</a>
	</li>

	<li <?php if((strpos($_SERVER['REQUEST_URI'],'emp-custody-create')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('emp-custody-create');?>">
	<?php echo $this->lang->line('Employee Custody'); ?>
	</a>
	</li>
	<?php
	}





			$pages=$this ->session->userdata['user']['pages_permission'];
			$page_compare=explode(',',$pages);

	if(   (($this ->session->userdata['user']['role'])=="1") || (in_array('add-jobs',$page_compare)) || (in_array('list-jobs',$page_compare)) || (in_array('job-offer',$page_compare))  )
			{
			?>
			<li <?php if(strpos($_SERVER['REQUEST_URI'],'add-jobs') || (strpos($_SERVER['REQUEST_URI'],'list-jobs')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
			<a>
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Hiring'); ?></span>
			</a>
				<ul class="nav nav-children myMenu">
			
				<li <?php if((strpos($_SERVER['REQUEST_URI'],'add-jobs')) ){echo 'class="nav-active"';};?>>
	            <a class="menu_name_fun" href="<?php echo base_url('add-jobs');?>"><?php echo $this->lang->line('Add Jobs'); ?></a> 
	           </li>
	           
				<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-jobs')) ){echo 'class="nav-active"';};?>>
	            <a class="menu_name_fun"  href="<?php echo base_url('list-jobs');?>"><?php echo $this->lang->line('List Jobs'); ?>  </a>
		        </li>

		       <li <?php if((strpos($_SERVER['REQUEST_URI'],'list_job_offer')) ){echo 'class="nav-active"';};?>>
	             <a class="menu_name_fun"  href="<?php echo base_url('list_job_offer');?>"><?php echo $this->lang->line('Job Offer'); ?> </a>
	              </li>
				</ul>
			</li>



       

               <?php

		}?>

          <li <?php if(strpos($_SERVER['REQUEST_URI'],'add-leave') || (strpos($_SERVER['REQUEST_URI'],'list-leave')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
           <a>
			<i class="fa fa-home" aria-hidden="true"></i>
			<span><?php echo $this->lang->line('Leave_system'); ?></span>
			</a>
	          <ul class="nav nav-children myMenu">
                  	
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'add-leave')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('add-leave');?>">
	<?php echo $this->lang->line('Add Leave'); ?> 
	</a>
	</li>
	

	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-leave')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('list-leave');?>">
   <?php echo $this->lang->line('List Leave'); ?>	
	</a>
	</li>
	
	
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-leave')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('list-employee-request');?>">
	<?php echo $this->lang->line('List employee request'); ?>	 
	</a>
	</li>

		     </ul>
			 </li>


    

	









	<?php
	if(in_array('list-user-files',$page_compare))
	{
	?>	
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-user-files')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('list-user-files');?>">
	<span><?php echo $this->lang->line('List User Files'); ?></span>
	</a>
	</li>
	<?php
	}
	?>	

</ul>
</li>
<?php
}
?>

<?php

if(  (($this ->session->userdata['user']['role'])=="1") && (($this ->session->userdata['user']['main_dept'])=="Main")  )
{?>

<li  <?php if(strpos($_SERVER['REQUEST_URI'],'customer_excel') || (strpos($_SERVER['REQUEST_URI'],'list_customer_excel')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?> >
<a>
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Email marketing customers Management'); ?></span>
</a>
<ul class="nav nav-children myMenu">
	
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'customer_excel')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('customer_excel');?>">
	<?php echo $this->lang->line('Customer excel upload'); ?>
	</a>
	</li>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list_customer_excel')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('list_customer_excel');?>">
	<?php echo $this->lang->line('List Customer'); ?>
	</a>
	</li>
	

</ul>
</li>

<li  <?php if(strpos($_SERVER['REQUEST_URI'],'add-inventory') || (strpos($_SERVER['REQUEST_URI'],'list-inventory'))  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?> >
<a>
<i class="fa fa-home" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Inventory Management'); ?></span>
</a>
<ul class="nav nav-children myMenu">
	
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'add-inventory')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('add-inventory');?>">
	<?php echo $this->lang->line('Excel upload warehouse details'); ?>
	</a>
	</li>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-inventory')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('list-inventory');?>">
	<?php echo $this->lang->line('List Inventory data'); ?>
	</a>
	</li>
	

</ul>
</li>
<li  <?php if(strpos($_SERVER['REQUEST_URI'],'upload-invoice-excel') || (strpos($_SERVER['REQUEST_URI'],'excel_upload_complete_sales_report')) || (strpos($_SERVER['REQUEST_URI'],'compare-sales-report-receipt'))  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?> >
<a>
<i class="fa fa-tasks" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Invoice Data'); ?> </span>
</a>
<ul class="nav nav-children myMenu">
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'upload-invoice-excel')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('upload-invoice-excel');?>">
	<?php echo $this->lang->line('Upload Receipt Register  Excel'); ?>
	</a>
	</li>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'excel_upload_complete_sales_report')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('excel_upload_complete_sales_report');?>">
	<?php echo $this->lang->line('Upload Complete Sales Report Excel'); ?>
	</a>
	</li>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'compare-sales-report-receipt')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('compare-sales-report-receipt');?>">
	<?php echo $this->lang->line('Compare Sales Report Vs. Receipt'); ?>
	</a>
	</li>
</ul>	
</li>
<?php
}?>




<?php
$pages=$this ->session->userdata['user']['pages_permission'];
$page_compare=explode(',',$pages);
if( (in_array("create-survey-data",$page_compare)) || (in_array('list-survey-data',$page_compare)) || (in_array('list-installations',$page_compare)) || (in_array('add-survey-customer-pricing',$page_compare)) )
{?> 
<li <?php if(strpos($_SERVER['REQUEST_URI'],'create-survey-data') || (strpos($_SERVER['REQUEST_URI'],'list-survey-data')) || (strpos($_SERVER['REQUEST_URI'],'list-installations')) || (strpos($_SERVER['REQUEST_URI'],'single-installation')) || (strpos($_SERVER['REQUEST_URI'],'list-single-installation')) || (strpos($_SERVER['REQUEST_URI'],'survey-bom')) || (strpos($_SERVER['REQUEST_URI'],'add-survey-customer-pricing')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-list-alt" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Survey Module'); ?> </span>
</a>
<ul class="nav nav-children myMenu">
	<?php
	if(in_array('create-survey-data',$page_compare))
	{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'create-survey-data')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('create-survey-data');?>"><?php echo $this->lang->line('Create Survey'); ?> </a></li>
	<?php
	}
	if(in_array('list-survey-data',$page_compare))
	{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-survey-data')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('list-survey-data');?>"><?php echo $this->lang->line('List Survey'); ?></a></li>
	<?php
	}
	if(in_array('list-installations',$page_compare))
	{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-installations')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('list-installations');?>"><?php echo $this->lang->line('List Installation'); ?> </a></li>
	<?php
	}?>
		<?php
	if(in_array('create-survey-data',$page_compare))
	{?>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'single-installation')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('single-installation');?>"><?php echo $this->lang->line('Create Single Installation'); ?> </a></li>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'list-single-installation')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('list-single-installation');?>"><?php echo $this->lang->line('List Single Installation'); ?> </a></li>	
	<?php
	}?>
	<?php
	if(in_array('add-survey-customer-pricing',$page_compare))
	{?>
<li <?php if(strpos($_SERVER['REQUEST_URI'],'survey-bom') || (strpos($_SERVER['REQUEST_URI'],'add-survey-customer-pricing')) ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
	<a>
	<i class="fa fa-calculator" aria-hidden="true"></i>
	<span><?php echo $this->lang->line('Accounts Survey Module'); ?> </span>
	</a>
	<ul class="nav nav-children myMenu">
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'survey-bom')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('survey-bom');?>"><?php echo $this->lang->line('Survey BOM'); ?> </a></li>
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'add-survey-customer-pricing')) ){echo 'class="nav-active"';};?>>
		<a class="menu_name_fun" href="<?php echo base_url('add-survey-customer-pricing');?>"><?php echo $this->lang->line('Create Customer Pricing'); ?> </a></li>
	</ul>
</li>
	
	<?php
	}
	?>
</ul>
</li>
<?php
}?>



<?php

if(  (($this ->session->userdata['user']['role'])=="2") && ( ($this ->session->userdata['user']['main_dept'])=="Main factory" || ($this ->session->userdata['user']['main_dept'])=="Traffic Sign" )  )
{?>
<li <?php if((strpos($_SERVER['REQUEST_URI'],'po-dashboard')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('po-dashboard');?>">
	<?php echo $this->lang->line('Dashboard'); ?>
	</a>
</li>

<?php
}?>

<!----------------emp profile------------->
<?php
$page_compare=explode(',',$pages);
if( (in_array("all-tickets",$page_compare))  )
{?>
<li <?php if(strpos($_SERVER['REQUEST_URI'],'all-tickets')  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-user" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Manage Profile'); ?></span>
</a>
<ul class="nav nav-children myMenu">
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'all-tickets')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('all-tickets');?>">
	<?php echo $this->lang->line('List all tickets'); ?>
	</a>
	</li>
</ul>
</li>
<?php
}?>
<!--------------------end profile------------>



<!----------------emp tasks------------->
<?php
$page_compare=explode(',',$pages);
if( (in_array("check-tasks",$page_compare))  )
{?>
<li <?php if(strpos($_SERVER['REQUEST_URI'],'check-tasks')  ){echo "class='nav-parent nav-expanded nav-active'";}else{ echo 'class="nav-parent"';} ?>>
<a>
<i class="fa fa-user" aria-hidden="true"></i>
<span><?php echo $this->lang->line('Check Your Tasks'); ?></span>
</a>
<ul class="nav nav-children myMenu">
	<li <?php if((strpos($_SERVER['REQUEST_URI'],'check-tasks')) ){echo 'class="nav-active"';};?>>
	<a class="menu_name_fun" href="<?php echo base_url('task-schedule');?>">
	<?php echo $this->lang->line('List of Tasks'); ?> 
	</a>
	</li>
</ul>
</li>
<?php
}?>
<!--------------------end emp tasks------------>











</ul>
</nav>


</div>
</div>
</aside>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
 $(document).ready(function() {
$('#mySearch').keyup(function () {
	//alert('inside menu');
	 var that = this, $allListElements = $('ul.myMenu > li');
     var $matchingListElements = $allListElements.filter(function (i, li) {
        var listItemText = $(li).text().toUpperCase(), searchText = that.value.toUpperCase();
        return ~listItemText.indexOf(searchText);
    });
    $allListElements.hide();
    $matchingListElements.show();
});
});
</script>
