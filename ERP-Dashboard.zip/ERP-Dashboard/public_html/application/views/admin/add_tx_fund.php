<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>
<?php
if (!empty($this->session->userdata('bal_update2'))) {
//	print_r($this->session->userdata['bal_update']['bank_name_updated']);
fund_tx_bal_update();
	}

?>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
.datepicker{z-index:18000 !important}

.required{
	color: red;
}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Account Entries</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Account Entries</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Table Data</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-bordered table-striped mb-none" id="datatable-default">
<thead>
<tr>
	<th style="width: 10%"></th>
<th>Bank name</th>
<?php
$current_year= date('Y');
$start_date1=$current_year.'-01-01';
$current_date=date('Y-m-d');
?>
<th>Balance from <?php echo $start_date1;?> 
upto <?php echo $current_date;?> </th>
<th>Total balances (total balance as per the data entered)</th>
<th>Action</th>
</tr>
</thead>
<tbody>

<tr class="gradeX">
<td>1</td>
<td>ADIB-BBMS</td>
<td><?php echo number_format((float)$bbms_result2, 2, '.', '');?></td>
<td><?php echo number_format((float)$bbms_result1, 2, '.', '');?></td>
<td>	
<button type="button" class="modal-with-form btn btn-warning" href="#modalForm" onclick="bank_name('ADIB-BBMS','<?php echo $bbms_result1;?>');">Transfer Funds</button>

</td>
</tr>
<tr class="gradeX">
<td>2</td>
<td>ADIB-Factory</td>
<td><?php echo number_format((float)$fact_result2, 2, '.', '');?></td>
<td><?php echo number_format((float)$fact_result1, 2, '.', '');?></td>
<td>	
<button type="button" class="modal-with-form btn btn-warning" href="#modalForm" onclick="bank_name('ADIB-Factory','<?php echo $fact_result1;?>');">Transfer Funds</button>

</td>
</tr>
<tr class="gradeX">
<td>3</td>
<td>ENBD</td>
<td><?php echo number_format((float)$ENBD2, 2, '.', '');?></td>
<td><?php echo number_format((float)$ENBD1, 2, '.', '');?></td>
<td>	
<button type="button" class="modal-with-form btn btn-warning" href="#modalForm" onclick="bank_name('ENBD','<?php echo $ENBD1;?>');">Transfer Funds</button>

</td>
</tr>

<tr class="gradeX">
<td>4</td>
<td>EI Bank</td>
<td><?php echo number_format((float)$ei_bank2, 2, '.', '');?></td>
<td><?php echo number_format((float)$ei_bank1, 2, '.', '');?></td>
<td>	
<button type="button" class="modal-with-form btn btn-warning" href="#modalForm" onclick="bank_name('EI Bank','<?php echo $ei_bank1;?>');">Transfer Funds</button>

</td>
</tr>

<tr class="gradeX">
<td>5</td>
<td>Cash Mr. Bachir Book</td>
<td><?php echo number_format((float)$cash_bachir2, 2, '.', '');?></td>
<td><?php echo number_format((float)$cash_bachir1, 2, '.', '');?></td>
<td>	
<button type="button" class="modal-with-form btn btn-warning" href="#modalForm" onclick="bank_name('Cash Mr. Bachir Book','<?php echo $cash_bachir1;?>');">Transfer Funds</button>

</td>
</tr>

<tr class="gradeX">
<td>6</td>
<td>Cash Garhoud</td>
<td><?php echo number_format((float)$Garhoud2, 2, '.', '');?></td>
<td><?php echo number_format((float)$Garhoud1, 2, '.', '');?></td>
<td>	
<button type="button" class="modal-with-form btn btn-warning" href="#modalForm" onclick="bank_name('Cash Garhoud','<?php echo $Garhoud1;?>');">Transfer Funds</button>

</td>
</tr>

<tr class="gradeX">
<td>7</td>
<td>Cash Factory</td>
<td><?php echo number_format((float)$cash_fact2, 2, '.', '');?></td>
<td><?php echo number_format((float)$cash_fact1, 2, '.', '');?></td>
<td>	
<button type="button" class="modal-with-form btn btn-warning" href="#modalForm" onclick="bank_name('Cash Factory','<?php echo $cash_fact1;?>');">Transfer Funds</button>

</td>
</tr>

<tr class="gradeX">
<td>8</td>
<td>Other Bank</td>
<td><?php echo number_format((float)$others2, 2, '.', '');?></td>
<td><?php echo number_format((float)$others1, 2, '.', '');?></td>
<td>	
<button type="button" class="modal-with-form btn btn-warning" href="#modalForm" onclick="bank_name('Other Bank','<?php echo $others1;?>');">Transfer Funds</button>

</td>
</tr>

</tbody>
</table>


<div id="modalForm" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Transfer Form</h2>
</header>
<div class="panel-body">
<!-- <form id="demo-form" class="form-horizontal mb-lg" novalidate="novalidate">
 -->	<?php echo form_open('submit_fund_tx','class="form-horizontal mb-lg"');?>
	<input type="hidden" name="debit_bnk" id="bank_name_selected">
	<input type="hidden" name="cur_bal" id="cur_bal">

<div class="form-group mt-lg">
<label class="col-sm-4 control-label"><b>Fund Transfering bank</b></label>
<div class="col-sm-8">
	<p class="bank_namt_tx"></p>
</div>
</div>

<div class="form-group">
<label class="col-sm-4 control-label"><b>Current total balance in <span class="bank_namt_tx"></span></b></label>
<div class="col-sm-8">
<p id="current_bal_dbt_bank"></p>
</div>
</div>

<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Transfer to <span class="required">::*::</span></label>
<div class="col-sm-9">
	<select class="form-control mb-md bank" name="credit_bnk" required="">
		<option value="">Choose</option>
		<option value="ADIB-BBMS">ADIB-BBMS</option>
		<option value="ADIB-Factory">ADIB-Factory</option>
		<option value="ENBD">ENBD</option>
		<option value="Cash Garhoud">Cash Garhoud</option>
		<option value="EI Bank">EI Bank</option>
		<option value="Cash Mr. Bachir Book">Cash Mr. Bachir Book</option>
		<option value="Cash Factory">Cash Factory</option>
		<option value="Other Bank">Other Bank</option>
	</select>
</div>
</div>

<div class="form-group">
<label class="col-sm-4 control-label"><b>Current total balance in <span id="crd_bnk_name"></span></b></label>
<div class="col-sm-8">
<p id="current_bal_crd_bank"></p>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Amount <span class="required">::*::</span></label>
<div class="col-sm-9">
<input type="text" name="amount" class="form-control" required />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Date <span class="required">::*::</span></label>
<div class="col-sm-9">
<input type="text" name="date" class="form-control" id='datetimepicker4'   required="" />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Note</label>
<div class="col-sm-9">
<textarea rows="5" class="form-control" name="desc" placeholder="Description" ></textarea>
</div>
</div>

</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit" class="btn btn-primary">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>

</section>
</div>

</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>


<script type="text/javascript">
	function bank_name(bank_name,cur_bal)
	{
		$('.bank_namt_tx').html(bank_name);
		$('#cur_bal').val(cur_bal);
		$('#current_bal_dbt_bank').html(cur_bal);
		$('#bank_name_selected').val(bank_name);
	}

	$('select').on('change', function() {
  			if(this.value!="")
  			{
  				bank_name_selected=this.value; 				
  				 jQuery.ajax({
		            url:"<?php echo base_url().'Fund_tx/crd_bank_bal';?>",
		            type:"post",
		            data:{"bank_name_selected":bank_name_selected},
		            success:function(result)
		            {
		            	$('#current_bal_crd_bank').html(result);
		            	$('#crd_bnk_name').html(bank_name_selected);	                   	
		            }
		        });
  				
  			}
		   
		});
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('#datetimepicker4').datetimepicker();
            });
        </script>

</body>
</html>