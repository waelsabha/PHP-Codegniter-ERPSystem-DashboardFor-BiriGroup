<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head'); ?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<script src="<?php echo base_url('admin_assets/'); ?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" rel="stylesheet" type='text/css'>


<style type="text/css">
.form_error {
font-size: 13px;
font-family: Arial;
color: red;
font-style: italic
}

.form_error p .errors {
color: red;
}

.errors {
font-size: 13px;
font-family: Arial;
color: red;
font-style: italic
}

.success {
font-size: 13px;
font-family: Arial;
color: green;
font-style: italic
}

.table-rows-border {
border-bottom: 1px solid #eff2f7;
padding-bottom: 15px;
margin-bottom: 15px;
}

.required {
color: red;
}

.countrypicker {
max-height: 100px;
}

.fa-whatsapp {
color: #fff;
background:
linear-gradient(#25d366, #25d366)10px 84%/15px 15px no-repeat,
radial-gradient(#25d366 59%, transparent 0);
}
</style>
</head>

<body>
<section class="body">

<?php $this->load->view('admin/header'); ?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside'); ?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Edit Account</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
    <a href="#">
        <i class="fa fa-home"></i>
    </a>
</li>
<li><span>Accounts Tree</span></li>
<li><span>Edit account</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

    <h2 class="panel-title">Edit Account</h2>
</header>
<div class="panel-body">
    <?php echo form_open_multipart('Admin_biri/submit_update_account_tree_data', 'class="form-horizontal form-bordered"'); ?>
    <div class="form_error">
        <p class="errors"> <?php echo $this->session->flashdata('errors'); ?></p>
        <p class="success"><?php echo $this->session->flashdata('success'); ?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

    <input type="hidden" name="sales_cust_id" value="">

    <input type="hidden" class="country_val_selected" name="country_val" value="">

    <div class="row">
        <div class="col-md-12 table-rows-border">
            <div class="col-md-6 col-sm-12">

                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder"> Account Name <abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">

                        <input type='text' name="cust_name" class="form-control" value="<?php echo $account_tree->label ?>" required disabled/>
                        <div class="form_error"> <?php echo $this->session->flashdata('cust_name'); ?></div>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <div class="row">
        <div class="col-md-12 table-rows-border">

            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Email</label>
                    <div class="col-md-8">

                            <input type='email' name="email" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->email; } ?>" />
                        
                        <span class="new_txt_fld"></span>
                       
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Address</label>
                    <div class="col-md-8">
                    <input type='text' name="address" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->address; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('address'); ?></div>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-12 table-rows-border">

            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Phone</label>
                    <div class="col-md-8">

                            <input type='text' name="phone" pattern="^[0-9 ]*$" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->phone; } ?>" />
                        
                        <span class="new_txt_fld"></span>
                       
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Mobile</label>
                    <div class="col-md-8">
                    <input type='text' name="mobile_phone" class="form-control" pattern="^+[0-9 ]*$" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->mobile_phone; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('address'); ?></div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 table-rows-border">

            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Fax</label>
                    <div class="col-md-8">

                            <input type='text' name="fax" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->fax; } ?>" />
                        
                        <span class="new_txt_fld"></span>
                       
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">PO Box</label>
                    <div class="col-md-8">
                    <input type='text' name="po_box" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->po_box; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('address'); ?></div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 table-rows-border">

            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Contact Person</label>
                    <div class="col-md-8">

                        <input type='text' name="contact_person" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->contact_person; } ?>" />
                        
                        <span class="new_txt_fld"></span>
                       
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>


        </div>
    </div>


    <div class="row">
        <div class="col-md-12 table-rows-border">

            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">VAT</label>
                    <div class="col-md-8">

                            <input type='text' name="vat_no" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->vat_no; } ?>" />
                        
                        <span class="new_txt_fld"></span>
                       
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>
            <input type="text" name="account_id" value="<?php echo $account_tree->id ?>" hidden>

             
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 table-rows-border">
<h4>Accounts Department Contact Details </h4>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Accounts Contact Person Name</label>
                    <div class="col-md-8">
                    <input type='text' name="acc_contact_name" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->acc_contact_name; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('acc_contact_name'); ?></div>

                    </div>
                </div>
            </div>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Accounts Contact number</label>
                    <div class="col-md-8">
                    <input type='text' name="acc_number" class="form-control" pattern="^+[0-9 ]*$" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->acc_number; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('acc_number'); ?></div>

                    </div>
                </div>
            </div>

               <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Accounts Contact Email</label>
                    <div class="col-md-8">
                    <input type='email' name="acc_email" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->acc_email; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('acc_email'); ?></div>

                    </div>
                </div>
            </div>
</div>
</div>

 <div class="row">
        <div class="col-md-12 table-rows-border">
<h4>Purchase Department Contact Details </h4>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Purchase Contact Person</label>
                    <div class="col-md-8">
                    <input type='text' name="pur_name" class="form-control"  value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->pur_name; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('pur_name'); ?></div>

                    </div>
                </div>
            </div>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Purchase Contact number</label>
                    <div class="col-md-8">
                    <input type='text' name="pur_number" class="form-control" pattern="^+[0-9 ]*$" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->pur_number; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('pur_number'); ?></div>

                    </div>
                </div>
            </div>

               <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Purchase Contact Email</label>
                    <div class="col-md-8">
                    <input type='email' name="pur_email" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->pur_email; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('pur_email'); ?></div>

                    </div>
                </div>
            </div>
</div>
</div>

 <div class="row">
        <div class="col-md-12 table-rows-border">
<h4>Manager Level Contact Details </h4>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Company Manager/Owner Name</label>
                    <div class="col-md-8">
                    <input type='text' name="own_name" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->own_name; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('own_name'); ?></div>

                    </div>
                </div>
            </div>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Company Manager/Owner number</label>
                    <div class="col-md-8">
                    <input type='text' name="own_number" class="form-control" pattern="^+[0-9 ]*$" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->own_number; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('own_number'); ?></div>

                    </div>
                </div>
            </div>

               <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Company Manager/Owner Name Email</label>
                    <div class="col-md-8">
                    <input type='email' name="own_email" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->own_email; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('own_email'); ?></div>

                    </div>
                </div>
            </div>

            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Sales Manager Name</label>
                    <div class="col-md-8">
                    <input type='text' name="sm_name" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->sm_name; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('sm_name'); ?></div>

                    </div>
                </div>
            </div>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Sales Manager number</label>
                    <div class="col-md-8">
                    <input type='text' name="sm_number" class="form-control" pattern="^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->sm_number; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('sm_number'); ?></div>

                    </div>
                </div>
            </div>

               <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Sales Manager Email</label>
                    <div class="col-md-8">
                    <input type='email' name="sm_email" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->sm_email; } ?>" />
                        <div class="form_error"> <?php echo $this->session->flashdata('sm_email'); ?></div>

                    </div>
                </div>
            </div>
</div>
</div>

<div class="row">
        <div class="col-md-12 table-rows-border">
<h4>Create Customer User for Login</h4>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Create Login Username</label>
                    <div class="col-md-8">
                    <input type='text' name="login_username" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->login_username; } ?>" autocomplete="off" />
                        <div class="form_error"> <?php echo $this->session->flashdata('login_username'); ?></div>

                    </div>
                </div>
            </div>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Create Login Password</label>
                    <div class="col-md-8">
                    <input type='password' name="login_password" class="form-control" value="<?php if(!empty($account_tree_data)) { echo $account_tree_data[0]->login_password; } ?>" autocomplete="off"  />
                        <div class="form_error"> <?php echo $this->session->flashdata('login_password'); ?></div>

                    </div>
                </div>
            </div>

              
</div>
</div>

     <div class="row">
        <div class="col-md-12 table-rows-border">
<h4>Data required for sales invoice </h4>
            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Sales Person</label>
                    <div class="col-md-8">

                        <select data-plugin-selectTwo  class="form-control populate" name="macd_salesman_id">
                          <option value="">Choose</option>
                        <?php
                        $data_salesman=array_filter($salesman);
                        foreach($data_salesman as $sm)
                        {
                          ?>
                           <option value="<?php echo $sm[0]->ed_id;?>" <?php if(!empty($account_tree_data)){if($account_tree_data[0]->macd_salesman_id==$sm[0]->ed_id){ echo 'selected'; }} ?>> <?php echo $sm[0]->ed_name;?> </option> 
                          <?php
                        }
                        ?>
                         </select>
                       
                        <div class="form_error"> <?php echo $this->session->flashdata('macd_salesman_id'); ?></div>
                    </div>
                </div>

            </div>

              <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Company </label>
                    <div class="col-md-8">

                     <select data-plugin-selectTwo  class="form-control populate" name="macd_company_id">
                      <option value="">Choose</option>
                     <?php
                     foreach($company_masters as $cm)
                     {?>
                      <option value="<?php echo $cm->mcomp_id;?>" <?php if(!empty($account_tree_data)){if($account_tree_data[0]->macd_company_id==$cm->mcomp_id){ echo 'selected'; }} ?>> <?php echo $cm->mcomp_name;?></option> 
                      <?php
                    }?>

                     </select>
                       
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>

             <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Country</label>
                    <div class="col-md-8">

                        <select data-plugin-selectTwo  class="form-control populate" name="country">
                              <option value="">Choose</option>
                             <?php
                             foreach($region as $mr)
                             {?>
                              <option value="<?php echo $mr->mr_id;?>" <?php if(!empty($account_tree_data)){if($account_tree_data[0]->country==$mr->mr_id){ echo 'selected'; }} ?>> <?php echo $mr->mr_name;?></option> 
                              <?php
                            }?>

                             </select>
                       
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>

              <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Payment Method</label>
                    <div class="col-md-8">
                    <select data-plugin-selectTwo  class="form-control populate" name="macd_payment_type_id">
                      <option value="">Choose</option>
                     <?php
                     foreach($payment_method as $pm)
                     {?>
                      <option value="<?php echo $pm->mpm_id;?>" <?php if(!empty($account_tree_data)){if($account_tree_data[0]->macd_payment_type_id==$pm->mpm_id){ echo 'selected'; }} ?>> <?php echo $pm->mpm_name;?></option> 
                      <?php
                    }?>

                     </select>
                       
                    <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>

             <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Sales Account Type</label>
                    <div class="col-md-8">
                    <select data-plugin-selectTwo  class="form-control populate" name="macd_sales_acc_id">
                      <option value="">Choose</option>
                     <?php
                     foreach($sales_accont as $sa)
                     {?>
                      <option value="<?php echo $sa->id;?>" <?php if(!empty($account_tree_data)){if($account_tree_data[0]->macd_sales_acc_id==$sa->id){ echo 'selected'; }} ?>> <?php echo $sa->label;?></option> 
                      <?php
                    }?>
                     </select>
                       
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>

            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Customer Credit Days</label>
                    <div class="col-md-8">
                  <input type="number" class="form-control" step="any" name="credit_days" value="<?php if(!empty($account_tree_data)){echo $account_tree_data[0]->credit_days;};?>">
                         <div class="form_error"> <?php echo $this->session->flashdata('credit_days'); ?></div>
                    </div>
                </div>

            </div>

            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Credit Limit Amount</label>
                    <div class="col-md-8">
                  <input type="number" class="form-control" step="any" name="credit_amount" value="<?php if(!empty($account_tree_data)){echo $account_tree_data[0]->credit_amount;};?>">
                         <div class="form_error"> <?php echo $this->session->flashdata('credit_amount'); ?></div>
                    </div>
                </div>

            </div><br/>

              <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Price Level</label>
                    <div class="col-md-8">

                       <select data-plugin-selectTwo  class="form-control populate" name="macd_price_level_id">
                          <option value="">Choose</option>
                         <?php
                         foreach($price_level as $pl)
                         {?>
                          <option value="<?php echo $pl->mpc_id;?>" <?php if(!empty($account_tree_data)){if($account_tree_data[0]->macd_price_level_id==$pl->mpc_id){ echo 'selected'; }} ?>> <?php echo $pl->mpc_name;?></option> 
                          <?php
                        }?>

                         </select>
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>

              <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Place of Supply</label>
                    <div class="col-md-8">
                     <select data-plugin-selectTwo  class="form-control populate" name="macd_place_supply_id">
                      <option value="">Choose</option>
                     <?php
                     foreach($place_supply as $ps)
                     {?>
                      <option value="<?php echo $ps->mw_id;?>" <?php if(!empty($account_tree_data)){if($account_tree_data[0]->macd_place_supply_id==$ps->mw_id){ echo 'selected'; }} ?>> <?php echo $ps->mps_name;?></option> 
                      <?php
                    }?>
                     </select>
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>

             <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Jurisdication</label>
                    <div class="col-md-8">
                    <select data-plugin-selectTwo  class="form-control populate" name="macd_jurisdication_id">
                      <option value="">Choose</option>
                     <?php
                     foreach($place_supply as $ps)
                     {?>
                      <option value="<?php echo $ps->mw_id;?>" <?php if(!empty($account_tree_data)){if($account_tree_data[0]->macd_jurisdication_id==$ps->mw_id){ echo 'selected'; }} ?>> <?php echo $ps->mps_name;?></option> 
                      <?php
                    }?>
                     </select>
                       
                        <div class="form_error"> <?php echo $this->session->flashdata('email'); ?></div>
                    </div>
                </div>

            </div>


            <div class="col-md-6 col-sm-12">
                <div class="form-group">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Currency Conv. value</label>
                    <div class="col-md-8">
                   <select data-plugin-selectTwo  class="form-control populate" name="macd_currency_value">
                      <option value="">Choose</option>
                      <?php
                      foreach($currency_convt as $cv)
                      {
                        ?>
                     <option value="<?php echo $cv->c_id;?>" <?php if(!empty($account_tree_data)){if($account_tree_data[0]->macd_currency_value==$cv->c_id){ echo 'selected'; }}else{if($cv->currency_name=="AED"){echo "selected";}} ?>  > <?php echo $cv->currency_name;?> </option> 
                        <?php
                      }
                      ?>
                     </select>
                        <div class="form_error"> <?php echo $this->session->flashdata('address'); ?></div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-9 col-sm-offset-3">
        <button class="btn btn-primary">Submit</button>
        <button type="reset" class="btn btn-default">Reset</button>
    </div>


    <?php echo form_close(); ?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">

</script>

</html>