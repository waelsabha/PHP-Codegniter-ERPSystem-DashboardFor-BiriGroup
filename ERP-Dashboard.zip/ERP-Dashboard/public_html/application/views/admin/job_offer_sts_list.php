<!doctype html>
<html class="fixed">


<head>

<?php $this->load->view('admin/head');?>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/morris/morris.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>


<style type="text/css">
  .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

  .datetimepicker4{z-index:18000 !important}
</style>
</head>
<body>
<section class="body">



<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">



<section role="main" class="content-body">
<header class="page-header">
<h2>Job Offer Sts</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Job Offer Status</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>





<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg"><?php echo $this->lang->line('Request job offer'); ?>
<div class="row">
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-tertiary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-shopping-cart"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $this->lang->line('New Job Offer Pending'); ?></h4>
<div class="info">
<strong>
<?php if(!empty($new_offer_pending)){print_r($new_offer_pending);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-info">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-thumbs-up"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $this->lang->line('Job Offer approved'); ?></h4>
<div class="info">
<strong>
<?php if(!empty($new_offer_approved)){print_r($new_offer_approved);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>




</div>
</div>

</div>




<?php  $this->load->view('admin/all_job_offer_pending',$pending_offer_list);?>

<?php  $this->load->view('admin/all_job_offer_approved',$approved_offer_list);?>

<!--closing row-->













</section>


</div>
</section>







<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-appear/jquery.appear.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>






<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
    $(function () {
          $('.datetimepicker4').datetimepicker();
      });

  function select_date()
  {
   var date_selected=$("input[name='date_selected']").val();
   if(date_selected=='')
      alert('please choose a date');
    else
    {
      jQuery.ajax({
         url:"<?php echo base_url().'Dashboard_controller/get_date_val';?>",
        type:"post",
        data:{"date_selected":date_selected},
        success:function(result)
        {
           var returndata=JSON.parse(result);
         // $.each()
        }
      });
      
    }
  }

</script>



<script type="text/javascript">
 $(document).ready(function()
    {
        
         $('#datatable-default2').DataTable( {//////pending table
              rowReorder: {
            selector: 'td:nth-child(2)'
              },
                 "pageLength": 50,
          responsive: true,
           "scrollX": true,
        });

         $('#datatable-default3').DataTable( {///approved table
              rowReorder: {
            selector: 'td:nth-child(2)'
              },
                 "pageLength": 50,
          responsive: true,
           "scrollX": true,
        });

      });

function approve_job_offer(id)
 {
    jQuery.ajax({
             url:"<?php echo base_url().'Admin_biri/approve_job_offer';?>",
                type:"post",
                data:{"job_id":id},
                beforeSend: function(){
                 $(".load-image").show();
               },
               complete: function(){
                 $(".load-image").hide();
               },
                success:function(result)
                {
                  if(result==1)
                    location.reload();
                  else
                  {
                    new PNotify({
                      title: 'Error',
                      text: 'Unable to send email.Please try again.',
                      type: 'error'
                    });
                  }
                  //console.log(result);
                }
            });
 }



</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker();
            });

        </script>


</body>

</html>