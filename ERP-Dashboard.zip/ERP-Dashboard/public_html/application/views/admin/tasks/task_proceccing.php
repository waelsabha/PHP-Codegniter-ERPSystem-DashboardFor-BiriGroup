<section class="panel">
<header class="panel-heading">
<?php
				if(($this->session->userdata['user']['main_dept']=="Main")||($this->session->userdata['user']['log_designation']=="Team-lead"))
				{   	
  ?>
<h2 class="panel-title">List Task Proccesing<span class="pull-right"><a href="<?php echo base_url('create-task');?>" class="btn btn-primary">Make New Task </a></span></h2>
<?php }?>
</header>

<div class="panel-body">
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>

	<th >Task Number</th>	
	<th >Task Name</th>	
	<th>Created by</th>
	
	<th>Task Status</th>
	<th >Task Deadline Date </th>
	<th>Brief</th>
	<th>Action</th>
</tr>
</thead>
<tbody class="data_item_req">
<?php

$i=1;
foreach($result as $index1=>$t)
{

if($t['t_status']=='1')
{

		

  if(!empty($t['expected_shipment_date']))
  {
  $converted_date_delivry = date("m/d/Y", strtotime($t['expected_shipment_date']));
  }
  
?>
<tr class="gradeX">
	<?php

	
		//echo "in else";
		if($t['t_status'] != '0')
		{
			$color='';$task_name='';
			switch($t['t_status'])
			{
			
			case '1':
			$task_name='Task Proccecing';
			$color='#f50057';
			break;
			case '2':
			$task_name='Task Postponent';
			$color='#ffc107';
			break;
			case '3':
			$task_name='Task Cancelled';
			$color='#FF5733';
			break;
			case '4':
			$task_name='Task Done';
			$color='#00cc00';
			break;
			
			}

			$task_sts=$task_name;
			$task_color=$color;
		}
		else
		{
			$task_sts='New Task';
			$task_color='blue';
		}
	
			
			?>
			
			<td><?php echo $t['t_id'];?></td>
			<td><?php echo $t['t_summary'];?><br/></td>
			<td><?php echo $t['t_user_created'];?><br/><b>Created On:</b> <?php echo $t['t_start_time'];?></td>
			
			<td>
			
			
					<!-- Example split danger button -->
<div class="btn-group">
  <button type="button" class="btn btn-sm" style="background-color:<?php echo $task_color;?>;color:white;"><?php echo $task_sts;?></button>
  <button type="button" class="btn btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color:<?php echo $task_color;?>;color:white;">
    <span class="fa fa-caret-down"></span>
  </button>
   
  	<?php
				if(($this->session->userdata['user']['main_dept']=="Main") || ($this->session->userdata['user']['main_dept']=="Purchase")||($this->session->userdata['user']['log_designation']=="Dubai_Direct")||($this->session->userdata['user']['log_designation']=="Team-lead"))
				{   	
  ?>

		 <div class="dropdown-menu">
					 	<?php
					if($t['t_status']=='1')
					{
					?>
 
    <a class="dropdown-item" href="<?php echo base_url('change_task_req_sts/4/'.$t['t_id']);?>">Done</a>
     <div class="dropdown-divider"></div>
      <a class="dropdown-item" href="<?php echo base_url('change_task_req_sts/2/'.$t['t_id']);?>">PostPonent</a>
     <div class="dropdown-divider"></div>
       <a class="dropdown-item" href="<?php echo base_url('change_task_req_sts/3/'.$t['t_id']);?>">Cancelled</a>
     <div class="dropdown-divider"></div>
    	<?php
			}
		elseif($t['t_status']=='2')
			{?>
  
   <a class="dropdown-item" href="<?php echo base_url('change_task_req_sts/1/'.$t['t_id']);?>">Resume</a>
     <div class="dropdown-divider"></div>
      <a class="dropdown-item" href="<?php echo base_url('change_task_req_sts/3/'.$t['t_id']);?>">Cancelled</a>
     <div class="dropdown-divider"></div>
   	<?php
	}
	elseif($t['t_status']=='3')
	{?>
 
    
    <?php
	}
	elseif($t['t_status']=='4')
	{?>
    
  
   <?php
	}
	elseif($t['t_status']=='5')
	{?>
     <a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalsm_complete<?php echo $t['t_id'];?>">Completed</a>
     <div class="dropdown-divider"></div>
     <?php
	}
	else{}
	?>
    <div class="dropdown-divider"></div>
   
  </div>
  	<?php






				}
				
				?>


</div>
<!-- Example end danger button -->

				
			</td>
			<td><?php echo $t['t_end_date'];?></td>

			<td><?php echo $t['t_brief'];?></td>
		
			
			<td>	
  	<?php
				if(($this->session->userdata['user']['main_dept']=="Main")||($this->session->userdata['user']['log_designation']=="Team-lead"))
				{   	
  ?>


<div class="dropdown-primary dropdown">
<button class="btn btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >Action</button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">
 

 

<a class="dropdown-item waves-light waves-effect" onclick="view_data_user('<?php echo $t['t_id'];?>');" ><i class="fa fa-eye"></i>View</a>
<div class="dropdown-divider"></div>


<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="edit_task_request/<?php echo $t['t_id'];?>"><i class="fa fa-pencil"></i>Edit Details</a>


<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modal_reqtask<?php echo $t['t_id'];?>"><i class="fa fa-pencil"></i>Write your Comment</a>







</div>
</div>
<?php }?>
<?php
$current_date=date('Y-m-d');    
  					
  					//it will take the end date and compare with date now ...then calculate the number of days pass, if it days 0 then today is the end date and if 1 then yesterday is the end date so we will put this condition 
  					$Date_difftoend=strtotime($current_date)-strtotime($t['t_end_date']);
  							
  					$final_end_date=round($Date_difftoend / (60 * 60 * 24));

					    if($final_end_date>=0)
					     {
						$glow_val='style="background-color: #da0606;
						  color: white;
						  -webkit-animation: glowing 1500ms infinite;
						  -moz-animation: glowing 1500ms infinite;
						  -o-animation: glowing 1500ms infinite;
						  animation: glowing 1500ms infinite;"';
					  echo '<button class="label label-lg " '.$glow_val.' >URGENT!! Late Task</button>';
						}
						else
						{
							$glow_val='';
						}
						?>
</td>

</tr>
<!-- Button trigger modal 2-->

<!----end modal--->

<!-- Button trigger modal 3 ordered-->
 <div id="modalsm1<?php echo $t['t_id'];?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Expected Date of shippment </h2>
</header>
<?php echo form_open('submit_item_req_sts');?>
<input type="hidden" value="<?php echo $t['t_id'];?>" name="item_req_sts_id">
<input type="hidden" value="3" name="status_value">

<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<div class="col-md-12 col-sm-12 table-rows-border ">
	<div class="form-group">
	<label class="col-md-3 control-label" for="inputSuccess">Expected Date of shippment</label>
	<div class="col-md-6">
	<input type='text' name="hold_date" class="form-control datetimepicker5 " />	
	</div>
	</div>
	</div>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit" class="btn btn-primary">Confirm</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!----end modal--->



<!---------modal for request info---------------->
<div id="modal_reqtask<?php echo $t['t_id'];?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Write your Comment.</h2>
</header>
<?php echo form_open('Task_Scheduler/submit_more_info_req');?>
<input type="hidden" value="<?php echo $t['t_id'];?>" name="item_task_id">
<input type="hidden" name="item_task_type" value="request">
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<div class="col-md-12 col-sm-12 table-rows-border ">
			<div class="form-group">
<label class="col-sm-3 control-label">Subject</label>
<div class="col-sm-9">
<input type="text" name="task_sub"  class="form-control" required="">
</div>
</div>
	<div class="form-group">
<label class="col-sm-3 control-label">Content</label>
<div class="col-sm-9">
<textarea rows="5" name="task_info" class="form-control" placeholder=">Write your Comment ..." required=""></textarea>
</div>
</div>
	</div>

	  <span class="load-image"><small style="color:red;"><br/>Please wait,sending email....<br/></small>
 <img src="<?php echo base_url('admin_assets/images/');?>loading_gif.gif" width="200" height="200" alt="Loading image" />
</span>

</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit" class="btn btn-primary" onclick="show_mail_sending_rq()">Confirm</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!-------------end of modal---------------------->






<!-- Button trigger modal 3 ordered-->
 <div id="modal_ordered<?php echo $t['t_id'];?>" class="modal-block modal-block-md mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Ordered  </h2>
</header>
<input type="hidden" value="<?php echo $t['t_id'];?>" name="item_req_sts_id">
<input type="hidden" value="3" name="status_value">

<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<div class="col-md-12 col-sm-12 table-rows-border ">
<div class="form-group">
	<label class="col-md-3 control-label" for="inputSuccess">When this order will be ready to ship? <abbr>*</abbr></label>
<div class="input-group mb-md">
<input type='text' name="expected_date" required="" class="form-control datetimepicker5 " />
<small class="error_msg" style="color: red"></small>
</div>
</div>

	<!-- <div class="form-group">
	<label class="col-md-3 control-label" for="inputSuccess">Upload Supporting Documents <abbr>*</abbr></label>
<div class="input-group mb-md">
<input type="file" class="form-control ordered_prd_file_<?php echo $t['t_id'];?>">
<span class="input-group-btn">
<button class="btn btn-success" type="button" onclick="ordered_file_upload(<?php echo $t['t_id'];?>,'ordered');">Click to Upload</button>
</span>
</div>
<br/><small>NOTE:File Size should be less than 1 MB , ONLY  PDF!!!</small>
	</div> -->
	</div>
</div>
</div>
</div>
 <footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button" onclick="ordered_file_upload(<?php echo $t['t_id'];?>,'ordered');" class="btn btn-primary">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>




 <div id="modal_ordered_ksa<?php echo $t['t_id'];?>" class="modal-block modal-block-md mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Ordered  </h2>
</header>
<input type="hidden" value="<?php echo $t['t_id'];?>" name="item_req_sts_id">
<input type="hidden" value="3" name="status_value">

<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<div class="col-md-12 col-sm-12 table-rows-border ">
<div class="form-group">
	<label class="col-md-3 control-label" for="inputSuccess">When this order will be ready to ship? <abbr>*</abbr></label>
<div class="input-group mb-md">
<input type='text' name="expected_date" required="" class="form-control datetimepicker5 " />
<small class="error_msg" style="color: red"></small>
</div>
</div>

	<!-- <div class="form-group">
	<label class="col-md-3 control-label" for="inputSuccess">Upload Supporting Documents <abbr>*</abbr></label>
<div class="input-group mb-md">
<input type="file" class="form-control ordered_prd_file_<?php echo $t['t_id'];?>">
<span class="input-group-btn">
<button class="btn btn-success" type="button" onclick="ordered_file_upload(<?php echo $t['t_id'];?>,'ordered');">Click to Upload</button>
</span>
</div>
<br/><small>NOTE:File Size should be less than 1 MB , ONLY  PDF!!!</small>
	</div> -->
	</div>
</div>
</div>
</div>
 <footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button" onclick="ordered_file_upload_ksa(<?php echo $t['t_id'];?>,'ordered');" class="btn btn-primary">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>

<!----end modal--->


<!-- Button trigger modal 3 ordered-->
 <div id="modal_rs<?php echo $t['t_id'];?>" class="modal-block modal-block-md mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Ready to Ship -> Upload Payment Documents </h2>
</header>	
<input type="hidden" value="<?php echo $t['t_id'];?>" name="item_req_sts_id">
<input type="hidden" value="3" name="status_value">

<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<div class="col-md-12 col-sm-12 table-rows-border ">

<div class="form-group">
	<label class="col-md-3 control-label" for="inputSuccess">When this order will be ready to ship? <abbr>*</abbr></label>
<div class="input-group mb-md">
<input type='text' name="expected_date" required="" class="form-control datetimepicker5 " />
<small class="error_msg" style="color: red"></small>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label" for="inputSuccess">Upload Payment Documents <abbr>*</abbr></label>
<div class="input-group mb-md">
<input type="file" class="form-control ordered_prd_file_<?php echo $t['t_id'];?>">
<!-- <span class="input-group-btn">
<button class="btn btn-success" type="button" onclick="ordered_file_upload(<?php echo $t['t_id'];?>,'ready_shipping');">Click to Upload</button>
</span> -->
</div>
<br/><small>NOTE:File Size should be less than 1 MB , <b style="color: red;">ONLY PDF FILES</b>  !!!</small>
	</div>

	  <span class="load-image"><small style="color:red;"><br/>Please wait,uploading file and sending email....<br/></small>
 <img src="<?php echo base_url('admin_assets/images/');?>loading_gif.gif" width="200" height="200" alt="Loading image" />
</span>
	</div>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button" onclick="ordered_file_upload(<?php echo $t['t_id'];?>,'ready_shipping');" class="btn btn-primary">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal--->
<!-- Button trigger modal 3 shipped-->
 <div id="modalsm2<?php echo $t['t_id'];?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Expected Date of Arrival/ETA </h2>
</header>
<?php echo form_open('submit_item_req_sts');?>
<input type="hidden" value="<?php echo $t['t_id'];?>" name="item_req_sts_id">
<input type="hidden" value="5" name="status_value">

<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<div class="col-md-12 col-sm-12 table-rows-border on_hold_till">
	<div class="form-group">
	<label class="col-md-3 control-label" for="inputSuccess">Expected Date of Arrival</label>
	<div class="col-md-6">
	<input type='text' name="hold_date" class="form-control datetimepicker5 on_hold_till"   />
	</div>
	</div>
	</div>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit" class="btn btn-primary">Confirm</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!----end modal--->

<!-- Button trigger modal 3 ready to ship-->
 <div id="modalsm3<?php echo $t['t_id'];?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Modify shippment date </h2>
</header>
<?php echo form_open('submit_item_req_sts');?>
<input type="hidden" value="<?php echo $t['t_id'];?>" name="item_req_sts_id">
<input type="hidden" value="4" name="status_value">
 
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<div class="col-md-12 col-sm-12 table-rows-border ">
			<?php
		if(!empty($converted_date_delivry))
		{
			echo "<b> Expected shippment date : ".$converted_date_delivry."</b>" ;
		}
		?>
	<div class="form-group">
	<label class="col-md-3 control-label" for="inputSuccess">Modify shippment date</label>
	<div class="col-md-6">

	<input type='text' value="" name="hold_date" class="form-control datetimepicker5 " autocomplete="off"  />	
	</div>
	</div>
	</div>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit" class="btn btn-primary">Confirm</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!----end modal--->
<script type="text/javascript">
	function view_data_user(id)
{
	//console.log('view');
    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('Task_Scheduler/ajax_load_view_task/')?>",
        type: "POST",
        data: {"t_id":id},
        success: function(data)
        {
        	$('.view_data_modal3').html(data);
            $('#modalsm3_view_data').modal('show'); // show bootstrap modal when complete loaded
          },
    });
}
</script>
<script type="text/javascript">

</script>
<!-------------------modal view quotation------------>
<div class="modal fade" id="modalsm3_view_data" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">View data</h3>
            </div>
            <div class="modal-body form ">
            	<div class="row view_data_modal3" ></div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>






<!------------modal view quotation ends----------->

<!------------modal complete add details modal ----------->
<div id="modalsm_complete<?php echo $t['t_id'];?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Details </h2>
</header>
<?php echo form_open('Task_Scheduler/submit_completed_extra_data');?>
<input type="hidden" value="<?php echo $t['t_id'];?>" name="item_req_id">
<input type="hidden" value="7" name="status_value">
 
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<div class="col-md-12 col-sm-12 table-rows-border ">
		
	<div class="form-group">
	<label class="col-md-3 control-label" for="inputSuccess">Add Material Receipt Number(MRN) </label>
	<div class="col-md-6">

	<input type='text' value="" name="mrn_num" class="form-control  " required="" autocomplete="off"  />	
	</div>
	</div>

	<div class="form-group">
	<label class="col-md-3 control-label" for="inputSuccess">Purchase Voucher Number(PV)</label>
	<div class="col-md-6">

	<input type='text' value="" name="pv_num" class="form-control  " required="" autocomplete="off"  />	
	</div>
	</div>


	</div>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit" class="btn btn-primary">Confirm</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!--------------------------end modal----------------------->

<?php 
}
}
?>



</tbody>
</table>
</div>

<!------------closing the section-panel here------------->
</div>
</section>