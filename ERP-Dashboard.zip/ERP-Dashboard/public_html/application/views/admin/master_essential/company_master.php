<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Masters - Company </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Masters</span></li>
<li><span> Company Details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-----section for lightbox opens here-->

<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Masters - Company<span><button class="btn btn-primary pull-right modal-with-form" href="#modalForm2">Add Company Master<i class="fa fa-plus"></i></button></span></h2>
<p class="panel-subtitle">Master company data here</p>
</header>
<div class="panel-body">
<div id="treeBasic" class="jstree jstree-1 jstree-default" role="tree" aria-activedescendant="j1_1">
	<?php
	foreach($result as $index=>$r)
	{?>
	<ul class="jstree-container-ul jstree-children">
		<li role="treeitem" aria-expanded="true" id="j1_1" class="jstree-node  jstree-open" aria-selected="false">
			<i class="jstree-icon jstree-ocl"></i>
	<a class="jstree-anchor modal-with-form" href="#modalForm_root<?php echo $r->mcomp_id;?>"><i class="jstree-icon jstree-themeicon fa fa-folder jstree-themeicon-custom"></i>
		<?php
		if(empty($r->mcomp_pid))
		{
		echo $r->mcomp_name;
	}?>
	</a>
	<?php
	foreach($child[$index] as $c)
	{
		foreach($c as $m)
		{
		?>
		<ul role="group" class="jstree-children">

			<li role="treeitem" data-jstree="{ &quot;opened&quot; : true }" aria-expanded="true" id="j1_3" class="jstree-node  jstree-open" aria-selected="false"><i class="jstree-icon jstree-ocl"></i><a class="jstree-anchor modal-with-form" href="#modalForm_child<?php echo $m->mcomp_id;?>"><i class="jstree-icon jstree-themeicon fa fa-folder jstree-themeicon-custom"></i>
			<?php
			echo $m->mcomp_name;
		?>
			</a>
			</li>
		</ul>
		<div id="modalForm_child<?php echo $m->mcomp_id;?>" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"> Child Company </h2>
</header>
<div class="panel-body">

<?php echo form_open('Masters_essentials/submit_master_comp','class="form-horizontal mb-lg extra-form"');?>
<div class="form-group mt-lg">
	<input type="hidden" name="type" value="editing_child">
	<input type="hidden" name="root_id" value="<?php echo $m->mcomp_id;?>">
<label class="col-sm-3 control-label">Child Name <abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" value="<?php echo $m->mcomp_name;?>" name="comp_master_name" class="form-control"  required />
</div>
</div>

</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary" type="submit">Edit</button>
<a class="btn btn-danger mb-xs mt-xs mr-xs modal-sizes" href="#modal_delete_<?php echo $m->mcomp_id;?>">Delete</a>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>

<!-- Button trigger modal 3, deleting child here-->
 <div id="modal_delete_<?php echo $m->mcomp_id;?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Are You Sure?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<p>Are you sure, you want to delete this details permanently?<br/>
			<small style="color: red">This action cannot be undone.</small>
		</p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<a href="<?php echo base_url('Masters_essentials/delete_comp/'.$m->mcomp_id);?>"  class="btn btn-primary">Confirm</a>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal for deleting child--->
		<?php
		}
	}?>
	</li>
</ul>
<div id="modalForm_root<?php echo $r->mcomp_id;?>" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Child Company </h2>
</header>
<div class="panel-body">

<?php echo form_open('Masters_essentials/submit_master_comp','class="form-horizontal mb-lg extra-form"');?>
<div class="form-group mt-lg">
	<input type="hidden" name="type" value="creating_child">
	<input type="hidden" name="root_id" value="<?php echo $r->mcomp_id;?>">
<label class="col-sm-3 control-label">Child Name <abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="comp_master_name" class="form-control"  required />
</div>
</div>

</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary" type="submit">Submit</button>
<a class="btn btn-danger mb-xs mt-xs mr-xs modal-sizes" href="#modal_delete_<?php echo $r->mcomp_id;?>">Delete</a>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>

<!-- deleting root here-->
 <div id="modal_delete_<?php echo $r->mcomp_id;?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Are You Sure?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
		<p>Are you sure, you want to delete this details permanently?<br/>
			<small style="color: red">This action cannot be undone.</small>
		</p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<a href="<?php echo base_url('Masters_essentials/delete_comp/'.$r->mcomp_id);?>"  class="btn btn-primary">Confirm</a>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal for deleting root--->

<?php
}?>

</div>
</div>
</section>


<!-----section for lighbox closes here--->
<div id="modalForm2" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Master Company </h2>
</header>
<div class="panel-body">

<?php echo form_open('Masters_essentials/submit_master_comp','class="form-horizontal mb-lg extra-form"');?>
	<input type="hidden" name="type" value="new_comp">
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Parent Name <abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="comp_master_name" class="form-control"  required />
</div>
</div>

</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary" type="submit">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	 $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );
</script>

</body>
</html>