<style type="text/css">
	.chat
{
    list-style: none;
    margin: 0;
    padding: 0;
}

.chat li
{
    margin-bottom: 10px;
    padding-bottom: 5px;
    border-bottom: 1px dotted #B3A9A9;
}

.chat li.left .chat-body
{
    margin-left: 60px;
}

.chat li.right .chat-body
{
    margin-right: 60px;
}


.chat li .chat-body p
{
    margin: 0;
    color: #777777;
}

.panel .slidedown .glyphicon, .chat .glyphicon
{
    margin-right: 5px;
}



::-webkit-scrollbar-track
{
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    background-color: #F5F5F5;
}

::-webkit-scrollbar
{
    width: 12px;
    background-color: #F5F5F5;
}

::-webkit-scrollbar-thumb
{
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);
    background-color: #555;
}

</style>
<div class="container">
    <div class="row">
        <div class="col-md-3">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <span class="glyphicon glyphicon-comment"></span> Chat
                    <div class="btn-group pull-right">
                        <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown" onclick="refresh_chat_data();">
                            <span class="glyphicon glyphicon-refresh"></span>
                        </button>
                       
                    </div>
                </div>
                <div class="panel-body">
                    <ul class="chat">
                    	 <?php
if(!empty($chat))
{
	
	foreach($chat as $t)
	{
		?>
		 <li class="<?php if($t->user_created==$this->session->userdata['user']['username']){ echo "right";}else{echo "left";};?> clearfix"><span class="chat-img <?php if($t->user_created==$this->session->userdata['user']['username']){ echo "pull-right";}else{echo "pull-left";};?>">
                            <i class="fa fa-user-circle fa-4x" ></i>
                        </span>
                            <div class="chat-body clearfix">
                                <div class="">
                                    <strong class="<?php if($t->user_created==$this->session->userdata['user']['username']){ echo "pull-right";};?> primary-font"><?php echo $t->user_created;?></strong> <small class="pull-right text-muted">
                                        <span class="glyphicon glyphicon-time"></span><?php echo $t->dc_date;?></small>
                                </div>
                                <br/><br/>
                                <p>
                                    <?php echo $t->msg_data;?>
                                </p>
                            </div>
                       
		<?php
	}
	
}
?>      
                    </ul>
                </div>
                <div class="panel-footer">
                    <div class="input-group">
                    	<input type="hidden" name="user_created" value="<?php echo $this->session->userdata['user']['username'];?>">
	<?php
	$url_path=explode('/',$_SERVER['REQUEST_URI']);
	?>
		<input type="hidden" name="page_url" value="<?php echo $url_path[1];?>">

                        <input type="text" name="chat_data" class="form-control input-sm" placeholder="Type your message here..." >
                        <span class="input-group-btn">

                            <button class="btn btn-warning btn-sm" onclick="discussion_data();">
                                Send</button>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
	function discussion_data()
	{
		var msg_data=$('input[name="chat_data"]').val();
		var user_created=$('input[name="user_created"]').val();
		var page_url=$('input[name="page_url"]').val();
		 jQuery.ajax({
                     url:"<?php echo base_url().'Masters_essentials/discussion_module';?>",
                    type:"post",
                     data:{"msg_data":msg_data,
                     "user_created":user_created,
                     "page_url":page_url},
                     success:function(result)
                    {
                      if(result)
                      {
                      	$('.chat_window').html(result);
        					$('input[name="chat_data"]').val('');
                      }
                    }
                 });  
	}

	function refresh_chat_data()
	{
		var page_url=$('input[name="page_url"]').val();
		 jQuery.ajax({
                     url:"<?php echo base_url().'Masters_essentials/refresh_chat_data';?>",
                    type:"post",
                     data:{"page_url":page_url},
                     success:function(result)
                    {
                      if(result)
                      {
                          console.log(result);
                      	$('.chat_window').html(result);
        				//	$('input[name="chat_data"]').val('');
                      }
                    }
                 });  
	}
</script>