<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" 
type="text/css"/>
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" 
type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">
<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Asset Register </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Asset Register</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Asset Register</h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('Masters_essentials/submit_asset_reg','class="myform" novalidate','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
 
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

<div class="row">

 <div class="col-md-12 col-sm-12 table-rows-border">
 
<div class="col-md-12 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Asset Class <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<select class="form-control" name="asset_class">
  <option>Choose</option>
  <option value="1">Land</option>
  <option value="2">Buildings</option>
  <option value="3">Machinery & Equipment</option>
  <option value="4">Furniture & Fixture</option>
  <option value="5">Vehicles</option>
  <option value="6">Computer & Other IT Equipment</option>
</select>
  
 <div class="form_error">  <?php echo $this->session->flashdata('ref_no');?></div>
</div>
</div>
<br/>
</div>

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Asset Description <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<input type="text" name="asset_desc" value=""  class="form-control">

  
 <div class="form_error">  <?php echo $this->session->flashdata('ref_no');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Commissioning Date<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
 <input type='text' name="date_ref" class="form-control datetimepicker4" value="<?php if(!empty($result[0]->q_date)){echo $converted_date_delivry;} ;?>" required />
  <div class="form_error">  <?php echo $this->session->flashdata('date_ref');?></div>

</div>
</div>
</div>




<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Company<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
 <select data-plugin-selectTwo  class="form-control populate" name="company_masters">
  <option value="">Choose</option>
 <?php
 foreach($company_masters as $cm)
 {?>
  <option value="<?php echo $cm->mcomp_id;?>" > <?php echo $cm->mcomp_name;?>
    
  </option> 
  <?php
}?>

 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('date_ref');?></div>

</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Gross Value<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
 <input type='text' name="groos_val" class="form-control" value=""  />
  <div class="form_error">  <?php echo $this->session->flashdata('date_ref');?></div>
</div>
</div>
</div>

</div>





<!-------start col-md-12------------------->

<!----------end col-md-12----------------------------->




<!-----div starts here for non-inquiry--->
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for non-inquiry--->
<!----div closes here--->

<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
 <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript"></script>
  
  <script>
            $(document).on('ready', function () {
                $("#file-1").fileinput();
                });
                  </script>
   
 <script>
    tinymce.init({
      selector : '.editors',
        plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
    });
   </script>
   
<script type="text/javascript">
 function add_more_row()
{
var tablecount = $('table tbody tr').length;
  if(tablecount=="0")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }

   var markup='<tr class="table'+table_id+'">'+
    ' <td>'+
       ' <select data-plugin-selectTwo  class="form-control populate salesman_'+table_id+'" name="choose_customer" >'+
  '<option >Choose</option>';
 jQuery.ajax({
                     url:"<?php echo base_url().'Receipt_Master/get_details_salesman';?>",
                    type:"post",
                     success:function(result)
                    {
                     // console.log(result);
                      if(result)
                      {
         var returndata = JSON.parse(result);                  
      $.each(returndata, function(key2,val2)
      {  
        if(val2[0]['ed_name']!='')
        {
          $('.salesman_'+table_id).append("<option value="+val2['ed_id']+">"+val2[0]['ed_name']+"</option>");
        } 
     });
                      }
                    }
                 });  
  
 markup+= '</select>'+
  '</td>'+
 ' <td>'+
     '<select data-plugin-selectTwo  class="form-control populate cust_acc_'+table_id+'" name="choose_customer_acc" >'+
    '<option >Choose</option>';
    jQuery.ajax({
                     url:"<?php echo base_url().'Receipt_Master/get_details_customer_acc';?>",
                    type:"post",
                    success:function(result)
                    {
                      if(result)
                      {
        var returndata = JSON.parse(result);
 // $('.cust_acc_'+table_id).empty().append("<option>Choose Value</option>"); 
    $.each(returndata, function(key2,val2)
      {  
        if(val2['sca_cust_name']!='')
        {
         $('select[name="choose_customer_acc"]').append("<option value="+val2['sca_id']+">"+val2['sca_cust_name']+"</option>");
        }
      });
                      }
                    }
                 });  
  markup+='</select>'+
    '</td>'+
    '<td><input type="text" class="form-control"></td>'+
    '<td><input type="text" class="form-control"> </td>'+
     '<td><input type="text" class="form-control"> </td> '+  
     ' <td><button type="button" class="btn btn-danger" style="cursor: pointer" onclick=table('+table_id+')>X</button></td>'
      '</tr>';
   
            $(".new_rows").append(markup);
             var rowcount = $('table tbody tr').length;
     $(".num_items").html(rowcount);
     $('select[name="choose_customer_acc"]').select2();
}

  function table(id)
  {
    $('table tbody .table'+id).remove();
    var rowcount = $('table tbody tr').length;
    $(".num_items").html(rowcount);
  }

</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker().datepicker("setDate", new Date());
            });
        </script>

</body>

</html>