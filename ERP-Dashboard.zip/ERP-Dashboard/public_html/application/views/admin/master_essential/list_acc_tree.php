<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Account Tree</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Account Tree</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-----section for lightbox opens here-->
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">List Account Tree<span class="pull-right"></span></h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div id="treeBasic" class="jstree jstree-1 jstree-default" role="tree" aria-activedescendant="j1_1">
    <?php
//pre_list($result_child);
    ?>

    <?php
    foreach($result as $index=>$val)
    {
    	echo '<ul class="jstree-container-ul jstree-children">
		<li role="treeitem" aria-expanded="true" id="j1_1" class="jstree-node  jstree-open" aria-selected="false">
			<i class="jstree-icon jstree-ocl"></i>
	<a class="jstree-anchor" href="#"><i class="jstree-icon jstree-themeicon fa fa-folder jstree-themeicon-custom"></i>';

    	echo $val['label'];
    	echo '</a>';
    	if(!empty($val['childs']))
    	{
    		foreach($val['childs'] as $index2=>$val2)
    		{
    			echo '<ul role="group" class="jstree-children">
    			<li role="treeitem" data-jstree="{ &quot;opened&quot; : true }" aria-expanded="true" id="j1_3" class="jstree-node  jstree-open" aria-selected="false"><i class="jstree-icon jstree-ocl"></i><a class="jstree-anchor" href="#"><i class="jstree-icon jstree-themeicon fa fa-folder jstree-themeicon-custom"></i>
    			';

    			echo $val2['label'];

    			if(!empty($result_child[$val2['id']]))
				    			{
				    				foreach($result_child[$val2['id']][0] as $p2)
				    				{
				    					echo '<ul role="group" class="jstree-children">
    			<li role="treeitem" data-jstree="{ &quot;opened&quot; : true }" aria-expanded="true" id="j1_3" class="jstree-node  jstree-open" aria-selected="false"><i class="jstree-icon jstree-ocl"></i><a class="jstree-anchor" href="#"><i class="jstree-icon jstree-themeicon fa fa-folder jstree-themeicon-custom"></i>
    			
    			';
				    					echo $p2->name;
				    					echo'</a>
			</li>
		</ul>';
				    				}
				    			}

    			if(!empty($val2['childs']))
		    	{
		    		foreach($val2['childs'] as $index3=>$val3)
		    		{
		    			echo '<ul role="group" class="jstree-children">
    			<li role="treeitem" data-jstree="{ &quot;opened&quot; : true }" aria-expanded="true" id="j1_3" class="jstree-node  jstree-open" aria-selected="false"><i class="jstree-icon jstree-ocl"></i><a class="jstree-anchor" href="#"><i class="jstree-icon jstree-themeicon fa fa-folder jstree-themeicon-custom"></i>
    			';
		    			echo $val3['label'];

		    			
		    			
		    			if(!empty($val3['childs']))
				    	{
				    		foreach($val3['childs'] as $index4=>$val4)
				    		{
				    			echo '<ul role="group" class="jstree-children">
    			<li role="treeitem" data-jstree="{ &quot;opened&quot; : true }" aria-expanded="true" id="j1_3" class="jstree-node  jstree-open" aria-selected="false"><i class="jstree-icon jstree-ocl"></i><a class="jstree-anchor" href="#"><i class="jstree-icon jstree-themeicon fa fa-folder jstree-themeicon-custom"></i>
    			';
				    			echo $val4['label'];
				    			
				    			
				    			
				    			if(!empty($val4['childs']))
						    	{
						    		foreach($val4['childs'] as $index5=>$val5)
						    		{
						    			echo '<ul role="group" class="jstree-children">
    			<li role="treeitem" data-jstree="{ &quot;opened&quot; : true }" aria-expanded="true" id="j1_3" class="jstree-node  jstree-open" aria-selected="false"><i class="jstree-icon jstree-ocl"></i><a class="jstree-anchor" href="#"><i class="jstree-icon jstree-themeicon fa fa-folder jstree-themeicon-custom"></i>
    			';
				    					echo $val5['label'];

				    	

						    			
						    			if(!empty($val5['childs']))
								    	{
								    	foreach($val5['childs'] as $index6=>$val6)
								    		{
								    			echo '<ul role="group" class="jstree-children">
    			<li role="treeitem" data-jstree="{ &quot;opened&quot; : true }" aria-expanded="true" id="j1_3" class="jstree-node  jstree-open" aria-selected="false"><i class="jstree-icon jstree-ocl"></i><a class="jstree-anchor" href="#"><i class="jstree-icon jstree-themeicon fa fa-folder jstree-themeicon-custom"></i>
    			';
				    					echo $val6['label'];

				    			
								    			echo'</a>
			</li>
		</ul>';
								    		}
								    	}
								    echo'</a>
			</li>
		</ul>';	
						    		}
						    	}
						    echo'</a>
			</li>
		</ul>';	
				    		}
				    	}
				 echo'</a>
			</li>
		</ul>';   	
		    		}
		    	}
		    echo'</a>
			</li>
		</ul>';	
    		}
    	}
    echo'
			</li>
		</ul>';
    }
    ?>
</div>

</div>
</section>
<!-----section for lighbox closes here--->

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	 $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );
</script>

</body>
</html>