
function get_pick_amount(table_id,ij_val=null)
{
  var param_data=pass_param();
  var param_val=param_data.split("##");
  var ij=param_val[0];
  var ref_doc_num= param_val[1];

 var form_input_amount=$('.form_input_amount_'+table_id).val();

  var  to_be_adjust= round($('.to_be_adjust').html());
   var  amount_adjusted_till_now=round($('.amount_adjusted').html());
  //var  to_be_adjust= $('.to_be_adjust').html();
  // var  amount_adjusted_till_now= $('.amount_adjusted').html();

   if(amount_adjusted_till_now=='')
     var amount_picked=0;
   else
    var amount_picked=parseFloat(amount_adjusted_till_now);

if(to_be_adjust=='')
   var amount_adjusted=0;
 else
  var amount_adjusted=parseFloat(to_be_adjust);

 if(ij!='')
  {
 //     console.log('ij '+ij);
  if($('.inv_selected_'+ij).is(':checked'))
  {   
    var total_amount_in_ref=$('.tot_sales_amount_'+ij).val();
    var amount_paid= $('.tot_sales_amount_paid_'+ij).val();
    if(amount_paid=='' || amount_paid=='0')
    { 
   //      console.log('in if 1');
   $('.refrence_amount_'+table_id).val('0');
  // console.log(total_amount_in_ref);
      if(parseFloat(total_amount_in_ref) > parseFloat(form_input_amount))
      { 
      //   console.log('in if 11');
         if(parseFloat(amount_adjusted)=='0' || parseFloat(amount_adjusted)=='' || parseFloat(amount_adjusted)=='0.00')
        {
       //    console.log('in if 12');
         var new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(form_input_amount);
         $('.tot_sales_amount_paid_'+ij).val(form_input_amount);
          amount_picked=parseFloat(form_input_amount);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
        }
        else
        {

       //   console.log('in else 12');
          var new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(amount_adjusted);
         $('.tot_sales_amount_paid_'+ij).val(amount_adjusted);
          amount_picked=parseFloat(amount_picked)+parseFloat(amount_adjusted);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
             
        }
      }
      else
      { 
        if(amount_adjusted!='0')
          {
            // console.log('in else 1.11'+amount_adjusted);
              var new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(amount_adjusted);
                $('.tot_sales_amount_paid_'+ij).val(amount_adjusted);
           amount_picked=parseFloat(amount_picked)+parseFloat(amount_adjusted);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked); 

          }
          else{
        // console.log('in else 11');
        $('.tot_sales_amount_paid_'+ij).val(total_amount_in_ref);
       amount_picked=parseFloat(amount_picked)+parseFloat(total_amount_in_ref);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
            }
       }
     }
    else
    { 
    //  console.log('in else 1');
       if(to_be_adjust!='0.00' || to_be_adjust!='0')
      {
        $('.refrence_amount_'+table_id).val(to_be_adjust);
         amount_picked=parseFloat(amount_adjusted_till_now)+parseFloat(to_be_adjust);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
      }
    }  
    
  }
  else
  {
    $('.refrence_amount_'+table_id).val(form_input_amount);
     amount_picked=form_input_amount;
     $('.form_input_ref_'+table_id).val('new_reference');
  }
}
else
{
   $('.confirm_btn_modal').show();
   if(to_be_adjust!='0.00')
   {
    $('.refrence_amount_'+table_id).val(form_input_amount);
    if( (amount_adjusted_till_now!='') && (amount_adjusted_till_now!='0') )
    {
      amount_picked=amount_adjusted_till_now;
      amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);   
    }
    else
    {
      amount_picked=form_input_amount;
      amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);   
    }  
      $('.form_input_ref_'+table_id).val('new_reference');  
    }
    else {}
}

  $('.amount_to_adj').html(form_input_amount);
   $('.amount_adjusted').html(amount_picked);
    $('.to_be_adjust').html(amount_adjusted);

    // $('.form_input_ref_'+table_id).val($('.form_input_ref_'+table_id).val() + ref_doc_num+'|#|');

  $('.form_input_ref_amount_'+table_id).val(form_input_amount);
  //   $('.modal-close-btn').trigger('click');
}


function pass_param()
{
  var checked_val=[]; var ref_number_correspond='';var unchecked_val=[];
  $('.class_checkbox').each(function() {
   if ( $(this).is(':checked') )
   {
      if(checked_val=='')
        {
            checked_val=$(this).val();
        }
        else if(jQuery.inArray($(this).val(), checked_val) !== -1)
         {
            checked_val=$(this).val();
         }
         else
          {
            if($(this).val()!=checked_val)///maybe from the unchceked value
            {
              if( $('.tot_sales_amount_paid_'+$(this).val() ).val()=='0' )
              {
                 checked_val=$(this).val();
              }
            }
          }    
    }
 else{
   unchecked_val=$(this).val();  
    $('.confirm_btn_modal').show();
   if(jQuery.inArray($(this).val(), checked_val) == -1)
         {
            checked_val = $.grep(checked_val, function(value) {
              return value != unchecked_val;
            });
         }
    var picked_adjusted_amount= $('.tot_sales_amount_paid_'+unchecked_val).val();
 $('.tot_sales_amount_paid_'+unchecked_val).val('0');
 var amount_adjusted=$('.amount_adjusted').html();
 var to_adjust=$('.to_be_adjust').html();
 var newly_adjusted=parseFloat(amount_adjusted)-parseFloat(picked_adjusted_amount);
$('.amount_adjusted').html(newly_adjusted);
 var new_to_adjust=parseFloat(to_adjust)+parseFloat(picked_adjusted_amount);
$('.to_be_adjust').html(new_to_adjust);

 }
     });
    ref_number_correspond=$('.ref_doc_numbers_'+checked_val).val();
 return checked_val+'##'+ref_number_correspond;
}


function get_checked_count(ij)
{
    var amounts=0;
  if($('.inv_selected_'+ij).is(':checked'))
  {   
    amounts=parseFloat($('input[name="total_invs_edited"]').val())+parseFloat($('.tot_sales_amount_'+ij).val());
    $('input[name="total_invs_edited"]').val(amounts);
    //$('input[name="add_cash_customer"]').val('1');
//console.log('checked box');
//$('.cash_cusotmer_details').show();

  }
  else
  {
 var amounts=1;
   amounts=parseFloat($('input[name="total_invs_edited"]').val())-parseFloat($('.tot_sales_amount_'+ij).val());
    $('input[name="total_invs_edited"]').val(amounts);
  }
}


function submit_sales_inv_amount()
{
  var issue_text_data=$('.text_data_issue').html();
  var to_be_adjust= $('.to_be_adjust').html();
   var refrence_names='';
if(to_be_adjust=='0')
{

   $('.class_checkbox').each(function() {
   if ( $(this).is(':checked') )
   {
     var table_id_modal=$('table tbody tr td input[name="table_id_modal"]').val();

      var sales_inv_id=$('table tbody tr td input[name="inv_id_modal[]"]').map(function(){return $(this).val();}).get().join('|$$|'); 
    //  console.log(sales_inv_id);
       var sales_inv_amount=$('table tbody tr td input[name="sales_inv_amount_modal[]"]').map(function(){return $(this).val();}).get().join('|$$|'); 
      var amount_paid=$('table tbody tr td input[name="paid_amount_modal[]"]').map(function(){return $(this).val();}).get().join('|$$|'); 
      var sales_doc_num=$('table tbody tr td input[name="inv_doc_numbers_modal[]"]').map(function(){return $(this).val();}).get().join('|$$|'); 
  //    console.log(sales_doc_num);

       $('.si_doc_num_'+table_id_modal+'').val(sales_doc_num);
       $('.si_inv_id_'+table_id_modal+'').val(sales_inv_id);
       $('.si_amount_'+table_id_modal+'').val(sales_inv_amount);
       $('.si_amount_paid_'+table_id_modal+'').val(amount_paid);
      
       var amountss_4='0';
        $('input[name="paid_amount_modal[]"]').each(function(){
        amountss_4= parseFloat(amountss_4)+parseFloat($(this).val());
        }); 

    refrence_names=$('.ref_doc_numbers_'+$(this).val()).val(); 
  // $('.form_input_ref_'+table_id_modal).val(refrence_names+'|#|');
   $('.form_input_ref_'+table_id_modal).val($('.form_input_ref_'+table_id_modal).val() + refrence_names+'|#|');

//$('.form_input_amount_'+table_id_modal).val(parseFloat(amountss_4));
$('.form_input_amount_'+table_id_modal).attr('readonly');
$('.form_input_amount_'+table_id_modal).prop("readonly", true);
    // $('.confirm_btn_modal').hide();
      } 
    else{}  
    }); 
      $('.modal-close-btn').trigger('click');
    }
    else
    {
       // $('.modal-close-btn').trigger('click');

      alert('Error in paid amount');
    }
}

