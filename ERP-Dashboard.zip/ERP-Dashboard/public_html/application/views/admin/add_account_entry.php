<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>
<?php
if (!empty($this->session->userdata('bal_update'))) {
//	print_r($this->session->userdata['bal_update']['bank_name_updated']);
update_bank_bal();
	}

?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Account Entry Form</h2>
</header>
<div class="panel-body">
	<?php echo form_open('submit_account_entry',array('onsubmit' => 'return checkform();','class'=>'form-horizontal form-bordered myform')
	);?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

    <input type="hidden" name="submit_value" value="">

    <input type="hidden" name="acc_id" value="<?php  if(!empty($result[0]->ae_id)) echo $result[0]->ae_id;?>">
<input type="hidden" name="status_data_entered" value="<?php  if(!empty($result[0]->ae_status_data)) echo $result[0]->ae_status_data;?>">
    <input type="hidden" name="page_type" value="<?php  if(!empty($page_type)) echo $page_type;?>">

<input type="hidden" name="bank" >


<div class="row">
	<div class="col-md-12 table-rows-border">
		<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Date <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<?php
if(!empty($result[0]->ae_date))
{
$convert=explode('-',$result[0]->ae_date);
$new_date= $convert[1].'/'.$convert[2].'/'.$convert[0];
// echo $result[0]->ae_date;
}
if(!empty($result[0]->ae_time))
{
$convert=date("g:i A", strtotime($result[0]->ae_time));
//echo $convert;
}
;?>
 <input type='text' name="date" class="form-control" id='datetimepicker4' value="<?php  if(!empty($new_date)) echo $new_date.' '.$convert;?>" required />

<!--  <input type="text" class="form-control" data-plugin-datepicker="" name="date" value="<?php  if(!empty($new_date)) echo $new_date;?>" required> 
 <div class="form_error">  <?php echo $this->session->flashdata('date');?></div>-->
</div> 
</div>

</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Add Description<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<textarea class="form-control" placeholder="Add Description" required="" id="main_desc" name="desc" rows="5"><?php  if(!empty($result[0]->ae_desc)) echo $result[0]->ae_desc;?></textarea>
<div class="form_error">  <?php echo $this->session->flashdata('desc');?></div>
</div>
</div>
	
</div>

</div>
</div>



<div class="row">
	<div class="col-md-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputDefault">Choose Category<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control mb-md cat" name="cat" required="" onchange="if (this.value=='Others'){this.form['others_cat'].style.visibility='visible'}else {this.form['others_cat'].style.visibility='hidden'};">
		<option value=""></option>
		<option value="Shipping" <?php if(!empty($result[0]->ae_cat)){ if($result[0]->ae_cat=='Shipping'){echo "selected";}} ?>>Shipping</option>
		<option value="Sales" <?php if(!empty($result[0]->ae_cat)){ if($result[0]->ae_cat=='Sales'){echo "selected";}} ?>>Sales</option>
		<option value="General Expenses" <?php if(!empty($result[0]->ae_cat)){ if($result[0]->ae_cat=='General Expenses'){echo "selected";}} ?>>General Expenses</option>
		<option value="Salaries" <?php if(!empty($result[0]->ae_cat)){ if($result[0]->ae_cat=='Salaries'){echo "selected";}} ?>>Salaries</option>
		<option value="Raw Material Purchases" <?php if(!empty($result[0]->ae_cat)){ if($result[0]->ae_cat=='Raw Material Purchases'){echo "selected";}} ?>>Raw Material Purchases</option>
		<option value="Import Purchases" <?php if(!empty($result[0]->ae_cat)){ if($result[0]->ae_cat=='Import Purchases'){echo "selected";}} ?>>Import Purchases</option>
		<option value="Personal Accounts" <?php if(!empty($result[0]->ae_cat)){ if($result[0]->ae_cat=='Personal Accounts'){echo "selected";}} ?>>Personal Accounts</option>
		<option value="Rent" <?php if(!empty($result[0]->ae_cat)){ if($result[0]->ae_cat=='Rent'){echo "selected";}} ?>>Rent</option>
		<option value="Others" <?php if(!empty($result[0]->ae_cat)){ if($result[0]->ae_cat=='Others'){echo "selected";}} ?>>Others</option>
		
	</select>
<div class="form_error">  <?php echo $this->session->flashdata('cat');?></div>
</div>
 </div>

</div>
<div class="col-md-6">

 <div class="form-group" id="cat_desc" >
 <!-- <label class="col-md-4 control-label" for="inputDefault">Enter Other Description</label>	 -->
  <div class="col-md-4"></div>
 <div class="col-md-8">
	<textarea class="form-control" style="visibility: hidden;" placeholder="Enter Other Description(if any)" name="others_cat" id="others_cat" rows="5"><?php  if(!empty($result[0]->ae_cat_desc)) echo $result[0]->ae_cat_desc;?></textarea>
	<div class="form_error">  <?php echo $this->session->flashdata('others_cat');?></div>
</div>
 </div>

</div>
</div>
</div>

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">

 <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Status<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control mb-md sts" name="status" required="" onchange="if (this.value=='Others'){this.form['others_status'].style.visibility='visible'}else {this.form['others_status'].style.visibility='hidden'};">
		<option value=""></option>
		<option value="Cash Deposit" <?php if(!empty($result[0]->ae_sts)){ if($result[0]->ae_sts=='Cash Deposit'){echo "selected";}} ?>>Cash Deposit</option>
		<option value="Cash" <?php if(!empty($result[0]->ae_sts)){ if($result[0]->ae_sts=='Cash'){echo "selected";}} ?>>Cash</option>
		<option value="PDC" <?php if(!empty($result[0]->ae_sts)){ if($result[0]->ae_sts=='PDC'){echo "selected";}} ?>>PDC</option>
		<option value="Bank Transfer" <?php if(!empty($result[0]->ae_sts)){ if($result[0]->ae_sts=='Bank Transfer'){echo "selected";}} ?>>Bank Transfer</option>
		<option value="Expected" <?php if(!empty($result[0]->ae_sts)){ if($result[0]->ae_sts=='Expected'){echo "selected";}} ?>>Expected</option>
		<option value="Others" <?php if(!empty($result[0]->ae_sts)){ if($result[0]->ae_sts=='Others'){echo "selected";}} ?>>Others</option>
		
	</select>
	<div class="form_error">  <?php echo $this->session->flashdata('status');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">

 <div class="form-group">
 	 <label class="col-md-4 control-label" for="inputDefault"></label>
 <div class="col-md-8">
	<textarea class="form-control" id="others_status" placeholder="Enter Other Description(if any)" name="others_status" style="visibility: hidden;" rows="5"><?php  if(!empty($result[0]->ae_sts_desc)) echo $result[0]->ae_sts_desc;?></textarea>
	<div class="form_error">  <?php echo $this->session->flashdata('others_status');?></div>
</div>
 </div>

</div>
</div>
</div>

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Bank<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control mb-md bank" required="" name="bank" onchange="if (this.value=='Other Bank'){this.form['other_bank'].style.visibility='visible'}else {this.form['other_bank'].style.visibility='hidden'};">
		<option value=""></option>
<option value="ADIB-BBMS" <?php if(!empty($result[0]->ae_bank)){ if($result[0]->ae_bank=='ADIB-BBMS'){echo "selected";}} ?>>ADIB-BBMS</option>
<option value="ADIB-Factory" <?php if(!empty($result[0]->ae_bank)){ if($result[0]->ae_bank=='ADIB-Factory'){echo "selected";}} ?>>ADIB-Factory</option>
<option value="ENBD" <?php if(!empty($result[0]->ae_bank)){ if($result[0]->ae_bank=='ENBD'){echo "selected";}} ?>>ENBD</option>
<option value="Cash Garhoud" <?php if(!empty($result[0]->ae_bank)){ if($result[0]->ae_bank=='Cash Garhoud'){echo "selected";}} ?>>Cash Garhoud</option>
<option value="EI Bank" <?php if(!empty($result[0]->ae_bank)){ if($result[0]->ae_bank=='EI Bank'){echo "selected";}} ?>>EI Bank</option>
<option value="Cash Mr. Bachir Book" <?php if(!empty($result[0]->ae_bank)){ if($result[0]->ae_bank=='Cash Mr. Bachir Book'){echo "selected";}} ?>>Cash Mr. Bachir Book</option>

<option value="Cash Factory" <?php if(!empty($result[0]->ae_bank)){ if($result[0]->ae_bank=='Cash Factory'){echo "selected";}} ?>>Cash Factory</option>

<option value="Other Bank" <?php if(!empty($result[0]->ae_bank)){ if($result[0]->ae_bank=='Other Bank'){echo "selected";}} ?>>Other Bank</option>
</select>
<div class="form_error">  <?php echo $this->session->flashdata('bank');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">

 <div class="form-group">
 	 <label class="col-md-4 control-label" for="inputDefault"></label>
 <div class="col-md-8">
	<textarea class="form-control" id="other_bank" placeholder="Enter Other Bank Details(if any)" name="other_bank" style="visibility: hidden;" rows="5"><?php  if(!empty($result[0]->ae_bank_desc)) echo $result[0]->ae_bank_desc;?></textarea>
	<div class="form_error">  <?php echo $this->session->flashdata('other_bank');?></div>
</div>
 </div>

</div>
</div>
</div>

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Enter Amount<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" class="form-control acc_amount" required="" name="amount" value="<?php  if(!empty($result[0]->ae_amount)) echo $result[0]->ae_amount;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('amount');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Cash type<abbr class="required">::*::</abbr></label>

<div class="col-md-8">
<label class="radio-inline">
<input type="radio" value="Received" required="" name="cash_type" <?php if(!empty($result[0]->ae_cash_type)){if($result[0]->ae_cash_type=='Received'){echo "checked";} }?>> We Received
</label>
<label class="checkbox-inline">
<input type="radio" value="Spend" required="" name="cash_type" <?php if(!empty($result[0]->ae_cash_type)){if($result[0]->ae_cash_type=='Spend'){echo "checked";} }?>> We Spend
</label>
<div class="form_error">  <?php echo $this->session->flashdata('cash_type');?></div>
</div>

</div>

</div>
</div>
</div>





<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary" type="submit">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>


<?php echo form_close();?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>


<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>


<script type="text/javascript">

	$(document).ready(function()
	{
		cat_val=$('.cat').val();
		if(cat_val=="Others")
		{
			$("#others_cat").attr("style", "visibility: visible")
		}
		else
		{
			$("#others_cat").attr("style", "visibility: hidden")
		}
		sts_val=$('.sts').val();
		if(sts_val=="Others")
		{
			$("#others_status").attr("style", "visibility: visible")
		}
		else
		{
			$("#others_status").attr("style", "visibility: hidden")
		}
		bank_val=$('.bank').val();
		if(bank_val=="Other Bank")
		{
			$("#other_bank").attr("style", "visibility: visible")
		}
		else
		{
			$("#other_bank").attr("style", "visibility: hidden")
		}

		var cash_type = $("input[name='cash_type']:checked").val();
		if(cash_type=="Received")
			{
				$('.acc_amount').css({'color': 'white', 'background-color': 'green'});
			}
			if(cash_type=="Spend")
			{
				$('.acc_amount').css({'color': 'white', 'background-color': 'red'});
			}	
		

		$('input:radio').change(function() {
			var cash_type = $("input[name='cash_type']:checked").val();
			if(cash_type=="Received")
			{
				$('.acc_amount').css({'color': 'white', 'background-color': 'green'});
			}
			if(cash_type=="Spend")
			{
				$('.acc_amount').css({'color': 'white', 'background-color': 'red'});
			}	

    		
  		});

  		$(function(){
	    var select_val = $('select[name=bank]').val();
	    if(select_val!='')
	    {
	    $("select[name=bank]").attr("disabled", "disabled");
	    $("input[name=bank]").val(select_val);
	    }	   
	});

 		
	});///end of doc.ready()


	var secondCall = false;
function checkform(){
    if (secondCall) {
        return;
    }
    var date=$("input[name='date']").val();

   jQuery.ajax({
	            url:"<?php echo base_url().'Admin_biri/before_submit';?>",
	            type:"post",
	            data:{"date_selected":date},
	            success:function(result)
	            {
	           $("input[name='submit_value']").val(result);
	           if(result==1)
			    	{
						new PNotify({
								title: 'Error',
								text: 'Date not allowed. This date is reconciled.',
								type: 'error'
							});
					}
			    	else
			    	{
			    		secondCall = true;
			    		new PNotify({
								title: 'Submitting..!',
								text: 'Please wait the form is submitting....!',
								type: 'success'
							});
			    		$('.myform').submit();
					}          	
	            }
		    });
    return false;
}
	
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('#datetimepicker4').datetimepicker();
            });
        </script>

</html>