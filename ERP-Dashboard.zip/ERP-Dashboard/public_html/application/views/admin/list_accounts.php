<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>
<?php
if (!empty($this->session->userdata('bal_update'))) {
//	print_r($this->session->userdata['bal_update']['bank_name_updated']);
update_bank_bal();
	}

?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Account Entries</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Account Entries</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>
<?php
	$url=$this->uri->segment(1);
	echo "<input type='hidden' name='url_segment' value='".$url."'>";
?>
<div class="row">
<div class="col-md-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Sort Table</h2>
</header>
<?php 
echo form_open('submit_lstacc_sorting');?>

<div class="panel-body">
<div class="row">
	<div class="col-sm-6">
	<div class="form-group">
	<label class="control-label">Cash type</label><br/>
		<label class="radio-inline">
		<input type="radio" value="Received" name="cash_type" <?php if(!empty($selection_val['cash_type'])){if($selection_val['cash_type']=='Received'){echo "checked";} }?> > We Received
		</label>
		<label class="checkbox-inline">
		<input type="radio" value="Spend" name="cash_type" <?php if(!empty($selection_val['cash_type'])){if($selection_val['cash_type']=='Spend'){echo "checked";} }?> > We Spend
		</label>
		<div class="form_error">  <?php echo $this->session->flashdata('cash_type');?></div>
	</div>
	</div>
	<div class="col-sm-6">
	<div class="form-group">
	<label class="control-label" for="inputPlaceholder">Choose Bank</label><br/>
	<select class="form-control mb-md bank" name="bank_name">
		<option value="">Choose</option>
		<option value="ADIB-BBMS" <?php if(!empty($selection_val['bank_name'])){ if($selection_val['bank_name']=='ADIB-BBMS'){echo "selected";}} ?>>ADIB-BBMS</option>

		<option value="ADIB-Factory" <?php if(!empty($selection_val['bank_name'])){ if($selection_val['bank_name']=='ADIB-Factory'){echo "selected";}} ?>>ADIB-Factory</option>

		<option value="ENBD" <?php if(!empty($selection_val['bank_name'])){ if($selection_val['bank_name']=='ENBD'){echo "selected";}} ?>>ENBD</option>

		<option value="Cash Garhoud" <?php if(!empty($selection_val['bank_name'])){ if($selection_val['bank_name']=='Cash Garhoud'){echo "selected";}} ?>>Cash Garhoud</option>

		<option value="EI Bank" <?php if(!empty($selection_val['bank_name'])){ if($selection_val['bank_name']=='ENBD'){echo "selected";}} ?>>EI Bank</option>

		<option value="Cash Mr. Bachir Book" <?php if(!empty($selection_val['bank_name'])){ if($selection_val['bank_name']=='Cash Mr. Bachir Book'){echo "selected";}} ?>>Cash Mr. Bachir Book</option>

		<option value="Cash Factory" <?php if(!empty($selection_val['bank_name'])){ if($selection_val['bank_name']=='Cash Factory'){echo "selected";}} ?>>Cash Factory</option>

		<option value="Other Bank" <?php if(!empty($selection_val['bank_name'])){ if($selection_val['bank_name']=='Other Bank'){echo "selected";}} ?>>Other Bank</option>
	</select>
<div class="form_error"><?php echo $this->session->flashdata('bank');?></div>

	</div>
	</div>
</div>

<div class="row">
	<div class="col-sm-6">
	<div class="form-group">
	<label class="control-label" for="inputPlaceholder">Choose Month</label><br/>
		<select class="form-control mb-md bank month_name" name="month_selected" >
			<option value="">Choose</option>
			<option value="01" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='01'){echo "selected";}} ?>>Jan</option>

			<option value="02" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='02'){echo "selected";}} ?>>Feb</option>

			<option value="03" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='03'){echo "selected";}} ?>>Mar</option>

			<option value="04" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='04'){echo "selected";}} ?>>Apr</option>

			<option value="05" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='05'){echo "selected";}} ?>>May</option>

			<option value="06" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='06'){echo "selected";}} ?>>Jun</option>

			<option value="07" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='07'){echo "selected";}} ?>>Jul</option>

			<option value="08" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='08'){echo "selected";}} ?>>Aug</option>

			<option value="09" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='09'){echo "selected";}} ?>>Sep</option>

			<option value="10" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='10'){echo "selected";}} ?>>Oct</option>

			<option value="11" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='11'){echo "selected";}} ?>>Nov</option>

			<option value="12" <?php if(!empty($selection_val['month'])){ if($selection_val['month']=='12'){echo "selected";}} ?>>Dec</option>
		</select>
	<div class="form_error">  <?php echo $this->session->flashdata('bank');?></div>
	
	</div>
	</div>
	<input value="<?php if(!empty($selection_val['year'])){ echo $selection_val['year'];}?>" type="hidden" name="selecte_year">
	<div class="col-sm-6">
	<div class="form-group">
	<label class="control-label" for="inputPlaceholder">Choose Year</label><br/>
		<select id="year" name="year_selected" class="form-control year_selected">
		
		</select>
		<div class="form_error">  <?php echo $this->session->flashdata('bank');?></div>
	</div>
	</div>
</div>

<div class="row">
<div class="col-sm-6">
	<div class="form-group">
	<label class="control-label" for="inputPlaceholder">Date Range</label><br/>
<div class="input-daterange input-group" data-plugin-datepicker="">
			    <span class="input-group-addon">
			    <i class="fa fa-calendar"></i>
			    </span>
			    <input type="text" class="form-control" name="start_date_rng" value="<?php  if(!empty($selection_val['start_date'])) echo $selection_val['start_date'];?>">
			    <span class="input-group-addon">to</span>
			    <input type="text" class="form-control" name="end_date_rng" value="<?php  if(!empty($selection_val['end_date'])) echo $selection_val['end_date'];?>">
			</div>
	</div>
</div>
<div class="col-sm-6">
	<div class="form-group">
	<label class="control-label" for="inputPlaceholder">Data Entry(this will work as an independent module only)</label><br/>
		<input type="text" data-plugin-datepicker="" class="form-control" name="date_entred" value="<?php  if(!empty($selection_val['entry_date'])) echo $selection_val['entry_date'];?>">

		<div class="form_error">  <?php echo $this->session->flashdata('bank');?></div>
	</div>
	</div>

</div>
<!-- onclick="type_bank();" -->
</div>
<footer class="panel-footer">
<button class="btn btn-primary">Submit</button>
</footer>
<?php
echo form_close();?>
</section>
</div>
</div>



<div class="row">
<div class="col-md-12">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Account Entries</h2>
</header>
<div class="panel-body">	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<table class="table table-bordered table-striped mb-none" id="datatable-default2">
				<thead>
<tr>
	<th></th>
<th>Category</th>
<th>Status</th>
<th>Bank</th>
<th>Date </th>
<th>Current Status</th> 
<th>Amount</th>
<th>Cash Mode </th>
<th>Description</th>
<th>Action</th>
</tr>
</thead>
<tbody>
	<?php
	$i=1;
	if(!empty($result))
	{
		foreach($result as $t)
			{?>
	<tr <?php if($t->ae_reconcile=='1'){echo'style="pointer-events:none;"';}?>>
		<td><?php echo $i++;?></td>
		<td><?php echo $t->ae_cat;?></td>
		<td><?php echo $t->ae_sts;?></td>
		<td><?php echo $t->ae_bank;?></td>
		<td><?php echo $t->ae_date;?></td>
		<td class="status_entry_<?php echo $t->ae_id;?>">
			<?php
		if($t->ae_status_data=="2")
		{
		print('<span class="pull-right label label-success">Success</span>');
		}
		else
		{
		print('<span class="pull-left label label-warning">Pending</span>');
			if(($this ->session->userdata['user']['role'])=="1")
			{
				print('<button type="button" class="mb-xs mt-xs mr-xs btn btn-xs btn-primary" onclick="change_status('.$t->ae_id.')">Approve Now</button>');
			}
		}?>
		</td> 
		<td><?php echo $t->ae_amount;?></td>
		<td><?php echo $t->ae_cash_type;?></td>
		<td><?php echo word_limiter($t->ae_desc,100);?></td>
		<td>

			<a class="mb-xs mt-xs mr-xs modal-sizes btn btn-default" href="#modalLG<?php echo $t->ae_id;?>"><i class="fa fa-eye"></i></a>

			<?php
		if(($this ->session->userdata['user']['role'])=="1")
		{
				print('&nbsp; &nbsp;<a href="edit_account_entry/'.$t->ae_id.'/manager_edit"><i class="fa fa-pencil"></i></a>');
		}
	else
	{
		if($t->ae_status_data!="2" )
		{
			print('&nbsp; &nbsp;<a href="edit_account_entry/'.$t->ae_id.'"><i class="fa fa-pencil"></i></a>');
		}
	}
			?>

			<a href="delete_account_entry/<?php echo $t->ae_id;?>" class="delete-row"><i class="fa fa-trash-o"></i></a>
		</td>
	</tr>

	<div id="modalLG<?php echo $t->ae_id;?>" class="modal-block modal-block-lg mfp-hide" >

			<section class="panel">
			<header class="panel-heading">
			<h2 class="panel-title">Details of Account Entry with id : <?php echo $t->ae_id;?></h2>
			</header>
			<div class="panel-body modal-body">
			<div class="modal-wrapper">
			<div class="modal-text">

			<p><b>Account Entry: </b><?php echo $t->ae_id;?></p>
			<p><b>Category : </b><?php echo $t->ae_cat;?></p>
			<p><b>Details of "Others" in Category : </b><?php echo $t->ae_cat_desc;?></p>

			<p><b>Status : </b><?php echo $t->ae_sts;?></p>
			<p><b>Details of "Others" in Status : </b><?php echo $t->ae_sts_desc;?></p>

			<p><b>Bank : </b> <?php echo $t->ae_bank;?></p>
			<p><b>Details of "Others" in Bank : </b><?php echo $t->ae_bank_desc;?></p>

			<p><b>Amount : </b> <?php echo $t->ae_amount;?></p>
			<p><b>Cash Type : </b> <?php echo $t->ae_cash_type;?></p>

			<p><b>Current entry status :</b> 
			<span style="text-align:left;"> 
		<?php
		if($t->ae_status_data=="2")
		{
		print('<span class="label label-success">Success</span>');
		}
		else
		{
		print('<span class="label label-warning">Pending</span>');
		}?>
		</span>
			</p>

			<p><b>Date : </b> <?php echo $t->ae_date;?></p>

			<p><b>Description : </b><?php echo $t->ae_desc;?></p>

			</div>
			</div>
			<button class="btn btn-default modal-dismiss" id="closemodal">Close</button>
			</div>
			
			</section>
</div>  
	<?php
}
}?>
</tbody>
</table>	

</div>
</section>
</div>
</div>


</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
$(document).ready(function()
	{
	
	  		var currentYear = new Date().getFullYear()
		    var option = "";
		    for (var year = currentYear-20 ; year <= currentYear; year++) 
		    {
      
	        var option = document.createElement("option");
	        option.text = year;
	        option.value = year;
        
	        document.getElementById("year").appendChild(option)
	      }
	      
	      var year_selected=$('input[name=selecte_year]').val();
	      if(year_selected!='')
		    document.getElementById("year").value = year_selected;
		    else
		      document.getElementById("year").value = currentYear;

		     $('#datatable-default2').DataTable( {
			              rowReorder: {
			            selector: 'td:nth-child(2)'
			        },
			        "pageLength": 50,
			    responsive: true,
			     "scrollX": true,
			} );

	});

function change_status(id)
		{
			 jQuery.ajax({
		            url:"<?php echo base_url().'Admin_biri/approve_entry';?>",
		            type:"post",
		            data:{"table_id":id},
		            success:function(result)
		            {
		            	if(result=='1')
		            	{
		            		new PNotify({
									title: 'Success',
									text: 'Status Changed successfully',
									type: 'success'
								});

		            		$('.status_entry_'+id).html(
		            			'<span class="label label-success">Success</span>'
		            			);
		            	}

		            }
		            });

		} 

     
</script>

</body>
</html>