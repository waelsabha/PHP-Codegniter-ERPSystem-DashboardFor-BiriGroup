<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
.countrypicker{
	max-height:100px;
}
.fa-whatsapp  {
  color:#fff;
  background:
  linear-gradient(#25d366,#25d366)10px 84%/15px 15px no-repeat,
  radial-gradient(#25d366 59%,transparent 0);
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Customer Entry Form</h2>
</header>
<div class="panel-body">
	<?php echo form_open_multipart('submit_user_mng','class="form-horizontal form-bordered"');?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

    <input type="hidden" name="user_id" value="<?php if(!empty($result[0]->log_id)){echo $result[0]->log_id;};?>">
    
  <input type="hidden" name="sub_type_val" value="<?php if(!empty($result[0]->log_sub_type)){echo $result[0]->log_sub_type;};?> ">
  
   <input type="hidden" class="country_val_selected" name="country_val" value="">

<div class="row">
	<div class="col-md-12 table-rows-border">
		<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">User Name<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type='text' name="user_name" class="form-control"  value="<?php if(!empty($result[0]->log_uname)){echo $result[0]->log_uname;};?>" required />
<div class="form_error">  <?php echo $this->session->flashdata('user_name');?></div>
</div>
</div>
	
</div>
		<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Department<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <select class="form-control mb-md bank" name="dept" >
		<option value="">Choose</option>
		<option value="Main" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="Main"){echo "selected";}}?>>Manager</option>
		<option value="Accounts" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="Accounts"){echo "selected";}}?>>Accounts</option>
		<option value="Sales" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="Sales"){echo "selected";}}?>>UAE-Sales</option>
		<option value="HR" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="HR"){echo "selected";}}?>>HR</option>
		<option value="ksa-Sales" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="ksa-Sales"){echo "selected";}}?>>KSA-Sales</option>
		<option value="Marketing" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="Marketing"){echo "selected";}}?>>Marketing</option>
		<option value="Main factory" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="Main factory"){echo "selected";}}?>>Main factory</option>
		<option value="Traffic Sign" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="Traffic Sign"){echo "selected";}}?>>Traffic Safety-Advertisement</option>
		<option value="Purchase" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="Purchase"){echo "selected";}}?>>Purchase</option>
		<option value="Factory Staff" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="Factory Staff"){echo "selected";}}?>>Factory Staff</option>
		<option value="Project Department" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="Project Department"){echo "selected";}}?>>Project Department</option>
	</select>
	<option value="KSA Sales" <?php if(!empty($result[0]->log_dept)){ if($result[0]->log_dept=="KSA Sales"){echo "selected";}}?>>KSA Sales</option>

<div class="choose_sales_type" >
		<div class="form-group">
	
			<label class="col-md-4 control-label" for="inputPlaceholder">
			Choose Sales Type:
			</label>
		<div class="col-md-8">
			<label class="checkbox-inline">
			<input type="radio" name="sale_type" value="gcc" <?php if(!empty($result[0]->log_sub_type)){ if($result[0]->log_sub_type=="gcc"){echo "checked";}}?>> GCC Sales
			</label>
			<label class="checkbox-inline">
			<input type="radio" name="sale_type" value="african"  <?php if(!empty($result[0]->log_sub_type)){ if($result[0]->log_sub_type=="african"){echo "checked";}}?> > African Sales
			</label>
		</div>
		</div>
	</div>
		
<div class="form_error">  <?php echo $this->session->flashdata('dept');?></div>
</div> 
</div>

</div>


</div>

<div class="col-md-12 table-rows-border">
		<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Email<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type='email' name="email" class="form-control" value="<?php if(!empty($result[0]->log_email)){echo $result[0]->log_email;};?>" required />
<div class="form_error">  <?php echo $this->session->flashdata('email');?></div>
</div>
</div>
	
</div>
		<!-- <div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Confirm Email<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type='password' name="confrm_pwd" class="form-control" value="" required />
 <div class="form_error">  <?php echo $this->session->flashdata('confrm_pwd');?></div>
</div> 
</div>

</div> -->


</div>
<?php
 if(empty($result[0]->log_pwd))
 	{?>
<div class="col-md-12 table-rows-border">
		<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Password<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type='password' name="pwd" class="form-control" value="" required />
<div class="form_error">  <?php echo $this->session->flashdata('pwd');?></div>
</div>
</div>
	
</div>
		<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Confirm Password<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type='password' name="confrm_pwd" class="form-control" value="" required />
 <div class="form_error">  <?php echo $this->session->flashdata('confrm_pwd');?></div>
</div> 
</div>

</div>


</div>
<?php
}
?>

<div class="col-md-12 table-rows-border">
		<?php
		if(!empty($result[0]->log_page))
		{
			$cust_interest=explode(',',$result[0]->log_page);
		}
		else{
			$cust_interest="";
		}
		?>
<div class="form-group">
<label class="col-md-3 control-label" for="inputSuccess">Choose what options they can view<abbr class="required">::*::</abbr></label>
		<div class="col-md-6">
		<div class="checkbox">
		<label>
		<input type="checkbox" name="view_options[]" value="add_account_entry" <?php if(!empty($cust_interest)){ if(in_array("add_account_entry",$cust_interest)){echo "checked";}}?>>Add accounts entry
		</label>
		</div>
		<div class="checkbox">
		<label>
		<input type="checkbox" name="view_options[]" value="list_account_entry" <?php if(!empty($cust_interest)){ if(in_array("list_account_entry",$cust_interest)){echo "checked";}}?>>
		List Account Entries
		</label>
		</div>
		<div class="checkbox">
		<label>
		<input type="checkbox" name="view_options[]" value="acc_excel_upload" <?php if(!empty($cust_interest)){ if(in_array("acc_excel_upload",$cust_interest)){echo "checked";}}?>>
		Upload Excel
		</label>
		</div>
		<div class="checkbox">
		<label>
		<input type="checkbox" name="view_options[]" value="tx_funds" <?php if(!empty($cust_interest)){ if(in_array("tx_funds",$cust_interest)){echo "checked";}}?>>
		Transfer Funds
		</label>
		</div>
		<div class="checkbox">
		<label>
		<input type="checkbox" name="view_options[]" value="list_txs" <?php if(!empty($cust_interest)){ if(in_array("list_txs",$cust_interest)){echo "checked";}}?>>
		List Transfers
		</label>
		</div>
		<div class="checkbox">
		<label>
		<input type="checkbox" name="view_options[]" value="add-customer-details" <?php if(!empty($cust_interest)){ if(in_array("add-customer-details",$cust_interest)){echo "checked";}}?>>
		Add Customer Details
		</label>
		</div>
		<div class="checkbox">
		<label>
		<input type="checkbox" name="view_options[]" value="list-customer-details" <?php if(!empty($cust_interest)){ if(in_array("list-customer-details",$cust_interest)){echo "checked";}}?>>
		List Customer Deatils
		</label>
		</div>
		<div class="checkbox">
		<label>
		<input type="checkbox" name="view_options[]" value="customer-excel-upload" <?php if(!empty($cust_interest)){ if(in_array("customer-excel-upload",$cust_interest)){echo "checked";}}?>>
		 Customer Excel Deatils Upload
		</label>
		</div>
		<div class="checkbox">
		<label>
	<input type="checkbox" name="view_options[]" value="add-users" <?php if(!empty($cust_interest)){ if(in_array("add-users",$cust_interest)){echo "checked";}}?>>
		Add Users
		</label>
		</div>
		<div class="checkbox">
		<label>
	<input type="checkbox" name="view_options[]" value="list-users" <?php if(!empty($cust_interest)){ if(in_array("list-users",$cust_interest)){echo "checked";}}?>>
		List Users
		</label>
		</div>
	<div class="checkbox">
		<label>
	<input type="checkbox" name="view_options[]" value="add-files" <?php if(!empty($cust_interest)){ if(in_array("add-files",$cust_interest)){echo "checked";}}?>>
		File manager
		</label>
		</div>
		<div class="checkbox">
		<label>
	<input type="checkbox" name="view_options[]" value="sales-book-dashboard" <?php if(!empty($cust_interest)){ if(in_array("sales-book-dashboard",$cust_interest)){echo "checked";}}?>>
		Sales Book
		</label>
		</div>
	<div class="checkbox">
		<label>
	<input type="checkbox" name="view_options[]" value="sales-book" <?php if(!empty($cust_interest)){ if(in_array("sales-book",$cust_interest)){echo "checked";}}?>>
		Sales Book Excel upload
		</label>
		</div>	
	<div class="checkbox">
		<label>
	<input type="checkbox" name="view_options[]" value="product-order" <?php if(!empty($cust_interest)){ if(in_array("product-order",$cust_interest)){echo "checked";}}?>>
		Production Order
		</label>
		</div>	
	<div class="checkbox">
		<label>
	<input type="checkbox" name="view_options[]" value="prd-order-list" <?php if(!empty($cust_interest)){ if(in_array("prd-order-list",$cust_interest)){echo "checked";}}?>>
		List Production Order
		</label>
		</div>	
	<div class="checkbox">
		<label>
	<input type="checkbox" name="view_options[]" value="prd-order-sts" <?php if(!empty($cust_interest)){ if(in_array("prd-order-sts",$cust_interest)){echo "checked";}}?>>
		Check production status
		</label>
		</div>					


		</div>
		<div class="col-md-3">
        

		<div class="checkbox">
		<label>
	     <input type="checkbox" name="view_options[]" value="edit-permission" <?php if(!empty($cust_interest)){ if(in_array("edit-permission",$cust_interest)){echo "checked";}}?>>
		 All Edit Permission
		 </label>
		</div>
		<div class="checkbox">
		<label>
	<input type="checkbox" name="view_options[]" value="delete-permission" <?php if(!empty($cust_interest)){ if(in_array("delete-permission",$cust_interest)){echo "checked";}}?>>
		All Delete Permission
		</label>
		</div>
		</div>

<div class="form_error">  <?php echo $this->session->flashdata('view_options');?></div>	
</div>
	


</div>
</div>


<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>


<?php echo form_close();?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
	$(document).ready(function()
	{
	$('.choose_sales_type').hide();
	var edit_sub_type = $("input[name='sub_type_val']").val();
	
	if(edit_sub_type!=null)
	{
		$('.choose_sales_type').show();
	}
	else
	{
		$('.choose_sales_type').hide();
	}
	$('select[name="dept"]').on('change', function(){
		if($(this).val()=="Sales")
		{
			$('.choose_sales_type').show();
			$("input[name='sale_type']").prop('required',true);
		}
		else
		{
			$('.choose_sales_type').hide();
			$("input[name='sale_type']").prop('required',false);
		}
			});
	});
</script>



</html>