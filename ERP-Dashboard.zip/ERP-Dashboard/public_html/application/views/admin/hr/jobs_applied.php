<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Candidate details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Candidate details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Table Data <small style="color:red">Please note, for viewing an .flv or .webm video file, you need a supporting player like GOM player</small></h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-bordered table-striped mb-none" id="datatable-default">
<thead>
<tr>
	<th style="width: 10%;"></th>
<th>Date applied</th>
<th>Position </th>	
<th>Photo</th>
<th>Candidate Name</th>
<th>Email</th>
<th>Mobile No:</th>
<th>Resume</th>
<th>Video</th>
<th>Current Status</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($result))
{
foreach($result as $t)
{
	$app_sts_val='';
	switch ($t->j_app_sts) {
		case 1:
		$app_sts_val='New/pending';
			break;
		case 2:
		$app_sts_val='Under Review';
			break;
		case 3:
		$app_sts_val='Selected';
			break;
		case 4:
		$app_sts_val='Contacted';
			break;
		case 5:
		$app_sts_val='Shortlisted for interview';
		break;	
		case 6:
		$app_sts_val='Rejected';
		break;						
		default:
			$app_sts_val='';
			break;
	}
?>	
<tr class="gradeX">
			<td><?php echo $i++;?></td>
			<td><?php echo $t->j_date;?></td>
			<td><?php echo $t->j_applied;?></td>
			<td><img src="https://birigroup.com/uploads/photo/<?php echo $t->j_photo;?>" width="100" height="100"></td>
			<td><?php echo $t->j_candidate;?></td>
			<td><?php echo $t->j_email;?></td>
			<td><?php echo $t->j_mob;?></td>
			<td><a href="https://birigroup.com/uploads/resume/<?php echo $t->j_resume;?>" target="_blank"><?php echo $t->j_resume;?></a></td>
			<td><a href="https://birigroup.com/uploads/video/<?php echo $t->j_video;?>" target="_blank"><?php echo $t->j_video;?></a></td>
			<td><?php echo $app_sts_val;?>
				<br/>
				<a href="#modalSM<?php echo $t->jid;?>" class="mb-xs mt-xs mr-xs modal-sizes btn btn-default">Click to change status<i class="fa fa-pencil"></i></a>
			</td>
		<td>

	<a href="#modalLG<?php echo $t->jid;?>" class="mb-xs mt-xs mr-xs modal-sizes btn btn-default"><i class="fa fa-eye"></i></a>
				&nbsp; &nbsp;
		

<a href="delete_job_details/<?php echo $t->jid;?>" class="delete-row"><i class="fa fa-trash-o"></i></a>
	
			</td>
	</tr>
<!-------modal to edit--------->
  <div id="modalSM<?php echo $t->jid;?>" class="modal-block modal-block-md mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Change Status</h2>
</header>
<div class="panel-body">
  <?php echo form_open('edit_status_job_application','class="myform" ');?>
  
    <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>


<input type="hidden" name="job_id" value="<?php if(!empty($t->jid)){echo $t->jid;};?>">

<div class="row">

  <div class="col-md-12 col-sm-12 table-rows-border">
 

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Change Status<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
	
 <select class="form-control" name="job_sts_curnt" 
 required="">
 	<option value="">Choose</option>
 	<option value="1" <?php if(!empty($t->j_app_sts)){if($t->j_app_sts=='1'){echo "selected";}} ;?>>New/pending</option>
 	<option value="2" <?php if(!empty($t->j_app_sts)){if($t->j_app_sts=='2'){echo "selected";}} ;?>>Under Review</option>
 	<option value="3" <?php if(!empty($t->j_app_sts)){if($t->j_app_sts=='3'){echo "selected";}} ;?>>Selected</option>
 	<option value="4" <?php if(!empty($t->j_app_sts)){if($t->j_app_sts=='4'){echo "selected";}} ;?>>Contacted</option>
 	<option value="5" <?php if(!empty($t->j_app_sts)){if($t->j_app_sts=='5'){echo "selected";}} ;?>>Shortlisted for interview</option>
 	<option value="6" <?php if(!empty($t->j_app_sts)){if($t->j_app_sts=='6'){echo "selected";}} ;?>>Rejected</option>
 </select>



  <div class="form_error">  <?php echo $this->session->flashdata('job_sts_curnt');?></div>
</div>
</div>

</div>

<div class="col-md-6 col-sm-12 rejection_reason">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Reason for rejection
</label>

<div class="col-md-8">
<textarea class="form-control" name="reason_rejec"></textarea>
  <div class="form_error">  <?php echo $this->session->flashdata('reason_rejec');?></div>
  <small>*For email purpose only*</small>
</div>

</div>
</div>


</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary" type="submit" >Confirm</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<!-- submit_main_form -->
<?php echo form_close();?>
</div>
</section>
</div>
<!----------------modal to view------------------------->	
<div id="modalLG<?php echo $t->jid;?>" class="modal-block modal-block-lg modal-header-color modal-block-info mfp-hide" data-backdrop="static" data-keyboard="false">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Candidate Details</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">

<div class="col-md-12">
<p><b>Position Applied : </b><?php echo $t->j_applied;?></p>
<p><b>Date of Application : </b><?php echo $t->j_date;?></p>
	<div class="col-md-6">

	<p><b>Candidate Name : </b><?php echo $t->j_candidate;?></p>
	<p><b>Email : </b><?php echo $t->j_email;?></p>
	<p><b>Mobile Number : </b><?php echo $t->j_mob;?></p>
	<p><b>Date of birth : </b><?php echo $t->j_dob;?></p>
	<p><b>Marital Status : </b><?php echo $t->j_maritial;?></p>
	<p><b>Nationality : </b><?php echo $t->j_nationality;?></p>

	
	</div>
	<div class="col-md-6">
	<p><b>Degree : </b>
		<?php if(!empty($t->j_degree))
	{
		$deg_val=explode(',',$t->j_degree);
		foreach($deg_val as $dv)
		{
			echo $dv.'<br/>';
		}
	} ;?></p>
	<p><b>Major : </b><?php if(!empty($t->j_major))
	{
		$deg_val=explode(',',$t->j_major);
		foreach($deg_val as $dv)
		{
			echo $dv.'<br/>';
		}
	} ;?></p>
<p><b>College/Institute : </b><?php if(!empty($t->j_college))
	{
		$deg_val=explode(',',$t->j_college);
		foreach($deg_val as $dv)
		{
			echo $dv.'<br/>';
		}
	} ;?></p>
	<p><b>Year of Passing : </b><?php if(!empty($t->j_yop))
	{
		$deg_val=explode(',',$t->j_yop);
		foreach($deg_val as $dv)
		{
			echo $dv.'<br/>';
		}
	} ;?></p>
	</div>

	<div class="col-md-6">
	<p><b>Organisation Name : </b><?php if(!empty($t->j_org_name))
	{
		$deg_val=explode(',',$t->j_org_name);
		foreach($deg_val as $dv)
		{
			echo $dv.'<br/>';
		}
	} ;?></p>
	<p><b>Position : </b><?php if(!empty($t->j_position))
	{
		$deg_val=explode(',',$t->j_position);
		foreach($deg_val as $dv)
		{
			echo $dv.'<br/>';
		}
	} ;?></p>
<p><b>Work Status : </b><?php if(!empty($t->j_wrk_sts))
	{
		$deg_val=explode(',',$t->j_wrk_sts);
		foreach($deg_val as $dv)
		{
			echo $dv.'<br/>';
		}
	} ;?></p>
	<p><b>Reason for leaving : <?php if(!empty($t->j_reason_leaving))
	{
		$deg_val=explode(',',$t->j_reason_leaving);
		foreach($deg_val as $dv)
		{
			echo $dv.'<br/>';
		}
	} ;?></p>
	</div>
	<div class="col-md-12">
		<p><b> Candidate Photo : <?php if(!empty($t->j_photo)){
			?>
			<a href="https://birigroup.com/uploads/photo/<?php echo $t->j_photo;?>" target="_blank"><?php echo $t->j_photo;?></a>

			<?php };?></b></p>

		<p><b>Resume : <?php if(!empty($t->j_resume)){?>
		<a href="https://birigroup.com/uploads/resume/<?php echo $t->j_resume;?>" target="_blank"><?php echo $t->j_resume;?></a>
		<?php };?></b></p>

		<p><b>Video : <?php if(!empty($t->j_video)){?>
<a href="https://birigroup.com/uploads/video/<?php echo $t->j_video;?>" target="_blank"><?php echo $t->j_video;?>
</a>
			<?php };?></b></p>

		
	</div>

</div>


</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-default modal-dismiss">Close</button>
</div>
</div>
</footer>
</section>
</div>


<?php 
}
}?>

</tbody>
</table>



</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	$(document).ready(function(){
$('.rejection_reason').hide();
	$('select[name="job_sts_curnt"]').on('change',function(){
	if($(this).val()=="6")
		$('.rejection_reason').show();
	else
		$('.rejection_reason').hide();
		});
	});
</script>

</body>
</html>