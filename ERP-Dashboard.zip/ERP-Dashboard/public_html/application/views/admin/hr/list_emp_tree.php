<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Employee Tree</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Employee Tree</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Table Data</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
	<th style="width: 10%;"></th>
<th>Employee Code </th>	
<th>Employee Name </th>	
<th>Position Name</th>
<th>Branch/location</th>
<th>Company Mobile</th>
<th>Company Email</th>
<th>Download all files</th>
<th>Download Custody</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($emp_details))
{
foreach($emp_details as $t)
{
	$emp_info=explode('$#$',$t->et_emp_info);
	//pre_list($emp_info);
	$emp_code=$t->et_code_branch;
$branch=explode(':',$emp_info[19]);
$emp_name=explode(':',$emp_info[0]);
$position=explode(':',$emp_info[8]);
$comp_mobile=explode(':',$emp_info[23]);
$comp_email=explode(':',$emp_info[24]);

$branch_name=$branch[1];
$branch_val;
switch($branch_name) 
{
	case 1:
	$branch_val='UAE-Diera';
	break;

	case 2:
	$branch_val='UAE-BANIYAS BRANCH';
	break;

	case 3:
	$branch_val='UAE-Dragon';
	break;

	case 4:
	$branch_val='UAE - Garhoud';
	break;

	case 5:
	$branch_val='KSA - Riyadh';
	break;

	case 6:
	$branch_val='KSA - Jeddah';
	break;
	case 7:
	$branch_val='KSA - Jeddah';
	break;
	case 8:
	$branch_val='FACTORY';
	break;
	case 9:
	$branch_val='KSA';
	break;
	
	default:
	break;
}
?>
<tr class="gradeX">
			<td><?php echo $i++;?></td>
				<td><?php echo $emp_code;?></td>
			<td><?php echo $emp_name[1];?></td>
			<td><?php echo $position[1];?></td>
			<td><?php echo $branch_val;?></td>
			<td><?php echo $comp_mobile[1];?></td>
			<td><?php echo $comp_email[1];?></td>
			<td><?php echo anchor('Employee_tree/download_emp_files/'.$t->et_id,'Download all');?></td>
			<td><?php echo anchor('Employee_tree/download_emp_custody/'.$t->et_id,'Download Custody');?></td>
			<td>
				<a onclick="view_data('<?php echo $t->et_id;?>');" ><i class="fa fa-eye"></i></a>
		&nbsp;&nbsp;
<a href="<?php echo base_url();?>Employee_tree/create_employee_tree/<?php echo $t->et_id;?>" ><i class="fa fa-pencil"></i></a>
		&nbsp;&nbsp;
	<a href="<?php echo base_url();?>Employee_tree/delete_employee_tree/<?php echo $t->et_id;?>" class="delete-row"><i class="fa fa-trash-o"></i></a> 
			</td>
	</tr>
<?php 
}
}?>

</tbody>
</table>

<!-------------------modal view quotation------------>
<div class="modal fade " id="modalsm2_view_data" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">View data</h3>
            </div>
            <div class="modal-body form ">
            	<div class="row view_data_modal" ></div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!------------modal view quotation ends----------->

</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	$(document).ready(function()
	{
		$('#country_id').val();
	 $('#datatable-default2').DataTable( {
	              rowReorder: {
	            selector: 'td:nth-child(2)'
	        },
	        "pageLength": 100,
	    responsive: true,
	     "scrollX": true,
		} );
	});

function view_data(id)
{
	console.log('view');
    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('Employee_tree/ajax_load_view/')?>",
        type: "POST",
        data: {"emp_id":id},
        success: function(data)
        {
        	$('.view_data_modal').html(data);
            $('#modalsm2_view_data').modal('show'); // show bootstrap modal when complete loaded
          },
    });
}
</script>
</body>
</html>