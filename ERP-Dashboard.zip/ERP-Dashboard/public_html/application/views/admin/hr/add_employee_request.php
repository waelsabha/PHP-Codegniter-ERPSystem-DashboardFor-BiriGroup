<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" rel="stylesheet"  type='text/css'>


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
.countrypicker{
	max-height:100px;
}
.fa-whatsapp  {
  color:#fff;
  background:
  linear-gradient(#25d366,#25d366)10px 84%/15px 15px no-repeat,
  radial-gradient(#25d366 59%,transparent 0);
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Add Jobs </h2>
</header>
<div class="panel-body">
	<?php echo form_open_multipart('submit_emp_request','class="form-horizontal form-bordered"');?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

    <input type="hidden" name="edit_empreq_id" value="<?php  if(!empty($result[0]->r_id)) echo $result[0]->r_id;?>">
    
    <input type="hidden" name="file_exist" value="<?php  if(!empty($result[0]->r_supporting_files)) echo $result[0]->r_supporting_files;?>">
  
  
<div class="row">
<div class="col-md-12 table-rows-border">
	<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Select User  <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select name="r_user" class="form-control" >
		<option></option>
		<?php
		foreach($emp_details as $ed)
		{
			?>

			<option value="<?php echo $ed->et_id;?>" <?php  if(!empty($result[0]->r_user)){if($result[0]->r_user==$ed->et_id){echo "selected";}} ?> > <?php echo $ed->et_name;?></option>

			<?php
		}
		?>
	</select>

 	<div class="form_error">  <?php echo $this->session->flashdata('r_user');?></div>
</div> 
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Subject of Request<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<input type="text" name="r_subject" class="form-control"  value="<?php  if(!empty($result[0]->r_subject)) echo $result[0]->r_subject;?>">
	<div class="form_error">  <?php echo $this->session->flashdata('r_subject');?></div>
	
</div>
</div>	
</div>

</div>
</div>








<div class="row">
	<div class="col-md-12 table-rows-border">
	


<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Request For :<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<label class="checkbox-inline">
<input type="checkbox" name="payment_type_loan" value="loan"  <?php if(!empty($result[0]-> loan_checked)){ $payment_type=explode(',', $result[0]->loan_checked);if( in_array('loan',$payment_type)){echo "checked";}} ;?> > Loan 
</label>

    <div class="form-group exact_loan_amt">
<label class="col-md-4 control-label" for="inputPlaceholder"> Amount </label>
<div class="col-md-8">

 <input type='text' name="r_amt_loan" class="form-control" value="<?php  if(!empty($result[0]-> r_amt_loan)) echo $result[0]-> r_amt_loan;?>" />
 
 <div class="form_error">  <?php echo $this->session->flashdata('r_amt_loan');?></div>
</div> 
</div>


<label class="checkbox-inline">
<input type="checkbox" name="payment_type_advanced" value="advanced"  <?php if(!empty($result[0]-> advanced_checked)){ $payment_type=explode(',', $result[0]->advanced_checked);if( in_array('ticketamt',$payment_type)){echo "checked";}} ;?> > Advanced amount
</label>
    <div class="form-group exact_advanced_amt">
<label class="col-md-4 control-label" for="inputPlaceholder"> Ticket </label>
<div class="col-md-8">

 <input type='text' name="advanvced_amt" class="form-control" value="<?php  if(!empty($result[0]-> r_amt_advanced)) echo $result[0]-> r_amt_advanced;?>" />
 
 <div class="form_error">  <?php echo $this->session->flashdata('advanvced_amt');?></div>
</div> 
</div>


 <div class="form_error">  <?php echo $this->session->flashdata('contract_type');?></div>
</div> 
</div>

</div>




</div>
</div>


















<div class="row">
	<div class="col-md-12 table-rows-border">
	<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> request description</label>

<div class="col-md-8">
<div class="input-group">
	<textarea class="form-control editors" name="r_desc"><?php  if(!empty($result[0]->r_desc)) echo $result[0]->r_desc;?></textarea>
</div>
 
 <div class="form_error">  <?php echo $this->session->flashdata('r_desc');?></div>
</div> 
</div>

</div>
</div>


<div class="row">
	<div class="col-md-12 table-rows-border">
	<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Supporting files(if any) </label>

<div class="col-md-8">
<div class="input-group">
	<input type="file" class="form-control" multiple="" name="r_supporting_files[]">
	<?php
	if(!empty($result[0]->r_supporting_files))
	{
	?>
	<a href="./uploads/leave_managment/<?php echo $result[0]->r_supporting_files;?>"><?php echo $result[0]->r_supporting_files;?> </a>
	<?php
	}
	?>
</div>
 
 <div class="form_error">  <?php echo $this->session->flashdata('r_supporting_files');?></div>
</div> 
</div>

</div>
</div>



<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>


<?php echo form_close();?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>


<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
		tinymce.init({
			selector : '.editors',
			  plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
		});
   </script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('#datetimepicker4').datepicker().datepicker("setDate", new Date());
            });
        </script>

<script type="text/javascript">
          $(function () {
                $('#datetimepicker5').datepicker().datepicker("setDate", new Date());
            });
        </script>
<script type="text/javascript">


 $(document).ready(function()
  {
  	 $('.exact_loan_amt').hide();


	$('input:checkbox').change(function() {
    
      //  $('.exact_salary_amt').show();

      var payment_type_leave = $("input[name='payment_type_loan']:checked").val();
      if(payment_type_leave=="loan")
      {
        $('.exact_loan_amt').show();
      }
     else
      {
        $('.exact_loan_amt').hide();
      }  
    
       
      });
        });
      
 </script>

 <script type="text/javascript">


 $(document).ready(function()
  {
  	 $('.exact_advanced_amt').hide();


	$('input:checkbox').change(function() {
    
      //  $('.exact_salary_amt').show();

      var payment_type_leave = $("input[name='payment_type_advanced']:checked").val();
      if(payment_type_leave=="advanced")
      {
        $('.exact_advanced_amt').show();
      }
     else
      {
        $('.exact_advanced_amt').hide();
      }  
    
       
      });
        });
      
 </script>

</html>