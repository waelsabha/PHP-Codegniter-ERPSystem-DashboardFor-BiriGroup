<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" rel="stylesheet"  type='text/css'>


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
.countrypicker{
	max-height:100px;
}
.fa-whatsapp  {
  color:#fff;
  background:
  linear-gradient(#25d366,#25d366)10px 84%/15px 15px no-repeat,
  radial-gradient(#25d366 59%,transparent 0);
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Add Jobs </h2>
</header>
<div class="panel-body">
	<?php echo form_open_multipart('submit_add_jobs','class="form-horizontal form-bordered"');?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

    <input type="hidden" name="update_job_id" value="<?php  if(!empty($result[0]->j_id)) echo $result[0]->j_id;?>">
  
  
<div class="row">
<div class="col-md-12 table-rows-border">
	<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Job Title  <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type='text' name="job_title" class="form-control" value="<?php  if(!empty($result[0]->j_title)) echo $result[0]->j_title;?>" required />
 	<div class="form_error">  <?php echo $this->session->flashdata('job_title');?></div>
</div> 
</div>
</div>

</div>
</div>


<div class="row">
	<div class="col-md-12 table-rows-border">
	
	<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Job Location<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

	
<input type='text' name="location" class="form-control" value="<?php if(!empty($result[0]-> j_location)) echo $result[0]-> j_location;?>"/>

<div class="form_error">  <?php echo $this->session->flashdata('location');?></div>
</div>
</div>
	
</div>


<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Type of employment option<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select data-plugin-selectTwo class="form-control populate" name="emp_type">
		<option></option>
		<option value="Full-time" <?php if(!empty($result[0]-> j_emp_type)){if($result[0]-> j_emp_type=="Full-time"){echo "selected";}} ;?>>Full-time</option>
		<option value="Part-time" <?php if(!empty($result[0]-> j_emp_type)){if($result[0]-> j_emp_type=="Part-time"){echo "selected";}} ;?>>Part-time</option>
		<option value="Either Full-time or Part-time" <?php if(!empty($result[0]-> j_emp_type)){if($result[0]-> j_emp_type=="Either Full-time or Part-time"){echo "selected";}} ;?>>Either Full-time or Part-time</option>
		
	</select>
	<div class="form_error">  <?php echo $this->session->flashdata('emp_type');?></div>
	
</div>
</div>	
</div>
</div>
</div>

<div class="row">
	<div class="col-md-12 table-rows-border">
	


<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Contract Type <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<label class="checkbox-inline">
<input type="checkbox" name="contract_type[]" value="Temporary" <?php if(!empty($result[0]-> j_cntrct_type)){ $contact_type=explode(',', $result[0]->j_cntrct_type);if( in_array('Temporary',$contact_type)){echo "checked";}} ;?>> Temporary
</label>
<label class="checkbox-inline">
<input type="checkbox" name="contract_type[]" value="Contract" <?php if(!empty($result[0]-> j_cntrct_type)){ $contact_type=explode(',', $result[0]->j_cntrct_type);if( in_array('Contract',$contact_type)){echo "checked";}} ;?>> Contract
</label>

<label class="checkbox-inline">
<input type="checkbox" name="contract_type[]" value="Internship" <?php if(!empty($result[0]-> j_cntrct_type)){ $contact_type=explode(',', $result[0]->j_cntrct_type);if( in_array('Internship',$contact_type)){echo "checked";}} ;?>> Internship
</label>

<label class="checkbox-inline">
<input type="checkbox" name="contract_type[]" value="Permanent" <?php if(!empty($result[0]-> j_cntrct_type)){ $contact_type=explode(',', $result[0]->j_cntrct_type);if( in_array('Permanent',$contact_type)){echo "checked";}} ;?>> Permanent
</label>

<label class="checkbox-inline">
<input type="checkbox" name="contract_type[]" value="Commission" <?php if(!empty($result[0]-> j_cntrct_type)){ $contact_type=explode(',', $result[0]->j_cntrct_type);if( in_array('Commission',$contact_type)){echo "checked";}} ;?>> Commission
</label>

<label class="checkbox-inline">
<input type="checkbox" name="contract_type[]" value="New-Grad" <?php if(!empty($result[0]-> j_cntrct_type)){ $contact_type=explode(',', $result[0]->j_cntrct_type);if( in_array('New-Grad',$contact_type)){echo "checked";}} ;?>> New-Grad
</label>


 
 <div class="form_error">  <?php echo $this->session->flashdata('contract_type');?></div>
</div> 
</div>

</div>


<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Salary Range</label>
<div class="col-md-8">

 <input type='text' name="salary" class="form-control" value="<?php  if(!empty($result[0]-> j_salary)) echo $result[0]-> j_salary;?>" />
 
 <div class="form_error">  <?php echo $this->session->flashdata('salary');?></div>
</div> 
</div>
</div>


</div>
</div>


<div class="row">
	<div class="col-md-12 table-rows-border">
	<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Job description</label>
<small>Describe the responsibilities of this job, required work experience, skills, or education.</small>
<div class="col-md-8">
<div class="input-group">
	<textarea class="form-control editors" name="job_desc"><?php  if(!empty($result[0]-> j_desc)) echo $result[0]-> j_desc;?></textarea>
</div>
 
 <div class="form_error">  <?php echo $this->session->flashdata('job_desc');?></div>
</div> 
</div>

</div>
</div>





<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>


<?php echo form_close();?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>


<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
		tinymce.init({
			selector : '.editors',
			  plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
		});
   </script>

</html>