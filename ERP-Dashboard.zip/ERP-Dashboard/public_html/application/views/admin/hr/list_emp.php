<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Employee details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Employee details</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Table Data<span class="pull-right"><a href="<?php echo base_url('add-employees');?>" class="btn btn-primary">Click to Create </a></span></h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-bordered table-striped mb-none" id="datatable-default">
<thead>
<tr>
	<th style="width: 10%;"></th>

<th>Employee Name </th>	
<th>Position Name</th>
<th>Branch/location</th>
<th>Mobile No:</th>
<th>Download all files</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($result))
{
foreach($result as $t)
{
$branch_name=$t->ed_branch;
$branch_val;
switch($branch_name) 
{
	case 1:
	$branch_val='Garhoud-HO';
	break;

	case 2:
	$branch_val='Baniyas Shop';
	break;

	case 3:
	$branch_val='Deira Shop';
	break;

	case 4:
	$branch_val='Ras Al khoor Store';
	break;

	case 5:
	$branch_val='Dragon Shop';
	break;

	case 6:
	$branch_val='RAK Factory';
	break;
	
	default:
	break;
}
?>
<tr class="gradeX">
			<td><?php echo $i++;?></td>
			<td><?php echo $t->ed_name;?></td>
			<td><?php echo $t->ed_pos;?></td>
			<td><?php echo $branch_val;?></td>
			<td><?php echo $t->ed_mob;?></td>
			<td><?php echo anchor('download_emp_files/'.$t->ed_id,'Download all');?></td>
			<td>
	<a href="#modalLG<?php echo $t->ed_id;?>" class="mb-xs mt-xs mr-xs modal-sizes btn btn-default"><i class="fa fa-eye"></i></a>
				&nbsp; &nbsp;
		
	<a href="edit_emp_details/<?php echo $t->ed_id;?>" ><i class="fa fa-pencil"></i></a>
		&nbsp;&nbsp;
<a href="delete_emp_details/<?php echo $t->ed_id;?>" class="delete-row"><i class="fa fa-trash-o"></i></a>
	
			</td>
	</tr>
<div id="modalLG<?php echo $t->ed_id;?>" class="modal-block modal-block-lg modal-header-color modal-block-info mfp-hide" data-backdrop="static" data-keyboard="false">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Employee Details</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">

<div class="col-md-12">

	<div class="col-md-4">
	<p><b>Employee Name : </b><?php echo $t->ed_name;?></p>
	
	<p><b>Mobile Number : </b><?php echo $t->ed_mob;?></p>
	<p><b>Gender : </b><?php if($t->ed_gender=='1'){echo "Male";}else{echo "Female";}?></p>
	<p><b>Nationality : </b><?php echo $t->country_name;?></p>

	<p><b>Maritial Status : </b><?php if($t->ed_martial_sts=='1'){echo "Married";}else{echo "Un-Married";}?></p>

	</div>
	<div class="col-md-4">
	<p><b>Position : </b><?php echo $t->ed_pos;?></p>
	<p><b>Date of Joining : </b><?php echo $t->ed_doj;?></p>
	<p><b>Branch/work location : </b><?php echo $branch_val;?></p>
	<p><b>Vacation date : </b><?php if(!empty($t->ed_vacation_date)){echo $t->ed_vacation_date;}?></p>
<p><b>Ticket status : </b><?php if(!empty($t->ed_tkt_sts)){if($t->ed_tkt_sts=='1'){ echo "Paid by company"; }else{ echo "Self-Paid";}}?></p>
	<p><b>Sick leave pay : </b><?php if(!empty($t->ed_sick_leave_pay)){echo $t->ed_sick_leave_pay;}?></p>
	</div>
	<div class="col-md-4">
		<p><b>Download Picture : <?php if(!empty($t->ed_pic)){echo anchor('download_emp_files_req/pic/'.$t->ed_id,'Download'); };?></b></p>

		<p><b>Download Job Offer Letter  : <?php if(!empty($t->ed_jol)){echo anchor('download_emp_files_req/jo/'.$t->ed_id,'Download');};?></b></p>

		<p><b>Download Employment Letter  : <?php if(!empty($t->ed_emp_ltr)){echo anchor('download_emp_files_req/el/'.$t->ed_id,'Download');};?></b></p>

		<p><b>Download Visa Copy : <?php if(!empty($t->ed_visa)){echo anchor('download_emp_files_req/vc/'.$t->ed_id,'Download');};?></b></p>

		<p><b>Download Passport Copy : <?php if(!empty($t->ed_psprt)){echo anchor('download_emp_files_req/pc/'.$t->ed_id,'Download');};?></b></p>

		<p><b>Download Emirates ID Copy : <?php if(!empty($t->ed_emirates_id)){ echo anchor('download_emp_files_req/ec/'.$t->ed_id,'Download');};?></b></p>
	</div>

</div>


</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-default modal-dismiss">Close</button>
</div>
</div>
</footer>
</section>
</div>


<?php 
}
}?>

</tbody>
</table>



</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	$(document).ready(function()
	{
		$('#country_id').val();

	});
</script>
</body>
</html>