<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
.countrypicker{
	max-height:100px;
}
.fa-whatsapp  {
  color:#fff;
  background:
  linear-gradient(#25d366,#25d366)10px 84%/15px 15px no-repeat,
  radial-gradient(#25d366 59%,transparent 0);
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Create / Add Employee Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Create / Add Employee Details</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<?php echo form_open_multipart('Employee_tree/submit_emp_tree');?>
<div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
      <p class="required"> Fileds marked as '::*::' are required fields</p>
  <?php if(!empty($emp_details)){
   $file_info=explode('$#$',$emp_details[0]->et_emp_files);

$pic_name=explode(':',$file_info[0]);
$job_offer_letter=explode(':',$file_info[1]);
$passport_copy=explode(':',$file_info[2]);
$visa_copy=explode(':',$file_info[3]);
$employee_contract=explode(':',$file_info[4]);
$emirates_id_copy=explode(':',$file_info[5]);
$driving_license_copy=explode(':',$file_info[6]);

}?>
<input type="hidden" name="emp_id_edit" value="<?php if(!empty($emp_details)){echo $emp_id;};?>">

<input type="hidden" name="edit_picture" value="<?php if(!empty($pic_name[1])){echo $pic_name[1];};?>">
<input type="hidden" name="edit_passport" value="<?php if(!empty($passport_copy[1])){echo $passport_copy[1];};?>">
<input type="hidden" name="edit_job_offer" value="<?php if(!empty($job_offer_letter[1])){echo $job_offer_letter[1];};?>">
<input type="hidden" name="edit_emplymnt_contract" value="<?php if(!empty($employee_contract[1])){echo $employee_contract[1];};?>">
<input type="hidden" name="edit_visa" value="<?php if(!empty($visa_copy[1])){echo $visa_copy[1];};?>">
<input type="hidden" name="edit_emirtaes_id" value="<?php if(!empty($emirates_id_copy[1])){echo $emirates_id_copy[1];};?>">
<input type="hidden" name="edit_driving_lic" value="<?php if(!empty($driving_license_copy[1])){echo $driving_license_copy[1];};?>">
        <div class="nav-tabs-custom">
            <!-- Tabs within a box -->
            <ul class="nav nav-tabs">
                <li class="active"><a href="#employee_info" data-toggle="tab">Employee Information</a></li>
                <li class=""><a href="#personal_info_tab" data-toggle="tab">Personal Information</a></li>
                <li class=""><a href="#leave_details_tab" data-toggle="tab">Leave Details</a></li>
				 <li class=""><a href="#earnings" data-toggle="tab">Earnings</a>
                </li>
                <li class=""><a href="#fileupload" data-toggle="tab">Files Upload</a>
                </li>
			</ul>
            <div class="tab-content bg-white">
                <!-- ************** general *************-->
                       <div class="tab-pane active" id="employee_info">
  <?php if(!empty($emp_details)){
   $emp_info=explode('$#$',$emp_details[0]->et_emp_info);

	$emp_name=explode(':',$emp_info[0]);
	$alias=explode(':',$emp_info[1]);
		$code=explode(':',$emp_info[2]);
		$basic_salary=explode(':',$emp_info[3]);
		$currency=explode(':',$emp_info[4]);
		$doj=explode(':',$emp_info[5]);
		$next_appraisal_date=explode(':',$emp_info[6]);
		$holiday1=explode(':',$emp_info[7]);
		$designation=explode(':',$emp_info[8]);
		$half_day=explode(':',$emp_info[9]);
		$holiday2=explode(':',$emp_info[10]);
		$salary_acc=explode(':',$emp_info[11]);
		$payable_account=explode(':',$emp_info[12]);
		$dor=explode(':',$emp_info[13]);
		$date_applicable=explode(':',$emp_info[14]);
		$emp_sts=explode(':',$emp_info[15]);
		$resg_date=explode(':',$emp_info[16]);
		$bank_name=explode(':',$emp_info[17]);
		$bank_branch_name=explode(':',$emp_info[18]);
		$branch=explode(':',$emp_info[19]);
		$acc_name=explode(':',$emp_info[20]);
		$vdo=explode(':',$emp_info[21]);
		$resign_payment_type=explode(':',$emp_info[22]);
		$company_mobile_no=explode(':',$emp_info[23]);
		$company_email=explode(':',$emp_info[24]);

        $folder_name=strtolower(preg_replace('/\s+/', '_', $emp_name[1]));
  }
  ?>
                            <div class="panel-body">
                                <div class="col-sm-7">
                                	 <div class="form-group">
                                        <label class="col-sm-4 control-label">Choose Login Name <abbr class="required">::*::</abbr></label>
                                        <div class="col-sm-8">
                                           <select class="form-control" name="login_username">
                                           		<option>Choose</option>
												<?php
												foreach($login_emp as $c)
													{?>
												<option value="<?php echo $c->log_id;?>" <?php if(!empty($emp_details[0]->ed_login_id)){if($emp_details[0]->ed_login_id ==$c->log_id){echo "selected";}} ?> ><?php echo $c->log_uname;?></option>
												<?php
											}?>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Employee Name </label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" value="<?php if(!empty($emp_details)){if(!empty($emp_name[1])) {echo $emp_name[1];} }?>" name="emp_name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Alias </label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" value="<?php if(!empty($emp_details)){if(!empty($alias[1])) {echo $alias[1];}}?>" name="alias">
                                        </div>
                                    </div>
                                   
                            
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Basic Salary </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" value="<?php if(!empty($emp_details)){if(!empty($basic_salary[1])) {echo $basic_salary[1];}}?>" name="basic_salary">
                                            </div>
                                        </div>
                                    </div>
                                   
                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Currency </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <select class="form-control" name="currency">
                                                    <option value="AED" <?php if(!empty($emp_details)){if($currency[1]=='AED'){echo "selected";}};?>>AED</option>

                                                    <option value="USD" <?php if(!empty($emp_details)){if($currency[1]=='USD'){echo "selected";}};?>>USD</option>

                                                    <option value="EURO" <?php if(!empty($emp_details)){if($currency[1]=='EURO'){echo "selected";}};?>>EURO</option>

                                                    <option value="OMR" <?php if(!empty($emp_details)){if($currency[1]=='OMR'){echo "selected";}};?>>OMR</option>

                                                    <option value="GBP" <?php if(!empty($emp_details)){if($currency[1]=='GBP'){echo "selected";}};?>>GBP</option>

                                                    <option value="QAR" <?php if(!empty($emp_details)){if($currency[1]=='QAR'){echo "selected";}};?>>QAR</option>
                                                </select>
                                            </div>
                                        </div>
                                </div>
                               
		
                                     <div class="form-group">
                                        <label class="col-sm-4 control-label">Date of Join</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input  type="text" name="doj"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($emp_details)){if(!empty($doj[1])) {echo $doj[1];}}?>" >
                                                <div class="input-group-addon">
                                                    <a href="#"><i class="fa fa-calendar"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Next Appraisal Date</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input  type="text" name="next_appraisal_date"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($emp_details)){if(!empty($next_appraisal_date[1])) {echo $next_appraisal_date[1];}}?>" >
                                                <div class="input-group-addon">
                                                    <a href="#"><i class="fa fa-calendar"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Holiday1 </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <select class="form-control" name="holiday1">
                                                    <option value="Monday" <?php if(!empty($emp_details)){if($holiday1[1]=='Monday'){echo "selected";}};?>>Monday</option>
                                                    <option value="Tuesday" <?php if(!empty($emp_details)){if($holiday1[1]=='Tuesday'){echo "selected";}};?>>Tuesday</option>
                                                    <option value="Wednesday" <?php if(!empty($emp_details)){if($holiday1[1]=='Wednesday'){echo "selected";}};?>>Wednesday</option>
                                                    <option value="Thursday" <?php if(!empty($emp_details)){if($holiday1[1]=='Thursday'){echo "selected";}};?>>Thursday</option>
                                                    <option value="Friday" <?php if(!empty($emp_details)){if($holiday1[1]=='Friday'){echo "selected";}};?>>Friday</option>
                                                    <option value="Saturday" <?php if(!empty($emp_details)){if($holiday1[1]=='GBP'){echo "selected";}};?>>Saturday</option>
                                                </select>
                                            </div>
                                        </div>
                                </div>

                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Designation </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <select class="form-control" name="designation">
                                                    <option value="IT" <?php if(!empty($emp_details)){if($designation[1]=='IT'){echo "selected";}};?>>IT</option>
                                                    <option value="Salesperson" <?php if(!empty($emp_details)){if($designation[1]=='Salesperson'){echo "selected";}};?>>Salesperson</option>
                                                    <option value="Office In-charge" <?php if(!empty($emp_details)){if($designation[1]=='Office In-charge'){echo "selected";}};?>>Office In-charge</option>
                                                    <option value="Sales Executive" <?php if(!empty($emp_details)){if($designation[1]=='Sales Executive'){echo "selected";}};?>>Sales Executive</option>
                                                    <option value="Ordinary Labour" <?php if(!empty($emp_details)){if($designation[1]=='Ordinary Labour'){echo "selected";}};?>>Ordinary Labour</option>
                                                    <option value="Driver" <?php if(!empty($emp_details)){if($designation[1]=='Driver'){echo "selected";}};?>>Driver</option>
                                                    <option value="Messenger" <?php if(!empty($emp_details)){if($designation[1]=='Messenger'){echo "selected";}};?>>Messenger</option>
                                                    <option value="Helper" <?php if(!empty($emp_details)){if($designation[1]=='Helper'){echo "selected";}};?>>Helper</option>
                                                    <option value="Welder" <?php if(!empty($emp_details)){if($designation[1]=='Welder'){echo "selected";}};?>>Welder</option>
                                                    <option value="Project Cordinator" <?php if(!empty($emp_details)){if($designation[1]=='Project Cordinator'){echo "selected";}};?>>Project Cordinator</option>
                                                    <option value="Accountant" <?php if(!empty($emp_details)){if($designation[1]=='Accountant'){echo "selected";}};?>>Accountant</option>
                                                     <option value="Senior Accountant" <?php if(!empty($emp_details)){if($designation[1]=='Senior Accountant'){echo "selected";}};?>>Senior Accountant</option>
                                                     <option value="FOREMAN" <?php if(!empty($emp_details)){if($designation[1]=='FOREMAN'){echo "selected";}};?>>FOREMAN</option>
                                                     <option value="Public Relations Officer" <?php if(!empty($emp_details)){if($designation[1]=='Public Relations Officer'){echo "selected";}};?>>Public Relations Officer</option>
                                                      <option value="Key Accounts Manager" <?php if(!empty($emp_details)){if($designation[1]=='Key Accounts Manager'){echo "selected";}};?>>Key Accounts Manager</option>
                                                       <option value="Sales Manger" <?php if(!empty($emp_details)){if($designation[1]=='Sales Manger'){echo "selected";}};?>>Sales Manger</option>
                                                      <option value="HR Manager" <?php if(!empty($emp_details)){if($designation[1]=='HR Manager'){echo "selected";}};?>>HR Manager</option>
                                                       <option value="Marketing Specialist" <?php if(!empty($emp_details)){if($designation[1]=='Marketing Specialist'){echo "selected";}};?>>Marketing Specialist</option>
                                                     <option value="Personal Assistant" <?php if(!empty($emp_details)){if($designation[1]=='Personal Assistant'){echo "selected";}};?>>Personal Assistant</option>
                                                     <option value="Graphic Designer" <?php if(!empty($emp_details)){if($designation[1]=='Graphic Designer'){echo "selected";}};?>>Graphic Designer</option>
                                                     <option value="Warehouse Supervisor" <?php if(!empty($emp_details)){if($designation[1]=='Warehouse Supervisor'){echo "selected";}};?>>Warehouse Supervisor</option>
                                                     <option value="Store Keeper" <?php if(!empty($emp_details)){if($designation[1]=='Store Keeper'){echo "selected";}};?>>Store Keeper</option>
                                                      <option value="Outdoor Sales Executive" <?php if(!empty($emp_details)){if($designation[1]=='Outdoor Sales Executive'){echo "selected";}};?>>Outdoor Sales Executive</option>

                                                       <option value="Indoor Sales Executive" <?php if(!empty($emp_details)){if($designation[1]=='Indoor Sales Executive'){echo "selected";}};?>>Indoor Sales Executive</option>
                                                      <option value="Administrator" <?php if(!empty($emp_details)){if($designation[1]=='Administrator'){echo "selected";}};?>>Administrator</option>
                                               </select>
                                            </div>
                                        </div>
                                </div>
      
                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Company Email </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                           <input type="text" name="company_email" class="form-control"
                    value="<?php if(!empty($emp_details)){if(!empty($company_email[1])){echo $company_email[1];}}?>">
                   
                                            </div>
                                        </div>
                                </div>

                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Company Mobile Number  </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                             <input  type="text" name="company_mobile_number"
                                                       class="form-control"
                                                       value="<?php if(!empty($emp_details)){if(!empty($company_mobile_no[1])) {echo $company_mobile_no[1];}}?>">
                                            </div>
                                        </div>
                                </div>

                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Half Day </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <select class="form-control" name="half_day">
                                                     <option value="Monday"<?php if(!empty($emp_details)){if($half_day[1]=='Monday'){echo "selected";}};?>>Monday</option>
                                                    <option value="Tuesday"<?php if(!empty($emp_details)){if($half_day[1]=='Tuesday'){echo "selected";}};?>>Tuesday</option>
                                                    <option value="Wednesday"<?php if(!empty($emp_details)){if($half_day[1]=='Wednesday'){echo "selected";}};?>>Wednesday</option>
                                                    <option value="Thursday"<?php if(!empty($emp_details)){if($half_day[1]=='Thursday'){echo "selected";}};?>>Thursday</option>
                                                    <option value="Friday"<?php if(!empty($emp_details)){if($half_day[1]=='Friday'){echo "selected";}};?>>Friday</option>
                                                    <option value="Saturday"<?php if(!empty($emp_details)){if($half_day[1]=='Saturday'){echo "selected";}};?>>Saturday</option>
                                                </select>
                                            </div>
                                        </div>
                                </div>

                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Holiday 2 </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <select class="form-control" name="holiday2">
                                                     <option value="Monday"<?php if(!empty($emp_details)){if($holiday2[1]=='Monday'){echo "selected";}};?>>Monday</option>
                                                    <option value="Tuesday"<?php if(!empty($emp_details)){if($holiday2[1]=='Tuesday'){echo "selected";}};?>>Tuesday</option>
                                                    <option value="Wednesday"<?php if(!empty($emp_details)){if($holiday2[1]=='Wednesday'){echo "selected";}};?>>Wednesday</option>
                                                    <option value="Thursday"<?php if(!empty($emp_details)){if($holiday2[1]=='Thursday'){echo "selected";}};?>>Thursday</option>
                                                    <option value="Friday"<?php if(!empty($emp_details)){if($holiday2[1]=='Friday'){echo "selected";}};?>>Friday</option>
                                                    <option value="Saturday"<?php if(!empty($emp_details)){if($holiday2[1]=='Saturday'){echo "selected";}};?>>Saturday</option>
                                                </select>
                                            </div>
                                        </div>
                                </div>
                                    </div>
                         <div class="col-md-5">
             
                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Salary Account  </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" name="salary_acc" value="<?php if(!empty($emp_details)){if(!empty($salary_acc[1])) {echo $salary_acc[1];}}?>">
                                            </div>
                                        </div>
                                </div>

                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Payable Account</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" name="payable_account" value="<?php if(!empty($emp_details)){if(!empty($payable_account[1])) {echo $payable_account[1];}}?>">
                                            </div>
                                        </div>
                                </div>

                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Date of Revision  </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                              <input  type="text" name="dor"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($emp_details)){if(!empty($dor[1])) {echo $dor[1];}}?>">
                                            </div>
                                        </div>
                                </div>

                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Date Applicable </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                               <input  type="text" name="date_applicable"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($emp_details)){if(!empty($date_applicable[1])) {echo $date_applicable[1];}}?>">
                                            </div>
                                        </div>
                                </div>
                                            <div class="form-group">
                                        <label class="col-sm-4 control-label">Employee Status </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <select class="form-control" name="emp_sts">
                                                     <option value="On Duty" <?php if(!empty($emp_details)){if($emp_sts[1]=='On Duty'){echo "selected";}};?>>On Duty</option>
                                                    <option value="Resigned" <?php if(!empty($emp_details)){if($emp_sts[1]=='Resigned'){echo "selected";}};?>>Resigned</option>
                                                    <option value="Suspended" <?php if(!empty($emp_details)){if($emp_sts[1]=='Suspended'){echo "selected";}};?>>Suspended</option>
                                                    <option value="Terminated" <?php if(!empty($emp_details)){if($emp_sts[1]=='Terminated'){echo "selected";}};?>>Terminated</option>
                                                    <option value="Deseased" <?php if(!empty($emp_details)){if($emp_sts[1]=='Deseased'){echo "selected";}};?>>Deseased</option>
                                                    <option value="Abscond" <?php if(!empty($emp_details)){if($emp_sts[1]=='Abscond'){echo "selected";}};?>>Abscond</option>
                                                    <option value="Long Leave" <?php if(!empty($emp_details)){if($emp_sts[1]=='Long Leave'){echo "selected";}};?>>Long Leave</option>
                                                    <option value="VRS" <?php if(!empty($emp_details)){if($emp_sts[1]=='VRS'){echo "selected";}};?>>VRS</option>
                                                    <option value="Retired" <?php if(!empty($emp_details)){if($emp_sts[1]=='Retired'){echo "selected";}};?>>Retired</option>
                                                </select>
                                            </div>
                                        </div>
                                </div>
                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Resignation Date  </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                              <input  type="text" name="resg_date"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($emp_details)){if(!empty($resg_date[1])) {echo $resg_date[1];}}?>">
                                            </div>
                                        </div>
                                </div>

                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Bank Name</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                             <input type="text" name="bank_name" class="form-control" value="<?php if(!empty($emp_details)){if(!empty($bank_name[1])) {echo $bank_name[1];}}?>">
                                            </div>
                                        </div>
                                </div>
   
                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Bank Branch Name</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                             <input type="text" name="bank_branch_name" class="form-control" value="<?php if(!empty($emp_details)){if(!empty($bank_branch_name[1])) {echo $bank_branch_name[1];}}?>">
                                            </div>
                                        </div>
                                </div>



         <div class="form-group">
                                        <label class="col-sm-4 control-label">Branch Name <abbr class="required">::*::</abbr></label>
                                        <div class="col-sm-8">
                                           <select class="form-control" name="branch">
                                                <option>Choose</option>
                                                <?php
                                                foreach($branch_company as $bc)
                                                    {?>
                                                <option value="<?php echo $bc->mcomp_id;?>" <?php if(!empty($emp_details[0]->et_branch)){if($emp_details[0]->et_branch ==$bc->mcomp_id){echo "selected";}} ?> ><?php echo $bc->mcomp_name;?></option>
                                                <?php
                                            }?>
                                           </select>
                                        </div>
                                    </div>








            
                                        <div class="form-group">
                                        <label class="col-sm-4 control-label">Employee Code  </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" name="emp_code" class="form-control"value="<?php if(!empty($emp_details)){if(!empty($code[1])) {echo $code[1];}}?>">
                                            </div>
                                        </div>
                                </div>

                    



                                        <div class="form-group">
                                        <label class="col-sm-4 control-label">evaluation  </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" name="evaluation_emp" class="form-control" value="<?php if(!empty($evaluation_emp)){if(!empty($evaluation_emp[1])) {echo $evaluation_emp[1];}}?>">
                                            </div>
                                        </div>
                                </div>
                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Account  </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" name="acc_name" class="form-control" value="<?php if(!empty($emp_details)){if(!empty($acc_name[1])) {echo $acc_name[1];}}?>">
                                            </div>
                                        </div>
                                </div>

                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Vacation Due On  </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                             <input  type="text" name="vdo"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($emp_details)){if(!empty($vdo[1])) {echo $vdo[1];}}?>">
                                            </div>
                                        </div>
                                </div>

                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Resign Payment Type  </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <select class="form-control" name="resign_payment_type">
                                                     <option option="Cash" <?php if(!empty($emp_details)){if($resign_payment_type[1]=='Cash'){echo "selected";}};?>>Cash</option>
                                                    <option option="Bank" <?php if(!empty($emp_details)){if($resign_payment_type[1]=='Bank'){echo "selected";}};?>>Bank</option>
                                                    <option option="WPS" <?php if(!empty($emp_details)){if($resign_payment_type[1]=='WPS'){echo "selected";}};?>>WPS</option>
                                                    <option option="Cheque" <?php if(!empty($emp_details)){if($resign_payment_type[1]=='Cheque'){echo "selected";}};?>>Cheque</option>
                                                </select>
                                            </div>
                                        </div>
                                </div>
                                    </div>
                                
                             </div>
                           
                        </div>
                  <?php if(!empty($emp_details)){
    $personal_info=explode('$#$',$emp_details[0]->et_personal_info);

    $gender=explode(':',$personal_info[0]);
    $nationality=explode(':',$personal_info[1]);
        $insurance_currency=explode(':',$personal_info[2]);
        $blood_grp=explode(':',$personal_info[3]);
        $marital_status=explode(':',$personal_info[4]);
        $dom=explode(':',$personal_info[5]);
        $spouse_emp_type=explode(':',$personal_info[6]);
        $spouse_name=explode(':',$personal_info[7]);
        $cont_adrs=explode(':',$personal_info[8]);
        $cont_city=explode(':',$personal_info[9]);
        $cont_pin=explode(':',$personal_info[10]);
        $cont_phone=explode(':',$personal_info[11]);
        $cont_mobile=explode(':',$personal_info[12]);
        $cont_email=explode(':',$personal_info[13]);
        $cont_fax=explode(':',$personal_info[14]);
        $permnt_adrs=explode(':',$personal_info[15]);
        $permnt_city=explode(':',$personal_info[16]);
        $permnt_country=explode(':',$personal_info[17]);
        $permnt_pin=explode(':',$personal_info[18]);
        $permnt_phone=explode(':',$personal_info[19]);
        $permnt_fax=explode(':',$personal_info[20]);
        $sec_username=explode(':',$personal_info[21]);
        $sec_password=explode(':',$personal_info[22]);
        $pr_ic_no=explode(':',$personal_info[23]);
        $pr_issue_date=explode(':',$personal_info[24]);

        $pr_expiry=explode(':',$personal_info[25]);
         $last_air_ticket=explode(':',$personal_info[26]);
          $airticket_entitlment_period=explode(':',$personal_info[27]);
           $passport_no=explode(':',$personal_info[28]);
            $passport_issue_date=explode(':',$personal_info[29]);
             $passport_issue_place=explode(':',$personal_info[30]);
              $passport_expiry=explode(':',$personal_info[31]);
               $visa_no=explode(':',$personal_info[32]);
         $visa_type=explode(':',$personal_info[33]);
          $visa_strt_date=explode(':',$personal_info[34]);
           $visa_expiry_date=explode(':',$personal_info[35]);
            $visa_issue_place=explode(':',$personal_info[36]);
             $visa_company=explode(':',$personal_info[37]);
              $visa_proof=explode(':',$personal_info[38]);
               $driving_lic=explode(':',$personal_info[39]);
                $driving_issue_date=explode(':',$personal_info[40]);
                 $driving_lic_exp=explode(':',$personal_info[41]);
                  $prob_period=explode(':',$personal_info[42]);

        $confirmation_date=explode(':',$personal_info[43]);
        $temp_emp=explode(':',$personal_info[44]);
        $contract_expiry=explode(':',$personal_info[45]);
        $contract_type=explode(':',$personal_info[46]);          
        $health_card=explode(':',$personal_info[47]);
        $issue_date_health_card=explode(':',$personal_info[48]);
        $expiry_date_health_card=explode(':',$personal_info[49]);

        $clg_name=explode(':',$personal_info[50]);
        $clg_yop=explode(':',$personal_info[51]);
        $clg_specialization=explode(':',$personal_info[52]);          
        $clg_college_university=explode(':',$personal_info[53]);

        $insurance_type=explode(':',$personal_info[54]);

  }
  ?>      
              <div class="tab-pane " id="personal_info_tab">
                   
                            <div class="panel-body">
                                <div class="col-sm-7">
                 <div class="row">                  
                 <div class="form-group">
                <label class="col-sm-4 control-label">Gender  </label>
                <div class="col-sm-8">
                    <label class="radio-inline">
                        <input type="radio" value="Male" name="gender"  <?php if(!empty($personal_info)){if($gender[1]=='Male'){echo "checked";}};?>>
                        Male                    
                    </label>
                    <label class="radio-inline">
                        <input type="radio" value="Female" name="gender"  <?php if(!empty($personal_info)){if($gender[1]=='Female'){echo "checked";}};?>>
                         Female
                    </label> 
                    <label class="radio-inline">
                        <input type="radio" value="Others" name="gender"  <?php if(!empty($personal_info)){if($gender[1]=='Others'){echo "checked";}};?>>
                         Others
                    </label>                 
                </div>
             </div>
         </div>

                                   
                    <div class="form-group">
                        <label
                                class="col-sm-4 control-label">Nationality</label>
                        <div class="col-sm-8">
                               <input type="text" name="nationality" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($nationality[1])) {echo $nationality[1];}}?>">
                         </div>
                    </div>

                    <div class="row">                  
                             <div class="form-group">
                            <div class="col-sm-8">
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="Medical Insurance" name="insurance_type"
                                     <?php if(!empty($personal_info)){if($insurance_type[1]=='Medical Insurance'){echo "checked";}};?>>
                                    Medical Insurance                     
                                </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="Insurance Provided" name="insurance_type"
                                     <?php if(!empty($personal_info)){if($insurance_type[1]=='Insurance Provided'){echo "checked";}};?>>
                                     Insurance Provided
                                </label> 
                                            
                            </div>
                         </div>
                     </div>   
                    
                                     
                         <div class="form-group">
                          <label class="col-sm-4 control-label">Value</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                             <span class="pull-left">
                                            <input type="text" class="form-control" name="insurance_val"></span>
                                            <span class="pull-right">   
                                                <select class="form-control" name="insurance_currency">
                                                    <option value="AED" <?php if(!empty($personal_info)){if($insurance_currency[1]=='AED'){echo "selected";}};?>>AED</option>
                                                    <option value="USD" <?php if(!empty($personal_info)){if($insurance_currency[1]=='USD'){echo "selected";}};?>>USD</option>
                                                    <option value="EURO" <?php if(!empty($personal_info)){if($insurance_currency[1]=='EURO'){echo "selected";}};?>>EURO</option>
                                                    <option value="OMR" <?php if(!empty($personal_info)){if($insurance_currency[1]=='OMR'){echo "selected";}};?>>OMR</option>
                                                    <option value="GBP" <?php if(!empty($personal_info)){if($insurance_currency[1]=='GBP'){echo "selected";}};?>>GBP</option>
                                                    <option value="QAR" <?php if(!empty($personal_info)){if($insurance_currency[1]=='QAR'){echo "selected";}};?>>QAR</option>
                                                </select>
                                            </span>
                                            </div>
                                        </div>
                                    </div>
                                    

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Blood Group </label>
                                        <div class="col-sm-8">
                                                <input type="text" class="form-control" name="blood_grp" value="<?php if(!empty($personal_info)){if(!empty($blood_grp[1])) {echo $blood_grp[1];}}?>">
                                        </div>
                                    </div>
                                
                                
                                <div class="form-group">
                 <label class="col-sm-4 control-label">Marital Status </label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <select class="form-control" name="marital_status">
                                                    <option value="Married" <?php if(!empty($personal_info)){if($marital_status[1]=='Married'){echo "selected";}};?>>Married</option>
                                                    <option value="UnMarried" <?php if(!empty($personal_info)){if($marital_status[1]=='UnMarried'){echo "selected";}};?>>UnMarried</option>
                                                    <option value="Divorced" <?php if(!empty($personal_info)){if($marital_status[1]=='Divorced'){echo "selected";}};?>>Divorced</option>
                                                    <option value="Widow" <?php if(!empty($personal_info)){if($marital_status[1]=='Widow'){echo "selected";}};?>>Widow</option>
                                                    <option value="Single" <?php if(!empty($personal_info)){if($marital_status[1]=='Single'){echo "selected";}};?>> Single</option>
                                                 </select>
                                            </div>
                                        </div>
                                </div>
                           
                                     <div class="form-group">
                    <label class="col-sm-4 control-label">Date of Marriage</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input  type="text" name="dom"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($personal_info)){if(!empty($dom[1])) {echo $dom[1];}}?>">
                                                <div class="input-group-addon">
                                                    <a href="#"><i class="fa fa-calendar"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
           
                                     <div class="form-group">
                                        <label class="col-sm-4 control-label"></label>
                                        <div class="col-sm-8">
                                             <label class="radio-inline">
                                                <input type="radio" value="Spouse is unemployed " name="spouse_emp_type" <?php if(!empty($personal_info)){if($spouse_emp_type[1]=='Spouse is unemployed'){echo "checked";}};?>>
                                                Spouse is unemployed                     
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" value="Spouse working in this company" name="spouse_emp_type" <?php if(!empty($personal_info)){if($spouse_emp_type[1]=='Spouse working in this company'){echo "checked";}};?>>
                                                 Spouse working in this company 
                                            </label> 
                                            <label class="radio-inline">
                                                <input type="radio" value="Spouse working in different company" name="spouse_emp_type" <?php if(!empty($personal_info)){if($spouse_emp_type[1]=='Spouse working in different company'){echo "checked";}};?>>
                                                 Spouse working in different company 
                                            </label>  
                                          </div>
                                    </div>

                                    <div class="form-group">
                                    <label class="col-sm-4 control-label">Spouse Name </label>
                                       <div class="col-sm-8">
                                                 <input type="text" name="spouse_name" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($spouse_name[1])) {echo $spouse_name[1];}}?>"> 
                                        </div>   
                                        </div> 

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Contact Details </label>
                                        <div class="col-sm-8">
                                          Address :<input type="text" name="cont_adrs" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($cont_adrs[1])) {echo $cont_adrs[1];}}?>">
                                     City :<input type="text" name="cont_city" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($cont_city[1])) {echo $cont_city[1];}}?>"> 
                                    Pin/Zip Code: <input type="text" name="cont_pin" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($cont_pin[1])) {echo $cont_pin[1];}}?>">
                                     Phone No.:<input type="text" name="cont_phone" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($cont_phone[1])) {echo $cont_phone[1];}}?>">
                                    Mobile :<input type="text" name="cont_mobile" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($cont_mobile[1])) {echo $cont_mobile[1];}}?>"> 
                                     Email ID: <input type="text" name="cont_email" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($cont_email[1])) {echo $cont_email[1];}}?>"> 
                                      Fax:<input type="text" name="cont_fax" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($cont_fax[1])) {echo $cont_fax[1];}}?>"> 
                                         </div>
                                </div>

                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Permanent Address </label>
                                        <div class="col-sm-8">
                                          Address :<input type="text" name="permnt_adrs" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($permnt_adrs[1])) {echo $permnt_adrs[1];}}?>">
                                     City :<input type="text" name="permnt_city" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($permnt_city[1])) {echo $permnt_city[1];}}?>"> 
                                       Country: <input type="text" name="permnt_country" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($permnt_country[1])) {echo $permnt_country[1];}}?>">
                                    Pin/Zip Code: <input type="text" name="permnt_pin" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($permnt_pin[1])) {echo $permnt_pin[1];}}?>">
                                     Phone No.:<input type="text" name="permnt_phone" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($permnt_phone[1])) {echo $permnt_phone[1];}}?>">
                                      Fax:<input type="text" name="permnt_fax" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($permnt_fax[1])) {echo $permnt_fax[1];}}?>"> 
                                         </div>
                                </div>
            
                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Security  </label>
                                        <div class="col-sm-8">
                                        <div class="input-group">
                                            <label class="radio-inline ">
                                                Username  
                                                  <input type="text" name="sec_username" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($sec_username[1])) {echo $sec_username[1];}}?>"> 
                                            </label> 
                                            <label class="radio-inline ">
                                                Password
                                                  <input type="text" name="sec_password" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($sec_password[1])) {echo $sec_password[1];}}?>"> 
                                            </label>  
                                         </div>
                                        </div>
                                </div>

                                <div class="row">
                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Permanent Residance </label>
                                        <div class="col-sm-8">
                                          IC No :<input type="text" name="pr_ic_no" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($pr_ic_no[1])) {echo $pr_ic_no[1];}}?>">
                                      PR Issue Date : <input  type="text" name="pr_issue_date"
                                                class="form-control start_date datetimepicker4" value="<?php if(!empty($personal_info)){if(!empty($pr_issue_date[1])) {echo $pr_issue_date[1];}}?>">
                                                <div class="input-group-addon">
                                                    <a href="#"><i class="fa fa-calendar"></i></a>
                                                </div>
                                        PR Expiry : <input type="text" name="pr_expiry" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($pr_expiry[1])) {echo $pr_expiry[1];}}?>">
                                    </div>
                                </div>
                            </div>
                                    </div>
                         <div class="col-md-5">
                              
                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Last Air Ticket</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                               <input  type="text" name="last_air_ticket"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($personal_info)){if(!empty($last_air_ticket[1])) {echo $last_air_ticket[1];}}?>">
                                                <div class="input-group-addon">
                                                    <a href="#"><i class="fa fa-calendar"></i></a>
                                                </div>
                                            </div>
                                            
                                         </div>
                                </div>

                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Airticket Entitlement Period</label>
                                        <div class="col-sm-8">
                                                <input type="text" class="form-control" name="airticket_entitlment_period" value="<?php if(!empty($personal_info)){if(!empty($airticket_entitlment_period[1])) {echo $airticket_entitlment_period[1];}}?>">
                                        </div>
                                </div>

                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Passport No.  </label>
                                        <div class="col-sm-8">
                                               <input type="text" class="form-control" name="passport_no" value="<?php if(!empty($personal_info)){if(!empty($passport_no[1])) {echo $passport_no[1];}}?>">
                                         </div>
                                </div>


                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Passport Issue Date </label>
                                        <div class="col-sm-8">
                                               <input  type="text" name="passport_issue_date"
                                                       class="form-control start_date datetimepicker4" value="<?php if(!empty($personal_info)){if(!empty($passport_issue_date[1])) {echo $passport_issue_date[1];}}?>"
                                                      >
                                        </div>
                                </div>

                                            <div class="form-group">
                                        <label class="col-sm-4 control-label">Passport Issue Place  </label>
                                        <div class="col-sm-8">
                                                <select class="form-control" name="passport_issue_place">
                                                     <option value="DFA Dubai" <?php if(!empty($personal_info)){if($passport_issue_place[1]=='DFA Dubai'){echo "selected";}};?>>DFA Dubai </option>
                                                    <option value="PCG Dubai" <?php if(!empty($personal_info)){if($passport_issue_place[1]=='PCG Dubai'){echo "selected";}};?>>PCG Dubai</option>
                                                  </select>
                                         </div>
                                </div>

                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Passport Expiry  </label>
                                        <div class="col-sm-8">
                                             <input  type="text" name="passport_expiry"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($personal_info)){if(!empty($passport_expiry[1])) {echo $passport_expiry[1];}}?>">
                                        </div>
                                </div>

                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Visa No.   </label>
                                        <div class="col-sm-8">
                                                <input type="text" class="form-control" name="visa_no" value="<?php if(!empty($personal_info)){if(!empty($visa_no[1])) {echo $visa_no[1];}}?>">
                                         </div>
                                </div>

                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Visa Type  </label>
                                        <div class="col-sm-8">
                                               <select class="form-control" name="visa_type">
                                                <option>Choose</option>
                                                    <option value="Visiting" <?php if(!empty($personal_info)){if($visa_type[1]=='Visiting'){echo "selected";}};?>>Visiting</option>
                                                    <option value="Government" <?php if(!empty($personal_info)){if($visa_type[1]=='Government'){echo "selected";}};?>>Government</option>
                                                    <option value="Employment" <?php if(!empty($personal_info)){if($visa_type[1]=='Employment'){echo "selected";}};?>>Employment</option>
                                                    <option value="Contract" <?php if(!empty($personal_info)){if($visa_type[1]=='Contract'){echo "selected";}};?>>Contract</option>
                                                    <option value="Temp Work Permit" <?php if(!empty($personal_info)){if($visa_type[1]=='Temp Work Permit'){echo "selected";}};?>>Temp. Work Permit</option>
                                                    <option value="OP" <?php if(!empty($personal_info)){if($visa_type[1]=='OP'){echo "selected";}};?>>OP</option>
                                                    <option value="V1" <?php if(!empty($personal_info)){if($visa_type[1]=='V1'){echo "selected";}};?>>V1</option>
                                                    <option value="V2" <?php if(!empty($personal_info)){if($visa_type[1]=='V2'){echo "selected";}};?>>V2</option>
                                                    <option value="V5" <?php if(!empty($personal_info)){if($visa_type[1]=='V5'){echo "selected";}};?>>V5</option>
                                                    <option value="V6" <?php if(!empty($personal_info)){if($visa_type[1]=='V6'){echo "selected";}};?>>V6</option>
                                                    <option value="V18" <?php if(!empty($personal_info)){if($visa_type[1]=='V18'){echo "selected";}};?>>V18</option>
                                                    <option value="Family Joining" <?php if(!empty($personal_info)){if($visa_type[1]=='Family Joining'){echo "selected";}};?>>Family Joining</option>
                                                </select>
                                         </div>
                                </div>
                                   <div class="form-group">
                                        <label class="col-sm-4 control-label">Visa Starting Date   </label>
                                        <div class="col-sm-8">
                                             <input  type="text" name="visa_strt_date"
                                                       class="form-control start_date datetimepicker4"
                                                      value="<?php if(!empty($personal_info)){if(!empty($visa_strt_date[1])) {echo $visa_strt_date[1];}}?>">
                                        </div>
                                </div>


                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Visa Expiry Date  </label>
                                        <div class="col-sm-8">
                                             <input  type="text" name="visa_expiry_date"
                                                       class="form-control start_date datetimepicker4"
                                                      value="<?php if(!empty($personal_info)){if(!empty($visa_expiry_date[1])) {echo $visa_expiry_date[1];}}?>">
                                        </div>
                                </div>

                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Visa Issue Place </label>
                                        <div class="col-sm-8">
                                                 <input type="text" class="form-control" name="visa_issue_place" value="<?php if(!empty($personal_info)){if(!empty($visa_issue_place[1])) {echo $visa_issue_place[1];}}?>">
                                        </div>
                                 </div>

                                  <div class="form-group">
                                        <label class="col-sm-4 control-label">Visa Company  </label>
                                        <div class="col-sm-8">
                                                 <input type="text" class="form-control" name="visa_company" value="<?php if(!empty($personal_info)){if(!empty($visa_company[1])) {echo $visa_company[1];}}?>">
                                        </div>
                                 </div>

                                  <div class="form-group">
                                        <label class="col-sm-4 control-label">Visa Proof </label>
                                        <div class="col-sm-8">
                                                 <input type="text" class="form-control" name="visa_proof" value="<?php if(!empty($personal_info)){if(!empty($visa_proof[1])) {echo $visa_proof[1];}}?>">
                                        </div>
                                 </div>

                                  <div class="form-group">
                                        <label class="col-sm-4 control-label">Driving License </label>
                                        <div class="col-sm-8">
                                                 <input type="text" class="form-control" name="driving_lic" value="<?php if(!empty($personal_info)){if(!empty($driving_lic[1])) {echo $driving_lic[1];}}?>">
                                        </div>
                                 </div>
  
                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Driving License Issue Date</label>
                                        <div class="col-sm-8">
                                              <input  type="text" name="driving_issue_date"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($personal_info)){if(!empty($driving_issue_date[1])) {echo $driving_issue_date[1];}}?>">
                                        </div>
                                 </div>

                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Driving License Expiry</label>
                                        <div class="col-sm-8">
                                                 <input type="text" class="form-control" name="driving_lic_exp" value="<?php if(!empty($personal_info)){if(!empty($driving_lic_exp[1])) {echo $driving_lic_exp[1];}}?>">
                                        </div>
                                 </div>

                                 <div class="form-group">
                                    Probation
                                        <label class="col-sm-4 control-label">Probation Period (Months) </label>
                                        <div class="col-sm-8">
                                                 <input type="text" class="form-control" name="prob_period" value="<?php if(!empty($personal_info)){if(!empty($prob_period[1])) {echo $prob_period[1];}}?>">
                                        </div>
                                 </div>

                                  <div class="form-group">
                                        <label class="col-sm-4 control-label">Confirmation Date</label>
                                        <div class="col-sm-8">
                                               <input  type="text" name="confirmation_date"
                                                       class="form-control start_date datetimepicker4" value="<?php if(!empty($personal_info)){if(!empty($confirmation_date[1])) {echo $confirmation_date[1];}}?>" >
                                        </div>
                                 </div>

                                  <div class="form-group">
                                    Contract
                                    <label class="checkbox-inline">
                                    <input type="checkbox" value="Temporary Employee" name="temp_emp" value="<?php if(!empty($personal_info)){if(!empty($temp_emp[1])) {echo $temp_emp[1];}}?>">
                                     Temporary Employee
                                </label>
                                 </div>

                                  <div class="form-group">
                                        <label class="col-sm-4 control-label">Contract expiry</label>
                                        <div class="col-sm-8">
                                                 <input type="text" name="contract_expiry"  class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($personal_info)){if(!empty($contract_expiry[1])) {echo $contract_expiry[1];}}?>">
                                        </div>
                                 </div>

                                  <div class="form-group">
                                        <label class="col-sm-4 control-label">Contract type </label>
                                        <div class="col-sm-8">
                                                 <input type="text" class="form-control" name="contract_type" value="<?php if(!empty($personal_info)){if(!empty($contract_type[1])) {echo $contract_type[1];}}?>">
                                        </div>
                                 </div>

                                 <div class="form-group">
                                    Health Card / Food Handler Certificate
                                        <label class="col-sm-4 control-label"> Card # </label>
                                        <div class="col-sm-8">
                                                 <input type="text" class="form-control" name="health_card" value="<?php if(!empty($personal_info)){if(!empty($health_card[1])) {echo $health_card[1];}}?>">
                                        </div>
                                 </div>


                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Issue Date  </label>
                                        <div class="col-sm-8">
                                            <input  type="text" name="issue_date_health_card"
                                                       class="form-control start_date datetimepicker4"
                                                       value="<?php if(!empty($personal_info)){if(!empty($issue_date_health_card[1])) {echo $issue_date_health_card[1];}}?>">
                                        </div>
                                 </div>


                                 <div class="form-group">
                                        <label class="col-sm-4 control-label">Expiry Date  </label>
                                        <div class="col-sm-8">
                         <input  type="text" name="expiry_date_health_card" class="form-control start_date datetimepicker4"  value="<?php if(!empty($personal_info)){if(!empty($expiry_date_health_card[1])) {echo $expiry_date_health_card[1];}}?>" >
                                        </div>
                                 </div>
                                    </div>

                                    <div class="col-sm-12">
                            <div class="panel panel-custom">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <strong>Educational Qualification</strong>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <table class="table table-bordered" style="width: 100%">
                                        <tr>
                                        <thead>
                                            <th>Name</th>
                                            <th>Year of Passing</th>
                                            <th>Specialization</th>
                                            <th>College/University Name</th>
                                        </thead>
                                        </tr>
                                        <tbody>
                                      <?php    
        if(!empty($clg_name[1])){
           $colg_name= explode('##',$clg_name[1]);
          }

          if(!empty($clg_yop[1])){
            $colg_yop=explode('##',$clg_yop[1]);
          }

          if(!empty($clg_specialization[1])){
            $colg_spec=explode('##',$clg_specialization[1]);
          }

          if(!empty($clg_college_university[1])){
            $colg_univ=explode('##',$clg_college_university[1]);
          }
          ?>
                                            <tr>
                                                <td><input type="text" name="name[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_name[0])) {echo $colg_name[0];}}?>"></td>
                                                <td><input type="text" name="yop[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_yop[0])) {echo $colg_yop[0];}}?>"></td>
                                                <td><input type="text" name="specialization[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_spec[0])) {echo $colg_spec[0];}}?>"></td>
                                                <td><input type="text" name="college_university[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_univ[0])) {echo $colg_univ[0];}}?>"></td>
                                            </tr>
                                             <tr>
                                               <td><input type="text" name="name[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_name[1])) {echo $colg_name[1];}}?>"></td>
                                                <td><input type="text" name="yop[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_yop[1])) {echo $colg_yop[1];}}?>"></td>
                                                <td><input type="text" name="specialization[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_spec[1])) {echo $colg_spec[1];}}?>"></td>
                                                <td><input type="text" name="college_university[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_univ[1])) {echo $colg_univ[1];}}?>"></td>
                                            </tr>
                                             <tr>
                                                <td><input type="text" name="name[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_name[2])) {echo $colg_name[2];}}?>"></td>
                                                <td><input type="text" name="yop[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_yop[2])) {echo $colg_yop[2];}}?>"></td>
                                                <td><input type="text" name="specialization[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_spec[2])) {echo $colg_spec[2];}}?>"></td>
                                                <td><input type="text" name="college_university[]" class="form-control" value="<?php if(!empty($personal_info)){if(!empty($colg_univ[2])) {echo $colg_univ[2];}}?>"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div><!-- ********************Allowance End ******************-->
                                
                             </div>
                              
                        </div>
<?php if(!empty($emp_details))
    {
    $leave_details=explode('$#$',$emp_details[0]->et_leave_details);
   // pre_list($leave_details);
     $offshore_basic=explode(':',$leave_details[0]);
        $offshore_currency=explode(':',$leave_details[1]);
        $vacation_calc_date=explode(':',$leave_details[2]);
        $gratuity_calc_date=explode(':',$leave_details[3]);
        $amount=explode(':',$leave_details[4]);
        $air_ticket_self=explode(':',$leave_details[5]);
        $air_ticket_dependant=explode(':',$leave_details[6]);
        $per_days_worked=explode(':',$leave_details[7]);
        $air_ticket_off_shore=explode(':',$leave_details[8]);
        $per_days_work_off_shore=explode(':',$leave_details[9]);
        $leaves=explode(':',$leave_details[10]);
         $travel_days=explode(':',$leave_details[11]);
          $leaves_off_shore=explode(':',$leave_details[12]); 
       
        $per_days_worked_off_shore=explode(':',$leave_details[13]);
        $total_days_worked_bf=explode(':',$leave_details[14]);
        $total_days_worked_bf_off_shore=explode(':',$leave_details[15]);
        $leave_bf=explode(':',$leave_details[16]);
        $paid_days_bf=explode(':',$leave_details[17]);
        $leaves_bf=explode(':',$leave_details[18]);
        $air_ticket_bf_self=explode(':',$leave_details[19]);
        $air_ticket_bf_dependant=explode(':',$leave_details[20]);
        $total_lop=explode(':',$leave_details[21]);
        $last_vacation_date=explode(':',$leave_details[22]);
}?>
                            <div class="tab-pane" id="leave_details_tab">
    
                            <div class="panel-body">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Offshore Basic  </label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($offshore_basic[1])) {echo $offshore_basic[1];}}?>" name="offshore_basic">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Offshore Currency </label>
                                        <div class="col-sm-8">
                                            <select class="form-control" name="offshore_currency">
                                                      <option value="AED" <?php if(!empty($leave_details)){if($offshore_currency[1]=='AED'){echo "selected";}};?>>AED</option>
                                                    <option value="USD" <?php if(!empty($leave_details)){if($offshore_currency[1]=='USD'){echo "selected";}};?>>USD</option>
                                                    <option value="EURO" <?php if(!empty($leave_details)){if($offshore_currency[1]=='EURO'){echo "selected";}};?>>EURO</option>
                                                    <option value="OMR" <?php if(!empty($leave_details)){if($offshore_currency[1]=='OMR'){echo "selected";}};?>>OMR</option>
                                                    <option value="GBP" <?php if(!empty($leave_details)){if($offshore_currency[1]=='GBP'){echo "selected";}};?>>GBP</option>
                                                    <option value="QAR" <?php if(!empty($leave_details)){if($offshore_currency[1]=='QAR'){echo "selected";}};?>>QAR</option>
                                                </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label
                                                class="col-sm-4 control-label">Vacation Calculated Date</label>
                                        <div class="col-sm-8">
                                               <input  type="text" name="vacation_calc_date" class="form-control start_date datetimepicker4" value="<?php if(!empty($leave_details)){if(!empty($vacation_calc_date[1])) {echo $vacation_calc_date[1];}}?>">
                                         </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Gratuity Calculated Date </label>
                                        <div class="col-sm-8">
                                                <input  type="text" name="gratuity_calc_date" class="form-control start_date datetimepicker4" value="<?php if(!empty($leave_details)){if(!empty($gratuity_calc_date[1])) {echo $gratuity_calc_date[1];}}?>" >
                                        </div>
                                    </div>
                                   
                                <div class="form-group">
                                        <label class="col-sm-4 control-label">Amount </label>
                                        <div class="col-sm-8">
                                        <input  type="text" name="amount" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($amount[1])) {echo $amount[1];}}?>">
                                        </div>
                                </div>
                                 
                               
                                      <div class="form-group"> Vacation Details / Air Ticket Details
                                        <label class="col-sm-4 control-label">Air Ticket for Self</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="air_ticket_self" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($air_ticket_self[1])) {echo $air_ticket_self[1];}}?>">
                                        </div>
                                    </div>
       
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Air Ticket for Dependants</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="air_ticket_dependant" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($air_ticket_dependant[1])) {echo $air_ticket_dependant[1];}}?>">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                         <label class="col-sm-4 control-label">Per Days Worked </label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="per_days_worked" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($per_days_worked[1])) {echo $per_days_worked[1];}}?>">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                         <label class="col-sm-4 control-label">Air Ticket(Off Shore)</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="air_ticket_off_shore" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($air_ticket_off_shore[1])) {echo $air_ticket_off_shore[1];}}?>">
                                        </div>
                                    </div>

                                     <div class="row">
                                     <div class="form-group">
                                         <label class="col-sm-4 control-label">Per Days Worked(Off Shore) </label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="per_days_work_off_shore" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($per_days_work_off_shore[1])) {echo $per_days_work_off_shore[1];}}?>">
                                        </div>
                                    </div>
                                </div>
                           <div class="form-group">
                                    Slabs for Vacation
                                        <label class="col-sm-4 control-label">Leaves</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="leaves" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($leaves[1])) {echo $leaves[1];}}?>">
                                        </div>
                                    </div>
                              
                                    <div class="form-group">
                                         <label class="col-sm-4 control-label">Per Days Worked </label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="per_days_worked" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($per_days_worked[1])) {echo $per_days_worked[1];}}?>">
                                        </div>
                                    </div>

                                     <div class="form-group">
                                         <label class="col-sm-4 control-label">Travel Days </label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="travel_days" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($travel_days[1])) {echo $travel_days[1];}}?>">
                                        </div>
                                    </div>

                                     <div class="form-group">
                                         <label class="col-sm-4 control-label">Leaves(Off Shore)</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="leaves_off_shore" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($leaves_off_shore[1])) {echo $leaves_off_shore[1];}}?>">
                                        </div>
                                    </div>

                                      <div class="form-group">
                                         <label class="col-sm-4 control-label">Per Days Worked(Off Shore)</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="per_days_worked_off_shore" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($per_days_worked_off_shore[1])) {echo $per_days_worked_off_shore[1];}}?>">
                                        </div>
                                    </div>
                                   
                                    <div class="form-group">
                                         <label class="col-sm-4 control-label">Total Days Worked B/f from last vacation</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="total_days_worked_bf" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($total_days_worked_bf[1])) {echo $total_days_worked_bf[1];}}?>">
                                        </div>
                                    </div>

                                      <div class="form-group">
                                         <label class="col-sm-4 control-label">Total Days Worked B/f from last vacation(Off Shore)</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="total_days_worked_bf_off_shore" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($total_days_worked_bf_off_shore[1])) {echo $total_days_worked_bf_off_shore[1];}}?>">
                                        </div>
                                    </div>

                                     <div class="form-group">
                                         <label class="col-sm-4 control-label">Leaves B/f </label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="leave_bf" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($leave_bf[1])) {echo $leave_bf[1];}}?>">
                                        </div>
                                    </div>

                                     <div class="form-group">
                                         <label class="col-sm-4 control-label">Paid Days B/f</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="paid_days_bf" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($paid_days_bf[1])) {echo $paid_days_bf[1];}}?>">
                                        </div>
                                    </div>

                                      <div class="form-group">
                                         <label class="col-sm-4 control-label">Leaves B/f(Off Shore)</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="leaves_bf" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($leaves_bf[1])) {echo $leaves_bf[1];}}?>">
                                        </div>
                                    </div>

                                     <div class="form-group">
                                         <label class="col-sm-4 control-label">Air Tickets B/f self </label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="air_ticket_bf_self" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($air_ticket_bf_self[1])) {echo $air_ticket_bf_self[1];}}?>">
                                        </div>
                                    </div>

                                      <div class="form-group">
                                         <label class="col-sm-4 control-label">Air Tickets B/f Dependants</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="air_ticket_bf_dependant" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($air_ticket_bf_dependant[1])) {echo $air_ticket_bf_dependant[1];}}?>">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                         <label class="col-sm-4 control-label">Total LOP</label>
                                        <div class="col-sm-8">
                                           <input  type="text" name="total_lop" class="form-control" value="<?php if(!empty($leave_details)){if(!empty($total_lop[1])) {echo $total_lop[1];}}?>">
                                        </div>
                                    </div>

                                     <div class="form-group">
                                         <label class="col-sm-4 control-label">Last Vacation Date</label>
                                        <div class="col-sm-8">
                                            <input  type="text" name="last_vacation_date" class="form-control start_date datetimepicker4" value="<?php if(!empty($leave_details)){if(!empty($last_vacation_date[1])) {echo $last_vacation_date[1];}}?>" >
                                        </div>
                                    </div>

                             </div>
                            
                        </div>
                     <?php if(!empty($emp_details))
    {
    $earning_details=explode('$#$',$emp_details[0]->et_earnings);
    
     $hra_value=explode(':',$earning_details[0]);
        $hra_account=explode(':',$earning_details[1]);
        $oa_value=explode(':',$earning_details[2]);
        $oa_account=explode(':',$earning_details[3]);
        $fa_value=explode(':',$earning_details[4]);
        $fa_account=explode(':',$earning_details[5]);
        $transp_value=explode(':',$earning_details[6]);
        $transp_account=explode(':',$earning_details[7]);
        $incentive_value=explode(':',$earning_details[8]);
        $incentive_account=explode(':',$earning_details[9]);
        $allowance_value=explode(':',$earning_details[10]);
        $allowance_account=explode(':',$earning_details[11]);
        $veh_allowance_value=explode(':',$earning_details[12]);
        $veh_allowance_account=explode(':',$earning_details[13]);
        $food_allowance_value=explode(':',$earning_details[14]);
        $food_allowance_account=explode(':',$earning_details[15]);
        $fixed_ot_value=explode(':',$earning_details[16]);
        $fixed_ot_account=explode(':',$earning_details[17]);
     }?>    
                        <div class="tab-pane" id="earnings">
                          
                             <div class="panel-body">
                                    
                                    <table class="table table-bordered">
                                        <thead>
                                            <th>Earnings</th>
                                            <th>Value</th>
                                            <th>Account</th>
                                          </thead>
                                          <tbody>
                                        <tr>
                                            <td><b>HRA </b></td>
                                           <td><input type="text" class="form-control" name="hra_value" value="<?php if(!empty($earning_details)){if(!empty($hra_value[1])) {echo $hra_value[1];}}?>"></td>
                                            <td><input type="text" class="form-control" name="hra_account" value="<?php if(!empty($earning_details)){if(!empty($hra_account[1])) {echo $hra_account[1];}}?>"></td>
                                        </tr>
                                        <tr>
                                            <td><b>Other Allowance </b></td>
                                           <td><input type="text" class="form-control" name="oa_value" value="<?php if(!empty($earning_details)){if(!empty($oa_value[1])) {echo $oa_value[1];}}?>"></td>
                                            <td><input type="text" class="form-control" name="oa_account" value="<?php if(!empty($earning_details)){if(!empty($oa_account[1])) {echo $oa_account[1];}}?>"></td>
                                        </tr>
                                        <tr>
                                            <td><b>Family Allowance </b></td>
                                           <td><input type="text" class="form-control" name="fa_value" value="<?php if(!empty($earning_details)){if(!empty($fa_value[1])) {echo $fa_value[1];}}?>"></td>
                                            <td><input type="text" class="form-control" name="fa_account" value="<?php if(!empty($earning_details)){if(!empty($fa_account[1])) {echo $fa_account[1];}}?>"></td>
                                        </tr>
                                        <tr>
                                            <td><b> Transportation</b></td>
                                           <td><input type="text" class="form-control" name="transp_value" value="<?php if(!empty($earning_details)){if(!empty($transp_value[1])) {echo $transp_value[1];}}?>"></td>
                                            <td><input type="text" class="form-control" name="transp_account" value="<?php if(!empty($earning_details)){if(!empty($transp_account[1])) {echo $transp_account[1];}}?>"></td>
                                        </tr>
                                        <tr>
                                            <td><b> Incentive(M)</b></td>
                                           <td><input type="text" class="form-control" name="incentive_value" value="<?php if(!empty($earning_details)){if(!empty($incentive_value[1])) {echo $incentive_value[1];}}?>"></td>
                                            <td><input type="text" class="form-control" name="incentive_account" value="<?php if(!empty($earning_details)){if(!empty($incentive_account[1])) {echo $incentive_account[1];}}?>"></td>
                                        </tr>
                                        <tr>
                                            <td><b>Allowance(M) </b></td>
                                           <td><input type="text" class="form-control" name="allowance_value"value="<?php if(!empty($earning_details)){if(!empty($allowance_value[1])) {echo $allowance_value[1];}}?>"></td>
                                            <td><input type="text" class="form-control" name="allowance_account"value="<?php if(!empty($earning_details)){if(!empty($allowance_account[1])) {echo $allowance_account[1];}}?>"></td>
                                        </tr>
                                        <tr>
                                            <td><b>Vehicle Allowance</b></td>
                                           <td><input type="text" class="form-control" name="veh_allowance_value"value="<?php if(!empty($earning_details)){if(!empty($veh_allowance_value[1])) {echo $veh_allowance_value[1];}}?>"></td>
                                            <td><input type="text" class="form-control" name="veh_allowance_account"value="<?php if(!empty($earning_details)){if(!empty($veh_allowance_account[1])) {echo $veh_allowance_account[1];}}?>"></td>
                                        </tr>
                                        <tr>
                                            <td><b> Food Allowance</b></td>
                                           <td><input type="text" class="form-control" name="food_allowance_value"value="<?php if(!empty($earning_details)){if(!empty($food_allowance_value[1])) {echo $food_allowance_value[1];}}?>"></td>
                                            <td><input type="text" class="form-control" name="food_allowance_account"value="<?php if(!empty($earning_details)){if(!empty($food_allowance_account[1])) {echo $food_allowance_account[1];}}?>"></td>
                                        </tr>
                                        <tr>
                                            <td><b>Fixed OT </b></td>
                                           <td><input type="text" class="form-control" name="fixed_ot_value"value="<?php if(!empty($earning_details)){if(!empty($fixed_ot_value[1])) {echo $fixed_ot_value[1];}}?>"></td>
                                            <td><input type="text" class="form-control" name="fixed_ot_account"value="<?php if(!empty($earning_details)){if(!empty($fixed_ot_account[1])) {echo $fixed_ot_account[1];}}?>"></td>
                                        </tr>                                      
                                    </tbody>
                                    </table>
                             </div>
                        </div>
                         <div class="tab-pane" id="fileupload">
                          
<div class="panel-body">
     <div class="col-md-12 col-sm-12">
		<div class="form-group">
		<label class="control-label">Passport size photo</label>
		<input type="file" multiple="" name="emp_pic[]" class="form-control class_pic_upload">
		<?php
		if(!empty($pic_name[1]))
		{
            ?>
            <a href="<?php echo base_url('uploads/employee_data/'.$folder_name.'/'.$pic_name[1]);?>" download="">
                <i class='fa fa-file-image-o fa-3x' style='color:red;'></i></a>
		<?php
		}?>

		<div class="form_error">  <?php echo $this->session->flashdata('emp_pic');?></div>
		</div>
	</div>

								
<div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="control-label">Job Offer Letter</label>
<input type="file" multiple="" name="jol[]" class="form-control class_jo_upload">
<?php
        if(!empty($job_offer_letter[1]))
        {
            ?>
<a href="<?php echo base_url('uploads/employee_data/'.$folder_name.'/'.$job_offer_letter[1]);?>" download="">
    <i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i></a>
<?php
}?>
<div class="form_error">  <?php echo $this->session->flashdata('jol');?></div>
</div>
</div>
<div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="control-label">Employment Contract letter</label>
<input type="file" multiple="" name="emp_ltr[]" class="form-control">
<?php
        if(!empty($employee_contract[1]))
        {
            ?>
<a href="<?php echo base_url('uploads/employee_data/'.$folder_name.'/'.$employee_contract[1]);?>" download="">
  <i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i></a>
  <?php
}?>
<div class="form_error">  <?php echo $this->session->flashdata('emp_ltr');?></div>
</div>
</div>
<div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="control-label">Visa Copy</label>
<input type="file" multiple="" name="visa_copy[]" class="form-control">
<?php
        if(!empty($visa_copy[1]))
        {
            ?>
<a href="<?php echo base_url('uploads/employee_data/'.$folder_name.'/'.$visa_copy[1]);?>" download="">
  <i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i></a>
  <?php
}?>
<div class="form_error">  <?php echo $this->session->flashdata('visa_copy');?></div>
</div>
</div>
<div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="control-label">Passport Copy</label>
<input type="file" multiple="" name="psprt[]" class="form-control">
<?php
        if(!empty($passport_copy[1]))
        {
            ?>
<a href="<?php echo base_url('uploads/employee_data/'.$folder_name.'/'.$passport_copy[1]);?>" download="">
  <i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i></a>
  <?php
}?>
<div class="form_error">  <?php echo $this->session->flashdata('psprt');?></div>
</div>
</div>
<div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="control-label">Emirates id Copy</label>
<input type="file" multiple="" name="emirts_copy[]" class="form-control">
<?php
        if(!empty($emirates_id_copy[1]))
        {
            ?>
<a href="<?php echo base_url('uploads/employee_data/'.$folder_name.'/'.$emirates_id_copy[1]);?>" download="">
  <i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i></a>
  <?php
}?>
<div class="form_error">  <?php echo $this->session->flashdata('emirts_copy');?></div>
</div>
</div>
<div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="control-label">Driving License Copy</label>
<input type="file" multiple="" name="driving_licence[]" class="form-control">
<?php
        if(!empty($driving_license_copy[1]))
        {
            ?>
<a href="<?php echo base_url('uploads/employee_data/'.$folder_name.'/'.$driving_license_copy[1]);?>" download="">
  <i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i></a>
  <?php
}?>
<div class="form_error">  <?php echo $this->session->flashdata('driving_licence');?></div>
</div>
</div>

<br/><br/>

                                    <div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
                            </div>
                            
                        </div>

            </div>
          


<?php echo form_close();?>
        </div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
  $(function () {
        $('.datetimepicker4').datepicker();
    });
  
      

</script>




</html>