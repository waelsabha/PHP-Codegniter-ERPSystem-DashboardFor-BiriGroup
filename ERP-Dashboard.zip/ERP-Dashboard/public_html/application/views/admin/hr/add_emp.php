<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
.countrypicker{
	max-height:100px;
}
.fa-whatsapp  {
  color:#fff;
  background:
  linear-gradient(#25d366,#25d366)10px 84%/15px 15px no-repeat,
  radial-gradient(#25d366 59%,transparent 0);
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<section class="panel">
<header class="panel-heading">
<div class="panel-actions">
<a href="#" class="fa fa-caret-down"></a>
<a href="#" class="fa fa-times"></a>
</div>
<h2 class="panel-title">Employee details</h2>
<p class="panel-subtitle">
Add employee details
</p>
</header>
<?php echo
form_open_multipart('submit_emp_office');?>

<div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
      <p class="required"> Fileds marked as '::*::' are required fields</p>

   <input type="hidden" name="edit_emp_id" value="<?php  if(!empty($result[0]->ed_id)) echo $result[0]->ed_id;?>"> 

<input type="hidden" name="edit_pic" value="<?php  if(!empty($result[0]->ed_pic)) echo $result[0]->ed_pic;?>">
<input type="hidden" name="edit_jo" value="<?php  if(!empty($result[0]->ed_jol)) echo $result[0]->ed_jol;?>">
<input type="hidden" name="edit_el" value="<?php  if(!empty($result[0]->ed_emp_ltr)) echo $result[0]->ed_emp_ltr;?>">
<input type="hidden" name="edit_vc" value="<?php  if(!empty($result[0]->ed_visa)) echo $result[0]->ed_visa;?>">
<input type="hidden" name="edit_pc" value="<?php  if(!empty($result[0]->ed_psprt)) echo $result[0]->ed_psprt;?>">
<input type="hidden" name="edit_eidc" value="<?php  if(!empty($result[0]->ed_emirates_id)) echo $result[0]->ed_emirates_id;?>">     

<div class="panel-body">
<div class="row">

<div class="col-md-6">
<div class="form-group">
<label class="control-label">Choose Employee<abbr class="required">::*::</abbr></label>
<select data-plugin-selectTwo class="form-control populate" name="login_emp_id" required="">
		<option></option>
		<?php
		foreach($login_emp as $c)
			{
				?>
		<option value="<?php echo $c->log_id;?>" <?php if((!empty($result[0]->ed_login_id))){if($result[0]->ed_login_id ==$c->log_id){echo "selected";}} ?> ><?php echo $c->log_uname;?></option>
		<?php
	}?>
	</select>
<div class="form_error">  <?php echo $this->session->flashdata('login_emp_id');?></div>
</div>
</div>
</div>

<div class="row">

<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Employee Name<abbr class="required">::*::</abbr></label>
<input type="text" name="emp_name" class="form-control" required="" value="<?php  if(!empty($result[0]->ed_name)) echo $result[0]->ed_name;?>">
<div class="form_error">  <?php echo $this->session->flashdata('emp_name');?></div>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Position Name<abbr class="required">::*::</abbr></label>
<input type="text" name="pos_name" class="form-control" required="" value="<?php  if(!empty($result[0]->ed_pos)) echo $result[0]->ed_pos;?>">
<div class="form_error">  <?php echo $this->session->flashdata('pos_name');?></div>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Date of Joining<abbr class="required">::*::</abbr></label>
<input type="text" name="doj" class="form-control" id='datetimepicker4'   required="" value="<?php  if(!empty($result[0]->ed_doj)){
	$new_date=date("m/d/Y", strtotime($result[0]->ed_doj));
echo $new_date;
} ?>"/>
<div class="form_error">  <?php echo $this->session->flashdata('doj');?></div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Nationality<abbr class="required">::*::</abbr></label>
<select data-plugin-selectTwo class="form-control populate" name="country" required="">
		<option></option>
		<?php
		foreach($country as $c)
			{
				?>
		<option value="<?php echo $c->country_id;?>" <?php if((!empty($result[0]->ed_nationality))){if($result[0]->ed_nationality==$c->country_id){echo "selected";}} ?> ><?php echo $c->name;?></option>
		<?php
	}?>
	</select>
<div class="form_error">  <?php echo $this->session->flashdata('country');?></div>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Gender<abbr class="required">::*::</abbr></label><br/>
<label class="radio-inline">
	<input type="radio" name="gender" value="1" required="" <?php if((!empty($result[0]->ed_gender))){if($result[0]->ed_gender=='1'){echo "checked";}} ?>> Male
	</label>
	<label class="checkbox-inline">
	<input type="radio" name="gender" value="2" required="" <?php if((!empty($result[0]->ed_gender))){if($result[0]->ed_gender=='2'){echo "checked";}} ?>> Female
	</label>
	<div class="form_error">  <?php echo $this->session->flashdata('gender');?></div>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Maritial Status<abbr class="required">::*::</abbr></label><br/>
<label class="radio-inline">
		<input type="radio" name="maritial_sts" value="1" required="" <?php if((!empty($result[0]->ed_martial_sts))){if($result[0]->ed_martial_sts=='1'){echo "checked";}} ?>> Married
	</label>
	<label class="checkbox-inline">
	<input type="radio" name="maritial_sts" value="2" required="" <?php if((!empty($result[0]->ed_martial_sts))){if($result[0]->ed_martial_sts=='2'){echo "checked";}} ?>> Un-Married
	</label>
	<div class="form_error">  <?php echo $this->session->flashdata('maritial_sts');?></div>
</div>
</div>

</div>
<div class="row">
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Mobile No:<abbr class="required">::*::</abbr></label>
<input type="text" name="mobile_num" class="form-control" required="" value="<?php if((!empty($result[0]->ed_mob))){ echo $result[0]->ed_mob;} ?>" />
<div class="form_error">  <?php echo $this->session->flashdata('mobile_num');?></div>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Branch/working location<abbr class="required">::*::</abbr></label>
<select class="form-control" name="branch" required="">
	<option>Choose</option>
	<option value="1" <?php if((!empty($result[0]->ed_branch))){if($result[0]->ed_branch=='1'){echo "selected";}} ?>>Garhoud-HO</option>
	<option value="2" <?php if((!empty($result[0]->ed_branch))){if($result[0]->ed_branch=='2'){echo "selected";}} ?>>Baniyas Shop</option>
	<option value="3" <?php if((!empty($result[0]->ed_branch))){if($result[0]->ed_branch=='3'){echo "selected";}} ?>>Deira Shop</option>
	<option value="4" <?php if((!empty($result[0]->ed_branch))){if($result[0]->ed_branch=='4'){echo "selected";}} ?>>Ras Al khoor Store</option>
	<option value="5" <?php if((!empty($result[0]->ed_branch))){if($result[0]->ed_branch=='5'){echo "selected";}} ?>>Dragon Shop</option>
	<option value="6" <?php if((!empty($result[0]->ed_branch))){if($result[0]->ed_branch=='6'){echo "selected";}} ?>>RAK Factory</option>
	<option value="7" <?php if((!empty($result[0]->ed_branch))){if($result[0]->ed_branch=='7'){echo "selected";}} ?>>KSA Riyadh</option>
</select>
<div class="form_error">  <?php echo $this->session->flashdata('branch');?></div>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Passport size photo</label>
<input type="file" multiple="" name="emp_pic[]" class="form-control class_pic_upload">
<?php
if(!empty($result[0]->ed_pic))
{
echo "<i class='fa fa-file-image-o fa-3x' style='color:red;'></i>";
}?>

<div class="form_error">  <?php echo $this->session->flashdata('emp_pic');?></div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Job Offer Letter</label>
<input type="file" multiple="" name="jol[]" class="form-control class_jo_upload">
<?php
if(!empty($result[0]->ed_jol))
{
echo "<i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i>";
}?>
<div class="form_error">  <?php echo $this->session->flashdata('jol');?></div>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Employment letter</label>
<input type="file" multiple="" name="emp_ltr[]" class="form-control">
<?php
if(!empty($result[0]->ed_emp_ltr))
{
echo "<i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i>";
}?>
<div class="form_error">  <?php echo $this->session->flashdata('emp_ltr');?></div>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Visa Copy</label>
<input type="file" multiple="" name="visa_copy[]" class="form-control">
<?php
if(!empty($result[0]->ed_visa))
{
echo "<i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i>";
}?>
<div class="form_error">  <?php echo $this->session->flashdata('visa_copy');?></div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Passport Copy</label>
<input type="file" multiple="" name="psprt[]" class="form-control">
<?php
if(!empty($result[0]->ed_psprt))
{
echo "<i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i>";
}?>
<div class="form_error">  <?php echo $this->session->flashdata('psprt');?></div>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Emirates id Copy</label>
<input type="file" multiple="" name="emirts_copy[]" class="form-control">
<?php
if(!empty($result[0]->ed_emirates_id))
{
echo "<i class='fa fa-file-pdf-o fa-3x' style='color:red;'></i>";
}?>
<div class="form_error">  <?php echo $this->session->flashdata('emirts_copy');?></div>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Vacation date</label>
<input type="text" name="vac_date" class="form-control" id='datetimepicker6'  value="<?php  if(!empty($result[0]->ed_vacation_date)){
	$new_date=date("m/d/Y", strtotime($result[0]->ed_vacation_date));
echo $new_date;
} ?>" />
<div class="form_error">  <?php echo $this->session->flashdata('vac_date');?></div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Ticket Status </label><br/>
 	<label class="radio-inline">
	<input type="radio" name="ticket_sts" value="1"  <?php if((!empty($result[0]->ed_tkt_sts))){if($result[0]->ed_tkt_sts=='1'){echo "checked";}} ?>> Paid by company
	</label>
	<label class="checkbox-inline">
	<input type="radio" name="ticket_sts" value="2"  <?php if((!empty($result[0]->ed_tkt_sts))){if($result[0]->ed_tkt_sts=='2'){echo "checked";}} ?>> Self-Paid
	</label>
	<div class="form_error">  <?php echo $this->session->flashdata('ticket_sts');?></div>
</div>
</div>

<div class="col-md-4 col-sm-4">
<div class="form-group">
<label class="control-label">Sick leave salary</label>
<input type="text" name="sick_salary" class="form-control" value="<?php if((!empty($result[0]->ed_sick_leave_pay))){echo $result[0]->ed_sick_leave_pay;} ?>">
<div class="form_error">  <?php echo $this->session->flashdata('sick_salary');?></div>
</div>
</div>
</div>
</div>
<footer class="panel-footer">
<button type="submit" class="btn btn-primary">Submit</button>
</footer>
</section>
<br/><br/><br/>
<?php echo form_close();?>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
  $(function () {
        $('#datetimepicker4').datepicker();
    });
  
      $(function () {
        $('#datetimepicker6').datepicker();
    });

      $(document).ready(function()
	{
		var edit_pic=$("input[name='edit_pic']").val();
		if(edit_pic!='')
		{
		$('.class_pic_upload').prop('required',false);
		}

		var edit_jo=$("input[name='edit_jo']").val();
		if(edit_jo!='')
		{
			$('.class_jo_upload').prop('required',false);
		}
	});

</script>




</html>