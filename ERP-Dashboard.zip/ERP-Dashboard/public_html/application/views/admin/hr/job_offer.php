<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" rel="stylesheet"  type='text/css'>


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
.countrypicker{
	max-height:100px;
}
.fa-whatsapp  {
  color:#fff;
  background:
  linear-gradient(#25d366,#25d366)10px 84%/15px 15px no-repeat,
  radial-gradient(#25d366 59%,transparent 0);
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Create Job Offer </h2>
</header>
<div class="panel-body">
		<?php echo form_open_multipart('Careers/submit_job_offer','class="myform" novalidate','');?>

		<input type="hidden" name="update_job_offer" value=" <?php if(!empty($result[0]->job_id)) {echo $result[0]->job_id ;} else {echo -1;};  ?>"> 
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

 <!--   <input type="hidden" name="update_job_offer" value=" // if(!empty($result[0]->job_id)) echo $result[0]->job_id;"> -->
  
  
<div class="row">
<div class="col-md-12 table-rows-border">
	<div class="col-md-6 col-sm-12">


</div>

</div>
</div>


<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	




<div class="col-md-6 col-sm-12">

  <div class="form-group">
           <label class="col-sm-4 control-label">Recipent Name <abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8">
                    <input type="text"  class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->job_id)){echo $result[0]->jo_recipt_name;}}else{}?>"  name="jo_recipt_name">
              </div>
                  </div>


</div>

<div class="col-md-6 col-sm-12">

  <div class="form-group">
           <label class="col-sm-4 control-label">Recipent Name Arabic <abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8">
                    <input type="text"  class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->job_id)){echo $result[0]->jo_recipt_name_ar;}}else{}?>"  name="jo_recipt_name_ar">
              </div>
                  </div>


</div>



</div>
</div>



<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	




<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Chose Nationality<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control" name="jo_recipt_nationality">

		<option value="">Choose</option>
		<?php
		foreach($nationality as $na)
		{
			?>      
		<option value="<?php echo $na->country_id;?>" <?php if(!empty($result[0]->job_id)){if($result[0]->jo_recipt_nationality==$na->country_id){echo "selected";}};?> ><?php echo $na->name;?></option>		
			<?php
		}   
		?>                        
	</select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('name');?></div>
</div>
</div>

</div>


<div class="form-group">
<label  for="inputSuccess">Choose Language<abbr class="required">::*::</abbr></label>
		<div class="col-md-6">
		<div class="checkbox">
		 <div class="col-sm-4">
		<input type="checkbox" name="languages[]" value="english" <?php if(!empty($result[0]->job_id)){if($result[0]->languages='english'){echo "checked";}}?>>English
		 <div class="col-sm-4">
		</div>
		</div>
		 <div class="col-sm-4">
		<input type="checkbox" name="languages[]" value="arabic" <?php if(!empty($result[0]->job_id)){if($result[0]->languages='arabic'){echo "checked";}}?>>
		Arabic
		 </div>
		</div>
	
		</div>

<div class="form_error">  <?php echo $this->session->flashdata('languages');?></div>	
</div>







</div>
</div>






















<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	
<div class="col-md-6 col-sm-12">


  <div class="form-group">
           <label class="col-sm-4 control-label">Contact Number<abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8">
                    <input type="text"  class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->job_id)){echo $result[0]->jo_phone;}}else{}?>"  name="jo_phone">
              </div>
                  </div>

</div>
<div class="col-md-6 col-sm-12">


  <div class="form-group">
           <label class="col-sm-4 control-label">EMAIL<abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8">
                    <input type="email"  class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->job_id)){echo $result[0]->jo_email;}}else{}?>"   name="jo_email">
              </div>
                  </div>


</div>
</div>
</div>





<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Chose Company<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control" name="master_company">

		<option value="">Choose</option>
		<?php
		foreach($master_company as $ms)
		{
			?>
		 <option value="<?php echo $ms->mcomp_id;?>" <?php if(!empty($result[0]->job_id)){if($result[0]->jo_branch==$ms->mcomp_id){echo "selected";}};?> ><?php echo $ms->mcomp_name;?></option>	
			<?php  
		}
		?>    
 
	</select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('mcomp_name');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Chose Position<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control" name="position_name">

		<option value="">Choose</option>
		<?php
		foreach($position_name as $pn)
		{
			?>
	<option value="<?php echo  $pn->pos_id;?>" <?php if(!empty($result[0]->job_id)){if($result[0]->jo_position_id== $pn->pos_id){echo "selected";}};?> ><?php echo $pn->position_name;?></option>		
			<?php
		}
		?>    
	</select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('position_name');?></div>
</div>
</div>

</div>
</div>
</div>

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Contract Period (Year)<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	
	<select  class="form-control" name="jo_contract_yr_num" required="">
  

  <option  value="<?php if(!empty($result)){if(!empty($result[0]->jo_contract_yr_num)){echo $result[0]->jo_contract_yr_num;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->jo_contract_yr_num)){echo $result[0]->jo_contract_yr_num;}}else{echo "Select ";}?> </option>






 <option value="1">1</option>
 

 <option value="3">3</option>

  <option value="2">2</option>
 </select>


  

</div>
</div>

</div>

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Chose Working Hour<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<!--	<select  class="form-control" name="jo_working_hours" required="">
  <option value="">Choose</option>
 <option value="4" selected="" <?php  echo "selected";?> >4</option>
 <option value="8" selected="" <?php  echo "selected";?> >8</option>
 <option value="10" selected="" <?php  echo "selected";?> >10</option>
 <option value="12" selected="" <?php  echo "selected";?> >up to 12</option>
 </select>
-->
 <input type="number" class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->job_id)){echo $result[0]->jo_working_hours;}}else{echo "8";}?>" name="jo_working_hours">
 <div class="form_error">  <?php echo $this->session->flashdata('jo_working_hours');?></div>
</div>
</div>

</div>
</div>
</div>


<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Termination From Employee/Month (0 means not possible)<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	
<select  class="form-control" name="termination_employee" required="">
 
  <option  value="<?php if(!empty($result)){if(!empty($result[0]->termination_employee)){echo $result[0]->termination_employee;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->termination_employee)){echo $result[0]->termination_employee;}}else{echo "Select ";}?> </option>

 <option value="1">1 month</option>
 <option value="2">2 month</option>
 <option value="3">3 month</option>
  <option value="0" > 0 Not possible</option>


 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('termination_employee');?></div>
  

</div>
</div>

</div>

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Termination From Employer/Month :<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select  class="form-control" name="termination_employer" required="">

 <option  value="<?php if(!empty($result)){if(!empty($result[0]->termination_employer)){echo $result[0]->termination_employer;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->termination_employer)){echo $result[0]->termination_employer;}}else{echo "Select ";}?> </option>
 <option value="0" >Not possible</option>
 <option value="1" >1 month</option>
 
 <option value="3" >3 month</option>
 <option value="2" >2 month</option>
 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('termination_employer');?></div>
</div>
</div>

</div>
</div>
</div>





<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Posibility of Increment <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	
<select  class="form-control" name="increment_sts" required="">

  <option  value="<?php if(!empty($result)){if(!empty($result[0]->increment_sts)){echo $result[0]->increment_sts;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->increment_sts)){echo $result[0]->increment_sts;}}else{echo "Select ";}?> </option>

 <option value="0" >None</option>
 <option value="12" >12 months</option>
 <option value="6">6 months</option>
 


 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('increment_sts');?></div>
  

</div>
</div>



<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Amount of first Increment <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	
 <input type="Number" id="increment_amount_id" class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->job_id)){echo $result[0]->increment_amount;}}else{}?>" min="500" max="10000" name="increment_amount">

  

</div>
</div>






</div>

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Probation Period :<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select  class="form-control" name="probation_period" required="">
   <option  value="<?php if(!empty($result)){if(!empty($result[0]->probation_period)){echo $result[0]->probation_period;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->probation_period)){echo $result[0]->probation_period;}}else{echo "Select ";}?> </option>
  <option value="1">1</option>
 <option value="2">2</option>
 <option value="3">3</option>
 <option value="4">4</option>
 <option value="5">5</option>
 <option value="6">6</option>
 
 
 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('probation_period');?></div>
</div>
</div>

</div>
</div>
</div>



<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Workdays From: <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	
	<select  class="form-control" name="day_start" required="">
 <option  value="<?php if(!empty($result)){if(!empty($result[0]->day_start)){echo $result[0]->day_start;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->day_start)){echo $result[0]->day_start;}}else{echo "From ";}?> </option>
 <option value="Saturday"   >Saturday</option>
 <option value="Monday"  >Monday</option>
   


 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('day_start');?></div>
  

</div>
</div>

</div>

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Workdays To:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select  class="form-control" name="day_end" required="">
  <option  value="<?php if(!empty($result)){if(!empty($result[0]->day_end)){echo $result[0]->day_end;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->day_end)){echo $result[0]->day_end;}}else{echo "To ";}?> </option>

 <option value="Thursday"  >Thursday</option>
  <option value="Saturday"   >Saturday</option>
   
 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('day_end');?></div>
</div>
</div>

</div>
</div>
</div>
















<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Working Hours From : <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	
	<select  class="form-control" name="jo_from_hour" required="">
 
<option  value="<?php if(!empty($result)){if(!empty($result[0]->jo_from_hour)){echo $result[0]->jo_from_hour;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->jo_from_hour)){echo $result[0]->jo_from_hour;}}else{echo "From ";}?> </option>
 <option value="7 am">7:00 am</option>
 <option value="7:30 am">7:30 am</option>
 <option value="8 am">8:00 am</option>
  <option value="8:30 am">8:30 am</option>
   <option value="9 am">9:00 am</option>
   <option value="9:30 am">9:30 am</option>
   <option value="10 am">10:00 am</option>
   <option value="10:30 am">10:30 am</option>
   <option value="11 am">11:00 am</option>
   <option value="11:30  am">11:30 am</option>
    <option value="12 am">12:00 am</option>
   <option value="12:30  am" >12:30 am</option>
   
 

 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('jo_from_hour');?></div>
  

</div>
</div>

</div>

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Working Hours To:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select  class="form-control" name="jo_to_hour" required="">
   <option  value="<?php if(!empty($result)){if(!empty($result[0]->jo_to_hour)){echo $result[0]->jo_to_hour;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->jo_to_hour)){echo $result[0]->jo_to_hour;}}else{echo "To ";}?> </option>
  <option value="5 pm">5:00 pm</option>
  <option value="5:30 pm">5:30 pm</option>
 <option value="6 pm">6:00 pm</option>
 <option value="6:30 pm">6:30 pm</option>
 <option value="7 pm">7:00 pm</option>
  <option value="7:30 pm">7:30 pm</option>
  <option value="8 pm">8:00 pm</option>
    <option value="8:30 pm">8:30 pm</option>
	<option value="9 pm">9 pm</option>
    <option value="9:30 pm">9:30 pm</option>
	<option value="10 pm" >10 pm</option>
    <option value="10:30 pm">10:30 pm</option>
	<option value="11 pm">11 pm</option>
    <option value="11:30 pm">11:30 pm</option>
	<option value="12 pm">12 pm</option>
    <option value="12:30 pm">12:30 pm</option>
  
 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('jo_to_hour');?></div>
</div>
</div>

</div>
</div>
</div>



<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Break Time From : <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	
	<select  class="form-control" name="jo_from_brk" required="">
 
<option  value="<?php if(!empty($result)){if(!empty($result[0]->jo_from_brk)){echo $result[0]->jo_from_brk;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->jo_from_brk)){echo $result[0]->jo_from_brk;}}else{echo "From ";}?> </option>
 <option value="1 pm"  >1 pm</option>
 <option value="2 pm"  >2 pm</option>
 <option value="3 pm"  >3 pm</option>
 <option value="4 pm"  >4 pm</option>
  

 

 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('jo_from_brk');?></div>
  

</div>
</div>

</div>

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Break Time To:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select  class="form-control" name="jo_to_brk" required="">
   <option  value="<?php if(!empty($result)){if(!empty($result[0]->jo_to_brk)){echo $result[0]->jo_to_brk;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->jo_to_brk)){echo $result[0]->jo_to_brk;}}else{echo "To ";}?> </option>
  <option value="2 pm" >2 pm</option>
  <option value="3 pm" >3 pm</option>
  <option value="4 pm" >4 pm</option>
  <option value="4 pm" >5 pm</option>
 
  
 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('jo_to_brk');?></div>
</div>
</div>

</div>
</div>
</div>




<div class="row">



	<div class="col-md-12 col-sm-12 table-rows-border">
	

<div class="col-md-6 col-sm-12">

  <div class="form-group">
          <label class="col-sm-4 control-label">Total Salary  <abbr class="required">::*::</abbr></label>
              <div class="col-sm-8">
            <input type="Number" id="totnumber" class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->job_id)){echo $result[0]->jo_total_salary;}}else{}?>" min="500" max="10000" name="tot_salary">
             </div>
                               
          </div>


</div>


<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Day Off  :<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select  class="form-control" name="day_off" required="">

 <option  value="<?php if(!empty($result)){if(!empty($result[0]->day_off)){echo $result[0]->day_off;}}else{echo "";}?>" selected=""><?php if(!empty($result)){if(!empty($result[0]->day_off)){echo $result[0]->day_off;}}else{echo "choose ";}?> </option>
 <option value="Friday"  >Friday</option>
 <option value="Sunday"  >Sunday</option>
 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('day_off');?></div>
</div>
</div>

</div>

</div>



</div>













	

<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>


<?php echo form_close();?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>


<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
		tinymce.init({
			selector : '.editors',
			  plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
		});
   </script>










</html>