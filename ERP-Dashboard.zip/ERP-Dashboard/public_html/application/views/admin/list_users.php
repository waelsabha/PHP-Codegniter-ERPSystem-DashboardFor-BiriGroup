<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Users</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Users</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">User managment</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-bordered table-striped mb-none" id="datatable-default">
<thead>
<tr>
	<th style="width: 10%;"></th>

<th>Username</th>
<th>Email</th>
<th>Role</th>	
<th>Department</th>	
<th>Page Permissions</th>
<th>User Created on</th>

<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
foreach($result as $t)
{
$role_name;
        		$role=$t->log_role;
        		switch($role)
        		{
        			case '1':
        			$role_name='manager';
        			break;
        			
        			case '2':
        			$role_name='staff';
        			break;
        			default:
        			break;
        		}

$pages=$t->log_page;
$page_compare=explode(',',$pages);

?>
<tr class="gradeX">
			<td><?php echo $i++;?></td>
		<td><a href="current_user_activity/<?php echo $t->log_id;?>" ><?php echo $t->log_uname;?></a></td>
			<td><?php echo $t->log_email;?></td>
			<td><?php echo $role_name;?></td>
			<td><?php echo $t->log_dept;?></td>
			<td>
			<?php
			if(in_array('add_account_entry',$page_compare))
				echo "Add accounts entry,";
			if(in_array('list_account_entry',$page_compare))
				echo "List accounts entry,";
			if(in_array('acc_excel_upload',$page_compare))
				echo "Excel Upload - Accounts,";

			if(in_array('tx_funds',$page_compare))
				echo "Fund Transfer,";
			if(in_array('list_txs',$page_compare))
				echo "List Fund Transfer,";

			if(in_array('add-customer-details',$page_compare))
				echo "Add Customers - Sales,";
			if(in_array('list-customer-details',$page_compare))
				echo "List Customers - Sales,";
			if(in_array('customer-excel-upload',$page_compare))
				echo " Customer Excel Upload - Sales,";		

			if(in_array('add-users',$page_compare))
				echo "Add Users - Manager,";
			if(in_array('list-users',$page_compare))
				echo "List Users - Manager,";

			if(in_array('add-files',$page_compare))
				echo " File Manager - Add files";
				
			if(in_array('sales-book-dashboard',$page_compare))
				echo " Sales Book Dashboard";
				
			if(in_array('sales-book',$page_compare))
				echo " Sales Book excel upload";		
				
			?>
				
			</td>
			<td><?php echo $t->log_dt_created;?></td>
			
			<td>

	
	<button class="mb-xs mt-xs mr-xs modal-sizes btn btn-xs btn-info chnage_date_modal_<?php echo $t->log_id;?>" href="#modalSM<?php echo $t->log_id;?>"><i class="fa fa-lock"></i></button>	
	&nbsp;&nbsp;	
	<a href="edit_user/<?php echo $t->log_id;?>" ><i class="fa fa-pencil"></i></a>
				&nbsp;&nbsp;
<a href="delete_user/<?php echo $t->log_id;?>" class="delete-row"><i class="fa fa-trash-o"></i></a>
	
			</td>
	</tr>
<div id="modalSM<?php echo $t->log_id;?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Change password?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
<p>Are you sure that you want to change password?</p>
<div class="col-md-12 table-rows-border">
		<div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">New Password<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type='password' name="new_pwd" class="form-control" value="" required />
<div class="form_error">  <?php echo $this->session->flashdata('pwd');?></div>
</div>
</div>
	
</div>
		<div class="col-md-12 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Confirm Password<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type='password' name="confrm_new_pwd" class="form-control" value="" required />
 <div class="form_error">  <?php echo $this->session->flashdata('confrm_pwd');?></div>
</div> 
</div>

</div>


</div>

</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary" type="button" onclick="change_pwd(<?php echo $t->log_id;?>)">Confirm</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<?php 
}?>

</tbody>
</table>



</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	
		function change_pwd(id)
		{
			var new_pwd=$('input[name=new_pwd]').val();
			var confrm_pwd=$('input[name=confrm_new_pwd]').val();
			if(new_pwd=='' || confrm_pwd=='')
				alert('please enter passwords');
			else if(new_pwd!=confrm_pwd)
				alert('passwords dosenot match');
			else{
				jQuery.ajax({
		            url:"<?php echo base_url().'Main_admin/update_password';?>",
		            type:"post",
		            data:{"user_id":id,'new_pwd':new_pwd},
		            success:function(result)
		            {
		            	if(result)
		            	{
		            	  $(".modal-dismiss").trigger("click");
		            		new PNotify({
									title: 'Success',
									text: 'Password Changed successfully',
									type: 'success'
								});
		            		//location.reload();

		            	}

		            }
		            });
			}
		}

	
</script>
</body>
</html>