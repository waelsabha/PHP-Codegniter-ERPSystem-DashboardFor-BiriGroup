<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>
<link rel="stylesheet" href="./admin_assets/vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="./admin_assets/vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="./admin_assets/vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="./admin_assets/vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="./admin_assets/stylesheets/theme.css" />

<link rel="stylesheet" href="./admin_assets/stylesheets/skins/default.css" />

<link rel="stylesheet" href="./admin_assets/stylesheets/theme-custom.css">

<script src="./admin_assets/vendor/modernizr/modernizr.js" type="text/javascript"></script>
<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>
</head>
<body>

<section class="body-sign">
<div class="center-sign">
<a href="#" class="logo pull-left">
	
 <img src="https://www.birigroup.com/temp_styles/assets/img/logo/Biri%20Group%20Logo-01.png" height="54" alt="Porto Admin" /> 
</a>
<div class="panel panel-sign">
<div class="panel-title-sign mt-xl text-right">
<h2 class="title text-uppercase text-bold m-none"><i class="fa fa-user mr-xs"></i> Sign In</h2>
</div>
<div class="panel-body">
<?php echo form_open('submit_login');?>
<input type="hidden" name="page_current_url" value="<?php if(!empty($page_current_url)){echo $page_current_url;};?>">
 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="form-group mb-lg">
<label>Username</label>
<div class="input-group input-group-icon">
<input name="username" type="text" class="form-control input-lg" />
<div class="form_error">  <?php echo $this->session->flashdata('username');?></div>
<span class="input-group-addon">
<span class="icon icon-lg">
<i class="fa fa-user"></i>
</span>
</span>
</div>
</div>
<div class="form-group mb-lg">
<div class="clearfix">
<label class="pull-left">Password</label>
<!-- <a href="#" class="pull-right">Lost Password?</a> -->
</div>
<div class="input-group input-group-icon">
<input name="pwd" type="password" class="form-control input-lg" />
<div class="form_error">  <?php echo $this->session->flashdata('pwd');?></div>
<span class="input-group-addon">
<span class="icon icon-lg">
<i class="fa fa-lock"></i>
</span>
</span>
</div>
</div>
<div class="row">
<div class="col-sm-8">
<div class="checkbox-custom checkbox-default">
<input id="RememberMe" name="rememberme" type="checkbox" />
<label for="RememberMe">Remember Me</label>
</div>
</div>
<div class="col-sm-4 text-right">
<button type="submit" class="btn btn-primary hidden-xs">Sign In</button>
<button type="submit" class="btn btn-primary btn-block btn-lg visible-xs mt-lg">Sign In</button>
</div>
</div>


<p class="text-center">Don't have an account yet? <a href="#">Sign Up!</a>
<?php echo form_close();?>
</div>
</div>
<p class="text-center text-muted mt-md mb-md">&copy; Copyright 2019. All rights reserved. <a href="#">Biri Group</a>.</p>
</div>
</section>


<script src="./admin_assets/vendor/jquery/jquery.js" type="text/javascript"></script> 
<script src="./admin_assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script> 
<script src="./admin_assets/vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script> 
<script src="./admin_assets/vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script> 
<script src="./admin_assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script> 
<script src="./admin_assets/vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script> 
<script src="./admin_assets/vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="./admin_assets/javascripts/theme.js" type="text/javascript"></script>

<script src="./admin_assets/javascripts/theme.custom.js" type="text/javascript"></script>

<script src="./admin_assets/javascripts/theme.init.js" type="text/javascript"></script>

</body>
</html>