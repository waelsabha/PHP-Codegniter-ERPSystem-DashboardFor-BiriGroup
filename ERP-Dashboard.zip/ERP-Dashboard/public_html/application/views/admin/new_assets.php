<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" 
type="text/css"/>
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" 
type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
table input.form-control {
  width: auto;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">
<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2><?php echo $this->lang->line('New_assets'); ?> </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span><?php echo $this->lang->line('assets'); ?></span></li>

</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title"><?php echo $this->lang->line('Create Assets Item'); ?> </h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('Manage_assets/submit_assets_item','class="myform" novalidate','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
 <input type="hidden" name="asset_id" value="<?php if(!empty($result[0]->al_id)){echo $result[0]->al_id;};?>">
  
  
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"><?php echo $this->lang->line('Fileds marked as'); ?> </p>

<div class="row">
<div class="col-md-6 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"><?php echo $this->lang->line('Assets_parent'); ?><abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="parent_asset_id" id="parent_asset" required="required">
  <option value=""><?php echo $this->lang->line('Choose'); ?></option>
 <?php
foreach($customers as $cb)
{
//pre_list($cb);
?>
<option value="<?php echo $cb->id;?>" <?php if(!empty($result[0]->si_customer_acc_id)){if($result[0]->si_customer_acc_id==$cb->id){echo "selected";}};?> ><?php echo $cb->label;?></option>
 
<?php
}
?>
 </select>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12 table-rows-border">

<label class="col-md-4 control-label" for="inputPlaceholder"><?php echo $this->lang->line('asset_name'); ?> <abbr class="required">::*::</abbr>
 
</label>
<div class="col-md-8">
 
 <select id="child_asset"  name="child_asset_name">
        <option value="">Select Parent Asset First</option>
   
 </select>
 
</div>


</div>
</div>

<div class="row">
<div class="col-md-6 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"><?php echo $this->lang->line('description'); ?><abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
 <input type='text' class="form-control populate" name="asset_desc" value="" ><br/>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"><?php echo $this->lang->line('serial_number'); ?> <abbr class="required">::*::</abbr>
 
</label>
<div class="col-md-8">
<input type='text' class="form-control populate" name="asset_serial" value="" ><br/>
</div>

</div>


</div>



<div class="row">
<div class="col-md-6 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> &nbsp &nbsp &nbsp Estimated price</abbr>
</label>
<div class="col-md-8">
 <input type='number' class="form-control populate" name="asset_price" value="" ><br/>
</div>
</div>
</div>

</div>



<div class="col-md-6 col-sm-12 table-rows-border">

<label class="col-md-4 control-label" for="inputPlaceholder"><?php echo $this->lang->line('Conditional_statue'); ?> <abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
 <select data-plugin-selectTwo  class="form-control populate" name="al_condition_asset"  required="required">
   <option value="">Select Statue</option>
      <option value="0">New</option>
	    <option value="1">Used but excellent</option>
		  <option value="2">good</option>
		    <option value="3">low average</option>
			  <option value="4">old</option>
 
 </select>
</div>

</div>
</div>




<button class="btn btn-primary " >Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>




<?php echo form_close();?>
</div>
</div>


</section>
</div>
</section>


<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
<a href="#" class="mobile-close visible-xs">
Collapse <i class="fa fa-chevron-right"></i>
</a>
<div class="sidebar-right-wrapper">

<div class="sidebar-widget widget-friends ">

<div class="chat_window">
<?php $this->load->view('admin/master_essential/chat_data',$chat);?>

</div>
</div>



</div>
</div>
</div>
</aside>
<?php $this->load->view('admin/sales/script_arabic_word');?>
<script src="<?php echo base_url('admin_assets/');?>tafqit.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
 <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript">
  </script>

  <script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

  
 <script>
        $(document).ready(function() {
            $('#parent_asset').change(function() {
                var parentAssetId = $(this).val();
                
                if (parentAssetId === '') {
                    $('#child_asset').html('<option value="">Select Parent Asset First</option>');
                    $('#child_asset').prop('disabled', true);
                } else {
                    $.ajax({
                        url: '<?php echo base_url("Manage_assets/get_assets_child"); ?>',
                        type: 'POST',
                        data: { parent_asset_id: parentAssetId },
                        dataType: 'json',
                        success: function(response) {
                            var options = '';
                            for (var i = 0; i < response.length; i++) {
                                options += '<option value="' + response[i].item_id + '">' + response[i].item_name + '</option>';
                            }
                            $('#child_asset').html(options);
							
                            $('#child_asset').prop('disabled', false);
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                }
            });
        });
    </script>

</body>

</html>