<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Positions</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Positions</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<!-- it will be paused temporary 
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Salary Structure details
<span><button class="btn btn-primary pull-right modal-with-form" href="#modalForm2">Add more structure details<i class="fa fa-plus"></i></button></span>
</h2>
<div id="modalForm2" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Details</h2>
</header>
<div class="panel-body">

 echo form_open('submit_list_salary_structure','class="form-horizontal mb-lg extra-form"');
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Term Name <abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="term_name" class="form-control"  required />
</div>
</div>


<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Term Name Arabic <abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="term_name_ar" class="form-control"  required />
</div>
</div>


<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Term Contain<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<textarea  name="term_contain" rows="6" cols="50" ></textarea>
</div>
</div>

<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Term Contain Arabic<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<textarea  name="term_contain_ar" rows="6" cols="50" ></textarea>
</div>
</div>

</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary" type="submit">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
 echo form_close();
</section>

</div>
</header>
-->
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>






<div class="row">
	
	
<div class="col-md-12 col-sm-12 table-rows-border">


<div class="col-md-6 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose The Company<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="company_request_salary" required="">
  <option value="">Choose</option>
 
 
 <option value="10" selected="" <?php  echo "selected";?> >Dubai Trading</option>
 

 <option value="9" selected="" <?php  echo "selected";?> >ksa trading</option>

  <option value="8" selected="" <?php  echo "selected";?> >biri industries RAK</option>


 </select>
</div>
</div>
</div>



</div>



</div>





<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	
<div class="col-md-6 col-sm-12">


  <div class="form-group">
           <label class="col-sm-4 control-label">Basic Salary<abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8">
                    <input type="number"   class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->detail_id)){echo $result[0]->precentage;}}else{}?>"  name="basic_salary">
              </div>
                  </div>

</div>


<div class="col-md-6 col-sm-12">


  <div class="form-group">
           <label class="col-sm-4 control-label">Housing Allowance<abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8">
                    <input type="number"   class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->detail_id)){}}else{}?>" name="housing_allowance">
              </div>
                  </div>

</div>





</div>
</div>



<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	


<div class="col-md-6 col-sm-12">


  <div class="form-group">
           <label class="col-sm-4 control-label">Transport / Petrol<abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8"
                    <input type="number"   class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->detail_id)){echo $result[2]->precentage;}}else{}?>"  name="transport_petrol">
              </div>
                  </div>

</div>




<div class="col-md-6 col-sm-12">


  <div class="form-group">
           <label class="col-sm-4 control-label">Telephone allowance <abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8">
                    <input type="number"   class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->detail_id)){echo $result[3]->precentage;}}else{}?>"  name="telephone_allowence">
              </div>
                  </div>

</div>

</div>
</div>

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	





<div class="col-md-6 col-sm-12">


  <div class="form-group">
           <label class="col-sm-4 control-label">Food Allowance  <abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8">
                    <input type="number"  class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->detail_id)){echo $result[4]->precentage;}}else{}?>"   name="food_allowancae">
              </div>
                  </div>


</div>


<div class="col-md-6 col-sm-12">


  <div class="form-group">
           <label class="col-sm-4 control-label">Car Allowance (if any) <abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8">
                    <input type="number"  class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->detail_id)){echo $result[5]->precentage;}}else{}?>" name="car_allowance">
              </div>
                  </div>


</div>







</div>
</div>

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
	


<div class="col-md-6 col-sm-12">


  <div class="form-group">
           <label class="col-sm-4 control-label">Other allowances<abbr class="required">::*::</abbr> </label>
           <div class="col-sm-8">
                    <input type="number"  class="form-control" value="<?php if(!empty($result)){if(!empty($result[0]->detail_id)){echo $result[6]->precentage;}}else{}?>"   name="other_allowance">
              </div>
                  </div>


</div>





</div>
</div>
</div>













</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">

	function add_text_field()
		{
			$('.new_txt_fld').append('<input type="text" name="add_sub_cat[]" class="form-control" style="border-color:black;" value="" />'); 
			return true;
		}








$(document).on('ready', function () 
{
  

$('select[name="company_request_salary"]').on("change",function(){
   if($(this).val()=="10")
                    {
                $('select[name="basic_salary"] ').val('5').trigger('change');

               //$('select[name="si_salesman"]').val(returndata[0]['macd_salesman_id']).trigger('change');
                $('select[name="housing_allowance"]').val('82').trigger('change');
                $('select[name="transport_petrol"]').val('3').trigger('change');
                $('select[name="telephone_allowence"]').val('8').trigger('change');
                $('select[name="food_allowancae"]').val('8').trigger('change');
               $('select[name="car_allowance"]').val('618').trigger('change');
               $('select[name="other_allowance"]').val('618').trigger('change');
                    }
                    else
                    {
  jQuery.ajax({
               url:"<?php echo base_url().'Sales_invoice/get_cust_full_details';?>",
                data:{"cust_id":$(this).val()},
              type:"post",
               success:function(result)
              {
                console.log(result);
                if(result)
                {
                  
                var returndata = JSON.parse(result);
             $('select[name="si_company"] ').val(returndata[0]['macd_company_id']).trigger('change');
         $('select[name="housing_allowance"]').val(returndata[0]['macd_salesman_id']).trigger('change');
          $('select[name="si_country"]').val(returndata[0]['country']).trigger('change');
          $('select[name="si_payment_type"]').val(returndata[0]['macd_payment_type_id']).trigger('change');
          $('select[name="si_pc_level"]').val(returndata[0]['macd_price_level_id']).trigger('change');
          $('select[name="si_plc_supply"]').val(returndata[0]['macd_place_supply_id']).trigger('change');
          $('select[name="si_jurisdiction"]').val(returndata[0]['macd_jurisdication_id']).trigger('change');
       $('select[name="si_sales_acc_id"]').val(returndata[0]['macd_sales_acc_id']).trigger('change');
       
                if(returndata[0]['macd_currency_value']!=null)
                {
                 $('select[name="si_currency"]').val(returndata[0]['macd_currency_value']).trigger('change');
                   if(returndata[0]['currency_val']!=null)
                   $('input[name="si_conv_value"]').val(returndata[0]['currency_val']);
                   else
                     $('input[name="si_conv_value"]').val('1');
               }
               else
               {
                if($('input[name="page_type"]').val()=="ksa")
                {
                  $('select[name="si_currency"]').val('SAR').trigger('change');
                  $('input[name="si_conv_value"]').val('0.975');
                }
                else
                {
                  $('select[name="si_currency"]').val('AED').trigger('change');
                  $('input[name="si_conv_value"]').val('1');
                }
                  
               }

           if(returndata[0]['phone']!=null)
           $('input[name="si_contact"]').val(returndata[0]['phone']);
         else
             $('input[name="si_contact"]').val(returndata[0]['mobile_phone']);

             if(returndata[0]['address']!=null)
           $('input[name="si_delivery_address"]').val(returndata[0]['address']);
          // console.log(returndata[0]);
                  
              }
                
            }
               }); 
          }///closed else////
          });
}); 





</script>









</body>
</html>