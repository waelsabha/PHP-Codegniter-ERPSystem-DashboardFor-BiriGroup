<!doctype html>
<html class="fixed">


<head>

<?php $this->load->view('admin/head');?>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/morris/morris.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/pie_country.css" />

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Dashboard</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Dashboard</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<?php
foreach($item_request_data as $t)
{
  if($t->ir_req_status=='1')
  {
?>

<div class="alert alert-success success-alert_<?php echo $t->ir_id;?>"  style="float: right;">
  <button type="button" class="close" onclick="alert_close(<?php echo $t->ir_id;?>)" data-dismiss="alert">x</button>
  <strong>New Item Request </strong> You have a new item request numbered #<?php echo $t->ir_req_no;?>
</div>
<div class="break_panel_<?php echo $t->ir_id;?>"><br/><br/><br/><br/></div>
<?php
  }
}
?>


<?php
if($this->session->userdata['user']['main_dept']=="Purchase")
		{
			if($this->session->userdata['user']['user_desig']=="Manager")
			{
			?>
<?php

$main_fact_process=array();
$advertising_process=array();

 //print_r($po_data);

foreach($po_data as $pd)
{
   $main_fact_process[]=$pd->po_order_status_fact;
   $advertising_process[]=$pd->po_order_status_adv;
  if(strpos($pd->po_dept, ',') !== false)
  {
  
  $dept_data=explode(',',$pd->po_dept);
    if($dept_data[0]=="Main factory")
    {
      $main_fact_process[]=$pd->po_order_status_fact;
    }
    else
    {
       $advertising_process[]=$pd->po_order_status_adv;
    }
  }
}


?>
<!----------------div for po main factory-------->
<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg">Production Order Main Factory
<div class="row">
  <?php
$new_mp=array();$accepted_mp=array();$on_prod_mp=array();
$ready_delivery_mp=array();$delivered_mp=array();$rejected_mp=array();
foreach($main_fact_process as $mp)
{

  if($mp=='1')
  {
    $new_mp[]=$mp;
  }
  elseif($mp=='2')
  {
    $accepted_mp[]=$mp;
  }
  elseif($mp=='3')
  {
    $on_prod_mp[]=$mp;
  }
  elseif($mp=='4')
  {
    $ready_delivery_mp[]=$mp;
  }
  elseif($mp=='5')
  {
    $delivered_mp[]=$mp;
  }
  elseif($mp=='0')
  {
     $rejected_mp[]=$mp;
  }
  else{}
}
?>
  <!--------this 3rd div-->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-primary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-users"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">New </h4>
<div class="info">
<strong>
  <?php if(!empty($new_mp)){echo count($new_mp);}?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!--------this 3rd div-->
<!-----end of 3rd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-tertiary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Approved </h4>
<div class="info">
<strong>
    <?php if(!empty($accepted_mp)){echo count($accepted_mp);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!--------this 3rd div-->
<!-----end of 3rd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-quartenary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">On Production </h4>
<div class="info">
<strong>
    <?php if(!empty($on_prod_mp)){echo count($on_prod_mp);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 3rd div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-warning">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Ready for delivery</h4>
<div class="info">
<strong>
   <?php if(!empty($ready_delivery_mp)){echo count($ready_delivery_mp);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 4th div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-success">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Delivered</h4>
<div class="info">
<strong>
     <?php if(!empty($delivered_mp)){echo count($delivered_mp);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 4th div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-secondary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Rejected Orders</h4>
<div class="info">
<strong>
    <?php if(!empty($rejected_mp)){echo count($rejected_mp);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 4th div--->
</div>
</div>

</div>
<!--closing row for po request-->

<!----------------div for po request-------->
<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg">Production Order Advertising
<div class="row">
  <?php
$new_ap=array();$accepted_ap=array();$on_prod_ap=array();
$ready_delivery_ap=array();$delivered_ap=array();$rejected_ap=array();
foreach($advertising_process as $ap)
{

  if($ap=='1')
  {
    $new_ap[]=$ap;
  }
  elseif($ap=='2')
  {
    $accepted_ap[]=$ap;
  }
  elseif($ap=='3')
  {
    $on_prod_ap[]=$ap;
  }
  elseif($ap=='4')
  {
    $ready_delivery_ap[]=$ap;
  }
  elseif($ap=='5')
  {
    $delivered_ap[]=$ap;
  }
  elseif($ap=='0')
  {
     $rejected_ap[]=$ap;
  }
  else{}
}
?>
  <!--------this 3rd div-->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-primary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-users"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">New </h4>
<div class="info">
<strong>
  <?php if(!empty($new_ap)){echo count($new_ap);}?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!--------this 3rd div-->
<!-----end of 3rd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-tertiary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Approved </h4>
<div class="info">
<strong>
    <?php if(!empty($accepted_ap)){echo count($accepted_ap);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!--------this 3rd div-->
<!-----end of 3rd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-quartenary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">On Production </h4>
<div class="info">
<strong>
    <?php if(!empty($on_prod_ap)){echo count($on_prod_ap);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 3rd div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-warning">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Ready for delivery</h4>
<div class="info">
<strong>
   <?php if(!empty($ready_delivery_ap)){echo count($ready_delivery_ap);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 4th div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-success">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Delivered</h4>
<div class="info">
<strong>
     <?php if(!empty($delivered_ap)){echo count($delivered_ap);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 4th div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-secondary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Rejected Orders</h4>
<div class="info">
<strong>
    <?php if(!empty($rejected_ap)){echo count($rejected_ap);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 4th div--->
</div>
</div>

</div>
<!--closing row for po request-->

<?php
}
}?>

<!----------------div for item request-------->
<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg">Item Request
  <?php
  $new_ir=array();$orderd_ir=array();$approved_ir=array();$shipment_ready_ir=array();$shipped_ir=array();$rejected_ir=array();
foreach($item_request_data as $ir)
{
  if($ir->ir_req_status=='1')
  {
    $new_ir[]= $ir->ir_req_status;
  }
  elseif($ir->ir_req_status=='2')
  {
    $orderd_ir[]=$ir->ir_req_status;
  }
   elseif($ir->ir_req_status=='3')
  {
    $approved_ir[]=$ir->ir_req_status;
  }
   elseif($ir->ir_req_status=='4')
  {
    $shipment_ready_ir[]=$ir->ir_req_status;
  }
   elseif($ir->ir_req_status=='5')
  {
    $shipped_ir[]=$ir->ir_req_status;
  }
   elseif($ir->ir_req_status=='6')
  {
    $rejected_ir[]=$ir->ir_req_status;
  }
  else{}
}
?>

<div class="row">
  <!--------this 1st div-->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-primary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-users"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">New Request</h4>
<div class="info">
<strong>
  <?php if(!empty($new_ir)){echo count($new_ir);}?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!--------this 1st div-->
<!-----end of 2nd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-tertiary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Request Ordered</h4>
<div class="info">
<strong>
   <?php if(!empty($orderd_ir)){echo count($orderd_ir);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!--------this 3rd div-->
<!-----end of 3rd div--->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-quartenary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Request Approved</h4>
<div class="info">
<strong>
   <?php if(!empty($approved_ir)){echo count($approved_ir);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 3rd div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-warning">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Ready for shippment</h4>
<div class="info">
<strong>
     <?php if(!empty($shipment_ready_ir)){echo count($shipment_ready_ir);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 4th div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-success">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Shipped</h4>
<div class="info">
<strong>
   <?php if(!empty($shipped_ir)){echo count($shipped_ir);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 4th div--->
<!------this is 4th div----->
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-secondary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-globe"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Rejected Orders</h4>
<div class="info">
<strong>
     <?php if(!empty($rejected_ir)){echo count($rejected_ir);}?>
</strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-----end of 4th div--->
</div>
</div>

</div>
<!--closing row for item request-->
</section>



</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-appear/jquery.appear.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>
<script>
$(document).ready(function() {
 // $("#success-alert").hide();

  });

function alert_close(id)
{
  $('.break_panel_'+id).remove();
    $(".success-alert_"+id).fadeTo(2000, 500).slideUp(500, function() {
      $(".success-alert_"+id).slideUp(500);
    });
}

</script>

</body>

</html>