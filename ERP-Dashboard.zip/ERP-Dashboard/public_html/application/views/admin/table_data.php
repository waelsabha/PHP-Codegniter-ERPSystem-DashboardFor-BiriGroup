<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Table Data( from <?php echo date("Y-m-d", strtotime("-7 days"));?> )
 
</h2>



</header>
<div class="panel-body">
    
     <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
    <th></th>
<th>Date</th>
<th>Amount</th>
<th>Type</th>
<th>Description</th>
<th>Bank</th>
<th>Total Balance</th> 

<th>Ttl BBMS</th>
<th>Ttl Factory</th>
<th>Ttl ENBD</th>
<th>Ttl EI</th>
<th>Ttl Cash Bachir</th>
<th>Ttl Cash Garhoud</th>
<!-- <th>Ttl Cash Factory</th> -->
<th>Ttl Other</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
$date_value=false;

	$new_bal_amount1='';$new_bal_amount2='';$new_bal_amount3='';$new_bal_amount4='';$new_bal_amount5='';$new_bal_amount6='';
	$new_bal_amount7='';$new_bal_amount8='';

	$total_balance='';
	$bal1='';$bal2='';$bal3='';$bal4='';$bal5='';$bal6='';$bal7='';$bal8='';
$banks_array=array('ADIB-BBMS','ADIB-Factory','ENBD','EI Bank','Cash Mr. Bachir Book','Cash Garhoud','Cash Factory','Other Bank');

foreach($cash_entire as $ce)
{
	if($ce->ae_bank==$banks_array[0])
	{
		if($new_bal_amount1=='')
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount1=$result_bal_date[0]-$ce->ae_amount;
			else
			$new_bal_amount1=$result_bal_date[0]+$ce->ae_amount;
		}
		else
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount1=$new_bal_amount1-$ce->ae_amount;
			else
			$new_bal_amount1=$new_bal_amount1+$ce->ae_amount;
		}		
	}
	elseif($ce->ae_bank==$banks_array[1])
	{
		if($new_bal_amount2=='')
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount2=$result_bal_date[1]-$ce->ae_amount;
			else
			$new_bal_amount2=$result_bal_date[1]+$ce->ae_amount;
		}
		else
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount2=$new_bal_amount2-$ce->ae_amount;
			else
			$new_bal_amount2=$new_bal_amount2+$ce->ae_amount;
		}
	}
	elseif($ce->ae_bank==$banks_array[2])
	{
		if($new_bal_amount3=='')
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount3=$result_bal_date[2]-$ce->ae_amount;
			else
			$new_bal_amount3=$result_bal_date[2]+$ce->ae_amount;
		}
		else
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount3=$new_bal_amount3-$ce->ae_amount;
			else
			$new_bal_amount3=$new_bal_amount3+$ce->ae_amount;
		}
	}
	elseif($ce->ae_bank==$banks_array[3])
	{
		if($new_bal_amount4=='')
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount4=$result_bal_date[3]-$ce->ae_amount;
			else
			$new_bal_amount4=$result_bal_date[3]+$ce->ae_amount;
		}
		else
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount4=$new_bal_amount4-$ce->ae_amount;
			else
			$new_bal_amount4=$new_bal_amount4+$ce->ae_amount;
		}
	}
	elseif($ce->ae_bank==$banks_array[4])
	{
		if($new_bal_amount5=='')
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount5=$result_bal_date[4]-$ce->ae_amount;
			else
			$new_bal_amount5=$result_bal_date[4]+$ce->ae_amount;
		}
		else
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount5=$new_bal_amount5-$ce->ae_amount;
			else
			$new_bal_amount5=$new_bal_amount5+$ce->ae_amount;
		}
	}
	elseif($ce->ae_bank==$banks_array[5])
	{

		if($new_bal_amount6=='')
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount6=$result_bal_date[5]-$ce->ae_amount;
			else
			$new_bal_amount6=$result_bal_date[5]+$ce->ae_amount;
		}
		else
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount6=$new_bal_amount6-$ce->ae_amount;
			else
			$new_bal_amount6=$new_bal_amount6+$ce->ae_amount;
		}
	}
	elseif($ce->ae_bank==$banks_array[6])
	{
		if($new_bal_amount7=='')
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount7=$result_bal_date[6]-$ce->ae_amount;
			else
			$new_bal_amount7=$result_bal_date[6]+$ce->ae_amount;
		}
		else
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount7=$new_bal_amount7-$ce->ae_amount;
			else
			$new_bal_amount7=$new_bal_amount7+$ce->ae_amount;
		}
	}
	elseif($ce->ae_bank==$banks_array[7])
	{
		if($new_bal_amount8=='')
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount8=$result_bal_date[7]-$ce->ae_amount;
			else
			$new_bal_amount8=$result_bal_date[7]+$ce->ae_amount;
		}
		else
		{
			if($ce->ae_cash_type=="Spend")
			$new_bal_amount8=$new_bal_amount8-$ce->ae_amount;
			else
			$new_bal_amount8=$new_bal_amount8+$ce->ae_amount;
		}
	}
	else
	{
		$new_bal_amount1=$result_bal_date[0];
		$new_bal_amount2=$result_bal_date[1];
		$new_bal_amount3=$result_bal_date[2];
		$new_bal_amount4=$result_bal_date[3];
		$new_bal_amount5=$result_bal_date[4];
		$new_bal_amount6=$result_bal_date[5];
		$new_bal_amount7=$result_bal_date[6];
		$new_bal_amount8=$result_bal_date[7];

	}
	
	
	if(!empty($new_bal_amount1)){$bal1=$new_bal_amount1;}
	else{$bal1=$result_bal_date[0];} 
	if(!empty($new_bal_amount2)){$bal2=$new_bal_amount2;}else{$bal2=$result_bal_date[1];}
	if(!empty($new_bal_amount3)){$bal3=$new_bal_amount3;}else{$bal3=$result_bal_date[2];}
	if(!empty($new_bal_amount4)){$bal4=$new_bal_amount4;}else{$bal4=$result_bal_date[3];}
	if(!empty($new_bal_amount5)){$bal5=$new_bal_amount5;}else{$bal5=$result_bal_date[4];}
	if(!empty($new_bal_amount6)){$bal6=$new_bal_amount6;}else{$bal6=$result_bal_date[5];}
	// if(!empty($new_bal_amount7)){$bal7=$new_bal_amount7;}else{$bal7=$result_bal_date[6];}
	if(!empty($new_bal_amount8)){$bal8=$new_bal_amount8;}else{$bal8=$result_bal_date[7];}

$total_balance=$bal1+$bal2+$bal3+$bal4+$bal5+$bal6+$bal8;
    ?>
<tr class="gradeX">
<td><?php echo $i++;?></td>
<?php
if ($ce->ae_date != $date_value) {?>
<td><?php echo $ce->ae_date;?></td>
<?php
}?>
<td><?php echo $ce->ae_amount;?></td>
<td><?php echo $ce->ae_cash_type;?></td>
<td><?php echo $ce->ae_desc;?></td>
<td><?php echo $ce->ae_bank;?></td>

<td <?php if(!empty($total_balance) && ($total_balance<0)){echo "style='background-color:#d22d5373;'";};?> ><?php echo number_format((float)$total_balance, 2, '.', '');?></td><!--total bank balance-->
<td <?php if(!empty($new_bal_amount1) && ($new_bal_amount1<0)){echo "style='background-color:#d22d5373;'";};?> >
	<?php if(!empty($new_bal_amount1))
{echo number_format((float)$new_bal_amount1, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[0], 2, '.', '');
}
;?>
	
</td>
<td <?php if(!empty($new_bal_amount2) && ($new_bal_amount2<0)){echo "style='background-color:#d22d5373;'";};?> >
	<?php if(!empty($new_bal_amount2))
{echo number_format((float)$new_bal_amount2, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[1], 2, '.', '');
}
;?>
	
</td>
<td <?php if(!empty($new_bal_amount3) && ($new_bal_amount3<0)){echo "style='background-color:#d22d5373;'";};?> >
	<?php if(!empty($new_bal_amount3))
{echo number_format((float)$new_bal_amount3, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[2], 2, '.', '');
};?>
	
</td>
<td <?php if(!empty($new_bal_amount4) && ($new_bal_amount4<0)){echo "style='background-color:#d22d5373;'";};?> >
	<?php if(!empty($new_bal_amount4))
{echo number_format((float)$new_bal_amount4, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[3], 2, '.', '');
};?>
	
</td> 
<td <?php if(!empty($new_bal_amount5) && ($new_bal_amount5<0)){echo "style='background-color:#d22d5373;'";};?> >
	<?php if(!empty($new_bal_amount5))
{echo number_format((float)$new_bal_amount5, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[4], 2, '.', '');
};?>
	
</td>
<td <?php if(!empty($new_bal_amount6) && ($new_bal_amount6<0)){echo "style='background-color:#d22d5373;'";};?> >
	<?php if(!empty($new_bal_amount6))
{echo number_format((float)$new_bal_amount6, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[5], 2, '.', '');
};?>
	
</td>
<!-- <td <?php if(!empty($new_bal_amount7) && ($new_bal_amount7<0)){echo "style='background-color:#d22d5373;'";};?> >
	<?php if(!empty($new_bal_amount7))
{echo number_format((float)$new_bal_amount7, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[6], 2, '.', '');
};?>
	
</td> -->
<td <?php if(!empty($new_bal_amount8) && ($new_bal_amount8<0)){echo "style='background-color:#d22d5373;'";};?>>
	<?php if(!empty($new_bal_amount8))
{echo number_format((float)$new_bal_amount8, 2, '.', '');}
else{
echo number_format((float)$result_bal_date[7], 2, '.', '');};?>
	
</td> 

<td>


	
</td>

</tr>

<div id="modalForm<?php echo $ce->ae_id;?>" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Edit Entry</h2>
</header>
<div class="panel-body">
<!-- <form id="demo-form" class="form-horizontal mb-lg" novalidate="novalidate">
 -->	<?php echo form_open('submit_account_entry','class="form-horizontal mb-lg"');?>
<input type="hidden" name="acc_id" value="<?php echo $ce->ae_id;?>">	
	<input type="hidden" name="page_edit" value="dashboard">
	

<div class="row">
	<div class="col-md-12 table-rows-border">
		<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Date <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<?php
if(!empty($ce->ae_date))
{
$convert=explode('-',$ce->ae_date);
$new_date= $convert[1].'/'.$convert[2].'/'.$convert[0];
// echo $result[0]->ae_date;
}
if(!empty($ce->ae_time))
{
$convert=date("g:i A", strtotime($ce->ae_time));
//echo $convert;
}
;?>
 <input type='text' name="date" class="form-control datetimepicker4" value="<?php  if(!empty($new_date)) echo $new_date.' '.$convert;?>" required />

<!--  <input type="text" class="form-control" data-plugin-datepicker="" name="date" value="<?php  if(!empty($new_date)) echo $new_date;?>" required> 
 <div class="form_error">  <?php echo $this->session->flashdata('date');?></div>-->
</div> 
</div>

</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Add Description<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<textarea class="form-control" placeholder="Add Description" required="" id="main_desc" name="desc" rows="5"><?php  if(!empty($ce->ae_desc)) echo $ce->ae_desc;?></textarea>
<div class="form_error">  <?php echo $this->session->flashdata('desc');?></div>
</div>
</div>
	<div>
	 <label class="col-md-4 control-label" for="inputPlaceholder">Is this an Opening Balance?<abbr class="required">::*::</abbr></label>
	<div class="col-md-8">
			<label class="radio-inline">
			<input type="radio" value="Yes" required="" name="opening_bal_status" <?php if(!empty($ce->ae_desc) && ($ce->ae_desc=='Opening Balances')){echo "checked";}?>> Yes
			</label>
			<label class="checkbox-inline">
			<input type="radio" value="No" required="" name="opening_bal_status" <?php if(!empty($ce->ae_desc) && ($ce->ae_desc!='Opening Balances')){echo "checked";}?>> No
			</label>
			<div class="form_error">  <?php echo $this->session->flashdata('opening_bal_status');?></div>
</div>
	</div>
</div>

</div>
</div>


<div class="row">
	<div class="col-md-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputDefault">Choose Category<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control mb-md cat" name="cat" required="" onchange="if (this.value=='Others'){this.form['others_cat'].style.visibility='visible'}else {this.form['others_cat'].style.visibility='hidden'};">
		<option value=""></option>
		<option value="Shipping" <?php if(!empty($ce->ae_cat)){ if($ce->ae_cat=='Shipping'){echo "selected";}} ?>>Shipping</option>
		<option value="Sales" <?php if(!empty($ce->ae_cat)){ if($ce->ae_cat=='Sales'){echo "selected";}} ?>>Sales</option>
		<option value="General Expenses" <?php if(!empty($ce->ae_cat)){ if($ce->ae_cat=='General Expenses'){echo "selected";}} ?>>General Expenses</option>
		<option value="Salaries" <?php if(!empty($ce->ae_cat)){ if($ce->ae_cat=='Salaries'){echo "selected";}} ?>>Salaries</option>
		<option value="Raw Material Purchases" <?php if(!empty($ce->ae_cat)){ if($ce->ae_cat=='Raw Material Purchases'){echo "selected";}} ?>>Raw Material Purchases</option>
		<option value="Import Purchases" <?php if(!empty($ce->ae_cat)){ if($ce->ae_cat=='Import Purchases'){echo "selected";}} ?>>Import Purchases</option>
		<option value="Personal Accounts" <?php if(!empty($ce->ae_cat)){ if($ce->ae_cat=='Personal Accounts'){echo "selected";}} ?>>Personal Accounts</option>
		<option value="Rent" <?php if(!empty($ce->ae_cat)){ if($ce->ae_cat=='Rent'){echo "selected";}} ?>>Rent</option>
		<option value="Others" <?php if(!empty($ce->ae_cat)){ if($ce->ae_cat=='Others'){echo "selected";}} ?>>Others</option>
		
	</select>
<div class="form_error">  <?php echo $this->session->flashdata('cat');?></div>
</div>
 </div>

</div>
<div class="col-md-6">

 <div class="form-group" id="cat_desc" >
 <!-- <label class="col-md-4 control-label" for="inputDefault">Enter Other Description</label>	 -->
  <div class="col-md-4"></div>
 <div class="col-md-8">
	<textarea class="form-control" style="visibility: hidden;" placeholder="Enter Other Description(if any)" name="others_cat" id="others_cat" rows="5"><?php  if(!empty($ce->ae_cat_desc)) echo $ce->ae_cat_desc;?></textarea>
	<div class="form_error">  <?php echo $this->session->flashdata('others_cat');?></div>
</div>
 </div>

</div>
</div>
</div>

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">

 <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Status<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control mb-md sts" name="status" required="" onchange="if (this.value=='Others'){this.form['others_status'].style.visibility='visible'}else {this.form['others_status'].style.visibility='hidden'};">
		<option value=""></option>
		<option value="Cash Deposit" <?php if(!empty($ce->ae_sts)){ if($ce->ae_sts=='Cash Deposit'){echo "selected";}} ?>>Cash Deposit</option>
		<option value="Cash" <?php if(!empty($ce->ae_sts)){ if($ce->ae_sts=='Cash'){echo "selected";}} ?>>Cash</option>
		<option value="PDC" <?php if(!empty($ce->ae_sts)){ if($ce->ae_sts=='PDC'){echo "selected";}} ?>>PDC</option>
		<option value="Bank Transfer" <?php if(!empty($ce->ae_sts)){ if($ce->ae_sts=='Bank Transfer'){echo "selected";}} ?>>Bank Transfer</option>
		<option value="Expected" <?php if(!empty($ce->ae_sts)){ if($ce->ae_sts=='Expected'){echo "selected";}} ?>>Expected</option>
		<option value="Others" <?php if(!empty($ce->ae_sts)){ if($ce->ae_sts=='Others'){echo "selected";}} ?>>Others</option>
		
	</select>
	<div class="form_error">  <?php echo $this->session->flashdata('status');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">

 <div class="form-group">
 	 <label class="col-md-4 control-label" for="inputDefault"></label>
 <div class="col-md-8">
	<textarea class="form-control" id="others_status" placeholder="Enter Other Description(if any)" name="others_status" style="visibility: hidden;" rows="5"><?php  if(!empty($ce->ae_sts_desc)) echo $ce->ae_sts_desc;?></textarea>
	<div class="form_error">  <?php echo $this->session->flashdata('others_status');?></div>
</div>
 </div>

</div>
</div>
</div>

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Bank<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select class="form-control mb-md bank" required="" name="bank" onchange="if (this.value=='Other Bank'){this.form['other_bank'].style.visibility='visible'}else {this.form['other_bank'].style.visibility='hidden'};">
		<option value=""></option>
<option value="ADIB-BBMS" <?php if(!empty($ce->ae_bank)){ if($ce->ae_bank=='ADIB-BBMS'){echo "selected";}} ?>>ADIB-BBMS</option>
<option value="ADIB-Factory" <?php if(!empty($ce->ae_bank)){ if($ce->ae_bank=='ADIB-Factory'){echo "selected";}} ?>>ADIB-Factory</option>
<option value="ENBD" <?php if(!empty($ce->ae_bank)){ if($ce->ae_bank=='ENBD'){echo "selected";}} ?>>ENBD</option>
<option value="Cash Garhoud" <?php if(!empty($ce->ae_bank)){ if($ce->ae_bank=='Cash Garhoud'){echo "selected";}} ?>>Cash Garhoud</option>
<option value="EI Bank" <?php if(!empty($ce->ae_bank)){ if($ce->ae_bank=='EI Bank'){echo "selected";}} ?>>EI Bank</option>
<option value="Cash Mr. Bachir Book" <?php if(!empty($ce->ae_bank)){ if($ce->ae_bank=='Cash Mr. Bachir Book'){echo "selected";}} ?>>Cash Mr. Bachir Book</option>

<option value="Cash Factory" <?php if(!empty($ce->ae_bank)){ if($ce->ae_bank=='Cash Factory'){echo "selected";}} ?>>Cash Factory</option>

<option value="Other Bank" <?php if(!empty($ce->ae_bank)){ if($ce->ae_bank=='Other Bank'){echo "selected";}} ?>>Other Bank</option>
</select>
<div class="form_error">  <?php echo $this->session->flashdata('bank');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">

 <div class="form-group">
 	 <label class="col-md-4 control-label" for="inputDefault"></label>
 <div class="col-md-8">
	<textarea class="form-control" id="other_bank" placeholder="Enter Other Bank Details(if any)" name="other_bank" style="visibility: hidden;" rows="5"><?php  if(!empty($ce->ae_bank_desc)) echo $ce->ae_bank_desc;?></textarea>
	<div class="form_error">  <?php echo $this->session->flashdata('other_bank');?></div>
</div>
 </div>

</div>
</div>
</div>

<div class="row">
	<div class="col-md-12 col-sm-12 table-rows-border">
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Enter Amount<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" class="form-control acc_amount" required="" name="amount" value="<?php  if(!empty($ce->ae_amount)) echo $ce->ae_amount;?>"> 
 <div class="form_error">  <?php echo $this->session->flashdata('amount');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Cash type<abbr class="required">::*::</abbr></label>

<div class="col-md-8">
<label class="radio-inline">
<input type="radio" value="Received" required="" name="cash_type" <?php if(!empty($ce->ae_cash_type)){if($ce->ae_cash_type=='Received'){echo "checked";} }?>> We Received
</label>
<label class="checkbox-inline">
<input type="radio" value="Spend" required="" name="cash_type" <?php if(!empty($ce->ae_cash_type)){if($ce->ae_cash_type=='Spend'){echo "checked";} }?>> We Spend
</label>
<div class="form_error">  <?php echo $this->session->flashdata('cash_type');?></div>
</div>

</div>

</div>
</div>
</div>




</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit" class="btn btn-primary">Submit</button>
<button class="btn btn-primary modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>

</section>
</div>

<div id="modalSM<?php echo $ce->ae_id;?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Delete Entry?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
<p>Are you sure that you want to delete it?</p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">


<a href="<?php echo base_url('delete_account_entry/'.$ce->ae_id.'/dashboard');?>" class="delete-row">Confirm</a>


<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>

<?php 
}?>

</tbody>
</table>



</div>
</section>

