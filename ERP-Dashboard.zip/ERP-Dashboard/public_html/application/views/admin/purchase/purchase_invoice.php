<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head'); ?>

    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-datepicker/css/datepicker3.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/select2/select2.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/theme.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/skins/default.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/theme-custom.css">
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

    <script src="<?php echo base_url('admin_assets/'); ?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/pnotify/pnotify.custom.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css">
    <link href="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>

            <style type="text/css">
            .form_error {
            font-size: 13px;
            font-family: Arial;
            color: red;
            font-style: italic
            }

            .form_error p .errors {
            color: red;
            }

            .errors {
            font-size: 13px;
            font-family: Arial;
            color: red;
            font-style: italic
            }

            .success {
            font-size: 13px;
            font-family: Arial;
            color: green;
            font-style: italic
            }

            .table-rows-border {
            border-bottom: 1px solid #eff2f7;
            padding-bottom: 15px;
            margin-bottom: 15px;
            }

            .required {
            color: red;
            }

  .datepicker table tr td.active
{
    background-color:blue;
    color:white;
    border-radius: 50%;
}

table input.form-control {
width: auto;
}
</style>
</head>

<body>
<section class="body">

<?php $this->load->view('admin/header'); ?>

<div class="inner-wrapper">
<?php $this->load->view('admin/aside'); ?>
<section role="main" class="content-body">
<header class="page-header">
    <h2>Transactions </h2>
    <div class="right-wrapper pull-right">
        <ol class="breadcrumbs">
            <li>
                <a href="#">
                    <i class="fa fa-home"></i>
                </a>
            </li>
            <li><span>Purchases</span></li>
            <li><span>Purchase Invoice</span></li>
        </ol>
        <a class="sidebar-right-toggle"></a>
    </div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Issue Purchase Invoice </h2>
</header>
<div class="panel-body">
<?php echo form_open_multipart('Purchase_controller/submit_purchase_voc', 'class="myform" novalidate', ''); ?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
<input type="hidden" name="pi_inv_id" value="<?php if (!empty($result[0]->pi_id)) {echo $result[0]->pi_id;  }; ?>">
<input type="hidden" name="files_added" value="<?php if (!empty($result[0]->pi_attachments)) {echo $result[0]->pi_attachments;  }; ?>">
<input type="hidden" name="mrn_inv_id" > 

<div class="form_error">
<p class="errors"> <?php echo $this->session->flashdata('errors'); ?></p>
<p class="success"><?php echo $this->session->flashdata('success'); ?></p>
</div>
<p class="required"> Fileds marked as '::*::' are required fields</p>

<div class="row">

<div class="col-md-12 col-sm-12 table-rows-border">

    <div class="col-md-6 col-sm-12">


        <div class="form-group">
            <label class="col-md-4 control-label" for="inputPlaceholder">Doc No <abbr class="required">::*::</abbr></label>
            <div class="col-md-8">

                <input type="text" name="pi_doc_no" value="<?php if (!empty($result)) {
                                                                if (!empty($result[0]->pi_doc_no)) {
                                                                    echo $result[0]->pi_doc_no;
                                                                }
                                                            } else {
                                                                echo $doc_num;
                                                            } ?>" readonly class="form-control">


                <div class="form_error"> <?php echo $this->session->flashdata('pi_doc_no'); ?></div>
            </div>
        </div>

    </div>
    <div class="col-md-6 col-sm-12 table-rows-border">
        <div class="form-group">
            <label class="col-md-4 control-label" for="inputPlaceholder"> Date<abbr class="required">::*::</abbr>

            </label>
            <div class="col-md-8">
                <?php
                if (!empty($result[0]->pi_date))
                    $converted_date = date("m/d/Y", strtotime($result[0]->pi_date));
                ?>
                 <input type='text'  name="pi_date" class="form-control datetimepicker5"  required  disabled="disabled" 
                 value="<?php if(!empty($result[0]->pi_date)){echo $converted_date;}else{ echo date('m/d/Y');} ;?>" />
                <div class="form_error"> <?php echo $this->session->flashdata('pi_date'); ?></div>

            </div>
        </div>
    </div>
     <div class="col-md-6 col-sm-12 table-rows-border">
     </div>
     <div class="col-md-6 col-sm-12 table-rows-border">
        <div class="form-group">
            <label class="col-md-4 control-label" for="inputPlaceholder">Due Date<abbr class="required">::*::</abbr>

            </label>
            <div class="col-md-8">
                <?php
                if (!empty($result[0]->pi_due_date))
                    $converted_date = date("m/d/Y", strtotime($result[0]->pi_due_date));
                ?>
                 <input type='text'  name="pi_due_date" class="form-control datetimepicker4"  required   
                 value="<?php if(!empty($result[0]->pi_due_date)){echo $converted_date;}else{ echo date('m/d/Y');} ;?>" />
                <div class="form_error"> <?php echo $this->session->flashdata('pi_due_date'); ?></div>

            </div>
        </div>
    </div>
    
    <div class="col-md-6 col-sm-12 table-rows-border">
        <div class="form-group">
            <label class="col-md-4 control-label" for="inputPlaceholder"> Purchase Account<abbr class="required">::*::</abbr>

            </label>
            <div class="col-md-8">
                <select data-plugin-selectTwo class="form-control populate" name="pi_purchase_account" required="">
                    <!-- <option value="">Choose</option> -->
                    <?php
                    foreach ($purchase_accont as $cb) {
                        //pre_list($cb);
                    ?>
                        <option value="<?php echo $cb->id; ?>" <?php if (!empty($result[0]->pi_purchase_account)) {
                          if ($result[0]->pi_purchase_account == $cb->id) { echo "selected";} }; ?>><?php echo $cb->label; ?>
                          </option>
                    <?php
                    }
                    ?>
                </select>
                <div class="form_error"> <?php echo $this->session->flashdata('pi_purchase_account'); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-sm-12 table-rows-border">
        <div class="form-group">
            <label class="col-md-4 control-label" for="inputPlaceholder">Vendors<abbr class="required">::*::</abbr>
            </label>
            <div class="col-md-8">
              <select data-plugin-selectTwo class="form-control populate" name="pi_vendor" required="">
                    <option value="">Choose</option>
                    <?php
                    foreach ($vendors as $cb) {
                        //pre_list($cb);
                        if($cb->file == 1)
                        {
                    ?>
                        <option value="<?php echo $cb->id; ?>" <?php if (!empty($result[0]->pi_vendor)) {
                         if ($result[0]->pi_vendor == $cb->id) { echo "selected"; } }; ?>><?php echo $cb->label; ?>
                         </option>
                    <?php
                        }
                    }
                    ?>
                </select>
            </div>
        </div>
    </div>

                                    <div class="col-md-6 col-sm-12">
  <div class="form-group">
<a type="button" class="btn btn-warning pull-right mb-xs mt-xs mr-xs modal-sizes" onclick="load_sales_inv();" href="#modalmd_sinv">Load all MRN</a>
</div>
</div>

        <div class="col-md-6 col-sm-12 table-rows-border">
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder"> Company<abbr class="required">::*::</abbr>

                </label>
                <div class="col-md-8">
                    <select data-plugin-selectTwo class="form-control populate" name="pi_company" required="">
                        <option value="">Choose</option>
                        <?php
                        foreach ($company_masters as $cm) { ?>
                            <option value="<?php echo $cm->mcomp_id; ?>" <?php if (!empty($result[0]->pi_company)) {
                        if ($result[0]->pi_company == $cm->mcomp_id) { echo "selected";  } }; ?>> <?php echo $cm->mcomp_name; ?>
                        </option>
                        <?php
                        } ?>
                    </select>
                    <div class="form_error"> <?php echo $this->session->flashdata('pi_company'); ?></div>

                </div>
            </div>
        </div>

                                    
        <div class="col-md-6 col-sm-12 table-rows-border">
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder"> Bill No<abbr class="required">::*::</abbr>

                </label>
                <div class="col-md-8">
                    <input type='text' name="pi_bill_no" class="form-control" value="<?php if (!empty($result[0]->pi_bill_no)) {
                           echo $result[0]->pi_bill_no; }; ?>" />
           
                    <div class="form_error"> <?php echo $this->session->flashdata('pi_bill_no'); ?></div>

                </div>
            </div>

        </div>

        <div class="col-md-6 col-sm-12 table-rows-border">
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder"> Narration<abbr class="required">::*::</abbr>

                </label>
                <div class="col-md-8">
                    <textarea name="pi_narration" class="form-control" ><?php if (!empty($result[0]->pi_narration)) {
                           echo $result[0]->pi_narration; }; ?></textarea>
                    <div class="form_error"> <?php echo $this->session->flashdata('pi_narration'); ?></div>

                </div>
                <!-- <span class="pull-right">
                    <label class="checkbox-inline">
                        <input type="checkbox" name="add_cash_customer" value="1"> Reserve Quantity
                    </label>
                </span> -->
            </div>

        </div>
        
        <div class="col-md-6 col-sm-12 table-rows-border">
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder"> Import Permit
                </label>
                <div class="col-md-8">
                    <input type='text' name="pi_import_permit" class="form-control" 
                    value="<?php if (!empty($result[0]->pi_import_permit)) {echo $result[0]->pi_import_permit; }; ?>" />
                    <div class="form_error"> <?php echo $this->session->flashdata('pi_import_permit'); ?></div>
                </div>
               </div>
        </div>

        <div class="col-md-6 col-sm-12 table-rows-border">
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">Place of Supply
                </label>
                <div class="col-md-8">
                    <select data-plugin-selectTwo class="form-control populate" name="pi_place_of_supply">
                        <option value="">Choose</option>
                        <?php
                        foreach ($place_supply as $ps) { ?>
                            <option value="<?php echo $ps->mw_id; ?>" <?php if (!empty($result[0]->pi_place_of_supply)) {
                             if ($result[0]->pi_place_of_supply == $ps->mw_id) {echo "selected";  } }; ?>> <?php echo $ps->mps_name; ?></option>
                        <?php
                        } ?>
                    </select>
                    <div class="form_error"> <?php echo $this->session->flashdata('pi_place_of_supply'); ?></div>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-sm-12 table-rows-border">
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">Jurisdiction
                </label>
                <div class="col-md-8">
                    <select data-plugin-selectTwo class="form-control populate" name="pi_jurisdiction">
                        <option value="">Choose</option>
                        <?php
                        foreach ($place_supply as $ps) { ?>
                            <option value="<?php echo $ps->mw_id; ?>" <?php if (!empty($result[0]->pi_jurisdiction)) {
                             if ($result[0]->pi_jurisdiction == $ps->mw_id) {echo "selected";}}; ?>> <?php echo $ps->mps_name; ?>
                                 
                             </option>
                        <?php
                        } ?>

                    </select>
                    <div class="form_error"> <?php echo $this->session->flashdata('pi_jurisdiction'); ?></div>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-sm-12 table-rows-border">
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder"> Currency Name<abbr class="required">::*::</abbr>
                </label>
                <div class="col-md-8">
                    <select data-plugin-selectTwo class="form-control populate" name="pi_currency">
                        <option value="">Choose</option>
                        <?php
                        foreach ($currency_convt as $cv) {
                        ?>
                            <option value="<?php echo $cv->currency_name;?>" <?php if (!empty($result[0]->pi_currency)) {
                                                                        if ($result[0]->pi_currency == $cv->currency_name) {
                                                                            echo "selected";
                                                                        }
                                                                    } else {
                                                                        if ($cv->currency_name == "AED") {
                                                                            echo "selected";
                                                                        }
                                                                    }; ?>> <?php echo $cv->currency_name; ?> </option>
                        <?php
                        }
                        ?>
                    </select>
                    <div class="form_error"> <?php echo $this->session->flashdata('pi_currency'); ?></div>

                </div>
            </div>
        </div>

        <div class="col-md-6 col-sm-12 table-rows-border">
            <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder">Currenct Conv.<abbr class="required">::*::</abbr>
                </label>
                <div class="col-md-8">
                    <input type='text' name="pi_conv_value" readonly="" class="form-control" 
                    value="<?php if (!empty($result[0]->pi_conv_value)) { echo $result[0]->pi_conv_value; } else { echo "1"; }; ?>" />
                    <div class="form_error"> <?php echo $this->session->flashdata('pi_conv_value'); ?></div>
                </div>
            </div>
        </div>

    </div>

    <div class="col-md-12 col-sm-12 table-rows-border">
        <div class="form-group">
            <p>Upload files here.Make sure the file size is less than 2MB.</p>
            <input class="form-control" name="files[]" type="file" multiple required />
            <div class="form_error"> <?php echo $this->session->flashdata('files[]'); ?></div>
        </div>
    </div>
    <?php
    if (!empty($result[0]->pi_attachments)) {
        echo "<h4> FILES UPLOADED :</h4>";
        $files_are = explode(',', $result[0]->pi_attachments);
        foreach ($files_are as $fr) {
            echo "<a href='" . base_url("uploads/sales_invoice/" . $fr) . "' target='_blank'>" . $fr . "</a><br/>";
        }
    } else {
    }
    ?>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive">
<table class="table table-border table-rows-border ">
<thead>
   
    <th>Image</th>
    <th>Item</th>
    <th>Description</th>
    <th>Units</th>
    <th>Quantity</th>
    <th>Link-1</th>
    <th>Rate</th>
    <th>Gross</th>
    <th>Discount %</th>
    <th>Discount Amount</th>
    <th>Addl. Charges</th>

    <th>Reverse Charge</th>
    <th>Adjustment</th>
   
    <th>Tax Code</th>
     <th>Vat %</th>
    <th></th>
</thead>
<tbody class="new_rows all_table_rows">
    <?php
    if (!empty($result[0])) /////used in update value
    {
        $prd_added = explode('|#|', $result[0]->pi_product);
        $prd_desc = explode('|#|', $result[0]->pi_description);
        $prd_unit = explode('|#|', $result[0]->pi_unit);
        $prd_link=explode('|#|', $result[0]->pi_link_1);

        $qnty_added = explode('|#|', $result[0]->pi_qty);
        $sum_qnty = array_sum($qnty_added);

        $rate_added = explode('|#|', $result[0]->pi_rate);
        $sum_rate = array_sum($rate_added);

        $gross_added = explode('|#|', $result[0]->pi_gross);
        $sum_gross = array_sum($gross_added);

        $disper_added = explode('|#|', $result[0]->pi_discount_percentage);
        $sum_disper = array_sum($disper_added);

        $disamnt_added = explode('|#|', $result[0]->pi_discount_amount);
        $sum_disamnt = array_sum($disamnt_added);

        $add_charges_added = explode('|#|', $result[0]->pi_additional_charge);
        $sum_add_charges = array_sum($add_charges_added);

        $reverse_charge = explode('|#|', $result[0]->pi_reverse_charge);
        $adjustment = explode('|#|', $result[0]->pi_adjustment);
    
        $vat_added = explode('|#|', $result[0]->pi_vat);
         $sum_vat = array_sum($vat_added);
         $tax_code = explode('|#|', $result[0]->pi_tax_code);

        $total_count_rows = count($prd_added);
        $ik = 1;
        foreach ($prd_added as $ca_index => $pa) {
               $sql2=$this->db2->query("SELECT pcode,p_prd_img FROM products WHERE pid = ".$pa." ");
                                        $prd_details=$sql2->result_array();

             if(empty($prd_details[0]['p_prd_img']))
                {
                    $filename="https://birigroup.com/uploads/prd_images/".$prd_details[0]['pcode'].'.jpeg';
                 if (file_exists($filename)) {
                    $img_path=$filename;
                    } else {
                    $img_path="https://birigroup.com/uploads/prd_images/".$prd_details[0]['pcode'].'.jpg';
                    }
                }
                 else
                 {
                    $first_img_prd=explode(',',$prd_details[0]['p_prd_img']);
                    if(!empty($first_img_prd[0]))
                    $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                    else
                    $img_path="https://birigroup.com/uploads/prd_images/".$prd_details[0]['p_prd_img'];
                 }
                 $tot_dis_per_amont = $gross_added[$ca_index]*($disper_added[$ca_index] / 100) ;  
                $total_gross_calc=$gross_added[$ca_index]+$add_charges_added[$ca_index]-$tot_dis_per_amont-$disamnt_added[$ca_index];      
                               
                     if($vat_added[$ca_index]=='15')
                    {
                    $org_amount=$total_gross_calc/1.15;
                    $vat_amount_calc=$org_amount*0.15;
                    $tot_fnet_vat=$total_gross_calc-$vat_amount_calc;
                    }
                    elseif($vat_added[$ca_index]=='5')
                    {
                         $org_amount=$total_gross_calc/1.05;
                    $vat_amount_calc=$org_amount*0.05;
                    $tot_fnet_vat=$total_gross_calc-$vat_amount_calc;
                    }
                    else{}  
                            
    ?>
<tr>

<td><img src="<?php echo $img_path;?>" width="100" height="100" class="img-responsive img<?php echo $ik; ?>"></td>
<td>
<select data-plugin-selectTwo class="form-control populate product_<?php echo $ik; ?>" name="pi_product[]" onchange="get_product_details()">
<option value="">Choose</option>
<?php
foreach ($products_list as $prd) {
?>
    <option value="<?php echo $prd->pid; ?>" <?php if (!empty($pa)) { if ($pa == $prd->pid) { echo "selected"; } }; ?>> 
        <?php echo str_replace('|~~|', ',', $prd->pname); ?> ::<br /> <?php echo $prd->pcode; ?> 
     </option>
<?php
}
?>
</select>
</td>
<td><input type="text" name="pi_description[]"  class="form-control description<?php echo $ik; ?>" value="<?php if(!empty($prd_desc[$ca_index])){echo $prd_desc[$ca_index];};?>"> </td>
<td>
<input class="form-control populate unit<?php echo $ik; ?>" name="pi_unit[]" value="<?php if(!empty($prd_unit[$ca_index])){echo $prd_unit[$ca_index];};?>">
</td>

<td><input type="number" name="pi_qty[]" onchange="calc_gross(<?php echo $ik; ?>);" onkeyup="calc_gross(<?php echo $ik; ?>);"
min="0" value="<?php if (!empty($qnty_added[$ca_index])) { echo $qnty_added[$ca_index]; } else {  echo "0";}; ?>" step="any" 
class="form-control qnyt_dt qnty<?php echo $ik; ?>" readonly=""> </td>

<td><input type="text" name="pi_link_1[]"  class="form-control unit<?php echo $ik;?>"  value="<?php if(!empty($prd_link[$ca_index])){echo $prd_link[$ca_index];};?>"  readonly=""> </td>
<td><input type="number" name="pi_rate[]" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" 
value="<?php if (!empty($rate_added[$ca_index])) {echo $rate_added[$ca_index];} else {  echo "0"; }; ?>" step="any" 
class="form-control rate_dt rate<?php echo $ik; ?>" readonly=""> </td>

<td><input type="number" name="pi_gross[]" value="<?php if (!empty($gross_added[$ca_index])) {
                                                echo $gross_added[$ca_index]; } else { echo "0"; }; ?>" step="any" readonly="" 
                                                class="form-control gross_dt gross<?php echo $ik; ?>"></td>

<td>
<input type="hidden" name="dis_per_each_prd[]" value="<?php if (!empty($tot_dis_per_amont)) {
      echo $tot_dis_per_amont; } else { echo "0"; }; ?>" class="form-control dis_per_each_prd<?php echo $ik; ?>" readonly="">

<input type="number" name="pi_discount_amount[]" value="<?php if (!empty($disper_added[$ca_index])) {
           echo $disper_added[$ca_index];} else { echo "0";}; ?>" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" step="any"  class="form-control disc_per_dt disperc<?php echo $ik; ?>" readonly="">
</td>

<td><input type="number" name="pi_discount_amount[]" value="<?php if (!empty($disamnt_added[$ca_index])) {
      echo $disamnt_added[$ca_index];} else {echo "0";}; ?>" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" step="any"   class="form-control disc_amount_dt disamnt<?php echo $ik; ?>" readonly=""> </td>

<td><input type="number" name="pi_additional_charge[]" value="<?php if (!empty($add_charges_added[$ca_index])) {
                                                    echo $add_charges_added[$ca_index];
                                                } else { echo "0"; }; ?>" onchange="calc_gross(<?php echo $ik; ?>)"
                                                 onkeyup="calc_gross(<?php echo $ik; ?>)" step="any"
                                                 class="form-control add_charges_dt addchrg<?php echo $ik; ?>" readonly="">
</td>
<td><input type="text" name="pi_reverse_charge[]" value="<?php if($reverse_charge[$ca_index]){echo $reverse_charge[$ca_index];} ;?>"  class="form-control  reverse_charge<?php echo $ik; ?>"> </td>
<td><input type="text" name="pi_adjustment[]" value="<?php if($adjustment[$ca_index]){echo $adjustment[$ca_index];} ;?>"  class="form-control adjustment<?php echo $ik; ?>"> </td>
 <td>
    <span> Apply vat<input type="checkbox" name="vat_checkbox" value="1" class="prd_vat_per<?php echo $ik; ?> " oninput="vat_perc(<?php echo $ik; ?>);"></span><br/>
    <input type="text" name="pi_tax_code[]" readonly="" value="<?php if($tax_code[$ca_index]){echo $tax_code[$ca_index];} ;?>" class="form-control prd_tax_code_<?php echo $ik; ?>"> </td>
<td>
   <input type="text" name="pi_vat[]" value="<?php if(!empty($vat_added[$ca_index])){echo $vat_added[$ca_index];};?>" readonly="" class="form-control form_vat_input_amount_<?php echo $ik; ?> vat<?php echo $ik; ?>">
    <input type="hidden" name="vat_fnet_val[]"  value="<?php if(!empty($tot_fnet_vat)){echo $tot_fnet_vat;};?>" class="form-control vat_fnet_val<?php echo $ik; ?>"> 
    <input type="hidden" name="vat_each_prd[]"  value="<?php if(!empty($vat_amount_calc)){echo $vat_amount_calc;};?>" class="form-control vat_each_prd_val<?php echo $ik; ?>">
</td>

<td></td>
</tr>
        <?php
            $ik++;
        }
    } 
        ?>
    <button type="button" class="btn btn-primary pull-right" onclick="add_more_row();">Add More</button>

</tbody>
</table>
<!-----for input tyype hidden fields------------->
<input type="hidden" name="hi_prd_id" class="form-control">
<input type="hidden" name="hi_description" value="" class="form-control">
<input type="hidden" name="hi_unit" value="" class="form-control">
<input type="hidden" name="hi_quantity" value="0" class="form-control">
<input type="hidden" name="hi_link_1" value="" class="form-control">
<input type="hidden" name="hi_rate" value="0" class="form-control">
<input type="hidden" name="hi_gross" value="0" class="form-control">
<input type="hidden" name="hi_discount_perentage" value="0" class="form-control">
<input type="hidden" name="hi_discount_amount" value="0" class="form-control">
<input type="hidden" name="hi_additional_charge" value="0" class="form-control">

<input type="hidden" name="hi_fnet" value="0" class="form-control">
<input type="hidden" name="hi_vat" value="0" class="form-control">

<input type="hidden" name="hi_reverse_charge" class="form-control datetimepicker5">
<input type="hidden" name="hi_adj" class="form-control">
<input type="hidden" name="hi_tax_code" value="0" class="form-control">
<input type="hidden" name="hi_aray_index_pos" value="0" class="form-control">
<input type="hidden" name="hid_date" value="0" class="form-control">
<input type="hidden" name="mrn_id" value="<?php if(!empty($result[0]->mrn_id)){echo $result[0]->mrn_id;}else{echo "0";};?>" class="form-control">
<!---------end for input type hidden--->
</div>
</div>
                <!-------start col-md-12------------------->
                <div class="col-md-12 col-sm-12 table-rows-border">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
                    <div class="col-md-8">
                        <span class="num_items">
                            <?php
                            if (!empty($result[0])) {
                                if (!empty($total_count_rows)) {
                                    echo $total_count_rows;
                                } else {
                                    echo "1";
                                }
                            } else {
                                echo "1";
                            }
                            ?>
                        </span>
                    </div>
                </div>
                <!----------end col-md-12----------------------------->

                <!-------start col-md-12------------------->
                <div class="col-md-6 col-sm-12 table-rows-border">
                    <label class="col-md-4 control-label" for="inputPlaceholder">Total Quantity:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="qnty_tot_button" name="si_tot_qnty" required="required" 
                        value="<?php if (!empty($sum_qnty)) { echo $sum_qnty;} else {    echo "0"; }; ?>">
                    </div>
                </div>
                <!----------end col-md-12----------------------------->
                <!-------start col-md-12------------------->
                <div class="col-md-6 col-sm-12 table-rows-border">
                    <label class="col-md-4 control-label" for="inputPlaceholder" style="display: none;"> Total Rate:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="hidden" readonly class="rate_tot_button" name="si_tot_rate" required="required" 
                        value="<?php if (!empty($sum_rate)) { echo $sum_rate;} else { echo "0"; }; ?>">
                    </div>
                </div>
                <!----------end col-md-12----------------------------->
                <!-------start col-md-12------------------->
                <div class="col-md-6 col-sm-12 table-rows-border">
                    <label class="col-md-4 control-label" for="inputPlaceholder"> Total Gross:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="gross_tot_button" name="si_tot_gross" required="required" 
                        value="<?php if (!empty($sum_gross)) { echo $sum_gross;} else {   echo "0"; }; ?>">
                    </div>
                </div>
                <!----------end col-md-12----------------------------->
                <!-------start col-md-12------------------->
                <div class="col-md-6 col-sm-12 table-rows-border">
                    <label class="col-md-4 control-label" for="inputPlaceholder"> Total Discount Percentage:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="disc_per_tot_button" name="si_tot_desc_per" required="required" 
                        value="<?php if (!empty($sum_disper)) { echo $sum_disper; } else {  echo "0";}; ?>">
                    </div>
                </div>
                <!----------end col-md-12----------------------------->
                <!-------start col-md-12------------------->
                <div class="col-md-6 col-sm-12 table-rows-border">
                    <label class="col-md-4 control-label" for="inputPlaceholder"> Total Discount Amount:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="disc_amount_tot_button" name="si_tot_desc_amount" required="required" 
                        value="<?php if (!empty($sum_disamnt)) { echo $sum_disamnt; } else {  echo "0"; }; ?>">
                    </div>
                </div>
                <!----------end col-md-12----------------------------->

                <!-------start col-md-12------------------->
                <div class="col-md-6 col-sm-12 table-rows-border">
                    <label class="col-md-4 control-label" for="inputPlaceholder"> Total Additional Charges:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="add_charges_tot_button" name="si_tot_add_charges" required="required" 
                        value="<?php if (!empty($sum_add_charges)) {echo $sum_add_charges;} else { echo "0";}; ?>">
                    </div>
                </div>
                <!----------end col-md-12----------------------------->
                <!-------start col-md-12------------------->
                <!-- <div class="col-md-6 col-sm-12 table-rows-border">

                    <label class="col-md-4 control-label" for="inputPlaceholder"> Total Fnet:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="fnet_tot_button" name="si_tot_fnet" required="required" value="<?php if (!empty($sum_fnet)) {
                          echo $sum_fnet;} else { echo "0";}; ?>">
                    </div>
                </div> -->
                <!----------end col-md-12----------------------------->
                <!-------start col-md-12------------------->
                <div class="col-md-6 col-sm-12 table-rows-border">
                    <label class="col-md-4 control-label" for="inputPlaceholder"> Total VAT Charges:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="vat_tot_button" name="pi_total_vat_amount" required="required" 
                        value="<?php if (!empty($result[0]->pi_total_vat_amount)) {echo $result[0]->pi_total_vat_amount; } else {echo "0"; }; ?>">
                    </div>
                </div>
                <!----------end col-md-12----------------------------->
                <!-------start col-md-12------------------->
                <div class="col-md-12 col-sm-12 table-rows-border">

                    <button class="btn btn-primary" type="button" onclick="get_amount_total()">Click to see total amount</button>
                    <br />
                    <label class="col-md-4 control-label amount_text" for="inputPlaceholder">Amount Total:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="amount_tot_button" name="pi_total_amount" required="required" 
                        value="<?php if (!empty($result[0]->pi_total_amount)) {echo $result[0]->pi_total_amount;} else { echo "0";}; ?>">
                        <small>Amount as per the currency rate selected</small>
                    </div>
                </div>
                <!----------end col-md-12----------------------------->

                <!-----div starts here for non-inquiry--->
                <!----div end here for non-inquiry--->
                    </section>
                    <!-----div starts here for non-inquiry--->
                    <input type="hidden" name="sales_inv_cust_id">
                    <input type="hidden" name="sales_inv_id">
                    <input type="hidden" name="sales_inv_amount">
                    <input type="hidden" name="sales_inv_amount_paid">
                    <input type="hidden" name="sales_doc_num">

                    <!-----div starts here for non-inquiry--->
                    <!-- Button trigger modal for sales invoice-->
                    <div id="modalmd_sinv" class="modal-block modal-block-lg mfp-hide">
                        <section class="panel">
                            <header class="panel-heading">
                                <h2 class="panel-title">References </h2>
                            </header>
                            <div class="panel-body">
                                <div class="modal-wrapper">
                                    <div class="modal-text modal_content_sinv">

                                    </div>
                                </div>
                            </div>
                            <footer class="panel-footer">
                                <div class="row">
                                    <div class="col-md-12 text-right">
                                        <button type="button" onclick="submit_sales_inv_amount()" class="btn btn-primary confirm_btn_modal">Confirm</button>
                                        <button class="btn btn-default modal-dismiss modal-close-btn">Cancel</button>
                                    </div>
                                </div>
                            </footer>
                        </section>
                    </div>
                    <!----end modal--->
                    <!----div closes here--->


                    <div class="cell_text_data"></div>

                    <div class="col-sm-9 col-sm-offset-3">
                       
                        <button  type="submit" class="submit_btn">Save</button>
                        <button type="reset" class="btn btn-default" onclick="check_for_reset()">Reset</button>
                    </div>

                    <?php echo form_close(); ?>
                </div>
            </div>

            </section>
            </div>
            </section>

            <aside id="sidebar-right" class="sidebar-right">
            <div class="nano">
            <div class="nano-content">
            <a href="#" class="mobile-close visible-xs">
                Collapse <i class="fa fa-chevron-right"></i>
            </a>
            <div class="sidebar-right-wrapper">

                <div class="sidebar-widget widget-friends ">

                    <div class="chat_window">
                        <?php $this->load->view('admin/master_essential/chat_data', $chat); ?>

                    </div>
                </div>

            </div>
            </div>
            </div>
            </aside>

<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/'); ?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/forms/examples.advanced.form.js" type="text/javascript" />
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript"></script>


<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>


<script>
$(document).on('ready', function() {
$('input').attr('autocomplete', 'off');
$("#file-1").fileinput();
});
</script>

<script>
tinymce.init({
selector: '.editors',
plugins: [
'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
],
});
</script>

<script type="text/javascript">

</script>

    <script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
    <script>
    tinymce.init({
    selector: '.editors',
    plugins: [
    'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
    ],
    });
    </script>

            <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

            <script type="text/javascript">
            $(function() {
            $('.datetimepicker4').datepicker();
            });

            $(function() {
            var date2 = $('.datetimepicker4').datepicker('getDate', '+1d');
            date2.setDate(date2.getDate() + 1);
            $('.datetimepicker5').datepicker().datepicker("setDate", date2);
            });

            $(document).on('ready', function() {
            $('select[name="si_currency"]').on('change', function() {

            jQuery.ajax({
                url: "<?php echo base_url() . 'Receipt_Master/get_currency_conv_val'; ?>",
                data: {
                    "currecny_selected": $(this).val()
                },
                type: "post",
                success: function(result) {
                    if (result) {
                        $("input[name='si_conv_value']").val(result);
                    }
                }
            });
            });

            $('.menu_name_fun').on('click', function() {
            if (confirm("Are you sure, You want to exit this page?")) {
                location.href = $(this).attr('href');
            } else {
                return false;
            }
            });

             $('select[name="pi_place_of_supply"]').on("change",function(){
                var selected_val=$(this).val();
                $('select[name="pi_jurisdiction"]').val(selected_val).trigger('change');
             });

            });

            function get_product_details(table_id) {
            var prd_selected = $('.product_' + table_id).find('option:selected').val();
            
            jQuery.ajax({
            url: "<?php echo base_url() . 'Sales_invoice/get_product_details'; ?>",
            data: {
                "prd_id": prd_selected
            },
            type: "post",
            success: function(result) {
                if (result) {
                    var returndata = JSON.parse(result);
                    $('.img' + table_id).attr('src', returndata['pimage']);
                    $('.rate' + table_id).val(returndata['prd_price']);
                    // console.log(result);
                }
            }
            });
            jQuery.ajax({
            url: "<?php echo base_url() . 'Purchase_controller/get_product_extras'; ?>",
            data: {
            "prd_id": prd_selected,
            "table_id": table_id
            },
            type: "post",
            success: function(result) {
            if (result) {
                console.log(result);
                $('.unit' + table_id).html(result);
            }
            }
            });
            }

            function get_amount_total() {
            var amountss1 = '0';
            $('table tbody tr td input[name="pi_qty[]"]').each(function() {
            amountss1 = parseFloat(amountss1) + parseFloat($(this).val());
            });
            $('.qnty_tot_button').val(parseFloat(amountss1.toFixed(2)));

            //////for rate tot calc//////
            var amountss_2 = '0';
            $('table tbody tr td input[name="pi_rate[]"]').each(function() {
            amountss_2 = parseFloat(amountss_2) + parseFloat($(this).val());
            });
            $('.rate_tot_button').val(parseFloat(amountss_2.toFixed(2)));

            /////////for gross tot_calc//////////

            var amountss_3 = '0';
            $('table tbody tr td input[name="pi_gross[]"]').each(function() {
            amountss_3 = parseFloat(amountss_3) + parseFloat($(this).val());
            });
            $('.gross_tot_button').val(parseFloat(amountss_3.toFixed(2)));

            ///////for dis per tot calc field/////////
            //  var amountss_4='0';
            // $('table tbody tr td input[name="si_dis_per[]"]').each(function(){
            // amountss_4= parseFloat(amountss_4)+parseFloat($(this).val());
            // }); 
            // $('.disc_per_tot_button').val(parseFloat(amountss_4));

            ///////for dis per tot calc field/////////
            var amountss_4_1 = '0';
            $('table tbody tr td input[name="each_disc_per_amount[]"]').each(function() {
                  console.log($(this).val());
            amountss_4_1 = parseFloat(amountss_4_1) + parseFloat($(this).val());
            });
            $('.disc_per_tot_button').val(parseFloat(amountss_4_1.toFixed(2)));

            //////for dis amount tot calc field/////////
            var amountss_5 = '0';
            $('table tbody tr td input[name="pi_discount_amount[]"]').each(function() {

            amountss_5 = parseFloat(amountss_5) + parseFloat($(this).val());
            });
            $('.disc_amount_tot_button').val(parseFloat(amountss_5.toFixed(2)));

            //////////for add charges tot calc field///////
            var amountss_6 = '0';
            $('table tbody tr td input[name="pi_additional_charge[]"]').each(function() {
            amountss_6 = parseFloat(amountss_6) + parseFloat($(this).val());
            });
            $('.add_charges_tot_button').val(parseFloat(amountss_6.toFixed(2)));

            ///////for fnet tot calc field///////////
            var amountss_7 = '0';
           
            ////////////for vat tot calc field//////
             var amountss_8='0';
            $('table tbody tr td input[name="each_vat_total[]"]').each(function(){
            amountss_8= parseFloat(amountss_8)+parseFloat($(this).val());
            }); 
            $('.vat_tot_button').val(parseFloat(amountss_8));

             var amountss_9='0';
            $('table tbody tr td input[name="each_fnet_total[]"]').each(function(){
            amountss_9= parseFloat(amountss_9)+parseFloat($(this).val());
            }); 
            $('.amount_tot_button').val(parseFloat(amountss_9));

            }

        function load_sales_inv()
        {
             var cust_id=$('select[name="pi_vendor"]').find('option:selected').val();
             var cust_name=$('select[name="pi_vendor"]').find('option:selected').text();

          jQuery.ajax({
               url:"<?php echo base_url().'Purchase_controller/get_vendor_mrn';?>",
                data:{"cust_id":cust_id},
              type:"post",
               success:function(result)
                {
                  if(result)
                  {
                  $('.modal_content_sinv').html(result);
                  $('.cust_name_val').html(cust_name);
                   $('#datatable-default2').DataTable();
                  }
                }
               }); 
        }
            ///////////////////////modal functions page/////////////////////////////////////////////////
 $('.confirm_btn_modal').on('click',function()
{
      $('input[name="choose_inv"]:checked').each(function() {
      
        jQuery.ajax({///////////this ajax for getting the form filled/////////////////
       url:"<?php echo base_url().'Purchase_controller/get_inv_details_checked';?>",
        data:{"checked_inv":this.value},
      type:"post",
       success:function(result)
        {
         // console.log(result);
          if(result)
          {
         var returndata = JSON.parse(result);
       // console.log(returndata);
          $('select[name="pi_company"] ').val(returndata['company']).trigger('change');
         $('select[name="pi_place_of_supply"]').val(returndata['pls_sup']).trigger('change');
          $('select[name="pi_jurisdiction"]').val(returndata['jurisdiction']).trigger('change');
           $('textarea[name="pi_narration"]').val(returndata['narration']);
           $('input[name="mrn_id"]').val(returndata['mrn_id']);
            // $('.vat_tot_button').val(returndata['tot_vat']);
             //   $('.amount_tot_button').val(returndata['tot_net']); 
         
             if(returndata['currency_val']!=null)
              {
               $('select[name="pi_currency"]').val(returndata['currency']).trigger('change');
               if(returndata['currency_val']!=null)
               $('input[name="pi_conv_value"]').val(returndata['currency_val']);
               else
                 $('input[name="pi_conv_value"]').val('1');
             }
             else
             {
                $('select[name="pi_currency"]').val('AED').trigger('change');
                $('input[name="pi_conv_value"]').val('1');
             }
          //$('.modal_content_sinv').html(result);
          // $('#datatable-default2').DataTable();
          }
        }
       }); 

        jQuery.ajax({////////this ajax for printing the table with data//////////////////
       url:"<?php echo base_url().'Purchase_controller/get_inv_table_checked';?>",
        data:{"checked_inv":this.value},
      type:"post",
       success:function(result)
        {
          if(result)
          {
          //   console.log(result);
         // $('table tbody .all_table_rows').html(result);
               var returndata = JSON.parse(result);
            //   console.log(returndata);
              $(returndata['html_result']).each(function(key,val) { 
               $('table .all_table_rows').append(val);
             });
              $('.modal-close-btn').click();      
              }
            }
           }); 
         });
   });         
            /////////////////////end of modal functions////////////////////////////////////


            function check_for_reset() {
            if (confirm("Are you sure, You want to reset this form?")) {
            $('.myform').trigger("reset");
            } else {
            return false;
            }
            }


            $('.myform').submit(function() {
           // e.preventDefault();

            var rowcount = $('.new_rows tr').length;

            var prd_ids = $('table tbody tr td input[name="pi_product[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var aray_index_pos=$('table tbody tr td input[name="prd_index_position[]"]').map(function(){
                return $(this).val();}).get().join('|#|'); 

            var prd_desc = $('table tbody tr td input[name="pi_description[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var prd_unit = $('table tbody tr td input[name="pi_unit[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var prd_link = $('table tbody tr td input[name="pi_link_1[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var qnty_nos = $('table tbody tr td input[name="pi_qty[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var rate_nos = $('table tbody tr td input[name="pi_rate[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var gross_nos = $('table tbody tr td input[name="pi_gross[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var disc_per_nos = $('table tbody tr td input[name="pi_discount_percentage[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var disc_amount_nos = $('table tbody tr td input[name="pi_discount_amount[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var add_charges_nos = $('table tbody tr td input[name="pi_additional_charge[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var reverse_charges = $('table tbody tr td input[name="pi_reverse_charge[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var adjustments = $('table tbody tr td input[name="pi_adjustment[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var fent_nos = $('table tbody tr td input[name="each_fnet_total[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            var vat_nos = $('table tbody tr td input[name="pi_vat[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

      
            var tax_code_nos = $('table tbody tr td input[name="pi_tax_code[]"]').map(function() {
            return $(this).val();
            }).get().join('|#|');

            //console.log(quantity+' '+package_size+' '+product_id);

            $("input[name='hi_prd_id']").val(prd_ids);
            $("input[name='hi_description']").val(prd_desc);
            $("input[name='hi_unit']").val(prd_unit);
            $("input[name='hi_link_1']").val(prd_link);
            $("input[name='hi_quantity']").val(qnty_nos);
            $("input[name='hi_rate']").val(rate_nos);
            $("input[name='hi_gross']").val(gross_nos);
            $("input[name='hi_discount_perentage']").val(disc_per_nos);
            $("input[name='hi_discount_amount']").val(disc_amount_nos);
            $("input[name='hi_additional_charge']").val(add_charges_nos);
            $("input[name='hi_fnet']").val(fent_nos);
            $("input[name='hi_vat']").val(vat_nos);
            $("input[name='hi_reverse_charge']").val(reverse_charges);
            $("input[name='hi_adj']").val(adjustments);
            $("input[name='hi_tax_code']").val(tax_code_nos);
            $("input[name='hi_aray_index_pos']").val(aray_index_pos);
            $("input[name='hid_date']").val($("input[name='pi_date']").val());

            var ij = 0;
            var data_var = [];

            $('.new_rows tr td').each(function() {
            var cellText = $(this).html();
            //  console.log(cellText);  
            $('.cell_text_data').append(cellText).hide();
            });
            //console.log(cellText);
           // console.log($("input[name='hi_prd_id']").val());
            // console.log($("input[name='hi_description']").val());
            // console.log($("input[name='hi_unit']").val());
            // console.log($("input[name='hi_link_1']").val());
            //  console.log($("input[name='hid_ref']").val());
            //var table_row_added=$('.new_rows').html();

            if ($('.new_rows tr').length == 0) {
            alert('Please choose items to add and submit');
            return false;
            } else {
            return true;
            }
           // return false;
            // your code here
            });
            // }
            </script>

            </body>

            </html>