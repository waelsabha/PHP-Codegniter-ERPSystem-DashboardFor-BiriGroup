<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head'); ?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-datepicker/css/datepicker3.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<script src="<?php echo base_url('admin_assets/'); ?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/pnotify/pnotify.custom.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css">
<link href="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css" />

<style type="text/css">
.form_error {
font-size: 13px;
font-family: Arial;
color: red;
font-style: italic
}

.form_error p .errors {
color: red;
}

.errors {
font-size: 13px;
font-family: Arial;
color: red;
font-style: italic
}

.success {
font-size: 13px;
font-family: Arial;
color: green;
font-style: italic
}

.table-rows-border {
border-bottom: 1px solid #eff2f7;
padding-bottom: 15px;
margin-bottom: 15px;
}

.required {
color: red;
}

.datepicker table tr td.today
{
    background-color:blue;
    color:white;
     border-radius: 50%;
}

table input.form-control {
width: auto;
}
</style>
</head>

<body>
<section class="body">

<?php $this->load->view('admin/header'); ?>

<div class="inner-wrapper">
<?php $this->load->view('admin/aside'); ?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Transactions </h2>
<div class="right-wrapper pull-right">
    <ol class="breadcrumbs">
        <li>
            <a href="#">
                <i class="fa fa-home"></i>
            </a>
        </li>
        <li><span>Purchases</span></li>
        <li><span>Material Receipt Note</span></li>
    </ol>
    <a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
    <section class="panel panel-featured panel-featured-primary">
        <header class="panel-heading">
            <h2 class="panel-title">Issue Material Receipt Note </h2>
        </header>
        <div class="panel-body">
            <?php echo form_open_multipart('Purchase_controller/submit_mrn', 'class="myform" novalidate', ''); ?>
            <!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
                <input type="hidden" name="mrn_id" value="<?php if (!empty($result[0]->mrn_id)) {
                    echo $result[0]->mrn_id;}; ?>">
                <input type="hidden" name="files_added" value="<?php if (!empty($result[0]->mrn_attachments)) {
                    echo $result[0]->mrn_attachments;}; ?>">
                <div class="form_error">
                    <p class="errors"> <?php echo $this->session->flashdata('errors'); ?></p>
                    <p class="success"><?php echo $this->session->flashdata('success'); ?></p>
                </div>
                <p class="required"> Fileds marked as '::*::' are required fields</p>
                <div class="row">
                    <div class="col-md-12 col-sm-12 table-rows-border">
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <label class="col-md-4 control-label" for="inputPlaceholder">Doc No <abbr class="required">::*::</abbr></label>
                                <div class="col-md-8">
                                    <input type="text" name="mrn_doc_no" value="<?php if (!empty($result)) {
                                        if (!empty($result[0]->mrn_doc_no)) {
                                            echo $result[0]->mrn_doc_no;
                                        }
                                        } else {
                                            echo $doc_num;
                                        } ?>" readonly class="form-control">
                                        <div class="form_error"> <?php echo $this->session->flashdata('mrn_doc_no'); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12 table-rows-border">
                                <div class="form-group">
                                    <label class="col-md-4 control-label" for="inputPlaceholder"> Date<abbr class="required">::*::</abbr>
                                    </label>
                                    <div class="col-md-8">
                                        <?php
                                        if (!empty($result[0]->mrn_date))
                                            $converted_date = date("m/d/Y", strtotime($result[0]->mrn_date));
                                        ?>
                                       <input type='text'  name="mrn_date" class="form-control datetimepicker5"  required value="<?php if(!empty($result[0]->mrn_date)){echo $converted_date;};?>" />
                                        <div class="form_error"> <?php echo $this->session->flashdata('mrn_date'); ?></div>

                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-12 table-rows-border">
                                <div class="form-group">
                                    <label class="col-md-4 control-label" for="inputPlaceholder"> Purchase Account<abbr class="required">::*::</abbr>

                                    </label>
                                    <div class="col-md-8">
                                        <select data-plugin-selectTwo class="form-control populate" name="mrn_purchase_account" required="">
                                            <!-- <option value="">Choose</option> -->
                                            <?php
                                            foreach ($purchase_accont as $cb) {
                                        //pre_list($cb);
                                                ?>
                                                <option value="<?php echo $cb->id; ?>" <?php if (!empty($result[0]->mrn_purchase_account)) {
                                                    if ($result[0]->mrn_purchase_account == $cb->id) {
                                                        echo "selected";
                                                    }
                                                }; ?>><?php echo $cb->label; ?></option>

                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <div class="form_error"> <?php echo $this->session->flashdata('mrn_purchase_account'); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12 table-rows-border">
                                <div class="form-group">
                                    <label class="col-md-4 control-label" for="inputPlaceholder">Vendors<abbr class="required">::*::</abbr>
                                    </label>
                                    <div class="col-md-8">
                                        <select data-plugin-selectTwo class="form-control populate" name="mrn_vendor" required="">
                                            <option value="">Choose</option>
                                            <?php
                                            foreach ($vendors as $cb) {
                                        //pre_list($cb);
                                                if($cb->file == 1)
                                                {
                                                    ?>
                                                    <option value="<?php echo $cb->id; ?>" <?php if (!empty($result[0]->mrn_vendor)) {
                                                        if ($result[0]->mrn_vendor == $cb->id) {
                                                            echo "selected";
                                                        }
                                                    }; ?>><?php echo $cb->label; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-12 table-rows-border">
                                <div class="form-group">
                                    <label class="col-md-4 control-label" for="inputPlaceholder"> Company<abbr class="required">::*::</abbr>

                                    </label>
                                    <div class="col-md-8">
                                        <select data-plugin-selectTwo class="form-control populate" name="mrn_company" required="">
                                            <option value="">Choose</option>
                                            <?php
                                            foreach ($company_masters as $cm) { ?>
                                                <option value="<?php echo $cm->mcomp_id; ?>" <?php if (!empty($result[0]->mrn_company)) {
                                                    if ($result[0]->mrn_company == $cm->mcomp_id) {
                                                        echo "selected";
                                                    }
                                                }; ?>> <?php echo $cm->mcomp_name; ?></option>
                                                <?php
                                            } ?>

                                        </select>
                                        <div class="form_error"> <?php echo $this->session->flashdata('mrn_company'); ?></div>

                                    </div>
                                </div>
                            </div>


                            <div class="col-md-6 col-sm-12 table-rows-border">
                                <div class="form-group">
                                    <label class="col-md-4 control-label" for="inputPlaceholder"> Warehouse<abbr class="required">::*::</abbr>

                                    </label>
                                    <div class="col-md-8">

                                        <select data-plugin-selectTwo class="form-control populate" name="mrn_warehouse" required="">
                                            <option value="">Choose</option>
                                            <?php
                                            foreach ($warehouse_data as $wd) { ?>
                                                <option value="<?php echo $wd->mw_id;?>" <?php if (!empty($result[0]->mrn_warehouse)) {
                                                    if ($result[0]->mrn_warehouse == $wd->mw_id) {
                                                        echo "selected";
                                                    }
                                                }; ?>> <?php echo $wd->mw_name;?> </option> 
                                                <?php
                                            } ?>

                                        </select>
                                        <div class="form_error"> <?php echo $this->session->flashdata('mrn_warehouse'); ?></div>

                                    </div>
                            <!-- <span class="pull-right">
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="add_cash_customer" value="1"> Reserve Quantity
                                </label>
                            </span> -->
                        </div>

                    </div>

                <div class="col-md-6 col-sm-12 table-rows-border">
                <div class="form-group">
                <label class="col-md-4 control-label" for="inputPlaceholder"> Narration<abbr class="required">::*::</abbr>
                </label>
                <div class="col-md-8">
                    <textarea name="mrn_narration" class="form-control"><?php if (!empty($result[0]->mrn_narration)) {echo $result[0]->mrn_narration;}; ?></textarea>
                <div class="form_error"> <?php echo $this->session->flashdata('mrn_narration'); ?></div>
                </div>
                 </div>
                </div> 

                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="inputPlaceholder"> Delivery Reference Number

                            </label>
                            <div class="col-md-8">
                                <input type='text' name="mrn_delivery_reference_no" class="form-control" value="<?php if (!empty($result[0]->mrn_delivery_reference_no)) {echo $result[0]->mrn_delivery_reference_no; }; ?>" />
                                <div class="form_error"> <?php echo $this->session->flashdata('mrn_delivery_reference_no'); ?></div>

                            </div>
                            <!-- <span class="pull-right">
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="add_cash_customer" value="1"> Reserve Quantity
                                </label>
                            </span> -->
                        </div>

                    </div>


                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="inputPlaceholder">Place of Supply
                            </label>
                            <div class="col-md-8">
                                <select data-plugin-selectTwo class="form-control populate" name="mrn_place_of_supply">
                                    <option value="">Choose</option>
                                    <?php
                                    foreach ($place_supply as $ps) { ?>
                                        <option value="<?php echo $ps->mw_id; ?>" <?php if (!empty($result[0]->mrn_place_of_supply)) {
                                            if ($result[0]->mrn_place_of_supply == $ps->mw_id) {
                                                echo "selected";
                                            }
                                        }; ?>> <?php echo $ps->mps_name; ?></option>
                                        <?php
                                    } ?>
                                </select>
                                <div class="form_error"> <?php echo $this->session->flashdata('mrn_place_of_supply'); ?></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="inputPlaceholder">Jurisdiction
                            </label>
                            <div class="col-md-8">
                                <select data-plugin-selectTwo class="form-control populate" name="mrn_jurisdiction">
                                    <option value="">Choose</option>
                                    <?php
                                    foreach ($place_supply as $ps) { ?>
                                        <option value="<?php echo $ps->mw_id; ?>" <?php if (!empty($result[0]->mrn_jurisdiction)) {
                                            if ($result[0]->mrn_jurisdiction == $ps->mw_id) {
                                                echo "selected";
                                            }
                                        }; ?>> <?php echo $ps->mps_name; ?></option>
                                        <?php
                                    } ?>
                                </select>
                                <div class="form_error"> <?php echo $this->session->flashdata('mrn_jurisdiction'); ?></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="inputPlaceholder"> Currency Name<abbr class="required">::*::</abbr>
                            </label>
                            <div class="col-md-8">
                                <select data-plugin-selectTwo class="form-control populate" name="mrn_currency">
                                    <option value="">Choose</option>
                                    <?php
                                    foreach ($currency_convt as $cv) {
                                        ?>
                                        <option value="<?php echo $cv->currency_name; ?>" <?php if (!empty($result[0]->mrn_currency)) {
                                            if ($result[0]->mrn_currency == $cv->currency_name) {
                                                echo "selected";
                                            }
                                        } else {
                                            if ($cv->currency_name == "AED") {
                                                echo "selected";
                                            }
                                        }; ?>> <?php echo $cv->currency_name; ?> </option>
                                        <?php
                                    }
                                    ?>
                                </select>
                                <div class="form_error"> <?php echo $this->session->flashdata('mrn_currency'); ?></div>

                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="inputPlaceholder">Currenct Conv.<abbr class="required">::*::</abbr>

                            </label>
                            <div class="col-md-8">
                                <input type='text' name="mrn_conv_value" readonly="" class="form-control" value="<?php if (!empty($result[0]->mrn_conv_value)) {
                                    echo $result[0]->mrn_conv_value; } else { echo "1"; }; ?>" />
                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_conv_value'); ?></div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="col-md-12 col-sm-12 table-rows-border">
                        <div class="form-group">
                            <p>Upload files here.Make sure the file size is less than 2MB.</p>
                            <input class="form-control" name="files[]" type="file" multiple required />
                            <div class="form_error"> <?php echo $this->session->flashdata('files[]'); ?></div>
                        </div>
                    </div>
                    <?php
                    if (!empty($result[0]->mrn_attachments)) {
                        echo "<h4> FILES UPLOADED :</h4>";
                        $files_are = explode(',', $result[0]->mrn_attachments);
                        foreach ($files_are as $fr) {
                            echo "<a href='" . base_url("uploads/sales_invoice/" . $fr) . "' target='_blank'>" . $fr . "</a><br/>";
                        }
                    } else {
                    }
                    ?>

                    <div class="col-md-12 col-sm-12 table-rows-border">
                        <div class="table-responsive">
                            <table class="table table-border table-rows-border">
                                <thead>

                                    <th>Image</th>
                                    <th>Item</th>
                                    <th>Description</th>
                                    <th>Units</th>
                                    <th>Quantity</th>
                                    <th>Link-1</th>
                                    <th>Rate</th>
                                    <th>Gross</th>
                                    <th>Discount %</th>
                                    <th>Discount Amount</th>
                                    <th>Addl. Charges</th>

                                    <th>Frieght</th>
                                    <th>Clearing</th>
                                    <th>Load/Unload</th>

                                    <th>Other</th>
                                    <th>Customs</th>
                                    <th>Control</th>
                                     <th>Tax Code</th>
                                    <th>Vat %</th>

                                   
                                    <th></th>
                                </thead>
                                <tbody class="new_rows">
                                    <?php
                                if (!empty($result[0])) /////used in update value
                                {
                                    $prd_added = explode('|#|', $result[0]->mrn_product);
                                    $prd_desc=explode('|#|',$result[0]->mrn_description);
                                    $prd_unit=explode('|#|',$result[0]->mrn_unit);
                                    $prd_link=explode('|#|',$result[0]->mrn_link);

                                    $qnty_added = explode('|#|', $result[0]->mrn_qty);
                                    $sum_qnty = array_sum($qnty_added);

                                    $rate_added = explode('|#|', $result[0]->mrn_rate);
                                    $sum_rate = array_sum($rate_added);

                                    $gross_added = explode('|#|', $result[0]->mrn_gross);
                                    $sum_gross = array_sum($gross_added);

                                    $disper_added = explode('|#|', $result[0]->mrn_discount_percentage);
                                    $sum_disper = array_sum($disper_added);

                                    $disamnt_added = explode('|#|', $result[0]->mrn_discount_amount);
                                    $sum_disamnt = array_sum($disamnt_added);

                                    $add_charges_added = explode('|#|', $result[0]->mrn_additional_charge);
                                    $sum_add_charges = array_sum($add_charges_added);

                                    $load_unload=explode('|#|', $result[0]->mrn_load_unload);

                                    $freight=explode('|#|', $result[0]->mrn_freight);
                                    $clearing=explode('|#|', $result[0]->mrn_clearing);
                                    $other=explode('|#|', $result[0]->mrn_other);
                                    $customs=explode('|#|', $result[0]->mrn_customs);
                                    $control=explode('|#|', $result[0]->mrn_control);
                                    $vat_added = explode('|#|', $result[0]->mrn_vat);

                                    $tax_code = explode('|#|', $result[0]->mrn_tax_code);
                                
                                    $total_count_rows = count($prd_added);
                                    $ik = 1;
                                    foreach ($prd_added as $ca_index => $pa) {

                                        $sql2=$this->db2->query("SELECT pcode,p_prd_img FROM products WHERE pid = ".$pa." ");
                                        $prd_details=$sql2->result_array();
                                            if(empty($prd_details[0]['p_prd_img']))
                                            {
                                                $filename="https://birigroup.com/uploads/prd_images/".$prd_details[0]['pcode'].'.jpeg';
                                             if (file_exists($filename)) {
                                                $img_path=$filename;
                                                } else {
                                                $img_path="https://birigroup.com/uploads/prd_images/".$prd_details[0]['pcode'].'.jpg';
                                                }
                                            }
                                             else
                                             {
                                                $first_img_prd=explode(',',$prd_details[0]['p_prd_img']);
                                                if(!empty($first_img_prd[0]))
                                                $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0];
                                                else
                                                $img_path="https://birigroup.com/uploads/prd_images/".$prd_details[0]['p_prd_img'];
                                             }
                                             if($vat_added[$ca_index]=='15')
                                            {
                                            $org_amount=$control[$ca_index]/1.15;
                                            $vat_amount_calc=$org_amount*0.15;
                                            $tot_fnet_vat=$control[$ca_index]-$vat_amount_calc;
                                            }
                                            elseif($vat_added[$ca_index]=='5')
                                            {
                                                 $org_amount=$control[$ca_index]/1.05;
                                            $vat_amount_calc=$org_amount*0.05;
                                            $tot_fnet_vat=$control[$ca_index]-$vat_amount_calc;
                                            }

                            $tot_dis_per_amont = $gross_added[$ca_index]*($disper_added[$ca_index] / 100) ;                
                                        ?>
                                        <tr>
                                            <td><img src="<?php echo $img_path;?>" width="100" height="100" class="img-responsive img<?php echo $ik; ?>"></td>
                                            <td>
                                                <select data-plugin-selectTwo class="form-control populate product_<?php echo $ik; ?>" name="mrn_product[]" onchange="get_product_details()">
                                                    <option value="">Choose</option>
                                                    <?php
                                                    foreach ($products_list as $prd) {
                                                        ?>
                                                        <option value="<?php echo $prd->pid; ?>" <?php if (!empty($pa)) {
                                                            if ($pa == $prd->pid) {
                                                                echo "selected";
                                                            }
                                                        }; ?>> <?php echo str_replace('|~~|', ',', $prd->pname); ?> ::<br /> <?php echo $prd->pcode; ?> </option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                            </td>

                                            <td><input type="text" name="mrn_description[]" value="<?php if(!empty($prd_desc[$ca_index])){echo $prd_desc[$ca_index];};?>"  class="form-control description<?php echo $ik; ?>"> </td>

                                            <td><input type="text" name="mrn_unit[]" value="<?php if(!empty($prd_unit[$ca_index])){echo $prd_unit[$ca_index];};?>"  class="form-control unit<?php echo $ik; ?>"> </td>

                                            <td><input type="number" name="mrn_qty[]" onchange="calc_gross(<?php echo $ik; ?>);" onkeyup="calc_gross(<?php echo $ik; ?>);" min="0" value="<?php if (!empty($qnty_added[$ca_index])) {
                                                echo $qnty_added[$ca_index];
                                                } else {
                                                    echo "0";
                                                }; ?>" step="any" class="form-control qnyt_dt qnty<?php echo $ik; ?>"> </td>

                                            <td><input type="text" name="mrn_link_1[]" value="<?php if(!empty($prd_link[$ca_index])){echo $prd_link[$ca_index];};?>"  class="form-control link_11<?php echo $ik; ?>"> </td>
                                            <td><input type="number" name="mrn_rate[]" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" value="<?php if (!empty($rate_added[$ca_index])) {
                                                    echo $rate_added[$ca_index];
                                                    } else {
                                                        echo "0";
                                                    }; ?>" step="any" class="form-control rate_dt rate<?php echo $ik; ?>"> </td>

                                            <td><input type="number" name="mrn_gross[]" value="<?php if (!empty($gross_added[$ca_index])) {echo $gross_added[$ca_index]; } else {
                                                        echo "0";
                                                    }; ?>" step="any" readonly="" class="form-control gross_dt gross<?php echo $ik; ?>"></td>

                                            <td>
                                            <input type="hidden" name="dis_per_each_prd[]" value="<?php if(!empty($tot_dis_per_amont)){echo $tot_dis_per_amont;};?>" class="form-control dis_per_each_prd<?php echo $ik; ?>">
                                            <input type="number" name="mrn_discount_percentage[]" value="<?php if (!empty($disper_added[$ca_index])) {  echo $disper_added[$ca_index]; } else {
                                                           echo "0";  }; ?>" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" step="any" class="form-control disc_per_dt disperc<?php echo $ik; ?>">
                                            </td>

                                            <td><input type="number" name="mrn_discount_amount[]" value="<?php if (!empty($disamnt_added[$ca_index])) {  echo $disamnt_added[$ca_index];  } else {   echo "0";
                                                   }; ?>" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" step="any" class="form-control disc_amount_dt disamnt<?php echo $ik; ?>"> </td>

                                            <td><input type="number" name="mrn_additional_charge[]" value="<?php if (!empty($add_charges_added[$ca_index])) { echo $add_charges_added[$ca_index]; } else {  echo "0";
                                               }; ?>" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" step="any" class="form-control add_charges_dt addchrg<?php echo $ik; ?>">
                                           </td>

                                           <td><input type="text" name="mrn_freight[]" value="<?php if(!empty($freight[$ca_index])){echo $freight[$ca_index];};?>" class="form-control freight freight<?php echo $ik; ?>"> </td>
                                           <td><input type="text" name="mrn_clearing[]" value="<?php if(!empty($clearing[$ca_index])){echo $clearing[$ca_index];};?>" class="form-control clearing clearing<?php echo $ik; ?>"> </td>
                                           <td>
                                            <select data-plugin-selectTwo class="form-control populate oad_unload_<?php echo $ik; ?>" name="si_load_unload[]">
                                                <option value="">Choose</option>
                                                <option value="0" <?php if(!empty($load_unload[$ca_index])){if($load_unload[$ca_index]=="Load"){echo "selected";}};?>>Load</option>
                                                <option value="1" <?php if(!empty($load_unload[$ca_index])){if($load_unload[$ca_index]=="Unload"){echo "selected";}};?>>Unload</option>
                                            </select>

                                        </td>

                                        <td><input type="text" name="mrn_other[]"  value="<?php if(!empty($other[$ca_index])){echo $other[$ca_index];};?>" class="form-control  other<?php echo $ik; ?>"> </td>
                                        <td><input type="text" name="mrn_customs[]"  value="<?php if(!empty($customs[$ca_index])){echo $customs[$ca_index];};?>" class="form-control  customs<?php echo $ik; ?>"> </td>
                                        <td><input type="text" name="mrn_control[]" value="<?php if(!empty($control[$ca_index])){echo $control[$ca_index];};?>"  readonly class="form-control  fnet<?php echo $ik; ?>"> </td>
                                    <td>
                                    <span> Apply vat<input type="checkbox" name="vat_checkbox" value="1" class="prd_vat_per<?php echo $ik;?> " oninput="vat_perc(<?php echo $ik;?>);"></span><br/>
                                    <input type="text" name="mrn_tax_code[]" readonly="" value="<?php if (!empty($tax_code[$ca_index])) {echo $tax_code[$ca_index];}else{echo "0";}; ?>" class="form-control prd_tax_code_<?php echo $ik; ?>"> </td>
                                    <td>
                                    <input type="text" name="mrn_vat[]" value="<?php if(!empty($vat_added[$ca_index])){echo $vat_added[$ca_index];};?>" readonly="" class="form-control form_vat_input_amount_<?php echo $ik;?> vat<?php echo $ik;?>">
                                    <input type="hidden" name="vat_fnet_val[]"  value="<?php if(!empty($tot_fnet_vat)){echo $tot_fnet_vat;};?>" class="form-control vat_fnet_val<?php echo $ik;?>"> 
                                    <input type="hidden" name="vat_each_prd[]"  value="<?php if(!empty($vat_amount_calc)){echo $vat_amount_calc;};?>" class="form-control vat_each_prd_val<?php echo $ik;?>">
                                    </td>
                                  
                                    <td></td>
                                </tr>
                                <?php
                                $ik++;
                            }
                                } else ////for adding new , for new inovices///////////////
                                {
                                    ?>
                                    <tr>
                                        <td><img src="" width="100" height="100" class="img-responsive img1"></td>
                                        <td>
                                            <select data-plugin-selectTwo class="form-control populate product_1" name="mrn_product[]" onchange="get_product_details('1')">
                                                <option value="">Choose</option>
                                                <?php
                                                foreach ($products_list as $prd) {
                                                    ?>
                                                    <option value="<?php echo $prd->pid; ?>"> <?php echo str_replace('|~~|', ',', $prd->pname); ?> ::<br /> <?php echo $prd->pcode; ?> </option>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                        </td>
                                        <td><input type="text" name="mrn_description[]"  class="form-control description1"> </td>
                                        <td > 
                                                <!-- <select class="form-control populate unit1" name="si_unit[]">
                                                    <option value="1">Choose</option>
                                                </select> -->
                                                <select class="form-control populate unit1" name="mrn_unit[]" style="width:120px;">
                                                    <option value="">Choose</option>

                                                </select>
                                            </td>
                                            <td><input type="number" name="mrn_qty[]" onchange="calc_gross('1');" onkeyup="calc_gross('1');" value="0" min="0" step="any" class="form-control qnyt_dt qnty1"> </td>
                                            <td><input type="text" name="mrn_link_1[]"  class="form-control link_11"> </td>
                                            <td><input type="number" name="mrn_rate[]" onchange="calc_gross('1')" onkeyup="calc_gross('1')" value="0" step="any" class="form-control rate_dt rate1"> </td>
                                            <td><input type="number" name="mrn_gross[]" value="0" step="any" readonly="" class="form-control gross_dt gross1"></td>
                                            <td>
                                                <input type="hidden" name="dis_per_each_prd[]" value="0" class="form-control dis_per_each_prd1">
                                                <input type="number" name="mrn_discount_percentage[]" value="0" onchange="calc_gross('1')" onkeyup="calc_gross('1')" step="any" class="form-control disc_per_dt disperc1">
                                            </td>
                                            <td><input type="number" name="mrn_discount_amount[]" value="0" onchange="calc_gross('1')" onkeyup="calc_gross('1')" step="any" class="form-control disc_amount_dt disamnt1"> </td>
                                            <td><input type="number" name="mrn_additional_charge[]" value="0" onchange="calc_gross('1')" onkeyup="calc_gross('1')" step="any" class="form-control add_charges_dt addchrg1"> </td>

                                            <td><input type="text" name="mrn_freight[]"  class="form-control freight freight1"> </td>
                                            <td><input type="text" name="mrn_clearing[]"  class="form-control clearing clearing1"> </td>
                                            <td>
                                                <select data-plugin-selectTwo class="form-control populate oad_unload_1" name="mrn_load_unload[]">
                                                    <option value="">Choose</option>
                                                    <option value="0">Load</option>
                                                    <option value="1">Unload</option>
                                                </select>

                                            </td>

                                            <td><input type="text" name="mrn_other[]"  class="form-control  other1"> </td>
                                            <td><input type="text" name="mrn_customs[]"  class="form-control  customs1"> </td>
                                            <td><input type="text" name="mrn_control[]" readonly  class="form-control  fnet1"> </td>
                                              <td>
                                                    <span> Apply vat<input type="checkbox" name="vat_checkbox" value="1" class="prd_vat_per1 " oninput="vat_perc(1);"></span><br/>
                                                <input type="text" name="mrn_tax_code[]" readonly="" value="0" class="form-control prd_tax_code_1"> </td>
                                            <td>
                                               <input type="text" name="mrn_vat[]" value="0" readonly="" class="form-control form_vat_input_amount_1 vat1">
                                                  <input type="hidden" name="vat_fnet_val[]"  value="0" class="form-control vat_fnet_val1"> 
                                                <input type="hidden" name="vat_each_prd[]"  value="0" class="form-control vat_each_prd_val1">
                                            </td>
                                          
                                            <td></td>
                                        </tr>
                                        <?php
                                    } ?>
                                
  <!-----for input tyype hidden fields------------->
                                     <input type="hidden" name="hi_prd_id" class="form-control">
                                    <input type="hidden" name="hi_description" value="" class="form-control">
                                    <input type="hidden" name="hi_unit" value="" class="form-control">

                                    <input type="hidden" name="hi_quantity" value="0" class="form-control">
                                    <input type="hidden" name="hi_link_1" value="0" class="form-control">
                                    <input type="hidden" name="hi_rate" value="0" class="form-control">
                                    <input type="hidden" name="hi_gross" value="0" class="form-control">
                                    <input type="hidden" name="hi_discount_percentage" value="0" class="form-control">
                                    <input type="hidden" name="hi_discount_amount" value="0" class="form-control">
                                    <input type="hidden" name="hi_additional_charge" value="0" class="form-control">

                                    <input type="hidden" name="hi_freight" value="" class="form-control">
                                    <input type="hidden" name="hi_clearing" value="" class="form-control">
                                    <input type="hidden" name="hi_load_unload" value="" class="form-control">

                                     <input type="hidden" name="hi_other" value="" class="form-control">
                                    <input type="hidden" name="hi_customs" value="" class="form-control">
                                  
                                    <input type="hidden" name="hi_control" value="0" class="form-control">
                                   
                                    <input type="hidden" name="hi_vat" class="form-control">
                                    <input type="hidden" name="hi_tax_code" value="0" class="form-control">
                                    <!---------end for input type hidden--->
                                        <button type="button" class="btn btn-primary pull-right" onclick="add_more_row()">Add More</button>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-------start col-md-12------------------->
                    <div class="col-md-12 col-sm-12 table-rows-border">
                        <label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
                        <div class="col-md-8">
                            <span class="num_items">
                                <?php
                                if (!empty($result[0])) {
                                    if (!empty($total_count_rows)) {
                                        echo $total_count_rows;
                                    } else {
                                        echo "1";
                                    }
                                } else {
                                    echo "1";
                                }
                                ?>
                            </span>
                        </div>
                    </div>
                    <!----------end col-md-12----------------------------->

                    <!-------start col-md-12------------------->
                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <label class="col-md-4 control-label" for="inputPlaceholder">Total Quantity:<abbr class="required">::*::</abbr></label>
                        <div class="col-md-8">
                            <input type="text" readonly class="qnty_tot_button" name="si_tot_qnty" required="required" value="<?php if (!empty($sum_qnty)) { echo $sum_qnty; } else {    echo "0"; }; ?>">
                        </div>
                    </div>
                    <!----------end col-md-12----------------------------->
                    <!-------start col-md-12------------------->
                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <label class="col-md-4 control-label" for="inputPlaceholder" style="display: none;"> Total Rate:<abbr class="required">::*::</abbr></label>
                        <div class="col-md-8">
                            <input type="hidden" readonly class="rate_tot_button" name="si_tot_rate" required="required" value="<?php if (!empty($sum_rate)) { echo $sum_rate;} else {    echo "0";}; ?>">
                        </div>
                    </div>
                    <!----------end col-md-12----------------------------->
                    <!-------start col-md-12------------------->
                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <label class="col-md-4 control-label" for="inputPlaceholder"> Total Gross:<abbr class="required">::*::</abbr></label>
                        <div class="col-md-8">
                            <input type="text" readonly class="gross_tot_button" name="si_tot_gross" required="required" value="<?php if (!empty($sum_gross)) { echo $sum_gross; } else {   echo "0"; }; ?>">
                        </div>
                    </div>
                    <!----------end col-md-12----------------------------->
                    <!-------start col-md-12------------------->
                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <label class="col-md-4 control-label" for="inputPlaceholder"> Total Discount Percentage:<abbr class="required">::*::</abbr></label>
                        <div class="col-md-8">
                            <input type="text" readonly class="disc_per_tot_button" name="si_tot_desc_per" required="required" value="<?php if (!empty($sum_disper)) {  echo $sum_disper;} else { echo "0";}; ?>">
                        </div>
                    </div>
                    <!----------end col-md-12----------------------------->
                    <!-------start col-md-12------------------->
                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <label class="col-md-4 control-label" for="inputPlaceholder"> Total Discount Amount:<abbr class="required">::*::</abbr></label>
                        <div class="col-md-8">
                            <input type="text" readonly class="disc_amount_tot_button" name="si_tot_desc_amount" required="required" value="<?php if (!empty($sum_disamnt)) { } else { }; ?>">
                        </div>
                    </div>
                    <!----------end col-md-12----------------------------->

                    <!-------start col-md-12------------------->
                    <div class="col-md-6 col-sm-12 table-rows-border">
                        <label class="col-md-4 control-label" for="inputPlaceholder"> Total Additional Charges:<abbr class="required">::*::</abbr></label>
                        <div class="col-md-8">
                            <input type="text" readonly class="add_charges_tot_button" name="si_tot_add_charges" required="required" value="<?php if (!empty($sum_add_charges)) {
                            } else { }; ?>">
                        </div>
                    </div>
                    <!----------end col-md-12----------------------------->
                    <!-------start col-md-12------------------->
                <div class="col-md-6 col-sm-12 table-rows-border">

                    <label class="col-md-4 control-label" for="inputPlaceholder"> Total Fnet:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="fnet_tot_button" name="si_tot_fnet" required="required" value="<?php if (!empty($sum_fnet)) { echo $sum_fnet;} else { echo "0";}; ?>">
                    </div>
                </div> 
                <!----------end col-md-12----------------------------->
                <!-------start col-md-12------------------->
                <div class="col-md-6 col-sm-12 table-rows-border">
                    <label class="col-md-4 control-label" for="inputPlaceholder"> Total VAT Charges:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="vat_tot_button" name="mrn_total_vat_amount" required="required" value="<?php if (!empty($mrn_total_vat_amount)) { echo $mrn_total_vat_amount; } else {   echo "0"; }; ?>">
                    </div>
                </div>
                <!----------end col-md-12----------------------------->
                <!-------start col-md-12------------------->
                <div class="col-md-12 col-sm-12 table-rows-border">

                    <button class="btn btn-primary" type="button" onclick="get_amount_total()">Click to see total amount</button>
                    <br />
                    <label class="col-md-4 control-label amount_text" for="inputPlaceholder">Amount Total:<abbr class="required">::*::</abbr></label>
                    <div class="col-md-8">
                        <input type="text" readonly class="amount_tot_button" name="mrn_total_amount" required="required" value="<?php if (!empty($result[0]->mrn_total_amount)) { echo $result[0]->mrn_total_amount;} ; ?>">
                        <small>Amount as per the currency rate selected</small>
                    </div>
                </div>
                <!----------end col-md-12----------------------------->

                <!-----div starts here for non-inquiry--->
                <!----div end here for non-inquiry--->
            </section>
            <!-----div starts here for non-inquiry--->

            <!-----div starts here for non-inquiry--->
            <!----div closes here--->

            <div class="cell_text_data"></div>
            <div class="col-sm-9 col-sm-offset-3">
              <!--   <a type="button" class="btn btn-primary mb-xs mt-xs mr-xs modal-sizes" href="#modalmd_sinv" onclick="get_cust_sales_inv()">Save</a> -->
                <button  type="submit" class="submit_btn">Save</button>
                <button type="reset" class="btn btn-default" onclick="check_for_reset()">Reset</button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>

</section>
</div>
</section>

<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
    <a href="#" class="mobile-close visible-xs">
        Collapse <i class="fa fa-chevron-right"></i>
    </a>
    <div class="sidebar-right-wrapper">

        <div class="sidebar-widget widget-friends ">

            <div class="chat_window">
                <?php $this->load->view('admin/master_essential/chat_data', $chat); ?>

            </div>
        </div>

    </div>
</div>
</div>
</aside>

<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/'); ?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/forms/examples.advanced.form.js" type="text/javascript" />
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript"></script>


<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>


<script>
$(document).on('ready', function() {
$('input').attr('autocomplete', 'off');
$("#file-1").fileinput();
});
</script>

<script>
tinymce.init({
selector: '.editors',
plugins: [
'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
],
});
</script>

<script type="text/javascript">
 function add_more_row()
{
var tablecount = $('table tbody tr').length;
  if(tablecount=="0")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }
   var markup='<tr class="table'+table_id+'">'+
    '<td><img src="" width="100" height="100" class="img-responsive img'+table_id+'"></td>'+
 ' <td class="select_prd_list_'+table_id+'">';
    jQuery.ajax({
                     url:"<?php echo base_url().'Purchase_controller/get_details_prd';?>",
                      data:{"table_id":table_id},
                    type:"post",
                    success:function(result)
                    {
                      if(result)
                      {
               $('.select_prd_list_'+table_id).html(result);
              $('select[name="mrn_product[]"]').select2();  
                      }
                    }
                 });  
  markup+='</td>'+
  '<td><input type="text" name="mrn_description[]"  value="" step="any" class="form-control "> </td>';
    markup+= '<td>'+
     ' <select class="form-control populate unit'+table_id+'" name="mrn_unit[]" style="width:120px;">'+
            '<option value="">Choose</option>'+

        '</select>'+
       ' </td>'+
    '<td><input type="number" name="mrn_qty[]" onchange="calc_gross('+table_id+');" onkeyup="calc_gross('+table_id+');"  value="0" step="any" class="form-control qnyt_dt qnty'+table_id+'"></td>'+
    '<td><input type="text" name="mrn_link_1[]"   step="any" class="form-control"> </td>'+
    '<td><input type="number" name="mrn_rate[]" onchange="calc_gross('+table_id+');" onkeyup="calc_gross('+table_id+');" value="0" step="any" class="form-control rate_dt rate'+table_id+'"> </td>'+
    '<td><input type="number" name="mrn_gross[]"  value="0" step="any" class="form-control gross_dt gross'+table_id+'" readonly=""> </td>'+
    '<td><input type="number" name="mrn_discount_percentage[]"  value="0" onchange="calc_gross('+table_id+');" onkeyup="calc_gross('+table_id+');" step="any" class="form-control disc_per_dt disperc'+table_id+'"> </td>'+
    '<td>'+
    ' <input type="hidden" name="dis_per_each_prd[]"  value="0" class="form-control dis_per_each_prd'+table_id+'">'+
    '<input type="number" name="mrn_discount_amount[]"  value="0" onchange="calc_gross('+table_id+');" onkeyup="calc_gross('+table_id+');"  step="any" class="form-control disc_amount_dt disamnt'+table_id+'"> </td>'+
    '<td><input type="number" name="mrn_additional_charge[]"  value="0" onchange="calc_gross('+table_id+');" onkeyup="calc_gross('+table_id+');"  step="any" class="form-control add_charges_dt addchrg'+table_id+'"> </td>'+

        '<td><input type="text" name="mrn_freight[]"  class="form-control freight freight'+table_id+'"> </td>'+
       ' <td><input type="text" name="mrn_clearing[]"  class="form-control clearing clearing'+table_id+'"> </td>'+
       ' <td>'+
            '<select data-plugin-selectTwo class="form-control populate oad_unload_'+table_id+'" name="mrn_load_unload[]">'+
               ' <option value="">Choose</option>'+
               ' <option value="0">Load</option>'+
                '<option value="1">Unload</option>'+
           ' </select>'+
        '</td>'+
       ' <td><input type="text" name="mrn_other[]"  class="form-control  other'+table_id+'"> </td>'+
       ' <td><input type="text" name="mrn_customs[]"  class="form-control  customs'+table_id+'"> </td>'+
       ' <td><input type="text" name="mrn_control[]" readonly  class="form-control  control'+table_id+' fnet'+table_id+'"> </td>'+
       '<td>'+
    '  <span> Apply vat<input type="checkbox" name="vat_checkbox" value="1" class="prd_vat_per'+table_id+' " oninput="vat_perc('+table_id+');"></span><br/>'+
    '<input type="text" name="mrn_tax_code[]" value="0"  class="form-control prd_tax_code_'+table_id+'"> </td> '+  
  '<td>'+
  '<input type="text" name="mrn_vat[]" value="0" readonly="" class="form-control form_vat_input_amount_'+table_id+' vat'+table_id+'"> '+
  '<input type="hidden" name="vat_fnet_val[]"  value="0" class="form-control vat_fnet_val'+table_id+'"> '+
       '<input type="hidden" name="vat_each_prd[]"  value="0" class="form-control vat_each_prd_val'+table_id+'"> </td> '+  
     ' <td><button type="button" class="btn btn-danger" style="cursor: pointer" onclick=table('+table_id+')>X</button></td>'
      '</tr>';
            $(".new_rows").append(markup);
             var rowcount = $('table tbody tr').length;
     $(".num_items").html(table_id);
}

  function table(id)
  {
    $('table tbody .table'+id).remove();
    var rowcount = $('table tbody tr').length;
    $(".num_items").html(rowcount);
  }

</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
<script>
tinymce.init({
selector: '.editors',
plugins: [
'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
],
});
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">
$(function() {
$('.datetimepicker4').datepicker();
});
       $( function() {
    $('.datetimepicker5' ).datepicker({ 
         
       startDate: '-7d', // controll start date like startDate: '-2m' m: means Month
endDate: new Date(),
todayHighlight: true,
setDate: new Date()
     // minDate: -20, maxDate: new Date()
       });
  } );


$(document).on('ready', function() {
$('select[name="mrn_currency"]').on('change', function() {

    jQuery.ajax({
        url: "<?php echo base_url() . 'Receipt_Master/get_currency_conv_val'; ?>",
        data: {
            "currecny_selected": $(this).val()
        },
        type: "post",
        success: function(result) {
            if (result) {
                $("input[name='mrn_conv_value']").val(result);
            }
        }
    });
});

$('.menu_name_fun').on('click', function() {
    if (confirm("Are you sure, You want to exit this page?")) {
        location.href = $(this).attr('href');
    } else {
        return false;
    }

});

 $('select[name="mrn_place_of_supply"]').on("change",function(){
        var selected_val=$(this).val();
        $('select[name="mrn_jurisdiction"]').val(selected_val).trigger('change');
     });

});

function get_product_details(table_id) {
var prd_selected = $('.product_' + table_id).find('option:selected').val();
var vat_type_choosed = $('select[name="si_vat_type"]').find('option:selected').val();
if (vat_type_choosed == "2") {
$('input[name="si_vat[]"]').val('0');
} else {
$('input[name="si_vat[]"]').val('5');
}

jQuery.ajax({
url: "<?php echo base_url() . 'Sales_invoice/get_product_details'; ?>",
data: {
"prd_id": prd_selected
},
type: "post",
success: function(result) {
if (result) {
var returndata = JSON.parse(result);
$('.img' + table_id).attr('src', returndata['pimage']);
$('.rate' + table_id).val(returndata['prd_price']);
    // console.log(result);
}
}
});
    jQuery.ajax({
    url: "<?php echo base_url() . 'Purchase_controller/get_product_extras'; ?>",
    data: {
    "prd_id": prd_selected,
    "table_id": table_id
    },
    type: "post",
    success: function(result) {
    if (result) {
    //console.log(result);
    $('.unit' + table_id).html(result);
    }
    }
    });
}


function vat_perc(table_id)
{ 
    //console.log('inside vat inptu');
var company_selected=$("select[name='mrn_company']").find('option:selected').text();
 var vat_per= $('.prd_vat_per'+table_id).val();
 var vat_amount_calc='';
 if ($("input[name=vat_checkbox]").is(':checked'))
 {
//console.log('checked box');
  if(company_selected.includes("KSA")==true)
  {
   // console.log('checked box-ksa');
     $('.prd_tax_code_'+table_id).val('SR-REC');
    $('.form_vat_input_amount_'+table_id).val('15');
    var input_amounts=$('.fnet'+table_id).val();
        org_amount=(parseFloat(input_amounts)/(parseFloat(1.15)) );
        vat_amount_calc=(parseFloat(org_amount)*(parseFloat(0.15))  );
       
          $('.vat_each_prd_val'+table_id).val(vat_amount_calc);///this will be vat of each item
          var tot_fnet_vat=parseFloat(input_amounts)-parseFloat(vat_amount_calc);
          $('.vat_fnet_val'+table_id).val(tot_fnet_vat);////calcualte the final value without vat 
   //     console.log(vat_amount_calc);       
  }
  else if(company_selected.includes("UAE"))
  {
    //console.log('checked box-uae');
      $('.prd_tax_code_'+table_id).val('SR-REC');
    $('.form_vat_input_amount_'+table_id).val('5');
    var input_amounts=$('.fnet'+table_id).val();
        org_amount=(parseFloat(input_amounts)/(parseFloat(1.05)) );
        vat_amount_calc=(parseFloat(org_amount)*(parseFloat(0.05))  );   
      
        $('.vat_each_prd_val'+table_id).val(vat_amount_calc);///this will be vat of each item
        var tot_fnet_vat=parseFloat(input_amounts)-parseFloat(vat_amount_calc);
        $('.vat_fnet_val'+table_id).val(tot_fnet_vat);////calcualte the final value without vat 
  }
  else { }
 }
 else
 {
  $('.prd_tax_code_'+table_id).val('0');
  $('.form_vat_input_amount_'+table_id).val('0');
  vat_amount_calc=0;
  //console.log(vat_amount_calc);  
   var input_amounts=$('.fnet'+table_id).val();
    $('.vat_each_prd_val'+table_id).val(vat_amount_calc);///this will be vat of each item
        var tot_fnet_vat=parseFloat(input_amounts)-parseFloat(vat_amount_calc);
        $('.vat_fnet_val'+table_id).val(tot_fnet_vat);////calcualte the final value without vat 
 }

}

function calc_gross(table_id) {
var qnty_tbl = $('.qnty' + table_id).val();
var rate_tbl = $('.rate' + table_id).val();
var tot_gross = parseFloat(qnty_tbl) * parseFloat(rate_tbl);

$('.gross' + table_id).val(tot_gross);
var dis_per_tbl = $('.disperc' + table_id).val();
var dis_amnt_tbl = $('.disamnt' + table_id).val();
var add_charge_tbl = $('.addchrg' + table_id).val();
var tot_dis_per_amont = (parseFloat(dis_per_tbl) / parseFloat(100)) * parseFloat(tot_gross);
$('.dis_per_each_prd' + table_id).val(tot_dis_per_amont);
var tot_fnet_calc=parseFloat(tot_gross)-parseFloat(tot_dis_per_amont)-parseFloat(dis_amnt_tbl)+parseFloat(add_charge_tbl);
  $('.fnet'+table_id).val(tot_fnet_calc);
  //var vat_tbl=$('.vat'+table_id).val();
}

function get_amount_total() {
var amountss1 = '0';
$('table tbody tr td input[name="mrn_qty[]"]').each(function() {
amountss1 = parseFloat(amountss1) + parseFloat($(this).val());
});
$('.qnty_tot_button').val(parseFloat(amountss1.toFixed(2)));

//////for rate tot calc//////
/////////for gross tot_calc//////////

var amountss_3 = '0';
$('table tbody tr td input[name="mrn_gross[]"]').each(function() {
amountss_3 = parseFloat(amountss_3) + parseFloat($(this).val());
});
$('.gross_tot_button').val(parseFloat(amountss_3.toFixed(2)));

///////for dis per tot calc field/////////
var amountss_4_1 = '0';
$('table tbody tr td input[name="dis_per_each_prd[]"]').each(function() {
amountss_4_1 = parseFloat(amountss_4_1) + parseFloat($(this).val());
});
$('.disc_per_tot_button').val(parseFloat(amountss_4_1.toFixed(2)));

//////for dis amount tot calc field/////////
var amountss_5 = '0';
$('table tbody tr td input[name="mrn_discount_amount[]"]').each(function() {
amountss_5 = parseFloat(amountss_5) + parseFloat($(this).val());
});
$('.disc_amount_tot_button').val(parseFloat(amountss_5.toFixed(2)));

//////////for add charges tot calc field///////
var amountss_6 = '0';
$('table tbody tr td input[name="mrn_additional_charge[]"]').each(function() {
amountss_6 = parseFloat(amountss_6) + parseFloat($(this).val());
});
$('.add_charges_tot_button').val(parseFloat(amountss_6.toFixed(2)));

///////for fnet tot calc field///////////
var amountss_7 = '0';
$('table tbody tr td input[name="mrn_control[]"]').each(function() {
amountss_7 = parseFloat(amountss_7) + parseFloat($(this).val());
});
$('.fnet_tot_button').val(parseFloat(amountss_7.toFixed(2)));

////////////for vat tot calc field//////
//  var amountss_8='0';
// $('table tbody tr td input[name="si_vat[]"]').each(function(){
// amountss_8= parseFloat(amountss_8)+parseFloat($(this).val());
// }); 
// $('.vat_tot_button').val(parseFloat(amountss_8));

////////////for vat tot calc field//////
var amountss_8_1 = '0';
$('table tbody tr td input[name="vat_each_prd[]"]').each(function() {
amountss_8_1 = parseFloat(amountss_8_1) + parseFloat($(this).val());
 console.log(amountss_8_1);
});
$('.vat_tot_button').val(parseFloat(amountss_8_1.toFixed(2)));

//////////show total amount///////////
//////////show total amount///////////


if (amountss_8_1 =='0' ) ////vat  is present

{

    var amountss_9_2 = '0';
$('table tbody tr td input[name="mrn_control[]"]').each(function() {
amountss_9_2 = parseFloat(amountss_9_2) + parseFloat($(this).val());
});
$('.amount_tot_button').val(parseFloat(amountss_9_2.toFixed(2)));
}

else 
{
var amountss_9 = '0';
$('table tbody tr td input[name="vat_fnet_val[]"]').each(function() {
amountss_9 = parseFloat(amountss_9) + parseFloat($(this).val());
});
$('.amount_tot_button').val(parseFloat(amountss_9.toFixed(2)));
} 



}

function get_cust_sales_inv() {
var cust_id = $('select[name="si_customer_acc_id"]').find('option:selected').val();
jQuery.ajax({
url: "<?php echo base_url() . 'Sales_invoice/get_cust_sales_inv'; ?>",
data: {
"cust_id": cust_id
},
type: "post",
success: function(result) {
//console.log(result);
$('.modal_content_sinv').html(result);
$('#datatable-default2').DataTable();
}
});

}
///////////////////////modal functions page/////////////////////////////////////////////////

/////////////////////end of modal functions////////////////////////////////////
function check_for_reset() {
if (confirm("Are you sure, You want to reset this form?")) {
$('.myform').trigger("reset");
} else {
return false;
}
}

$('.myform').submit(function() {
// e.preventDefault();

var rowcount = $('.new_rows tr').length;

var prd_ids = $('table tbody tr td select[name="mrn_product[]"]').map(function() {
return $(this).find('option:selected').val();
}).get().join('|#|');

var prd_desc = $('table tbody tr td input[name="mrn_description[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var prd_unit = $('table tbody tr td select[name="mrn_unit[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var prd_link = $('table tbody tr td input[name="mrn_link_1[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var prd_qnty = $('table tbody tr td input[name="mrn_qty[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var rate_nos = $('table tbody tr td input[name="mrn_rate[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var gross_nos = $('table tbody tr td input[name="mrn_gross[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var disc_per_nos = $('table tbody tr td input[name="mrn_discount_percentage[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var disc_amount_nos = $('table tbody tr td input[name="mrn_discount_amount[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var add_charges_nos = $('table tbody tr td input[name="mrn_additional_charge[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var frieght = $('table tbody tr td input[name="mrn_freight[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var clearing = $('table tbody tr td input[name="mrn_clearing[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var load_unload = $('table tbody tr td select[name="mrn_load_unload[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var other = $('table tbody tr td input[name="mrn_other[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var customs = $('table tbody tr td input[name="mrn_customs[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var control = $('table tbody tr td input[name="mrn_control[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var vat_nos = $('table tbody tr td input[name="mrn_vat[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

var tax_code_nos = $('table tbody tr td input[name="mrn_tax_code[]"]').map(function() {
return $(this).val();
}).get().join('|#|');

//console.log(quantity+' '+package_size+' '+product_id);

$("input[name='hi_prd_id']").val(prd_ids);
$("input[name='hi_description']").val(prd_desc);
$("input[name='hi_unit']").val(prd_unit);
$("input[name='hi_quantity']").val(prd_qnty);
$("input[name='hi_link_1']").val(prd_link);
$("input[name='hi_rate']").val(rate_nos);
$("input[name='hi_gross']").val(gross_nos);
$("input[name='hi_discount_percentage']").val(disc_per_nos);
$("input[name='hi_discount_amount']").val(disc_amount_nos);
$("input[name='hi_additional_charge']").val(add_charges_nos);
$("input[name='hi_freight']").val(frieght);
$("input[name='hi_clearing']").val(clearing);
$("input[name='hi_load_unload']").val(load_unload);
$("input[name='hi_other']").val(other);
$("input[name='hi_customs']").val(customs);
$("input[name='hi_control']").val(control);
$("input[name='hi_vat']").val(vat_nos);
$("input[name='hi_tax_code']").val(tax_code_nos);

var ij = 0;
var data_var = [];

$('.new_rows tr td').each(function() {
var cellText = $(this).html();
//  console.log(cellText);  
$('.cell_text_data').append(cellText).hide();
});
 // console.log($("input[name='hi_rate']").val());
 // console.log($("input[name='hi_quantity']").val());
 // console.log($("input[name='hi_unit']").val());

 // console.log($("input[name='hi_load_unload']").val());
//console.log(cellText);
// console.log($("input[name='hid_salesman']").val());
// console.log($("input[name='hid_customer']").val());
// console.log($("input[name='hid_amounts']").val());
// console.log($("input[name='hid_remark']").val());
//  console.log($("input[name='hid_ref']").val());
//var table_row_added=$('.new_rows').html();

if ($('.new_rows tr').length == 0) {
alert('Please choose items to add and submit');
return false;
} else {

 return true;

 }
//return false;
// your code here
});
// }
</script>

</body>

</html>