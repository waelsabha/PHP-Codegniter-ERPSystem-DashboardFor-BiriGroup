<!doctype html>
<html class="fixed">

<head>
    <?php $this->load->view('admin/head'); ?>

    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-datepicker/css/datepicker3.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/select2/select2.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/theme.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/skins/default.css" />
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>stylesheets/theme-custom.css">
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

    <script src="<?php echo base_url('admin_assets/'); ?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
    <link rel="stylesheet" href="<?php echo base_url('admin_assets/'); ?>vendor/pnotify/pnotify.custom.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css">
    <link href="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css" />

    <style type="text/css">
        .form_error {
            font-size: 13px;
            font-family: Arial;
            color: red;
            font-style: italic
        }

        .form_error p .errors {
            color: red;
        }

        .errors {
            font-size: 13px;
            font-family: Arial;
            color: red;
            font-style: italic
        }

        .success {
            font-size: 13px;
            font-family: Arial;
            color: green;
            font-style: italic
        }

        .table-rows-border {
            border-bottom: 1px solid #eff2f7;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }

        .required {
            color: red;
        }

        table input.form-control {
            width: auto;
        }
    </style>
</head>

<body>
    <section class="body">

        <?php $this->load->view('admin/header'); ?>

        <div class="inner-wrapper">
            <?php $this->load->view('admin/aside'); ?>
            <section role="main" class="content-body">
                <header class="page-header">
                    <h2>Transactions </h2>
                    <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="#">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li><span>Purchases</span></li>
                            <li><span>Purchase Return</span></li>
                        </ol>
                        <a class="sidebar-right-toggle"></a>
                    </div>
                </header>

                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel panel-featured panel-featured-primary">
                            <header class="panel-heading">

                                <h2 class="panel-title">Issue Purchase Return </h2>
                            </header>
                            <div class="panel-body">
                                <?php echo form_open_multipart('', 'class="myform" novalidate', ''); ?>
                                <!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
                                <input type="hidden" name="inv_id" value="<?php if (!empty($result[0]->si_id)) {
                                                                                echo $result[0]->si_id;
                                                                            }; ?>">
                                <input type="hidden" name="files_added" value="<?php if (!empty($result[0]->si_attachments)) {
                                                                                    echo $result[0]->si_attachments;
                                                                                }; ?>">

                                <div class="form_error">
                                    <p class="errors"> <?php echo $this->session->flashdata('errors'); ?></p>
                                    <p class="success"><?php echo $this->session->flashdata('success'); ?></p>
                                </div>
                                <p class="required"> Fileds marked as '::*::' are required fields</p>

                                <div class="row">

                                    <div class="col-md-12 col-sm-12 table-rows-border">

                                        <div class="col-md-6 col-sm-12">


                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder">Doc No <abbr class="required">::*::</abbr></label>
                                                <div class="col-md-8">

                                                    <input type="text" name="mrn_doc_no" value="<?php if (!empty($result)) {
                                                                                                    if (!empty($result[0]->si_doc_no)) {
                                                                                                        echo $result[0]->si_doc_no;
                                                                                                    }
                                                                                                } else {
                                                                                                    echo $doc_num;
                                                                                                } ?>" readonly class="form-control">


                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_doc_no'); ?></div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder"> Date<abbr class="required">::*::</abbr>

                                                </label>
                                                <div class="col-md-8">
                                                    <?php
                                                    if (!empty($result[0]->si_date))
                                                        $converted_date = date("m/d/Y", strtotime($result[0]->si_date));
                                                    ?>
                                                    <?php
                                                        $date = date('Y-m-d', strtotime('-7 days', strtotime(date('Y-m-d'))));
                                                        
                                                    ?>
                                                    <input type='date' min="<?php echo $date; ?>" max="<?php echo date('Y-m-d'); ?>" name="mrn_date" class="form-control" value="<?php  echo date('Y-m-d'); ?>" required />
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_date'); ?></div>

                                                </div>
                                            </div>
                                        </div>

                                        

                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder"> Purchase Account<abbr class="required">::*::</abbr>

                                                </label>
                                                <div class="col-md-8">
                                                    <select data-plugin-selectTwo class="form-control populate" name="mrn_purchase_account" required="">
                                                        <!-- <option value="">Choose</option> -->
                                                        <?php
                                                        foreach ($purchase_accont as $cb) {
                                                            //pre_list($cb);
                                                        ?>
                                                            <option value="<?php echo $cb->id; ?>" <?php if (!empty($result[0]->si_sales_acc_id)) {
                                                                                                        if ($result[0]->si_sales_acc_id == $cb->id) {
                                                                                                            echo "selected";
                                                                                                        }
                                                                                                    }; ?>><?php echo $cb->label; ?></option>

                                                        <?php
                                                        }
                                                        ?>
                                                    </select>
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_purchase_account'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder">Vendors<abbr class="required">::*::</abbr>

                                                </label>
                                                <div class="col-md-8">
                                                
                                                    <select data-plugin-selectTwo class="form-control populate" name="mrn_vendor" required="">
                                                        <option value="">Choose</option>
                                                        
                                                        <?php
                                                        foreach ($vendors as $cb) {
                                                            //pre_list($cb);
                                                            if($cb->file == 1)
                                                            {
                                                        ?>
                                                            <option value="<?php echo $cb->id; ?>" <?php if (!empty($result[0]->si_customer_acc_id)) {
                                                                                                        if ($result[0]->si_customer_acc_id == $cb->id) {
                                                                                                            echo "selected";
                                                                                                        }
                                                                                                    }; ?>><?php echo $cb->label; ?></option>

                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        

                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder"> Raise Receipt<abbr class="required">::*::</abbr>

                                                </label>
                                                <div class="col-md-8">
                                                    <input type="checkbox" name="raise_receipt" >
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_company'); ?></div>

                                                </div>
                                            </div>
                                        </div>


                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder"> Company<abbr class="required">::*::</abbr>

                                                </label>
                                                <div class="col-md-8">
                                                    <select data-plugin-selectTwo class="form-control populate" name="mrn_company" required="">
                                                        <option value="">Choose</option>
                                                        <?php
                                                        foreach ($company_masters as $cm) { ?>
                                                            <option value="<?php echo $cm->mcomp_id; ?>" <?php if (!empty($result[0]->si_company)) {
                                                                                                            if ($result[0]->si_company == $cm->mcomp_id) {
                                                                                                                echo "selected";
                                                                                                            }
                                                                                                        }; ?>> <?php echo $cm->mcomp_name; ?></option>
                                                        <?php
                                                        } ?>

                                                    </select>
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_company'); ?></div>

                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder"> Warehouse<abbr class="required">::*::</abbr>

                                                </label>
                                                <div class="col-md-8">
                                                   
                                                <select data-plugin-selectTwo class="form-control populate" name="mrn_warehouse" required="">
                                                        <option value="">Choose</option>
                                                        <?php
                                                        foreach ($warehouse_data as $wd) { ?>
                                                            <option value="<?php echo $wd->mw_id;?>" <?php if (!empty($result[0]->si_company)) {
                                                                                                            if ($result[0]->si_company == $cm->mcomp_id) {
                                                                                                                echo "selected";
                                                                                                            }
                                                                                                        }; ?>> <?php echo $wd->mw_name;?> </option> 
                                                        <?php
                                                        } ?>

                                                    </select>
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_warehouse'); ?></div>

                                                </div>
                                                <!-- <span class="pull-right">
                                                    <label class="checkbox-inline">
                                                        <input type="checkbox" name="add_cash_customer" value="1"> Reserve Quantity
                                                    </label>
                                                </span> -->
                                            </div>

                                        </div>

                                        <!-- <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Project
</label>
<div class="col-md-8">
 <input type='text' name="date_ref" class="form-control" value=""  />
  <div class="form_error">  <?php echo $this->session->flashdata('date_ref'); ?></div>
</div>
</div>
</div>
 -->
                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder"> Bill no<abbr class="required">::*::</abbr>

                                                </label>
                                                <div class="col-md-8">
                                                    <input type="text" name="bill_no" class="form-control">
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_company'); ?></div>

                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder"> Narration<abbr class="required">::*::</abbr>

                                                </label>
                                                <div class="col-md-8">
                                                    <input type='text' name="mrn_narration" class="form-control" value="<?php if (!empty($result[0]->si_lpo_no)) {
                                                                                                                        echo $result[0]->si_lpo_no;
                                                                                                                    }; ?>" />
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_narration'); ?></div>

                                                </div>
                                                <!-- <span class="pull-right">
                                                    <label class="checkbox-inline">
                                                        <input type="checkbox" name="add_cash_customer" value="1"> Reserve Quantity
                                                    </label>
                                                </span> -->
                                            </div>

                                        </div>
                                        
                                       

                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder">Place of Supply
                                                </label>
                                                <div class="col-md-8">
                                                    <select data-plugin-selectTwo class="form-control populate" name="mrn_place_of_supply">
                                                        <option value="">Choose</option>
                                                        <?php
                                                        foreach ($place_supply as $ps) { ?>
                                                            <option value="<?php echo $ps->mw_id; ?>" <?php if (!empty($result[0]->si_plc_supply)) {
                                                                                                            if ($result[0]->si_plc_supply == $ps->mw_id) {
                                                                                                                echo "selected";
                                                                                                            }
                                                                                                        }; ?>> <?php echo $ps->mps_name; ?></option>
                                                        <?php
                                                        } ?>

                                                    </select>
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_place_of_supply'); ?></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder">Jurisdiction
                                                </label>
                                                <div class="col-md-8">
                                                    <select data-plugin-selectTwo class="form-control populate" name="mrn_jurisdiction">
                                                        <option value="">Choose</option>
                                                        <?php
                                                        foreach ($place_supply as $ps) { ?>
                                                            <option value="<?php echo $ps->mw_id; ?>" <?php if (!empty($result[0]->si_jurisdiction)) {
                                                                                                            if ($result[0]->si_jurisdiction == $ps->mw_id) {
                                                                                                                echo "selected";
                                                                                                            }
                                                                                                        }; ?>> <?php echo $ps->mps_name; ?></option>
                                                        <?php
                                                        } ?>

                                                    </select>
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_jurisdiction'); ?></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder"> Currency Name<abbr class="required">::*::</abbr>
                                                </label>
                                                <div class="col-md-8">
                                                    <select data-plugin-selectTwo class="form-control populate" name="mrn_currency">
                                                        <option value="">Choose</option>
                                                        <?php
                                                        foreach ($currency_convt as $cv) {
                                                        ?>
                                                            <option value="<?php echo $cv->c_id; ?>" <?php if (!empty($result[0]->si_currency)) {
                                                                                                        if ($result[0]->si_currency == $cv->c_id) {
                                                                                                            echo "selected";
                                                                                                        }
                                                                                                    } else {
                                                                                                        if ($cv->currency_name == "AED") {
                                                                                                            echo "selected";
                                                                                                        }
                                                                                                    }; ?>> <?php echo $cv->currency_name; ?> </option>
                                                        <?php
                                                        }
                                                        ?>
                                                    </select>
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_currency'); ?></div>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder">Currenct Conv.<abbr class="required">::*::</abbr>

                                                </label>
                                                <div class="col-md-8">
                                                    <input type='text' name="mrn_conv_value" readonly="" class="form-control" value="<?php if (!empty($result[0]->si_conv_value)) {
                                                                                                                                        echo $result[0]->si_conv_value;
                                                                                                                                    } else {
                                                                                                                                        echo "1";
                                                                                                                                    }; ?>" />
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_conv_value'); ?></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-12 table-rows-border">
                                            <div class="form-group">
                                                <label class="col-md-4 control-label" for="inputPlaceholder"> Vat Type<abbr class="required">::*::</abbr>
                                                </label>
                                                <div class="col-md-8">
                                                    <select data-plugin-selectTwo class="form-control populate" name="mrn_vat_type" required="">
                                                        <option value="">Choose</option>

                                                        <option value="1" selected="selected" <?php if (!empty($result[0]->si_vat_type)) {
                                                                                                    if ($result[0]->si_vat_type == '1') {
                                                                                                        echo "selected";
                                                                                                    }
                                                                                                }; ?>> Taxable Invoice</option>
                                                        <option value="2" <?php if (!empty($result[0]->si_vat_type)) {
                                                                                if ($result[0]->si_vat_type == '2') {
                                                                                    echo "selected";
                                                                                }
                                                                            }; ?>>Non-Taxable Invoice </option>

                                                    </select>
                                                    <div class="form_error"> <?php echo $this->session->flashdata('mrn_vat_type'); ?></div>

                                                </div>
                                            </div>
                                        </div>


                                    </div>

                                    <div class="col-md-12 col-sm-12 table-rows-border">
                                        <div class="form-group">
                                            <p>Upload files here.Make sure the file size is less than 2MB.</p>
                                            <input class="form-control" name="files[]" type="file" multiple required />
                                            <div class="form_error"> <?php echo $this->session->flashdata('files[]'); ?></div>
                                        </div>
                                    </div>
                                    <?php
                                    if (!empty($result[0]->si_attachments)) {
                                        echo "<h4> FILES UPLOADED :</h4>";
                                        $files_are = explode(',', $result[0]->si_attachments);
                                        foreach ($files_are as $fr) {
                                            echo "<a href='" . base_url("uploads/sales_invoice/" . $fr) . "' target='_blank'>" . $fr . "</a><br/>";
                                        }
                                    } else {
                                    }
                                    ?>

                                    <div class="col-md-12 col-sm-12 table-rows-border">
                                        <div class="table-responsive">
                                            <table class="table table-border table-rows-border">
                                                <thead>
                                                   
                                                    <th>Image</th>
                                                    <th>Item</th>
                                                    <th>Description</th>
                                                    <th>Units</th>
                                                    <th>Quantity</th>
                                                    <th>Link-1</th>
                                                    <th>Rate</th>
                                                    <th>Gross</th>
                                                    <th>Discount %</th>
                                                    <th>Discount Amount</th>
                                                    <th>Addl. Charges</th>
                                                   
                                                    <th>Vat %</th>

                                                    <th>CDiff</th>
                                                    <th>IDiff</th>
                                                  
                                                    <th>Tax Code</th>
                                                    <th></th>
                                                </thead>
                                                <tbody class="new_rows">
                                                    <?php
                                                    if (!empty($result[0])) /////used in update value
                                                    {
                                                        $warehouse_added = explode('|#|', $result[0]->mrn_warehouse);
                                                        $prd_added = explode('|#|', $result[0]->mrn_product);

                                                        $qnty_added = explode('|#|', $result[0]->mrn_quantity);
                                                        $sum_qnty = array_sum($qnty_added);

                                                        $rate_added = explode('|#|', $result[0]->mrn_rate);
                                                        $sum_rate = array_sum($rate_added);

                                                        $gross_added = explode('|#|', $result[0]->mrn_gross);
                                                        $sum_gross = array_sum($gross_added);

                                                        $disper_added = explode('|#|', $result[0]->mrn_discount_percentage);
                                                        $sum_disper = array_sum($disper_added);

                                                        $disamnt_added = explode('|#|', $result[0]->mrn_discount_amount);
                                                        $sum_disamnt = array_sum($disamnt_added);

                                                        $add_charges_added = explode('|#|', $result[0]->mrn_additional_charge);
                                                        $sum_add_charges = array_sum($add_charges_added);

                                                      

                                                        $vat_added = explode('|#|', $result[0]->mrn_vat);
                                                        $sum_vat = array_sum($vat_added);

                                                        

                                                        $total_count_rows = count($prd_added);
                                                        $ik = 1;
                                                        foreach ($prd_added as $ca_index => $pa) {
                                                    ?>
                                                            <tr>
                                                                
                                                                <td><img src="" width="100" height="100" class="img-responsive img<?php echo $ik; ?>"></td>
                                                                <td>
                                                                    <select data-plugin-selectTwo class="form-control populate product_<?php echo $ik; ?>" name="mrn_product[]" onchange="get_product_details()">
                                                                        <option value="">Choose</option>
                                                                        <?php
                                                                        foreach ($products_list as $prd) {
                                                                        ?>
                                                                            <option value="<?php echo $prd->pid; ?>" <?php if (!empty($pa)) {
                                                                                                                        if ($pa == $prd->pid) {
                                                                                                                            echo "selected";
                                                                                                                        }
                                                                                                                    }; ?>> <?php echo str_replace('|~~|', ',', $prd->pname); ?> ::<br /> <?php echo $prd->pcode; ?> </option>
                                                                        <?php
                                                                        }
                                                                        ?>
                                                                    </select>
                                                                </td>

                                                                <td><input type="text" name="mrn_description[]"  class="form-control description<?php echo $ik; ?>"> </td>
                                                                <td>
                                                                     
                                                                    <select class="form-control populate unit<?php echo $ik; ?>" name="mrn_unit[]">
                                                                        <option value="">Choose</option>
                                                                    </select>
                                                                </td>

                                                                <td><input type="number" name="mrn_quantity[]" onchange="calc_gross(<?php echo $ik; ?>);" onkeyup="calc_gross(<?php echo $ik; ?>);" min="0" value="<?php if (!empty($qnty_added[$ca_index])) {
                                                                                                                                                                                                        echo $qnty_added[$ca_index];
                                                                                                                                                                                                    } else {
                                                                                                                                                                                                        echo "0";
                                                                                                                                                                                                    }; ?>" step="any" class="form-control qnyt_dt qnty<?php echo $ik; ?>"> </td>

                                                                <td><input type="text" name="mrn_link_1[]"  class="form-control unit<?php echo $ik; ?>"> </td>
                                                                <td><input type="number" name="mrn_rate[]" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" value="<?php if (!empty($rate_added[$ca_index])) {
                                                                                                                                                                                                        echo $rate_added[$ca_index];
                                                                                                                                                                                                    } else {
                                                                                                                                                                                                        echo "0";
                                                                                                                                                                                                    }; ?>" step="any" class="form-control rate_dt rate<?php echo $ik; ?>"> </td>

                                                                <td><input type="number" name="mrn_gross[]" value="<?php if (!empty($gross_added[$ca_index])) {
                                                                                                                        echo $gross_added[$ca_index];
                                                                                                                    } else {
                                                                                                                        echo "0";
                                                                                                                    }; ?>" step="any" readonly="" class="form-control gross_dt gross<?php echo $ik; ?>"></td>

                                                                <td>
                                                                    <input type="hidden" name="dis_per_each_prd[]" value="0" class="form-control dis_per_each_prd<?php echo $ik; ?>">
                                                                    <input type="number" name="mrn_discount_percentage[]" value="<?php if (!empty($disper_added[$ca_index])) {
                                                                                                                        echo $disper_added[$ca_index];
                                                                                                                    } else {
                                                                                                                        echo "0";
                                                                                                                    }; ?>" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" step="any" class="form-control disc_per_dt disperc<?php echo $ik; ?>">
                                                                </td>

                                                                <td><input type="number" name="mrn_discount_amount[]" value="<?php if (!empty($disamnt_added[$ca_index])) {
                                                                                                                            echo $disamnt_added[$ca_index];
                                                                                                                        } else {
                                                                                                                            echo "0";
                                                                                                                        }; ?>" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" step="any" class="form-control disc_amount_dt disamnt<?php echo $ik; ?>"> </td>

                                                                <td><input type="number" name="mrn_additional_charge[]" value="<?php if (!empty($add_charges_added[$ca_index])) {
                                                                                                                            echo $add_charges_added[$ca_index];
                                                                                                                        } else {
                                                                                                                            echo "0";
                                                                                                                        }; ?>" onchange="calc_gross(<?php echo $ik; ?>)" onkeyup="calc_gross(<?php echo $ik; ?>)" step="any" class="form-control add_charges_dt addchrg<?php echo $ik; ?>">
                                                                </td>

                                                               
                                                                    <?php
                                                                    $fent_with_vat = $fnet_added[$ca_index] * ($vat_added[$ca_index] / 100);
                                                                    $tot_fnet_vat = $fent_with_vat + $fnet_added[$ca_index];
                                                                    ?>
                                                                    <input type="hidden" name="vat_fnet_val[]" value="<?php if (!empty($tot_fnet_vat)) {
                                                                                                                            echo $tot_fnet_vat;
                                                                                                                        }; ?>" class="form-control vat_fnet_val<?php echo $ik; ?>">

                                                                    <input type="hidden" name="vat_each_prd[]" value="0" class="form-control vat_each_prd_val<?php echo $ik; ?>">

                                                                    <input type="number" name="mrn_vat[]" value="<?php if (!empty($vat_added[$ca_index])) {
                                                                                                                    echo $vat_added[$ca_index];
                                                                                                                } else {
                                                                                                                    echo "0";
                                                                                                                }; ?>" step="any" readonly="" class="form-control vat_dt vat<?php echo $ik; ?>">
                                                                </td>
                                                                <td><input type="text" name="mrn_cdiff[]"  class="form-control cdiff cdiff<?php echo $ik; ?>"> </td>
                                                                <td><input type="text" name="mrn_idiff[]"  class="form-control idiff idiff<?php echo $ik; ?>"> </td>

                                                                <td><input type="text" name="mrn_tax_code[]" readonly="" value="<?php if (!empty($taxcode_added[$ca_index])) {
                                                                                                                                    echo $taxcode_added[$ca_index];
                                                                                                                                }; ?>" class="form-control"> </td>
                                                                <td></td>

                                                                <!-----for input tyype hidden fields------------->
                                                                <input type="hidden" name="hi_warehouse" class="form-control">
                                                                <input type="hidden" name="hi_prd_id" class="form-control">
                                                                <input type="hidden" name="hi_description" value="" class="form-control">
                                                                <input type="hidden" name="hi_unit" value="" class="form-control">

                                                                <input type="hidden" name="hi_quantity" value="0" class="form-control">
                                                                <input type="hidden" name="hi_link_1" value="0" class="form-control">
                                                                <input type="hidden" name="hi_rate" value="0" class="form-control">
                                                                <input type="hidden" name="hi_gross" value="0" class="form-control">
                                                                <input type="hidden" name="hi_discount_percentage" value="0" class="form-control">
                                                                <input type="hidden" name="hi_discount_amount" value="0" class="form-control">
                                                                <input type="hidden" name="hi_additional_charge" value="0" class="form-control">

                                                                <input type="hidden" name="hi_vat" value="0" class="form-control">

                                                                <input type="hidden" name="hi_cdiff" value="0" class="form-control">
                                                                <input type="hidden" name="hi_idiff" value="0" class="form-control">
                                                               
                                                                <input type="hidden" name="hi_remark" class="form-control">
                                                                <input type="hidden" name="hi_tax_code" value="0" class="form-control">
                                                                <!---------end for input type hidden--->

                                                            </tr>
                                                        <?php
                                                            $ik++;
                                                        }
                                                    } else ////for adding new , for new inovices///////////////
                                                    {
                                                        ?>
                                                        <tr>
                                                           
                                                            <td><img src="" width="100" height="100" class="img-responsive img1"></td>
                                                            <td>
                                                                <select data-plugin-selectTwo class="form-control populate product_1" name="mrn_product[]" onchange="get_product_details('1')">
                                                                    <option value="">Choose</option>
                                                                    <?php
                                                                    foreach ($products_list as $prd) {
                                                                    ?>
                                                                        <option value="<?php echo $prd->pid; ?>"> <?php
                                                                                                                    echo str_replace('|~~|', ',', $prd->pname); ?> ::<br /> <?php echo $prd->pcode; ?> </option>
                                                                    <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </td>
                                                            <td><input type="text" name="mrn_description[]"  class="form-control description1"> </td>
                                                            <td > 
                                                                    <!-- <select class="form-control populate unit1" name="si_unit[]">
                                                                        <option value="1">Choose</option>
                                                                    </select> -->
                                                                    <select class="form-control populate unit1" name="mrn_unit[]" style="width:120px;">
                                                                        <option value="">Choose</option>
                                                                   
                                                                    </select>
                                                            </td>
                                                            <td><input type="number" name="mrn_quantity[]" onchange="calc_gross('1');" onkeyup="calc_gross('1');" value="0" min="0" step="any" class="form-control qnyt_dt qnty1"> </td>
                                                            <td><input type="text" name="mrn_link_1[]"  class="form-control link_11"> </td>
                                                            <td><input type="number" name="mrn_rate[]" onchange="calc_gross('1')" onkeyup="calc_gross('1')" value="0" step="any" class="form-control rate_dt rate1"> </td>
                                                            <td><input type="number" name="mrn_gross[]" value="0" step="any" readonly="" class="form-control gross_dt gross1"></td>
                                                            <td>
                                                                <input type="hidden" name="dis_per_each_prd[]" value="0" class="form-control dis_per_each_prd1">
                                                                <input type="number" name="mrn_discount_percentage[]" value="0" onchange="calc_gross('1')" onkeyup="calc_gross('1')" step="any" class="form-control disc_per_dt disperc1">
                                                            </td>
                                                            <td><input type="number" name="mrn_discount_amount[]" value="0" onchange="calc_gross('1')" onkeyup="calc_gross('1')" step="any" class="form-control disc_amount_dt disamnt1"> </td>
                                                            <td><input type="number" name="mrn_additional_charge[]" value="0" onchange="calc_gross('1')" onkeyup="calc_gross('1')" step="any" class="form-control add_charges_dt addchrg1"> </td>

                                                            
                                                           
                                                            <td>
                                                                <input type="hidden" name="vat_fnet_val[]" value="0" class="form-control vat_fnet_val1">
                                                                <input type="hidden" name="vat_each_prd[]" value="0" class="form-control vat_each_prd_val1">
                                                                <input type="number" name="mrn_vat[]" value="5" step="any" readonly="" class="form-control vat_dt vat1">
                                                            </td>

                                                            <td><input type="text" name="mrn_cdiff[]"  class="form-control freight cdiff1"> </td>
                                                            <td><input type="text" name="mrn_idiff[]"  class="form-control freight idiff1"> </td>
                                                            <td><input type="text" name="mrn_tax_code[]" readonly="" value="0" class="form-control"> </td>
                                                            <td></td>

                                                            <!-----for input tyype hidden fields------------->
                                                            <input type="hidden" name="hi_warehouse" class="form-control">
                                                            <input type="hidden" name="hi_prd_id" class="form-control">
                                                            <input type="hidden" name="hi_description" value="" class="form-control">
                                                            <input type="hidden" name="hi_unit" value="" class="form-control">
                                                            <input type="hidden" name="hi_quantity" value="0" class="form-control">
                                                            <input type="hidden" name="hi_link_1" value="" class="form-control">
                                                            <input type="hidden" name="hi_rate" value="0" class="form-control">
                                                            <input type="hidden" name="hi_gross" value="0" class="form-control">
                                                            <input type="hidden" name="hi_discount_perentage" value="0" class="form-control">
                                                            <input type="hidden" name="hi_discount_amount" value="0" class="form-control">
                                                            <input type="hidden" name="hi_additional_charge" value="0" class="form-control">
                                                                                                                                                                           
                                                            <input type="hidden" name="hi_vat" value="0" class="form-control">
                                                            <input type="hidden" name="hi_cdiff" value="0" class="form-control">
                                                            <input type="hidden" name="hi_idiff" value="0" class="form-control">
                                                            <input type="hidden" name="hi_delivery_date" class="form-control datetimepicker5">
                                                            <input type="hidden" name="hi_remrk" class="form-control">
                                                            <input type="hidden" name="hi_tax_code" value="0" class="form-control">
                                                            <!---------end for input type hidden--->




                                                        </tr>
                                                    <?php
                                                    } ?>
                                                    <button type="button" class="btn btn-primary pull-right" onclick="add_more_row();">Add More</button>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>



                                    <!-------start col-md-12------------------->
                                    <div class="col-md-12 col-sm-12 table-rows-border">
                                        <label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
                                        <div class="col-md-8">
                                            <span class="num_items">
                                                <?php
                                                if (!empty($result[0])) {
                                                    if (!empty($total_count_rows)) {
                                                        echo $total_count_rows;
                                                    } else {
                                                        echo "1";
                                                    }
                                                } else {
                                                    echo "1";
                                                }
                                                ?>
                                            </span>
                                        </div>
                                    </div>
                                    <!----------end col-md-12----------------------------->

                                    <!-------start col-md-12------------------->
                                    <div class="col-md-6 col-sm-12 table-rows-border">
                                        <label class="col-md-4 control-label" for="inputPlaceholder">Total Quantity:<abbr class="required">::*::</abbr></label>
                                        <div class="col-md-8">
                                            <input type="text" readonly class="qnty_tot_button" name="si_tot_qnty" required="required" value="<?php if (!empty($sum_qnty)) {
                                                                                                                                                    echo $sum_qnty;
                                                                                                                                                } else {
                                                                                                                                                    echo "0";
                                                                                                                                                }; ?>">
                                        </div>
                                    </div>
                                    <!----------end col-md-12----------------------------->
                                    <!-------start col-md-12------------------->
                                    <div class="col-md-6 col-sm-12 table-rows-border">
                                        <label class="col-md-4 control-label" for="inputPlaceholder" style="display: none;"> Total Rate:<abbr class="required">::*::</abbr></label>
                                        <div class="col-md-8">
                                            <input type="hidden" readonly class="rate_tot_button" name="si_tot_rate" required="required" value="<?php if (!empty($sum_rate)) {
                                                                                                                                                    echo $sum_rate;
                                                                                                                                                } else {
                                                                                                                                                    echo "0";
                                                                                                                                                }; ?>">
                                        </div>
                                    </div>
                                    <!----------end col-md-12----------------------------->
                                    <!-------start col-md-12------------------->
                                    <div class="col-md-6 col-sm-12 table-rows-border">
                                        <label class="col-md-4 control-label" for="inputPlaceholder"> Total Gross:<abbr class="required">::*::</abbr></label>
                                        <div class="col-md-8">
                                            <input type="text" readonly class="gross_tot_button" name="si_tot_gross" required="required" value="<?php if (!empty($sum_gross)) {
                                                                                                                                                    echo $sum_gross;
                                                                                                                                                } else {
                                                                                                                                                    echo "0";
                                                                                                                                                }; ?>">
                                        </div>
                                    </div>
                                    <!----------end col-md-12----------------------------->
                                    <!-------start col-md-12------------------->
                                    <div class="col-md-6 col-sm-12 table-rows-border">
                                        <label class="col-md-4 control-label" for="inputPlaceholder"> Total Discount Percentage:<abbr class="required">::*::</abbr></label>
                                        <div class="col-md-8">
                                            <input type="text" readonly class="disc_per_tot_button" name="si_tot_desc_per" required="required" value="<?php if (!empty($sum_disper)) {
                                                                                                                                                            echo $sum_disper;
                                                                                                                                                        } else {
                                                                                                                                                            echo "0";
                                                                                                                                                        }; ?>">
                                        </div>
                                    </div>
                                    <!----------end col-md-12----------------------------->
                                    <!-------start col-md-12------------------->
                                    <div class="col-md-6 col-sm-12 table-rows-border">
                                        <label class="col-md-4 control-label" for="inputPlaceholder"> Total Discount Amount:<abbr class="required">::*::</abbr></label>
                                        <div class="col-md-8">
                                            <input type="text" readonly class="disc_amount_tot_button" name="si_tot_desc_amount" required="required" value="<?php if (!empty($sum_disamnt)) {
                                                                                                                                                                echo $sum_disamnt;
                                                                                                                                                            } else {
                                                                                                                                                                echo "0";
                                                                                                                                                            }; ?>">
                                        </div>
                                    </div>
                                    <!----------end col-md-12----------------------------->

                                    <!-------start col-md-12------------------->
                                    <div class="col-md-6 col-sm-12 table-rows-border">
                                        <label class="col-md-4 control-label" for="inputPlaceholder"> Total Additional Charges:<abbr class="required">::*::</abbr></label>
                                        <div class="col-md-8">
                                            <input type="text" readonly class="add_charges_tot_button" name="si_tot_add_charges" required="required" value="<?php if (!empty($sum_add_charges)) {
                                                                                                                                                                echo $sum_add_charges;
                                                                                                                                                            } else {
                                                                                                                                                                echo "0";
                                                                                                                                                            }; ?>">
                                        </div>
                                    </div>
                                    <!----------end col-md-12----------------------------->
                                    <!-------start col-md-12------------------->
                                    <!-- <div class="col-md-6 col-sm-12 table-rows-border">

                                        <label class="col-md-4 control-label" for="inputPlaceholder"> Total Fnet:<abbr class="required">::*::</abbr></label>
                                        <div class="col-md-8">
                                            <input type="text" readonly class="fnet_tot_button" name="si_tot_fnet" required="required" value="<?php if (!empty($sum_fnet)) {
                                                                                                                                                    echo $sum_fnet;
                                                                                                                                                } else {
                                                                                                                                                    echo "0";
                                                                                                                                                }; ?>">
                                        </div>
                                    </div> -->
                                    <!----------end col-md-12----------------------------->
                                    <!-------start col-md-12------------------->
                                    <div class="col-md-6 col-sm-12 table-rows-border">
                                        <label class="col-md-4 control-label" for="inputPlaceholder"> Total VAT Charges:<abbr class="required">::*::</abbr></label>
                                        <div class="col-md-8">
                                            <input type="text" readonly class="vat_tot_button" name="si_tot_vat" required="required" value="<?php if (!empty($si_tot_vat_amount)) {
                                                                                                                                                echo $si_tot_vat_amount;
                                                                                                                                            } else {
                                                                                                                                                echo "0";
                                                                                                                                            }; ?>">
                                        </div>
                                    </div>
                                    <!----------end col-md-12----------------------------->
                                    <!-------start col-md-12------------------->
                                    <div class="col-md-12 col-sm-12 table-rows-border">

                                        <button class="btn btn-primary" type="button" onclick="get_amount_total()">Click to see total amount</button>
                                        <br />
                                        <label class="col-md-4 control-label amount_text" for="inputPlaceholder">Amount Total:<abbr class="required">::*::</abbr></label>
                                        <div class="col-md-8">
                                            <input type="text" readonly class="amount_tot_button" name="si_tot_amount" required="required" value="<?php if (!empty($result[0]->si_tot_amount)) {
                                                                                                                                                        echo $result[0]->si_tot_amount;
                                                                                                                                                    } else {
                                                                                                                                                        echo "0";
                                                                                                                                                    }; ?>">
                                            <small>Amount as per the currency rate selected</small>
                                        </div>
                                    </div>
                                    <!----------end col-md-12----------------------------->

                                    <!-----div starts here for non-inquiry--->
                                    <!----div end here for non-inquiry--->
                        </section>
                        <!-----div starts here for non-inquiry--->
                        <input type="hidden" name="sales_inv_cust_id">
                        <input type="hidden" name="sales_inv_id">
                        <input type="hidden" name="sales_inv_amount">
                        <input type="hidden" name="sales_inv_amount_paid">
                        <input type="hidden" name="sales_doc_num">

                        <!-----div starts here for non-inquiry--->
                        <!-- Button trigger modal for sales invoice-->
                        <div id="modalmd_sinv" class="modal-block modal-block-lg mfp-hide">
                            <section class="panel">
                                <header class="panel-heading">
                                    <h2 class="panel-title">References </h2>
                                </header>
                                <div class="panel-body">
                                    <div class="modal-wrapper">
                                        <div class="modal-text modal_content_sinv">

                                        </div>
                                    </div>
                                </div>
                                <footer class="panel-footer">
                                    <div class="row">
                                        <div class="col-md-12 text-right">
                                            <button type="button" onclick="submit_sales_inv_amount()" class="btn btn-primary confirm_btn_modal">Confirm</button>
                                            <button class="btn btn-default modal-dismiss modal-close-btn">Cancel</button>
                                        </div>
                                    </div>
                                </footer>
                            </section>
                        </div>
                        <!----end modal--->
                        <!----div closes here--->


                        <div class="cell_text_data"></div>

                        <div class="col-sm-9 col-sm-offset-3">
                            <a type="button" class="btn btn-primary mb-xs mt-xs mr-xs modal-sizes" href="#modalmd_sinv" onclick="get_cust_sales_inv()">Save</a>
                            <button style="display: none;" type="submit" class="submit_btn"></button>
                            <button type="reset" class="btn btn-default" onclick="check_for_reset()">Reset</button>
                        </div>

                        <?php echo form_close(); ?>
                    </div>
                </div>


            </section>
        </div>
    </section>


    <aside id="sidebar-right" class="sidebar-right">
        <div class="nano">
            <div class="nano-content">
                <a href="#" class="mobile-close visible-xs">
                    Collapse <i class="fa fa-chevron-right"></i>
                </a>
                <div class="sidebar-right-wrapper">

                    <div class="sidebar-widget widget-friends ">

                        <div class="chat_window">
                            <?php $this->load->view('admin/master_essential/chat_data', $chat); ?>

                        </div>
                    </div>



                </div>
            </div>
        </div>
    </aside>

    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery/jquery.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/select2/select2.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.custom.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/theme.init.js" type="text/javascript"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/forms/examples.advanced.form.js" type="text/javascript" />
    </script>

    <script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript"></script>


    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/'); ?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>


    <script>
        $(document).on('ready', function() {
            $('input').attr('autocomplete', 'off');
            $("#file-1").fileinput();
        });
    </script>

    <script>
        tinymce.init({
            selector: '.editors',
            plugins: [
                'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
            ],
        });
    </script>

    <script type="text/javascript">
        function add_more_row() {
            var tablecount = $('table tbody tr').length;
            if (tablecount == "0") {
                var table_id = "1";
            } else {
                var table_id = parseInt($(".num_items").text()) + 1;
            }
            var prev_table_row = parseFloat(table_id) - 1;
            var warehouse_selected_prev = $('.warehouse_' + prev_table_row).find('option:selected').val();
            var markup = '<tr class="table' + table_id + '">' +
                ' <td class="select_warehouse_list_' + table_id + '">';
            jQuery.ajax({
                url: "<?php echo base_url() . 'Sales_invoice/get_details_warehouse'; ?>",
                data: {
                    "table_id": table_id
                },
                type: "post",
                success: function(result) {
                    // console.log(result);
                    if (result) {
                        $('.select_warehouse_list_' + table_id).html(result);
                        $('.warehouse_' + table_id).val(warehouse_selected_prev).trigger('change');
                        $('select[name="si_warehouse[]"]').select2();

                    }
                }
            });

            markup += '</td>' +
                '<td><img src="" width="100" height="100" class="img-responsive img' + table_id + '"></td>' +
                ' <td class="select_prd_list_' + table_id + '">';
            jQuery.ajax({
                url: "<?php echo base_url() . 'Sales_invoice/get_details_prd'; ?>",
                data: {
                    "table_id": table_id
                },
                type: "post",
                success: function(result) {
                    if (result) {
                        $('.select_prd_list_' + table_id).html(result);
                        $('select[name="si_product[]"]').select2();
                    }
                }
            });
            markup += '</td>' +
                '<td><input type="number" name="si_qnty[]" onchange="calc_gross(' + table_id + ');" onkeyup="calc_gross(' + table_id + ');"  value="0" step="any" class="form-control qnyt_dt qnty' + table_id + '"></td>' +
                '<td><input type="number" name="si_rate[]" onchange="calc_gross(' + table_id + ');" onkeyup="calc_gross(' + table_id + ');" value="0" step="any" class="form-control rate_dt rate' + table_id + '"> </td>' +

                '<td><input type="number" name="si_gross[]"  value="0" step="any" class="form-control gross_dt gross' + table_id + '" readonly=""> </td>' +

                '<td><input type="number" name="si_dis_per[]"  value="0" onchange="calc_gross(' + table_id + ');" onkeyup="calc_gross(' + table_id + ');" step="any" class="form-control disc_per_dt disperc' + table_id + '"> </td>' +

                '<td>' +
                ' <input type="hidden" name="dis_per_each_prd[]"  value="0" class="form-control dis_per_each_prd' + table_id + '">' +
                '<input type="number" name="si_dis_amount[]"  value="0" onchange="calc_gross(' + table_id + ');" onkeyup="calc_gross(' + table_id + ');"  step="any" class="form-control disc_amount_dt disamnt' + table_id + '"> </td>' +

                '<td><input type="number" name="si_add_charges[]"  value="0" onchange="calc_gross(' + table_id + ');" onkeyup="calc_gross(' + table_id + ');"  step="any" class="form-control add_charges_dt addchrg' + table_id + '"> </td>' +

                '<td><input type="number"  name="si_fnet[]" step="any"value="0"  readonly="" class="form-control fnet_dt fnet' + table_id + '"> </td>' +

                '<td> <input type="hidden" name="vat_fnet_val[]"  value="0" class="form-control vat_fnet_val' + table_id + '"> ' +
                ' <input type="hidden" name="vat_each_prd[]"  value="0" class="form-control vat_each_prd_val' + table_id + '">' +
                '<input type="number" name="si_vat[]"  step="any" value="5"  readonly=""  class="form-control vat_dt vat' + table_id + '"> </td>' +

                '<td><input name="si_delivery_date[]" type="text" class="form-control datetimepicker5"> </td> ' +
                '<td><input type="text" name="si_remrk[]" class="form-control"> </td> ' +
                '<td><input type="text" name="si_tax_code[]" value="0" readonly="" class="form-control"> </td> ' +

                ' <td><button type="button" class="btn btn-danger" style="cursor: pointer" onclick=table(' + table_id + ')>X</button></td>' +

                '</tr>';

            $(".new_rows").append(markup);
            var rowcount = $('table tbody tr').length;
            $(".num_items").html(rowcount);
            $('select[name="si_product[]"]').select2();
            $('select[name="si_warehouse[]"]').select2();
            $('input[name="si_delivery_date[]"]').datepicker();
        }

        function table(id) {
            $('table tbody .table' + id).remove();
            var rowcount = $('table tbody tr').length;
            $(".num_items").html(rowcount);
        }
    </script>

    <script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
    <script>
        tinymce.init({
            selector: '.editors',
            plugins: [
                'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
            ],
        });
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

    <script type="text/javascript">
        $(function() {
            $('.datetimepicker4').datepicker();
        });

        $(function() {
            var date2 = $('.datetimepicker4').datepicker('getDate', '+1d');
            date2.setDate(date2.getDate() + 1);
            $('.datetimepicker5').datepicker().datepicker("setDate", date2);
        });

        $(document).on('ready', function() {
            $('select[name="si_currency"]').on('change', function() {

                jQuery.ajax({
                    url: "<?php echo base_url() . 'Receipt_Master/get_currency_conv_val'; ?>",
                    data: {
                        "currecny_selected": $(this).val()
                    },
                    type: "post",
                    success: function(result) {
                        if (result) {
                            $("input[name='si_conv_value']").val(result);
                        }
                    }
                });
            });

            $('select[name="si_vat_type"]').on('change', function() {
                var vat_choosed = $(this).val();
                if (vat_choosed == "2") {
                    $('input[name="si_vat[]"]').val('0');
                } else {
                    $('input[name="si_vat[]"]').val('5');
                }
            });

            $('.menu_name_fun').on('click', function() {
                if (confirm("Are you sure, You want to exit this page?")) {
                    location.href = $(this).attr('href');
                } else {
                    return false;
                }

            });

            $('select[name="si_customer_acc_id"]').on("change", function() {
                jQuery.ajax({
                    url: "<?php echo base_url() . 'Sales_invoice/get_cust_full_details'; ?>",
                    data: {
                        "cust_id": $(this).val()
                    },
                    type: "post",
                    success: function(result) {
                        if (result) {
                            var returndata = JSON.parse(result);
                            $('select[name="si_company"] ').val(returndata[0]['macd_company_id']).trigger('change');
                            $('select[name="si_salesman"]').val(returndata[0]['macd_salesman_id']).trigger('change');
                            $('select[name="si_country"]').val(returndata[0]['country']).trigger('change');
                            $('select[name="si_payment_type"]').val(returndata[0]['macd_payment_type_id']).trigger('change');
                            $('select[name="si_pc_level"]').val(returndata[0]['macd_price_level_id']).trigger('change');
                            $('select[name="si_plc_supply"]').val(returndata[0]['macd_place_supply_id']).trigger('change');
                            $('select[name="si_jurisdiction"]').val(returndata[0]['macd_jurisdication_id']).trigger('change');
                            $('select[name="si_sales_acc_id"]').val(returndata[0]['macd_sales_acc_id']).trigger('change');

                            if (returndata[0]['macd_currency_value'] != null) {
                                $('select[name="si_currency"]').val(returndata[0]['macd_currency_value']).trigger('change');
                                if (returndata[0]['currency_val'] != null)
                                    $('input[name="si_conv_value"]').val(returndata[0]['currency_val']);
                                else
                                    $('input[name="si_conv_value"]').val('1');
                            } else {
                                $('select[name="si_currency"]').val('1').trigger('change');
                                $('input[name="si_conv_value"]').val('1');
                            }

                            if (returndata[0]['phone'] != null)
                                $('input[name="si_contact"]').val(returndata[0]['phone']);
                            else
                                $('input[name="si_contact"]').val(returndata[0]['mobile_phone']);

                            if (returndata[0]['address'] != null)
                                $('input[name="si_delivery_address"]').val(returndata[0]['address']);
                            // console.log(returndata[0]);
                        }
                    }
                });
            });

        });

        function get_product_details(table_id) {
            var prd_selected = $('.product_' + table_id).find('option:selected').val();
            var vat_type_choosed = $('select[name="si_vat_type"]').find('option:selected').val();
            if (vat_type_choosed == "2") {
                $('input[name="si_vat[]"]').val('0');
            } else {
                $('input[name="si_vat[]"]').val('5');
            }

            jQuery.ajax({
                url: "<?php echo base_url() . 'Sales_invoice/get_product_details'; ?>",
                data: {
                    "prd_id": prd_selected
                },
                type: "post",
                success: function(result) {
                    if (result) {
                        var returndata = JSON.parse(result);
                        $('.img' + table_id).attr('src', returndata['pimage']);
                        $('.rate' + table_id).val(returndata['prd_price']);
                        
                        // console.log(result);
                        
          
                    }
                }
            });
            jQuery.ajax({
                url: "<?php echo base_url() . 'Purchase_controller/get_product_extras'; ?>",
                data: {
                "prd_id": prd_selected,
                "table_id": table_id
                },
                type: "post",
                success: function(result) {
                if (result) {
                    console.log(result);
                    $('.unit' + table_id).html(result);
                }
                }
            });
        }

        function calc_gross(table_id) {
            var qnty_tbl = $('.qnty' + table_id).val();
            var rate_tbl = $('.rate' + table_id).val();
            var tot_gross = parseFloat(qnty_tbl) * parseFloat(rate_tbl);

            $('.gross' + table_id).val(tot_gross);

            var dis_per_tbl = $('.disperc' + table_id).val();

            var dis_amnt_tbl = $('.disamnt' + table_id).val();
            var add_charge_tbl = $('.addchrg' + table_id).val();

            var tot_dis_per_amont = (parseFloat(dis_per_tbl) / parseFloat(100)) * parseFloat(tot_gross);

            $('.dis_per_each_prd' + table_id).val(tot_dis_per_amont);

            var tot_fnet_calc = parseFloat(tot_gross) - parseFloat(tot_dis_per_amont) - parseFloat(dis_amnt_tbl) + parseFloat(add_charge_tbl);

            $('.fnet' + table_id).val(tot_fnet_calc);
            var vat_tbl = $('.vat' + table_id).val();

            var fent_with_vat = parseFloat(tot_fnet_calc) * (parseFloat(vat_tbl) / parseFloat(100));
            $('.vat_each_prd_val' + table_id).val(fent_with_vat);
            var tot_fnet_vat = parseFloat(fent_with_vat) + parseFloat(tot_fnet_calc);
            $('.vat_fnet_val' + table_id).val(tot_fnet_vat);

        }

        function get_amount_total() {
            var amountss1 = '0';
            $('table tbody tr td input[name="si_qnty[]"]').each(function() {
                amountss1 = parseFloat(amountss1) + parseFloat($(this).val());
            });
            $('.qnty_tot_button').val(parseFloat(amountss1.toFixed(2)));

            //////for rate tot calc//////
            var amountss_2 = '0';
            $('table tbody tr td input[name="si_rate[]"]').each(function() {
                amountss_2 = parseFloat(amountss_2) + parseFloat($(this).val());
            });
            $('.rate_tot_button').val(parseFloat(amountss_2.toFixed(2)));

            /////////for gross tot_calc//////////

            var amountss_3 = '0';
            $('table tbody tr td input[name="si_gross[]"]').each(function() {
                amountss_3 = parseFloat(amountss_3) + parseFloat($(this).val());
            });
            $('.gross_tot_button').val(parseFloat(amountss_3.toFixed(2)));

            ///////for dis per tot calc field/////////
            //  var amountss_4='0';
            // $('table tbody tr td input[name="si_dis_per[]"]').each(function(){
            // amountss_4= parseFloat(amountss_4)+parseFloat($(this).val());
            // }); 
            // $('.disc_per_tot_button').val(parseFloat(amountss_4));

            ///////for dis per tot calc field/////////
            var amountss_4_1 = '0';
            $('table tbody tr td input[name="dis_per_each_prd[]"]').each(function() {
                amountss_4_1 = parseFloat(amountss_4_1) + parseFloat($(this).val());
            });
            $('.disc_per_tot_button').val(parseFloat(amountss_4_1.toFixed(2)));

            //////for dis amount tot calc field/////////
            var amountss_5 = '0';
            $('table tbody tr td input[name="si_dis_amount[]"]').each(function() {
                amountss_5 = parseFloat(amountss_5) + parseFloat($(this).val());
            });
            $('.disc_amount_tot_button').val(parseFloat(amountss_5.toFixed(2)));

            //////////for add charges tot calc field///////
            var amountss_6 = '0';
            $('table tbody tr td input[name="si_add_charges[]"]').each(function() {
                amountss_6 = parseFloat(amountss_6) + parseFloat($(this).val());
            });
            $('.add_charges_tot_button').val(parseFloat(amountss_6.toFixed(2)));

            ///////for fnet tot calc field///////////
            var amountss_7 = '0';
            $('table tbody tr td input[name="si_fnet[]"]').each(function() {
                amountss_7 = parseFloat(amountss_7) + parseFloat($(this).val());
            });
            $('.fnet_tot_button').val(parseFloat(amountss_7.toFixed(2)));

            ////////////for vat tot calc field//////
            //  var amountss_8='0';
            // $('table tbody tr td input[name="si_vat[]"]').each(function(){
            // amountss_8= parseFloat(amountss_8)+parseFloat($(this).val());
            // }); 
            // $('.vat_tot_button').val(parseFloat(amountss_8));

            ////////////for vat tot calc field//////
            var amountss_8_1 = '0';
            $('table tbody tr td input[name="vat_each_prd[]"]').each(function() {
                amountss_8_1 = parseFloat(amountss_8_1) + parseFloat($(this).val());
            });
            $('.vat_tot_button').val(parseFloat(amountss_8_1.toFixed(2)));

            //////////show total amount///////////
            if (amountss_8_1 != null) ////vat  is present
            {
                var amountss_9 = '0';
                $('table tbody tr td input[name="vat_fnet_val[]"]').each(function() {
                    amountss_9 = parseFloat(amountss_9) + parseFloat($(this).val());
                });
                $('.amount_tot_button').val(parseFloat(amountss_9.toFixed(2)));
            } else {
                $('.amount_tot_button').val(parseFloat(amountss_7.toFixed(2)));
            }


        }


        function get_cust_sales_inv() {
            var cust_id = $('select[name="si_customer_acc_id"]').find('option:selected').val();
            jQuery.ajax({
                url: "<?php echo base_url() . 'Sales_invoice/get_cust_sales_inv'; ?>",
                data: {
                    "cust_id": cust_id
                },
                type: "post",
                success: function(result) {
                    //console.log(result);
                    $('.modal_content_sinv').html(result);
                    $('#datatable-default2').DataTable();
                }
            });

        }
        ///////////////////////modal functions page/////////////////////////////////////////////////

        function get_pick_amount(ij_val = null) {
            var param_data = pass_param();
            var param_val = param_data.split("##");
            var ij = param_val[0];
            var ref_doc_num = param_val[1];

            var form_input_amount = $('input[name="si_tot_amount"]').val();
            var to_be_adjust = $('.to_be_adjust').html();
            var amount_adjusted_till_now = $('.amount_adjusted').html();

            if (amount_adjusted_till_now == '')
                var amount_picked = 0;
            else
                var amount_picked = parseFloat(amount_adjusted_till_now);

            if (to_be_adjust == '')
                var amount_adjusted = 0;
            else
                var amount_adjusted = parseFloat(to_be_adjust);

            if (ij != '') {
                console.log('ij ' + ij);
                if ($('.inv_selected_' + ij).is(':checked')) {
                    var total_amount_in_ref = $('.tot_sales_amount_' + ij).val();
                    var amount_paid = $('.tot_sales_amount_paid_' + ij).val();
                    if (amount_paid == '' || amount_paid == '0') {
                        console.log('in if 1');
                        $('input[name="refrence"]').val('0');
                        // console.log(total_amount_in_ref);
                        if (parseFloat(total_amount_in_ref) > parseFloat(form_input_amount)) {
                            console.log('in if 11');
                            if (parseFloat(amount_adjusted) == '0' || parseFloat(amount_adjusted) == '' || parseFloat(amount_adjusted) == '0.00') {
                                console.log('in if 12');
                                var new_amount_adjusted = parseFloat(total_amount_in_ref) - parseFloat(form_input_amount);
                                $('.tot_sales_amount_paid_' + ij).val(form_input_amount);
                                amount_picked = parseFloat(form_input_amount);
                                amount_adjusted = parseFloat(form_input_amount) - parseFloat(amount_picked);
                            } else {

                                console.log('in else 12');
                                var new_amount_adjusted = parseFloat(total_amount_in_ref) - parseFloat(amount_adjusted);
                                $('.tot_sales_amount_paid_' + ij).val(amount_adjusted);
                                amount_picked = parseFloat(amount_picked) + parseFloat(amount_adjusted);
                                amount_adjusted = parseFloat(form_input_amount) - parseFloat(amount_picked);

                            }
                        } else if (parseFloat(total_amount_in_ref) < parseFloat(form_input_amount)) {
                            console.log('in if 11.elseif');
                            if (parseFloat(amount_adjusted) == '0' || parseFloat(amount_adjusted) == '' || parseFloat(amount_adjusted) == '0.00') {
                                console.log('in if 12.elseif');
                                var new_amount_adjusted = parseFloat(form_input_amount) - parseFloat(total_amount_in_ref);
                                $('.tot_sales_amount_paid_' + ij).val(total_amount_in_ref);
                                amount_picked = parseFloat(amount_adjusted_till_now) + parseFloat(total_amount_in_ref);
                                amount_adjusted = parseFloat(form_input_amount) - parseFloat(amount_picked);
                            } else {
                                console.log('in else 12.elseif');
                                var new_amount_adjusted = parseFloat(amount_adjusted) - parseFloat(total_amount_in_ref);
                                console.log(new_amount_adjusted);
                                $('.tot_sales_amount_paid_' + ij).val(total_amount_in_ref);
                                amount_picked = parseFloat(amount_adjusted_till_now) + parseFloat(total_amount_in_ref);
                                amount_adjusted = parseFloat(new_amount_adjusted);
                            }

                        } else {
                            if (amount_adjusted != '0') {
                                console.log('in else 1.11' + amount_adjusted);
                                var new_amount_adjusted = parseFloat(total_amount_in_ref) - parseFloat(amount_adjusted);
                                $('.tot_sales_amount_paid_' + ij).val(amount_adjusted);
                                amount_picked = parseFloat(amount_picked) + parseFloat(amount_adjusted);
                                amount_adjusted = parseFloat(form_input_amount) - parseFloat(amount_picked);

                            } else {
                                console.log('in else 11');
                                if ($('input[name="refrence"]').val() == '0') {
                                    console.log('in else 11 - in if 11');
                                    var new_ref_value = $('input[name="refrence"]').val();
                                    amount_picked = parseFloat(amount_picked) - parseFloat(new_ref_value);
                                    amount_adjusted = parseFloat(amount_adjusted) - parseFloat(new_ref_value);
                                } else {
                                    console.log('in else 11- in else 11');
                                    $('.tot_sales_amount_paid_' + ij).val(total_amount_in_ref);
                                    amount_picked = parseFloat(amount_picked) + parseFloat(total_amount_in_ref);
                                    amount_adjusted = parseFloat(form_input_amount) - parseFloat(amount_picked);
                                }
                            }
                        }
                    } else {
                        console.log('in else 1- ' + to_be_adjust);
                        if ((to_be_adjust != '0.00')) {
                            if (to_be_adjust != '0') {
                                console.log('in else 1.1.1');
                                var new_ref_val = $('input[name="refrence"]').val();
                                $('input[name="refrence"]').val(parseFloat(new_ref_val) + parseFloat(to_be_adjust));
                                amount_picked = parseFloat(amount_adjusted_till_now) + parseFloat(to_be_adjust);
                                amount_adjusted = parseFloat(form_input_amount) - parseFloat(amount_picked);


                            }
                        } else {
                            console.log('in else 1.1.2');
                            $('input[name="refrence"]').val($('input[name="refrence"]').val());
                        }
                    }

                } else {
                    $('input[name="refrence"]').val(form_input_amount);
                }
            } else {
                $('.confirm_btn_modal').show();
                if (to_be_adjust != '0.00') {
                    $('input[name="refrence"]').val(form_input_amount);
                    if ((amount_adjusted_till_now != '') && (amount_adjusted_till_now != '0')) {
                        amount_picked = amount_adjusted_till_now;
                        amount_adjusted = parseFloat(form_input_amount) - parseFloat(amount_picked);
                    } else {
                        amount_picked = form_input_amount;
                        amount_adjusted = parseFloat(form_input_amount) - parseFloat(amount_picked);
                    }
                } else {}
            }

            $('.amount_to_adj').html(form_input_amount);
            $('.amount_adjusted').html(amount_picked);
            $('.to_be_adjust').html(amount_adjusted);

            // $('.form_input_ref_'+table_id).val($('.form_input_ref_'+table_id).val() + ref_doc_num+'|#|');
            //   $('.modal-close-btn').trigger('click');
        }


        function pass_param() {
            var checked_val = [];
            var ref_number_correspond = '';
            var unchecked_val = [];
            $('.class_checkbox').each(function() {
                if ($(this).is(':checked')) {
                    if (checked_val == '') {
                        checked_val = $(this).val();
                    } else if (jQuery.inArray($(this).val(), checked_val) !== -1) {
                        checked_val = $(this).val();
                    } else {
                        if ($(this).val() != checked_val) ///maybe from the unchceked value
                        {
                            if ($('.tot_sales_amount_paid_' + $(this).val()).val() == '0') {
                                checked_val = $(this).val();
                            }
                        }
                    }
                } else {
                    unchecked_val = $(this).val();
                    $('.confirm_btn_modal').show();
                    if (jQuery.inArray($(this).val(), checked_val) == -1) {
                        checked_val = $.grep(checked_val, function(value) {
                            return value != unchecked_val;
                        });
                    }
                    var picked_adjusted_amount = $('.tot_sales_amount_paid_' + unchecked_val).val();
                    $('.tot_sales_amount_paid_' + unchecked_val).val('0');
                    var amount_adjusted = $('.amount_adjusted').html();
                    var to_adjust = $('.to_be_adjust').html();
                    var newly_adjusted = parseFloat(amount_adjusted) - parseFloat(picked_adjusted_amount);
                    $('.amount_adjusted').html(newly_adjusted);
                    var new_to_adjust = parseFloat(to_adjust) + parseFloat(picked_adjusted_amount);
                    $('.to_be_adjust').html(new_to_adjust);

                }
            });
            ref_number_correspond = $('.ref_doc_numbers_' + checked_val).val();
            return checked_val + '##' + ref_number_correspond;
        }


        function check_val_less_than_amount(ij) {

            var tot_amount = $('.tot_sales_amount_' + ij).val();
            var paid_amount = $('.tot_sales_amount_paid_' + ij).val();

            var balnce_amount = parseFloat(tot_amount) - parseFloat(paid_amount);
            $('.tot_sales_bal_amount_' + ij).val(balnce_amount.toFixed(2));

            if (parseFloat(paid_amount) > parseFloat(tot_amount)) {
                $('.amount_overdue_' + ij).html('Paid amount exceeds total amount');
                $('.confirm_btn_modal').hide();
            } else {
                $('.amount_overdue_' + ij).html('');
                $('.confirm_btn_modal').show();
            }
        }


        function get_checked_count(ij) {
            var amounts = 0;
            if ($('.inv_selected_' + ij).is(':checked')) {
                amounts = parseFloat($('input[name="total_invs_edited"]').val()) + parseFloat($('.tot_sales_amount_' + ij).val());
                $('input[name="total_invs_edited"]').val(amounts);
                //$('input[name="add_cash_customer"]').val('1');
                //console.log('checked box');
                //$('.cash_cusotmer_details').show();

            } else {
                var amounts = 1;
                amounts = parseFloat($('input[name="total_invs_edited"]').val()) - parseFloat($('.tot_sales_amount_' + ij).val());
                $('input[name="total_invs_edited"]').val(amounts);
            }
        }


        function submit_sales_inv_amount() {
            var issue_text_data = $('.text_data_issue').html();
            var to_be_adjust = $('.to_be_adjust').html();
            var refrence_names = '';
            if (to_be_adjust == '0') {

                $('.class_checkbox').each(function() {
                    if ($(this).is(':checked')) {
                        //    console.log(sales_doc_num);

                        var sales_inv_ids = $('table tbody tr td input[name="inv_id_modal[]"]').map(function() {
                            return $(this).val();
                        }).get().join('|#|');
                        var sales_inv_amount = $('table tbody tr td input[name="sales_inv_amount_modal[]"]').map(function() {
                            return $(this).val();
                        }).get().join('|#|');
                        //console.log(sales_inv_ids); 
                        var sales_inv_amount_paid = $('table tbody tr td input[name="paid_amount_modal[]"]').map(function() {
                            return $(this).val();
                        }).get().join('|#|');
                        var sales_inv_doc_num = $('table tbody tr td input[name="inv_doc_numbers_modal[]"]').map(function() {
                            return $(this).val();
                        }).get().join('|#|');

                        $("input[name='sales_inv_id']").val(sales_inv_ids);
                        $("input[name='sales_inv_amount']").val(sales_inv_amount);
                        $("input[name='sales_inv_amount_paid']").val(sales_inv_amount_paid);
                        $("input[name='sales_doc_num']").val(sales_inv_doc_num);
                        // $('.confirm_btn_modal').hide();
                    } else {}
                });
                $('.submit_btn').trigger('click');
                $('.modal-close-btn').trigger('click');

            } else {
                // $('.modal-close-btn').trigger('click');
                alert('Error in paid amount');
            }
        }

        /////////////////////end of modal functions////////////////////////////////////


        function check_for_reset() {
            if (confirm("Are you sure, You want to reset this form?")) {
                $('.myform').trigger("reset");
            } else {
                return false;
            }
        }


        $('.myform').submit(function() {
            // e.preventDefault();

            var rowcount = $('.new_rows tr').length;

            var warehouse_ids = $('table tbody tr td select[name="si_warehouse[]"]').map(function() {
                return $(this).find('option:selected').val();
            }).get().join('|#|');

            var prd_ids = $('table tbody tr td select[name="si_product[]"]').map(function() {
                return $(this).find('option:selected').val();
            }).get().join('|#|');

            var qnty_nos = $('table tbody tr td input[name="si_qnty[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            var rate_nos = $('table tbody tr td input[name="si_rate[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            var gross_nos = $('table tbody tr td input[name="si_gross[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            var disc_per_nos = $('table tbody tr td input[name="si_dis_per[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            var disc_amount_nos = $('table tbody tr td input[name="si_dis_amount[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            var add_charges_nos = $('table tbody tr td input[name="si_add_charges[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            var fent_nos = $('table tbody tr td input[name="si_fnet[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            var vat_nos = $('table tbody tr td input[name="si_vat[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            var delivery_date_nos = $('table tbody tr td input[name="si_delivery_date[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            var remark_nos = $('table tbody tr td input[name="si_remrk[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            var tax_code_nos = $('table tbody tr td input[name="si_tax_code[]"]').map(function() {
                return $(this).val();
            }).get().join('|#|');

            //console.log(quantity+' '+package_size+' '+product_id);

            $("input[name='hi_warehouse']").val(warehouse_ids);
            $("input[name='hi_prd_id']").val(prd_ids);
            $("input[name='hi_qnty']").val(qnty_nos);
            $("input[name='hi_rate']").val(rate_nos);
            $("input[name='hi_gross']").val(gross_nos);
            $("input[name='hi_dis_per']").val(disc_per_nos);
            $("input[name='hi_dis_amount']").val(disc_amount_nos);
            $("input[name='hi_add_charges']").val(add_charges_nos);
            $("input[name='hi_fnet']").val(fent_nos);
            $("input[name='hi_vat']").val(vat_nos);
            $("input[name='hi_delivery_date']").val(delivery_date_nos);
            $("input[name='hi_remrk']").val(remark_nos);
            $("input[name='hi_tax_code']").val(tax_code_nos);

            var ij = 0;
            var data_var = [];

            $('.new_rows tr td').each(function() {
                var cellText = $(this).html();
                //  console.log(cellText);  
                $('.cell_text_data').append(cellText).hide();
            });

            //console.log(cellText);
            // console.log($("input[name='hid_salesman']").val());
            // console.log($("input[name='hid_customer']").val());
            // console.log($("input[name='hid_amounts']").val());
            // console.log($("input[name='hid_remark']").val());
            //  console.log($("input[name='hid_ref']").val());
            //var table_row_added=$('.new_rows').html();

            if ($('.new_rows tr').length == 0) {
                alert('Please choose items to add and submit');
                return false;
            } else {

                return true;

            }
            //return false;
            // your code here
        });
        // }
    </script>

</body>

</html>