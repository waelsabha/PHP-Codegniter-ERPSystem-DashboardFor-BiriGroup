<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Excel Upload Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Excel Upload Form</span></li>
<li><span>Upload</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Excel Upload Form</h2>
</header>
<div class="panel-body">
	<?php echo form_open_multipart('submit_excel_sheet','class="form-horizontal form-bordered"');?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

    <div class="form-group">
<label class="col-md-3 control-label" for="inputPlaceholder">File name</label>
<div class="col-md-6">

 <input type="text" class="form-control"  name="dwnload_title" > 
 <div class="form_error">  <?php echo $this->session->flashdata('dwnload_title');?></div>
</div>
</div>


<div class="form-group">
	<label class="col-md-3 control-label">File Upload</label>
	<div class="col-md-6">
	<div class="fileupload fileupload-new" data-provides="fileupload">
	<div class="input-append">
	<div class="uneditable-input">
	<i class="fa fa-file fileupload-exists"></i>
	<span class="fileupload-preview"></span>
	</div>
	<span class="btn btn-default btn-file">
	<span class="fileupload-exists">Change</span>
	<span class="fileupload-new">Select file</span>
	<input type="file" name="userfile">
	</span>
	<a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
	</div>
	</div>
	</div>
</div>

 



<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>


<?php echo form_close();?>
</div>
</section>

</div>
</div>


<div class="row">

<div class="col-md-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Download the sample excel file</h2>
</header>
<div class="panel-body">

	<h4>Please read the below details before filling the excel file :</h4>
		<ul>
			<li>Please add the <b>category name</b> as shown below:(Choose the value that match your category)</li>
			<ul class="list-unstyled">
				<li>Shipping</li>
				<li>Sales</li>
				<li>General Expenses</li>
				<li>Salaries</li>
				<li>Raw Material Purchases</li>
				<li>Import Purchases</li>
				<li>Export Purchases</li>
				<li>Rent</li>
				<li>Others</li>
			</ul>
			<li>If you want to add any more details for the option selected as Others, please write it down in the "Extra Desc. For Category" field of excel. </li>
		</ul>

			<ul>
			<li>Please add the <b>bank name</b> as shown below:(Choose the value that match your category)</li>
			<ul class="list-unstyled">
				<li>ADIB-BBMS</li>
				<li>ADIB-Factory</li>
				<li>ENBD</li>
				<li>Cash Garhoud</li>
				<li>EI Bank</li>
				<li>Cash Mr. Bachir Book</li>
				<li>Cash Factory</li>
				<li>Other Bank</li>
			</ul>
			<li>If you want to add any more details for the option selected as Other Bank, please write it down in the "Extra Bank Desc" field of excel. </li>
		</ul>

		<ul>
			<li>Please add the <b>status name</b> as shown below:(Choose the value that match your category)</li>
			<ul class="list-unstyled">
				<li>Cash Deposit</li>
				<li>Cash</li>
				<li>PDC</li>
				<li>Bank Transfer</li>
				<li>Expected</li>
				<li>Others</li>
			</ul>
			<li>If you want to add any more details for the option selected as Others, please write it down in the "Extra Status Desc" field of excel. </li>
		</ul>
		<ul>
			<li>Add <b>the data for opening balace as <u>Opening Balances</u> in the Description field </b> </li>
		</ul>

		<ul>
			<li>Add <b>date</b> as <b> "month/date/year time AM/PM", example(2/14/2019 12:00 AM) </b> </li>
		</ul>
		<ul>
			<li>Add the <b>cash type</b> values must be either: Received or Spend. Choose from one, if its a green, then it means cash received, if it is a red, it means cash spend.</li>
		</ul>
		<ul>
			<li>Please enter numeric value only, in the <b>amount field</b>. No symbols like('-','+','.') etc..</li>
		</ul>
		<ul>
			<li>For each new excel file uploaded, please <b>give a new name as per the date for the excel sheet</b>. So that for any emergency it is easy to identify the exact excel sheet from the database.</li>
		</ul>

		<button type="button" class="btn btn-primary pull-left"><a href="<?php echo base_url('admin_assets/Final_excel.xlsx');?>" download="" style="color: white;">Click here to download the excel</a></button>
<div class="row">
	<div class="col-md-12">
			<button type="button" class="btn btn-primary pull-right"><a href="<?php echo base_url('admin_assets/Final_excel_7-8-2019.xlsx');?>" target="_new" style="color: white;">Click here to view a sample excel.</a></button>
			<p><b>NOTE: This is only a sample excel file. Just to view the data,Not for use.</b></p>
		</div>
	</div>	

</div>
</section>
</div>

</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>


</html>