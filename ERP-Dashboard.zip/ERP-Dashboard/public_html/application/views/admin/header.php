<header class="header">
<div class="logo-container">
<?php
if(isset($this->session->userdata['user']['main_dept']))
{
if($this->session->userdata['user']['main_dept']=='Sales')
{
?>
<a href="<?php echo base_url('marketing-dashboard');?>" class="logo">
<?php
}
elseif(($this->session->userdata['user']['main_dept']=='Main factory') || ($this->session->userdata['user']['main_dept']=='Traffic Sign'))
{
?>
<a href="<?php echo base_url('po-dashboard');?>" class="logo">
<?php
}
elseif($this->session->userdata['user']['main_dept']=='ksa-Sales')
{
?>
<a href="<?php echo base_url('sales-book-dashboard');?>" class="logo">
<?php
}
elseif($this->session->userdata['user']['main_dept']=='Purchase')
{
?>
<a href="<?php echo base_url('combined_db');?>" class="logo">
<?php
}
elseif( ($this->session->userdata['user']['main_dept']=='Project Department') || ($this->session->userdata['user']['main_dept']=='Factory Staff') )
{
?>
<a href="<?php echo base_url('survey-dashboard');?>" class="logo">
<?php
}
else
{
?>
<a href="<?php echo base_url('dashboard');?>" class="logo">
<?php
}
}
else
{
?>
<a href="<?php echo base_url('logout');?>" class="logo">
<?php
}?>
<img src="https://www.birigroup.com/temp_styles/assets/img/logo/Biri%20Group%20Logo-01.png" height="35" alt="Biri Admin" />
</a>
<div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
</div>
</div>

<div class="header-right">

<span class="separator"></span>
<ul class="notifications">

<li>
<select onchange="javascript:window.location.href='<?php echo base_url(); ?>LanguageSwitcher/switchLang/'+this.value;">
    <option value="english" selected="selected" <?php if( ($this->session->userdata('site_lang') == 'english') || empty($this->session->userdata('site_lang')) ) echo 'selected="selected"'; ?>>English</option>
    <option value="ar" <?php if($this->session->userdata('site_lang') == 'ar') echo 'selected="selected"'; ?>>Arabic</option>
  
</select>
</li>

<li>
	<?php
if($this->session->userdata['user']['role'] =='1')
{
$notification_details=$this->Admin_model->get_data('activities',array('act_notification_sts_mngmnt'=>'1'),'10','','act_id','DESC');
$get_all_notifiction_count=$this->Admin_model->get_data('activities',array('act_notification_sts_mngmnt'=>'1'));
}
else
{
$notification_details=$this->Admin_model->get_data('activities',array('act_notification_sts'=>'1','act_user'=>$this->session->userdata['user']['username'] ),'10','','act_id','DESC');
//echo $this->db->last_query();
$get_all_notifiction_count=$this->Admin_model->get_data('activities',array('act_notification_sts'=>'1','act_user'=>$this->session->userdata['user']['username']));
}

	?>
<a href="#" class="dropdown-toggle notification-icon" data-toggle="dropdown" aria-expanded="false">
<i class="fa fa-bell"></i>
<span class="badge"><?php 
if(!empty($get_all_notifiction_count))
echo count($get_all_notifiction_count);?></span>
</a>
<div class="dropdown-menu notification-menu">
<div class="notification-title">
<span class="pull-right label label-default"><?php 
if(!empty($get_all_notifiction_count))
echo count($get_all_notifiction_count);?></span>
Alerts
</div>
<div class="content">
	 <ul>
	 	<?php
		
		$title='';$msg_content='';$link_to_page='';
		if(!empty($notification_details))
		{
			
		foreach($notification_details as $n)
			{
				//print_r($n);
				if(!empty($n->act_po_id))
				{
//echo "in if";
					$title="Prduction Order - #".$n->act_po_id;
					$msg_content='<b style="color:black;">'.$n->act_function.'</b> ::<span><p style="color:black;">'.$n->act_status.'</p></span>';
					$link_to_page='list-production';
					$type='po';
					$type_id=$n->act_id;
				}
				elseif(!empty($n->act_quot_id))
				{
				//	echo "in else-if1";
					$q_data=$this->Admin_model->get_data("qoutattion_entry",array('q_id'=>$n->act_quot_id) );
					$title="Quotation - #".$q_data[0]->q_ref_no;
					$msg_content='<b style="color:black;">'.$n->act_function.'</b> ::<span><p style="color:black;">'.$n->act_status.'</p></span>';
					$link_to_page='list-quotation';
					$type='quotation';
					$type_id=$n->act_id;

				}
				elseif(!empty($n->act_item_req_id))
				{
				//	echo "in else-if12";
					$i_data=$this->Admin_model->get_data("item_request",array('ir_id'=>$n->act_item_req_id) );
					$title="Item Request - #".$i_data[0]->ir_req_no;
					$msg_content='<b style="color:black;">'.$n->act_function.'</b> ::<span><p style="color:black;">'.$n->act_status.'</p></span>';
					$link_to_page='list-item-request';
					$type='item_req';
					$type_id=$n->act_id;

				}
				elseif(!empty($n->act_survey_id))
				{
				//	echo "in else-if13";
					$s_data=$this->Admin_model->get_data("survey_table",array('st_id'=>$n->act_survey_id) );
					$title="Survey - #".$s_data[0]->st_survey_no;
					$msg_content='<b style="color:black;">'.$n->act_function.'</b> ::<span><p style="color:black;">'.$n->act_status.'</p></span>';
					$link_to_page='list-survey-data';
					$type='survey';
					$type_id=$n->act_id;

				}
				elseif(!empty($n->act_installation_id))
				{
				//	echo "in else-if14";
					$si_data=$this->db->query("select s.st_survey_no from survey_table as s join installation_details as i on s.st_id=i.insd_survey_id where i.insd_id='".$n->act_installation_id."' ");
					$data_result_set1=$si_data->result_array();

					$title="Installation survey - #".$data_result_set1[0]->st_survey_no;
					$msg_content='<b style="color:black;">'.$n->act_function.'</b> ::<span><p style="color:black;">'.$n->act_status.'</p></span>';
					$link_to_page='list-installations';
					$type='installation';
					$type_id=$n->act_id;
				}
				else
				{
				//	echo"in else";
				}
	 	?>
	 	<li>
	 	<?php 
		if(!empty($type)){?>
		<a onclick="get_notification_clicked('<?php echo $type;?>','<?php echo $type_id;?>');" style="cursor: pointer; " class="clearfix">
		<div class="image">
		<i class="fa fa-info bg-warning"></i>
		</div>
		<span class="title"><?php echo $title;?></span>
		<span class="message"><?php echo $msg_content;?></span>
		</a>
		</li>
		<?php
			}
		}
		}
		?>
	</ul>
<hr>
<!-- <div class="text-right">
<a href="<?php echo base_url('all-notifications');?>" class="view-more">View All</a>
</div> -->
</div>
</div>
</li>

</ul>

<span class="separator"></span>
<div id="userbox" class="userbox">
<a href="#" data-toggle="dropdown">
<figure class="profile-picture">
<img src="<?php echo base_url('admin_assets/');?>images/%21logged-user.jpg" alt="Joseph Doe" class="img-circle" data-lock-picture="assets/images/%21logged-user.jpg" />
</figure>
<div class="profile-info" data-lock-name="John Doe" data-lock-email="">
<span class="name"><?php echo $this->lang->line('text_title_header'); ?>, <?php echo $this ->session->userdata['user']['username'];?></span>
<span class="role"><?php if(($this ->session->userdata['user']['role'])=="1"){echo $this->lang->line('text_name_Admin');}else{echo $this->lang->line('text_name_staff');};?></span>
</div>
<i class="fa custom-caret"></i>
</a>
<div class="dropdown-menu">
<ul class="list-unstyled">
<li class="divider"></li>
<!-- <li>
<a role="menuitem" tabindex="-1" href="pages-user-profile.html"><i class="fa fa-user"></i> My Profile</a>
</li>
<li>
<a role="menuitem" tabindex="-1" href="#" data-lock-screen="true"><i class="fa fa-lock"></i> Lock Screen</a>
</li> -->
<li>
<a role="menuitem" tabindex="-1" href="<?php echo base_url('logout');?>"><i class="fa fa-power-off"></i> <?php echo $this->lang->line('logout'); ?></a>
</li>
</ul>
</div>
</div>
</div>

</header>

<script>
	//$('form').attr('autocomplete','on');

function get_notification_clicked(type,type_id)
{
 $.ajax({
              url:"<?php echo base_url().'Welcome/manage_notification';?>",
              data:{"nt_type":type,"nt_type_id":type_id},
              type: 'post',
              success:function(result)
              {
              	window.location.href = result;
             // console.log(result);
              }
     });
}

</script>