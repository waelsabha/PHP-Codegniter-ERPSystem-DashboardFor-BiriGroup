<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
  .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Study sold item last 12 month</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>product Sold during Year</span></li>
</ol>
<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
</div>
</header>

<div class="row">
<div class="col-md-12">
  <section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Filter Based on Warehouse</h2>





 


<div id="modalForm2" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Choose particular product</h2>
</header>
<div class="panel-body">


<div class="form-group mt-lg">
<label class="col-sm-3 control-label">WhareHouse Name <abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="term_name" class="form-control"  required />
</div>
</div>


<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Product  Name <abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="term_name_ar" class="form-control"  required />
</div>
</div>



</div>






</header>
<div class="panel-body">
  
  <div class="form-group">
    <label class="control-label" for="inputPlaceholder">Choose Warehouse (When You chose it will calculete the invoice and fill it in database)</label> 
    <select class="form-control" name="warehouse" >
      <option value="">Choose</option>
                <?php
                foreach($warehouse as $w)
                {
                  ?>
                  <option   value="<?php echo $w->mw_id;?>"><?php echo $w->mw_name;?></option>




                  <?php
                }
                ?>
            </select>
              
  


</section>
</div>











</div>
</section>
</div>
</div>






<!-----section for lightbox opens here-->
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">List product Sold during Year</h2>

</header>
<div class="panel-body">
  
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>

<!-- <th>Company</th> -->
<th>Invoice Doc</th>
<th>WhareHouse ID</th>
<th>Product ID </th>
<th>Qnty</th>
<th>Sale Date</th>
</tr>
</thead>
<tbody class="load_data">
<?php
if(!empty($result))
{
  $i=1;
foreach($result as $t)
{
  ?>
<tr>

    <td><?php echo $t['si_doc_no'];?></td>  
    <td><?php echo $t['si_warehouse'];?></td> 
    <td><?php echo $t['si_product'];?></td> 
  <td><?php echo $t['si_qnty'];?></td>  
  <td><?php echo $t['si_date'];?></td>  
  
</tr>

<!-- Button trigger modal 3-->
 
<!----end modal--->

<!-- Button trigger modal 3-->
 
<!----end modal--->

<?php
$i++;
}
}?>
</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->
<!-- Button trigger modal for sales invoice-->

<!----end modal--->
</section>
</div>

</section>

<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
<a href="#" class="mobile-close visible-xs">
Collapse <i class="fa fa-chevron-right"></i>
</a>
<div class="sidebar-right-wrapper">

<div class="sidebar-widget widget-friends ">

<div class="chat_window">
<?php $this->load->view('admin/master_essential/chat_data',$chat);?>

</div>
</div>
</div>
</div>
</div>
</aside>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
   $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );

    $('select[name="warehouse"]').on("change",function()
    {
      $('table .load_data').html();
     jQuery.ajax({
               url:"<?php echo base_url().'Study_stock/submit_wharehouse_stock';?>",
                data:{"warehouse_id":$(this).val()},
              type:"post",
               success:function(result)
              {
                 if(result)
                { 
                   $('table .load_data').html(result);
                   $('table .load_data').show();
                   
                }
                else
                {
                   $('table .load_data').hide();
                  
                }
              }
            });
 });
</script>

 

</body>
</html>