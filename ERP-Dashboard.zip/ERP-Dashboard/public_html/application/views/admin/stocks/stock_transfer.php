<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" 
type="text/css"/>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" 
type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
 table input.form-control {
  width: auto;
}

</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">
<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Stock </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Stock Transfer Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title"> Stock Transfer </h2>
</header>

<div class="panel-body">

 
 <?php echo form_open_multipart('Prd_stocks/submit_stock_transfer','class="myform" ','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
     <input type="hidden" name="form_type" value="stock_excess">
   <input type="hidden" name="added_ps_id" value="<?php if(!empty($result[0]->ps_id )){echo $result[0]->ps_id ;} ;?>">

    <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

<div class="row">
 <div class="col-md-12 col-sm-12 table-rows-border">
 
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Doc No <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type="text" name="stock_doc_no" value="<?php if(!empty($result[0]->ps_id)){echo $result[0]->ps_id ;}else{echo $doc_num;}?>" readonly class="form-control">
 <div class="form_error">  <?php echo $this->session->flashdata('stock_doc_no');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Date<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <?php
  if(!empty($result[0]->ps_date))
  $converted_date = date("m/d/Y", strtotime($result[0]->ps_date));
  ?>
 <input type='text' name="ps_date" class="form-control datetimepicker4" value="<?php if(!empty($result[0]->cbr_date)){echo $converted_date;}else{echo date('m/d/Y');} ;?>" required="required" disabled="disabled" />
 <input type="hidden" name="hid_date" value="">
  <div class="form_error">  <?php echo $this->session->flashdata('ps_date');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Company<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
 <select data-plugin-selectTwo  class="form-control populate" name="ps_company" required="required">
  <option value="">Choose</option>
 <?php
 foreach($company_masters as $cm)
 {?>
  <option value="<?php echo $cm->mcomp_id;?>" <?php if(!empty($result[0]->ps_company)){if($result[0]->ps_company==$cm->mcomp_id){echo "selected";}}elseif(!empty($pdr_result[0]->ps_company)){if($pdr_result[0]->ps_company==$cm->mcomp_id){echo "selected";}}else{};?>> <?php echo $cm->mcomp_name;?></option> 
  <?php
}?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('ps_company');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Narration
</label>
<div class="col-md-8">
 <input type='text' name="ps_narration" class="form-control" value="<?php if(!empty($result[0]->ps_narration)){echo $result[0]->ps_narration;}else{}  ;?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('ps_narration');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Warehouse Issue<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="ps_transfer_from" <?php if(!empty($it->ps_transfer_from)){echo 'readonly';};?> >
  <option value="">Choose</option>
<?php
foreach($warehouse_data as $wd)
{
  ?>
   <option value="<?php echo $wd->mw_id;?>" <?php if(!empty($result[0]->ps_transfer_from)){if($result[0]->ps_transfer_from==$wd->mw_id){echo "selected";}};?>> <?php echo strtolower($wd->mw_name);?> </option> 
  <?php
}
?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('ps_transfer_from');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Issue/Recpt
</label>
<div class="col-md-8">
 <input type='text' name="ps_issue_recpt" readonly=""  class="form-control" value="Issues"  />
  <div class="form_error">  <?php echo $this->session->flashdata('ps_issue_recpt');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Transfered to <abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
  <select data-plugin-selectTwo  class="form-control populate" name="ps_transfer_to" <?php if(!empty($result[0]->ps_transfer_to)){echo 'readonly';};?> >
  <option value="">Choose</option>
<?php
foreach($warehouse_data as $wd)
{
  ?>
   <option value="<?php echo $wd->mw_id;?>" <?php if(!empty($result[0]->ps_transfer_to)){if($result[0]->ps_transfer_to==$wd->mw_id){echo "selected";}};?>> <?php echo strtolower($wd->mw_name);?> </option> 
  <?php
}
?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('ps_transfer_to');?></div>
</div>
</div>
</div>

</div>



<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive">
<table class="table table-border table-rows-border">
  <thead>
     <th>Items</th>
      <th>Image</th>
       <th>Units</th>
        <th>Quantity</th>
         <th>Rate</th>
         <th>Gross</th>
  </thead>
  <tbody class="new_rows">
    <?php
   if(!empty($result[0]) )/////used in update value
   { 
       $ik=1;
      foreach($result_details as $ca_index=>$it)
      {
        if(!empty($it->psd_product))
        {
          $prd_data=$this->tm->get_data('products',array('pid'=>$it->psd_product));
          $units_data=$this->tm->get_data('prd_units',array('pu_pid_focus'=>$prd_data[0]->prod_id_focus));


        }
        ?>
 <tr>
       
<td>
 <select data-plugin-selectTwo  class="form-control populate product_<?php echo $ik;?>" name="psd_product[]" onchange="get_product_details(<?php echo $ik;?>)">
  <option value="">Choose</option>
<?php
$prd_image = '';
foreach($products_list as $prd)
{
  
  ?>
   <option value="<?php echo $prd->pid;?>"  <?php if(!empty($it->psd_product)){
                  if($it->psd_product==$prd->pid){
                                                                              if(empty($prd->p_prd_img))
                                                                                {
                                                                                  $filename="https://birigroup.com/uploads/prd_images/".$prd->pcode.'.jpeg';
                                                                                  if (file_exists($filename)) {
                                                                                    $prd_image=$filename;
                                                                                  } else {
                                                                                      $prd_image="https://birigroup.com/uploads/prd_images/".$prd->pcode.'.jpg';
                                                                                  }
                                                                                }
                                                                                else
		                                                                            {
                                                                                    $prd_image = explode(',',$prd->p_prd_img);
                                                                                    $prd_image = $prd_image[0];
                                                                                    if(!empty($prd_image))
                                                                                    {
                                                                                      $prd_image="https://birigroup.com/uploads/prd_images/".$prd_image;
                                                                                    }
                                                                                    else
		 	                                                                                $img_path="https://birigroup.com/uploads/prd_images/".$prd->p_prd_img;
                                                                                }
                    echo "selected";}};?>> <?php 
    echo str_replace('|~~|', ',', $prd->pname);?> ::<br/> <?php echo $prd->pcode;?> </option> 
  <?php
}
?>
 </select>
  <input type="hidden" name="stock_details_id[]" value="<?php echo $it->psd_id;?>">
        <input type="hidden" name="stock_details_ids" >
  </td>
<td><img src="<?php echo $prd_image; ?>" width="100" height="100" class="img-responsive img<?php echo $ik;?>"></td>
   <td>
     <select class="form-control populate product_unit_1" name="psd_unit[]" >
  <option value="">Choose</option>
  <?php
  if(!empty($units_data))
  {
    $units_more=explode('|##|',$units_data[0]->pu_units);
    ?>
    <option value="<?php echo $units_data[0]->pu_base_unit;?>" <?php if(!empty($it->psd_unit)){if($it->psd_unit==$units_data[0]->pu_base_unit){echo "selected";}};?>><?php echo $units_data[0]->pu_base_unit;?></option>
    <?php
    foreach($units_more as $um)
    {
    
    ?>
<option value="<?php echo $um;?>" <?php if(!empty($it->psd_unit)){if($it->psd_unit==$um){echo "selected";}};?>><?php echo $um;?></option>
    <?php
    }
  }
  else
  {
    ?>
    <option value="Default" <?php if(!empty($it->psd_unit)){if($it->psd_unit=='Default'){echo "selected";}};?>>Default</option>
    <?php
  }
?>
 </select>

  </td>
  <td><input type="number" name="psd_qnty[]" value="<?php if(!empty($it->psd_qnty)){echo $it->psd_qnty;};?>" step="any"  class="form-control qnty_<?php echo $ik;?>" onchange="check_qnty_transering('<?php echo $ik;?>');" 
    onblur="check_qnty_transering('<?php echo $ik;?>');"><br/><p>Current available stock : <span class="stock_data_<?php echo $ik;?>"> </span></p> </td>
    <td><input type="number" name="psd_rate[]" value="<?php if(!empty($it->psd_rate)){echo $it->psd_rate;};?>" step="any"  class="form-control rate_<?php echo $ik;?>" onchange="amount_total(<?php echo $ik;?>)" onblur="amount_total(<?php echo $ik;?>)"> </td>
    <td><input type="number" name="psd_gross[]" value="<?php if(!empty($it->psd_gross)){echo $it->psd_gross;};?>" step="any"  class="form-control gross_<?php echo $ik;?>"> </td>
    </tr>
        <?php
        $ik++;
      }

    }
    else//////mainly for adding new values
      {?>
    <tr>
    
<td>
   <select data-plugin-selectTwo  class="form-control populate product_1" name="psd_product[]" onchange="get_product_details('1')">
  <option value="">Choose</option>
<?php
foreach($products_list as $prd)
{
  ?>
   <option value="<?php echo $prd->pid;?>" > <?php
    echo str_replace('|~~|', ',', $prd->pname);?> ::<br/> <?php echo $prd->pcode;?> </option> 
  <?php
}
?>
 </select>
  </td>
   <td><img src="" width="100" height="100" class="img-responsive img1"></td>
  <td>
     <select class="form-control populate product_unit_1" name="psd_unit[]" >
  <option value="">Choose</option>
 </select>
  </td>
  <td><input type="number" name="psd_qnty[]" class="form-control qnty_1" onchange="check_qnty_transering('1');" 
    onblur="check_qnty_transering('1');" step="any"><br/><p>Current available stock : <span class="stock_data_1"> </span></p> </td>
    <td><input type="number" name="psd_rate[]" class="form-control rate_1"  step="any" onchange="amount_total(1)" onblur="amount_total(1)"> </td>
    <td><input type="number" name="psd_gross[]" class="form-control gross_1" step="any"> </td>
    </tr>
    <?php
  }?>
 <button type="button" class="btn btn-primary pull-right" onclick="add_more_row();">Add More</button>
  </tbody>
</table>
</div>

</div>

<div class="cell_text_data"></div>

<input type="hidden" name="hid_item" size="5">
<input type="hidden" name="hid_desc" size="5">
<input type="hidden" name="hid_unit" size="5">
<input type="hidden" name="hid_qnty" size="5">
<input type="hidden" name="hid_rate" size="5">
<input type="hidden" name="hid_gross" size="5">
<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
<div class="col-md-8">
  <span class="num_items">
    <?php
    if(!empty($result[0]))
    {
  if(!empty($total_count_rows))
  {
    echo $total_count_rows;
  }
     else
    {
      echo "1";
    }
  }
  elseif(!empty($pdr_result[0]))
    {
     if(!empty($total_count_rows))
      {
        echo $total_count_rows;
      }
       else
        {
          echo "1";
        }
    }
  else
  {
    echo "1";
  }
  ?>
  </span>
</div>
</div>
<!----------end col-md-12----------------------------->

<!-------start col-md-12------------------->

<!----------end col-md-12----------------------------->


<!-----div starts here for non-inquiry--->
<!----div end here for non-inquiry--->
</section>

<!-----div starts here for non-inquiry--->
 <!-- Button trigger modal for sales invoice-->

<!----end modal--->
<!----div closes here--->

<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Save</button>
<button type="reset" class="btn btn-default" onclick="check_for_reset()">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>


</section>
</div>
</section>



<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
<a href="#" class="mobile-close visible-xs">
Collapse <i class="fa fa-chevron-right"></i>
</a>
<div class="sidebar-right-wrapper">

<div class="sidebar-widget widget-friends ">

<div class="chat_window">
<?php $this->load->view('admin/master_essential/chat_data',$chat);?>

</div>
</div>



</div>
</div>
</div>
</aside>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
 <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript"></script>

  <script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script>
            $(document).on('ready', function () {
                $(document).on("keyup", ".amount", calculate_amount_total);
                $("#file-1").fileinput();
                });

               $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
     } );
} );
                  </script>
                  
        <script>
      $(document).ready(function()
{    
             /////for file upload////
  $("#file-1").fileinput({
      // 'theme': 'fas',
     //        'showPreview': true,
     //         'showUpload': false,
     //      'showRemove':true,
     //        'maxFileSize': 5000,
     //    'maxFilesNum': 10,
     //        'allowedFileExtensions': ['jpg', 'png', 'gif'],

        theme: 'fas',
         showUpload: false,
          showCancel: true,
        overwriteInitial: false,
        maxFileSize: 3000,////max file size  is 2000 kb,else will show error
        maxFilesNum: 10,


        // "success":true,
        //allowedFileTypes: ['image', 'video', 'flash'],
       
    });
 
     $(".file").on('fileselect', function(event, n, l) {
     alert('File Selected. Name: ' + l + ', Num: ' + n);
     });
     
      });
   </script>
   
 <script>
    tinymce.init({
      selector : '.editors',
        plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
    });
   </script>
   
<script type="text/javascript">
 function add_more_row()
{
var tablecount = $('table tbody tr').length;
  if(tablecount=="0")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }

   var markup='<tr class="table'+table_id+'">'+
 ' <td class="select_item_list_'+table_id+'">';
    jQuery.ajax({
                     url:"<?php echo base_url().'Prd_stocks/get_details_prd';?>",
                       data:{"table_id":table_id},
                    type:"post",
                    success:function(result)
                    {
                      if(result)
                      {
           $('.select_item_list_'+table_id).html(result);
        $('select[name="psd_product[]"]').select2();   
                       }
                    }
                 });  
  markup+= '</td>'+
   
       '<td><img src="" width="100" height="100" class="img-responsive img'+table_id+'"></td>'+
 ' <td> <select class="form-control populate product_unit_'+table_id+'" name="psd_unit[]" >'+
  '<option value="">Choose</option></select></td>'+
   
   '<td><input type="number" name="psd_qnty[]" class="form-control qnty_'+table_id+'"  onchange="check_qnty_transering('+table_id+');" onblur="check_qnty_transering('+table_id+');"  step="any"><br/><p>Current available stock : <span class="stock_data_'+table_id+'"> </span></p> </td>'+
    '<td><input type="number" name="psd_rate[]" class="form-control rate_'+table_id+'" step="any" onchange="amount_total('+table_id+');" onblur="amount_total('+table_id+');"> </td>'+
   ' <td><input type="number" name="psd_gross[]" class="form-control gross_'+table_id+'" step="any"> </td>'+
     ' <td><button type="button" class="btn btn-danger" style="cursor: pointer" onclick=table('+table_id+')>X</button></td>'
      '</tr>';
      $(".new_rows").append(markup);
      var rowcount = $('table tbody tr').length;
     $(".num_items").html(table_id);
}

  function table(id)
  {
    $('table tbody .table'+id).remove();
    var rowcount = $('table tbody tr').length;
    $(".num_items").html(rowcount);
  }

  function salesman_selected_id(table_id=null)
  {
    if(table_id!='')
    {
    var sales_man_selected= $('select[name="cbr_salesman[]"]').find('option:selected').val();
     //var sales_man_selected= $('.salesman_'+table_id).find('option:selected').val();
// var sales_man_selected= $('.salesman_'+table_id).val();
    //var sales_man_selected= $('table tbody tr td .salesman_'+table_id+' option:selected').map(function(){return $(this).val();}).get().join('|#|');
      console.log(sales_man_selected);
    }
  }

  function amount_total(table_id)
{
  var amountss='0';
  var qntys=$('.qnty_'+table_id).val();
  var rates=$('.rate_'+table_id).val();
  $(".gross_"+table_id).val(parseFloat(qntys)*parseFloat(rates));
}

function calculate_amount_total()
{
  var amountss='0';
  $('table tbody tr td input[name="psd_gross[]"]').each(function(){
  amountss= parseFloat(amountss)+parseFloat($(this).val());
  }); 
  $('.amount_tot_button').val(parseFloat(amountss));
}

function get_product_details(table_id)
{
    var prd_selected=$('.product_'+table_id).find('option:selected').val();
 var warehouse_to=$("select[name='ps_transfer_to']").find('option:selected').val();
 var warehouse_from=$("select[name='ps_transfer_from']").find('option:selected').val();

    jQuery.ajax({
               url:"<?php echo base_url().'Prd_stocks/get_product_extras';?>",
                data:{"prd_id":prd_selected,"table_id":table_id},
              type:"post",
               success:function(result)
              {
                 if(result)
                {
                 // console.log(result);
                  $('.product_unit_'+table_id).html(result);

                }
              }
            });

      jQuery.ajax({
               url:"<?php echo base_url().'Prd_stocks/get_product_quantity';?>",
                data:{"prd_id":prd_selected,"warehouse_to":warehouse_to,"warehouse_from":warehouse_from},
              type:"post",
               success:function(result)
              {
                 if(result)
                {
                  $('.stock_data_'+table_id).html(result);
                }
              }
            });

       jQuery.ajax({
               url:"<?php echo base_url().'Sales_invoice/get_product_details';?>",
                data:{"prd_id":prd_selected},
              type:"post",
               success:function(result)
              {
                 if(result)
                {
                  var returndata = JSON.parse(result);
                 $('.img'+table_id).attr('src',returndata['pimage']);
               // $('.rate'+table_id).val(returndata['prd_price']);
                }
              }
            });
}

function check_qnty_transering(table_id)
{
 var prd_details=$('.product_'+table_id).find('option:selected').val();

var quantity_added=$('.qnty_'+table_id).val();
 var current_stock_data=$('.stock_data_'+table_id).html();

 if(parseFloat(quantity_added)>parseFloat(current_stock_data))
 {
  alert('Quantity Error: Entered quantity is more than what`s in stock or Not Exsit in your warehouse.Please re-eneter quantity');
 }


}
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').
                datepicker({startDate: new Date() });
            });
            $( function() {
    $('#datetimepicker55' ).datepicker({ 
       startDate: '-20d', // controll start date like startDate: '-2m' m: means Month
  endDate: new Date()
     // minDate: -20, maxDate: new Date()
       });
  } );
$(document).on('ready', function () 
{
$('input').attr('autocomplete','off'); 

  $('select[name="cbr_currency"]').on('change',function(){
    
     jQuery.ajax({
               url:"<?php echo base_url().'Receipt_Master/get_currency_conv_val';?>",
                data:{"currecny_selected":$(this).val()},
              type:"post",
               success:function(result)
              {
                if(result)
                {
                $("input[name='cbr_rate_currency']").val(result);
                }
              }
               }); 
  });

  $('.menu_name_fun').on('click',function(){
          if (confirm("Are you sure, You want to exit this page?")) {
                  location.href = $(this).attr('href');
            } 
            else {
              return false;
            }
          });

}); 

</script>
<!-- <script type="text/javascript" src="<?php echo base_url('modal_inv_js.js');?>"></script> -->
<script type="text/javascript">

function check_for_reset()
{
  if (confirm("Are you sure, You want to reset this form?")) {
                 $('.myform').trigger("reset");
            } 
            else {
              return false;
            }
}

$('.myform').submit(function() {
 //e.preventDefault();
var rowcount = $('.new_rows tr').length; 
var prd_ids=
$('table tbody tr td select[name="psd_product[]"]').map(function(){return $(this).find('option:selected').val();}).get().join('|#|');
var unit_ids=$('table tbody tr td select[name="psd_unit[]"]').map(function(){return $(this).find('option:selected').val();}).get().join('|#|');
var qnty_s=$('table tbody tr td input[name="psd_qnty[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
 var rates_s=$('table tbody tr td input[name="psd_rate[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
 var gross=$('table tbody tr td input[name="psd_gross[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
 var stock_details_id=$('table tbody tr td input[name="stock_details_id[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
  var desc=$('table tbody tr td input[name="psd_desc[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
//console.log(warehouse_ids);console.log(stock_details_id);
//console.log(quantity+' '+package_size+' '+product_id);

//console.log(prd_ids);

$("input[name='hid_item']").val(prd_ids);
$("input[name='hid_unit']").val(unit_ids);
$("input[name='hid_qnty']").val(qnty_s);
$("input[name='hid_rate']").val(rates_s);
$("input[name='hid_gross']").val(gross);
$("input[name='hid_desc']").val(desc);
$("input[name='stock_details_ids']").val(stock_details_id);

$("input[name='hid_date']").val($("input[name='ps_date']").val());
//console.log($("input[name='ps_date']").val());
var ij=0;
var data_var=[];

$('.new_rows tr td').each(function() { 
var cellText = $(this).html(); 
 //  console.log(cellText);  
    $('.cell_text_data').append(cellText).hide(); 
});

 if ($('.new_rows tr').length == 0) 
 {
  alert('Please choose items to add and submit');
  return false;
 }
 else
 {
  return true;
 }
 //return false;
  // your code here
});
        </script>

</body>

</html>