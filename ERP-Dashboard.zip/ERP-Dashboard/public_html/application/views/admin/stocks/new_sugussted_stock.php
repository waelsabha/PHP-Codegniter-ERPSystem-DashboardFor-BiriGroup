<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
  .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Checking Product Stock</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>

<li><span>product suggest</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-md-12">
  <section class="panel">
<header class="panel-heading">
<?php echo form_open('suggested_stock_qnty');?>
<h2 class="panel-title">Choose Whare Hose</h2>
</header>
<div class="panel-body">
  <div class="form-group">
    <label class="control-label" for="inputPlaceholder">Choose Department</label>


 <select data-plugin-selectTwo class='form-control populate ' name='wharehouse_id' required="">
<option value="">choose</option>
<?php
    foreach($warehouse as $wh)
      {
        //$prd_name=explode('|~~|',$sc->pname);
        ?>
    <option value="<?php echo $wh->mw_id;?>" ><?php echo $wh->mw_name;?></option>
    <?php
  }?>

 </select>

 
  <br/>


  


 <select data-plugin-selectTwo class='form-control populate search_product_select' name='product_id'>
<option></option>
<?php
    foreach($products_list as $pl)
      {
        //$prd_name=explode('|~~|',$sc->pname);
        ?>
    <option value="<?php echo $pl->pid;?>" ><?php echo $pl->pname;?></option>
    <?php
  }?>

 </select>


   </div>




<br/>

  <button type="button" class="btn btn-primary" onclick="check_suggested();">Submit</button>
</div>



  



<?php echo form_close();?>

</section>
</div>
<!-- <div class="col-md-6">
  <section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Filter Based on </h2>
</header>
<div class="panel-body">

  
</div>
</section>
</div> -->

</div>



<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">the suggusted product</h2>

</header>
<div class="panel-body">
  
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result table-responsive">

</div>


</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
  
 function check_suggested()
  {
   var whid=$('select[name=wharehouse_id]').val();
   var pdid=$('select[name=product_id]').val();
   
     if(whid==''||pdid=='')
     {
      alert('Please choose wharehouse and product');
     }
      else{
        jQuery.ajax({
                  url:"<?php echo base_url().'Study_stock/suggested_stock_qnty';?>",
                  type:"post",
                  data:{"wh_id":whid,"pd_id":pdid},
                  success:function(result)
                  {
                    
                     $('.data_result').html(result);
                     $('#datatable-default2').DataTable({ 
                          "destroy": true, //use for reinitialize datatable
                        });    
                  // $('.hse_code_val').html(result);
                  }
              });
    }

  }

  
  
</script>

</body>
</html>