<!doctype html>
<html class="fixed">

<head>

<?php
$html='Current Stock report for ';
if(!empty($result)){

  if  (!empty($warehouse_name[1])){
  $html.='for all Stock Qouantitiy';

  }
  else{
    $html.=$warehouse_name[0]->mw_name;

  }
  
  }

  $header_data['data']=$html;

  if(!empty($header_data))
    $this->load->view('admin/head',$header_data);
  else
    $this->load->view('admin/head');
?>


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
  .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Current Stock </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Current Stock</span></li>
</ol>
<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
</div>
</header>

<div class="row">
<div class="col-md-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Choose Data </h2>

</header>
<div class="panel-body">
  <?php echo form_open_multipart('Prd_stocks/get_current_stock_warehouse','class="form-horizontal form-bordered ledger_form_class"');?>
    <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
  <div class="row">
  <div class="col-sm-12 table-rows-border" align="center">
      <div class="form-group">
    <label class="col-md-4 control-label" for="inputPlaceholder">Choose Warehouse<abbr class="required">::*::</abbr>

    </label>
    <div class="col-md-8">
     <select data-plugin-selectTwo  class="form-control populate" name="warehouse_id">
       <option value="">Choose</option>
      <?php
     foreach($warehouse as $w)
      {                                      
        ?>
        <option value="<?php echo $w->mw_id;?>" <?php if(!empty($form_input)){if($form_input['warehouse_id']==$w->mw_id){echo "selected";}else{}};?>><?php echo $w->mw_name;?></option>
      <?php
      }?>
    </select>
     
    </div>
    </div>
  </div>
</div>






<div class="row" style="margin-top: 2%;">
<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
</div>
<?php echo form_close();?>
</div>
  </section>
</div>
</div>
<!-----section for lightbox opens here-->
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">List Current Stock of :  <?php echo $warehouse_name[0]->mw_name ;?></h2>

</header>
<div class="panel-body">
  
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>

<!-- <th>Company</th> -->

<th>Image</th>
<th>Product Name</th>
<th>Code </th>
<th>Category </th>
<th>Total Stock</th>

<th>Suggusted Stock (3months)</th>
</tr>
</thead>
<tbody class="load_data">
<?php
if(!empty($result))
{
  $i=1;
foreach($result as $t)
{

$image=$t['p_prd_img'];
if(!empty($image) )
{
  $path = "https://birigroup.com/uploads/prd_images/".$image;//this is the image path
  

}
else{
  $path = "https://birigroup.com/uploads/prd_images/no_image.jpg";//this is the image path



} 

$type = pathinfo($path, PATHINFO_EXTENSION);
  $data = file_get_contents($path);
  $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

  ?>
<tr>
 
  <td >
    <img class="img-fluid" src="<?php echo $base64;  ?>" style="max-height:100px;"></td>
     
   
    <td><?php echo $t['pname'];?></td>    
  <td><?php echo $t['pcode'];?></td>  
   <td><?php echo $t['pcat'];?></td>
  <td><?php echo $t['tot_qnty'];?></td> 

  <td><?php echo $t['sd_suggested_qnty'];?></td> 
</tr>

<!-- Button trigger modal 3-->
 
<!----end modal--->

<!-- Button trigger modal 3-->
 
<!----end modal--->

<?php
$i++;
}
}?>
</tbody>
</table>
</div>
</div>
</section>
<!-----section for lighbox closes here--->
<!-- Button trigger modal for sales invoice-->

<!----end modal--->
</section>
</div>

</section>


<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
<a href="#" class="mobile-close visible-xs">
Collapse <i class="fa fa-chevron-right"></i>
</a>
<div class="sidebar-right-wrapper">

<div class="sidebar-widget widget-friends ">

<div class="chat_window">
<?php $this->load->view('admin/master_essential/chat_data',$chat);?>

</div>
</div>
</div>
</div>
</div>
</aside>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>

<script type="text/javascript">
   $(document).ready(function()
    {      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
     dom: 'Bfrtip',
        buttons: [
           {
            extend: 'csvHtml5',
            text: 'CSV',
          
        },
        {
            extend: 'excelHtml5',
            text: 'Excel',
          
        },
           { 
             extend: 'pdfHtml5',
             text: 'PDF',

             
  customize: function ( doc ) {
   if (doc) {


               


                   var arr2 = $('.img-fluid').map(function(){
                      return this.src;
                 }).get();



               for (var i = 0, c = 1; i < arr2.length; i++, c++) {
                  doc.content[1].table.body[c][0] = {
                       image: arr2[i], 
                       width: 100,
                   };
               }




           }
       },

             
                  footer: true 
           }
        ],
        "pageLength":300,
    responsive: true,
     "scrollX": true,
     
     } );
} );

    $('select[name="warehouse"]').on("change",function()
    {
      $('table .load_data').html();
     jQuery.ajax({
               url:"<?php echo base_url().'Prd_stocks/get_current_stock_warehouse';?>",
                data:{"warehouse_id":$(this).val()},
              type:"post",
               success:function(result)
              {
                 if(result)
                {
                   $('table .load_data').html(result);
                   $('table .load_data').show();
                }
                else
                {
                   $('table .load_data').hide();
                }
              }
            });
 });
</script>

 

</body>
</html>