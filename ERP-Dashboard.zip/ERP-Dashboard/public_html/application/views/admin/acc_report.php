<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2> Account report</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Reports</span></li>
<li><span>Account reports</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="modal fade modal-header-color modal-block-info" id="modalLG" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="overflow: visible;">

			<section class="panel">
			<header class="panel-heading">
			<h2 class="panel-title">Details of Account Entry with id : <span id="id_modal"></span></h2>
			</header>
			<div class="panel-body modal-body">
			<div class="modal-wrapper">
			<div class="modal-text">

			<p><b>Category : </b><span id="category"></span></p>
			<p><b>Details of "Others" in Category : </b><span id="othr_cat"></span></p>

			<p><b>Status : </b><span id="status"></span></p>
			<p><b>Details of "Others" in Status : </b><span id="othr_sts"></span></p>

			<p><b>Bank : </b> <span id="bank"></span></p>
			<p><b>Details of "Others" in Bank : </b><span id="othr_bnk"></span></p>

			<p><b>Amount : </b><span id="amount"></span></p>
			<p><b>Cash Type : </b><span id="cash_type"></span></p>

			<p><b>Current entry status :</b> <span id="entry_sts"></span>
			</p>

			<p><b>Date : </b><span id="date"></span></p>

			<p><b>Description : </b><span id="desc"></span></p>

			</div>
			</div>
			<button class="btn btn-default modal-dismiss" id="closemodal">Close</button>
			</div>
			
			</section>
</div>

<div id="modalSM" class="modal-block modal-block-sm mfp-hide">
	<section class="panel">
	<header class="panel-heading">
	<h2 class="panel-title">Change Status</h2>
	</header>
	<div class="panel-body">
	<div class="modal-wrapper">
	<div class="modal-text">

	<div class="col-md-12">
	<button class="btn btn-primary modal-confirm" onclick="approve_sts()">Approve Now</button>
	<button class="btn btn-default modal-dismiss">Cancel</button>
	</div>

	</div>
	</div>
	</div>
	
	</section>
</div>

<div class="row">
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Report Based on cash type only</h2>
</header>
<div class="panel-body">
	<div class="form-group">
		<label class="col-md-3 control-label" for="inputPlaceholder">Cash type</label>

		<div class="col-md-6">
		<label class="radio-inline">
		<input type="radio" value="Received" name="cash_type"> We Received
		</label>
		<label class="checkbox-inline">
		<input type="radio" value="Spend" name="cash_type"> We Spend
		</label>
		<div class="form_error">  <?php echo $this->session->flashdata('cash_type');?></div>
		</div>

	</div>
</div>
</section>
</div>

<div class="col-md-6">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Report Based on bank type only</h2>
</header>
<div class="panel-body">
		<div class="form-group">
<label class="col-md-3 control-label" for="inputPlaceholder">Choose Bank</label>
<div class="col-md-6">
	<select class="form-control mb-md bank" name="bank" >
		<option value="">Choose</option>
		<option value="ADIB-BBMS">ADIB-BBMS</option>
		<option value="ADIB-Factory">ADIB-Factory</option>
		<option value="ENBD">ENBD</option>
		<option value="Cash Garhoud">Cash Garhoud</option>
		<option value="EI Bank">EI Bank</option>
		<option value="Cash Mr. Bachir Book">Cash Mr. Bachir Book</option>
		<option value="Cash Factory">Cash Factory</option>
		<option value="Other Bank">Other Bank</option>
	</select>
<div class="form_error">  <?php echo $this->session->flashdata('bank');?></div>
</div>
</div>
</div>
</section>
</div>

</div>
<div class="row">
<!-- <div class="col-md-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Report Based on cash type and bank</h2>
</header>
<div class="panel-body">
<div class="col-md-6">
	<div class="form-group">
		<label class="col-md-3 control-label" for="inputPlaceholder">Cash type</label>

		<div class="col-md-6">
		<label class="radio-inline">
		<input type="radio" value="Received" name="cash_type"> We Received
		</label>
		<label class="checkbox-inline">
		<input type="radio" value="Spend" name="cash_type"> We Spend
		</label>
		<div class="form_error">  <?php echo $this->session->flashdata('cash_type');?></div>
		</div>

	</div>
</div>
<div class="col-md-6">
	<div class="form-group">
<label class="col-md-3 control-label" for="inputPlaceholder">Choose Bank</label>
<div class="col-md-6">
	<select class="form-control mb-md bank" name="bank" >
		<option value="">Choose</option>
		<option value="ADIB-BBMS">ADIB-BBMS</option>
		<option value="ADIB-Factory">ADIB-Factory</option>
		<option value="ENBD">ENBD</option>
		<option value="Cash Garhoud">Cash Garhoud</option>
		<option value="EI Bank">EI Bank</option>
		<option value="Cash Mr. Bachir Book">Cash Mr. Bachir Book</option>
		<option value="Cash Factory">Cash Factory</option>
		<option value="Other Bank">Other Bank</option>
	</select>
<div class="form_error"><?php echo $this->session->flashdata('bank');?></div>
</div>
</div>
</div>
<button type="button" class="btn btn-primary"  onclick="type_bank();">Submit</button>	
</div>
</section>
</div> -->

<div class="col-md-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Report Based on month and year</h2>
</header>
<div class="panel-body">
	<div class="col-md-6">
		<div class="form-group">
			<label class="col-md-3 control-label" for="inputPlaceholder">Choose Month</label>
			<div class="col-md-6">
				<select class="form-control mb-md bank month_name" name="month" >
					<option value="">Choose</option>
					<option value="01">Jan</option>
					<option value="02">Feb</option>
					<option value="03">Mar</option>
					<option value="04">Apr</option>
					<option value="05">May</option>
					<option value="06">Jun</option>
					<option value="07">Jul</option>
					<option value="08">Aug</option>
					<option value="09">Sep</option>
					<option value="10">Oct</option>
					<option value="11">Nov</option>
					<option value="12">Dec</option>
				</select>
			<div class="form_error">  <?php echo $this->session->flashdata('bank');?></div>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="form-group">
			<label class="col-md-3 control-label" for="inputPlaceholder">Choose Year</label>
			<div class="col-md-6">
				<select id="year" name="year_selected" class="form-control year_selected">
				
			</select>
			<div class="form_error">  <?php echo $this->session->flashdata('bank');?></div>
			</div>
		</div>
	</div>
	<button type="button" class="btn btn-primary"  onclick="month_yr();">Submit</button>
</div>
</section>
</div>



<div class="col-md-12">
	<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Report Based on date range</h2>
</header>
<div class="panel-body">
	<div class="form-group">
		<label class="col-md-3 control-label" for="inputPlaceholder">Date Range</label>

		<div class="col-md-6">
			<div class="input-daterange input-group" data-plugin-datepicker="">
			    <span class="input-group-addon">
			    <i class="fa fa-calendar"></i>
			    </span>
			    <input type="text" class="form-control" name="start_date_rng">
			    <span class="input-group-addon">to</span>
			    <input type="text" class="form-control" name="end_date_rng">
			</div>
		<div class="form_error">  <?php echo $this->session->flashdata('cash_type');?></div>
		</div>

	</div>
	<button type="button" class="btn btn-primary"  onclick="this_range();">Submit</button>
</div>
</section>
</div>

</div>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Table Data</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>



 <div class="row table-responsive" id="acc_rpt_data"></div>





</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>/javascripts/ui-elements/examples.notifications.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function()
	{
		$('input:radio').change(function() {
			var cash_type = $("input[name='cash_type']:checked").val();
			  jQuery.ajax({
		            url:"<?php echo base_url().'Admin_biri/cash_type_selected';?>",
		            type:"post",
		            data:{"cash_type":cash_type},
		            success:function(result)
		            {
		            	$('#acc_rpt_data').html(result);
		            	$('#datatable-default').DataTable({ 
                      	"destroy": true, //use for reinitialize datatable
                  		});		            	
		            }
		        });
    		
  		});

  		$('select').on('change', function() {
  			if(this.value!="")
  			{
  				bank_type=this.value;
  				 jQuery.ajax({
		            url:"<?php echo base_url().'Admin_biri/cash_type_selected';?>",
		            type:"post",
		            data:{"bank_type":bank_type},
		            success:function(result)
		            {
		            	$('#acc_rpt_data').html(result);	
		            	$('#datatable-default').DataTable({ 
                      	"destroy": true, //use for reinitialize datatable
                  		});		            	
		            }
		        });
  				
  			}
		   
		});

		$('#closemodal').click(function() {
		    $('#modalLG').modal('hide');
		});

	
	});

		function view_modal(id)
		{
			$('#modalLG').modal('toggle');
			$("#modalLG").removeClass("mfp-hide");

			//$(".modal-body").show();
			// $("#modalLG").addClass("modal-block modal-block-lg modal-header-color modal-block-info");
			
			 jQuery.ajax({
		            url:"<?php echo base_url().'Admin_biri/modal_data';?>",
		            type:"post",
		            data:{"table_id":id},
		            success:function(result)
		            {
		            		//console.log(result);
		            	var returnedData = JSON.parse(result);
		            
		            	$('#category').html(returnedData.cat);
                        $('#othr_cat').html(returnedData.cat_desc);
                        $('#status').html(returnedData.sts);
                        $('#othr_sts').html(returnedData.sts_desc);
                        $('#bank').html(returnedData.bank);
                        $('#othr_bnk').html(returnedData.bank_desc);
                        $('#cash_type').html(returnedData.cash_type);
                        $('#date').html(returnedData.date);
                        $('#desc').html(returnedData.desc);
                        $('#amount').html(returnedData.amount);
                        $('#id_modal').html(returnedData.id);
                        $('#entry_sts').html(returnedData.show_data);
                        
		            }
		        });
		}

		function change_status(id)
		{
			 jQuery.ajax({
		            url:"<?php echo base_url().'Admin_biri/approve_entry';?>",
		            type:"post",
		            data:{"table_id":id},
		            success:function(result)
		            {
		            	if(result=='1')
		            	{
		            		new PNotify({
									title: 'Success',
									text: 'Status Changed successfully',
									type: 'success'
								});

		            		$('.status_entry_'+id).html(
		            			'<span class="pull-right label label-success">Success</span>'
		            			);
		            	}

		            }
		            });

		}


</script>
<script type="text/javascript">
$(document).ready(function()
	{
	
	  		var currentYear = new Date().getFullYear()
		    var option = "";
		    for (var year = currentYear-20 ; year <= currentYear; year++) 
		    {
      
	        var option = document.createElement("option");
	        option.text = year;
	        option.value = year;
        
	        document.getElementById("year").appendChild(option)
	        
		    }
		    document.getElementById("year").value = currentYear;

	});
function this_range()
    {
        var start_date=$('input[name=start_date_rng]').val();
        var end_date=$('input[name=end_date_rng]').val();

          jQuery.ajax({
                     url:"<?php echo base_url().'Accounts_controller/this_range_date';?>",
                    type:"post",
                    data:{"start_date_selected":start_date,"end_date_selected":end_date},
                    success:function(result)
                    {
                    	$('#acc_rpt_data').html(result);
		            	$('#datatable-default').DataTable({ 
                      	"destroy": true, //use for reinitialize datatable
                  		});		            	
                    }
                });
    }

    function month_yr()
    {
    	 var month_selected=$('select[name=month]').val();
    	 var year_selected=$('select[name=year_selected]').val();
    	
    	  jQuery.ajax({
                     url:"<?php echo base_url().'Accounts_controller/month_yr';?>",
                    type:"post",
                    data:{"month_selected":month_selected,"year_selected":year_selected},
                    success:function(result)
                    {
                    	$('#acc_rpt_data').html(result);
		            	$('#datatable-default').DataTable({ 
                      	"destroy": true, //use for reinitialize datatable
                  		});		  
                    }
                });
    }

    function type_bank()
    {
    	 var type_selected=$('input[name=cash_type]:checked').val();
    	 var bank_selected=$('select[name=bank]').val();

    	  jQuery.ajax({
                     url:"<?php echo base_url().'Accounts_controller/type_bank';?>",
                    type:"post",
                    data:{"type_selected":type_selected,
                    "bank_selected":bank_selected},
                    success:function(result)
                    {
                    	$('#acc_rpt_data').html(result);
		            	$('#datatable-default').DataTable({ 
                      	"destroy": true, //use for reinitialize datatable
                  		});		  
                    }
                });
    }

</script>
</body>
</html>