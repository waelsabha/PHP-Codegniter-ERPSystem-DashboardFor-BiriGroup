<section class="panel">
<header class="panel-heading">

<h2 class="panel-title"><?php echo $this->lang->line('Approved'); ?></h2>
<p class="panel-subtitle">All Approved pictures</p>
</header>
<div class="panel-body">

<div class="data_result">

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default3">
thead>
<tr>
  <th ></th>
<th>Recipt Name</th>
<th>Recipt Name Arabic</th>

<th>Branch where wrork</th>
<th>Position Name </th>
<th>Working Hours</th>
<th>Total Salary</th>
<th>probation_period</th>


<th><?php echo $this->lang->line('Action'); ?></th>

</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($approved_offer_list))
{
  foreach($approved_offer_list as $indexap=>$rtap)
  {
       

?>
<tr class="gradeX">
      <td width='2%'><?php echo $i++;?></td>
      <td><?php echo $rtap->jo_recipt_name;?></td>
      <td><?php echo $rtap->jo_recipt_name_ar;?></td>
      <td><?php echo $rtap->mcomp_name;?></td>
      <td><?php echo $rtap->position_name;?></td>
      <td><?php echo $rtap->jo_working_hours;?></td>
      <td><?php echo $rtap->jo_total_salary;?></td>
      <td><?php echo $rtap->probation_period;?></td>
         <td>

       Approved <br/>
      
      
     <?php
     }
  }

  
  else{
    echo('Error Result');
  }
 ?>

 



</td>



  </tr>
</tbody>
</table>
</div>


</div>
</section>