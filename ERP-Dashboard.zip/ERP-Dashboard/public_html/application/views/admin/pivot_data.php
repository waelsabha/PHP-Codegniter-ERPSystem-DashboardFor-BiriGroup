<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Pivot Table( from <?php echo date("Y-m-d", strtotime("-7 days"));?> ) 
</h2>

<?php 

$result_test=array();
$new_bal_amount1='';$new_bal_amount2='';$new_bal_amount3='';$new_bal_amount4='';$new_bal_amount5='';$new_bal_amount6='';
	$new_bal_amount7='';$new_bal_amount8='';

	$total_balance='';
	$bal1='';$bal2='';$bal3='';$bal4='';$bal5='';$bal6='';$bal7='';$bal8='';

	$rx_bnk1=array();$rx_bnk2=array();$rx_bnk3=array();$rx_bnk4=array();$rx_bnk5=array();$rx_bnk6=array();$rx_bnk7=array();$rx_bnk8=array();

	

$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
// $date = date('Y-m-d h:i:s a', time());
$current_time=$dt->format('H:i:s');
$current_date=$dt->format('Y-m-d');
//print_r($current_time);


$banks_array=array('ADIB-BBMS','ADIB-Factory','ENBD','EI Bank','Cash Mr. Bachir Book','Cash Garhoud','Cash Factory','Other Bank');
foreach($cash_entire as $element)
{
	if($element->ae_bank==$banks_array[0])
	{
		if($element->ae_date >= $current_date)
		{

			if($new_bal_amount1=='')
			{
				if($element->ae_cash_type=="Spend")
				{
					if($current_time >= '8:0:0')
					{
				$new_bal_amount1=$result_bal_date[0]-$element->ae_amount;
					}
				}
				else
				{
					if($current_time >= '18:0:0')
					{
					$new_bal_amount1=$result_bal_date[0]+$element->ae_amount;
					}
				}
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				{
					if($current_time >= '8:0:0')
					{
				$new_bal_amount1=$new_bal_amount1-$element->ae_amount;
					}
				}
				else
				{
					if($current_time >= '18:0:0')
					{
				$new_bal_amount1=$new_bal_amount1+$element->ae_amount;
					}
				}
			}
		}
		else
		{
			if($new_bal_amount1=='')
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount1=$result_bal_date[0]-$element->ae_amount;
				else
				$new_bal_amount1=$result_bal_date[0]+$element->ae_amount;
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount1=$new_bal_amount1-$element->ae_amount;
				else
				$new_bal_amount1=$new_bal_amount1+$element->ae_amount;
			}
		}		
	}
	elseif($element->ae_bank==$banks_array[1])
	{
		if($element->ae_date >= $current_date)
		{
			if($new_bal_amount2=='')
			{
				if($element->ae_cash_type=="Spend")
				{
					if($current_time >= '8:0:0')
					{
				$new_bal_amount2=$result_bal_date[1]-$element->ae_amount;
					}
				}
				else
				{
					if($current_time >= '18:0:0')
					{
					$new_bal_amount2=$result_bal_date[1]+$element->ae_amount;
					}
				}
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				{
					if($current_time >= '8:0:0')
					{	
				$new_bal_amount2=$new_bal_amount2-$element->ae_amount;
					}
				}
				else
				{
					if($current_time >= '18:0:0')
					{
				$new_bal_amount2=$new_bal_amount2+$element->ae_amount;
					}
				}
			}
		}
		else
		{
			if($new_bal_amount2=='')
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount2=$result_bal_date[1]-$element->ae_amount;
				else
				$new_bal_amount2=$result_bal_date[1]+$element->ae_amount;
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount2=$new_bal_amount2-$element->ae_amount;
				else
				$new_bal_amount2=$new_bal_amount2+$element->ae_amount;
			}
		}	
	}
	elseif($element->ae_bank==$banks_array[2])
	{
		if($element->ae_date >= $current_date)
		{
			if($new_bal_amount3=='')
			{
				if($element->ae_cash_type=="Spend")
				{
					if($current_time >= '8:0:0')
					{
				$new_bal_amount3=$result_bal_date[2]-$element->ae_amount;
				}}

				else
				{
					if($current_time >= '18:0:0')
					{
				$new_bal_amount3=$result_bal_date[2]+$element->ae_amount;
				}}
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				{
					if($current_time >= '8:0:0')
					{
				$new_bal_amount3=$new_bal_amount3-$element->ae_amount;
				}}
				else
				{
					if($current_time >= '18:0:0')
					{
				$new_bal_amount3=$new_bal_amount3+$element->ae_amount;
				}}
			}
		}
		else
		{
			if($new_bal_amount3=='')
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount3=$result_bal_date[2]-$element->ae_amount;
				else
				$new_bal_amount3=$result_bal_date[2]+$element->ae_amount;
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount3=$new_bal_amount3-$element->ae_amount;
				else
				$new_bal_amount3=$new_bal_amount3+$element->ae_amount;
			}
		}	
	}
	elseif($element->ae_bank==$banks_array[3])
	{
		if($element->ae_date >= $current_date)
		{
			if($new_bal_amount4=='')
			{
				if($element->ae_cash_type=="Spend")
				{
					if($current_time >= '8:0:0')
					{
						$new_bal_amount4=$result_bal_date[3]-$element->ae_amount;
					}
				}
				else
				{
					if($current_time >= '18:0:0')
					{
						$new_bal_amount4=$result_bal_date[3]+$element->ae_amount;
					}
				}	
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				{
					if($current_time >= '8:0:0')
					{
				$new_bal_amount4=$new_bal_amount4-$element->ae_amount;
				}}
				else
				{
					if($current_time >= '18:0:0')
					{
				$new_bal_amount4=$new_bal_amount4+$element->ae_amount;
				}}
			}
		}
		else
		{
			if($new_bal_amount4=='')
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount4=$result_bal_date[3]-$element->ae_amount;
				else
				$new_bal_amount4=$result_bal_date[3]+$element->ae_amount;
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount4=$new_bal_amount4-$element->ae_amount;
				else
				$new_bal_amount4=$new_bal_amount4+$element->ae_amount;
			}
		}
	}
	elseif($element->ae_bank==$banks_array[4])
	{
		if($element->ae_date >= $current_date)
		{
			if($new_bal_amount5=='')
			{
				if($element->ae_cash_type=="Spend"){
					if($current_time >= '8:0:0'){
				$new_bal_amount5=$result_bal_date[4]-$element->ae_amount;
					}}
				else{
					if($current_time >= '18:0:0'){
				$new_bal_amount5=$result_bal_date[4]+$element->ae_amount;
				}}
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				{
				if($current_time >= '8:0:0'){
				$new_bal_amount5=$new_bal_amount5-$element->ae_amount;
				}}
				else
				{
				if($current_time >= '18:0:0'){
				$new_bal_amount5=$new_bal_amount5+$element->ae_amount;
				}}
			}
		}
		else
		{
			if($new_bal_amount5=='')
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount5=$result_bal_date[4]-$element->ae_amount;
				else
				$new_bal_amount5=$result_bal_date[4]+$element->ae_amount;
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount5=$new_bal_amount5-$element->ae_amount;
				else
				$new_bal_amount5=$new_bal_amount5+$element->ae_amount;
			}
		}
	}
	elseif($element->ae_bank==$banks_array[5])
	{
		if($element->ae_date >= $current_date)
		{
			if($new_bal_amount6=='')
			{
				if($element->ae_cash_type=="Spend"){
					if($current_time >= '8:0:0'){
				$new_bal_amount6=$result_bal_date[5]-$element->ae_amount;
				}}
				else
				{
					if($current_time >= '18:0:0'){
				$new_bal_amount6=$result_bal_date[5]+$element->ae_amount;
				}}
			}
			else
			{
				if($element->ae_cash_type=="Spend"){
					if($current_time >= '8:0:0'){
				$new_bal_amount6=$new_bal_amount6-$element->ae_amount;
				}}
				else
				{
					if($current_time >= '18:0:0'){
				$new_bal_amount6=$new_bal_amount6+$element->ae_amount;
				}}
			}
		}
		else
		{
			if($new_bal_amount6=='')
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount6=$result_bal_date[5]-$element->ae_amount;
				else
				$new_bal_amount6=$result_bal_date[5]+$element->ae_amount;
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount6=$new_bal_amount6-$element->ae_amount;
				else
				$new_bal_amount6=$new_bal_amount6+$element->ae_amount;
			}
		}
	}
	elseif($element->ae_bank==$banks_array[6])
	{
		if($element->ae_date >= $current_date)
		{
			if($new_bal_amount7=='')
			{
				if($element->ae_cash_type=="Spend"){
					if($current_time >= '8:0:0'){
				$new_bal_amount7=$result_bal_date[6]-$element->ae_amount;
				}}
				else{
				if($current_time >= '18:0:0'){
				$new_bal_amount7=$result_bal_date[6]+$element->ae_amount;
				}}
			}
			else
			{
				if($element->ae_cash_type=="Spend"){
					if($current_time >= '8:0:0'){
				$new_bal_amount7=$new_bal_amount7-$element->ae_amount;
				}}
				else{
				if($current_time >= '18:0:0'){
				$new_bal_amount7=$new_bal_amount7+$element->ae_amount;
				}}
			}
		}
		else
		{
			if($new_bal_amount7=='')
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount7=$result_bal_date[6]-$element->ae_amount;
				else
				$new_bal_amount7=$result_bal_date[6]+$element->ae_amount;
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount7=$new_bal_amount7-$element->ae_amount;
				else
				$new_bal_amount7=$new_bal_amount7+$element->ae_amount;
			}
		}	
	}
	elseif($element->ae_bank==$banks_array[7])
	{
		if($element->ae_date >= $current_date)
		{
			if($new_bal_amount8=='')
			{
				if($element->ae_cash_type=="Spend"){
					if($current_time >= '8:0:0'){
				$new_bal_amount8=$result_bal_date[7]-$element->ae_amount;
				}}
				else{
				if($current_time >= '18:0:0'){
				$new_bal_amount8=$result_bal_date[7]+$element->ae_amount;
				}}
			}
			else
			{
				if($element->ae_cash_type=="Spend"){
					if($current_time >= '8:0:0'){
				$new_bal_amount8=$new_bal_amount8-$element->ae_amount;
				}}
				else{
				if($current_time >= '18:0:0'){
				$new_bal_amount8=$new_bal_amount8+$element->ae_amount;
				}}
			}
		}
		else
		{
			if($new_bal_amount8=='')
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount8=$result_bal_date[7]-$element->ae_amount;
				else
				$new_bal_amount8=$result_bal_date[7]+$element->ae_amount;
			}
			else
			{
				if($element->ae_cash_type=="Spend")
				$new_bal_amount8=$new_bal_amount8-$element->ae_amount;
				else
				$new_bal_amount8=$new_bal_amount8+$element->ae_amount;
			}
		}	
	}
	else
	{}

	if(!array_key_exists($element->ae_date,$result_test)){
        // Add new data in array with ACCOUNT_NUMBER as an index
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['date'] = date('d F', strtotime($element->ae_date));
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['amount']= $element->ae_amount;
       $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['type'] = $element->ae_cash_type;
       $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['desc'] = $element->ae_desc;
       $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['bank'] = $element->ae_bank;

        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['bbms'] = $new_bal_amount1;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['fact'] = $new_bal_amount2;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['enbd'] = $new_bal_amount3;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['ei'] = $new_bal_amount4;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['bachir'] = $new_bal_amount5;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['garhoud'] = $new_bal_amount6;
         $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['cash_fact'] = $new_bal_amount7;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['other_bnk'] = $new_bal_amount8;

    }else{
        // Only alter category index
       $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['amount'] .= ",".$element->ae_amount;
       $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['type'] .= ",". $element->ae_cash_type;
       $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['desc'] .= "#,#". $element->ae_desc;
       $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['bank'] .= ",". $element->ae_bank;

       $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['bbms'] .= ",". $new_bal_amount1;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['fact'] .= ",". $new_bal_amount2;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['enbd'] .= ",". $new_bal_amount3;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['ei'] .= ",". $new_bal_amount4;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['bachir'] .= ",". $new_bal_amount5;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['garhoud'] .= ",". $new_bal_amount6;
         $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['cash_fact'] .= ",". $new_bal_amount7;
        $result_test[$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date][$element->ae_date]['other_bnk'] .= ",". $new_bal_amount8;
    }
//$result_test[$element->ae_date][] = $element->ae_date;
}
//ksort($result_test, SORT_NUMERIC);

// echo "<pre>";
// print_r($result_test);
// echo "</pre>";
//
;?>

</header>
<div class="panel-body">
    
     <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-responsive table-bordered table-striped mb-none " id="datatable-details">
<thead>
<tr>
<th></th>
 <th>Date</th>
<th style="display: none">Amount</th>
<th style="display: none">Type</th>
<th style="display: none">Desc.</th>
<th style="display: none">Bank</th>

<th>Total Balance</th> 

<th>Ttl BBMS</th>
<th>Ttl Factory</th>
<th>Ttl ENBD</th>
<th>Ttl EI</th>
<th>Ttl CashBachir</th>
<th>Ttl CashGarhoud</th><ABBR>QWE</ABBR>
<!-- <th>Ttl Cash Factory</th> -->
<th>Ttl Other</th>


</tr>
</thead>
<tbody>

<?php
$i=1;$j=1;
$test_data=array();
	$new_bal_amount1='';$new_bal_amount2='';$new_bal_amount3='';$new_bal_amount4='';$new_bal_amount5='';$new_bal_amount6='';
	$new_bal_amount7='';$new_bal_amount8='';

	$total_balance='';
	$bal1='';$bal2='';$bal3='';$bal4='';$bal5='';$bal6='';$bal7='';$bal8='';

	$rx_bnk1=array();$rx_bnk2=array();$rx_bnk3=array();$rx_bnk4=array();$rx_bnk5=array();$rx_bnk6=array();$rx_bnk7=array();$rx_bnk8=array();
$banks_array=array('ADIB-BBMS','ADIB-Factory','ENBD','EI Bank','Cash Mr. Bachir Book','Cash Garhoud','Cash Factory','Other Bank');

foreach($result_test as $key2=>$index2)
{
	$xpl1 =explode(",",$index2[$key2][$key2][$key2][$key2]['amount']);
    $n_category1 = "";$n_category1_test="";
    foreach($xpl1 as $b1 => $a1){
    	$amount[]=$a1;
    	///$word_limited1= str_pad($a1,26);
    	$n_category1 .= ($b1!=0) ? "<hr/>".$a1 : $a1 ; //amount
    }
	
	$xpl2 = explode(",",$index2[$key2][$key2][$key2][$key2]['type']);
    $n_category2 = "";$n_category2_test="";
    foreach($xpl2 as $b2 => $a2){
    	$cash_type[]=$a2;
		//$word_limited2= str_pad($a2,26);
	   $n_category2 .= ($b2!=0) ? "<hr/>".$a2 : $a2 ; //type
    }

   $xpl3 = explode("#,#",$index2[$key2][$key2][$key2][$key2]['desc']);
    $n_category3 = "";
    foreach($xpl3 as $b3 => $a3){

    	//$word_limited3= substr($a3, 0, 26);
    	//character_limiter($a3,12);
       $n_category3 .= ($b3!=0) ? "<hr/>".$a3 : $a3; //desc
    }

    $xpl4 = explode(",",$index2[$key2][$key2][$key2][$key2]['bank']);
    $n_category4 = "";$n_category4_test="";
 	foreach($xpl4 as $b4 => $a4)
 	{
     $n_category4 .= ($b4!=0) ? "<hr/>".$a4 : $a4 ; //bank
    }

    $xpl5 = explode(",",$index2[$key2][$key2][$key2][$key2]['bbms']);
    $bbms_end=end($xpl5);
    $n_category5 = "";
 	foreach($xpl5 as $b5 => $a5)
 	{
     $n_category5 .= ($b5!=0) ? "<hr/>".$a5 : $a5 ; //bbms
    }

    $xpl6 = explode(",",$index2[$key2][$key2][$key2][$key2]['fact']);
     $fact_end=end($xpl6);
    $n_category6 = "";
 	foreach($xpl6 as $b6 => $a6)
 	{
     $n_category6 .= ($b6!=0) ? "<hr/>".$a6 : $a6 ; //fact
    }

    $xpl7 = explode(",",$index2[$key2][$key2][$key2][$key2]['enbd']);
     $enbd_end=end($xpl7);
    $n_category7 = "";
 	foreach($xpl7 as $b7=> $a7)
 	{
     $n_category7 .= ($b7!=0) ? "<hr/>".$a7 : $a7 ; //enbd
    }

    $xpl8 = explode(",",$index2[$key2][$key2][$key2][$key2]['ei']);
     $ei_end=end($xpl8);
    $n_category8 = "";
 	foreach($xpl8 as $b8 => $a8)
 	{
     $n_category8 .= ($b8!=0) ? "<hr/>".$a8 : $a8 ; //ei
    }

    $xpl9 = explode(",",$index2[$key2][$key2][$key2][$key2]['bachir']);
     $bachir_end=end($xpl9);
    $n_category9 = "";
 	foreach($xpl9 as $b9 => $a9)
 	{
     $n_category9 .= ($b9!=0) ? "<hr/>".$a9 : $a9 ; //bachir
    }

    $xpl10 = explode(",",$index2[$key2][$key2][$key2][$key2]['garhoud']);
    $garhoud_end=end($xpl10);
    $n_category10 = "";
 	foreach($xpl10 as $b10 => $a10)
 	{
     $n_category10 .= ($b10!=0) ? "<hr/>".$a10 : $a10 ; //garhoud
    }

    $xpl11 = explode(",",$index2[$key2][$key2][$key2][$key2]['cash_fact']);
    $cash_fact_end=end($xpl11);
    $n_category11 = "";
 	foreach($xpl11 as $b11 => $a11)
 	{
     $n_category11 .= ($b11!=0) ? "<hr/>".$a11 : $a11 ; //cash_fact
    }

    $xpl12 = explode(",",$index2[$key2][$key2][$key2][$key2]['other_bnk']);
    $other_bnk_end=end($xpl12);
    $n_category12 = "";
 	foreach($xpl12 as $b12 => $a12)
 	{
     $n_category12 .= ($b12!=0) ? "<hr/>".$a12 : $a12 ; //other_bnk
    }

  
//print_r($test_data);



    if(!empty($bbms_end)){$bal1=$bbms_end;}
	else{$bal1=$result_bal_date[0];} 
	if(!empty($fact_end)){$bal2=$fact_end;}else{$bal2=$result_bal_date[1];}
	if(!empty($enbd_end)){$bal3=$enbd_end;}else{$bal3=$result_bal_date[2];}
	if(!empty($ei_end)){$bal4=$ei_end;}else{$bal4=$result_bal_date[3];}
	if(!empty($bachir_end)){$bal5=$bachir_end;}else{$bal5=$result_bal_date[4];}
	if(!empty($garhoud_end)){$bal6=$garhoud_end;}else{$bal6=$result_bal_date[5];}
	// if(!empty($cash_fact_end)){$bal7=$cash_fact_end;}else{$bal7=$result_bal_date[6];}
	if(!empty($other_bnk_end)){$bal8=$other_bnk_end;}else{$bal8=$result_bal_date[7];}

$total_balance=$bal1+$bal2+$bal3+$bal4+$bal5+$bal6+$bal8;
    ?>
<tr class="gradeX">
	<td><?php echo $i;?></td>
<td style="vertical-align: middle;"><?php print_r($index2[$key2][$key2][$key2][$key2]['date']);?></td>

 <td style="display: none"><?php echo $n_category1;?></td><!--amount-->
<td style="display: none"><?php echo $n_category2;?></td><!--type-->
<td style="display: none"><?php echo $n_category3;?></td><!--desc-->
<td style="display: none"><?php echo $n_category4;?></td><!--bank-->

<td <?php if(!empty($total_balance) && ($total_balance<0)){echo "style='background-color:#d22d5373;vertical-align: middle;'";}else{echo "style='vertical-align: middle;'";};?>><?php echo number_format((float)$total_balance, 2, '.', '');?></td><!--total bank balance-->

<td <?php if(!empty($bbms_end) && ($bbms_end<0)){echo "style='background-color:#d22d5373;vertical-align: middle;'";}else{echo "style='vertical-align: middle;'";};?> ><?php if(!empty($bbms_end))
{echo number_format((float)$bbms_end, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[0], 2, '.', '');
}
;?></td>

<td <?php if(!empty($fact_end) && ($fact_end<0)){echo "style='background-color:#d22d5373;vertical-align: middle;'";}else{echo "style='vertical-align: middle;'";};?>><?php if(!empty($fact_end))
{echo number_format((float)$fact_end, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[1], 2, '.', '');
}
;?></td>

<td <?php if(!empty($enbd_end) && ($enbd_end<0)){echo "style='background-color:#d22d5373;vertical-align: middle;'";}else{echo "style='vertical-align: middle;'";};?>><?php if(!empty($enbd_end))
{echo number_format((float)$enbd_end, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[2], 2, '.', '');
}
;?></td>

<td <?php if(!empty($ei_end) && ($ei_end<0)){echo "style='background-color:#d22d5373;vertical-align: middle;'";}else{echo "style='vertical-align: middle;'";};?>><?php if(!empty($ei_end))
{echo number_format((float)$ei_end, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[3], 2, '.', '');
}
;?></td>

<td <?php if(!empty($bachir_end) && ($bachir_end<0)){echo "style='background-color:#d22d5373;vertical-align: middle;'";}else{echo "style='vertical-align: middle;'";};?>><?php if(!empty($bachir_end))
{echo number_format((float)$bachir_end, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[4], 2, '.', '');
}
;?></td>

<td <?php if(!empty($garhoud_end) && ($garhoud_end<0)){echo "style='background-color:#d22d5373;vertical-align: middle;'";}else{echo "style='vertical-align: middle;'";};?>><?php if(!empty($garhoud_end))
{echo number_format((float)$garhoud_end, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[5], 2, '.', '');
}
;?></td>

<td <?php if(!empty($other_bnk_end) && ($other_bnk_end<0)){echo "style='background-color:#d22d5373;vertical-align: middle;'";}else{echo "style='vertical-align: middle;'";};?>><?php if(!empty($other_bnk_end))
{echo number_format((float)$other_bnk_end, 2, '.', '');
}
else{echo number_format((float)$result_bal_date[7], 2, '.', '');
}
;?></td>


</tr>

<?php 
$i=$i+1;
}?>

</tbody>
</table>



</div>
</section>

