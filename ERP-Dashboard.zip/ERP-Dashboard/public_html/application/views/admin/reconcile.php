<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>
<?php
if (!empty($this->session->userdata('bal_update'))) {
//	print_r($this->session->userdata['bal_update']['bank_name_updated']);
update_bank_bal();
	}

?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Account Entries</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Account Entries</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>
<?php
	$url=$this->uri->segment(1);
	echo "<input type='hidden' name='url_segment' value='".$url."'>";
?>


<?php
if(empty($page_name))
{?>
<a href="<?php echo base_url('list_reconcilled');?>" type="button" class="mb-xs mt-xs mr-xs btn btn-lg btn-danger">List reconciled entries</a>
<?php
}else{?>
<a href="<?php echo base_url('reconcile_entries');?>" type="button" class="mb-xs mt-xs mr-xs btn btn-lg btn-danger">List un-reconciled entries</a>
<?php
}?>


<div class="row">
<div class="col-md-12">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Account Enteries</h2>
</header>
<div class="panel-body">	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<table class="table table-bordered table-striped mb-none" id="datatable-default2">
				<thead>
<tr>
	<th></th>
<th>Category</th>
<th>Status</th>
<th>Bank</th>
<th>Date </th>
<th>Current Status</th> 
<th>Amount</th>
<th>Cash Mode </th>
<th>Description</th>
<th>Action</th>
</tr>
</thead>
<tbody>
	<?php
	$i=1;
	if(!empty($result))
	{
		foreach($result as $t)
			{?>
	<tr>
		<td><?php echo $i++;?></td>
		<td><?php echo $t->ae_cat;?></td>
		<td><?php echo $t->ae_sts;?></td>
		<td><?php echo $t->ae_bank;?></td>
		<td><?php echo $t->ae_date;?></td>
		<td class="status_entry_<?php echo $t->ae_id;?>">
			<?php
		if($t->ae_status_data=="2")
		{
		print('<span class="pull-right label label-success">Success</span>');
		}
		else
		{
		print('<span class="pull-left label label-warning">Pending</span>');
			if(($this ->session->userdata['user']['role'])=="1")
			{
				print('<button type="button" class="mb-xs mt-xs mr-xs btn btn-xs btn-primary" onclick="change_status('.$t->ae_id.')">Approve Now</button>');
			}
		}?>
		</td> 
		<td><?php echo $t->ae_amount;?></td>
		<td><?php echo $t->ae_cash_type;?></td>
		<td><?php echo word_limiter($t->ae_desc,100);?></td>
		<td>
<?php
		if($t->ae_reconcile=="1")
		{
		print('<span class="pull-right label label-success">Reconciled</span>');
			if(($this ->session->userdata['user']['role'])=="1")
			{
				print('<a class="mb-xs mt-xs mr-xs modal-sizes btn btn-warning" href="#modalSM1'.$t->ae_id.'">Un-Reconcile Now</a>
				');
			}
		}
		else
		{
		print('<span class="pull-left label label-warning">Not Reconciled</span>');
			if(($this ->session->userdata['user']['role'])=="1")
			{
				print('<a class="mb-xs mt-xs mr-xs modal-sizes btn btn-primary" href="#modalSM'.$t->ae_id.'>">Reconcile Now</a>
				');
			}
		}?>
		</td>
	</tr>
<div id="modalSM1<?php echo $t->ae_id;?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Are you sure?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
<p>Are you sure you want to Un-Reconcile the details?</p>
<p>By un-reconcile you are going to give edit permission for this entry.
</p>
<p><b>Date selected: <?php echo $t->ae_date;?></b></p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<a href="<?php echo base_url('un_reconcile_data_now/'.$t->ae_id);?>" class="delete-row">Confirm</a>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>

<div id="modalSM<?php echo $t->ae_id;?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Are you sure?</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
<p>Are you sure you want to reconcile the details?</p>
<p>By reconciling you are going to finalise all the entires till the date selected.
</p>
<p><b>Date selected: <?php echo $t->ae_date;?></b></p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<a href="<?php echo base_url('reconcile_data_now/'.$t->ae_id);?>" class="delete-row">Confirm</a>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<?php
}
}?>
</tbody>
</table>	

</div>
</section>
</div>
</div>


</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
$(document).ready(function()
	{
	     $('#datatable-default2').DataTable( {
			              rowReorder: {
			            selector: 'td:nth-child(2)'
			        },
			        "pageLength": 50,
			    responsive: true,
			     "scrollX": true,
			} );

	});

function change_status(id)
		{
			 jQuery.ajax({
		            url:"<?php echo base_url().'Admin_biri/approve_entry';?>",
		            type:"post",
		            data:{"table_id":id},
		            success:function(result)
		            {
		            	if(result=='1')
		            	{
		            		new PNotify({
									title: 'Success',
									text: 'Status Changed successfully',
									type: 'success'
								});

		            		$('.status_entry_'+id).html(
		            			'<span class="label label-success">Success</span>'
		            			);
		            	}

		            }
		            });

		} 

     
</script>

</body>
</html>