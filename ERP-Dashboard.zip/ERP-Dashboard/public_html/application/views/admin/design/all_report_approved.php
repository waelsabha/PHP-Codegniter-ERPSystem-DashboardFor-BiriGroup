<section class="panel">
<header class="panel-heading">

<h2 class="panel-title"><?php echo $this->lang->line('Approved picture'); ?></h2>
<p class="panel-subtitle">All Approved pictures</p>
</header>
<div class="panel-body">

<div class="data_result">

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default3">
<thead>
<tr>
  <th ></th>

<th>User Issued</th>
<th>Report Date </th>
<th>Report Num</th>

<th>Product Details</th>
<th>Product Code</th>
<th>Main Problem</th>
<th>Another Note</th>
<th><?php echo $this->lang->line('Action'); ?></th>

</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($return_report_approve))
{
  foreach($return_report_approve as $indexap=>$rtap)
  {
       
    $fixed_dateap=$rtap->pr_fixed_date;

//print_r($final_date);

$prodcodefix=$rtap->pr_prd_code;


//
//$wgt=explode('|#|',$t->po_wgt);

//$pckg_type=explode('|#|',$t->po_pck_type);
// $rmks=explode('|#|',$t->po_rmks);
//$req=explode('|#|',$t->po_spcl_rq);

//if(!empty($t->remaining_qnty))
//$qty_to_show=explode(',',$t->remaining_qnty);
//else
//$qty_to_show=explode('|#|',$t->po_qnty);
//?>
<tr class="gradeX">
      <td width='2%'><?php echo $i++;?></td>
      <td><?php echo $rtap->pr_user_created;?></td>
      <td><?php echo $fixed_dateap;?></td>
      <td><?php echo $rtap->pr_id;?></td>
      <td><?php echo $rtap->pr_prd_name;?></td>
      <td><?php echo $rtap->pr_prd_code;?></td>
       <td><?php echo $rtap->pr_exact_problem;?></td>
      <td><?php echo $rtap->pr_another_note;?></td>
         <td>
  <?php
  if($this->session->userdata['user']['main_dept']=="Marketing")
  {
    
  
      ?>
       Approved <br/>
      
      
     <?php
     }
  }

  }
  else{
    echo('Error Result');
  }
 ?>

 



</td>



  </tr>
</tbody>
</table>
</div>


</div>
</section>