<section class="panel">
<header class="panel-heading">

<h2 class="panel-title"><?php echo $this->lang->line('New Request'); ?></h2>
<p class="panel-subtitle">All Pending picture to fix</p>
</header>
<div class="panel-body">

<div class="data_result">

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
  <th ></th>

<th>User Issued</th>
<th>Report Date </th>
<th>Report Num</th>

<th>Product Details</th>
<th>Product Code</th>
<th>Main Problem</th>
<th>Another Note</th>
<th><?php echo $this->lang->line('Action'); ?></th>

</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($picture_reports))
{
  foreach($picture_reports as $indexr=>$pr)
  {
       
    //$return_date=$rt->pr_date;

//print_r($final_date);

$prodcode=$pr->pr_prd_code;

//?>
<tr class="gradeX">
      <td width='2%'><?php echo $i++;?></td>
      <td><?php echo $pr->pr_user_created;?></td>
      <td><?php echo $pr->pr_date;;?></td>
      <td><?php echo $pr->pr_id;?></td>
      <td><?php echo $pr->pr_prd_name;?></td>
      <td><?php echo $pr->pr_prd_code;?></td>
     <td><?php echo $pr->pr_exact_problem;?></td>
      <td><?php echo $pr->pr_another_note;?></td>
    
       <td>
         
 
       Pending <br/>
       
      <!--<button type="button" class="btn btn-sm btn-primary" onclick="approve_report(<?php echo $pr->pr_id;?>)">Aprove Now(fully)</button>  -->

               
              <a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('change_img_req_sts/2/'.$pr->pr_id);?>" >  <button type="button" class="btn btn-sm btn-primary"> Aprove Now(fully)    </button>   </a>        
     <?php
     }
  }

  
  else{
    echo('Error Result');
  }
 ?>

 
   </td>



  </tr>
</tbody>
</table>
</div>


</div>
</section>