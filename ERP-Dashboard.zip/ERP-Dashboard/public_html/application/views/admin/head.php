<meta charset="UTF-8">
<?php
if(!empty($data))
{
echo "<title>".$data."</title>";
}
else
{
echo "<title>Biri Group Admin Panel</title>";
}
?>
<meta name="keywords" content="Biri Group Admin panel" />
<meta name="description" content="Admin panel ">
<meta name="author" content="Biri Group">

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">


<!-- <style type="text/css">
@media only screen and (min-width: 768px)
{
	.sidebar-left {
		    width: 200px !important;
		  }
					  html.fixed .content-body {
			    margin-left: 200px !important;
			}
}

	@media only screen  and (min-width : 1224px) {
		 .sidebar-left {
		    width: 100px;
		  }
					  html.fixed .content-body {
			    margin-left: 100px;
			}
}



@media only screen  and (min-width : 1824px) {
	 .sidebar-left {
		    width: 100px;
		  }
					  html.fixed .content-body {
			    margin-left: 100px;
			}
}

		@media screen and (min-width: 1400px) {
		  .sidebar-left {
		    width: 100px;
		  }
					  html.fixed .content-body {
			    margin-left: 100px;
			}
		}
		@media screen and (min-width: 1600px) {
		  .sidebar-left {
		    width: 100px;
		  }
		  	html.fixed .content-body {
				    margin-left: 100px;
				}
		}
		@media screen and (min-width: 1900px) {
		  .sidebar-left {
		    width: 100px;
		  }
		  html.fixed .content-body {
			    margin-left: 100px;
			}
		}

</style> -->