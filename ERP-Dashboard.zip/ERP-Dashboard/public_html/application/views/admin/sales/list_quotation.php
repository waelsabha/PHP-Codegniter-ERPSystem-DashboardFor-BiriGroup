<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
  .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}

@-webkit-keyframes glowing {
  0% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -webkit-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
}

@-moz-keyframes glowing {
  0% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -moz-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
}

@-o-keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

@keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

</style>
<style type="text/css">
    .dot {
  height: 25px;
  width: 25px;
  border-radius: 50%;
  display: inline-block;
}
    
</style>
</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Orders</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Quotations</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>
<input type="hidden" name="base_url" value="<?php echo base_url();?>">

<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">List Quotations
  <!-- <span class="pull-right"><a class="btn btn-primary mb-xs mt-xs mr-xs modal-sizes" href="#modalsm2"></i>Export as excel </a></span> -->
  </h2>

</header>
<div class="panel-body">
  
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result">

<table class="table table-bordered table-striped mb-none" id="memListTable">
<thead>
<tr>
<th>Doc number</th> 
<th>Sales Person</th>
<th>Qutation Date</th>
<th>Company Name</th>
<th>Customer Name</th>
<th width="20%">Quotation Status</th> 
<th>Action</th>
<th>Survey Manage</th>
</tr>
</thead>
<tbody>

</tbody>
</table>

</div>
<script type="text/javascript">
  function issue_performa(quot_id)
  {
      $('#modalsm2_performa').modal('show');
      $('.quot_id').val(quot_id);
  } 
</script>

<script type="text/javascript">
  function approve_stamp(quot_id)
  {
      $('#modalsm21').modal('show');
      $('.quot_id').val(quot_id);
  } 
</script>

<!-----------modal issue performa invoice---->
<div class="modal fade" id="modalsm2_performa" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Issue Proforma Invoice?</h3>
            </div>
            <div class="modal-body form">
        <div class="row">
          <input type="hidden" class="quot_id" name="quot_id" value="">
                      <div class="col-md-12 col-sm-12 table-rows-border on_hold_till">
          <p>Are you sure you want to issue proforma invoice for this quotation?</p>
          </div>
        </div>
            </div>
            <div class="modal-footer">
               <button onclick='make_performa()'  class="btn btn-primary">Confirm</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<input type="hidden" name="page_type" class="page_type" value="<?php if(!empty($page_type)){echo $page_type;};?>">
<!---------------------modal for excel download , -------------------------->
<div id="modalsm2" class="modal-block modal-block-md mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Filter Data for excel download</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
    <?php echo form_open('Quotation_sample/filter_excel_download');?>
     <div class="row">
            <div class="form-group">
              <label class="col-md-3 control-label" for="inputSuccess">Choose Month</label>
              <div class="col-md-6">
              <select class="form-control " name="filter_month">
                <option value="">Choose</option>
                <option value="01">Jan</option>
                <option value="02">Feb</option>
                <option value="03">Mar</option>
                <option value="04">Apr</option>
                <option value="05">May</option>
                <option value="06">Jun</option>
                <option value="07">Jul</option> 
                <option value="08">Aug</option>
                <option value="09">Sep</option>
                <option value="10">Oct</option>
                <option value="11">Nov</option>
                <option value="12">Dec</option>
              </select>
              </div>
            </div>

            <div class="form-group">
              <label class="col-md-3 control-label" for="inputSuccess">Choose Year</label>
              <div class="col-md-6">
              <select id="year" name="filter_year" class="form-control year_selected">
        
                 </select>
              </div>
            </div>

        </div>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit"  class="btn btn-primary">Confirm</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>



<!---------------------modal for excel download , end here-------------------------->

<div class="modal fade" id="modalsm21" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Approve Stamp &amp; Signature request</h3>
            </div>
            <div class="modal-body form">
        <div class="row">
          <input type="hidden" class="quot_id" name="quot_id" value="">
                      <div class="col-md-12 col-sm-12 table-rows-border on_hold_till">
          <p>Are you sure you want to approve this request to show stamp and signature?</p>
          </div>
        </div>
          <span class="load-image"><small style="color:red;"><br/>Please wait,sending email....<br/></small>
 <img src="<?php echo base_url('admin_assets/images/');?>loading_gif.gif" width="150" height="150" alt="Loading image" />
</span>
            </div>
            <div class="modal-footer">
              
                 <button onclick='approve_req("decline");' class="btn btn-danger pull-left">Decline Request</button>
                  <button onclick='approve_req("approve");' class="btn btn-primary">Approve Request</button>
                <button type="button" class="btn btn-warning" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!-----------------modal performa endss-------->

<script type="text/javascript">
  function lost_reason(quot_id)
  {
    console.log('lost reason');
      $('#modalsm3_reason_lost').modal('show');
      $('.quot_id').val(quot_id);
  }
</script>
<!-----------modal reason for lost-------------->
<div class="modal fade" id="modalsm3_reason_lost" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Reason for lost?</h3>
            </div>
            <div class="modal-body form">
              <?php echo form_open('submit_quotation_sts');?>
        <div class="row">
          <input type="hidden" class="quot_id" name="qtn_sts_id">
          <input type="hidden" value="Lost" name="qtn_sts_type">

          <div class="col-md-12 col-sm-12 table-rows-border reason_lost">
  <div class="form-group">
  <label class="col-md-3 control-label" for="inputSuccess">Reason to lose quotation</label>
  <div class="col-md-6">
  <textarea class="form-control reason_lost" name="reason_lost"></textarea>
  </div>
  </div>
  </div>
        </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
               <?php echo form_close();?>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!------modal reason for lost ends------------->
<script type="text/javascript">
    function due_till_date(quot_id)
  {
    console.log('due till date');
    $('#modalsm2_due_till_date').modal('show');
     $('.quot_id').val(quot_id);
  }
</script>

<!-------------------modal due till date------------>
<div class="modal fade" id="modalsm2_due_till_date" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Due Date Till?</h3>
            </div>
            <div class="modal-body form">
            <?php echo form_open('submit_quotation_sts');?>
        <div class="row">
<input type="hidden" class="quot_id" name="qtn_sts_id">
<input type="hidden" value="On hold Till" name="qtn_sts_type">

          <div class="col-md-12 col-sm-12 table-rows-border reason_lost">
  <div class="form-group">
  <label class="col-md-3 control-label" for="inputSuccess">On Hold Till</label>
  <div class="col-md-6">
  <input type='text' name="hold_date" class="form-control datetimepicker4 on_hold_till"/>
  </div>
  </div>
  </div>
        </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
               <?php echo form_close();?>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!------------modal due till date ends----------->


<!------modal add current note status------------->
<script type="text/javascript">
    function add_note_sts(quot_data)
  {
     var quot_data_split=quot_data.split(",");
   // console.log(quot_data_split[0]);  console.log(quot_data_split[1]);
    $('#modalsm2_add_note').modal('show');
     $('.quot_id').val(quot_data_split[0]);
     $('.quot_sts').val(quot_data_split[1]);
       $('.quot_sts_text').html(quot_data_split[1]);
  }



</script>

<div class="modal fade" id="modalsm2_add_note" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Add Note</h3>
            </div>
            <div class="modal-body form">
              <?php echo form_open('Quotation_sample/submit_quotation_note');?>
 <div class="row">
<input type="hidden" class="quot_id" name="qtn_sts_id">
<input type="hidden" class="quot_sts" name="qtn_sts_type" >

 <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
  <label class="col-md-3 control-label " for="inputSuccess">Date of follow-up</label>
  <div class="col-md-6">
  <input  type='text' name="date_follow_up" class="form-control datetimepicker4" readonly="" required=""> 
  </div>
  </div>
  </div>

   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Way to follow-up through </label>
<div class="col-md-8">
<label class="checkbox-inline">
   <input type="checkbox" name="follow_up_way[]" value="Phone">  Phone
</label>
<label class="checkbox-inline">
   <input type="checkbox" name="follow_up_way[]" value="Email">  Email
</label>
<label class="checkbox-inline">
   <input type="checkbox" name="follow_up_way[]" value="Direct Meet"> Direct Meet 
</label>
 <div class="form_error">  </div>
</div>
</div>
  </div>

   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
  <label class="col-md-3 control-label " for="inputSuccess">Name of person contacted / meet :</label>
  <div class="col-md-6">
 <input  type='text' name="name_follow_up_person" class="form-control "  required=""> 
  </div>
  </div>
  </div>

   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
  <label class="col-md-3 control-label " for="inputSuccess">Next follow-up date</label>
  <div class="col-md-6">
  <input  type='text' name="next_follow_up_date" class="form-control datetimepicker5"  required=""> 
  </div>
  </div>
  </div>

    <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
  <label class="col-md-3 control-label " for="inputSuccess"> Notes on follow-up</label>
  <div class="col-md-6">
  <textarea rows='5' type='text' name="notes_follow_up" class="form-control " required=""> </textarea>
  </div>
  </div>
  </div>
        </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
               <?php echo form_close();?>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!------modal  current note status - ends------------->

<script type="text/javascript">
  function view_quotation_data(id)
{
  console.log('view');
    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('Quotation_sample/ajax_load_view/')?>",
        type: "POST",
        data: {"quot_id":id},
        success: function(data)
        {
          $('.view_data_modal').html(data);
            $('#modalsm2_view_data').modal('show'); // show bootstrap modal when complete loaded
          },
    });
}
</script>

<!-------------------modal view quotation------------>
<div class="modal fade" id="modalsm2_view_data" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">View data</h3>
            </div>
            <div class="modal-body form ">
              <div class="row view_data_modal" ></div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!------------modal view quotation ends----------->





<!------modal create survey------------->

<script type="text/javascript">

 function create_quotation_survey(id)
  {   var qutid=id;
    //var quot_data_split=quot_data.split(",");
   // console.log(quot_data_split[0]);  console.log(quot_data_split[1]);
    $('#modalsm2_create_survey').modal('show');
     $('.quot_id').val(qutid);
     //$('.quot_sts').val(quot_data_split[1]);
       //$('.quot_sts_text').html(quot_data_split[1]);
  }
</script>

<!-------------------modal view create survey------------>
<div class="modal fade" id="modalsm2_create_survey" role="dialog">

    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Create Survey</h3>
            </div>
            <div class="modal-body form">
              <?php echo form_open('Quotation_sample/submit_quotation_Survey');?>
 <div class="row">
<input type="hidden" class="quot_id" name="qtn_survey_id">






   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">1. Dose items in the quotation matching your inquiry ? </label>
</div>
  </div>

     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder"> 1-هل العناصر الموجودة بعرض السعر المرسل هي نفس العناصر التي تم الاستفسار عنها؟  </label>
</div>
  </div>


   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">

<div class="col-md-12">
<label class="checkbox-inline">
   <input type="radio" id="yes" name="inquiry_matching" value="1">  Yes
</label>
<label class="checkbox-inline">
   <input type="radio" id="no" name="inquiry_matching" value="0">  No
</label>

 <div class="form_error">  </div>
</div>
</div>
  </div>

     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">

<div class="col-md-12">
<label class="checkbox-inline">
  <textarea rows='5' type='text' name="inquiry_note" class="form-control " required=""> </textarea> 
</label>
 <div class="form_error">  </div>
</div>
</div>
  </div>


  <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">----------------------------------------------------------------------------------------------------------------</label>
</div>
</div>




   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">2.    Did you already work with us or this is the first time ( if it’s the first time how you find us)? </label>
</div>
  </div>
     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder"> 2.   هل انت عميل سابق او هذه عميل جديد؟ في حال كان عميل جديد كيف عرفت بنا؟</label>
</div>
  </div>

  <div class="col-md-12">
<label class="checkbox-inline">
   <input type="radio" id="yesold" name="new_customer" value="1">  Yes /نعم 
</label>
<label class="checkbox-inline">
   <input type="radio" id="nonew" name="new_customer" value="0">  No
</label>

 <div class="form_error">  </div>
</div>



     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">

<div class="col-md-12">
<label class="checkbox-inline">
  <textarea rows='5' type='text' name="how_find_us" class="form-control " required=""> </textarea> 
</label>
 <div class="form_error">  </div>
</div>
</div>
  </div>

  <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">----------------------------------------------------------------------------------------------------------------</label>
</div>
</div>



   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">3.    Sales employee evaluation in the following points: </label>
</div>
  </div>

     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder"> 3.   ما هو تقييمك لموظف المبيعات بالنواحي التالية؟ :   </label>
</div>
  </div>



   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-8 control-label" for="inputPlaceholder">-  Response time /وقت الاستجابة   </label>
<div class="col-md-10">
<label class="checkbox-inline">
   <input type="radio" id="late" name="s_respons" value="0">  Late / متأخر 
</label>
<label class="checkbox-inline">
   <input type="radio" id="gooodres" name="s_respons" value="1">  Good / جيد  
</label>

<label class="checkbox-inline">
   <input type="radio" id="fastres" name="s_respons" value="2">  Fast / سريع   
</label>
</br>
</div>
</div>
  </div>




   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
    </br>
<label class="col-md-8 control-label" for="inputPlaceholder">-explain all the details? / شرح كل التفاصيل   </label>
<div class="col-md-10">
<label class="checkbox-inline">
   <input type="radio" id="yeshe" name="s_explaininig" value="0"> yes he did / نعم لقد فعل  
</label>
<label class="checkbox-inline">
   <input type="radio" id="nohedidnt" name="s_explaininig" value="1">  No he didn't / لا لم يفعل  
</label>

<label class="checkbox-inline">
   <input type="radio" id="notsure" name="s_explaininig" value="2">  not Sure / لست متأكد   
</label>
</br>
</div>
</div>
  </div>

</br>
    <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
    </br>
<label class="col-md-8 control-label" for="inputPlaceholder">-communication skills?   / اسلوب التواصل  </label>
<div class="col-md-10">
<label class="checkbox-inline">
   <input type="radio" id="proff" name="s_comunication_skills" value="2"> Professional  / ناحترافي
</label>
<label class="checkbox-inline">
   <input type="radio" id="normal" name="s_comunication_skills" value="1">  normal  / لمتوسط 
</label>

<label class="checkbox-inline">
   <input type="radio" id="lessthan" name="s_comunication_skills" value="0">  less than expected / لدون المتوقع    
</label>

</div>
</div>
  </div>


   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">- Any other notes: </label>
</div>
  </div>

     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder"> -    ملاحظات عن الموظف   :   </label>
</div>
  </div>

     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder"> <textarea rows='5' type='text' name="addi_note_emp" class="form-control " > </textarea>   </label>
</div>
  </div>






  <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">----------------------------------------------------------------------------------------------------------------</label>
</div>
</div>






   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">4.   What is the status of the current quotation ? </label>
</div>
  </div>

     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">4.   ما هو وضع عرض السعر الحالي  :   </label>

</br>
</div>
  </div>


    <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
    </br>




<div class="col-md-10">

    <label class="checkbox-inline">

   <input type="radio" id="urgentinquire" name="sts_uregent" value="0"> urgent inquire / نستعجل 
</label>
<label class="checkbox-inline">
   <input type="radio" id="jih" name="sts_uregent" value="1"> Job in hand   / نلمشروع قيد التنفيذ  
</label>
<label class="checkbox-inline">
   <input type="radio" id="evalu" name="sts_uregent" value="2">  evaluation of a project   / لتقييم لمشروع مستقبلي 
</label>

<label class="checkbox-inline">
   <input type="radio" id="fut" name="sts_uregent" value="3">  pricing for future deal / لتسعير لتعاملات مستقبلية    
</label>

</div>
</div>
  </div>

  <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">----------------------------------------------------------------------------------------------------------------</label>
</div>
</div>




   <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">if Urgent Put a date </label>
</div>
  </div>

     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">في حال كنت مستعدجل  ضع تاريخ متوقع للمتاابعة     </label>

</br>
</div>
  </div>
  <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">
    <input type="date" id="urdate" name="dat_urgent" value="">

</label>
</div>
</div>




 <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">----------------------------------------------------------------------------------------------------------------</label>
</div>
</div>


 <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder">5. There Is No Ansewr For Customer ?  Put Notification</label>
</div>
  </div>
     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder"> 5.   لم يقم الزبون بالرد بخصوص الاستبيان ؟ قم بوضع بعض الملاحظات </label>
</div>
  </div>


     <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-12 control-label" for="inputPlaceholder"> <textarea rows='5' type='text' name="addi_note_no_survey" class="form-control " > </textarea>   </label>
</div>
  </div>


  


 </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
               <?php echo form_close();?>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<!------------modal view create survey ends----------->



<script type="text/javascript">
  function view_survey_data(id)
{
  console.log('view');
    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('Quotation_sample/survey_load_view/')?>",
        type: "POST",
        data: {"quot_id":id},
        success: function(data)
        {
          $('.view_data_modal').html(data);
            $('#modalsm3_view_data').modal('show'); // show bootstrap modal when complete loaded
          },
    });
}
</script>

<!-------------------modal view quotation------------>
<div class="modal fade" id="modalsm3_view_data" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">View data</h3>
            </div>
            <div class="modal-body form ">
              <div class="row view_data_modal" ></div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!------------modal view quotation ends----------->

<script type="text/javascript">
  function edit_survey_data(id)
{
  console.log('view');
    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('Quotation_sample/survey_load_edit/')?>",
        type: "POST",
        data: {"quot_id":id},
        success: function(data)
        {
          $('.view_data_modal').html(data);
            $('#modalsm4_edit_data').modal('show'); // show bootstrap modal when complete loaded
          },
    });
}
</script>






<script type="text/javascript">
   function get_more_note_info(quot_id)
        {
            $('#modal_more_info').modal('show');
              $.ajax({
                url : "<?php echo site_url('Quotation_sample/sts_notes/')?>",
                type: "POST",
                data: {"quot_id":quot_id},
                success: function(data)
                {
                  $('.view_data_modal').html(data);
                  //  $('#modal_more_info').modal('show'); // show bootstrap modal when complete loaded
                  },
            });
        }
</script>
<!-------------------modal view quotation------------>
<div class="modal fade" id="modal_more_info" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">More Info data</h3>
            </div>
            <div class="modal-body form ">
              <div class="row view_data_modal" >
                
              </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!------------modal view quotation ends----------->

</div>
</section>

</section>
</div>
<button id="position-4-success" class="mt-sm mb-sm btn btn-success" style="display: none;">Top bar </button>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

 

<script type="text/javascript">
         $(function () {
                $('.datetimepicker4').datepicker().datepicker("setDate", new Date());
  $(".load-image").hide();
         var date2 = $('.datetimepicker4').datepicker('getDate', '+2d'); 
          date2.setDate(date2.getDate()+2); 
        $('.datetimepicker5').datepicker().datepicker("setDate", date2);
                       
        var currentYear = new Date().getFullYear();
        var option = "";
        for (var year = currentYear-20 ; year <= currentYear; year++) 
        {
      
          var option = document.createElement("option");
          option.text = year;
          option.value = year;
        
          document.getElementById("year").appendChild(option)
          
        }
        document.getElementById("year").value = currentYear;

     });

     $(document).ready(function() {
      var page_type=$('.page_type').val();
    $('#memListTable').DataTable({
        // Processing indicator
        "processing": true,
        // DataTables server-side processing mode
        "serverSide": true,
        // Initial no order.
        "order": [],
        // Load data from an Ajax source
        "ajax": {
            "url": "<?php echo base_url('Quotation_sample/quotationList'); ?>",
            "data":{"page_type":page_type},
            "type": "POST",
        },

         "pageLength": 100,
    responsive: true,
        //Set column definition initialisation properties
        "columnDefs": [{ 
            "targets": [0],
            "orderable": false,
        }],

         //   dom: 'Bfrtip',
         // buttons: [
         //     'copyHtml5',
         //     'excelHtml5',
         //    'csvHtml5',
         //     'pdfHtml5'
         // ],
    });
var stack_bar_top = {"dir1": "down", "dir2": "right", "push": "top", "spacing1": 0, "spacing2": 0};
    $('#position-4-success').click(function() {
    var notice = new PNotify({
      title: 'Notification',
      text: 'Some notification text.',
      type: 'success',
      addclass: 'stack-bar-top',
      stack: stack_bar_top,
      width: "100%"
    });
  });

    });
        </script>
      <script>
        
        function change_quto_sts(qout_id)
        {
          var selected_sts=$("select[name='quotation_sts_set']").val();
          if( (selected_sts=="First follow up mail send") || (selected_sts=="Second follow up mail send") || (selected_sts=="Third follow up mail send") )
          {
          $('#set_reminder_'+qout_id+'').show();
          $('.reason_lost').hide();
          $('.on_hold_till').hide();
          }
          else if(selected_sts=="On hold Till")
          {
          $('#on_hold_till_'+qout_id+'').show();
          $('.reason_lost').hide();
          $('.set_reminder').hide();
          }
          else if(selected_sts=="Lost")
          {
          $('#reason_lost_'+qout_id+'').show();
          $('.set_reminder').hide();
          $('.on_hold_till').hide();
          }
          else
          {
          $('.set_reminder').hide();
    $('.reason_lost').hide();
    $('.on_hold_till').hide();
          }       
        }      
      </script>  

      <script type="text/javascript">
        function make_performa()
        {
          var quot_id=$('.quot_id').val();
          base_url=$('input[name="base_url"]').val();
          location.href= base_url+'issue_performa_invoice/'+quot_id;
        }

        function approve_req(type)
        {
           var quot_id=$('.quot_id').val();
            jQuery.ajax({
                     url:"<?php echo base_url().'Quotation_controller/approve_req_quot';?>",
                      data:{"quot_id":quot_id,"type_req":type},
                    type:"post",
                      beforeSend: function(){
                 $(".load-image").show();
               },
               complete: function(){
                 $(".load-image").hide();
               },
                    success:function(result)
                    {
                       if(result)
                      {
                        $('.close').trigger('click');
                        $('.quot_req_id_'+quot_id).hide();
                        var stack_bar_top = {"dir1": "down", "dir2": "right", "push": "top", "spacing1": 0, "spacing2": 0};
                        if(type=="approve")
                        {
                        var notice = new PNotify({
                            title: 'Approved',
                            text: 'Request to display Stamp and Signature in quotation is Approved successfully.',
                            type: 'success',
                            addclass: 'stack-bar-top',
                            stack: stack_bar_top,
                            width: "100%"
                          });
                      }
                      else
                      {
                           var notice = new PNotify({
                            title: 'Declined',
                            text: 'Request to display Stamp and Signature in quotation is Declined successfully.',
                            type: 'success',
                            addclass: 'stack-bar-top',
                            stack: stack_bar_top,
                            width: "100%"
                          });
                      }
                      }
                    }
                 }); 
        }

 
      </script>

</body>
</html>