<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Picture Report</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>report this Picture</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12 col-md-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">report this Picture</h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('submit_picture_report','class="myform" ','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
 
  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>


<div class="row">
<!-----=====================table col-12 starts here===================
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Problem Subject <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type="text" name="ts_subject" value=""  class="form-control" required="">
 <div class="form_error"> </div>
</div>
</div>
</div>
--=====================table col-12 ends here===================---->

<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Product Name</label>
<div class="col-md-8">
 <input type="hidden" name="pr_prd_id" value="<?php echo $products[0]->pid;?>"  class="form-control" >
 <?php
 $prd_name=explode('|~~|',$products[0]->pname);
 ;?>
 <input type="text" name="pr_prd_name" class="form-control" value="<?php echo $prd_name[0].'-'.$products[0]->pcode;?>" readonly>
 <div class="form_error">  <?php echo $this->session->flashdata('pr_prd_name');?></div>
</div>
</div>
</div>







<!-----=====================table for code we used in photo name===================---->

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Product Code For Photo</label>
<div class="col-md-8">
 <input type="hidden" name="" value="<?php echo $products[0]->pid;?>"  class="form-control" >
 <?php
 $prd_name=explode('|~~|',$products[0]->pname);
 ;?>
 <input type="text" name="pr_prd_code" class="form-control" value="<?php echo $products[0]->pcode;?>" readonly>
 <div class="form_error">  <?php echo $this->session->flashdata('pr_prd_code');?></div>
</div>
</div>
</div>
<!-----=====================table for code we used in photo name===================---->


<!-----=====================table for commomn Problems===================---->
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-3 control-label" for="inputSuccess">Choose what problem need to report<abbr class="required">::*::</abbr></label>
    <div class="col-md-6">
    <div class="radio">
    <label>
    <input type="radio" name="view_option" value="Different_Product">Different Product Picture
    </label>
    </div>
    <div class="radio">
    <label>
    <input type="radio" name="view_option" value="Unclear_Photo">
    Unclear Photo
    </label>
    </div>
    <div class="radio">
    <label>
    <input type="radio" name="view_option" value="Low_quality" >
   Low Quality
    </label>
    </div>
    <div class="radio">
    <label>
    <input type="radio" name="view_option" value="no_photo">
   No Photo
    </label>
    </div>
    
  
  
 
     


    </div>
    <div class="col-md-3">
    </div>

<div class="form_error">  <?php echo $this->session->flashdata('view_option');?></div> 
</div>
  
</div>



<!-----=====================table for commomn Problems===================---->









<!-----=====================table col-12 ends here===================---->

<!-----=====================table col-12 starts here===================---->
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Another Note<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <textarea class="form-control" name="pr_another_note"></textarea>
 <div class="form_error">  <?php echo $this->session->flashdata('pr_another_note');?></div>
</div>
</div>
</div>
<!-----=====================table col-12 ends here===================---->

<!----div end here for non-inquiry--->
</section>
<!-----div starts here for details---->

<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>


</section>
</div>

</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

</body>

</html>