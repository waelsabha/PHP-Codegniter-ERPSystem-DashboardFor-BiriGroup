<section class="panel">
<header class="panel-heading">

<h2 class="panel-title"><?php echo $this->lang->line('NEW Returned'); ?></h2>
<p class="panel-subtitle">All Pending returnss</p>
</header>
<div class="panel-body">

<div class="data_result">

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
  <th ></th>

<th>Sales Person</th>
<th>Return Date</th>
<th>Return Doc_Num</th>

<th>Product return details</th>
<th>Product Code</th>
<th><?php echo $this->lang->line('Action'); ?></th>

</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($return_result))
{
  foreach($return_result as $indexr=>$rt)
  {
       
    $return_date=$rt->srt_date;

//print_r($final_date);

$prodcode=explode('|#|',$rt->srt_desc);
$qnty=explode('|#|',$rt->srt_qnty);

$countqnt=count($qnty);
$countname=count($prodcode);
//$wgt=explode('|#|',$t->po_wgt);

//$pckg_type=explode('|#|',$t->po_pck_type);
// $rmks=explode('|#|',$t->po_rmks);
//$req=explode('|#|',$t->po_spcl_rq);

//if(!empty($t->remaining_qnty))
//$qty_to_show=explode(',',$t->remaining_qnty);
//else
//$qty_to_show=explode('|#|',$t->po_qnty);
//?>
<tr class="gradeX">
      <td width='2%'><?php echo $i++;?></td>
      <td><?php echo $rt->srt_user_created;?></td>
      <td><?php echo $return_date;?></td>
      <td><?php echo $rt->srt_doc_no;?></td>
     


    <td>
        <table class="table table-bordered">
          <thead>
           <th><?php echo $this->lang->line('Product Name'); ?></th>
          
      
            <th><?php echo $this->lang->line('Quantity'); ?></th>
          </thead>
          <tbody>
             <?php
        for($i=0;$i<$countqnt;$i++)
          {
             //$prd_name=explode('|#|',$rep['srt_desc']);
            //$prod_code_ret=$rep['pcode'];
            ?>
            <tr>
              <td><?php
              
                echo $prodcode[$i];
                ?> 
              </td>
              <td><?php 
              
              echo $qnty[$i];
                 ?> 
              </td>
           
            </tr>
          <?php
          }?>  
          </tbody>
        </table>
      </td>








      <td>
        <table class="table table-bordered">
          <thead>
            <th>Product Code</th>
          </thead>
          <tbody>
             <?php
        foreach($prd_data1[$indexr] as $indexr2=>$rp)
          {
             $prd_name_db=explode('|~~|',$rp['pname']);
            $prod_code=$rp['pcode'];
            ?>
            <tr>
              <td><?php
                if(empty($prod_code))
                echo $prd_name_db[0].'<br/>'.$prd_name_db[1];
              else
                echo $prod_code;
                ?> 
              </td>
             
            </tr>
          <?php
          }?>  
          </tbody>
        </table>
      </td>
       
         <td>
 
       Pending <br/>
       
      <button type="button" class="btn btn-sm btn-primary" onclick="approve_return(<?php echo $rt->srt_id;?>)">Aprove Now(fully)</button> 
     <?php
     }
  }

  
  else{
    echo('Error Result');
  }
 ?>

 




  </tr>
</tbody>
</table>
</div>


</div>
</section>