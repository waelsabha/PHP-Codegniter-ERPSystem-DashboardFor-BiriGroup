<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<style type="text/css">
  .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
  border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
  color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Add Sales Target </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span> Sales Target</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Add Sales Target</h2>
</header>
<div class="panel-body">
  <?php echo form_open_multipart('submit_sales_target','class="myform"');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
  
    <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>


<input type="hidden" name="edit_target_id" value="<?php if(!empty($result[0]->st_id)){echo $result[0]->st_id;};?>">


<!-- <input type='hidden' name='prd_id_update[]' value="<?php if(!empty($result[0]->po_prd_name)){echo $result[0]->po_prd_name;};?>"> -->

<div class="row">
<div class="col-md-12 col-sm-12 table-rows-border">
  
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose sales person <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <select class="form-control" name="st_sales_person">
    <option>Choose</option>
    <?php
    if(!empty($salesperson))
    {
      foreach($salesperson as $sp)
        {
          print_r($sp);

          ?>
    <option value="<?php echo $sp->log_uname;?>" <?php if(!empty($result)){if($result[0]->st_sales_person==$sp->log_uname){echo "selected";}};?>><?php echo $sp->log_uname;?></option>
    <?php
    }
      }
      ?>
  </select>
 <div class="form_error">  <?php echo $this->session->flashdata('st_sales_person');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose month of the year <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <select class="form-control monthname_quarter" name="st_month" onload="calc_quarter()"   onchange="calc_quarter()">
    <option>Choose</option>
    <option value="01" <?php if(!empty($result)){if($result[0]->st_month=="1"){echo "selected";}};?>>Jan</option>
    <option value="02" <?php if(!empty($result)){if($result[0]->st_month=="2"){echo "selected";}};?>>Feb</option>
    <option value="03" <?php if(!empty($result)){if($result[0]->st_month=="3"){echo "selected";}};?>>March</option>
    <option value="04" <?php if(!empty($result)){if($result[0]->st_month=="4"){echo "selected";}};?>>April</option>
    <option value="05" <?php if(!empty($result)){if($result[0]->st_month=="5"){echo "selected";}};?>>May</option>
    <option value="06" <?php if(!empty($result)){if($result[0]->st_month=="6"){echo "selected";}};?>>June</option>
    <option value="07" <?php if(!empty($result)){if($result[0]->st_month=="7"){echo "selected";}};?>>July</option>
    <option value="08" <?php if(!empty($result)){if($result[0]->st_month=="8"){echo "selected";}};?>>Aug</option>
    <option value="09" <?php if(!empty($result)){if($result[0]->st_month=="9"){echo "selected";}};?>>Sep</option>
    <option value="10" <?php if(!empty($result)){if($result[0]->st_month=="10"){echo "selected";}};?>>Oct</option>
    <option value="11" <?php if(!empty($result)){if($result[0]->st_month=="11"){echo "selected";}};?>>Nov</option>
    <option value="12" <?php if(!empty($result)){if($result[0]->st_month=="12"){echo "selected";}};?>>Dec</option>
  </select>
  <div class="form_error">  <?php echo $this->session->flashdata('st_month');?></div>
</div>
</div>
</div>

</div>



<div class="col-md-12 col-sm-12 table-rows-border">
  
<div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="col-md-3 control-label" for="inputPlaceholder" style="font-size: 16px;color:red;">This Month in The </label>
<div class="col-md-9">
 <input type="text" style="font-size: 16px;color:blue;" readonly="" value="" class="quarternum"> 

</div>
</div>
</div>



</div>

<div class="col-md-12 col-sm-12 table-rows-border">
  
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Enter total target for the month <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type="number"  name="st_total_target" onchange="calc_targets_suggest()" value="<?php if(!empty($result[0]->st_total_target)){ echo $result[0]->st_total_target;};?>"  class="form-control monthtarget">
 <div class="form_error">  <?php echo $this->session->flashdata('st_total_target');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Suggusted Quarter</label>
<div class="col-md-8">
 <input type="number"  readonly=""    name="st_target_sug" value="<?php  echo $result[0]->st_target_sug;;?>" class="form-control quartersuggusted">
 <div class="form_error ">  <?php echo $this->session->flashdata('st_target_sug');?></div>
</div>
</div>
</div>

</div>
<div class="col-md-12 col-sm-12 table-rows-border">
  
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Quarter value (Suggusted not accepted)</label>
<div class="col-md-8">
 <input type="number" name="si_quarter_target" value="<?php if(!empty($result[0]->si_quarter_target)){ echo $result[0]->si_quarter_target;};?>"  class="form-control">
 <div class="form_error">  <?php echo $this->session->flashdata('si_quarter_target');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Suggusted Weekly</label>
<div class="col-md-8">
 <input type="number" readonly=""  name="st_target_sg_week" value="<?php if(!empty($result[0]->st_target_achieve)){ echo $result[0]->st_target_achieve;};?>" class="form-control weeklysuggusted">
 <div class="form_error">  <?php echo $this->session->flashdata('st_target_achieve');?></div>
</div>
</div>
</div>

</div>




</div>

<!-- submit_main_form -->
<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
<!-- submit_main_form -->

<?php echo form_close();?>
</div>
</section>



</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>



<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
    tinymce.init({
      selector : '.editors',
        plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
    });
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('#datetimepicker4').datepicker().datepicker("setDate", new Date());
            });



          function calc_targets_suggest()
        {
  var month_target_value=$('.monthtarget').val();

  var tot_quartersuggusted=parseFloat(month_target_value)*3;

  var weekly_suggusted=parseFloat(month_target_value/4).toFixed(0);

   $('.quartersuggusted').val(tot_quartersuggusted);
     $('.weeklysuggusted').val(weekly_suggusted);

 

}

          function calc_quarter()
 {
          var monthname_quarter=$('.monthname_quarter').val();

        if (monthname_quarter==10|| monthname_quarter==11 || monthname_quarter==12) 
        {
         var quartnum="Fourth Quarter ";
        }

        else if (monthname_quarter==7||monthname_quarter==8||monthname_quarter==9) 
        {
        var quartnum="Third Quarter ";
        }
        else if (monthname_quarter==4||monthname_quarter==5||monthname_quarter==6) 
        {
         var quartnum="Second Quarter ";
        }
        else if (monthname_quarter==1||monthname_quarter==2||monthname_quarter==3) 
        {
          var quartnum="First Quarter ";
        }


          

           $('.quarternum').val(quartnum);
            

 

}


        </script>

</body>

</html>