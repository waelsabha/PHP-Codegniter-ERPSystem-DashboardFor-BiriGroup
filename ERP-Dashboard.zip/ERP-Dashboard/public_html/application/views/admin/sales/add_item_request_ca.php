<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<style type="text/css">
  .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
  border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
  color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Item Request</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Item Request</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Create Item Request</h2>
</header>
<div class="panel-body">
  <?php echo form_open_multipart('submit_item_req_ca','class="myform"');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
  
    <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>


<input type="hidden" name="edit_item_req_id" value="<?php if(!empty($result[0]->ir_id)){echo $result[0]->ir_id;};?>">
<input type="hidden" name="quotation_created_by" value="<?php if(!empty($result[0]->ir_user_created)){echo $result[0]->ir_user_created;};?>">

<input type="hidden" name="edit_files" value="<?php if(!empty($result[0]->ir_attachments)){echo $result[0]->ir_attachments;};?>">

<!-- <input type='hidden' name='prd_id_update[]' value="<?php if(!empty($result[0]->po_prd_name)){echo $result[0]->po_prd_name;};?>"> -->

<div class="row">
<div class="col-md-12 col-sm-12 table-rows-border">
  
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Request No <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type="text" name="ir_req_no" value="<?php if(!empty($result[0]->ir_req_no)){echo $result[0]->ir_req_no;}else{echo $doc_num;}?>" readonly class="form-control">
 <div class="form_error">  <?php echo $this->session->flashdata('ir_req_no');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Request title <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type="text" name="ir_req_title" value="<?php if(!empty($result[0]->ir_req_title)){echo $result[0]->ir_req_title;}?>" class="form-control" required>
 <div class="form_error">  <?php echo $this->session->flashdata('ir_req_title');?></div>
</div>
</div>
</div>

</div>




<!-- test !-->

<div class="col-md-12 col-sm-12 table-rows-border">
  
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Destination Country<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<select  class="form-control" name="country_dest" required="">
<?php foreach($country_dest as $country_val){ ?>

 <option value="<?php  {echo $country_val->country_id;}?>"selected="" > <?php {echo $country_val->name;}?></option>
<?php
 }?>
 
  
 </select>
 <div class="form_error">  <?php echo $this->session->flashdata('ir_req_no');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Port Of Loading <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <select  class="form-control" name="port_of_loading" required="">
 <?php foreach($Ports_loading as $port_load) { ?>
	 <option value="<?php  {echo $port_load->ports_id;}?>"selected="" > <?php {echo $port_load->Port_name;}?></option>
<?php	 
 } ?>

  
 </select>
  <span><button class="btn btn-primary pull-right modal-with-form" href="#modalForm2"> <i class="fa fa-plus"></i></button></span>
 <div class="form_error">  <?php echo $this->session->flashdata('ir_req_title');?></div>
</div>
</div>
</div>

</div>


<!--end of test1 !-->



<!-- test2 !-->

<div class="col-md-12 col-sm-12 table-rows-border">
  
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> CBM Size (Pallet=3.3 CBM)<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type="text" name="cbm_size" value="<?php if(!empty($result[0]->ir_req_title)){echo $result[0]->ir_req_title;}?>" class="form-control" required>
 <div class="form_error">  <?php echo $this->session->flashdata('ir_req_no');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Shipment Method<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <select  class="form-control" name="shipping_method" required="">
 <?php foreach($shipment_methods as $shipment_s) { ?>
 <option value="<?php  {echo $shipment_s->Shipment_id;}?>"selected="" > <?php {echo $shipment_s->Shipment_name;}?></option>
  <?php
  }
  ?>
 </select>
 <div class="form_error">  <?php echo $this->session->flashdata('ir_req_title');?></div>
</div>
</div>
</div>

</div>


<!--end of test2 !-->




<div class="col-md-12 col-sm-12 table-rows-border">
  
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Request Type <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<select  class="form-control" name="request_type" required="">

 <option value="direct import" selected="" <?php  echo "selected";?> >Direct Import</option>
  
 <option value="dubai supply" selected="" <?php  echo "selected";?> >Dubai Supply</option>

 </select>
</div>
</div>
</div>



</div>








<div class="col-md-12 col-sm-12 table-rows-border ">
  
<div class="col-md-6 ">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Is the item stock or sold ?<abbr class="required">::*::</abbr></label>
 <div class="col-md-8">
<input type="radio" name="ir_delivery_type" value="Stock" <?php if(!empty($result[0]->ir_delivery_type)){if($result[0]->ir_delivery_type=="Stock"){echo "checked";}};?> >Stock<br>
<input type="radio" name="ir_delivery_type" value="Sold" <?php if(!empty($result[0]->ir_delivery_type)){if($result[0]->ir_delivery_type=="Sold"){echo "checked";}};?> > Sold
  <div class="form_error">  </div>
 <div class="form_error">  <?php echo $this->session->flashdata('ir_delivery_type');?></div>
</div>
</div>
</div>


<div class="form-group exact_delivery_date">
<label class="col-md-4 control-label" for="inputPlaceholder"> Exact Delivery Date<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <?php
  if(!empty($result[0]->ir_exact_delivery_date))
  $converted_date_delivry = date("m/d/Y", strtotime($result[0]->ir_exact_delivery_date));
  ?>
 <input type='text' name="ir_exact_delivery_date" class="form-control" id='datetimepicker4' value="<?php if(!empty($converted_date_delivry)){echo $converted_date_delivry;} ;?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('ir_exact_delivery_date');?></div>
</div>
</div>
</div>


<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="col-md-6">
<div class="form-group">

<label class="col-md-4 control-label" for="inputPlaceholder">Upload Files(supporting documents/any files. )<abbr class="required">Not mandatory</abbr></label>
<div class="col-md-8"><small>Please upload only jpeg,jpg,png,pdf files</small>
<input type="file" name="ir_attachments[]">
<input type="file" name="ir_attachments[]">
<input type="file" name="ir_attachments[]">
<input type="file" name="ir_attachments[]">
<input type="file" name="ir_attachments[]">
  <div class="form_error">  <?php echo $this->session->flashdata('ir_attachments');?></div>
</div>
</div>
</div>

  <div class="col-md-6">
    <p><b>Attachments </b>
      
        <?php if(!empty($result[0]->ir_attachments))
        {
         echo "<br/>";
          $files_attached=explode(',',$result[0]->ir_attachments);
          foreach($files_attached as $t)
          {
             $file_parts = pathinfo($t);
            if(($file_parts['extension']=="jpeg")||($file_parts['extension']=="jpg")||($file_parts['extension']=="png")||($file_parts['extension']=="PNG"))
            {
           
              echo "<img src='".base_url('uploads/file_manager/').$t."' width='100' height='100' >";echo "<br/>";
            }
           ?>
           <a href="<?php echo base_url('uploads/file_manager/'.$t);?>" target="_blank"><?php echo $t;?></a><br/>
           <?php
          }
       }?></p>
  </div>

</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Extra details/notes<abbr class="required">Not mandatory</abbr></label>
<div class="col-md-8">
<textarea name="ir_extra_details" class="form-control editors"><?php if(!empty($result[0]->ir_extra_details)){echo $result[0]->ir_extra_details;};?></textarea>

  <div class="form_error">  <?php echo $this->session->flashdata('ir_extra_details');?></div>
</div>
</div>
</div>

</div>

<div class="cell_text_data"></div>
<!-- submit_main_form -->

</div>
</section>

<section class="panel panel-featured panel-featured-primary">

<div class="panel-body">
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->

<div class="row">

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Search Product<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<small>Type a word or letter then press 'space' key</small>
<select data-plugin-selectTwo class='form-control populate search_product_select' name='search_product_cat'>
<option></option>
<?php
    foreach($products as $c)
      {
        $prd_name=explode('|~~|',$c->pname);
        ?>
    <option value="<?php echo $c->pid;?>" ><?php echo $prd_name[0].' ::  <br/><br/> '.$c->pcode;?></option>
    <?php
  }?>

 </select>

<div class="form_error">  <?php echo $this->session->flashdata('search_product_cat');?></div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive">  
<table class="table table-bordered mb-none">
  <thead>
    <tr>
      <!--  <th>#</th>  -->
      <th></th>
      <th>Product Name</th>
      <th>Quantity</th>
    
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody class="new_rows">
  <?php
  if(!empty($result[0]->ir_prd_id))
  {
  $i=1;

foreach($prds as $index=>$p)
{
  
  foreach($p as $indx2=>$q)
  {
    
  $pname=explode('|~~|',$q->pname);
  
    $qnty=explode('|#|',$result[0]->ir_prd_qnty);
$rmks=explode('|#|',$result[0]->ir_prd_extra_data);
    ?>
<tr>
  <td><?php echo $i;?></td>
<td>
<input type="hidden" name="prd_id[]" value="<?php echo $q->pid;?>">
<input type="hidden" name="prdids">
<?php echo $pname[0].'<br/>'.$pname[1];?></td>
<td>
  <input type='hidden' name='qntys' >
  <input type='number' name='qnty[]'  value="<?php echo $qnty[$index];?>"></td>

  <td>
 <input type='hidden' name='extra_detail' >
 <textarea type="text" name='extra_details[]' class="prd_extra_details<?php echo $i;?>"><?php echo $rmks[$index];?></textarea>
</td>

</tr>

<?php
$i++;
}
}
  }
  ?>
  </tbody>
</table>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">

<label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
<div class="col-md-8">
  <span class="num_items">
    <?php
  if(!empty($result[0]->po_prd_name))
  {
    $p_ids=explode('|#|',$result[0]->po_prd_name);
    echo count($p_ids);
  }?>
  </span>
</div>

</div>

</div>


<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
<!-- submit_main_form -->

<?php echo form_close();?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>




<section>
<div id="modalForm2" class="modal-block modal-block-primary mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Add Master  </h2>
</header>
<div class="panel-body">

<?php echo form_open('Item_request/submit_new_port','class="form-horizontal mb-lg extra-form"');?>
  <input type="hidden" name="country_request" value="ca">
<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Port Name <abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<input type="text" name="port_name" class="form-control"  required />
</div>
</div>

<div class="form-group mt-lg">
<label class="col-sm-3 control-label">Port Country<abbr class="required">::*::</abbr></label>
<div class="col-sm-9">
<select  class="form-control" name="port_country_id" required="">
<?php foreach($country_dest as $country_val){ ?>

 <option value="<?php  {echo $country_val->country_id;}?>"selected="" > <?php {echo $country_val->name;}?></option>
<?php
 }?>
 
  
 </select>
</div>
</div>




</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-primary" type="submit">Submit</button>
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>








<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>


<script type="text/javascript">
  $(document).ready(function()
  {
    ///$('.search_product_select').hide()

    var production_id=$("input[name='ordr_id']").val();
   
    $('.exact_delivery_date').hide();

   
    $('input:radio').change(function() {
      var ir_delivery_type = $("input[name='ir_delivery_type']:checked").val();
      if(ir_delivery_type=="Sold")
      {
        $('.exact_delivery_date').show();
      }
      if(ir_delivery_type=="Stock")
      {
        $('.exact_delivery_date').hide();
      }   
      });
 
$('.search_product_select').on("change",function(e)
{
  var prd_name=$('.search_product_select :selected').text();
var search_prd_id=$('.search_product_select :selected').val();
var category_selected=$("select[name='choose_category']").val();
var tablecount = $('table tbody tr').length;
  if(tablecount=="0")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }
  jQuery.ajax({
                url:"<?php echo base_url().'Product_order/search_product_id_quot';?>",
                type:"post",
                data:{"search_prd_id":search_prd_id},
                success:function(result)
                    {
                      //console.log(result);
                    var returndata = JSON.parse(result);
                    $('.prd_weight'+table_id).val(returndata.wgt);
                   $('.prd_en'+table_id).text(returndata.prd_name_en);
                   $('.prd_ar'+table_id).text(returndata.prd_name_ar);
                    $('.prd_code'+table_id).text(returndata.prd_code);
                    }
            });

  $('.prd_name_selected').text(prd_name);
    //$('.prd_name').html(prd_name);
    var table_data=$('.new_rows').length;
    var i=table_data;
    var new_quantity='0';
    
        var markup = "<tr class='table"+table_id+"'>"+
        "<td><button type='button' onclick=table("+table_id+")>X</button></td>"+
        "<td ><input type='hidden' name='prd_id[]' value='"+search_prd_id+"'><input type='hidden' name='prdids'><span class='prd_en"+table_id+"'></span><br/><span class='prd_ar"+table_id+"'></span><br/><span class='prd_code"+table_id+"'></span>"+
        "</td><td><input type='hidden' name='qntys'>"+
        "<input type='number' class='qnty_val' name='qnty[]' ></td>"+
       "<td><input type='hidden' name='extra_detail'> <textarea name='extra_details[]' class='prd_extra_details"+table_id+"'></textarea></td>"+
        "</tr>";
            $("table tbody").append(markup);
     var rowcount = $('table tbody tr').length;
     $(".num_items").html(rowcount);
    });
  });

  function table(id)
  {
    $('table tbody .table'+id).remove();
    var rowcount = $('table tbody tr').length;
    $(".num_items").html(rowcount);
  }
   
$('.myform').submit(function() {
  
var rowcount = $('table tbody tr').length;
var product_id=$('table tbody tr td input[name="prd_id[]"]').map(function(){return $(this).val();}).get().join('|#|');
var quantity=$('table tbody tr td input[name="qnty[]"]').map(function(){return $(this).val();}).get().join('|#|');  
var extra_det=$('table tbody tr td textarea[name="extra_details[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
//console.log(quantity+' '+package_size+' '+product_id);

$("input[name='prdids']").val(product_id);
$("input[name='qntys']").val(quantity);
$("input[name='extra_detail']").val(extra_det);

var ij=0;

$('table tbody tr td').each(function() {  
var cellText = $(this).html(); 
   // console.log(cellText);  
    $('.cell_text_data').append(cellText).hide();
});

//console.log($("input[name='prdids']").val());
 //console.log($("input[name='variation_selected_val']").val());

 if(cellText=='')
  return false;
  else
   return true;
    
  //return false;

  // your code here
});
  
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
    tinymce.init({
      selector : '.editors',
        plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
    });
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('#datetimepicker4').datepicker().datepicker("setDate", new Date());
            });
        </script>

</body>

</html>