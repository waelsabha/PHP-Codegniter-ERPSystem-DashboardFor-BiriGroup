<section class="panel">
<header class="panel-heading">

<h2 class="panel-title"><?php echo $this->lang->line('Approved return'); ?></h2>
<p class="panel-subtitle">All Approved returnss</p>
</header>
<div class="panel-body">

<div class="data_result">

<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default3">
<thead>
<tr>
  <th ></th>

<th>Sales Person</th>
<th>Return Date</th>
<th>Return Doc_Num</th>

<th>Product return details</th>
<th>Product Code</th>
<th>Action</th>

</tr>
</thead>
<tbody>
<?php
$i=1;
if(!empty($return_result_approve))
{
  foreach($return_result_approve as $indexap=>$rtap)
  {
       
    $return_dateap=$rtap->srt_date;

//print_r($final_date);

$prodcodeaprove=explode('|#|',$rtap->srt_desc);
$qntyaprove=explode('|#|',$rtap->srt_qnty);

$countqntaprove=count($prodcodeaprove);
$countnameaprove=count($qntyaprove);
//$wgt=explode('|#|',$t->po_wgt);

//$pckg_type=explode('|#|',$t->po_pck_type);
// $rmks=explode('|#|',$t->po_rmks);
//$req=explode('|#|',$t->po_spcl_rq);

//if(!empty($t->remaining_qnty))
//$qty_to_show=explode(',',$t->remaining_qnty);
//else
//$qty_to_show=explode('|#|',$t->po_qnty);
//?>
<tr class="gradeX">
      <td width='2%'><?php echo $i++;?></td>
      <td><?php echo $rtap->srt_user_created;?></td>
      <td><?php echo $return_dateap;?></td>
      <td><?php echo $rtap->srt_doc_no;?></td>
     


    <td>
        <table class="table table-bordered">
          <thead>
           <th><?php echo $this->lang->line('Product Name'); ?></th>
          
      
            <th><?php echo $this->lang->line('Quantity'); ?></th>
          </thead>
          <tbody>
             <?php
        for($k=0;$k<$countqntaprove;$k++)
          {
             //$prd_name=explode('|#|',$rep['srt_desc']);
            //$prod_code_ret=$rep['pcode'];
            ?>
            <tr>
              <td><?php
              
                echo $prodcodeaprove[$k];
                ?> 
              </td>
              <td><?php 
              
              echo $qntyaprove[$k];
                 ?> 
              </td>
           
            </tr>
          <?php
          }?>  
          </tbody>
        </table>
      </td>








      <td>
        <table class="table table-bordered">
          <thead>
            <th>Product Code</th>
          </thead>
          <tbody>
             <?php
        foreach($prd_data2[$indexap] as $indexap2=>$rp2)
          {
             $prd_name_db=explode('|~~|',$rp2['pname']);
            $prod_code2=$rp2['pcode'];
            ?>
            <tr>
              <td><?php
                if(empty($prod_code2))
                echo $prd_name_db[0].'<br/>'.$prd_name_db[1];
              else
                echo $prod_code2;
                ?> 
              </td>
             
            </tr>
          <?php
          }?>  
          </tbody>
        </table>
      </td>
       
         <td>
  <?php
  if($this->session->userdata['user']['main_dept']=="Sales")
  {
    
  
      ?>
       Approved <br/>
      
      
     <?php
     }
  }

  }
  else{
    echo('Error Result');
  }
 ?>

 



</td>



  </tr>
</tbody>
</table>
</div>


</div>
</section>