<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}

</style>
<style type="text/css">
    .dot {
  height: 25px;
  width: 25px;
  border-radius: 50%;
  display: inline-block;
}
    
</style>
</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Add Proforma Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Add</span></li>
<li><span>Extra Details Proforma </span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Extra Details Proforma</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

			<?php echo form_open('Quotation_controller/submit_pi_details');?>
<!-------------------modal due till date------------>
    <h3 class="modal-title">Add Extra Details (TRN Number / LPO)</h3>
         
            <div class="modal-body form">
            <?php echo form_open('submit_pi_details');?>
				<div class="row">
<input type="hidden" class="quot_id" name="qout_id" value="<?php echo $details[0]->q_id;?>">
<h4> Details for Local Invoice </h4><br/>
	<div class="col-md-12 col-sm-12 table-rows-border reason_lost">
    <div class="col-md-6">
  	<div class="form-group">
    <label class="control-label" for="inputSuccess">TRN Number</label>
  	<input type='text' name="trn_number" value="<?php if(!empty($details[0]->q_pi_trn)){echo $details[0]->q_pi_trn;};?>" class="form-control "/>
  	</div>
    </div>

    <div class="col-md-6">
  	<div class="form-group">
  	<label class="control-label" for="inputSuccess">LPO Number</label>
  	<input type='text' name="lpo_number" value="<?php if(!empty($details[0]->q_pi_po_number)){echo $details[0]->q_pi_po_number;};?>" class="form-control"/> <br/><br/> 
  	</div>
    </div>
    

    <div class="col-md-12 table-rows-border">
      <div class="col-md-12">
    <div class="form-group">
      <label class="col-md-4 control-label" for="inputPlaceholder">Display HSC Code:<abbr class="required">*</abbr></label>
<div class="col-md-8">
 <input type="radio" name="display_hsc" value="1" <?php if(!empty($details[0]->q_display_hsc)){if($details[0]->q_display_hsc=='1'){echo "checked";}};?>>Yes<br>
    <input type="radio" name="display_hsc" value="2" <?php if(!empty($details[0]->q_display_hsc)){if($details[0]->q_display_hsc=='2'){echo "checked";}}else{echo "checked";};?>> No 
    <br/><br/>
  <div class="form_error">  </div>  
</div>
</div>
    </div>
    </div>


    <div class="row">
<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Show stamp & Signature<abbr class="required">::*::</abbr><br/><small>Get approval for showing company signed stamp image in this Proforma from managment</small></label>
 <div class="col-md-8">
<input type="radio" name="show_stamp" value="1" <?php if(!empty($details[0]->show_stamp_proforma)){if($details[0]->show_stamp_proforma==1){echo "checked";}};?> >Yes<br>
<input type="radio" name="show_stamp" value="2" <?php if(!empty($details[0]->show_stamp_proforma)){if($details[0]->show_stamp_proforma==2){echo "checked";}}else{echo "checked";};?> > No

  <div class="form_error">  </div>

  <input type="hidden" name="approved_sts_sign" value="<?php if(!empty($details[0]->p_approval_stamp_sign)){echo $details[0]->p_approval_stamp_sign;}else{echo '1';};?>">

    <input type="hidden" name="total_price_final" value="<?php if(!empty($details[0]->q_total_price)){echo $details[0]->q_total_price;};?>">

      <input type="hidden" name="converted_ar" value="<?php if(!empty($details[0]->q_price_ar)){echo $details[0]->q_price_ar;};?>">
  
 <div class="form_error">  <?php echo $this->session->flashdata('show_stamp');?></div>
</div>
</div>
</div>
</div>


	</div>
<br/><br/><br/>
<h4> Details of Customer </h4><br/>
<?php 
if(!empty($details[0]->q_id))
{
if(!empty($details[0]->proforma_cust_details))
{
$cust_info=explode('$#$',$details[0]->proforma_cust_details);

  $c_comp_name=explode(':',$cust_info[0]);
    $c_cust_name=explode(':',$cust_info[1]);
    $c_cust_email=explode(':',$cust_info[2]);
      $c_cust_mobile=explode(':',$cust_info[3]);
    $c_tel_no=explode(':',$cust_info[4]);
    $c_address=explode(':',$cust_info[5]);
      $c_cust_country=explode(':',$cust_info[6]);
    $c_cust_pin=explode(':',$cust_info[7]);
    $c_cust_fax=explode(':',$cust_info[8]);

    $c_name=$c_cust_name[1];
    $c_comp=$c_comp_name[1];
    $c_email= $c_cust_email[1];
    $c_tel=$c_tel_no[1];
    $c_mob=$c_cust_mobile[1];
    $cust_address=$c_address[1];
    $c_country=$c_cust_country[1];
    $c_pin=$c_cust_pin[1];
    $c_fax=$c_cust_fax[1];
}
else
{
   $c_name=$details[0]->q_cust_name;
    $c_comp=$details[0]->q_cust_comp;
    $c_email= $details[0]->q_cust_email;
    $c_tel=$details[0]->q_cust_landline;
    $c_mob=$details[0]->q_cust_mob;
    $cust_address='';
    $c_country='';
    $c_pin='';
    $c_fax='';
}
}
?>
<div class="col-md-12 col-sm-12 table-rows-border reason_lost">
    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Company Name :</label>
    <input type='text' name="c_comp_name" value="<?php if(!empty($c_comp)){echo $c_comp;};?>" class="form-control "/>
    </div>
    </div>

    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Customer Name :</label>
    <input type='text' name="c_cust_name" value="<?php if(!empty($c_name)){echo $c_name;};?>" class="form-control "/>
    </div>
    </div>

     <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Customer Email(Company Email):</label>
    <input type='text' name="c_cust_email"  value="<?php if(!empty($c_email)){echo $c_email;};?>"class="form-control"/>
    </div>
    </div>

     <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Customer Mobile(Company Mobile):</label>
    <input type='text' name="c_cust_mobile"  value="<?php if(!empty($c_mob)){echo $c_mob;};?>"class="form-control"/>
    </div>
    </div>

    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Tel No:</label>
    <input type='text' name="c_tel_no" required=""  value="<?php if(!empty($c_tel)){echo $c_tel;};?>"class="form-control"/>
    </div>
    </div>

      <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess" >Address:</label>
    <textarea class="form-control" rows="5" name="c_address"><?php if(!empty($cust_address)){echo $cust_address;};?></textarea>
    </div>
  </div>

  </div>

<div class="col-md-12 col-sm-12 table-rows-border reason_lost">

    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Customer Country :</label>
      <select data-plugin-selectTwo  class="form-control populate "
     name="c_cust_country" >
<option value="">Choose</option>
<?php
foreach($country as $pr)
{
  ?>
   <option value="<?php echo $pr->country_id;?>" <?php if(!empty($c_country)){if($c_country==$pr->country_id){echo "selected";}};?> > <?php echo $pr->name;?> </option> 
  <?php
}
?> 
 </select>
    </div>
    </div>

    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Pin :</label>
    <input type='text' name="c_cust_pin" value="<?php if(!empty($c_pin)){echo $c_pin;};?>" class="form-control "/>
    </div>
    </div>

    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Fax Number :</label>
    <input type='text' name="c_cust_fax" value="<?php if(!empty($c_fax)){echo $c_fax;};?>" class="form-control"/><br/><br/>
    </div>
    </div>
  </div>

  <div class="col-md-12 col-sm-12 table-rows-border">
  <div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Is Notify Party Same as Consignee:<abbr class="required">*</abbr></label>
<div class="col-md-8">
 <input type="radio" name="same_notify" value="1" <?php if(!empty($details[0]->q_notify_val)){if($details[0]->q_notify_val=='1'){echo "checked";}}else{echo "checked";};?>>Yes<br>
    <input type="radio" name="same_notify" value="2" <?php if(!empty($details[0]->q_notify_val)){if($details[0]->q_notify_val=='2'){echo "checked";}};?>> No 
  <div class="form_error">  </div>  
</div>
</div>

</div>
</div>
<?php 
if(!empty($details[0]->q_id))
{
if(!empty($details[0]->proforma_notify_cust_details))
{
$notify_info=explode('$#$',$details[0]->proforma_notify_cust_details);

  $n_comp_name=explode(':',$notify_info[0]);
    $n_cust_name=explode(':',$notify_info[1]);
     $n_address=explode(':',$notify_info[2]);
    $n_cust_tel=explode(':',$notify_info[3]);
   
    $n_country=explode(':',$notify_info[4]);
    $n_cust_pin=explode(':',$notify_info[5]);
    $n_cust_fax=explode(':',$notify_info[6]);

    $cn_name=$n_cust_name[1];
    $cn_comp=$n_comp_name[1];
    $cn_tel=$n_cust_tel[1];
    $ncust_address=$n_address[1];
    $cn_country=$n_country[1];
    $cn_pin=$n_cust_pin[1];
    $cn_fax=$n_cust_fax[1];
}

}
?>
  <br/><br/><br/>
  <div class="notif_party" <?php if(!empty($details[0]->q_notify_val)){if($details[0]->q_notify_val=='2'){echo "style='display: block;'";}}else{echo "style='display: none;'";};?> >
<h4> Details of Notify Party </h4><br/>
    <div class="col-md-12 col-sm-12 table-rows-border ">
      <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Notify Company Name :</label>
    <input type='text' name="n_comp_name" value="<?php if(!empty($cn_comp)){echo $cn_comp;};?>" class="form-control "/>
    </div>
    </div>

    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Notify Customer Name :</label>
    <input type='text' name="n_cust_name" value="<?php if(!empty($cn_name)){echo $cn_name;};?>" class="form-control "/>
    </div>
    </div>

     <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Notify Customer Address :</label>
    <textarea class="form-control " rows='5' name="n_address"><?php if(!empty($ncust_address)){echo $ncust_address;};?></textarea>
    </div>
    </div>

    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Notify Telephone No. :</label>
    <input type='text' name="n_cust_tel" value="<?php if(!empty($cn_tel)){echo $cn_tel;};?>" class="form-control "/>
    </div>
    </div>

     <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Notify Country :</label>
     <select data-plugin-selectTwo  class="form-control populate "
     name="n_country" >
<option value="">Choose</option>
<?php
foreach($country as $pr)
{
  ?>
   <option value="<?php echo $pr->country_id;?>" <?php if(!empty($cn_country)){if($cn_country==$pr->country_id){echo "selected";}};?> > <?php echo $pr->name;?> </option> 
  <?php
}
?> 
 </select>
    </div>
    </div>

    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Notify Pin :</label>
    <input type='text' name="n_cust_pin" value="<?php if(!empty($cn_pin)){echo $cn_pin;};?>" class="form-control "/>
    </div>
    </div>

    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Notify FAX :</label>
    <input type='text' name="n_cust_fax" value="<?php if(!empty($cn_fax)){echo $cn_fax;};?>" class="form-control "/>
    </div>
    </div>
</div>
</div>

<br/><br/><br/>
<h4> Details for Export Invoice </h4><br/>
    <div class="col-md-12 col-sm-12 table-rows-border reason_lost">
      <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Country of Orgin</label>
    <select multiple data-plugin-selectTwo class="form-control populate" name='q_orgin_country[]'>
<?php
if(!empty($details[0]->q_country_orgin))
{
  $aray_orgin=explode(',',$details[0]->q_country_orgin);
}
foreach($country as $pr)
{
  ?>
   <option value="<?php echo $pr->country_id;?>" <?php if(!empty($details[0]->q_country_orgin)){if(in_array($pr->country_id, $aray_orgin)){echo "selected";}};?> > <?php echo $pr->name;?> </option> 
  <?php
}
?> 
</select>
    </div>
    </div>

      <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Country of Final Destination</label>
   <select multiple data-plugin-selectTwo  class="form-control populate "
     name="q_final_country[]" >
  <option value="">Choose</option>
<?php
if(!empty($details[0]->q_country_final))
{
  $aray_final=explode(',',$details[0]->q_country_final);
}
foreach($country as $pr)
{
  ?>
   <option value="<?php echo $pr->country_id;?>" <?php  if(!empty($details[0]->q_country_final)){if(in_array($pr->country_id, $aray_final)){echo "selected";}};?> > <?php echo $pr->name;?>  </option> 
  <?php
}
?>
 </select>
    </div>
    </div>

      <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Country of Loading </label>
   <select data-plugin-selectTwo  class="form-control populate "
     name="country_loading" onchange="port_data('orgin')">
  <option value="">Choose</option>
<?php
foreach($country as $pr)
{
  ?>
   <option value="<?php echo $pr->country_id;?>" <?php  if(!empty($details[0]->q_country_loading)){if($details[0]->q_country_loading==$pr->country_id){echo "selected";}};?> > <?php echo $pr->name;?>  </option> 
  <?php
}
?>
 </select>
    </div>
    </div>
    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Port of Loading</label>
    <div class="loading">
    <?php if(!empty($details[0]->q_port_orgin))
    {
      ?>
      <select data-plugin-selectTwo  class="form-control populate "
     name="q_port_load" >
  <option value="">Choose</option>
<?php
foreach($port_org as $pr)
{
  ?>
   <option value="<?php echo $pr['pid'];?>" <?php  if(!empty($details[0]->q_port_orgin)){if($details[0]->q_port_orgin==$pr['pid']){echo "selected";}};?> > <?php echo $pr['pname'];?>  </option> 
  <?php
}
?>
 </select>
      <?php
    }
   ?>
  </div>
    </div>
    </div>

  </div>

    <div class="col-md-12 col-sm-12 table-rows-border reason_lost">
  
  <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Country of Discharge </label>
   <select data-plugin-selectTwo  class="form-control populate "
     name="country_discharge" onchange="port_data('final')">
  <option value="">Choose</option>
<?php
foreach($country as $pr)
{
  ?>
   <option value="<?php echo $pr->country_id;?>" <?php  if(!empty($details[0]->q_country_discharge)){if($details[0]->q_country_discharge==$pr->country_id){echo "selected";}};?> > <?php echo $pr->name;?>  </option> 
  <?php
}
?>
 </select>
    </div>
    </div>

    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Port of Discharge</label>
      <div class="discharge">
     <?php if(!empty($details[0]->q_port_final))
    {
      ?>
      <select data-plugin-selectTwo  class="form-control populate "
     name="q_port_final" >
  <option value="">Choose</option>
<?php
foreach($port_final as $pf)
{
  ?>
   <option value="<?php echo $pf['pid'];?>" <?php  if(!empty($details[0]->q_port_final)){if($details[0]->q_port_final==$pf['pid']){echo "selected";}};?> > <?php echo $pf['pname'];?>  </option> 
  <?php
}
?>
 </select>
      <?php
    }
   ?>
  </div>
    
    </div>
    </div>
  </div>

  <div class="col-md-12 col-sm-12 table-rows-border reason_lost">
    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Invoice Number</label>
   <input name="inv_number" value="<?php if(!empty($details[0]->q_inv_no)){echo $details[0]->q_inv_no;};?>"  class="form-control" >
    </div>
    </div>

    <div class="col-md-6">
    <div class="form-group">
       <?php
  if(!empty($details[0]->q_inv_date))
  $converted_date_delivry = date("m/d/Y",strtotime($details[0]->q_inv_date));
  ?>
    <label class="control-label" for="inputSuccess">Invoice Date</label>
    <?php if(!empty($details[0]->q_inv_date))
    {?>
    <input name="inv_date" value="<?php if(!empty($details[0]->q_inv_date)){echo $converted_date_delivry;};?>"   class="form-control" id='datetimepicker5' >
    <?php
  }
  else{?>
<input name="inv_date"  class="form-control" id='datetimepicker4' >
    <?php
  }?>
    </div>
    </div>
  </div>

    <div class="col-md-12 col-sm-12 table-rows-border reason_lost">
    <div class="col-md-6">
    <div class="form-group">
    <label class="control-label" for="inputSuccess">Delivery Condition</label>
    <input type='text' value="<?php if(!empty($details[0]->q_deliver_condition)){echo $details[0]->q_deliver_condition;};?>"  name="delivery_cond" class="form-control "/>
    </div>
    </div>
    
  </div>
				</div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm</button>
               <button class="<?php echo base_url('list-porforma');?>">Return</button>
               <?php echo form_close();?>
            </div>
        
<!------------modal due till date ends----------->
</div>
</section>

</section>
</div>

</section>
<?php $this->load->view('admin/sales/script_arabic_word');?>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

   <script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>


<script type="text/javascript">
$(document).ready(function()
  {
     var coverted_arabic='';
    var total_price=$("input[name='total_price_final']").val();

   var coverted_arabic=convert_number(total_price,'female');
   console.log(coverted_arabic);
   $('input[name="converted_ar"]').val(coverted_arabic);


    $('input:radio').change(function() {
      var ir_delivery_type = $("input[name='same_notify']:checked").val();
      if(ir_delivery_type=="2")
      {
        $('.notif_party').show();
      }
      if(ir_delivery_type=="1")
      {
        $('.notif_party').hide();
      }   
      });
});

  function port_data(type) {
    if(type=="orgin")
    {
  var country_id=$('select[name="country_loading"]').val();  
    }
    else
    {
 var country_id=$('select[name="country_discharge"]').val();  
    }
      jQuery.ajax({
                     url:"<?php echo base_url().'Quotation_controller/get_port_details';?>",
                    type:"post",
                     data:{"country_id":country_id,"type":type},
                    success:function(result)
                    {
                     if(result)
                      {
                        if(type=="orgin")
                        {
                          $('.loading').html(result);
                          $('select').select2();
                        }
                        else
                        {
                          $('.discharge').html(result);
                          $('select').select2();
                        }
                  //    console.log(returndata);

                      }
                    }
                 }); 
  }

</script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  
<script type="text/javascript">
          $(function () {
                $('#datetimepicker4').datepicker().datepicker("setDate", new Date());
                $('#datetimepicker5').datepicker().datepicker();
            });
        </script>


</body>
</html>