<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
 

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>





<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
.countrypicker{
	max-height:100px;
}
.fa-whatsapp  {
  color:#fff;
  background:
  linear-gradient(#25d366,#25d366)10px 84%/15px 15px no-repeat,
  radial-gradient(#25d366 59%,transparent 0);
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>File Manager</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Add Files</span></li>
<li><span>Upload</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Upload Files</h2>
</header>
<div class="panel-body">
	<?php echo form_open_multipart('submit_bus_card','class="form-horizontal form-bordered"');?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

    <input type="hidden" name="user_id" value="<?php if(!empty($result[0]->log_id)){echo $result[0]->log_id;};?>">
  
   <input type="hidden" class="country_val_selected" name="country_val" value="">

<div class="row">

<div class="col-md-12 table-rows-border">
		
		<div class="col-md-12 col-sm-12">

  <div class="form-group">


  <p>Upload files here.Make sure the file size is less than 2MB.</p>
 <input id="file-1" name="files[]" type="file"  multiple  required />
 <div class="form_error">  <?php echo $this->session->flashdata('confrm_pwd');?></div>
</div> 
</div>

<div class="col-md-12 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">File Name<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type='text' name="file_name" placeholder="enter file name here" class="form-control" value="" required />
<div class="form_error">  <?php echo $this->session->flashdata('pwd');?></div>
</div>
</div>
	
</div>

</div>


</div>




<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>


<?php echo form_close();?>
</div>
</section>

</div>
</div>

<table class="table table-bordered table-striped mb-none" id="datatable-default">
<thead>
<tr>
	<th style="width: 10%;"></th>

<th>File Name</th>

<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
if(!empty($result))
{
$j=1;
foreach($result as $t)
{

$pages=$t->bc_img;
$images=explode(',',$pages);

?>
<tr class="gradeX">
			<td><?php echo $j++;?></td>
				<td><a href="<?php echo base_url('download_files/'.$t->bc_id);?>">
        <?php echo $t->bc_name;?></a></td>
			 <td>
<a href="delete_bus_card/<?php echo $t->bc_id;?>" class="delete-row"><i class="fa fa-trash"></i></a>
	
			</td> 
	</tr>

<?php 
}
}
else{}
?>

</tbody>
</table>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="https://code.jquery.com/jquery-3.3.1.min.js" crossorigin="anonymous"></script>
 <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript"></script>

 <script>
            $(document).on('ready', function () {
                $("#file-1").fileinput();
            });
        </script>

<script type="text/javascript">

$(document).ready(function()
{

    $("#file-1").fileinput({
    	// 'theme': 'fas',
     //        'showPreview': true,
     //         'showUpload': false,
     //      'showRemove':true,
     //        'maxFileSize': 5000,
     //    'maxFilesNum': 10,
     //        'allowedFileExtensions': ['jpg', 'png', 'gif'],

        theme: 'fas',
         showUpload: false,
          showCancel: true,
        overwriteInitial: false,
        maxFileSize: 3000,////max file size  is 2000 kb,else will show error
        maxFilesNum: 10,


        // "success":true,
        //allowedFileTypes: ['image', 'video', 'flash'],
       
    });

});
    
     $(".file").on('fileselect', function(event, n, l) {
     alert('File Selected. Name: ' + l + ', Num: ' + n);
     });
     
   
 
</script>
</html>