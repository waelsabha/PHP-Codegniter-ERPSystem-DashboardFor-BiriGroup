<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<style type="text/css">
	.form_error 
{font-size: 18px;font-family:Arial;color:red;font-style:italic;}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 18px;font-family:Arial;color:red;font-style:italic;}
.success
{font-size: 18px;font-family:Arial;color:green;font-style:italic;}

.datepicker{z-index:18000 !important;}
.dropdown-divider
{
	border-bottom: 1px solid #08c;
}

.datepicker table tr td.today
{
    background-color:blue;
    color:white;
    border-radius: 50%;
}


@-webkit-keyframes glowing {
  0% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -webkit-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
}

@-moz-keyframes glowing {
  0% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -moz-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
}

@-o-keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

@keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

</style>
<style type="text/css">
    .dot {
  height: 25px;
  width: 25px;
  border-radius: 50%;
  display: inline-block;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>
<div class="inner-wrapper">
<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Orders</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Item Request</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg">
<div class="row">
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-secondary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-shopping-cart"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">New Request</h4>
<div class="info">
<strong>
<?php if(!empty($new_req)){print_r($new_req);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-info">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-thumbs-up"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Accepted Req</h4>
<div class="info">
<strong>
<?php if(!empty($approved_req)){print_r($approved_req);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-warning">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-gears"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Req Ordered</h4>
<div class="info">
<strong>
<?php if(!empty($req_ordered)){print_r($req_ordered);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-primary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-truck"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Ready to Ship</h4>
<div class="info">
<strong>
<?php if(!empty($ready_ship)){print_r($ready_ship);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-tertiary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-check"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Shipped</h4>
<div class="info">
<strong>
<?php if(!empty($shipped)){print_r($shipped);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>

<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-danger">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-trash-o"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Rejected Req</h4>
<div class="info">
<strong>
<?php if(!empty($rejected)){print_r($rejected);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>

<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-success">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-check"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Completed</h4>
<div class="info">
<strong>
<?php if(!empty($completed)){print_r($completed);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>




<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-primary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-archive" aria-hidden="true"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Ready Pallet</h4>
<div class="info">

<string>

<?php if(!empty($cbm_total)){print_r($cbm_total);};?>
 </string>
 
</div>
</div>

</div>
</div>
</div>
</section>
</div>




</div>
</div>

</div>

 <div class="form_error">
            <p class="errors"><b>  <?php echo $this->session->flashdata('errors');?></b></p>
            <p class="success"><b><?php echo $this->session->flashdata('success');?></b></p>
 </div>
 <input type="hidden" name="base_url" value="<?php echo base_url();?>">

<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">List NEW Item Request <!-- <span class="pull-right"><button class="btn btn-primary btn-sm" type="button" onclick="load_completed()">Load Completed</button> --></h2>
</header>

<div class="panel-body">
  <?php 
if(empty($page_type))
{?>
<?php $this->load->view('admin/sales/req_new_uk',$result);?>
<?php
}
else
{?>
  
<?php $this->load->view('admin/sales/req_others_uk',$result);?>
  <?php
}?>
</div>
</section>
<?php 
if(empty($page_type))
{?>
<?php $this->load->view('admin/sales/req_accepted_uk',$result);?>
<?php $this->load->view('admin/sales/req_ordered_uk',$result);?>
<?php $this->load->view('admin/sales/req_ready_to_ship_uk',$result);?>
<?php $this->load->view('admin/sales/req_shipped_uk',$result);?>
<?php
}?>
<!-- Button trigger modal 3 accepted-->
 <script type="text/javascript">
  function adjust_qnty_acepted(id)
{
    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('Item_request/current_prd_qnty_uk/')?>",
        type: "POST",
        data: {"item_re_id":id},
        success: function(data)
        {
          $('.view_data_modal').html(data);
            $('#modal_accepted').modal('show'); // show bootstrap modal when complete loaded
          },
    });
}

</script>
<script>

      function adjust_qnty_acepted_ksa(id)
{
    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('Item_request/current_prd_qnty_ksa/')?>",
        type: "POST",
        data: {"item_re_id":id},
        success: function(data)
        {
          $('.view_data_modal').html(data);
            $('#modal_accepted_ksa').modal('show'); // show bootstrap modal when complete loaded
          },
    });
}
    </script>
<div class="modal modal-lg fade" id="modal_accepted" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">View data</h3>
            </div>
            <?php echo form_open('Item_request/submit_adj_qnty_uk');?>
          
            <div class="modal-body modal-lg form ">
              <div class="row view_data_modal" ></div>
            </div>
 <footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button" class="btn btn-primary" onclick="get_prd_qnty();" >Submit</button>
<button class="btn btn-default modal-dismiss"  data-dismiss="modal">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
        </div><!-- /.modal-content -->

    </div><!-- /.modal-dialog -->
</div>

<div class="modal modal-lg fade" id="modal_accepted_uk" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">View data</h3>
            </div>
            <?php echo form_open('Item_request/submit_adj_qnty_uk');?>
          
            <div class="modal-body modal-lg form ">
              <div class="row view_data_modal" ></div>
            </div>
 <footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button" class="btn btn-primary" onclick="get_prd_qnty_ksa();" >Submit</button>
<button class="btn btn-default modal-dismiss"  data-dismiss="modal">Cancel</button>
</div>
</div>
</footer>
<?php echo form_close();?>
        </div><!-- /.modal-content -->

    </div><!-- /.modal-dialog -->
</div>
<!----end modal--->

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>



<script type="text/javascript">
          $(function () {
  $(".load-image").hide();
                //$('.datetimepicker4').datepicker().datepicker("setDate", new Date());
                $('.datetimepicker5').datepicker({
  defaultDate: null,
  todayHighlight: true,
   startDate: new Date() ,
});
            });

    $(document).ready(function()
    {
      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
	} );
    } );     

function load_completed()
{
 jQuery.ajax({
     url:"<?php echo base_url().'Item_request/load_completed_req_uk';?>",
   	type:"post",
     success:function(result)
    {
    	$('.data_item_req').html(result);
    }
});
}


  function ordered_file_upload(id,type)
     {
       var base_url=$('input[name="base_url"]').val();
    
      var file_data = $('.ordered_prd_file_'+id).prop('files')[0];
      var expected_date=$('input[name="expected_date"]').val();
      var tracking_details=$('input[name="tracking_details"]').val();
      var tracking_code=$('input[name="tracking_code"]').val();

      if(expected_date!='' && file_data!='')
      {
      var form_data = new FormData();

        form_data.append('ordered_file_data', file_data);
        form_data.append('req_id', id);
        form_data.append('req_type', type);
        form_data.append('expected_date', expected_date);
        form_data.append('tracking_details', tracking_details);
        form_data.append('tracking_code', tracking_code);

      $.ajax({
              url:"<?php echo base_url().'Item_request/ordered_file_upload_uk';?>",
              data:form_data,
              processData: false,
              contentType: false,
              type: 'post',
               beforeSend: function(){
                 $(".load-image").show();
               },
               complete: function(){
                 $(".load-image").hide();
               },
              success:function(result)
              {
                if(result)
                {
                	if(result)
                	{
                		location.reload();
                	}

                }
                else
                {
                	alert('Error in upload. Please check file type/size and try again');
                }
              }
     		});
  		}
  		else
  		{
  			$('.error_msg').html('Expected date and file upload is mandatory');
  		}
    }



      function ordered_file_upload_ksa(id,type)
     {
       var base_url=$('input[name="base_url"]').val();
    
      var file_data = $('.ordered_prd_file_'+id).prop('files')[0];
      var expected_date=$('input[name="expected_date"]').val();
      var tracking_details=$('input[name="tracking_details"]').val();
      var tracking_code=$('input[name="tracking_code"]').val();

      if(expected_date!='' && file_data!='')
      {
      var form_data = new FormData();

        form_data.append('ordered_file_data', file_data);
        form_data.append('req_id', id);
        form_data.append('req_type', type);
        form_data.append('expected_date', expected_date);
        form_data.append('tracking_details', tracking_details);
        form_data.append('tracking_code', tracking_code);

      $.ajax({
              url:"<?php echo base_url().'Item_request/ordered_file_upload_ksa';?>",
              data:form_data,
              processData: false,
              contentType: false,
              type: 'post',
               beforeSend: function(){
                 $(".load-image").show();
               },
               complete: function(){
                 $(".load-image").hide();
               },
              success:function(result)
              {
                if(result)
                {
                    if(result)
                    {
                        location.reload();
                    }

                }
                else
                {
                    alert('Error in upload. Please check file type/size and try again');
                }
              }
            });
        }
        else
        {
            $('.error_msg').html('Expected date and file upload is mandatory');
        }
    }

function show_mail_sending_rq()
{
	 $(".load-image").show();
}

    function get_prd_qnty()
    {
    	var acptd_qnty=$('table tbody tr td input[name="accepted_qnty[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
    	var item_req_id=$('input[name="item_req_id_accepted_data"]').val();

    	var form_data = new FormData();

    
        form_data.append('acptd_qnty', acptd_qnty);
        form_data.append('req_id', item_req_id);
        $.ajax({
              url:"<?php echo base_url().'Item_request/submit_adj_qnty_uk';?>",
              data:form_data,
              processData: false,
              contentType: false,
              type: 'post',
              success:function(result)
              {
                if(result)
                {
                	if(result)
                	{
                		 $('.close').trigger('click');
                        var stack_bar_top = {"dir1": "down", "dir2": "right", "push": "top", "spacing1": 0, "spacing2": 0};
                        var notice = new PNotify({
                            title: 'Accepted',
                            text: 'Accepted Request with update in quantity, Mail send on update.',
                            type: 'success',
                            addclass: 'stack-bar-top',
                            stack: stack_bar_top,
                            width: "100%"
                          });
                		//console.log(result);
                		location.reload();
                	}
                }
                else
                {
                	alert('Error in quantity. Please make sure the accepted quantity is less than/equal to original');
                }
              }
     		});

    }


      function get_prd_qnty_ksa()
    {
        var acptd_qnty=$('table tbody tr td input[name="accepted_qnty[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
        var item_req_id=$('input[name="item_req_id_accepted_data"]').val();

        var form_data = new FormData();

    
        form_data.append('acptd_qnty', acptd_qnty);
        form_data.append('req_id', item_req_id);
        $.ajax({
              url:"<?php echo base_url().'Item_request/submit_adj_qnty_ksa';?>",
              data:form_data,
              processData: false,
              contentType: false,
              type: 'post',
              success:function(result)
              {
                if(result)
                {
                    if(result)
                    {
                         $('.close').trigger('click');
                        var stack_bar_top = {"dir1": "down", "dir2": "right", "push": "top", "spacing1": 0, "spacing2": 0};
                        var notice = new PNotify({
                            title: 'Accepted',
                            text: 'Accepted Request with update in quantity, Mail send on update.',
                            type: 'success',
                            addclass: 'stack-bar-top',
                            stack: stack_bar_top,
                            width: "100%"
                          });
                        //console.log(result);
                        location.reload();
                    }
                }
                else
                {
                    alert('Error in quantity. Please make sure the accepted quantity is less than/equal to original');
                }
              }
            });

    }
  </script>



</body>
</html>