<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>
 
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Invoice</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Pages</span></li>
<li><span>Request Status</span></li>
</ol>
<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
</div>
</header>
<?php
if(!empty($result && $prds))
{?>
<section class="panel">
<div class="panel-body">
<div class="invoice">
<header class="clearfix">
<div class="row">
<div class="col-sm-6 mt-md">
<h2 class="h2 mt-none mb-sm text-dark text-bold">Item Request Number</h2>
<h4 class="h4 m-none text-dark text-bold">#<?php echo $result[0]->ir_req_no;?></h4>
</div>

</div>
</header>
<div class="col-md-12 col-sm-12">
	<h2 class="error-code text-dark text-center text-semibold m-none">Success <i class="fa fa-thumbs-up"></i></h2>
	</div>
<div class="bill-info">
<div class="row">
<div class="col-md-6">
<div class="bill-to">
<p class="h5 mb-xs text-dark text-semibold">Request Status: <h4>
	<?php

	$req_sts_value='';
	switch($result[0]->ir_req_status)
	{
		case '1':
		$req_sts_value="New Item Request";
		break;

		case '2':
		$req_sts_value="Request Accepted";
		break;

		case '3':
		$req_sts_value="Request Ordered";
		break;

		case '4':
		$req_sts_value="Ready to Ship";
		break;

		case '5':
		$req_sts_value="Shipped";
		break;

		case '6':
		$req_sts_value="Request Rejected";
		break;
	}

	 echo $req_sts_value;?></h4></p>
	 <?php
	 if($result[0]->ir_req_status=="1")
	 	{?>
<p class=" mb-xs text-dark text-semibold">Expected date of shipping : <h4><?php echo $result[0]->ir_order_date;?></h4></p>
<?php
}
elseif($result[0]->ir_req_status=="5")
{
?>
<p class=" mb-xs text-dark text-semibold">Expected Time of Arrival(ETA) : <h4><?php echo $result[0]->eta;?></h4></p>
<?php
}
else{}
?>
<p>Your order is submitted to <br/>
	<ul>
		<li>Purchase Department</li>
</ul>
</p>

</div>
</div>
<div class="col-md-6">
<div class="bill-data text-right">

<p>Sales Person:<?php echo $result[0]->ir_user_created;?></p>
<p>Item Type :<?php echo $result[0]->ir_delivery_type;?></p>
<p>Exact delivery date:<?php echo $result[0]->ir_exact_delivery_date;?></p>

</div>
</div>

<div class="col-md-12 col-sm-12">
	<p><span class="h5 mb-xs text-dark text-semibold">Extra Details:</span><?php echo $result[0]->ir_extra_details;?></p>
</div>
	<div class="col-md-12 col-sm-12">
<p>An email is send to the concerned person,notifying them about the item request. Please be patient for the response from them. You will be able to see the status of the current order within 4 hours. By the time if there is any edit you can do that now. For that go to the "List item request" section. Thank you!</p>
</div>
</div>
</div>
<h4>Product Details</h4>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<th></th>
	<th>Product</th>
	<th>Quantity </th>
	<th>Remarks</th>
	
</tr>
</thead>
<tbody>
	<?php
	$i=1;
foreach($prds as $index=>$p)
{
	foreach($p as $indx2=>$q)
	{
	$pname=explode('|~~|',$q->pname);	
	$qnty=explode('|#|',$result[0]->ir_prd_qnty);
$rmks=explode('|#|',$result[0]->ir_prd_extra_data);
		?>
<tr>
<td><?php echo $i++;?></td>
<td><?php echo $pname[0].'<br/>'.$pname[1];?></td>
<td><?php echo $qnty[$index];?></td>
<td><?php echo $rmks[$index];?></td>
</tr>
<?php
}
}
?>
</tbody>
</table>
</div>

</div>

</div>
</section>

<?php
}
?>
<a href="<?php echo base_url('list-item-request');?>" class="btn btn-success btn-round waves-effect waves-light">
Check List Item Request</a>
</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="text/javascript"></script>

</body>


</html>