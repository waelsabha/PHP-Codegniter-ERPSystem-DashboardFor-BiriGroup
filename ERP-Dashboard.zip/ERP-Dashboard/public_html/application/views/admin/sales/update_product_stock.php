<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
.countrypicker{
	max-height:100px;
}
.fa-whatsapp  {
  color:#fff;
  background:
  linear-gradient(#25d366,#25d366)10px 84%/15px 15px no-repeat,
  radial-gradient(#25d366 59%,transparent 0);
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Update Stock</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Update Product Stock </span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<div class="tabs">
<ul class="nav nav-tabs nav-justified">
<li class="active">
<a href="#popular10" data-toggle="tab" class="text-center"><i class="fa fa-star"></i> Upload Excel</a>
</li>
<li>
<a href="#recent10" data-toggle="tab" class="text-center">Show Data Uploaded</a>
</li>
</ul>
<div class="tab-content">
<div id="popular10" class="tab-pane active">
  <div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Excel Upload Form</h2>
</header>
<div class="panel-body">
  <?php echo form_open_multipart('submit_product_update_stock','class="form-horizontal form-bordered"');?>
    <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="form-group">
  <label class="col-md-3 control-label">File Upload</label>
  <div class="col-md-6">
  <div class="fileupload fileupload-new" data-provides="fileupload">
  <div class="input-append">
  <div class="uneditable-input">
  <i class="fa fa-file fileupload-exists"></i>
  <span class="fileupload-preview"></span>
  </div>
  <span class="btn btn-default btn-file">
  <span class="fileupload-exists">Change</span>
  <span class="fileupload-new">Select file</span>
  <input type="file" name="userfile">
  </span>
  <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
  </div>
  </div>
  <small style="color: red;">Upload Excel format only, which is downloaded from below</small>
  </div>
</div>
<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>


<?php echo form_close();?>
</div>
</section>

</div>
</div>

        <div class="row">
            <div class="col-md-12">
            <section class="panel">
            <header class="panel-heading">
            <h2 class="panel-title">Download excel file</h2>
            </header>
            <div class="panel-body">

              <h4>
               <a href="<?php echo base_url('excel_download_sample_update_stock');?>" >Click here to download the excel sheet.</a>
               </h4>
              <p> After downloading the excel, please update the same with current Dubai and RAK product stocks (every day) and upload the same file.</p>            
            </div>
            </section>
            </div>
          </div>
    

</div>
<div id="recent10" class="tab-pane">
<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default-2">
<thead>
<tr>
<th></th>
<th>Item Code</th>
<th>DXB Qnty</th>
<th>RAK Qnty</th>
</tr>
</thead>
<tbody>
<?php
    $i=1;
    if(!empty($prd_stock))
    {
  foreach($prd_stock as $index=>$q)
  { 
  ?>
<tr>
<td><?php echo $i++;?></td>
<td><?php echo $q->ps_prd_code;?> </td> 
<td><?php echo $q->ps_dxb_qnty;?> </td>
<td><?php echo $q->ps_rak_qnty;?> </td>
</tr>
<?php
}
}
?>
</tbody>
</table>
</div>
</div>

</div>
</div>
</div>
</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>


<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>

<script type="text/javascript">
 $(document).ready(function() {
  $('#datatable-default-2').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5'
        ],
         "pageLength": 50,
    } );
} );
</script>
</body>
</html>