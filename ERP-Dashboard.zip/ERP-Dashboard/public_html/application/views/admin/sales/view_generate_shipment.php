<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<style type="text/css">
	.form_error 
{font-size: 18px;font-family:Arial;color:red;font-style:italic;}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 18px;font-family:Arial;color:red;font-style:italic;}
.success
{font-size: 18px;font-family:Arial;color:green;font-style:italic;}

.datepicker{z-index:18000 !important;}

</style>
<style type="text/css">
    .dot {
  height: 25px;
  width: 25px;
  border-radius: 50%;
  display: inline-block;
}
</style>
</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>View Shipment Details</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>View</span></li>
<li><span>Shipment Details </span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">View Shipment Details </h2>

</header>


<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors"><b>  <?php echo $this->session->flashdata('errors');?></b></p>
            <p class="success"><b><?php echo $this->session->flashdata('success');?></b></p>
    </div>
<div class="data_result">
<table class="table table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th></th>
	<th>Item Request</th>
	
	<th>Item Details</th>
	
</tr>
</thead>
<tbody>
<?php
$i=1;
foreach($shipment_details as $index1=>$t)
{
	$org_qnty=explode('|#|',$t->ir_prd_qnty);
	$shipped_qnty=explode(',',$t->gsd_prd_qty_shipped);
	$remianing_qnty=explode(',',$t->gsd_prd_qty_remaining);
?>
<tr class="gradeX">
	
			<td><?php echo $i++;?></td>
			<td><?php echo $t->ir_req_no;?></td>			
			<td>
				<table class="table table-bordered">
					<thead>
						<th>Item Name</th>
						<th>Original Quantity</th>
						<th>Quantity Shipped</th>
						<th>Remaining Quantity</th>
					</thead>
					<tbody>
						<?php
						foreach($prd_data[$index1] as $index2=>$p)
						{?>
						<tr>
							<td><?php echo $p[0]->pname;?></td>
							<td><?php echo $org_qnty[$index2];?></td>
							<td><?php echo $shipped_qnty[$index2];?></td>
							<td><?php echo $remianing_qnty[$index2];?></td>
						</tr>
						<?php
					}?>
					</tbody>
				</table>
			</td>	
<?php 
}
?>
</tbody>
</table>
</div>

</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>



<script type="text/javascript">
          $(function () {

                //$('.datetimepicker4').datepicker().datepicker("setDate", new Date());
                $('.datetimepicker5').datepicker({
  defaultDate: null
});
            });

    $(document).ready(function()
    {
      
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 50,
    responsive: true,
     "scrollX": true,
	} );
    } );     

  </script>


</body>
</html>