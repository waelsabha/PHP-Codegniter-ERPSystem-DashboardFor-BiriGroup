<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<style type="text/css">
  .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
  border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
  color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Generate Item Request</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span> Item Request</span></li>
<li><span>Generate</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Generate Item Request</h2>
</header>
<div class="panel-body">
  <?php echo form_open_multipart('submit_generate_shipment','class="myform"');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
  
    <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

<input type="hidden" name="edit_item_req_id" value="<?php if(!empty($result[0]->ir_id)){echo $result[0]->ir_id;};?>">

<!-- <input type='hidden' name='prd_id_update[]' value="<?php if(!empty($result[0]->po_prd_name)){echo $result[0]->po_prd_name;};?>"> -->

<div class="row">
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Generate Shipment No <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type="text" name="gnr_no" value=""  class="form-control">
 <div class="form_error">  <?php echo $this->session->flashdata('gnr_no');?></div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border ">
  
  <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Shipment Status  <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <select class="form-control" name="shipment_sts" required="">
  <option>Choose</option>
  <option value="2">Accepted</option>
  <option value="3">Ordered</option>
  <option value="4">Ready to Ship</option>
  <option value="5">Shipped</option>
  <option value="6">Rejected</option>
 </select>
 <div class="form_error">  <?php echo $this->session->flashdata('shipment_sts');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">ESD/ETA<abbr class="required">::*::</abbr></label>
 <div class="col-md-8">
<input type='text' value="" name="date_shipment" class="form-control datetimepicker5 " autocomplete="off"  />	
 <div class="form_error">  <?php echo $this->session->flashdata('date_shipment');?></div>
</div>
</div>
</div>

</div>



<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Extra details/notes<abbr class="required">Not mandatory</abbr></label>
<div class="col-md-8">
<textarea name="extra_details" class="form-control editors"></textarea>

  <div class="form_error">  <?php echo $this->session->flashdata('extra_details');?></div>
</div>
</div>
</div>

</div>

<div class="cell_text_data"></div>
<!-- submit_main_form -->

</div>
</section>

<section class="panel panel-featured panel-featured-primary">

<div class="panel-body">
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->

<div class="row">

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Item from Request for shipment<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<small>Type a word or letter then press 'space' key</small>
<select data-plugin-selectTwo class='form-control populate search_product_select' name='search_product_cat' onchange="get_item_req();">
<option></option>
<?php
    foreach($result as $c)
      {
         ?>
    <option value="<?php echo $c->ir_id;?>" ><?php echo $c->ir_req_no?> :: <?php echo $c->ir_req_title?></option>
    <?php
  }?>

 </select>

<div class="form_error">  <?php echo $this->session->flashdata('search_product_cat');?></div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive">  
<table class="table table-bordered mb-none">
  <thead>
    <tr>
      <!--  <th>#</th>  -->
      <th></th>
      <th>Item Request ID</th>
      <th>Item Request Details</th>
    
    </tr>
  </thead>
  <tbody class="table_original">


  </tbody>
</table>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">

<label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
<div class="col-md-8">
  <span class="num_items"> </span>
  <span style="display: none;" class="num_items_sub_table"></span>
</div>

</div>

</div>


<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
<!-- submit_main_form -->

<?php echo form_close();?>
</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script type="text/javascript">
          $(function () {
   //$('.datetimepicker4').datepicker().datepicker("setDate", new Date());
                $('.datetimepicker5').datepicker({
					  defaultDate: null
					});
            });

function get_item_req()
{
	var item_selected=$('select[name="search_product_cat"]').val();
  var item_selected_text=$('select[name="search_product_cat"] option:selected').text();
  var item_details=item_selected_text.split('::');
	var tablecount = $('table tbody tr').length;
  if(tablecount=="0" || tablecount=="")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }
	  jQuery.ajax({
                url:"<?php echo base_url().'Item_request/choose_req';?>",
                type:"post",
                data:{"item_choosed":item_selected},
                success:function(result)
                {
                 // console.log(result);
                var returndata = JSON.parse(result);
                 var markup = "<tr class='table"+table_id+" row_original'>"+
                   "<td>#</td>"+
                  "<td><input type='hidden' name='itemid'>"+item_details[0]+"<input type='hidden' name='item_id[]' value='"+item_selected+"'></td>"+
                  "<td>"+
                  "<table class='table table-bordered test_table' >"+
                  "<thead>"+
                  "<th>Item Name</th>"+
                  "<th>Original Quantity</th>"+
                  "<th>Quantity Shipped</th>"+
                  "<th>Remaining Quantity</th>"+
                  "</thead><tbody>";
                  var ik=1;var sub_table_id;
                      
    $.each(returndata, function(key2,val2)
		      {

            var item_sub_table=$(".num_items_sub_table").text();
           if($.isNumeric(key2))
           {
            if(item_sub_table=='')
                      {
                         sub_table_id='1';
                          $(".num_items_sub_table").text(ik);
                      }
                      else
                      {
                         sub_table_id=parseFloat(item_sub_table)+1;
                         $(".num_items_sub_table").text(sub_table_id);
                      }


					     // var product_full=val2[0]['pname'].split('|~~|');
					     markup +="<tr>"+  	
          "<td><input type='hidden' name='prdids'><input type='hidden' name='prd_id[]' value='"+val2[0]['pid']+"' class='prd_id_selected_"+sub_table_id+"'><span class=''>"+val2[0]['pname']+"</span></td>"+
           "<td>"+returndata['qnty'][key2]+"<input type='hidden' name='org_qnty[]' value='"+returndata['qnty'][key2]+"' class='qnty_original_"+sub_table_id+"'><input type='hidden' name='org_qntys' size='5'></td>"+
           "<td><input type='hidden' name='qntys' size='5'><input type='text' name='qnty_shipped[]' value='0' class='qnty_shipped_"+sub_table_id+"' onkeyup='check_remaining("+sub_table_id+")'></td>"+
          "<td><input type='hidden' name='remaining_qnty' size='5'><input type='text' name='qnty_remaining[]' value='0' class='qnty_remaining_"+sub_table_id+"'></td>"+
          "</tr>";
            }
         	});
					  markup +="</tbody></table></td></tr>";
					   $(".table_original").append(markup);
          }
      });
	  var rowcount = $('table tbody tr').length;
   var current_num_items=$(".num_items").text();
  
   if( table_id!='1' )
   {
    $(".num_items").html(parseInt($(".num_items").text())+1);
    }
    else
    {
     $(".num_items").text('1');
    }
}

function check_remaining(sub_table_id)
{
  var qnty_org=$('.qnty_original_'+sub_table_id).val();
var qnty_shipped=$('.qnty_shipped_'+sub_table_id).val();
  var qnty_remain=$('.qnty_remaining_'+sub_table_id).val();

  var total_remaining=parseFloat(qnty_org)-parseFloat(qnty_shipped);
  $('.qnty_remaining_'+sub_table_id).val(total_remaining);
}

$('.myform').submit(function() {
 // e.preventDefault();
var rowcount = $('.row_original').length;

var item_req_id=$('table tbody tr td input[name="item_id[]"]').map(function(){return $(this).val();}).get().join('|#|');  
var prd_ids=$('table tbody tr td table tbody tr td input[name="prd_id[]"]').map(function(){return $(this).val();}).get().
join('|#|');
var qty_shipped=$('table tbody tr td table tbody tr td input[name="qnty_shipped[]"]').map(function(){return $(this).val();}).
get().join('|#|'); 
var qty_remaining=$('table tbody tr td table tbody tr td input[name="qnty_remaining[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var qnty_orginal=$('table tbody tr td table tbody tr td input[name="org_qnty[]"]').map(function(){return $(this).val();}).get().join('|#|');

//console.log(quantity+' '+package_size+' '+product_id);
$("input[name='prdids']").val(prd_ids);
$("input[name='qntys']").val(qty_shipped);
$("input[name='remaining_qnty']").val(qty_remaining);
$("input[name='itemid']").val(item_req_id);
$("input[name='org_qntys']").val(qnty_orginal);

var ij=0;
var data_var=[];

$('.row_original').each(function() { 
//console.log(key);
 var cellText = $(this).html();   
    $('.cell_text_data').append(cellText).hide(); 
});

 //console.log($('.cell_text_data').text());
//console.log($("input[name='prdids']").val());
//console.log($("input[name='qntys']").val());
//console.log($("input[name='unit_prices']").val());
//console.log($("input[name='total_prices']").val());
 //console.log($("input[name='variation_selected_val']").val());
 
 if(cellText=='')
 return false;
 else
  return true;
 //return false;
  // your code here  
});


</script>          
</body>

</html>
