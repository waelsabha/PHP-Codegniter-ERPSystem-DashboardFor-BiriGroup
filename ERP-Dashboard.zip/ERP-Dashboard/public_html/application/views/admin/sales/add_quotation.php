<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" 
type="text/css"/>
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" 
type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
table input.form-control {
  width: auto;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">
<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Quotation Form </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Quotation Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Quotation Form</h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('submit_quotation_details','class="myform" novalidate','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
 
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

<?php
if(empty($page_name) && !empty($result[0]->q_id))
{
  ?>
<input type="hidden" name="quotation_id" value="<?php if(!empty($result[0]->q_id)){echo $result[0]->q_id;};?>">
<?php
}?>
<input type="hidden" name="quotation_created_by" value="<?php if(!empty($result[0]->q_user_id)){echo $result[0]->q_user_id;};?>">

<input type="hidden" name="inquiry_files" value="<?php if(!empty($result[0]->q_files)){echo $result[0]->q_files;};?>">

<input type="hidden" name="edit_cust_data_id" value="<?php if((!empty($customers_data[0]))){echo $customers_data[0]->sca_id;}?>">

<div class="row">

 <div class="col-md-12 col-sm-12 table-rows-border">
 
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Document No <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<?php
if($this->session->userdata['user']['user_position']=="Sales-Manager" || (($this ->session->userdata['user']['main_dept'])=="Main") )
{?>
 <input type="text" name="ref_no" value="<?php if(!empty($result[0]-> q_ref_no)){echo $result[0]-> q_ref_no;}else{echo $doc_num;}?>" <?php if(empty($result[0]-> q_ref_no)){echo "readonly";};?> class="form-control">
<?php
}
else
{
?>
<input type="text" name="ref_no" value="<?php if(!empty($result[0]-> q_ref_no)){echo $result[0]-> q_ref_no;}else{echo $doc_num;}?>" readonly class="form-control">
<?php
}?>
  
 <div class="form_error">  <?php echo $this->session->flashdata('ref_no');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Date<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
<?php
  if(!empty($result[0]->q_date))
  {
  $converted_date_delivry = date("m/d/Y", strtotime($result[0]->q_date));
}
?>
 <input type='text' name="date_ref" class="form-control" id='datetimepicker4' value="<?php if(!empty($result[0]->q_date)){echo $converted_date_delivry;} ;?>" required />
 
 <div class="form_error">  <?php echo $this->session->flashdata('date_ref');?></div>

</div>
</div>
</div>


</div>




<div class="col-md-12 col-sm-12 table-rows-border">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Company / Customer<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <select data-plugin-selectTwo  class="form-control populate" name="choose_customer">

  <option value="">Choose</option>
  <?php
  foreach($customers as $cd)
  {
   ?>
  <option value="<?php echo $cd->sca_id;?>" <?php if((!empty($customers_data[0]))){if($customers_data[0]->sca_id==$cd->sca_id){echo "selected";}} ?> ><?php echo $cd->sca_cust_company;?> :: <?php echo $cd->sca_cust_name;?> </option> 
   <?php
  }
  ?>
 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('choose_customer');?></div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Quotation Subject<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<textarea class="form-control" name="quote_sub" required> <?php if(!empty($result[0]->q_sub)){echo $result[0]->q_sub;};?></textarea>


  
 <div class="form_error">  <?php echo $this->session->flashdata('quote_sub');?></div>
</div>
</div>
</div>




<div class="col-md-12 col-sm-12 table-rows-border">
 
 <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">If Cash customer-Click here</label>
<div class="col-md-8">
<label class="checkbox-inline">
   <input type="checkbox" name="add_cash_customer" value="1" <?php if(!empty($result)){if((empty($result[0]-> q_cusotmer_id))){echo "checked";}} ?>> Click to add cash-customer
</label>
 <div class="form_error">  <?php echo $this->session->flashdata('add_cash_customer');?></div>
</div>
</div>


<div class="cash_cusotmer_details" <?php if(!empty($result)){ ?>style="display: show;"<?php }else{?>style="display: none;" <?php }?>>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Name <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<input type="text" class="form-control" value="<?php if((!empty($customers_data[0]))){echo $customers_data[0]->sca_cust_name;}else{if(!empty($result[0]->q_cust_name)){echo $result[0]->q_cust_name;} } ?>" name="cash_cust_name">
  
 <div class="form_error">  <?php echo $this->session->flashdata('cash_cust_name');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Company <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<input type="text" class="form-control" value="<?php if((!empty($customers_data[0]))){echo $customers_data[0]->sca_cust_company;}else{if(!empty($result[0]->q_cust_comp)){echo $result[0]->q_cust_comp;}} ?>" name="cash_cust_comp">
  
 <div class="form_error">  <?php echo $this->session->flashdata('cash_cust_comp');?></div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Mobile <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<input type="text" class="form-control" value="<?php if((!empty($customers_data[0]))){echo $customers_data[0]->sca_cust_mobile;}else{if(!empty($result[0]->q_cust_mob)){echo $result[0]->q_cust_mob;}} ?>" name="cash_cust_mob">
  
 <div class="form_error">  <?php echo $this->session->flashdata('cash_cust_mob');?></div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Email <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<input type="text" class="form-control" value="<?php if((!empty($customers_data[0]))){echo $customers_data[0]->sca_cust_email;}else{if(!empty($result[0]->q_cust_email)){echo $result[0]->q_cust_email;}} ?>" name="cash_cust_email">
  
 <div class="form_error">  <?php echo $this->session->flashdata('cash_cust_email');?></div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Landline</label>
<div class="col-md-8">

<input type="text" class="form-control" value="<?php if((!empty($customers_data[0]))){echo $customers_data[0]->sca_cust_landline;}else{if(!empty($result[0]->q_cust_landline)){echo $result[0]->q_cust_landline;}} ?>" name="q_cust_landline">
  
 <div class="form_error">  <?php echo $this->session->flashdata('cash_cust_land');?></div>
</div>
</div>
</div>

</div>

</div>


<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">If inquiry-Click here</label>
<div class="col-md-8">
<label class="checkbox-inline">
   <input type="checkbox" name="for_inquiry" value="1" <?php if(!empty($result)){if((empty($result[0]->q_inquiry))){echo "checked";}} ?>> Click to add inquiry-files
</label>
 <div class="form_error">  <?php echo $this->session->flashdata('for_inquiry');?></div>
</div>
</div>
</div>

<div class="for-inquiry-div">
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
  <p>Upload files here.Make sure the file size is less than 2MB.</p>
 <input id="file-1" name="files[]" type="file"  multiple  required />
 <div class="form_error">  <?php echo $this->session->flashdata('files[]');?></div>
</div> 
</div>

</div>

<!-----div starts here for non-inquiry--->
<div class="non-inquiry">
<!----div starts here for non-inquiry--->
<h4>For notes section</h4>


<div class="col-md-12 col-sm-12 table-rows-border">
  
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Delivery time<abbr class="required">*</abbr></label>
<div class="col-md-8">
  <textarea  name="delivery_time" class="form-control" ><?php if(!empty($result[0]-> q_delivery_time)){echo $result[0]-> q_delivery_time;};?></textarea>


  <div class="form_error">  <?php echo $this->session->flashdata('delivery_time');?></div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Stock availability notes<abbr class="required">*</abbr></label>
<div class="col-md-8">
<input type="radio" name="stock_ava" value="1" checked <?php if(!empty($result[0]-> q_stock_note)){if($result[0]-> q_stock_note=='1'){echo "checked";}};?> > Add note of stock availabitlity<br/>
<input type="radio" name="stock_ava" value="2" <?php if(!empty($result[0]-> q_stock_note)){if($result[0]-> q_stock_note=='2'){echo "checked";}};?> > Dont add note

  <div class="form_error">  <?php echo $this->session->flashdata('stock_ava');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Offer Validity(enter number of days) <abbr class="required">*</abbr></label>
<div class="col-md-8">
  <input type="number" name="offer_vailidity" value="<?php if(!empty($result[0]-> q_offer_validity)){echo $result[0]-> q_offer_validity;};?>" class="form-control ">


  <div class="form_error">  <?php echo $this->session->flashdata('offer_vailidity');?></div>
</div>
</div>
</div>

</div>

<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Project Type<abbr class="required">*</abbr></label>
<div class="col-md-8">
 <select class="form-control" name="q_project">

 <?php 
 foreach($project_masters as $pj)
 {
?>
<option value="<?php echo $pj->mpj_id;?>" <?php if(!empty($result[0]->q_project)){if($result[0]->q_project==$pj->mpj_id){echo "selected";}}else{if($pj->mpj_id=='1'){echo "selected";}};?>><?php echo $pj->mpj_name;?></option>
<?php
 }
 ?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('q_project');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Tender Number<abbr class="required">*</abbr></label>
<div class="col-md-8">
  <input type="text" name="q_tendor_no" value="<?php if(!empty($result[0]->q_tendor_no)){echo $result[0]->q_tendor_no;};?>" class="form-control ">


  <div class="form_error">  <?php echo $this->session->flashdata('q_tendor_no');?></div>
</div>
</div>
</div>

</div>



<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Payment type<abbr class="required">*</abbr></label>
<div class="col-md-8">


 <select class="form-control" name="payment_type">

  <option value="">Choose</option>
  <option value="Cash on Delivery" <?php if(!empty($result[0]-> q_payment_type)){if($result[0]-> q_payment_type =='Cash on Delivery'){echo "selected";}};?>>Cash on Delivery</option>
  <option value="Advance" <?php if(!empty($result[0]-> q_payment_type)){if($result[0]-> q_payment_type =='Advance'){echo "selected";}};?>>Advance</option>
  <option value="CDC on delivery" <?php if(!empty($result[0]-> q_payment_type)){if($result[0]-> q_payment_type =='CDC on delivery'){echo "selected";}};?>>CDC on delivery</option>
  <option value="PDC days" <?php if(!empty($result[0]-> q_payment_type)){if($result[0]-> q_payment_type =='PDC days'){echo "selected";}};?>>PDC days</option>
  <option value="Credit days" <?php if(!empty($result[0]-> q_payment_type)){if($result[0]-> q_payment_type =='Credit days'){echo "selected";}};?>>Credit days</option>
    <option value="Bank LC" <?php if(!empty($result[0]-> q_payment_type)){if($result[0]-> q_payment_type =='Bank LC'){echo "selected";}};?>>Bank LC</option>
  <option value="100% TT" <?php if(!empty($result[0]-> q_payment_type)){if($result[0]-> q_payment_type =='100% TT'){echo "selected";}};?>>100% TT</option>
     <option value="Cash before Delivery" <?php if(!empty($result[0]-> q_payment_type)){if($result[0]-> q_payment_type =='Cash before Delivery'){echo "selected";}};?>>Cash before Delivery</option>
 </select>

  <div class="form_error">  <?php echo $this->session->flashdata('payment_type');?></div>  
</div>
</div>

</div>


</div>

<div class="row">
<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
  <label class="col-md-4 control-label" for="inputPlaceholder">Payment notes</label>
<div class="col-md-8">
<textarea name="q_payment_notes"  class="form-control editors"><?php if(!empty($result[0]-> q_payment_notes)){echo $result[0]-> q_payment_notes;};?></textarea>
<small>Use a proper payment note. This will be the one which gets displayed in payment area of quotation. Always use <b>"as" followed by the type of payment and preceded by the % symbol.</b> If you are using "50 % advance", the string will not get accepted.   </small>
  <div class="form_error">  <?php echo $this->session->flashdata('q_payment_notes');?></div>
</div>
 </div>
</div>
</div>  


<div class="row">
<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Show stamp & Signature<abbr class="required">::*::</abbr><br/><small>Get approval for showing company signed stamp image in this quotation from managment</small></label>
 <div class="col-md-8">
<input type="radio" name="show_stamp" value="1" <?php if(!empty($result[0]->show_stamp)){if($result[0]->show_stamp==1){echo "checked";}};?> >Yes <abbr class="required">(Request Only If Your Customer Ask For necessary Only)</abbr> <br>
<input type="radio" name="show_stamp" value="2" <?php if(!empty($result[0]->show_stamp)){if($result[0]->show_stamp==2){echo "checked";}}else{echo "checked";};?> > No <abbr class="success">(Default)</abbr>

  <div class="form_error">  </div>

  <input type="hidden" name="approved_sts_sign" value="<?php if(!empty($result[0]->q_approval_stamp_sign)){echo $result[0]->q_approval_stamp_sign;}else{echo '1';};?>">
  
 <div class="form_error">  <?php echo $this->session->flashdata('show_stamp');?></div>
</div>
</div>
</div>
</div>


<div class="row">
  <div class="col-md-12 table-rows-border">
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Additional description</label>

<div class="col-md-8">
<div class="input-group">
  <textarea class="form-control editors" name="q_add_notes"><?php if(!empty($result[0]->q_add_notes)){echo $result[0]->q_add_notes;};?></textarea>
</div>
 
 <div class="form_error">  <?php echo $this->session->flashdata('q_add_notes');?></div>
</div> 
</div>

</div>
</div>

<div class="cell_text_data"></div>
<!-- submit_main_form -->
<!-----div end here for non-inquiry--->
</div>
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for non-inquiry--->
<div class="non-inquiry">
<!----div starts here for non-inquiry--->
<section class="panel panel-featured panel-featured-primary">

<div class="panel-body">
 
<div class="row">


<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive"> 
<table class="table table-bordered mb-none">
 <thead>
  <tr>
   <!--  <th>#</th>  -->
   <th ></th>
   
   <th >Product Name</th>
   <th >Quantity</th>
   
   <th >Unit Price in AED</th>
     
   <th>Total Price AED</th>

   <th >Unit Price in USD</th>
     
   <th>Total Price in USD</th>

     <th >Unit Price in KSA</th>
     
   <th>Total Price in KSA</th>



    <th>VAT(5%) for AED</th>
 <th>Extra Details</th>
  <th >Weight<br/>(for porforma)</th>
    <th >HSC Code<br/>(for porforma)</th>

  </tr>
 </thead>
 <tbody class="new_rows">
 <?php
 if(!empty($result[0]->q_prd_id) || !empty($result2))
 {
 $i=1;
 if(!empty($result[0]->q_prd_id))
$prds=explode('|#|',$result[0]->q_prd_id);

 if(!empty($result2[0]->q_prd_id))
$prds=explode('|#|',$result2[0]->q_prd_id);

foreach($prds as $index=>$p)
{
 if(!empty($result2))
 {
 $qnty=explode('|#|',$result2[0]->q_prd_qnty);
$unit_price=explode('|#|',$result2[0]->q_prd_price);
$currencytype=$result2[0]->q_currency_type;
$tot_price=explode('|#|',$result2[0]->q_prd_tot);
$vat_pre=explode('|#|',$result2[0]->q_prd_vat);
$prd_rmks=explode('|#|',$result2[0]->q_remarks);
$prd_wgt=explode('|#|',$result2[0]->q_prd_wgt);
$prd_hsccode=explode('|#|',$result2[0]->q_prd_hsc);
 }
 else
 {
  $qnty=explode('|#|',$result[0]->q_prd_qnty);
  $unit_price=explode('|#|',$result[0]->q_prd_price);
  $currencytype=$result[0]->q_currency_type;
  $tot_price=explode('|#|',$result[0]->q_prd_tot);
  $vat_pre=explode('|#|',$result[0]->q_prd_vat);
  $prd_rmks=explode('|#|',$result[0]->q_remarks);
  $prd_wgt=explode('|#|',$result[0]->q_prd_wgt);
  $prd_hsccode=explode('|#|',$result[0]->q_prd_hsc);
}
  
  ?>
<tr class="edit_remove_<?php echo $i;?>">
 <td><button type='button'   onclick="table_edit('<?php echo $i;?>')">X</button></td>
 

<td>
    <select data-plugin-selectTwo  class="form-control populate product_<?php echo $i;?>"
     name="si_product[]" onchange="get_product_details('<?php echo $i;?>');">
  <option value="">Choose</option>
<?php
foreach($products_list as $prd)
{
  ?>
   <option value="<?php echo $prd->pid;?>" <?php if(!empty($p)){if($p==$prd->pid){echo "selected";}};?> > <?php echo str_replace('|~~|', ',', $prd->pname);?> ::<br/> <?php echo $prd->pcode;?> </option> 
  <?php
}
?>
 </select>
<input type="hidden" name="prdids">
</td>

<td>
 <input type='hidden' name='qntys' size='5'>
 <button type="button" onclick="inc_qnty('<?php echo $i;?>')">+</button><input type='number' name='qnty[]' size='5' value="<?php echo $qnty[$index];?>" class="prd_quntity<?php echo $i;?> ">
 <button type="button" onclick="dec_qnty('<?php echo $i;?>')">-</button></td>

<td>
 <input type='hidden' name='unit_prices' size='5'>
<input type='text' name='unit_price[]' size='5' value="<?php if($currencytype=='aed'){echo  number_format($unit_price[$index],1);}else if($currencytype=='usd'){
echo number_format($unit_price[$index]*3.66,1);}else{echo number_format($unit_price[$index]*0.975,1);} ; ?>" class="prd_unit_price<?php echo $i;?> "></td>

<td>
 <input type='hidden' name='total_prices' size='10'>
<input type='text' name='total_price[]' value="<?php if($currencytype=='aed'){echo number_format($tot_price[$index],1);} else if($currencytype=='usd'){

echo number_format($tot_price[$index]*3.66,1);}else{echo number_format($tot_price[$index]*0.975,1);}   ;?>" class="prd_total_price<?php echo $i;?> "></td>

<td>
 <input type='hidden' name='unit_prices_usd' size='5'>
<input type='text' name='unit_price_usd[]' size='5' value="<?php echo $unit_price_usd[$index];?>" class="prd_unit_price_usd<?php echo $i;?> "></td>


<td>
 <input type='hidden' name='total_prices_usd' size='10'>
<input type='text' name='total_price_usd[]' value="<?php echo $tot_price_usd[$index];?>" class="prd_total_price_usd<?php echo $i;?> "></td>








<td>
 <input type='hidden' name='unit_prices_ksa' size='5'>
<input type='text' name='unit_price_ksa[]' size='5' value="<?php echo $unit_price_ksa[$index];?>" class="prd_unit_price_ksa<?php echo $i;?> "></td>


<td>
 <input type='hidden' name='total_prices_ksa' size='10'>
<input type='text' name='total_price_ksa[]' value="<?php echo $tot_price_ksa[$index];?>" class="prd_total_price_ksa<?php echo $i;?> "></td>



<td>
 <input type='hidden' name='vat_pers' size='10'>
 Apply vat<input type='checkbox' name='vat_checkbox'  value='1' size='5' style='width:50px;' class='prd_vat_per<?php echo $i;?>' onInput='vat_perc("<?php echo $i;?>")'><br/>
 <input type="text" name='vat_per[]' value="<?php echo $vat_pre[$index];?>" class="prd_vat_price<?php echo $i;?> ">
</td>

<td>
 <input type='hidden' name='extra_detail' size='10'>
 <input type="text" name='extra_details[]' value="<?php echo $prd_rmks[$index];?>" class="prd_extra_details<?php echo $i;?> form-control">
</td> 

 <td>
 <input type='hidden' name='wgt_prds' size='5'>
<input type='text' name='wgt_prd[]' size='5' value="<?php echo $prd_wgt[$index];?>" class="prd_wgt_s<?php echo $i;?>"></td>

 <td>
 <input type='hidden' name='hsccodes_prds' size='5'>
<input type='text' name='hsccodes[]' size='5' value="<?php echo $prd_hsccode[$index];?>" class="prd_hsc_code<?php echo $i;?> "></td>

</tr>
<?php
$i++;
}
 }
 else
 {
  ?>
  <tr class='table1'>
  <td><!-- <button type='button' onclick="table(1);">X</button> --></td> 
      <td ><input type="hidden" name="prdids">
        <select data-plugin-selectTwo  class="form-control populate product_1"
     name="si_product[]" onchange="get_product_details('1');">
  <option value="">Choose</option>
<?php
foreach($products_list as $prd)
{
  ?>
   <option value="<?php echo $prd->pid;?>" <?php if(!empty($pa)){if($pa==$prd->pid){echo "selected";}};?> > <?php echo str_replace('|~~|', ',', $prd->pname);?> ::<br/> <?php echo $prd->pcode;?> </option> 
  <?php
}
?>
 </select>
       </td>
      <td ><input type='hidden' name='qntys' >
      <button type="button" onclick="inc_qnty(1);">+</button><input type='number'  name='qnty[]'   class='prd_quntity1'><button type="button" onclick="dec_qnty(1);">-</button></td>
     
    <td><input type='hidden' name='unit_prices' > <input type='text' name='unit_price[]'  class='prd_unit_price1 '></td>   
        <td ><input type='hidden' name='total_prices'><input type='text' name='total_price[]' class='prd_total_price1 '></td>

            <td><input type='hidden' name='unit_prices_usd' > <input type='text' name='unit_price_usd[]'  class='prd_unit_price_usd1 '></td>  


        <td ><input type='hidden' name='total_prices_usd'><input type='text' name='total_price_usd[]' class='prd_total_price_usd1 '></td>

    <td><input type='hidden' name='unit_prices_ksa' > <input type='text' name='unit_price_ksa[]'  class='prd_unit_price_ksa1 '></td>  


        <td ><input type='hidden' name='total_prices_ksa'><input type='text' name='total_price_ksa[]' class='prd_total_price_ksa1 '></td>


        <td ><input type='hidden' name='vat_pers'> Apply vat<input type='checkbox' name='vat_checkbox'  value='1'  class='prd_vat_per1 ' onInput='vat_perc(1);'><br/><input type='text' name='vat_per[]' class='prd_vat_price1'></td>
   <td ><input type='hidden' name='extra_detail' > <input type='text' name='extra_details[]'   class='prd_extra_details1 form-control'></td>
          <td ><input type='hidden' name='wgt_prds' > <input type='text' name='wgt_prd[]'  class='prd_wgt_s1 '></td> 
        <td ><input type='hidden' name='hsccodes_prds'> <input type='text' name='hsccodes[]' class='prd_hsc_code1 '></td>
           <!--       <td><button type='button' onclick='copy_text(1);'>Copy</td> -->
    </tr>
 <?php
 }
 ?>
 
 </tbody>
</table>
</div>
</div>
<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
<!-- <label class="col-md-4 control-label" for="inputPlaceholder">Search Product<abbr class="required">::*::</abbr></label> -->
<div class="col-md-8">
<button type="button" class="btn btn-primary pull-right" onclick="add_more_row();">Add More</button>
<div class="form_error">  <?php echo $this->session->flashdata('search_product_cat');?></div>
</div>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">

<label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
<div class="col-md-8">
 <span class="num_items">
   <?php
 if(!empty($result[0]->q_prd_id))
 {
  $p_ids=explode('|#|',$result[0]->q_prd_id);
  echo count($p_ids);
 }
elseif(!empty($result2))
{
   $p_ids=explode('|#|',$result2[0]->q_prd_id);
  echo count($p_ids);
}
else
{
  echo "1";
}
 ?>
 </span>
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Choose Currency type:</label>
<div class="col-md-8">
  <select name="currency_type" class="form-control">
    <option value="">Choose</option>
     <?php
    if(!empty($result2))
      {?>
  <option value="aed" <?php if(!empty($result2[0]->q_currency_type)){if($result2[0]->q_currency_type =='aed'){echo "selected";}};?>>AED</option>
     <option value="sr" <?php if(!empty($result2[0]->q_currency_type)){if($result2[0]->q_currency_type =='sr'){echo "selected";}};?>>Saudi Riyal</option>
      <option value="usd" <?php if(!empty($result2[0]->q_currency_type)){if($result2[0]->q_currency_type =='usd'){echo "selected";}};?>>US DOllar</option>
        <?php
      }
      else{
        ?>
    <option value="aed" <?php if(!empty($result[0]->q_currency_type)){if($result[0]->q_currency_type =='aed'){echo "selected";}};?>>AED</option>
     <option value="sr" <?php if(!empty($result[0]->q_currency_type)){if($result[0]->q_currency_type =='sr'){echo "selected";}};?>>Saudi Riyal</option>
      <option value="usd" <?php if(!empty($result[0]->q_currency_type)){if($result[0]->q_currency_type =='usd'){echo "selected";}};?>>US DOllar</option>
      <?php
    }?>
    
  </select>
</div>
</div>
<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Additional Charges:</label>
<div class="col-md-8">
<input type="number" name="additional_charge" min='0' value="<?php if(!empty($result[0]-> q_additional_charge)){echo $result[0]-> q_additional_charge;}else{echo '0';};?>" required="" >
</div>
</div>


<div class="col-md-12 col-sm-12 table-rows-border ">
<label class="col-md-4 control-label" for="inputPlaceholder">Discount Price:</label>
<div class="col-md-8">
<input type="number" name="discount_percentage" min='0' value="<?php if(!empty($result[0]-> q_discount_per)){echo $result[0]-> q_discount_per;}else{echo '0';};?>" required="" >

</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Calculate Price:</label>
<div class="col-md-8">

<button type="button" class="label label-danger" style="width:30;height:40;" onclick="fill_data_price()">Click here to calculate price</button>

</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Total price :</label>
<div class="col-md-8">
 <span class="total_price_prds"><?php if(!empty($result[0]-> q_total_price)){echo $result[0]-> q_total_price;}else{'0';};?></span>
  <input type="hidden" name="total_price_final" value="<?php if(!empty($result[0]-> q_total_price)){echo $result[0]-> q_total_price;}else{'0';};?>">
  <input type="hidden" name="converted_ar" value="">
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Net Total:</label>
<div class="col-md-8">
 <span class="net_total"><?php if(!empty($result[0]->q_net_total)){echo $result[0]->q_net_total;}else{'0';};?></span>
  <input type="hidden" name="net_total" value="<?php if(!empty($result[0]->q_net_total)){echo $result[0]->q_net_total;}else{'0';};?>">
</div>
</div>


<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Total VAT :</label>
<div class="col-md-8">
 <span class="total_vat_price"><?php if(!empty($result[0]-> q_total_vat)){echo $result[0]-> q_total_vat;}else{'0';};?></span>
 <input type="hidden" name="total_vat_final" value="<?php if(!empty($result[0]-> q_total_vat)){echo $result[0]-> q_total_vat;}else{'0';};?>">
</div>
</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Grand total:</label>
<div class="col-md-8">
 <span class="grand_total"><?php if(!empty($result[0]-> q_grand_total)){echo $result[0]-> q_grand_total;}else{'0';};?></span>
  <input type="hidden" name="grand_total" value="<?php if(!empty($result[0]-> q_grand_total)){echo $result[0]-> q_grand_total;}else{'0';};?>">
</div>
</div>


<div class="row">
<div class="col-md-12 col-sm-12 table-rows-border">
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Show grand total? <abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <div class="col-md-8">
<input type="radio" name="show_grand_total" value="1" <?php if(!empty($result[0]->show_total)){if($result[0]->show_total==1){echo "checked";}};?> >Yes<br>
<input type="radio" name="show_grand_total" value="2" <?php if(!empty($result[0]->show_total)){if($result[0]->show_total==2){echo "checked";}};?>> No

  <div class="form_error">  </div>
</div>
  
 <div class="form_error">  <?php echo $this->session->flashdata('show_grand_total');?></div>
</div>
</div>
</div>
</div>

</div>

<!-- submit_main_form -->


</div>
</section>

<!---------div closes for non-inquiry--->
</div>
<!----div closes here--->

<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>


</section>
</div>
</section>

<?php $this->load->view('admin/sales/script_arabic_word');?>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
 <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript"></script>
  
  <script>
            $(document).on('ready', function () {
                $("#file-1").fileinput();
                });
                  </script>
                  
        <script>
      $(document).ready(function()
{    
             /////for file upload////
  $("#file-1").fileinput({
      // 'theme': 'fas',
     //        'showPreview': true,
     //         'showUpload': false,
     //      'showRemove':true,
     //        'maxFileSize': 5000,
     //    'maxFilesNum': 10,
     //        'allowedFileExtensions': ['jpg', 'png', 'gif'],

        theme: 'fas',
         showUpload: false,
          showCancel: true,
        overwriteInitial: false,
        maxFileSize: 3000,////max file size  is 2000 kb,else will show error
        maxFilesNum: 10,


        // "success":true,
        //allowedFileTypes: ['image', 'video', 'flash'],
       
    });
 
     $(".file").on('fileselect', function(event, n, l) {
     alert('File Selected. Name: ' + l + ', Num: ' + n);
     });
     
      });
        </script>
  
 <script>
    tinymce.init({
      selector : '.editors',
        plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
    });
   </script>
   
<script type="text/javascript">
 $(document).ready(function()
 {
   var coverted_arabic='';
    var total_price=$("input[name='total_price_final']").val();

   var coverted_arabic=convert_number(total_price,'female');
   console.log(coverted_arabic);
   $('input[name="converted_ar"]').val(coverted_arabic);

  //$('.search_product_select').hide()
  $('.adv_payment_data').hide();
 
  $('.for-inquiry-div').hide();
  var production_id=$("input[name='ordr_id']").val();
  if(production_id=='')
  {
   $('.approve_btn').hide();
  }
  else{
   $('.approve_btn').show();
  $('select[name="variation_select[]"]').on("change",function(){

   var class_name=$(this).attr('class');

   var ret = class_name.split(" ");
   var variation_name=ret[1];
   var table_row_id=ret[2];
   var var_class_name=variation_name.replace('print_var','');
   
   });
  
  }
  $('.choose_other_dlvry_date').hide();

  var days_delivery=$("input[name='exact_dlvry_date']:checked").val();
  if(days_delivery=="no")
  {
   $('.choose_other_dlvry_date').show();
  }

  $('input:radio').change(function() {
   var delivery_days = $("input[name='exact_dlvry_date']:checked").val();
   if(delivery_days=="no")
   {
    $('.choose_other_dlvry_date').show();
   }
   if(delivery_days=="yes")
   {
    $('.choose_other_dlvry_date').hide();
   }  
    });

  $("select[name='choose_customer']").change(function(){
    var cust_id=$(this).val();
      jQuery.ajax({
                     url:"<?php echo base_url().'Quotation_controller/get_customer_details';?>",
                    type:"post",
                     data:{"customer_id":cust_id},
                    success:function(result)
                    {
                      if(result)
                      {
                   var returndata = JSON.parse(result);
                        $('input[name="cash_cust_name"]').val(returndata.sca_cust_name); 
                        $('input[name="cash_cust_comp"]').val(returndata.sca_cust_company);  
                        $('input[name="cash_cust_mob"]').val(returndata.sca_cust_mobile);  
                        $('input[name="cash_cust_email"]').val(returndata.sca_cust_email);  
                        $('input[name="cash_cust_land"]').val(returndata.sca_cust_landline);   
                        $('.cash_cusotmer_details').show();
                      }
                    }
                 });        
  });

    $("select[name='choose_category']").change(function() {
      //console.log('in choose cat');
      $('select[name="search_product_cat"]').html('');

    var category_selected=$("select[name='choose_category']").val();
   // console.log(category_selected);
     jQuery.ajax({
                     url:"<?php echo base_url().'Product_order/choose_category';?>",
                    type:"post",
                     data:{"category_selected":category_selected},
                    success:function(result)
                    {
                      //console.log(result);
                    var returndata = JSON.parse(result);
                    $('select[name="search_product_cat"]').append("<option>Choose Value</option>");
                    $.each(returndata, function(key2,val2)
      {
       
       var product_full=val2['pname'].split('|~~|');
       $('select[name="search_product_cat"]').append("<option value="+val2['pid']+">"+product_full[0]+" "+product_full[1]+" ::  <br/><br/> "+val2['pcode']+"</option>");
      });
                    }
                });
    });

  $("input[name='search_product']").on("keyup", function(e) {
          var key_code = e.which || e.keyCode;
      if(key_code=="32") 
      {
       var to_search=$("input[name='search_product']").val();
       var category_selected=$("select[name='choose_category']").val();
      
        jQuery.ajax({
                     url:"<?php echo base_url().'Product_order/search_product';?>",
                    type:"post",
                     data:{"to_search":to_search,"category_selected":category_selected},
                    success:function(result)
                    {
                   // console.log(result); 
                     //$('.search_product_input').hide();
                     $('.search_product_select').show();

                     $('.search_product_select').html( '<option value="">Choose Values</option>'+ result);
                    }
                });
      }
  });

 
$('input[name="add_cash_customer"]').on("click",function(){
  if($(this).is(':checked'))
  {
    $('input[name="add_cash_customer"]').val('1');
//console.log('checked box');
$('.cash_cusotmer_details').show();

  }
  else
  {
    //console.log('unchecked box');
    $('.cash_cusotmer_details').hide();
  }

});


$('input[name="for_inquiry"]').on("click",function(){
  if($(this).is(':checked'))
  {
    $('input[name="for_inquiry"]').val('1');
//console.log('checked box');
$('.for-inquiry-div').show();
$('.non-inquiry').hide();
  }
  else
  {
    //console.log('unchecked box');
    $('.for-inquiry-div').hide();
    $('.non-inquiry').show();
  }

});

$('select[name="payment_type"]').on("change",function(){
  if($(this).val()=="Advance")
  {
    $('.adv_payment_data').show();
  }
  else
  {
    $('.adv_payment_data').hide();
  }

 });
   });

function add_more_row()
{
 $(".div_var").html('');
 $(".update_variation").html('');
 var prd_name=$('.search_product_select :selected').text();
var search_prd_id=$('.search_product_select :selected').val();
var category_selected=$("select[name='choose_category']").val();

var tablecount = $('table tbody tr').length;
  if(tablecount=="0")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }

  console.log(table_id);

 $('.prd_name_selected').text(prd_name);
  //$('.prd_name').html(prd_name);
  var table_data=$('.new_rows').length;
  var i=table_data;
  var new_quantity='0';

      var markup = "<tr class='table"+table_id+"'>"+
      "<td><button type='button' onclick=table("+table_id+")>X</button></td>"+
       ' <td class="select_prd_list_'+table_id+'"><input type="hidden" name="prdids">';
    jQuery.ajax({
                     url:"<?php echo base_url().'Quotation_controller/get_details_prd';?>",
                      data:{"table_id":table_id},
                    type:"post",
                    success:function(result)
                    {
                      if(result)
                      {
               $('.select_prd_list_'+table_id).html(result);
              $('select[name="si_product[]"]').select2();  
                      }
                    }
                 });  

  markup+=  '</td>'+
      "<td ><input type='hidden' name='qntys' >"+
      "<button type='button' onclick=inc_qnty("+table_id+")>+</button><input type='number' name='qnty[]' class='prd_quntity"+table_id+"'><button type='button' onclick=dec_qnty("+table_id+")>-</button></td>"+
  "<td ><input type='hidden' name='unit_prices'> <input type='text' name='unit_price[]' class='prd_unit_price"+table_id+"'></td>"+
  "<td ><input type='hidden' name='total_prices'><input type='text' name='total_price[]' class='prd_total_price"+table_id+"'></td>"+
  "<td ><input type='hidden' name='unit_prices_usd'> <input type='text' name='unit_price_usd[]' class='prd_unit_price_usd"+table_id+"'></td>"+
  "<td ><input type='hidden' name='total_prices_usd'><input type='text' name='total_price_usd[]' class='prd_total_price_usd"+table_id+"'></td>"+
  "<td ><input type='hidden' name='unit_prices_ksa'> <input type='text' name='unit_price_ksa[]' class='prd_unit_price_ksa"+table_id+"'></td>"+
  "<td ><input type='hidden' name='total_prices_ksa'><input type='text' name='total_price_ksa[]' class='prd_total_price_ksa"+table_id+"'></td>"+
  "<td><input type='hidden' name='vat_pers' > Apply vat<input type='checkbox' name='vat_checkbox'  value='1'  class='prd_vat_per"+table_id+"' onInput='vat_perc("+table_id+")'><br/><input type='text' name='vat_per[]' class='prd_vat_price"+table_id+"'></td>"+
   "<td ><input type='hidden' name='extra_detail' > <input type='text' name='extra_details[]'   class='prd_extra_details"+table_id+"'></td>"+
      "<td ><input type='hidden' name='wgt_prds' > <input type='text' name='wgt_prd[]' class='prd_wgt_s"+table_id+"'></td>"+
 "<td ><input type='hidden' name='hsccodes_prds' > <input type='text' name='hsccodes[]'  class='prd_hsc_code"+table_id+"'></td>"+
                 // "<td><button type='button' onclick='copy_text("+table_id+")'>Copy</td>"+
      "</tr>";
            $("table tbody").append(markup);
   var rowcount = $('table tbody tr').length;
   var current_num_items=$(".num_items").text();
     $(".num_items").html(rowcount);
     $('select[name="si_product[]"]').select2();
 //  $(".num_items").html(rowcount);
  }

function get_product_details(table_id)
{
    var prd_selected=$('.product_'+table_id).find('option:selected').val();
var vat_type_choosed=$('select[name="si_vat_type"]').find('option:selected').val();
    if(vat_type_choosed=="2")
    {
      $('input[name="si_vat[]"]').val('0');
    }
    else
    {
   $('input[name="si_vat[]"]').val('5');
    }
    
    jQuery.ajax({
               url:"<?php echo base_url().'Sales_invoice/get_product_details';?>",
                data:{"prd_id":prd_selected},
              type:"post",
               success:function(result)
              {
                 if(result)
                {
                  var returndata = JSON.parse(result);
                 $('.img'+table_id).attr('src',returndata['pimage']);
                $('.prd_unit_price'+table_id).val(returndata['prd_price']);
                }
              }
            });
}

function inc_qnty(table_id)
{ 
var prd_price=$('.prd_unit_price'+table_id).val();
  var curnt_qnty=$('.prd_quntity'+table_id).val();

  var prd_price_USD= (prd_price /3.66).toFixed(2);

  $('.prd_unit_price_usd'+table_id).val((prd_price /3.66).toFixed(2));

  var prd_price_ksa= (prd_price /0.975).toFixed(2);

  $('.prd_unit_price_ksa'+table_id).val((prd_price /0.975).toFixed(2));


  if(curnt_qnty=='')
  {
    $('.prd_quntity'+table_id).val(parseFloat(1) );
  }
  else
  {
    $('.prd_quntity'+table_id).val(parseFloat(curnt_qnty) + parseFloat(1) );
  }
// console.log(curnt_qnty);

//  $('input[name="qnty[]"]').val(parseFloat(curnt_qnty) + parseFloat(1) );
  var new_qnty=$('.prd_quntity'+table_id).val();
var new_price=(parseFloat(new_qnty) * parseFloat(prd_price));

 $('.prd_total_price'+table_id).val(((new_price * 100) / 100).toFixed(2));
var new_price_USD=(new_price /3.66).toFixed(2);


  $('.prd_total_price_usd'+table_id).val(((new_price_USD * 100) / 100).toFixed(2));
var new_price_ksa=(new_price /0.975).toFixed(2);
$('.prd_total_price_ksa'+table_id).val(((new_price_ksa * 100) / 100).toFixed(2));

 //$('.prd_unit_price_usd'+table_id).val((Math.round(new_price /3.65)).toFixed(2));







 }

function dec_qnty(table_id)
{
 // console.log(table_id);

    var prd_price=$('.prd_unit_price'+table_id).val();
 var curnt_qnty=$('.prd_quntity'+table_id).val();

  var prd_price_USD= (prd_price /3.66).toFixed(2);

$('.prd_unit_price_usd'+table_id).val((prd_price /3.66).toFixed(2));
    var prd_price_ksa= (prd_price /0.975).toFixed(2);

  $('.prd_unit_price_ksa'+table_id).val((prd_price *0.975).toFixed(2));

  var dec_qnty_val=parseFloat(curnt_qnty) - parseFloat(1);
  if (dec_qnty_val < 1)
  {
    $('.prd_quntity'+table_id).val('1');
  } 
  else{
  $('.prd_quntity'+table_id).val(dec_qnty_val);
}
  

    var new_qnty=$('.prd_quntity'+table_id).val();
var new_price=(parseFloat(new_qnty) * parseFloat(prd_price));

 $('.prd_total_price'+table_id).val(((new_price * 100) / 100).toFixed(2));
var new_price_USD=(new_price /3.66).toFixed(2);


  $('.prd_total_price_usd'+table_id).val(((new_price_USD * 100) / 100).toFixed(2));
var new_price_ksa=(new_price /0.975).toFixed(2);
$('.prd_total_price_ksa'+table_id).val(((new_price_ksa * 100) / 100).toFixed(2));


}
function vat_perc(table_id)
{ 
 var vat_per= $('.prd_vat_per'+table_id).val();
 if ($("input[name=vat_checkbox]").is(':checked'))
 {
 var tot_price=$('.prd_total_price'+table_id).val();
var vat_price=(parseFloat(5)/parseFloat(100))*(parseFloat(tot_price));
$('.prd_vat_price'+table_id).val((Math.round(vat_price * 100) / 100).toFixed(2));

 }
}
function fill_data_price()
{
  var currency_type=$("select[name='currency_type']").val();
  if(currency_type=="sr")
   var fixed_rate='0.979333';
  else if(currency_type=="usd")
//var fixed_rate='3.67250';
var fixed_rate='3.66';
else
var fixed_rate='1';

var additional_charge=$("input[name='additional_charge']").val();
  var discount_percent=$("input[name='discount_percentage']").val();
  var tot_price=$("input[name='total_price[]']").val();
  var vat_values=$("input[name='vat_per[]']").val();
 
  var sum = 0;
$("input[name='total_price[]']").each(function() {
        sum += Number($(this).val());
    });

    var converted_price=(parseFloat(sum))/(parseFloat(fixed_rate));

   $('.total_price_prds').html(((converted_price * 100) / 100).toFixed(2) + currency_type); ////this shows total product price   
$("input[name='total_price_final']").val(((converted_price * 100) / 100).toFixed(2));

// var vat_sum=0;
// $("input[name='vat_per[]']").each(function() {
//         vat_sum += Number($(this).val());
//     });
// var converted_price_vat=(parseFloat(fixed_rate)*parseFloat(vat_sum));
// $('.total_vat_price').html((Math.round(converted_price_vat * 100) / 100).toFixed(2) + currency_type); ////this shows total vat
// $("input[name='total_vat_final']").val((Math.round(converted_price_vat * 100) / 100).toFixed(2));

if(discount_percent=='' || discount_percent==0 )
{
$("input[name='total_price_discounted']").val(0);
discount_percent=0;
}

if(additional_charge=='' || additional_charge==0)
{
$("input[name='total_price_additional']").val(0);
additional_charge=0;
}
  
  var net_total=((parseFloat(sum)+parseFloat(additional_charge)-parseFloat(discount_percent)))/(parseFloat(fixed_rate));
  $('.net_total').html((Math.round(net_total * 100) / 100).toFixed(2) + currency_type);///this show grand total
$("input[name='net_total']").val(((net_total * 100) / 100).toFixed(2));

if(discount_percent=='' || discount_percent==0 )
{
   var vat_sum=0;
  $("input[name='vat_per[]']").each(function() {
          vat_sum += Number($(this).val());
      });

  if (currency_type=='sr' ||currency_type=='usd')
  {
     var converted_price_vat=(parseFloat(vat_sum));
  }
  else {
    var converted_price_vat=(parseFloat(vat_sum))/(parseFloat(fixed_rate));
  }
  $('.total_vat_price').html(((converted_price_vat * 100) / 100).toFixed(2) + currency_type); ////this shows total vat
  $("input[name='total_vat_final']").val(((converted_price_vat * 100) / 100).toFixed(2));
}
 /////apply vat on the discount net total , if discount present/////
else /////apply vat on the discount net total , if discount present/////
{

  var vat_values=$("input[name='vat_per[]']").val();
  if (vat_values==0||vat_values=='')
  {
    var converted_price_vat=0;
     
  }
else{
  var converted_price_vat=(parseFloat(net_total)*parseFloat(0.05));

}

$('.total_vat_price').html(((converted_price_vat * 100) / 100).toFixed(2) + currency_type); ////this shows total vat
$("input[name='total_vat_final']").val(((converted_price_vat * 100) / 100).toFixed(2));



}



var total_vat=((parseFloat(net_total)+parseFloat(converted_price_vat)));
$('.grand_total').html(((total_vat * 100) / 100).toFixed(2) + currency_type);///this show price + vat
$("input[name='grand_total']").val(((total_vat * 100) / 100).toFixed(2));
  //console.log(sum);
  
}
//  function copy_text(t_id)
// {
//   var table_id=parseInt($(".num_items").text())+1;
//   var table_prd_id_selected=$('.prd_id_selected_'+t_id).val();
//   var prd_name_en=$('.prd_en'+t_id).html();
//   var prd_name_ar=$('.prd_ar'+t_id).html();
//   var prd_name_code=$('.prd_code'+t_id).html();
//   var prd_unit_price=$('.prd_unit_price'+t_id).val();
//   var markup = "<tr class='table"+table_id+"'>"+
//       "<td><button type='button' onclick=table("+table_id+")>X</button></td>"+
//       "<td style='width:20% important;'><input type='hidden' name='prd_id[]' value='"+table_prd_id_selected+"'><input type='hidden' name='prdids'><span class='prd_en"+table_id+"'>"+prd_name_en+"</span><br/><span class='prd_ar"+table_id+"'>"+prd_name_ar+"</span><br/><span class='prd_code"+table_id+"'>"+prd_name_code+"</span></td><td width='5%'><input type='hidden' name='qntys' size='5'>"+
//       "<button onclick=inc_qnty("+table_id+")>+</button><input type='number' name='qnty[]' size='5' style='width:50px;' class='prd_quntity"+table_id+"'><button onclick=dec_qnty("+table_id+")>-</button></td>"+
//        "<td width='5%'><input type='hidden' name='unit_prices' size='5'><input type='text' name='unit_price[]' size='5' style='width:50px;' class='prd_unit_price"+table_id+"' value="+prd_unit_price+"></td>"+
     
//         "<td width='10%'><input type='hidden' name='total_prices'><input type='text' name='total_price[]' style='width:100px;' class='prd_total_price"+table_id+"'></td>"+
//                "<td width='10%'><input type='hidden' name='vat_pers' size='5'> Apply vat<input type='checkbox' name='vat_checkbox'  value='1' size='5' style='width:50px;' class='prd_vat_per"+table_id+"' onInput='vat_perc("+table_id+")'><br/><input type='text' name='vat_per[]' class='prd_vat_price"+table_id+"'></td>"+
               
//                 "<td width='5%'><input type='hidden' name='extra_detail' size='5'> <input type='text' name='extra_details[]' style='width:100px;'  class='prd_extra_details"+table_id+"'></td>"+
//       "</tr>";
//             $("table tbody").append(markup);
//      var rowcount = $('table tbody tr').length;
//      $(".num_items").html(rowcount);
// }

 function table(id)
 {
  $('table tbody .table'+id).remove();
  var rowcount = $('table tbody tr').length;
  $(".num_items").html(rowcount+1);
 // $(".num_items").html(rowcount);
 }
    
  function table_edit(id)
 {
 
 $('.edit_remove_'+id).remove();
  var rowcount = $('table tbody tr').length;
  $(".num_items").html(rowcount);
   $(this).closest("tr").remove();
    $(this).parent().remove();


  // var rowcount = ($('table tbody tr').length)-1;
  //  $(".num_items").html(rowcount);
 } 

$('.myform').submit(function() {
  //e.preventDefault();
var rowcount = $('table tbody tr').length;
var quantity=$('table tbody tr td input[name="qnty[]"]').map(function(){return $(this).val();}).get().join('|#|');  

var prd_wgt=$('table tbody tr td input[name="wgt_prd[]"]').map(function(){return $(this).val();}).get().join('|#|');
var prd_hscode=$('table tbody tr td input[name="hsccodes[]"]').map(function(){return $(this).val();}).get().join('|#|');

var unt_price=$('table tbody tr td input[name="unit_price[]"]').map(function(){return $(this).val();}).get().join('|#|');

var unt_price_usd=$('table tbody tr td input[name="unit_price_usd[]"]').map(function(){return $(this).val();}).get().join('|#|');
var unt_price_ksa=$('table tbody tr td input[name="unit_price_ksa[]"]').map(function(){return $(this).val();}).get().join('|#|');

var vat_price=$('table tbody tr td input[name="vat_per[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var tot_price=$('table tbody tr td input[name="total_price[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var tot_price_usd=$('table tbody tr td input[name="total_price_usd[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var tot_price_ksa=$('table tbody tr td input[name="total_price_ksa[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

 var extra_det=$('table tbody tr td input[name="extra_details[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var product_id=$('table tbody tr td select[name="si_product[]"]').map(function(){return $(this).find('option:selected').val();}).get().join('|#|');  
//console.log(quantity+' '+product_id);
//console.log(quantity+' '+package_size+' '+product_id);

$("input[name='prdids']").val(product_id);
$("input[name='qntys']").val(quantity);
$("input[name='wgt_prds']").val(prd_wgt);
$("input[name='hsccodes_prds']").val(prd_hscode);

$("input[name='unit_prices']").val(unt_price);
$("input[name='unit_prices_usd']").val(unt_price_usd);
$("input[name='unit_prices_ksa']").val(unt_price_ksa);

$("input[name='vat_pers']").val(vat_price);

$("input[name='total_prices']").val(tot_price);
$("input[name='total_prices_usd']").val(tot_price_usd);
$("input[name='total_prices_ksa']").val(tot_price_ksa);



$("input[name='extra_detail']").val(extra_det);

var ij=0;
var data_var=[];

$('table tbody tr td').each(function() { 
var cellText = $(this).html(); 
   //console.log(cellText);  
    $('.cell_text_data').append(cellText).hide(); 
});

//console.log(cellText);
//console.log($("input[name='prdids']").val());
//console.log($("input[name='qntys']").val());
//console.log($("input[name='unit_prices']").val());
//console.log($("input[name='total_prices']").val());
 //console.log($("input[name='variation_selected_val']").val());
var table_row_added=$('.new_rows').html();

 if ($('.new_rows tr').length == 0) 
 {
  alert('Please choose items to add and submit');
  return false;
 }
 else
 {
  return true;
 }
 //return false;
  // your code here
});
 
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  
<script type="text/javascript">
          $(function () {
                $('#datetimepicker4').datepicker().datepicker("setDate", new Date());
                    $('#datetimepicker5').datepicker().datepicker();
            });
        </script>

</body>

</html>