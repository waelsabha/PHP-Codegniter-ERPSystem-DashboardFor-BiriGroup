<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>
 
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">


<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Quotation</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Pages</span></li>
<li><span>Quotation Status</span></li>
</ol>
<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
</div>
</header>
<?php
if(!empty($result))
{?>
<section class="panel">
<div class="panel-body">
<div class="invoice">
<header class="clearfix">
<div class="row">
<div class="col-sm-6 mt-md">
<h2 class="h2 mt-none mb-sm text-dark text-bold">Document Number</h2>
<h4 class="h4 m-none text-dark text-bold"><?php echo $result[0]->q_ref_no;?></h4>
</div>

</div>
</header>
<div class="col-md-12 col-sm-12">
	<h2 class="error-code text-dark text-center text-semibold m-none">Success <i class="fa fa-thumbs-up"></i></h2>
	</div>
<div class="bill-info">
<div class="row">
<div class="col-md-6">
<div class="bill-to">

<p>Quotation in the name of and subject: <br/>
	<ul>
		<li><?php echo $result[0]->q_cust_name;?></li>
		<li><?php echo $result[0]->q_cust_comp;?></li>
		<li><?php echo $result[0]->q_cust_email;?></li>
		<li>Customer mobile:<?php echo $result[0]->q_cust_mob;?></li>
		<li>Customer landline:<?php echo $result[0]->q_cust_landline;?></li>
		<li>Subject : <?php echo $result[0]->q_sub;?></li>
		
</ul>
</p>

</div>
</div>

<div class="col-md-6">
<div class="bill-data text-right">
<p class="mb-none">
<span class="text-dark">Date:</span>
<span class="value"><?php echo date('Y-m-d');?></span>
</p>
</div>
</div>

<div class="col-md-12 col-sm-12">

</div>
</div>
</div>
<h4>Product Details</h4>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<th></th>
	<th>Product</th>
	<th>Quantity </th>
	<th>Unit Price </th>
	<th>Vat(%)</th>
	<th>Total Price</th>	
	<th>Extra Details</th>	
	
	
</tr>
</thead>
<tbody>
<?php
$i=1;
$total_sum_prd='0';
$total_vat_sum_prd='0';
$total_discount_sum_prd='0';
 foreach($prds as $index=>$p)
 {
 $prd_unit_price=explode('|#|',$result[0]->q_prd_price);
 $prd_vat=explode('|#|',$result[0]->q_prd_vat);
 $prd_qnty=explode('|#|',$result[0]->q_prd_qnty);
 $prd_tot=explode('|#|',$result[0]->q_prd_tot);
 $prd_rmks=explode('|#|',$result[0]->q_remarks);
 
 $total_sum_prd=$total_sum_prd+$prd_tot[$index];

$total_vat_sum_prd=$prd_tot[$index]+$total_vat_sum_prd;
if($result[0]-> q_currency_type=='aed')	
{
	$fixed_rate='1';
	$current_price_q=$prd_unit_price[$index];
}		
elseif($result[0]-> q_currency_type=='sr')
{
	$fixed_rate='0.979333';
	$current_price_q=number_format((float)$prd_unit_price[$index]/0.979333, 2, '.', '');
	
}
elseif($result[0]-> q_currency_type=='usd')
{
	$fixed_rate='3.67250';
	
	
	$current_price_q=number_format((float)$prd_unit_price[$index]/3.67250, 2, '.', '');
}

 ?>	
<tr>

<td><?php echo $i++;?></td>
<td><?php echo $p[0]->pname;?></td>
<td><?php echo $prd_qnty[$index];?></td>
<td><?php echo $current_price_q;?></td>
<td><?php echo $prd_vat[$index];?></td>
<td><?php echo $result[0]->q_total_price;?> <?php echo $result[0]-> q_currency_type ;?></td>
<td><?php echo $prd_rmks[$index];?> </td>

</tr>
<?php
}?>
</tbody>
</table>
<div class="col-md-12">
<div class="bill-data text-right">

<p>Total Price : <?php echo number_format((float)$result[0]->q_total_price, 2, '.', '').' '.$result[0]-> q_currency_type;?></p>
<?php
if(!empty($result[0]->q_discount_per))
{
$discount_price=$result[0]->q_discount_per;
?>
<p>Discount Price: <?php echo number_format((float)$result[0]->q_discount_per, 2, '.', '').' '.$result[0]-> q_currency_type;?> </p>
<?php
}
else
{
$discount_price=0;
}
if(!empty($result[0]->q_additional_charge))
{
$additional_price=$result[0]->q_additional_charge;
?>
<p>Additional charges: <?php echo $result[0]->q_additional_charge;?> </p>
<?php
}
else
{
$additional_price=0;
}
?>
<?php
$net_total=(($result[0]->q_total_price+$additional_price)-$discount_price);
?>
<p>Net Total : <?php echo number_format((float)$net_total, 2, '.', '').' '.$result[0]-> q_currency_type;?></p>

<p>VAT %: <?php echo number_format((float)$result[0]->q_total_vat, 2, '.', '').' '.$result[0]-> q_currency_type;?></p>

<p>Grand Total: <?php echo number_format((float)$result[0]-> q_grand_total, 2, '.', '').' '.$result[0]-> q_currency_type;?></p>
</div>
</div>
<a href="<?php echo base_url('generate_quotation/').$result[0]->q_id;?>" class="btn btn-success btn-round waves-effect waves-light">
Download as  PDF</a>


</div>

</div>

</div>
</section>

<?php
}

?>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>


</body>




</html>