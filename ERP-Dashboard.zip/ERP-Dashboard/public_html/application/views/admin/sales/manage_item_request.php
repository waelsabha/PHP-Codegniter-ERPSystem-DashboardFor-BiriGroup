<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>



<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 

<style type="text/css">
  .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
  color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
  border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
  color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Item Request</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Item Request</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Manage Item Request</h2>

</header>

<?php echo form_open('submit_adj_qnty');?>
<input type="hidden" name="item_req_id" value="<?php echo $result[0]->ir_id;?>" class="form-control">
<div class="panel-body">
  
   <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result">
<table class="table table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
  <th >Item Request Number</th>  
  <th >Item Details</th> 
 
</tr>
</thead>
<tbody>

<tr class="gradeX">
 
      <td><?php echo $result[0]->ir_req_no;?></td>
      <td>
        <table class="table table-bordered"> 
          <thead>
            <th>#</th>
            <th>Item Name</th>
            <th>Original Quantity</th>
            <th>Adjusted Quantity</th>
          </thead>
          <tbody>
            <?php
            $a=1;
            $qnty=explode('|#|',$result[0]->ir_prd_qnty);
            //pre_list($prds);
            foreach($prds as $index=>$p)
              {?>
            <tr>
              <td><?php echo $a++;?></td>
              <td><?php echo $p[0]->pname;?><input type="hidden" name="prd_ids[]" value="<?php echo $p[0]->pid;?>"></td>
              <td><?php echo $qnty[$index];?></td>
              <td><input type="text" name="adj_qnty[]"></td>
            </tr>
            <?php
            }?>
          </tbody>
        </table>

      </td>
   
</tr>
<!-- Button trigger modal 2-->

<!----end modal--->

</tbody>
</table>
</div>

<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
</div>
<?php echo form_close();?>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>


<script type="text/javascript">
  $(document).ready(function()
  {
    ///$('.search_product_select').hide()

    var production_id=$("input[name='ordr_id']").val();
   
    $('.exact_delivery_date').hide();

   
    $('input:radio').change(function() {
      var ir_delivery_type = $("input[name='ir_delivery_type']:checked").val();
      if(ir_delivery_type=="Sold")
      {
        $('.exact_delivery_date').show();
      }
      if(ir_delivery_type=="Stock")
      {
        $('.exact_delivery_date').hide();
      }   
      });
 
$('.search_product_select').on("change",function(e)
{
  var prd_name=$('.search_product_select :selected').text();
var search_prd_id=$('.search_product_select :selected').val();
var category_selected=$("select[name='choose_category']").val();
var tablecount = $('table tbody tr').length;
  if(tablecount=="0")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }
  jQuery.ajax({
                url:"<?php echo base_url().'Product_order/search_product_id_quot';?>",
                type:"post",
                data:{"search_prd_id":search_prd_id},
                success:function(result)
                    {
                      //console.log(result);
                    var returndata = JSON.parse(result);
                    $('.prd_weight'+table_id).val(returndata.wgt);
                   $('.prd_en'+table_id).text(returndata.prd_name_en);
                   $('.prd_ar'+table_id).text(returndata.prd_name_ar);
                    $('.prd_code'+table_id).text(returndata.prd_name_ar);
                    }
            });

  $('.prd_name_selected').text(prd_name);
    //$('.prd_name').html(prd_name);
    var table_data=$('.new_rows').length;
    var i=table_data;
    var new_quantity='0';
    
        var markup = "<tr class='table"+table_id+"'>"+
        "<td><button type='button' onclick=table("+table_id+")>X</button></td>"+
        "<td ><input type='hidden' name='prd_id[]' value='"+search_prd_id+"'><input type='hidden' name='prdids'><span class='prd_en"+table_id+"'></span><br/><span class='prd_ar"+table_id+"'></span><br/><span class='prd_code"+table_id+"'></span>"+
        "</td><td><input type='hidden' name='qntys'>"+
        "<input type='number' class='qnty_val' name='qnty[]' ></td>"+
       "<td><input type='hidden' name='extra_detail'> <textarea name='extra_details[]' class='prd_extra_details"+table_id+"'></textarea></td>"+
        "</tr>";
            $("table tbody").append(markup);
     var rowcount = $('table tbody tr').length;
     $(".num_items").html(rowcount);
    });
  });

  function table(id)
  {
    $('table tbody .table'+id).remove();
    var rowcount = $('table tbody tr').length;
    $(".num_items").html(rowcount);
  }
   
$('.myform').submit(function() {
  
var rowcount = $('table tbody tr').length;
var product_id=$('table tbody tr td input[name="prd_id[]"]').map(function(){return $(this).val();}).get().join('|#|');
var quantity=$('table tbody tr td input[name="qnty[]"]').map(function(){return $(this).val();}).get().join('|#|');  
var extra_det=$('table tbody tr td textarea[name="extra_details[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
//console.log(quantity+' '+package_size+' '+product_id);

$("input[name='prdids']").val(product_id);
$("input[name='qntys']").val(quantity);
$("input[name='extra_detail']").val(extra_det);

var ij=0;

$('table tbody tr td').each(function() {  
var cellText = $(this).html(); 
   // console.log(cellText);  
    $('.cell_text_data').append(cellText).hide();
});

//console.log($("input[name='prdids']").val());
 //console.log($("input[name='variation_selected_val']").val());

 if(cellText=='')
  return false;
  else
   return true;
    
  //return false;

  // your code here
});
  
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
    tinymce.init({
      selector : '.editors',
        plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
    });
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

</body>

</html>