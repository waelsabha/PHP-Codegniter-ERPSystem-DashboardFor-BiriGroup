<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
 <link rel="stylesheet" type="text/css" href="<?php echo base_url('admin_assets/');?>waves.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('admin_assets/');?>feather.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('admin_assets/');?>widget.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('admin_assets/');?>style.css">
<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}

ul.timeline {
    list-style-type: none;
    position: relative;
}
ul.timeline:before {
    content: ' ';
    background: #d4d9df;
    display: inline-block;
    position: absolute;
    left: 29px;
    width: 2px;
    height: 100%;
    z-index: 400;
}
ul.timeline > li {
    margin: 20px 0;
    padding-left: 20px;
}
ul.timeline > li:before {
    content: ' ';
    background: white;
    display: inline-block;
    position: absolute;
    border-radius: 50%;
    border: 3px solid #22c0e8;
    left: 20px;
    width: 20px;
    height: 20px;
    z-index: 400;
}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>Quotation HISTORY</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Quotation</span></li>
<li><span>HISTORY</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Quotation HISTORY</h2>

</header>
<div class="panel-body">

<!----here starts the timeline-->

<div class="container mt-5 mb-5">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<h4>Quotation </h4>
			<ul class="timeline">
			<?php
if(!empty($result))
{
foreach($result as $t)
{?>
				<li>
					<small style="margin-left:3em;"><?php echo $t->act_date;?> <?php echo $t->act_time;?></small>
					<h6 style="margin-left:2em;"><?php echo $t->act_function;?> by <?php echo $t->act_user;?> </h6>
					<p class="text-muted m-b-0" style="margin-left:2em;">Function done:<?php echo $t->act_status;?> at <?php echo $t->act_date_time;?></p>
				</li>
				<?php
				}
				}
				?>
				
			</ul>
		</div>
	</div>
</div>

<!-- timeline end-->



</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/widget-data.js" type="text/javascript"></script>


</body>
</html>