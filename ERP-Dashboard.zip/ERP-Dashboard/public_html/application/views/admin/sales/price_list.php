<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
 

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
 <link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" type="text/css"/>


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
.countrypicker{
	max-height:100px;
}
.fa-whatsapp  {
  color:#fff;
  background:
  linear-gradient(#25d366,#25d366)10px 84%/15px 15px no-repeat,
  radial-gradient(#25d366 59%,transparent 0);
}
.row.display-flex {
  display: flex;
  flex-wrap: wrap;
}
.row.display-flex > [class*='col-'] {
  display: block;
  flex-direction: column;
}


</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2> Price List</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Check Price </span></li>
<li><span>Check</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>












<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Check Price  </h2>
</header>
<div class="panel-body">
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
  

    <input type="hidden" name="user_id" value="<?php if(!empty($result[0]->log_id)){echo $result[0]->log_id;};?>">
  


<div class="row">

<div class="col-md-12 table-rows-border">
<?php echo form_open('get_price_item');?>
		<div class="col-md-12 col-sm-12">
<label>Choose Product from list:</label>
<div class="input-group mb-md">
<select data-plugin-selectTwo class='form-control populate' class="form-control" name="price_list">
  <option>Choose</option>
  <?php
  foreach($prds as $v)
  {

    $prd_name=explode('|~~|',$v->pname);
    ?>
<option value="<?php echo $v->pid;?>" <?php if(!empty($option_choosed_form)){ if($option_choosed_form==$v->pid){echo "selected";}} ;?>><?php echo $prd_name[0].' '.$prd_name[1].' ::  <br/><br/> '.$v->pcode ;?></option>

    <?php
  }
  ?>
</select>
<span class="input-group-btn">
<button class="btn btn-success" type="submit">Submit</button>
</span>
</div>

 
</div>

</div>




<!-----div starts here for non-inquiry---
 -- Button trigger modal for sales invoice--
 <div id="modalmd_Pic" class="modal-block modal-block-lg mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Report This Picture</h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text modal_content_pic_report">
   
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button" onclick="submit_pic_report()"  class="btn btn-primary confirm_btn_modal">Confirm</button>
<button class="btn btn-default modal-dismiss modal-close-btn">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
----end modal---
---div closes here--->
<?php echo form_close();?>
</div>

<div class="row">

<!-----result goes here--->
<div class="col-md-12 col-sm-12 result_div">
<?php
if(!empty($result_data))
{
					if(empty($result_data[0]->p_prd_img))
						{
							$filename="https://birigroup.com/uploads/prd_images/".rawurlencode($result_data[0]->pcode).".jpeg";
						 if (file_exists($filename)) {
						 	$img_path=$filename;
							} else {
							$img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($result_data[0]->pcode).".jpg";
						    }
						}
						else
						{
							$first_img_prd=explode(',',$result_data[0]->p_prd_img);
							if(!empty($first_img_prd[0]))
						 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
						 	
						 	else
						 	$img_path="https://birigroup.com/uploads/prd_images/".$result_data[0]->p_prd_img."";
						 	
						}
$price_level1=(($result_data[0]->p_uae_final*10)/100);
		$price_level2=(($result_data[0]->p_uae_final*25)/100);
		  $product_full=explode(',',$result_data[0]->pname);
?>
<section class="panel">
  <div class="col-md-6 col-sm-6 ">
<header class="panel-heading bg-tertiary" >
<div class="panel-heading-profile-picture" style="height: 100%">
<img src="<?php echo $img_path;?>" style="width: 250px;height: 250px;border-radius: 50%;">


</div>

<p >Issue in Picture ? <a style="color: red;" href="<?php echo base_url('get_picture_report/'.$result_data[0]->pid);?>">Click here to Report this Picture</a></p>

</header>
</div>
 <div class="col-md-6 col-sm-6 ">
<div class="panel-body">
<h4 class="text-semibold mt-sm item_name"><?php echo $product_full[0].' '.$product_full[1];?></h4>
<p class="item_code">Code: <?php echo $result_data[0]->pcode;?> </p>
<?php
if($this->session->userdata['user']['role'] =='1'||$this->session->userdata['user']['main_dept']=="Main"||$this->session->userdata['user']['sub_dept']=="ksa")
{?>
<ul class="simple-bullet-list mb-xlg">
<li class="blue">
<span class="title">KSA Base Price: <?php echo ($result_data[0]->p_base_price);?> SAR</span>
</li>
</ul>
<?php }?>

<hr class="solid short">
<ul class="simple-bullet-list mb-xlg">
<div class="col-md-6 col-sm-6 ">
<li class="red">
<span class="title">UAE Final Price :<?php echo $result_data[0]->p_uae_final;?> AED</span>

</li>
<li class="green">
<span class="title">Level1 Price: <?php echo ($price_level1+$result_data[0]->p_uae_final);?> AED</span>
</li>

<li class="orange">
<span class="title">Level2 Price: <?php echo ($price_level2+$result_data[0]->p_uae_final);?> AED</span>
</li>
</div>
 <div class="col-md-6 col-sm-6 ">
 	<li class="red">
<span class="title">KSA Final Price :<?php if(!empty($result_data[0]->p_ksa)){
	$ksa_final=$result_data[0]->p_ksa;
	$ksa_reg=($ksa_final*0.10);
	$ksa_comp=($ksa_final*0.20);
	$ksa_retail=($ksa_final*0.50);
	echo $ksa_final;
	}
	else{
	$ksa_final=$result_data[0]->p_uae_final+12.5;
	$ksa_reg=($ksa_final*0.10);
	$ksa_comp=($ksa_final*0.20);
	$ksa_retail=($ksa_final*0.50);
	echo $ksa_final;}?> AED</span>

</li>
<li class="green">
<span class="title">KSA Reg#1: <?php echo ($ksa_reg+$ksa_final);?> AED</span>
</li>

<li class="orange">
<span class="title">KSA Companies: <?php echo ($ksa_comp+$ksa_final);?> AED</span>
</li>

<li class="orange">
<span class="title">KSA Retail: <?php echo ($ksa_retail+$ksa_final);?> AED</span>
</li>
 </div>
 <div class="col-md-12 col-sm-12 ">
<li class="red">
<span class="title">DXB Quantity :
<?php 
if($stock_data[0]->ps_dxb_qnty < 0)
{
echo $stock_data[0]->ps_dxb_qnty.' <b style="color:red;">Contact Warehouse Supervisor</b>';
}
else
{
echo $stock_data[0]->ps_dxb_qnty;
}?> </span>
<small>Date & Time :<?php echo $stock_data[0]->ps_date;?> <?php echo $stock_data[0]->ps_time;?></small>
</li>
<li class="green">
<span class="title">RAK Quantity: 
<?php 
if($stock_data[0]->ps_rak_qnty < 0)
{
echo $stock_data[0]->ps_rak_qnty.' <b style="color:red;">Contact Warehouse Supervisor</b>';
}
else
{
echo $stock_data[0]->ps_rak_qnty;
}?></span>
<small>Date & Time :<?php echo $stock_data[0]->ps_date;?> <?php echo $stock_data[0]->ps_time;?></small>
</li>

<p>Issue in stock quantity? <a href="<?php echo base_url('raise_stock_ticket/'.$result_data[0]->pid);?>"> Click here to Raise ticket now</a></p>

<li class="orange">
<span class="title">Click to see datasheet: 
<?php if(!empty($result_data[0]->p_datasheets))
{?>
<a href="https://ad.birigroup.ae/uploads/production/datasheets/<?php echo $result_data[0]->p_datasheets;?>" target="_blank">
<?php echo $result_data[0]->p_datasheets;?> </a></span>
<?php
}?>
</li>
</div>
</ul>
</div>
</div>
</section>
<?php
}?>
</div>
<!-----result ends here--->
<div class="clearfix"></div>


<!-----result of more products goes here--->
<br/>
<div class="row display-flex">
<div class="col-md-12 col-sm-12 col-xs-12">
<h3>More products in this category</h3>
<?php
if(!empty($more_this_cat))
{
foreach($more_this_cat as $indx=>$mc)
{
if($mc->pid!=$option_choosed_form)
{
if(empty($mc->p_prd_img))
						{
							$filename="https://birigroup.com/uploads/prd_images/".rawurlencode($mc->pcode).".jpeg";
						 if (file_exists($filename)) {
						 	$img_path=$filename;
							} else {
							$img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($mc->pcode).".jpg";
						    }
						}
						else
						{
							$first_img_prd=explode(',',$mc->p_prd_img);
							if(!empty($first_img_prd[0]))
						 	$img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
						 	
						 	else
						 	$img_path="https://birigroup.com/uploads/prd_images/".$mc->p_prd_img."";
						 	
						}
$price_level1=(($mc->p_uae_final*10)/100);
		$price_level2=(($mc->p_uae_final*25)/100);
		  $product_full=explode(',',$mc->pname);
?>
<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="display:flex;">
<section class="panel">
<div class="panel-body">
<div class="thumb-info mb-md">
<img src="<?php echo $img_path;?>" class="rounded img-responsive" alt="">

</div>

<div class="col-md-12 col-sm-12 ">
<div class="panel-body">
<h4 class="text-semibold mt-sm item_name"><?php echo $product_full[0].' '.$product_full[1];?></h4>
<p class="item_code">Code: <?php echo $mc->pcode;?> </p>
<hr class="solid short">
<ul class="simple-bullet-list mb-xlg">

<li class="red">
<span class="title">UAE Final Price :<?php echo $mc->p_uae_final;?> AED</span>

</li>
<li class="green">
<span class="title">Level1 Price: <?php echo ($price_level1+$mc->p_uae_final);?> AED</span>
</li>

<li class="orange">
<span class="title">Level2 Price: <?php echo ($price_level2+$mc->p_uae_final);?> AED</span>
</li>
<li class="red">
<span class="title">KSA Final Price :<?php if(!empty($mc->p_ksa)){
	$ksa_final=$mc->p_ksa;
	$ksa_reg=($ksa_final*0.10);
	$ksa_comp=($ksa_final*0.20);
	$ksa_retail=($ksa_final*0.50);
	echo $ksa_final;
	}
	else{
	$ksa_final=$mc->p_uae_final+12.5;
	$ksa_reg=($ksa_final*0.10);
	$ksa_comp=($ksa_final*0.20);
	$ksa_retail=($ksa_final*0.50);
	echo $ksa_final;}?> AED</span>

</li>
<li class="green">
<span class="title">KSA Reg#1: <?php echo ($ksa_reg+$ksa_final);?> AED</span>
</li>

<li class="orange">
<span class="title">KSA Companies: <?php echo ($ksa_comp+$ksa_final);?> AED</span>
</li>

<li class="orange">
<span class="title">KSA Retail: <?php echo ($ksa_retail+$ksa_final);?> AED</span>
</li>
<li class="red">
<span class="title">DXB Quantity :
<?php 
if($sub_cat_stock[$indx][0]->ps_dxb_qnty < 0)
{
echo $sub_cat_stock[$indx][0]->ps_dxb_qnty.' <b style="color:red;">Contact Warehouse Supervisor</b>';
}
else
{
echo $sub_cat_stock[$indx][0]->ps_dxb_qnty;
}?> </span>

</li>
<li class="green">
<span class="title">RAK Quantity: 
<?php 
if($sub_cat_stock[$indx][0]->ps_rak_qnty < 0)
{
echo $sub_cat_stock[$indx][0]->ps_rak_qnty.' <b style="color:red;">Contact Warehouse Supervisor</b>';
}
else
{
echo $sub_cat_stock[$indx][0]->ps_rak_qnty;
}?></span>
</li>
<p>Issue in stock quantity? <a href="<?php echo base_url('raise_stock_ticket/'.$mc->pid);?>"> Click here to Raise ticket now</a></p>
</ul>
</div>
</div>

</div>
</section>


</div>

<?php
}
}
}?>
</div>
</div>
<!-----end of more products-->



</div>

</div>
</section>

</div>
</div>




</section>
</div>
</section>



















<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script type="text/javascript">
  
  $(document).ready(function()
 {
     $(".submit_button").click(function() {
      //console.log('in choose cat');
    
    var category_selected=$("select[name='price_list']").val();
   // console.log(category_selected);
     jQuery.ajax({
                     url:"<?php echo base_url().'Quotation_controller/get_price_item';?>",
                    type:"post",
                     data:{"category_selected":category_selected},
                    success:function(result)
                    {
                     //console.log(result);
                    $('.result_div').html(result);
                    $('.result_div').show();
                    }
                });
    });
 });




</script>

</html>