<!doctype html>
<html class="fixed">


<head>

<?php $this->load->view('admin/head');?>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/morris/morris.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/pie_country.css" />
<style type="text/css">
    .form_error 
{font-size: 18px;font-family:Arial;color:red;font-style:italic;}
.form_error p .errors{
    color: red;
}
.errors
{font-size: 18px;font-family:Arial;color:red;font-style:italic;}
.success
{font-size: 18px;font-family:Arial;color:green;font-style:italic;}

.datepicker{z-index:18000 !important;}
.dropdown-divider
{
    border-bottom: 1px solid #08c;
}

.datepicker table tr td.today
{
    background-color:blue;
    color:white;
    border-radius: 50%;
}


@-webkit-keyframes glowing {
  0% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -webkit-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
}

@-moz-keyframes glowing {
  0% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -moz-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
}

@-o-keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

@keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

</style>
<style type="text/css">
    .dot {
  height: 25px;
  width: 25px;
  border-radius: 50%;
  display: inline-block;
}
</style>
</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>



<section role="main" class="content-body">
<header class="page-header">
<h2>Dashboard</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Dashboard</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>



<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg">Total Count
<div class="row">
<div class="col-md-6 col-xl-6">
<section class="panel">
<div class="panel-body bg-danger">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Total Amounts due</h4>
<div class="info">
  <h2 class="title">
<strong>
  <?php if(!empty($totaldue)){echo $totaldue;}?>
 </strong>
 </h2>
</div>
</div>

</div>
</div>
</div>
</section>
</div>


</div>
</div>

</div>
<!-- we will try for block for month quarter week and month-->



<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg">Monthely Target And Quarter
<div class="row">
<div class="col-md-6 col-xl-6">
<section class="panel">
<div class="panel-body bg-white">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
  <?php if($monthly_status=='warning'){?>  <h5  style="background-color: #fef3c3;
                          color: red;
                         ">less than Target per 15% <i style="background-color: #fef3c3;
                          color: red;" class="fa fa-warning"></i></h5>    <?php     }?>


                            <?php if($monthly_status=='danger'){?> <h5  style="background-color: #da0606;
                          color: white;
                          ">Level Down <i style="
                          color: yellow;"  class="fa fa-thumbs-down"></i> </h5>     <?php     }?>

                          <?php if($monthly_status=='great'){?>  <h5  style="background-color: #06da26;
                          color: white;
                         ">Great Work<i style="background-color: #06da26;
                          color: yellow;"  class="fa fa-star"></i><i style="background-color: #06da26;
                          color: yellow;"  class="fa fa-star"></i> </h5>    <?php     }?>

                          <?php if($monthly_status=='done'){?>  <h5  style="background-color: #06da26;
                          color: white;
                    ">Done <i style="background-color: #06da26;
                          color: yellow;" class="fa fa-thumbs-up"></i></h5>    <?php     }?>

</div>
</div>
<div class="widget-summary-col">
<div class="summary">
Your Target For This Month
<div class="info">

  <?php if(!empty($monthely_requested_target)){echo $monthely_requested_target;}?>
 
</div>

</div>
<div class="widget-summary-col">
<div class="summary">
<h5 class="title">Your Achivment Till Now</h5>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalmonth)){echo $totalmonth;}?>  <p> </p>
 </strong>
  </h2>

       
        

</div>
</div>

<div class="summary">
<h5 class="title"><?php if(!empty($monthely_requested_target>$totalmonth)){echo 'remaining to achive';}else{echo 'extra above achivement';}?> </h5>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalmonth)){if($monthely_requested_target>$totalmonth) {echo (intval($monthely_requested_target-$totalmonth));}else{echo (intval($totalmonth-$monthely_requested_target));}}?> 
 </strong>
  </h2>

       
        

</div>
</div>



<div class="summary">
<h5 class="title">Achivement percentage:</h5>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalmonth &&$monthely_requested_target )){echo (intval(($totalmonth/$monthely_requested_target)*100));}?>%
 </strong>
  </h2>

      
        

</div>
</div>

</div>
</div>

</div>
</div>
</section>
</div>
<div class="col-md-6 col-xl-6">
<section class="panel">
<div class="panel-body bg-white">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">



   <?php if($quarter_status=='warning'){?>  <h5  style="background-color: #fef3c3;
                          color: red;
                         ">less than Target per 15% <i style="background-color: #fef3c3;
                          color: red;" class="fa fa-warning"></i></h5>    <?php     }?>


                            <?php if($quarter_status=='danger'){?> <h5  style="background-color: #da0606;
                          color: white;
                         ">Level Down <i style="
                          color: yellow;"  class="fa fa-thumbs-down"></i> </h5>    <?php     }?>

                          <?php if($quarter_status=='great'){?> <h5  style="background-color: #06da26;
                          color: white;
                         ">Great Work<i style="background-color: #06da26;
                          color: yellow;"  class="fa fa-star"></i><i style="background-color: #06da26;
                          color: yellow;"  class="fa fa-star"></i> </h5>    <?php     }?>

                          <?php if($quarter_status=='done'){?> <h5  style="background-color: #06da26;
                          color: white;
                    ">Done <i style="background-color: #06da26;
                          color: yellow;" class="fa fa-thumbs-up"></i></h5>     <?php     }?>
 
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
Your Target For <?php if(!empty($current_quarter)){echo $current_quarter;}?> Quarter
<div class="info">

  <?php if(!empty($quarter_requested_target)){echo $quarter_requested_target;}?>

</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Your Achivment Till Now</h4>
<div class="info">
<h2 class="title">
    <strong>
      <?php if(!empty($totalqouarter)){echo $totalqouarter;}?> 
      </strong>
    </h2>
  
</div>
</div>



<div class="summary">
<h5 class="title"><?php if(!empty($quarter_requested_target>$totalqouarter)){echo 'remaining to achive';}else{echo 'extra above achivement';}?> </h5>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalqouarter)){if($quarter_requested_target>$totalqouarter) {echo (intval($quarter_requested_target-$totalqouarter));}else{echo (intval($totalqouarter-$quarter_requested_target));}}?> 
 </strong>
  </h2>

       
        

</div>
</div>


<div class="summary">
<h5 class="title">Achivement percentage:</h5>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalqouarter &&$quarter_requested_target )){echo (intval(($totalqouarter/$quarter_requested_target)*100));}?>%
 </strong>
  </h2>

       
        

</div>
</div>

</div>
</div>

</div>
</div>
</section>
</div>


</div>
</div>

</div>




<!-- second Row------>




<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg">WeekLy Target And Daily
<div class="row">
<div class="col-md-6 col-xl-6">
<section class="panel">
<div class="panel-body bg-trancperant">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
 <?php if($weekly_status=='warning'){?>   <h5  style="background-color: #fef3c3;
                          color: red;
                         ">less than Target per 15% <i style="background-color: #fef3c3;
                          color: red;" class="fa fa-warning"></i></h5>     <?php     }?>


                            <?php if($weekly_status=='danger'){?>  <h5  style="background-color: #da0606;
                          color: white;
                          ">Level Down <i style="
                          color: yellow;"  class="fa fa-thumbs-down"></i> </h5>     <?php     }?>

                          <?php if($weekly_status=='great'){?>  <h5  style="background-color: #06da26;
                          color: white;
                         ">Great Work<i style="background-color: #06da26;
                          color: yellow;"  class="fa fa-star"></i><i style="background-color: #06da26;
                          color: yellow;"  class="fa fa-star"></i> </h5>  <?php     }?>

                          <?php if($weekly_status=='done'){?> <h5  style="background-color: #06da26;
                          color: white;
                    ">Done <i style="background-color: #06da26;
                          color: yellow;" class="fa fa-thumbs-up"></i></h5>  <?php     }?>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
Target  <?php if(!empty($num_week_by_month)){echo $num_week_by_month;}?> of month
<div class="info">
<strong>
  <?php if(!empty($weekly_requested_target)){echo $weekly_requested_target;}?>
 </strong>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Your Achivment Till Now</h4>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalweek)){echo $totalweek;}?>

 </strong>
</h2>
</div>
</div>


<div class="summary">
<h5 class="title"><?php if(!empty($weekly_requested_target>$totalweek)){echo 'remaining to achive';}else{echo 'extra above achivement';}?> </h5>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalqouarter)){if($weekly_requested_target>$totalweek) {echo (intval($weekly_requested_target-$totalweek));}else{echo (intval($totalweek-$weekly_requested_target));}}?> 
 </strong>
  </h2>

       
        

</div>
</div>


<div class="summary">
<h5 class="title">Achivement percentage:</h5>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalweek &&$weekly_requested_target )){echo (intval(($totalweek/$weekly_requested_target)*100));}?>%
 </strong>
  </h2>

       
        

</div>
</div>

</div>
</div>

</div>
</div>
</section>
</div>
<div class="col-md-6 col-xl-6">
<section class="panel">
<div class="panel-body bg-white">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
 <?php if($daily_status=='warning'){?>   <h5  style="background-color: #fef3c3;
                          color: red;
                         ">less than Target per 15% <i style="background-color: #fef3c3;
                          color: red;" class="fa fa-warning"></i></h5>    <?php     }?>


                            <?php if($daily_status=='danger'){?>   <h5  style="background-color: #da0606;
                          color: white;
                         ">Level Down <i style="
                          color: yellow;"  class="fa fa-thumbs-down"></i> </h5>     <?php     }?>

                          <?php if($daily_status=='great'){?> <h5  style="background-color: #06da26;
                          color: white;
                         ">Great Work<i style="background-color: #06da26;
                          color: yellow;"  class="fa fa-star"></i><i style="background-color: #06da26;
                          color: yellow;"  class="fa fa-star"></i> </h5>  <?php     }?>

                          <?php if($daily_status=='done'){?> <h5  style="background-color: #06da26;
                          color: white;
                    ">Done <i style="background-color: #06da26;
                          color: yellow;" class="fa fa-thumbs-up"></i></h5>   <?php     }?>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
Target For  <?php //if(!empty($num_day_of_week)){echo $num_day_of_week;}?>Today sales
<div class="info">
<strong>
  <?php if(!empty($daily_requested_target)){echo $daily_requested_target;}?>
 </strong>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title">Your Achivment Till Now</h4>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalday)){echo $totalday;}?>

   
 </strong>
</h2>
</div>
</div>

<div class="summary">
<h5 class="title"><?php if(!empty($daily_requested_target>$totalday)){echo 'remaining to achive';}else{echo 'extra above achivement';}?> </h5>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalqouarter)){if($daily_requested_target>$totalday) {echo (intval($daily_requested_target-$totalday));}else{echo (intval($totalday-$daily_requested_target));}}?> 
 </strong>
  </h2>

       
        

</div>
</div>

<div class="summary">
<h5 class="title">Achivement percentage:</h5>
<div class="info">
<h2 class="title">
    <strong>
  <?php if(!empty($totalday &&$daily_requested_target )){echo (intval(($totalday/$daily_requested_target)*100));}?>%
 </strong>
  </h2>

       
        

</div>
</div>

</div>
</div>

</div>
</div>
</section>
</div>


</div>
</div>

</div>





<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Total Sales Data comparison</h2>
</header>
<div class="panel-body">
<div id="container0" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
</div>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Sales Data comparison</h2>
</header>
<div class="panel-body">
<div id="container1" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>

<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Product Sales per Category(for current year and previous year)</h2>
</header>
<div class="panel-body">
<div id="container6" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>












<!--endof try-->





<!-- try to get sales unpaid and partially -->


<div class="data_result">
<table class="table table-responsive table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th class="action_class"><?php echo $this->lang->line('Action'); ?></th>

<th><?php echo $this->lang->line('Doc_No'); ?></th>
<th><?php echo $this->lang->line('Date'); ?></th>
<th><?php echo $this->lang->line('Company'); ?></th>
<th><?php echo $this->lang->line('Customer'); ?> </th>
<th><?php echo $this->lang->line('Narration'); ?></th>
<th><?php echo $this->lang->line('Due_Amount'); ?></th>
<th><?php echo $this->lang->line('Total_Amount'); ?></th>
<th><?php echo $this->lang->line('Delivery_Status'); ?></th>
<th><?php echo $this->lang->line('Status'); ?></th>
</tr>
</thead>
<tbody>
<?php
if(!empty($sales_not_paid))
{
  $i=1;
foreach($sales_not_paid as $t)
{
  
  ?>
<tr>
<td class="action_class">
      <div class="dropdown-primary dropdown " <?php if($i==1){echo "style='display:contents';";};?>>
<button class="btn btn-primary dropdown-toggle waves-effect waves-light" type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" ><?php echo $this->lang->line('Action'); ?> </button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">
  <a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalmd_sinv" onclick="get_doc_details(<?php echo $t['si_id'];?>,'<?php echo $page_type;?>');"><i class="fa fa-eye"></i><?php echo $this->lang->line('View'); ?></a>
<?php
if($this->session->userdata['user']['role'] !='1')
{
if($t['si_current_sts']=="not-paid"||"partially_paid")
{?>
<div class="dropdown-divider"></div>

<a class="dropdown-item waves-light waves-effect modalmd_edit" href="<?php echo base_url('Sales_invoice/sales_invoice_page/'.$page_type.'/'.$t['si_id']);?>" onclick="check_edit('<?php echo $t['si_id'];?>,<?php echo $page_type;?>');" ><i class="fa fa-pencil"></i><?php echo $this->lang->line('Edit_Details'); ?></a>
<?php } ?>
<a class="dropdown-item waves-light waves-effect modalmd_edit"  style="display: none;" ><i class="fa fa-pencil"></i><?php echo $this->lang->line('Open_edit_modal'); ?></a>

<?php

}
else
{
  if($t['si_delivery_sts']!='delivered')
{
  
  
  ?>
<div class="dropdown-divider"></div>

<a class="dropdown-item waves-light waves-effect modalmd_edit" href="<?php echo base_url('Sales_invoice/sales_invoice_page/'.$page_type.'/'.$t['si_id']);?>" onclick="check_edit('<?php echo $t['si_id'];?>,<?php echo $page_type;?>');" ><i class="fa fa-pencil"></i><?php echo $this->lang->line('Edit_Details'); ?></a>
<a class="dropdown-item waves-light waves-effect modalmd_edit"  style="display: none;" ><i class="fa fa-pencil"></i><?php echo $this->lang->line('Open_edit_modal'); ?> </a>

<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalsm2<?php echo $t['si_id'];?>"><i class="fa fa-trash-o"></i><?php echo $this->lang->line('Delete'); ?> </a>
<?php
}
else{}
}?> 
<div class="dropdown-divider"></div>
<!-- <a class="dropdown-item waves-light waves-effect" href=""><i class="fa fa-pdf"></i>Generate PDF </a> -->
<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modalsm_pdf<?php echo $t['si_id'];?>"><i class="fa fa-pdf"></i><?php echo $this->lang->line('Generate_Pdf'); ?></a>
</div>
  </td> 
  <td><?php echo $t['si_doc_no'];?></td>
  <td><?php echo $t['si_date'];?> </td>
  <td><?php echo $t['mcomp_name'];?> </td>  
  <td><?php echo $t['cust_acc'];?></td>   
  <td><?php echo $t['si_narration'];?></td> 
  <td><?php echo round($t['atx_bal_amount'],2); ?></td>
  <td><?php echo round($t['si_tot_amount'],2); ?></td>
  <td>
    <?php if($t['si_delivery_sts']=="not_delivered")
      {
        ?>
      <span class="label label-danger"><?php echo $this->lang->line('Not_Delivered'); ?></span>
      <?php
      }

              else if($t['si_delivery_sts']=="fully_returned")
      {
        ?>
      <span class="label label-warning"><?php echo $this->lang->line('Returened_All'); ?></span>
      <?php
      }
      else if($t['si_delivery_sts']=="partially_returned")
      {
        ?>
      <span class="label label-warning"><?php echo $this->lang->line('partially_Returened'); ?></span>
      <?php
      }
        else if($t['si_delivery_sts']=="partially_delivered")
      {
        ?>
      <span class="label label-warning"><?php echo $this->lang->line('Partially_Delivered'); ?></span>
      <?php
      }
       else if($t['si_delivery_sts']=="wrong_deliverd")
      {
        ?>
      <span class="label label-warning"><?php echo $this->lang->line('Wrong_Delivered'); ?></span>
      <?php
      }
      else if($t['si_delivery_sts']=="delivered")
      {
        ?>
        <span class="label label-success"><?php echo $this->lang->line('Delivered'); ?></span>
    
        <?php
      }
      ?>
  </td> 
 <td> 
    <?php if($t['si_current_sts']=="not-paid")
    {
      ?>
    <span class="label label-danger"><?php echo $this->lang->line('Not_paid'); ?></span>
    <?php
    }
    elseif($t['si_current_sts']=="fully-paid")
    {
      ?>
  <span class="label label-success"><?php echo $this->lang->line('Paid'); ?></span> 
      <?php
    }
    else
    {
      ?>
      <span class="label label-warning"><?php echo $this->lang->line('Partially_Paid'); ?></span>
  
      <?php
    }
    ?>
  </td>    
</tr>

<!-- Button trigger modal 3-->
 <div id="modalsm2<?php echo $t['si_id'];?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"><?php echo $this->lang->line('Are You Sure?'); ?> </h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
    <p>  <?php echo $this->lang->line('Are you sure, you want to delete this payment details permanently?'); ?>
      <small style="color: red"><?php echo $this->lang->line('This action cannot be undone?'); ?>.</small>
    </p>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<a href="<?php echo base_url('Sales_invoice/delete_invoice/'.$page_type.'/'.$t['si_id']);?>"  class="btn btn-primary"><?php echo $this->lang->line('Confirm'); ?></a>
<button class="btn btn-default modal-dismiss"><?php echo $this->lang->line('Cancel'); ?></button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!----end modal--->

<!-- Button trigger modal 3-->
 <div id="modalsm_pdf<?php echo $t['si_id'];?>" class="modal-block modal-block-sm mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"><?php echo $this->lang->line('Generate PDF'); ?></h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
  <?php echo form_open('Sales_invoice/generate_invoice_pdf/'.$page_type);?>
    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"><?php echo $this->lang->line('Choose option to print Invoice as'); ?><abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
  <input type="hidden" name="sales_inv_id" value="<?php echo $t['si_id'];?>">
 <input type='radio' name="pdf-print-option" value="1" ><?php echo $this->lang->line('With Letter-head'); ?><br/>
 <input type='radio' name="pdf-print-option" value="2" ><?php echo $this->lang->line('Without Letter-head'); ?><br/>
</div>
</div>

</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="submit" class="btn btn-primary"><?php echo $this->lang->line('Confirm'); ?></button>
<button class="btn btn-default modal-dismiss"><?php echo $this->lang->line('Cancel'); ?></button>
</div>
</div>
</footer>
<?php echo form_close();?>
</section>
</div>
<!----end modal--->

<?php
$i++;
}
}?>
</tbody>
</table>
</div>









<!-- end of unpaid invoices -->












<!--closing row-->



<div class="row">
<div class="col-md-12 col-lg-12 col-xl-12">
<h5 class="text-semibold text-dark text-uppercase mb-md mt-lg"><?php echo $this->lang->line('Return ORDER'); ?>
<div class="row">
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-tertiary">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-shopping-cart"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $this->lang->line('NEW Returned'); ?></h4>
<div class="info">
<strong>
<?php if(!empty($new_return)){print_r($new_return);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<div class="col-md-4 col-xl-4">
<section class="panel">
<div class="panel-body bg-info">
<div class="widget-summary">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa fa-thumbs-up"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $this->lang->line('Approved return'); ?></h4>
<div class="info">
<strong>
<?php if(!empty($approved_return)){print_r($approved_return);};?>
 </strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>




</div>
</div>

</div>




<?php  $this->load->view('admin/sales/all_returned_pending',$return_result);?>

<?php  $this->load->view('admin/sales/all_returned_approved',$return_result_approve);?>

<!--closing row-->





<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Pie Chart</h2>
<p class="panel-subtitle">Default Pie Chart</p>
</header>
<div class="panel-body">

<div id="container1" ></div>


</div>
</section>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Country wise Customers</h2>
<p class="panel-subtitle">World Map</p>
</header>
<div class="panel-body">

<!-- <div id="container2" style="min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div> -->
<div id="chartdiv" style="min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>

</div>
</section>




</section>



</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-appear/jquery.appear.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>







<script src="https://www.amcharts.com/lib/4/core.js"></script>
<script src="https://www.amcharts.com/lib/4/charts.js"></script>
<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>
<script type="text/javascript">
    /**
 * ---------------------------------------
 * This demo was created using amCharts 4.
 * 
 * For more information visit:
 * https://www.amcharts.com/
 * 
 * Documentation is available at:
 * https://www.amcharts.com/docs/v4/
 * ---------------------------------------
 */





 












// Themes begin
am4core.useTheme(am4themes_animated);
//

var chart = am4core.create("container1", am4charts.PieChart3D);
chart.hiddenState.properties.opacity = 0; // this creates initial fade-in

chart.data = [
<?php
$i=0;
foreach($pie_result as $t)
{
    echo '{country:"'.$t->name.'", 
    litres:'.$t->row_count.'},';
    $i++;
}
;?>
];

chart.innerRadius = am4core.percent(40);
chart.depth = 120;

chart.legend = new am4charts.Legend();

var series = chart.series.push(new am4charts.PieSeries3D());
series.dataFields.value = "litres";
series.dataFields.depthValue = "litres";
series.dataFields.category = "country";
series.slices.template.cornerRadius = 5;
series.colors.step = 3;


</script>


<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>




<script src="https://www.amcharts.com/lib/4/maps.js"></script>
<script src="https://www.amcharts.com/lib/4/geodata/worldLow.js"></script>


<script type="text/javascript">
   /**
 * ---------------------------------------
 * This demo was created using amCharts 4.
 * 
 * For more information visit:
 * https://www.amcharts.com/
 * 
 * Documentation is available at:
 * https://www.amcharts.com/docs/v4/
 * ---------------------------------------
 */

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

// Create map instance
var chart = am4core.create("chartdiv", am4maps.MapChart);

var title = chart.titles.create();
title.text = "[bold font-size: 20]Customers per country[/]";
title.textAlign = "middle";

var latlong = {
  "AD": {"latitude":42.5, "longitude":1.5},
  "AE": {"latitude":24, "longitude":54},
  "AF": {"latitude":33, "longitude":65},
  "AG": {"latitude":17.05, "longitude":-61.8},
  "AI": {"latitude":18.25, "longitude":-63.1667},
  "AL": {"latitude":41, "longitude":20},
  "AM": {"latitude":40, "longitude":45},
  "AN": {"latitude":12.25, "longitude":-68.75},
  "AO": {"latitude":-12.5, "longitude":18.5},
  "AP": {"latitude":35, "longitude":105},
  "AQ": {"latitude":-90, "longitude":0},
  "AR": {"latitude":-34, "longitude":-64},
  "AS": {"latitude":-14.3333, "longitude":-170},
  "AT": {"latitude":47.3333, "longitude":13.3333},
  "AU": {"latitude":-27, "longitude":133},
  "AW": {"latitude":12.5, "longitude":-69.9667},
  "AZ": {"latitude":40.5, "longitude":47.5},
  "BA": {"latitude":44, "longitude":18},
  "BB": {"latitude":13.1667, "longitude":-59.5333},
  "BD": {"latitude":24, "longitude":90},
  "BE": {"latitude":50.8333, "longitude":4},
  "BF": {"latitude":13, "longitude":-2},
  "BG": {"latitude":43, "longitude":25},
  "BH": {"latitude":26, "longitude":50.55},
  "BI": {"latitude":-3.5, "longitude":30},
  "BJ": {"latitude":9.5, "longitude":2.25},
  "BM": {"latitude":32.3333, "longitude":-64.75},
  "BN": {"latitude":4.5, "longitude":114.6667},
  "BO": {"latitude":-17, "longitude":-65},
  "BR": {"latitude":-10, "longitude":-55},
  "BS": {"latitude":24.25, "longitude":-76},
  "BT": {"latitude":27.5, "longitude":90.5},
  "BV": {"latitude":-54.4333, "longitude":3.4},
  "BW": {"latitude":-22, "longitude":24},
  "BY": {"latitude":53, "longitude":28},
  "BZ": {"latitude":17.25, "longitude":-88.75},
  "CA": {"latitude":54, "longitude":-100},
  "CC": {"latitude":-12.5, "longitude":96.8333},
  "CD": {"latitude":0, "longitude":25},
  "CF": {"latitude":7, "longitude":21},
  "CG": {"latitude":-1, "longitude":15},
  "CH": {"latitude":47, "longitude":8},
  "CI": {"latitude":8, "longitude":-5},
  "CK": {"latitude":-21.2333, "longitude":-159.7667},
  "CL": {"latitude":-30, "longitude":-71},
  "CM": {"latitude":6, "longitude":12},
  "CN": {"latitude":35, "longitude":105},
  "CO": {"latitude":4, "longitude":-72},
  "CR": {"latitude":10, "longitude":-84},
  "CU": {"latitude":21.5, "longitude":-80},
  "CV": {"latitude":16, "longitude":-24},
  "CX": {"latitude":-10.5, "longitude":105.6667},
  "CY": {"latitude":35, "longitude":33},
  "CZ": {"latitude":49.75, "longitude":15.5},
  "DE": {"latitude":51, "longitude":9},
  "DJ": {"latitude":11.5, "longitude":43},
  "DK": {"latitude":56, "longitude":10},
  "DM": {"latitude":15.4167, "longitude":-61.3333},
  "DO": {"latitude":19, "longitude":-70.6667},
  "DZ": {"latitude":28, "longitude":3},
  "EC": {"latitude":-2, "longitude":-77.5},
  "EE": {"latitude":59, "longitude":26},
  "EG": {"latitude":27, "longitude":30},
  "EH": {"latitude":24.5, "longitude":-13},
  "ER": {"latitude":15, "longitude":39},
  "ES": {"latitude":40, "longitude":-4},
  "ET": {"latitude":8, "longitude":38},
  "EU": {"latitude":47, "longitude":8},
  "FI": {"latitude":62, "longitude":26},
  "FJ": {"latitude":-18, "longitude":175},
  "FK": {"latitude":-51.75, "longitude":-59},
  "FM": {"latitude":6.9167, "longitude":158.25},
  "FO": {"latitude":62, "longitude":-7},
  "FR": {"latitude":46, "longitude":2},
  "GA": {"latitude":-1, "longitude":11.75},
  "GB": {"latitude":54, "longitude":-2},
  "GD": {"latitude":12.1167, "longitude":-61.6667},
  "GE": {"latitude":42, "longitude":43.5},
  "GF": {"latitude":4, "longitude":-53},
  "GH": {"latitude":8, "longitude":-2},
  "GI": {"latitude":36.1833, "longitude":-5.3667},
  "GL": {"latitude":72, "longitude":-40},
  "GM": {"latitude":13.4667, "longitude":-16.5667},
  "GN": {"latitude":11, "longitude":-10},
  "GP": {"latitude":16.25, "longitude":-61.5833},
  "GQ": {"latitude":2, "longitude":10},
  "GR": {"latitude":39, "longitude":22},
  "GS": {"latitude":-54.5, "longitude":-37},
  "GT": {"latitude":15.5, "longitude":-90.25},
  "GU": {"latitude":13.4667, "longitude":144.7833},
  "GW": {"latitude":12, "longitude":-15},
  "GY": {"latitude":5, "longitude":-59},
  "HK": {"latitude":22.25, "longitude":114.1667},
  "HM": {"latitude":-53.1, "longitude":72.5167},
  "HN": {"latitude":15, "longitude":-86.5},
  "HR": {"latitude":45.1667, "longitude":15.5},
  "HT": {"latitude":19, "longitude":-72.4167},
  "HU": {"latitude":47, "longitude":20},
  "ID": {"latitude":-5, "longitude":120},
  "IE": {"latitude":53, "longitude":-8},
  "IL": {"latitude":31.5, "longitude":34.75},
  "IN": {"latitude":20, "longitude":77},
  "IO": {"latitude":-6, "longitude":71.5},
  "IQ": {"latitude":33, "longitude":44},
  "IR": {"latitude":32, "longitude":53},
  "IS": {"latitude":65, "longitude":-18},
  "IT": {"latitude":42.8333, "longitude":12.8333},
  "JM": {"latitude":18.25, "longitude":-77.5},
  "JO": {"latitude":31, "longitude":36},
  "JP": {"latitude":36, "longitude":138},
  "KE": {"latitude":1, "longitude":38},
  "KG": {"latitude":41, "longitude":75},
  "KH": {"latitude":13, "longitude":105},
  "KI": {"latitude":1.4167, "longitude":173},
  "KM": {"latitude":-12.1667, "longitude":44.25},
  "KN": {"latitude":17.3333, "longitude":-62.75},
  "KP": {"latitude":40, "longitude":127},
  "KR": {"latitude":37, "longitude":127.5},
  "KW": {"latitude":29.3375, "longitude":47.6581},
  "KY": {"latitude":19.5, "longitude":-80.5},
  "KZ": {"latitude":48, "longitude":68},
  "LA": {"latitude":18, "longitude":105},
  "LB": {"latitude":33.8333, "longitude":35.8333},
  "LC": {"latitude":13.8833, "longitude":-61.1333},
  "LI": {"latitude":47.1667, "longitude":9.5333},
  "LK": {"latitude":7, "longitude":81},
  "LR": {"latitude":6.5, "longitude":-9.5},
  "LS": {"latitude":-29.5, "longitude":28.5},
  "LT": {"latitude":55, "longitude":24},
  "LU": {"latitude":49.75, "longitude":6},
  "LV": {"latitude":57, "longitude":25},
  "LY": {"latitude":25, "longitude":17},
  "MA": {"latitude":32, "longitude":-5},
  "MC": {"latitude":43.7333, "longitude":7.4},
  "MD": {"latitude":47, "longitude":29},
  "ME": {"latitude":42.5, "longitude":19.4},
  "MG": {"latitude":-20, "longitude":47},
  "MH": {"latitude":9, "longitude":168},
  "MK": {"latitude":41.8333, "longitude":22},
  "ML": {"latitude":17, "longitude":-4},
  "MM": {"latitude":22, "longitude":98},
  "MN": {"latitude":46, "longitude":105},
  "MO": {"latitude":22.1667, "longitude":113.55},
  "MP": {"latitude":15.2, "longitude":145.75},
  "MQ": {"latitude":14.6667, "longitude":-61},
  "MR": {"latitude":20, "longitude":-12},
  "MS": {"latitude":16.75, "longitude":-62.2},
  "MT": {"latitude":35.8333, "longitude":14.5833},
  "MU": {"latitude":-20.2833, "longitude":57.55},
  "MV": {"latitude":3.25, "longitude":73},
  "MW": {"latitude":-13.5, "longitude":34},
  "MX": {"latitude":23, "longitude":-102},
  "MY": {"latitude":2.5, "longitude":112.5},
  "MZ": {"latitude":-18.25, "longitude":35},
  "NA": {"latitude":-22, "longitude":17},
  "NC": {"latitude":-21.5, "longitude":165.5},
  "NE": {"latitude":16, "longitude":8},
  "NF": {"latitude":-29.0333, "longitude":167.95},
  "NG": {"latitude":10, "longitude":8},
  "NI": {"latitude":13, "longitude":-85},
  "NL": {"latitude":52.5, "longitude":5.75},
  "NO": {"latitude":62, "longitude":10},
  "NP": {"latitude":28, "longitude":84},
  "NR": {"latitude":-0.5333, "longitude":166.9167},
  "NU": {"latitude":-19.0333, "longitude":-169.8667},
  "NZ": {"latitude":-41, "longitude":174},
  "OM": {"latitude":21, "longitude":57},
  "PA": {"latitude":9, "longitude":-80},
  "PE": {"latitude":-10, "longitude":-76},
  "PF": {"latitude":-15, "longitude":-140},
  "PG": {"latitude":-6, "longitude":147},
  "PH": {"latitude":13, "longitude":122},
  "PK": {"latitude":30, "longitude":70},
  "PL": {"latitude":52, "longitude":20},
  "PM": {"latitude":46.8333, "longitude":-56.3333},
  "PR": {"latitude":18.25, "longitude":-66.5},
  "PS": {"latitude":32, "longitude":35.25},
  "PT": {"latitude":39.5, "longitude":-8},
  "PW": {"latitude":7.5, "longitude":134.5},
  "PY": {"latitude":-23, "longitude":-58},
  "QA": {"latitude":25.5, "longitude":51.25},
  "RE": {"latitude":-21.1, "longitude":55.6},
  "RO": {"latitude":46, "longitude":25},
  "RS": {"latitude":44, "longitude":21},
  "RU": {"latitude":60, "longitude":100},
  "RW": {"latitude":-2, "longitude":30},
  "SA": {"latitude":25, "longitude":45},
  "SB": {"latitude":-8, "longitude":159},
  "SC": {"latitude":-4.5833, "longitude":55.6667},
  "SD": {"latitude":15, "longitude":30},
  "SE": {"latitude":62, "longitude":15},
  "SG": {"latitude":1.3667, "longitude":103.8},
  "SH": {"latitude":-15.9333, "longitude":-5.7},
  "SI": {"latitude":46, "longitude":15},
  "SJ": {"latitude":78, "longitude":20},
  "SK": {"latitude":48.6667, "longitude":19.5},
  "SL": {"latitude":8.5, "longitude":-11.5},
  "SM": {"latitude":43.7667, "longitude":12.4167},
  "SN": {"latitude":14, "longitude":-14},
  "SO": {"latitude":10, "longitude":49},
  "SR": {"latitude":4, "longitude":-56},
  "ST": {"latitude":1, "longitude":7},
  "SV": {"latitude":13.8333, "longitude":-88.9167},
  "SY": {"latitude":35, "longitude":38},
  "SZ": {"latitude":-26.5, "longitude":31.5},
  "TC": {"latitude":21.75, "longitude":-71.5833},
  "TD": {"latitude":15, "longitude":19},
  "TF": {"latitude":-43, "longitude":67},
  "TG": {"latitude":8, "longitude":1.1667},
  "TH": {"latitude":15, "longitude":100},
  "TJ": {"latitude":39, "longitude":71},
  "TK": {"latitude":-9, "longitude":-172},
  "TM": {"latitude":40, "longitude":60},
  "TN": {"latitude":34, "longitude":9},
  "TO": {"latitude":-20, "longitude":-175},
  "TR": {"latitude":39, "longitude":35},
  "TT": {"latitude":11, "longitude":-61},
  "TV": {"latitude":-8, "longitude":178},
  "TW": {"latitude":23.5, "longitude":121},
  "TZ": {"latitude":-6, "longitude":35},
  "UA": {"latitude":49, "longitude":32},
  "UG": {"latitude":1, "longitude":32},
  "UM": {"latitude":19.2833, "longitude":166.6},
  "US": {"latitude":38, "longitude":-97},
  "UY": {"latitude":-33, "longitude":-56},
  "UZ": {"latitude":41, "longitude":64},
  "VA": {"latitude":41.9, "longitude":12.45},
  "VC": {"latitude":13.25, "longitude":-61.2},
  "VE": {"latitude":8, "longitude":-66},
  "VG": {"latitude":18.5, "longitude":-64.5},
  "VI": {"latitude":18.3333, "longitude":-64.8333},
  "VN": {"latitude":16, "longitude":106},
  "VU": {"latitude":-16, "longitude":167},
  "WF": {"latitude":-13.3, "longitude":-176.2},
  "WS": {"latitude":-13.5833, "longitude":-172.3333},
  "YE": {"latitude":15, "longitude":48},
  "YT": {"latitude":-12.8333, "longitude":45.1667},
  "ZA": {"latitude":-29, "longitude":24},
  "ZM": {"latitude":-15, "longitude":30},
  "ZW": {"latitude":-20, "longitude":30}
};

var mapData = [
<?php
$i=0;
foreach($pie_result as $t)
{
    echo '{ "id":"'.$t->code.'", "name":"'.$t->name.'", "value":'.$t->row_count.', "color": chart.colors.getIndex('.$i.') },';
    $i++;
}
;?>
  
];

// Add lat/long information to data
for(var i = 0; i < mapData.length; i++) {
  mapData[i].latitude = latlong[mapData[i].id].latitude;
  mapData[i].longitude = latlong[mapData[i].id].longitude;
}

// Set map definition
chart.geodata = am4geodata_worldLow;

// Set projection
chart.projection = new am4maps.projections.Miller();

// Create map polygon series
var polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());
polygonSeries.exclude = ["AQ"];
polygonSeries.useGeodata = true;
polygonSeries.nonScalingStroke = true;
polygonSeries.strokeWidth = 0.5;
//polygonTemplate.fill = am4core.color("#74B266");

var imageSeries = chart.series.push(new am4maps.MapImageSeries());
imageSeries.data = mapData;
imageSeries.dataFields.value = "value";

var imageTemplate = imageSeries.mapImages.template;
imageTemplate.propertyFields.latitude = "latitude";
imageTemplate.propertyFields.longitude = "longitude";
imageTemplate.nonScaling = true
//imageTemplate.fill = am4core.color("#74B266");

// var circle = imageTemplate.createChild(am4core.Circle);
// circle.fillOpacity = 0.7;
// circle.propertyFields.fill = "color";
// circle.tooltipText = "{name}: [bold]{value}[/]";

var imageSeriesTemplate = imageSeries.mapImages.template;
var marker = imageSeriesTemplate.createChild(am4core.Image);
marker.href = "https://s3-us-west-2.amazonaws.com/s.cdpn.io/t-160/marker.svg";
marker.width = 20;
marker.height = 20;
marker.nonScaling = true;
marker.tooltipText = "{name}: [bold]{value}[/]";
marker.horizontalCenter = "middle";
marker.verticalCenter = "bottom";

imageSeries.heatRules.push({
  "target": marker,
  "property": "radius",
  "min": 4,
  "max": 30,
  "dataField": "value"
})
</script>

<script type="text/javascript">
 $(document).ready(function()
    {
        
         $('#datatable-default2').DataTable( {//////pending table
              rowReorder: {
            selector: 'td:nth-child(2)'
              },
                 "pageLength": 50,
          responsive: true,
           "scrollX": true,
        });

         $('#datatable-default3').DataTable( {///approved table
              rowReorder: {
            selector: 'td:nth-child(2)'
              },
                 "pageLength": 50,
          responsive: true,
           "scrollX": true,
        });

      });

function approve_return(id)
 {
    jQuery.ajax({
             url:"<?php echo base_url().'Sales_dashboard_controller/approve_return';?>",
                type:"post",
                data:{"srt_id":id},
                beforeSend: function(){
                 $(".load-image").show();
               },
               complete: function(){
                 $(".load-image").hide();
               },
                success:function(result)
                {
                  if(result==1)
                    location.reload();
                  else
                  {
                    new PNotify({
                      title: 'Error',
                      text: 'Unable to send email.Please try again.',
                      type: 'error'
                    });
                  }
                  //console.log(result);
                }
            });
 }



</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker();
            });

        </script>
<script type="text/javascript">

// $(document).ready(function()
//     {
//       $('#datatable-default3').DataTable( {
//               rowReorder: {
//             selector: 'td:nth-child(2)'
//         },
//          "pageLength": 25,
//     responsive: true,
//      "scrollX": true,
// } );

//       $month_selected=$('input[name="month_selected"]').val();
//       $date_end=$('input[name="end_date_rng"]').val();
//       $date_strt=$('input[name="start_date_rng"]').val();

//       // if($month_selected=='' && $date_end=='' && $date_strt=='')
//       // {
//       //  window.location.href = 'sales-book-dashboard';
//       // }

//     } );
    Highcharts.chart('container0', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Total Sales Comparison'
    },
    
    xAxis: {
        type: 'category',
        labels: {
            rotation: -45,
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Sales Comparison(millions)'
        }
    },
    legend: {
        enabled: false
    },
    tooltip: {
        pointFormat: 'Total Sales : <b>{point.y:.1f} millions</b>'
    },
    series: [{
        name: 'Sales',
        colorByPoint: true,
        data: [
        <?php 
foreach($total_sales_all_years as $tsy)
{
?>

            ['<?php echo $tsy->sbr_voc_year;?>', <?php echo number_format((float)$tsy->total_amount, 2, '.', '');?>],
            <?php
            }?>
          
        ],
        dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y:.1f}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    }]
});
      
Highcharts.chart('container1', {
chart: {
type: 'column'
},
title: {
text: 'Last year and this year comparison'
},

xAxis: {
categories: [
    'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug',
    'Sep','Oct','Nov','Dec'
],
crosshair: true
},
yAxis: {
min: 0,
title: {
    text: 'Sales Income'
}
},
tooltip: {
headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    '<td style="padding:0"><b>{point.y:.1f} AED</b></td></tr>',
footerFormat: '</table>',
shared: true,
useHTML: true
},
plotOptions: {
column: {
    pointPadding: 0.2,
    borderWidth: 0
}
},
 series: [

{
name: '<?php print_r($last_last_last_prev_yr_fifth);?>',
data: [
<?php 
   foreach($months_last_last_last_prev_fifth as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

},

{
name: '<?php print_r($last_last_last_prev_yr);?>',
data: [
<?php 
   foreach($months_last_last_last_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

},

{
name: '<?php print_r($last_last_prev_yr);?>',
data: [
<?php 
   foreach($months_last_last_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($last_previous_year);?>',
data: [
<?php 
   foreach($months_last_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($previous_year);?>',
data: [
<?php 
   foreach($months_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

}, {
name: '<?php print_r($current_year);?>',
data: [
  <?php 
   foreach($months_curnt as $mc)
   {
    if(empty($mc))
      echo '0';
    else
      echo number_format((float)$mc, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>]//12 data,for all months

}]
});

Highcharts.chart('container6', {
chart: {
type: 'column'
},
title: {
text: 'Last year and this year comparison as per category'
},

xAxis: {
categories: [
<?php
foreach($all_category_comparison as $ac)
{
  if(!empty($ac))
  {
  //echo "'".$ac->sbp_ar_category."'";
  echo "'".$ac."'";
  echo ',';
  }
}
  ?>  
],
crosshair: true
},
yAxis: {
min: 0,
title: {
    text: 'Category Sales Income'
}
},
tooltip: {
headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    '<td style="padding:0"><b>{point.y:.1f} AED</b></td></tr>',
footerFormat: '</table>',
shared: true,
useHTML: true
},
plotOptions: {
column: {
    pointPadding: 0.2,
    borderWidth: 0
}
},
series: [

  


{
name: '<?php print_r($last_last_last_prev_yr_fifth);?>',
data: [

<?php 
   foreach($cat_amount_last_last_last_fifth as $indx1=>$mp)
   {
      
    if(empty($mp[0]->sbp_ar_category))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_gross_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

},

{
name: '<?php print_r($last_last_prev_yr);?>',
data: [

<?php 
   foreach($cat_amount_last_last_prev as $indx1=>$mp)
   {
      
    if(empty($mp[0]->sbp_ar_category))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_gross_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($last_previous_year);?>',
data: [

<?php 
   foreach($cat_amount_last_prev as $indx1=>$mp)
   {
      
    if(empty($mp[0]->sbp_ar_category))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_gross_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($previous_year);?>',
data: [

<?php 
   foreach($cat_amount_prev as $indx1=>$mp)
   {
      
    if(empty($mp[0]->sbp_ar_category))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_gross_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

}, {
name: '<?php print_r($current_year);?>',
data: [
  <?php 
   foreach($cat_amount_curnt as $indx2=>$mc)
   {
   $sum_cat2=array_sum($mc);
    foreach($all_category as $indx2=>$ac)
  {
    if($ac->sbp_ar_category==$indx2)
    {
    if(empty($mc))
      echo '0';
    else
      echo number_format((float)$sum_cat2, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
    }
   }
?>]//12 data,for all months

}]
});
</script>


</body>

</html>