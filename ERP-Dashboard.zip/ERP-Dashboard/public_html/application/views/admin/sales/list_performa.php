<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}

@-webkit-keyframes glowing {
  0% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -webkit-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
}

@-moz-keyframes glowing {
  0% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; -moz-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
}

@-o-keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}

@keyframes glowing {
  0% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF0000; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #B20000; box-shadow: 0 0 3px #B20000; }
}


</style>
<style type="text/css">
    .dot {
  height: 25px;
  width: 25px;
  border-radius: 50%;
  display: inline-block;
}
    
</style>
</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Orders</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Performa Invoices</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">List PI</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
<div class="data_result">
<table class="table table-bordered table-striped mb-none" id="datatable-default2">
<thead>
<tr>
<th></th>
	<th >Doc number</th>
	
<th>Sales Person</th>
<th>Qutation Date</th>
<th >Company Name</th>
<th>Customer Name</th>

<th>Action</th>

</tr>
</thead>
<tbody>
<?php
$i=1;
$total_vat_sum_prd='';
$total_discount_sum_prd='';
$total_sum_prd='';

foreach($result as $index1=>$t)
{

	$qnty=explode('|#|',$t-> q_prd_qnty);
$unit_price=explode('|#|',$t-> q_prd_price);
$vat=explode('|#|',$t-> q_prd_vat);  
$total=explode('|#|',$t-> q_prd_tot);


$dicount_per=$t->q_discount_per;
?>
<tr class="gradeX">
<td><?php echo $i++;?></td>
			<td><?php echo $t->q_ref_no;?></td>
			<td><?php echo $t-> q_user_id;?></td>
			<td><?php echo $t-> q_date;?></td>
			<td><?php echo $t-> q_cust_comp;?></td>
			<td><?php echo $t-> q_cust_name;?></td>
			<td>	
<div class="dropdown-primary dropdown">
<button class="btn btn-primary dropdown-toggle waves-effect waves-light " type="button" id="dropdown-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >Action</button>
<div class="dropdown-menu" aria-labelledby="dropdown-2" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 44px, 0px); top: 0px; left: 0px; will-change: transform;">

<div class="dropdown-divider"></div>                      
<a class="dropdown-item waves-light waves-effect"  onclick="view_proquotation_data('<?php echo $t->q_id;?>')"> <i class="fa fa-eye"></i>View
</a>
  

<div class="dropdown-divider"></div>                                                                                                                                     
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('edit_quotation/'.$t->q_id);?>" >Edit</a>



<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('Quotation_controller/extra_details_performa/'.$t->q_id);?>">Add Extra Details </a>

<?php
if($t->show_stamp_proforma=='1')
{
if($t->p_approval_stamp_sign=='1')
{
  if($this->session->userdata['user']['main_dept']=="Main")
  {
  ?>
<div class="dropdown-divider"></div>
<a class="dropdown-item " onclick="approve_stamp('<?php echo $t->q_id;?>')" ><i class="fa fa-thumbs-o-up"></i>Approve Stamp Request
</a>
<?php
}
}
}
?>
<!-- <a class="dropdown-item waves-light waves-effect " href="<?php echo base_url('generate_quotation/').$t->q_id.'/pi';?>">Generate PI as PDF</a> -->
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes" href="#modal_generate_pdf<?php echo $t->q_id;?>">Generate PI as PDF</a>
<!-- <div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect" href="<?php echo base_url('Proforma_Invoice/excel_proforma/'.$t->q_id);?>">Generate PI as Excel</a> -->
<div class="dropdown-divider"></div>
<a class="dropdown-item waves-light waves-effect " href="<?php echo base_url('send_mail_quotation/').$t->q_id.'/pi';?>">Send PI as email</a>
</div>
</div>
<?php
if($t->show_stamp_proforma=='1')
{
  if($t->p_approval_stamp_sign=='1')
  {
    if($this->session->userdata['user']['main_dept']=="Main")
    {
      ?>
<button type="button" class="label label-lg label-danger" style="background-color: #da0606;
  color: white;
  -webkit-animation: glowing 1500ms infinite;
  -moz-animation: glowing 1500ms infinite;
  -o-animation: glowing 1500ms infinite;
  animation: glowing 1500ms infinite;">Requesting approval for Stamp and sign</button>
      <?php
    }
  }
}
?>
 </td>
			
	</tr>
<!-------------------modal due till date------------>
<div id="modal_generate_pdf<?php echo $t->q_id;?>" class="modal-block modal-block-lg mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Genearte PDF - Proforma </h2>
</header>

<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text">
     
                <div class="row">
                  <div class="col-md-12">
                    <div class="col-md-4"><a class="btn btn-primary btn-lg" href="<?php echo base_url('generate_localproforma/'.$t->q_id.'/pi');?>">Local Proforma Invoice</a></div>
                    <div class="col-md-4"><a class="btn btn-primary btn-lg" target="_blank" href="<?php echo base_url('Proforma_Invoice/export_performa/berry/'.$t->q_id);?>">Export Proforma Invoice for Berry Building Materials</a></div>
                    <div class="col-md-4"><a class="btn btn-primary btn-lg" target="_blank" href="<?php echo base_url('Proforma_Invoice/export_performa/birind/'.$t->q_id);?>">Export Proforma Invoice for Biri Industries</a></div>
                  </div>
                </div>
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button class="btn btn-default modal-dismiss">Cancel</button>
</div>
</div>
</footer>

</section>
</div>

<script type="text/javascript">
  function approve_stamp(quot_id)
  {
      $('#modalsm21').modal('show');
      $('.quot_id').val(quot_id);
  } 
</script>

<div class="modal fade" id="modalsm21" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Approve Stamp &amp; Signature request-Porforma</h3>
            </div>
            <div class="modal-body form">
        <div class="row">
          <input type="hidden" class="quot_id" name="quot_id" value="">
                      <div class="col-md-12 col-sm-12 table-rows-border on_hold_till">
          <p>Are you sure you want to approve this request to show stamp and signature in this Porforma?</p>
          </div>
        </div>
            </div>
            <div class="modal-footer">
                <button onclick='approve_req("decline");' class="btn btn-danger pull-left">Decline Request</button>
                  <button onclick='approve_req("approve");' class="btn btn-primary">Approve Request</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!------------modal due till date ends----------->
<?php 
}
$total_vat_sum_prd='';
$total_discount_sum_prd='';
$total_sum_prd='';
?>

</tbody>
</table>
</div>


</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').datepicker().datepicker("setDate", new Date());
            });
    $(document).ready(function()
    {
        
         $('#datatable-default2').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
        "pageLength": 100,
    responsive: true,
     "scrollX": true,
	} );
    } );        
        </script>
        
      <script>
      	
      	function change_quto_sts(qout_id)
      	{
      		var selected_sts=$("select[name='quotation_sts_set']").val();
      		if( (selected_sts=="First follow up mail send") || (selected_sts=="Second follow up mail send") || (selected_sts=="Third follow up mail send") )
      		{
      		$('#set_reminder_'+qout_id+'').show();
      		$('.reason_lost').hide();
      		$('.on_hold_till').hide();
      		}
      		else if(selected_sts=="On hold Till")
      		{
      		$('#on_hold_till_'+qout_id+'').show();
      		$('.reason_lost').hide();
      		$('.set_reminder').hide();
      		}
      		else if(selected_sts=="Lost")
      		{
      		$('#reason_lost_'+qout_id+'').show();
      		$('.set_reminder').hide();
      		$('.on_hold_till').hide();
      		}
      		else
      		{
      		$('.set_reminder').hide();
 		$('.reason_lost').hide();
 		$('.on_hold_till').hide();
      		}
      	}

       function approve_req(type)
        {
           var quot_id=$('.quot_id').val();
            jQuery.ajax({
                     url:"<?php echo base_url().'Quotation_controller/approve_req_proforma';?>",
                    data:{"quot_id":quot_id,"type_req":type},
                    type:"post",
                beforeSend: function(){
                 $(".load-image").show();
               },
               complete: function(){
                 $(".load-image").hide();
               },
                    success:function(result)
                    {
                      if(result)
                      {
                         $('.close').trigger('click');
                           $('.quot_req_id_'+quot_id).hide();
                        var stack_bar_top = {"dir1": "down", "dir2": "right", "push": "top", "spacing1": 0, "spacing2": 0};
                         if(type=="approve")
                        {
                        var notice = new PNotify({
                            title: 'Approved',
                            text: 'Request to display Stamp and Signature in Proforma is Approved successfully.',
                            type: 'success',
                            addclass: 'stack-bar-top',
                            stack: stack_bar_top,
                            width: "100%"
                          });
                       //$('#position-4-success').click();
                       }
                      else
                      {
                           var notice = new PNotify({
                            title: 'Declined',
                            text: 'Request to display Stamp and Signature in quotation is Declined successfully.',
                            type: 'success',
                            addclass: 'stack-bar-top',
                            stack: stack_bar_top,
                            width: "100%"
                          });
                      }
                      }
                    }
                 }); 
        }
      </script>  


<!-------------------function view proforma quotation------------>
<script type="text/javascript">
  function view_proquotation_data(id)
{
  console.log('view');
    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('Quotation_sample/ajax_load_view/')?>",
        type: "POST",
        data: {"quot_id":id},
        success: function(data)
        {
          $('.view_data_modal').html(data);
            $('#modalsm3_view_data').modal('show'); // show bootstrap modal when complete loaded
          },
    });
}
</script>
<!-------------------modal view proforma quotation------------>
<div class="modal fade" id="modalsm3_view_data" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">View data</h3>
            </div>
            <div class="modal-body form ">
              <div class="row view_data_modal" ></div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<!-------------------modal view proforma quotation------------>








</body>
</html>