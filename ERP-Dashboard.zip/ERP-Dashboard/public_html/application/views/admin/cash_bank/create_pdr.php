<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" /> 
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link href="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.css" media="all" rel="stylesheet" 
type="text/css"/>

<style type="text/css">
 .form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
 color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
 border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
 color: red;
}
table input.form-control {
  width: auto;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">
<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Cash & Bank </h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Post Dated Receipt Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle" ></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel panel-featured panel-featured-primary">
<header class="panel-heading">

<h2 class="panel-title">Cash & Bank -- Post Dated Receipt </h2>
</header>
<div class="panel-body">
 <?php echo form_open_multipart('Receipt_Master/submit_pdr','class="myform" ','');?>
<!--  <form action="submit_prd" class="form-horizontal form-bordered product_entry_form" enctype="multipart/form-data" method="post"> -->
   <input type="hidden" name="added_cbr_id" value="<?php if(!empty($result[0]->cbr_id)){echo $result[0]->cbr_id;} ;?>">
<input type="hidden" name="page_type" value="">
 <input type="hidden" name="files_added" value="<?php if(!empty($result[0]->cbr_attachments)){echo $result[0]->cbr_attachments;} ;?>">

    <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fileds marked as '::*::' are required fields</p>

<div class="row">
 <div class="col-md-12 col-sm-12 table-rows-border">
 
<div class="col-md-6 col-sm-12">


<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Doc No <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<input type="text" name="cbr_doc_no" value="<?php if(!empty($result[0]->cbr_doc_no)){echo $result[0]->cbr_doc_no;}else{echo $doc_num;}?>" readonly class="form-control">

  
 <div class="form_error">  <?php echo $this->session->flashdata('ref_no');?></div>
</div>
</div>

</div>
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Date<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
  <?php
  if(!empty($result[0]->cbr_date))
  $converted_date = date("m/d/Y", strtotime($result[0]->cbr_date));
  ?>
 <input type='text' name="cbr_date" class="form-control datetimepicker4" value="<?php if(!empty($result[0]->cbr_date)){echo $converted_date;}else{echo date('m/d/Y');} ;?>" required="required" disabled="disabled" />
  <input type="hidden" name="hid_date" value="">
  <div class="form_error">  <?php echo $this->session->flashdata('cbr_date');?></div>

</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">  Cash&amp;Bank<abbr class="required">::*::</abbr>
 
</label>
<div class="col-md-8">
 <select data-plugin-selectTwo  class="form-control populate" name="cbr_acc" required="required">
  <option value="">Choose</option>
 <?php
foreach($cash_bank as $abc=>$cb)
{
   if($abc!='0')
  {
foreach($cb as $abc=>$cb1)
{
 
  ?>
<option value="<?php echo $cb1->id;?>" <?php if(!empty($result[0]->cbr_acc)){if($result[0]->cbr_acc==$cb1->id){echo "selected";}};?>><?php echo $cb1->label;?></option>
<?php
  
}
}

}
?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('cbr_acc');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Maturity Date<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
  <?php
  if(!empty($result[0]->cbr_maturity_date))
  {
  $converted_due_date = date("m/d/Y", strtotime($result[0]->cbr_maturity_date));
}
  ?>
 <input type='text' name="cbr_maturity_date" id="datetimepicker55" class="form-control" value="<?php if(!empty($result[0]->cbr_maturity_date)){echo $converted_due_date;} ;?>" required />
  <div class="form_error">  <?php echo $this->session->flashdata('cbr_maturity_date');?></div>

</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Company<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
 <select data-plugin-selectTwo  class="form-control populate" name="cbr_company" required="required">
  <option value="">Choose</option>
 <?php
 foreach($company_masters as $cm)
 {?>
  <option value="<?php echo $cm->mcomp_id;?>" <?php if(!empty($result[0]->cbr_company)){if($result[0]->cbr_company==$cm->mcomp_id){echo "selected";}};?>> <?php echo $cm->mcomp_name;?></option> 
  <?php
}?>

 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('cbr_company');?></div>

</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Narration<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
 <input type='text' name="cbr_narration" class="form-control" value="<?php if(!empty($result[0]->cbr_narration)){echo $result[0]->cbr_narration;} ;?>" required="required" />
  <div class="form_error">  <?php echo $this->session->flashdata('cbr_narration');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Cheque No.

</label>
<div class="col-md-8">
 <input type='text' name="cbr_cheque_no" class="form-control" value="<?php if(!empty($result[0]->cbr_cheque_no)){echo $result[0]->cbr_cheque_no;} ;?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('cbr_cheque_no');?></div>
</div>
</div>
</div>


<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Bill No.

</label>
<div class="col-md-8">
 <input type='text' name="cbr_bill_no" class="form-control" value="<?php if(!empty($result[0]->cbr_bill_no)){echo $result[0]->cbr_bill_no;} ;?>"  />
  <div class="form_error">  <?php echo $this->session->flashdata('cbr_bill_no');?></div>
</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Currency Type<abbr class="required">::*::</abbr>
</label>
<div class="col-md-8">
 <select data-plugin-selectTwo  class="form-control populate" name="cbr_currency">
  <option value="">Choose</option>
  <?php
  foreach($currency_convt as $cv)
  {
    ?>
 <option value="<?php echo $cv->currency_name;?>" <?php if(!empty($result[0]->cbr_currency)){if($result[0]->cbr_currency==$cv->currency_name){echo "selected";}}else{ if($cv->currency_name=="AED"){echo "selected";}};?>> <?php echo $cv->currency_name;?> </option> 
    <?php
  }
  ?>
 </select>
  <div class="form_error">  <?php echo $this->session->flashdata('cbr_currency');?></div>

</div>
</div>
</div>

<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Currency Conv.<abbr class="required">::*::</abbr>

</label>
<div class="col-md-8">
 <input type='text' name="cbr_rate_currency" class="form-control" value="<?php if(!empty($result[0]->cbr_rate_currency)){echo $result[0]->cbr_rate_currency;}else{echo "1";} ;?>"  readonly=true />
  <div class="form_error">  <?php echo $this->session->flashdata('cbr_rate_currency');?></div>
</div>
</div>
</div>

</div>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="form-group">
  <p>Upload files here.Make sure the file size is less than 2MB.</p>
 <input class="form-control" name="files[]" type="file"  multiple  />
 <small>Choose multiple files for uploading</small>
 <div class="form_error">  <?php echo $this->session->flashdata('files[]');?></div>
</div> 
</div>
<?php
if(!empty($result[0]->cbr_attachments))
{
  echo "<h4> FILES UPLOADED :</h4>";
  $files_are=explode(',',$result[0]->cbr_attachments);
  foreach($files_are as $fr)
  {
    echo "<a href='".base_url("uploads/receipt_files/".$fr)."' target='_blank'>".$fr."</a><br/>";
  }
}
?>

<div class="col-md-12 col-sm-12 table-rows-border">
<div class="table-responsive">
<table class="table table-border table-rows-border">
  <thead>
    <th>Account<abbr class="required">::*::</abbr></th>
     <th>Salesman<abbr class="required">::*::</abbr></th>
       <th>Amount as currency<abbr class="required">::*::</abbr></th>
        <th>Reference</th>
         <th>Remark</th>
         <th></th>
  </thead>
  <tbody class="new_rows">
    <?php
    if(!empty($result[0]))/////used in update value
    {
      $salesman_added=explode('|#|',$result[0]->cbr_salesman);
      $cust_added=explode('|#|',$result[0]->cbr_customer_acc);
      $total_count_rows=count($cust_added);
      $amount_added=explode('|#|',$result[0]->cbr_amount);
      $ref_added=explode('|#|',$result[0]->cbr_ref);
      $remark_added=explode('|#|',$result[0]->cbr_remark);
      $ik=1;
      foreach($cust_added as $ca_index=>$ca)
      {
        ?>
 <tr>



<td>
   <select data-plugin-selectTwo  class="form-control populate cust<?php echo $ik;?>" name="cbr_customer_acc[]" onchange="get_cust_details(<?php echo $ik;?>);">
  <option value="">Choose</option>
  <?php
  foreach($customers as $cs)
  {
?>
  <option value="<?php echo $cs['id'];?>" <?php if(!empty($ca)){if($ca==$cs['id']){echo "selected";}};?>> <?php echo strtolower($cs['label']);?> </option> 
  <?php
  }?>

 </select>
  </td>

     <td> 
        <select data-plugin-selectTwo  class="form-control populate salesman_<?php echo $ik;?>" name="cbr_salesman[]" >
  <option value="">Choose</option>
<?php
$data_salesman=array_filter($salesman);
foreach($data_salesman as $sm)
{
  ?>
   <option value="<?php echo $sm[0]->ed_id;?>" <?php if(!empty($salesman_added[$ca_index])){if($salesman_added[$ca_index]==$sm[0]->ed_id){echo "selected";}};?>> <?php echo strtolower($sm[0]->ed_name);?> </option> 
  <?php
}
?>
 </select>
</td>




  <td><input type="number" name="cbr_amount[]" step="any" value="<?php if(!empty($amount_added[$ca_index])){echo $amount_added[$ca_index];};?>" onchange="calculate_amount_total()" onblur="calculate_amount_total()"  class="form-control amount"  value="0"></td>
  <td><input type="text" name="cbr_ref[]"  value="<?php if(!empty($ref_added[$ca_index])){echo $ref_added[$ca_index];};?>" class="form-control" onclick="get_cust_sales_inv(<?php echo $ik;?>);"> <br/>
 <a style="display: none;" class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes sales_invoice_modal_a" href="#modalmd_sinv"><i class="fa fa-trash-o"></i>Pop-up Invoice </a> </td>
    <td><input type="text" name="cbr_remark[]" value="<?php if(!empty($remark_added[$ca_index])){echo $remark_added[$ca_index];};?>" class="form-control" > 
    </td>


 

    <td></td>

<input type="hidden" name="hid_salesman" size="5">
<input type="hidden" name="hid_customer" size="5">
<input type="hidden" name="hid_amounts" size="5">
<input type="hidden" name="hid_ref" size="5">
<input type="hidden" name="hid_remark" size="5">

 <input type="hidden" class="si_inv_id_<?php echo $ik;?>" name="si_inv_id[]" size="5" value="<?php echo implode('|$$|',$array_sales_inv_id);?>">
<input type="hidden" class="si_doc_num_<?php echo $ik;?>" name="si_doc_num[]" size="5" value="<?php echo implode('|$$|',$array_sales_doc);?>">
<input type="hidden" class="si_amount_<?php echo $ik;?>" name="si_amount[]" size="5" value="<?php echo implode('|$$|',$array_amounts_sales);?>">
<input type="hidden" class="si_amount_paid_<?php echo $ik;?>" name="si_amount_paid[]" size="5" value="<?php echo implode('|$$|',$array_paid_amounts);?>">
    </tr>
        <?php
        $ik++;
      }

    }
    else//////mainly for adding new values
      {?>
    <tr>

<td>
   <select data-plugin-selectTwo  class="form-control populate cust1" name="cbr_customer_acc[]" onchange="get_cust_details(1);">
  <option value="">Choose</option>
  <?php
  foreach($customers as $cs)
  {
?>
  <option value="<?php echo $cs['id'];?>" > <?php echo strtolower($cs['label']);?> </option> 
  <?php
  }?>

 </select>
  </td>


      <td> 
        <select data-plugin-selectTwo  class="form-control populate salesman_1" name="cbr_salesman[]" >
  <option value="">Choose</option>
<?php
$data_salesman=array_filter($salesman);
foreach($data_salesman as $sm)
{
  ?>
   <option value="<?php echo $sm[0]->ed_id;?>" > <?php echo strtolower($sm[0]->ed_name);?> </option> 
  <?php
}
?>
 </select>
</td>


  <td><input type="number" name="cbr_amount[]" onchange="calculate_amount_total()" onblur="calculate_amount_total()" class="form-control amount sales_inv_amount1 form_input_amount_1" step="any"  value="0"></td>
  <td><input type="text" name="cbr_ref[]" readonly="" class="form-control form_input_ref_1" onclick="get_cust_sales_inv(1);">
<input type="hidden" name="ref_amounts[]" class="form_input_ref_amount_1" size="5">
    <br/>
 <a style="display: none;" class="dropdown-item waves-light waves-effect mb-xs mt-xs mr-xs modal-sizes sales_invoice_modal_a" href="#modalmd_sinv"><i class="fa fa-trash-o"></i>Pop-up Invoice </a>
 <input type="hidden" class="si_inv_id_1" name="si_inv_id[]" size="5">
<input type="hidden" class="si_doc_num_1" name="si_doc_num[]" size="5">
<input type="hidden" class="si_amount_1" name="si_amount[]" size="5">
<input type="hidden" class="si_amount_paid_1" name="si_amount_paid[]" size="5"> 

   </td>
    <td><input type="text" name="cbr_remark[]" class="form-control"> </td>
    <td></td>
<input type="hidden" name="hid_salesman" size="5">
<input type="hidden" name="hid_customer" size="5">
<input type="hidden" name="hid_amounts" size="5">
<input type="hidden" name="hid_ref" size="5">
<input type="hidden" name="hid_remark" size="5">
    </tr>
    <?php
  }?>
 <button type="button" class="btn btn-primary pull-right" onclick="add_more_row();">Add More</button>
  
  </tbody>
</table>
</div>

</div>

<div class="cell_text_data"></div>

<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">
<label class="col-md-4 control-label" for="inputPlaceholder">Total Number of items:</label>
<div class="col-md-8">
  <span class="num_items">
    <?php
    if(!empty($result[0]))
    {
  if(!empty($total_count_rows))
  {
    echo $total_count_rows;
  }
   else
  {
    echo "1";
  }
  }
   else
  {
    echo "1";
  }
  ?>
  </span>
</div>
</div>
<!----------end col-md-12----------------------------->

<!-------start col-md-12------------------->
<div class="col-md-12 col-sm-12 table-rows-border">

<!--   <button class="btn btn-primary" type="button" onclick="calculate_amount_total()">Click to see total amount</button> -->
  <br/>
  <label class="col-md-4 control-label" for="inputPlaceholder">Amount Total:<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="text" readonly class="amount_tot_button" name="cbr_tot_amount" required="required" value="<?php if(!empty($result[0]->cbr_tot_amount)){echo $result[0]->cbr_tot_amount;};?>">
  <small>Amount as per the currency rate selected</small>
 <!--  <button type="button" class="btn btn-md btn-success amount_tot_button"></button> -->
</div>
</div>
<!----------end col-md-12----------------------------->


<!-----div starts here for non-inquiry--->
<!----div end here for non-inquiry--->
</section>
<!-----div starts here for non-inquiry--->
<input type="hidden" name="sales_inv_cust_id">
  <input type="hidden" name="sales_inv_id">
    <input type="hidden" name="sales_inv_amount">
  <input type="hidden" name="sales_inv_amount_paid">
  <input type="hidden" name="sales_doc_num">
<!-----div starts here for non-inquiry--->
 <!-- Button trigger modal for sales invoice-->
 <div id="modalmd_sinv" class="modal-block modal-block-lg mfp-hide">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">References </h2>
</header>
<div class="panel-body">
<div class="modal-wrapper">
<div class="modal-text modal_content_sinv">
   
</div>
</div>
</div>
<footer class="panel-footer">
<div class="row">
<div class="col-md-12 text-right">
<button type="button" onclick="submit_sales_inv_amount()"  class="btn btn-primary confirm_btn_modal">Confirm</button>
<button class="btn btn-default modal-dismiss modal-close-btn">Cancel</button>
</div>
</div>
</footer>
</section>
</div>
<!----end modal--->
<!----div closes here--->


<div class="col-sm-9 col-sm-offset-3">
<button type="submit" class="btn btn-primary">Save</button>
<button type="reset" class="btn btn-default" onclick="check_for_reset()">Reset</button>
</div>

<?php echo form_close();?>
</div>
</div>

</section>
</div>
</section>


<aside id="sidebar-right" class="sidebar-right">
<div class="nano">
<div class="nano-content">
<a href="#" class="mobile-close visible-xs">
Collapse <i class="fa fa-chevron-right"></i>
</a>
<div class="sidebar-right-wrapper">

<div class="sidebar-widget widget-friends ">

<div class="chat_window">
<?php $this->load->view('admin/master_essential/chat_data',$chat);?>

</div>
</div>



</div>
</div>
</div>
</aside>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-maskedinput/jquery.maskedinput.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-tagsinput/bootstrap-tagsinput.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/forms/examples.advanced.form.js" type="text/javascript" /></script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
 <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/sortable.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/piexif.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/plugins/purify.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/fr.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/js/locales/es.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/fas/theme.js" type="text/javascript"></script>
  <script src="<?php echo base_url('admin_assets/');?>bootstrap-fileinput-master/themes/explorer-fas/theme.js" type="text/javascript"></script>
  

    <script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script>
            $(document).on('ready', function () {
                $(document).on("keyup", ".amount", calculate_amount_total);
                $("#file-1").fileinput();
                });
                  </script>
                  
        <script>
      $(document).ready(function()
{    
             /////for file upload////
  $("#file-1").fileinput({
      // 'theme': 'fas',
     //        'showPreview': true,
     //         'showUpload': false,
     //      'showRemove':true,
     //        'maxFileSize': 5000,
     //    'maxFilesNum': 10,
     //        'allowedFileExtensions': ['jpg', 'png', 'gif'],

        theme: 'fas',
         showUpload: false,
          showCancel: true,
        overwriteInitial: false,
        maxFileSize: 3000,////max file size  is 2000 kb,else will show error
        maxFilesNum: 10,


        // "success":true,
        //allowedFileTypes: ['image', 'video', 'flash'],
       
    });
 
     $(".file").on('fileselect', function(event, n, l) {
     alert('File Selected. Name: ' + l + ', Num: ' + n);
     });

     $('select[name="cbr_company"]').on('change',function(){
    var company_selected=$("select[name='cbr_company']").find('option:selected').text();
      if(company_selected.includes("KSA")==true)
      {
        $('input[name="page_type"]').val('ksa');
      }
      else if(company_selected.includes("Dragon"))
      {
         $('input[name="page_type"]').val('dragon');
      }
      else if(company_selected.includes("UAE"))
      {
         $('input[name="page_type"]').val('uae');
      }
      else
      { }
  });
     
      });
   </script>
   
 <script>
    tinymce.init({
      selector : '.editors',
        plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
    });
   </script>
   
<script type="text/javascript">
 function add_more_row()
{
var tablecount = $('table tbody tr').length;
  if(tablecount=="0")
  {
    var table_id="1"; 
  }
  else
  {
    var table_id=parseInt($(".num_items").text())+1;
  }

   var markup='<tr class="table'+table_id+'">'+



'<td class="select_cust_list_'+table_id+'"><input type="hidden" name="hid_customer" size="5">';     
    jQuery.ajax({
                     url:"<?php echo base_url().'Receipt_Master/get_details_customer_acc_pdr';?>",
                     data:{"table_id":table_id},
                    type:"post",
                    success:function(result)
                    {
                      if(result)
                      {
           $('.select_cust_list_'+table_id).html(result);
                         $('select[name="cbr_customer_acc[]"]').select2();
                      }
                    }
                 });  
  markup+='</td>'+


   '<td class="select_salesman_list_'+table_id+'"> <input type="hidden" name="hid_salesman" size="5">';
 jQuery.ajax({
                     url:"<?php echo base_url().'Receipt_Master/get_details_salesman';?>",
                     data:{"table_id":table_id},
                    type:"post",
                     success:function(result)
                    {
                    // console.log(result);
                      if(result)
                      {
        $('.select_salesman_list_'+table_id).html(result);
        $('select[name="cbr_salesman[]"]').select2();
                      }
                    }
                 });  
  
 markup+= '</td>'+

    '<td><input type="hidden" name="hid_amounts" size="5"><input type="number" name="cbr_amount[]"  onchange="calculate_amount_total()" onblur="calculate_amount_total()" onkeyup="calculate_amount_total()" class="form-control amount sales_inv_amount'+table_id+' form_input_amount_'+table_id+' " step="any" value="0"></td>'+
    '<td><input type="hidden" name="hid_ref" size="5"><input type="text" name="cbr_ref[]" readonly class="form-control form_input_ref_'+table_id+'" onclick="get_cust_sales_inv('+table_id+');">'+ 
    '<input type="hidden" name="ref_amounts[]" class="form_input_ref_amount_'+table_id+'" size="5">'+
 '</td>'+
      '<td><input type="hidden" name="hid_remark" size="5"><input type="hidden" class="si_inv_id_'+table_id+'"  name="si_inv_id[]" size="5">'+
'<input type="hidden" class="si_doc_num_'+table_id+'"  name="si_doc_num[]" size="5">'+'<input type="hidden" class="si_amount_'+table_id+'" name="si_amount[]"  size="5">'+'<input type="hidden" class="si_amount_paid_'+table_id+'" name="si_amount_paid[]"  size="5">'+
'<input type="text" name="cbr_remark[]" class="form-control"> </td> '+  
     ' <td><button type="button" class="btn btn-danger" style="cursor: pointer" onclick=table('+table_id+')>X</button></td>'
      '</tr>';
   
            $(".new_rows").append(markup);
             var rowcount = $('table tbody tr').length;
     $(".num_items").html(rowcount);
     $('select[name="cbr_customer_acc[]"]').select2();

}

  function table(id)
  {
    $('table tbody .table'+id).remove();
    var rowcount = $('table tbody tr').length;
    $(".num_items").html(rowcount);
  }

  function salesman_selected_id(table_id=null)
  {
    if(table_id!='')
    {
    var sales_man_selected= $('select[name="cbr_salesman[]"]').find('option:selected').val();
     //var sales_man_selected= $('.salesman_'+table_id).find('option:selected').val();
// var sales_man_selected= $('.salesman_'+table_id).val();
    //var sales_man_selected= $('table tbody tr td .salesman_'+table_id+' option:selected').map(function(){return $(this).val();}).get().join('|#|');
      console.log(sales_man_selected);
    }
  }

  function get_cust_sales_inv(table_id)
{
  var cust_id=$('.cust'+table_id).find('option:selected').val();
    var cust_amount_paid=$('.form_input_amount_'+table_id).val();
 jQuery.ajax({
               url:"<?php echo base_url().'Receipt_Master/get_cust_sales_inv';?>",
                data:{"cust_id":cust_id,'table_id':table_id,'cust_amount_paid':cust_amount_paid},
              type:"post",
               success:function(result)
              {
               
                $('.modal_content_sinv').html(result);
                $('.sales_invoice_modal_a').show();
                 $('#datatable-default2').DataTable();
               }
            });
}

function get_cust_details(table_id)
{
    var cust_id=$('.cust'+table_id).find('option:selected').val();
    jQuery.ajax({
               url:"<?php echo base_url().'Sales_invoice/get_cust_full_details';?>",
                data:{"cust_id":cust_id},
              type:"post",
               success:function(result)
              {
                if(result)
                {
                var returndata = JSON.parse(result);
               $('.salesman_'+table_id).val(returndata[0]['macd_salesman_id']).trigger('change');
                }
              }
            }); 
}

</script>

<script type="text/javascript" src="<?php echo base_url('modal_inv_js.js');?>"></script>

<script type="text/javascript">


function calculate_amount_total()
{
  var amountss='0';
$('table tbody tr td input[name="cbr_amount[]"]').each(function(){
amountss= parseFloat(amountss)+parseFloat($(this).val());
}); 
var currency_rate_selected=$("input[name='cbr_rate_currency']").val();
$("input[name='cbr_tot_amount']").val(parseFloat(amountss*currency_rate_selected).toFixed(2));
$('.amount_tot_button').val(parseFloat(amountss*currency_rate_selected).toFixed(2));

}
</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=tfsqh0u009vdg9i8lkuj7r4ibz63lnmvrob8o52t5e26dhx6"></script>
 <script>
  tinymce.init({
   selector : '.editors',
     plugins: [
          'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table contextmenu paste code'
        ],
  });
   </script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  
<script type="text/javascript">
          $(function () {
                $('.datetimepicker4').
                datepicker({startDate: new Date() });
            });
            $( function() {
    $('#datetimepicker55' ).datepicker({ 
       startDate: '-1y', // controll start date like startDate: '-2m' m: means Month

     // minDate: -20, maxDate: new Date()
       });
  } );
$(document).on('ready', function () 
{
$('input').attr('autocomplete','off'); 

  $('select[name="cbr_currency"]').on('change',function(){
    
     jQuery.ajax({
               url:"<?php echo base_url().'Receipt_Master/get_currency_conv_val';?>",
                data:{"currecny_selected":$(this).val()},
              type:"post",
               success:function(result)
              {
                if(result)
                {
                $("input[name='cbr_rate_currency']").val(result);
                }
              }
               }); 
  });

  $('.menu_name_fun').on('click',function(){
          if (confirm("Are you sure, You want to exit this page?")) {
                  location.href = $(this).attr('href');
            } 
            else {
              return false;
            }

          });


}); 





var checked_val= '';
function get_pick_amount(table_id,ij_val=null)
{

    $('.dataTables_filter input[type=search]').val('');
 
  $('#datatable-default2').DataTable().search('').draw(); 
  
  var param_data=pass_param_2(null,checked_val);
  checked_val = '';
  console.log('inside get pick amount');
  console.log(param_data);
  var param_val=param_data.split("##");
  var ij=param_val[0];
  console.log(param_val);
  console.log(ij);
  var ref_doc_num= param_val[1];

  var form_input_amount=$('.form_input_amount_'+table_id).val();
  var  to_be_adjust= $('.to_be_adjust').html();
  var  amount_adjusted_till_now= $('.amount_adjusted').html();

  var amount_all=$('.amount_to_adj').html();
  console.log('amount_all = '+amount_all);
  console.log('amount_adjusted_till_now = '+amount_adjusted_till_now);

   if(amount_adjusted_till_now=='')
   {
    console.log('here 1');
    var amount_picked=0;
   }
     
   else  if(parseFloat(amount_adjusted_till_now)==parseFloat(amount_all))
   {

     var amount_picked=parseFloat(amount_all).toFixed(2);
       var amount_adjusted=parseFloat(to_be_adjust).toFixed(2);
       console.log('here 2');
       console.log('amount_adjusted'+amount_adjusted);

   }
    else if (parseFloat(amount_adjusted_till_now)<=parseFloat(amount_all))
   {
    var amount_picked=parseFloat(amount_adjusted_till_now).toFixed(2);
    var amount_adjusted=parseFloat(amount_all-amount_picked).toFixed(2);
    console.log('here 3');
       console.log('amount_adjusted'+amount_adjusted);
   }



   else if (parseFloat(amount_adjusted_till_now)>=parseFloat(amount_all))
   {
          var amount_picked=parseFloat(amount_all).toFixed(2);
     var amount_adjusted=0;
     console.log('here 4');
       console.log('amount_adjusted'+amount_adjusted);

   }
// if(to_be_adjust=='')
//    var amount_adjusted=0;
//  else
//   var amount_adjusted=parseFloat(to_be_adjust);

 if(ij!='')
  {
    console.log('here');
     console.log('ij '+ij);
  if($('.inv_selected_'+ij).is(':checked'))
  {   
    var total_amount_in_ref=$('.tot_sales_amount_'+ij).val();
    var amount_paid= $('.tot_sales_amount_paid_'+ij).val();
    if(amount_paid=='' || amount_paid=='0')
    { 
         console.log('in if 1');
        $('.refrence_amount_'+table_id).val('0');
        console.log('total_amount_in_ref = '+total_amount_in_ref);
        console.log('form_input_amount = '+form_input_amount);
      if(parseFloat(total_amount_in_ref) > parseFloat(form_input_amount))
      { 
         console.log('in if 11');console.log(amount_adjusted);
         if(parseFloat(amount_adjusted)=='0' || parseFloat(amount_adjusted)=='' || parseFloat(amount_adjusted)=='0.00')
        {
           console.log('in if 12');

         
         if (amount_picked==0)
         {

            var new_amount_adjusted=parseFloat(form_input_amount).toFixed(2);
               $('.tot_sales_amount_paid_'+ij).val(new_amount_adjusted);
                amount_picked=parseFloat(form_input_amount);
            amount_adjusted=0;
         }
         else {
           

                
              var new_amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
		        $('.tot_sales_amount_paid_'+ij).val(new_amount_adjusted);
		        amount_picked=parseFloat(amount_picked)+parseFloat(new_amount_adjusted);
            amount_adjusted=parsefloat(amount_adjusted-new_amount_adjusted).toFixed(2);
          
         } 
         //$('.tot_sales_amount_paid_'+ij).val(form_input_amount);
         //$('.tot_sales_amount_paid_'+ij).val();
     
        }
        else
        {

          console.log('in else 12');
          var new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(amount_adjusted);
         $('.tot_sales_amount_paid_'+ij).val(amount_adjusted);
          amount_picked=parseFloat(amount_picked)+parseFloat(amount_adjusted);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
             
        }
      }
      else if(parseFloat(total_amount_in_ref) < parseFloat(form_input_amount))
      {
           console.log('in if 11.elseif'); 
           console.log('amount_picked = '+amount_picked);
            console.log('form_input_amount = '+form_input_amount);
            console.log('amount_adjusted = '+amount_adjusted);
           if(parseFloat(amount_adjusted)=='0' || parseFloat(amount_adjusted)==''|| parseFloat(amount_adjusted)=='0.00')
          {            
            
              
            if(amount_picked>=form_input_amount)
            {
                   console.log('in if 12.elseif');
                  var new_amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
                  $('.tot_sales_amount_paid_'+ij).val(new_amount_adjusted);
                  amount_picked=parseFloat(amount_picked);
                  amount_adjusted=0;    

            }
                               
                  
          }         
          else
          {
            console.log('in else 12.elseif');
            var new_amount_adjusted=parseFloat(amount_adjusted)-parseFloat(total_amount_in_ref);
            console.log('form_input_amount = '+form_input_amount);
            console.log('amount_adjusted_till_now = '+amount_adjusted_till_now);
            console.log('amount_adjusted = '+amount_adjusted);
            console.log('total_amount_in_ref = '+total_amount_in_ref);

            if(parseFloat(amount_adjusted) < parseFloat(total_amount_in_ref))
                {
                  var new_amount_adjusted = parseFloat(amount_adjusted) - parseFloat(amount_adjusted);
                  total_amount_in_ref = amount_adjusted;
                                  
                }
            console.log('new_amount_adjusted = '+new_amount_adjusted);
           $('.tot_sales_amount_paid_'+ij).val(total_amount_in_ref);
            amount_picked=parseFloat(amount_adjusted_till_now)+parseFloat(total_amount_in_ref);
           amount_adjusted=parseFloat(new_amount_adjusted);

           console.log('amount_picked = '+amount_picked);
           console.log('amount_adjusted = '+amount_adjusted);
          }
       
      }
      else
      { 
        if(amount_adjusted!='0')
          {
             console.log('in else 1.11'+amount_adjusted);
             var new_amount_adjusted;
               new_amount_adjusted=parseFloat(total_amount_in_ref)-parseFloat(amount_adjusted);
                $('.tot_sales_amount_paid_'+ij).val(amount_adjusted);
           amount_picked=parseFloat(amount_picked)+parseFloat(amount_adjusted);
         amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked); 

          }
          else{
         console.log('in else 11');
             if($('.tot_sales_amount_paid_'+ij).val()=='0')
             {
              console.log('in else 11 - in if 1.11');
               $('.tot_sales_amount_paid_'+ij).val(total_amount_in_ref);   console.log(total_amount_in_ref);
              amount_picked=parseFloat(amount_picked)+parseFloat(total_amount_in_ref);
              amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);
             }
             else if($('.refrence_amount_'+table_id).val()=='0')
             {
              console.log('in else 11- in else 2.11');
              var new_ref_value=$('.refrence_amount_'+table_id).val();
              console.log(new_ref_value);
               amount_picked=parseFloat(amount_picked)-parseFloat(new_ref_value);
                amount_adjusted=parseFloat(amount_adjusted)-parseFloat(new_ref_value);
              }
              else
              {

              }
            }
       }
     }
    else
    { 
     console.log('in else 1- '+ to_be_adjust);
       if( (to_be_adjust!='0.00') )
      {
        // if(to_be_adjust!='0')
        // {
        //   console.log('in else 1.1.1');

        //    var new_ref_val=$('.refrence_amount_'+table_id).val();
        //      $('.refrence_amount_'+table_id).val(parseFloat(new_ref_val)+parseFloat(to_be_adjust));
        //       amount_picked=parseFloat(amount_adjusted_till_now)+parseFloat(to_be_adjust);
        //       amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);        
        // }D
      }
      else
      {
          console.log('in else 1.1.2');
           $('.refrence_amount_'+table_id).val($('.refrence_amount_'+table_id).val());
           amount_picked=form_input_amount;
        $('.form_input_ref_'+table_id).val('new_reference');
      }
    }  
    
  }
  else
  {
     $('.refrence_amount_'+table_id).val(form_input_amount);
      amount_picked=form_input_amount;
     $('.form_input_ref_'+table_id).val('new_reference');
  }
}
else
{
   $('.confirm_btn_modal').show();
   if(to_be_adjust!='0.00')
   {
    $('.refrence_amount_'+table_id).val(form_input_amount);
      if( (amount_adjusted_till_now!='') && (amount_adjusted_till_now!='0') )
      {
        amount_picked=amount_adjusted_till_now;
        amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);   
      }
      else
      {
        amount_picked=form_input_amount;
        amount_adjusted=parseFloat(form_input_amount)-parseFloat(amount_picked);   
      }  
       $('.form_input_ref_'+table_id).val('new_reference');  
    }
    else {}
}

  $('.amount_to_adj').html(form_input_amount);
   $('.amount_adjusted').html(amount_picked);
    $('.to_be_adjust').html(amount_adjusted);

    // $('.form_input_ref_'+table_id).val($('.form_input_ref_'+table_id).val() + ref_doc_num+'|#|');
      $('.form_input_ref_amount_'+table_id).val(form_input_amount);
  //   $('.modal-close-btn').trigger('click');


//  $('.dataTables_filter input[type=search]').val('');
//  //$('#datatable-default2').dataTable().fnFilter('');
//  $('#datatable-default2').DataTable().search('').draw();
  
}


function pass_param_2(checkbox,val)
{
  console.log(checkbox);
  var checked = null;
  if(checkbox != null)
  {   
    console.log('inside if')
    var checked = checkbox.checked;
  }
  else{
    
  }
  
  var num_count = 0;
  console.log('inside pass param');
   var ref_number_correspond='';var unchecked_val=[];
  console.log(checked_val);
  console.log('checked');
  console.log(checked);
  if(checked != null){
   if ( checked )
   {
      if(checked_val=='')
        {
            //checked_val.push($(this).val());
            checked_val = val;
        }
        else if(jQuery.inArray($(this).val(), checked_val) !== -1)
         {
            //checked_val.push($(this).val());
            checked_val = val;
         }
         else
          {
            if(val!=checked_val)///maybe from the unchceked value
            {
              if( $('.tot_sales_amount_paid_'+val ).val()=='0' )
              {
                 checked_val = val;
              }
            }
          }    
         console.log(checked_val); 
    }
 else{
      // console.log('inside unchecked val');
      // console.log(num_count); 
      // console.log(checked_val); 
      unchecked_val=val;  
      $('.confirm_btn_modal').show();
   
      var picked_adjusted_amount= $('.tot_sales_amount_paid_'+unchecked_val).val();

      $('.tot_sales_amount_paid_'+unchecked_val).val('0');
      var amount_adjusted=$('.amount_adjusted').html();
      var to_adjust=$('.to_be_adjust').html();
      var newly_adjusted=parseFloat(amount_adjusted)-parseFloat(picked_adjusted_amount);

      if(parseFloat(newly_adjusted) >='0')
      $('.amount_adjusted').html(newly_adjusted);
      else
      $('.amount_adjusted').html('0');//////it can be a negative number, not sure, expecting a wrong logic here

      var new_to_adjust=parseFloat(to_adjust)+parseFloat(picked_adjusted_amount);
      $('.to_be_adjust').html(new_to_adjust);
}
  }

 num_count++;
    
    ref_number_correspond=$('.ref_doc_numbers_'+checked_val).val();
    console.log(checked_val);
 return checked_val+'##'+ref_number_correspond;
}



function pass_param_old()
{
  var checked_val=[]; var ref_number_correspond='';var unchecked_val=[];
  $('.class_checkbox').each(function() {
   if ( $(this).is(':checked') )
   {
      if(checked_val=='')
        {
            checked_val=$(this).val();
        }
        else if(jQuery.inArray($(this).val(), checked_val) !== -1)
         {
            checked_val=$(this).val();
         }
         else
          {
            if($(this).val()!=checked_val)///maybe from the unchceked value
            {
              if( $('.tot_sales_amount_paid_'+$(this).val() ).val()=='0' )
              {
                 checked_val=$(this).val();
              }
            }
          }    
    }
 else{
  //console.log('inside unchecked val');
   unchecked_val=$(this).val();  
    $('.confirm_btn_modal').show();
   if(jQuery.inArray($(this).val(), checked_val) == -1)
         {
         // console.log(' inside unchecked val condition ');
            checked_val = $.grep(checked_val, function(value) {
              return value != unchecked_val;
            });
         }
    var picked_adjusted_amount= $('.tot_sales_amount_paid_'+unchecked_val).val();

 $('.tot_sales_amount_paid_'+unchecked_val).val('0');
 var amount_adjusted=$('.amount_adjusted').html();
 var to_adjust=$('.to_be_adjust').html();
 var newly_adjusted=parseFloat(amount_adjusted)-parseFloat(picked_adjusted_amount);

 if(parseFloat(newly_adjusted) >='0')
$('.amount_adjusted').html(newly_adjusted);
else
$('.amount_adjusted').html('0');//////it can be a negative number, not sure, expecting a wrong logic here

 var new_to_adjust=parseFloat(to_adjust)+parseFloat(picked_adjusted_amount);
$('.to_be_adjust').html(new_to_adjust);
 }
     });
    ref_number_correspond=$('.ref_doc_numbers_'+checked_val).val();
 return checked_val+'##'+ref_number_correspond;
}


function check_val_less_than_amount(ij)
{
  console.log('working event');
  var tot_amount=$('.tot_sales_amount_'+ij).val();
  var paid_amount=$('.tot_sales_amount_paid_'+ij).val();

/////////////////// new changes ////////////////////////////////////////
var amount_adjusted=$('.amount_adjusted').html();
//console.log(amount_adjusted);
var to_adjust=$('.to_be_adjust').html();
var cust_amount=$('.amount_to_adj').html();
console.log(ij);
console.log(cust_amount);

var new_amount_adj=parseFloat(amount_adjusted)+parseFloat(paid_amount);
$('.amount_adjusted').html(new_amount_adj);
$('.to_be_adjust').html(parseFloat(cust_amount)-parseFloat(new_amount_adj));
///////////////////till here new changes are////////////////////////////////////////

  var balnce_amount=parseFloat(tot_amount)-parseFloat(paid_amount);
  $('.tot_sales_bal_amount_'+ij).val(balnce_amount.toFixed(2));

  if(parseFloat(paid_amount) > parseFloat(tot_amount))
  {
    $('.amount_overdue_'+ij).html('Paid amount exceeds total amount');
    $('.confirm_btn_modal').hide();
  }
  else
  {
     $('.amount_overdue_'+ij).html('');
    $('.confirm_btn_modal').show();
  }
}


function get_checked_count(ij)
{
    var amounts=0;
  if($('.inv_selected_'+ij).is(':checked'))
  {   
    amounts=parseFloat($('input[name="total_invs_edited"]').val())+parseFloat($('.tot_sales_amount_'+ij).val());
    $('input[name="total_invs_edited"]').val(amounts);
    //$('input[name="add_cash_customer"]').val('1');
//console.log('checked box');
//$('.cash_cusotmer_details').show();

  }
  else
  {
 var amounts=1;
   amounts=parseFloat($('input[name="total_invs_edited"]').val())-parseFloat($('.tot_sales_amount_'+ij).val());
    $('input[name="total_invs_edited"]').val(amounts);
  }
}


function submit_sales_inv_amount()
{


////this two rows if you search about one value manually it will reset the search box befor saving and that will be useful to take all rows selcted befor
  $('.dataTables_filter input[type=search]').val('');
 $('#datatable-default2').DataTable().search('').draw();
/////////////////////////////////////////////


  var issue_text_data=$('.text_data_issue').html();
  var to_be_adjust= $('.to_be_adjust').html();
   var refrence_names='';
    var table_id_modal=$('table tbody tr td input[name="table_id_modal"]').val();
     $('.form_input_ref_'+table_id_modal).val('');
     $('.si_doc_num_'+table_id_modal+'').val('');
       $('.si_inv_id_'+table_id_modal+'').val('');
       $('.si_amount_'+table_id_modal+'').val('');
       $('.si_amount_paid_'+table_id_modal+'').val('');
       // $('table tbody tr td input[name="inv_id_modal[]"]').val('');
       // $('table tbody tr td input[name="sales_inv_amount_modal[]"]').val('');
       // $('table tbody tr td input[name="paid_amount_modal[]"]').val('');
       // $('table tbody tr td input[name="inv_doc_numbers_modal[]"]').val('');
if(to_be_adjust=='0')
{
   $('.class_checkbox').each(function() {
   if ( $(this).is(':checked') )
   {
    
//console.log('table_id_modal '+table_id_modal);
      var sales_inv_id=$('table tbody tr td input[name="inv_id_modal[]"]').map(function(){return $(this).val();}).get().join('|$$|'); 
    //  console.log(sales_inv_id);
var sales_inv_amount=$('table tbody tr td input[name="sales_inv_amount_modal[]"]').map(function(){return $(this).val();}).get().join('|$$|'); 
      var amount_paid=$('table tbody tr td input[name="paid_amount_modal[]"]').map(function(){return $(this).val();}).get().join('|$$|'); 
    var sales_doc_num=$('table tbody tr td input[name="inv_doc_numbers_modal[]"]').map(function(){return $(this).val();}).get().join('|$$|'); 
  //   console.log(sales_doc_num);

       $('.si_doc_num_'+table_id_modal+'').val(sales_doc_num);
       $('.si_inv_id_'+table_id_modal+'').val(sales_inv_id);
       $('.si_amount_'+table_id_modal+'').val(sales_inv_amount);
       $('.si_amount_paid_'+table_id_modal+'').val(amount_paid);
      
       var amountss_4='0';
        $('input[name="paid_amount_modal[]"]').each(function(){
        amountss_4= parseFloat(amountss_4)+parseFloat($(this).val());
        }); 

    refrence_names=$('.ref_doc_numbers_'+$(this).val()).val(); 

  // $('.form_input_ref_'+table_id_modal).val(refrence_names+'|#|');

   $('.form_input_ref_'+table_id_modal).val($('.form_input_ref_'+table_id_modal).val() + refrence_names+'|$$|');

//$('.form_input_amount_'+table_id_modal).val(parseFloat(amountss_4));
$('.form_input_amount_'+table_id_modal).attr('readonly');
$('.form_input_amount_'+table_id_modal).prop("readonly", true);
    // $('.confirm_btn_modal').hide();
      } 
    else{}  
    }); 
      $('.modal-close-btn').trigger('click');
    }
    else
    {
       // $('.modal-close-btn').trigger('click');

      alert('Error in paid amount');
    }
}









function reset_fields()
{


        $('.dataTables_filter input[type=search]').val('');

 $('#datatable-default2').DataTable().search('').draw();

  
  var amount_tot=$('.amount_to_adj').html();
  $("input[name='paid_amount_modal[]']").val('0');
  $("input[name='refrence']").val('0');
  $('.amount_adjusted').html('0');
  $('.to_be_adjust').html('0');



var inputs = document.querySelectorAll('.class_checkbox');
        for (var i = 0; i < inputs.length; i++) {
            inputs[i].checked = false;
        }

//$('.inv_selected_1').val('0');
//$('.class_checkbox').html('0');
//$('.inv_selected_').prop('checked', false);
     



}

function check_for_reset()
{
  if (confirm("Are you sure, You want to reset this form?")) {
                 $('.myform').trigger("reset");
            } 
            else {
              return false;
            }
}





// function reset_fields()
// {
//   var amount_tot=$('.amount_to_adj').html();
//   $("input[name='paid_amount_modal[]']").val('0');
//   $("input[name='refrence']").val('0');
//   $('.amount_adjusted').html('0');
//   $('.to_be_adjust').html('0');
// }

// function check_for_reset()
// {
//   if (confirm("Are you sure, You want to reset this form?")) {
//                  $('.myform').trigger("reset");
//             } 
//             else {
//               return false;
//             }
// }

$('.myform').submit(function() {
// e.preventDefault();

var rowcount = $('.new_rows tr').length;
var salesman_ids=$('table tbody tr td select[name="cbr_salesman[]"]').map(function(){return $(this).find('option:selected').val();}).get().join('|#|');  

var customer_acc_ids=$('table tbody tr td select[name="cbr_customer_acc[]"]').map(function(){return $(this).val();}).get().join('|#|');

var receipt_amounts=$('table tbody tr td input[name="cbr_amount[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var receipt_ref=$('table tbody tr td input[name="cbr_ref[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

 var receipt_remarks=$('table tbody tr td input[name="cbr_remark[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

 var sales_inv_ids=$('table tbody tr td input[name="si_inv_id[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
 //console.log(sales_inv_ids);
var sales_inv_amount=$('table tbody tr td input[name="si_amount[]"]').map(function(){return $(this).val();}).get().join('|#|');
var sales_inv_amount_paid=$('table tbody tr td input[name="si_amount_paid[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var sales_inv_doc_num=$('table tbody tr td input[name="si_doc_num[]"]').map(function(){return $(this).val();}).get().join('|#|');
//console.log(quantity+' '+package_size+' '+product_id);

$("input[name='hid_salesman']").val(salesman_ids);
$("input[name='hid_customer']").val(customer_acc_ids);

$("input[name='hid_amounts']").val(receipt_amounts);
$("input[name='hid_remark']").val(receipt_remarks);

$("input[name='hid_ref']").val(receipt_ref);
$("input[name='sales_inv_id']").val(sales_inv_ids);
$("input[name='sales_inv_amount']").val(sales_inv_amount);
$("input[name='sales_inv_amount_paid']").val(sales_inv_amount_paid);
$("input[name='sales_doc_num']").val(sales_inv_doc_num);
$("input[name='hid_date']").val($("input[name='cbr_date']").val());
var ij=0;
var data_var=[];

$('.new_rows tr td').each(function() { 
var cellText = $(this).html(); 
 //  console.log(cellText);  
    $('.cell_text_data').append(cellText).hide(); 
});

//console.log(cellText);
 // console.log($("input[name='hid_salesman']").val());
 // console.log($("input[name='hid_customer']").val());
 //  console.log($("input[name='sales_inv_id']").val());
 // console.log($("input[name='sales_inv_amount_paid']").val());

// console.log($("input[name='hid_amounts']").val());
// console.log($("input[name='hid_remark']").val());
//  console.log($("input[name='hid_ref']").val());
//var table_row_added=$('.new_rows').html();

 if ($('.new_rows tr').length == 0) 
 {
  alert('Please choose items to add and submit');
  return false;
 }
 else
 {
  return true;
 }
 //return false;
  // your code here
});
        </script>

<script type="text/javascript">




$('.myform').submit(function() {
 //e.preventDefault();

var rowcount = $('.new_rows tr').length;
var salesman_ids=$('table tbody tr td select[name="cbr_salesman[]"]').map(function(){return $(this).find('option:selected').val();}).get().join('|#|');  

var customer_acc_ids=$('table tbody tr td select[name="cbr_customer_acc[]"]').map(function(){return $(this).val();}).get().join('|#|');

var receipt_amounts=$('table tbody tr td input[name="cbr_amount[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

var receipt_ref=$('table tbody tr td input[name="cbr_ref[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

 var receipt_remarks=$('table tbody tr td input[name="cbr_remark[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

 var sales_inv_ids=$('table tbody tr td input[name="si_inv_id[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
 //console.log(sales_inv_ids);
var sales_inv_amount=$('table tbody tr td input[name="si_amount[]"]').map(function(){return $(this).val();}).get().join('|#|');
var sales_inv_amount_paid=$('table tbody tr td input[name="si_amount_paid[]"]').map(function(){return $(this).val();}).get().join('|#|'); 
var sales_inv_doc_num=$('table tbody tr td input[name="si_doc_num[]"]').map(function(){return $(this).val();}).get().join('|#|'); 

$('table tbody tr td input[name="cbr_amount[]"]').each(function(){
var each_amounts=$(this).val();
if(each_amounts=='')
{
   return false;
}
});

$('table tbody tr td input[name="cbr_ref[]"]').each(function(){
var each_amounts_ref=$(this).val();
if(each_amounts_ref=='')
{
   return false;
}
});
//console.log(quantity+' '+package_size+' '+product_id);

$("input[name='hid_salesman']").val(salesman_ids);
$("input[name='hid_customer']").val(customer_acc_ids);

$("input[name='hid_amounts']").val(receipt_amounts);
$("input[name='hid_remark']").val(receipt_remarks);

$("input[name='hid_ref']").val(receipt_ref);

$("input[name='sales_inv_id']").val(sales_inv_ids);
$("input[name='sales_inv_amount']").val(sales_inv_amount);
$("input[name='sales_inv_amount_paid']").val(sales_inv_amount_paid);
$("input[name='sales_doc_num']").val(sales_inv_doc_num);
$("input[name='hid_date']").val($("input[name='cbr_date']").val());
var ij=0;
var data_var=[];

$('.new_rows tr td').each(function() { 
var cellText = $(this).html(); 
 //  console.log(cellText);  
    $('.cell_text_data').append(cellText).hide(); 
});

//console.log(cellText);
 //console.log($("input[name='sales_inv_id']").val());
 //console.log($("input[name='hid_customer']").val());
// console.log($("input[name='hid_amounts']").val());
// console.log($("input[name='hid_remark']").val());
//  console.log($("input[name='hid_ref']").val());
//var table_row_added=$('.new_rows').html();

 if ($('.new_rows tr').length == 0) 
 {
  alert('Please choose items to add and submit');
  return false;
 }
 else
 {
  return true;
 }
 //return false;
  // your code here
});
        </script>









</body>

</html>