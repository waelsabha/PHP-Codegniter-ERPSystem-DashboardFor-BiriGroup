<table style="width: 100% !important;">
			<tbody>
		<tr>

			<td><span style="border: 1px solid black;"><?php echo $currency_name[0]->currency_name.''.$amount[$index_val];?></span></td>
			<td colspan="2"><h3><ul>CASH RECEIPT VOUCHER</ul></h3></td>
			
			<td><p style="border: 1px solid black;"><span>No. <?php echo $recpt_data[0]->cbr_doc_no;?></span><br/>

				<span>Date: <?php echo $recpt_data[0]->cbr_date;?></span></p></td>

		</tr>

		<tr>

			<td><p>Received from Mr./Ms. :</p></td>
			<td colspan="2"><?php echo $cutomer_data[0]->label;?></td>

		</tr>

		<tr >

			<td><p>The Sum of : <?php echo $currency_name[0]->currency_name;?></p></td>

            <td colspan="3"> <?php echo $this->numbertowordconvertsconver->convert_number($amount[$index_val]);?></td>

		</tr>

		<tr>

			<td><p >Being :</p></td>
			<td colspan="3"><span>not sure</span> <span><?php echo $recpt_data[0]->cbr_due_date;?></span></td>

		</tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		<tr></tr><tr></tr>
		
		
		<tr></tr>
		
		<tr style="padding-top:2em;">

			<td colspan="2"><p >Recivers Signature : <span  style="display: inline-block;border-bottom: 0.5px dotted black;width:25%;"></p></td>
			
			<td colspan="2"><p >Signature :<span class="dotted-line" style="display: inline-block;border-bottom: 0.5px dotted black;width:25%;"></p></td>
			
		</tr>
</tbody>
	</table>