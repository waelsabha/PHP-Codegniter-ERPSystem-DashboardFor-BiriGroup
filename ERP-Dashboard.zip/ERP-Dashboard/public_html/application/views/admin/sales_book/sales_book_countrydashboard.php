<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>
<?php
//$this->session->unset_userdata('prd_info');
//print_r($this->session->userdata['prd_info']);
if (!empty($this->session->userdata('prd_info'))) {
insert_prd_sales_vochuer();
}

?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<style type="text/css">
.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>
</head>


<body>

<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Dashboard</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Dashboard</span></li>
<li><span>Country Sales Data</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-md-12">
<section class="panel">
<header class="panel-heading">

<a href="https://mybusiness.googleapis.com/v4/accounts/{accountId}/locations/{locationId}/reviews"></a>

<h2 class="panel-title">Sort Table</h2>
</header>
<?php 
  echo form_open('submit_date_range_sales_country_book');?>

<div class="panel-body">





<div class="row">
  <div class="col-sm-6">
  <div class="form-group">
  <label class="control-label" for="inputPlaceholder">Choose Country</label><br/>
   <div class="col-md-8">
 <select data-plugin-selectTwo  class="form-control populate" name="choose_country">

  <option value="">Choose</option>
  <?php
  foreach($country as $cou)
  {

   ?>
  <option value="<?php echo $cou->sbr_city;?>"  > <?php echo $cou->sbr_city;?> </option> 
   <?php
  }
  ?>
 </select>

  
 <div class="form_error">  <?php echo $this->session->flashdata('choose_customer');?></div>
</div>
  <div class="form_error">  </div>
  
  </div>
  </div>

</div>


<div class="row">
  <div class="col-sm-6">
  <div class="form-group">
  <label class="control-label" for="inputPlaceholder">Choose Month</label><br/>
    <select class="form-control mb-md bank month_name" name="month_selected" >
      <option value="">Choose</option>
      <option value="01" >Jan</option>

      <option value="02" >Feb</option>

      <option value="03" >Mar</option>

      <option value="04" >Apr</option>

      <option value="05" >May</option>

      <option value="06" >Jun</option>

      <option value="07" >Jul</option>

      <option value="08" >Aug</option>

      <option value="09" >Sep</option>

      <option value="10" >Oct</option>

      <option value="11" >Nov</option>

      <option value="12" >Dec</option>
    </select>
  <div class="form_error">  </div>
  
  </div>
  </div>
  <div class="col-sm-6"> 
  <div class="form-group">
  <label class="control-label" for="inputPlaceholder"> OR Choose Date-range</label><br/>
   <div class="input-daterange input-group" data-plugin-datepicker="">
    <span class="input-group-addon">
    <i class="fa fa-calendar"></i>
    </span>
    <input type="text" class="form-control" name="start_date_rng">
    <span class="input-group-addon">to</span>
    <input type="text" class="form-control" name="end_date_rng">
</div>
    
  </div>
  </div>
</div>


<!-- onclick="type_bank();" -->
</div>
<footer class="panel-footer">
<button class="btn btn-primary">Submit</button>
</footer>
<?php
echo form_close();?>
</section>
</div>
</div>









<div class="row">
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"> Top Category Product Sales (for  <?php echo $choose_country , $previous_year;?> ) </h2>
</header>
<div class="panel-body">
<div id="container444" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Top Category Product Sales (for <?php echo $choose_country,$current_year;?>)</h2>
</header>
<div class="panel-body">
<div id="container4" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
</div>


<div class="row">
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"> Top Item Product Sales Quantity (for  <?php echo $choose_country, $previous_year;?> ) </h2>
</header>
<div class="panel-body">
<div id="containeritemprev" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title"> Top Item Product Sales Quantity (for <?php echo $choose_country,$current_year;?>)</h2>
</header>
<div class="panel-body">
<div id="containeritem" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
</div>



<div class="row">
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Top Custumer for Sales (for  <?php echo $choose_country, $previous_year;?> ) </h2>
</header>
<div class="panel-body">
<div id="containcustomerlast" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Top Custumer for Sales (for <?php echo $choose_country,$current_year;?>)</h2>
</header>
<div class="panel-body">
<div id="containcustomer" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
</div>













<?php
$result_test=array();
$total_prds=0;
$calc_sum=[];
$k=0;
$gross_sum=[];
if(!empty($cat_prd))
{
foreach($cat_prd as $index=>$element)
{
  //sort($r['sum']);
   arsort($element);
$avg_prd_price=0;
  $total_cat_count=count($index);
  $total_prds=count($element);
$avg_cat_price=0;$total_prd_sum=0;$total_prd_qnty=0;

  foreach($element as $b1=>$r)
  {
if(empty($r['prd_code'])){$code_prd="NULL";}else{$code_prd=$r['prd_code'];}
    //$gross_sum[]=$r['sum'];
    //  $sort_array=arsort($element);
   $total_prd_sum=$total_prd_sum+$r['sum'];
   $total_prd_qnty=$total_prd_qnty+$r['prd_qnty'];

  $avg_prd_price=($r['sum']/$r['prd_qnty']);
$avg_cat_price=($total_prd_sum/$total_prd_qnty);
  
  
    if(!array_key_exists($index,$result_test)){
        // Add new data in array with ACCOUNT_NUMBER as an index
        $result_test[$index][$index][$index][$index][$index]['total_count_cat']= $total_cat_count;
        $result_test[$index][$index][$index][$index][$index]['total_count_prd']= $total_prds;
        $result_test[$index][$index][$index][$index][$index]['total_prd_qty']= $total_prd_qnty;
        $result_test[$index][$index][$index][$index][$index]['total_prd_sum']= $total_prd_sum;
        $result_test[$index][$index][$index][$index][$index]['cat_avg_price']= $avg_cat_price;

        $result_test[$index][$index][$index][$index][$index]['prd_code']= $code_prd;
        $result_test[$index][$index][$index][$index][$index]['prd_qnty']= $r['prd_qnty'];
        $result_test[$index][$index][$index][$index][$index]['prd_sum']= $r['sum'];
        $result_test[$index][$index][$index][$index][$index]['prd_avg_price']= number_format((float)$avg_prd_price, 2, '.', '');

    }else
    {
      $result_test[$index][$index][$index][$index][$index]['total_prd_qty'].=",". $total_prd_qnty;
      $result_test[$index][$index][$index][$index][$index]['total_prd_sum'].=",". $total_prd_sum;
      $result_test[$index][$index][$index][$index][$index]['cat_avg_price'].=",". $avg_cat_price;
        // Only alter category index
       $result_test[$index][$index][$index][$index][$index]['prd_code'] .=",".$code_prd; 
      $result_test[$index][$index][$index][$index][$index]['prd_qnty'].=",".$r['prd_qnty'];  
      $result_test[$index][$index][$index][$index][$index]['prd_sum'].=",".$r['sum'];
       $result_test[$index][$index][$index][$index][$index]['prd_avg_price'].=",".number_format((float)$avg_prd_price, 2, '.', '');
    }
  }
  $total_prd_qnty=0;
  $avg_prd_price=0;
  $total_prd_sum=0;
 $avg_cat_price=0;
}
}
?>

<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Data table view for category Vs Products</h2>
</header>
<div class="panel-body">
<table class="table table-responsive table-bordered table-striped mb-none " id="datatable-details2">
<thead>
<tr>
<th></th>
 <th>Category</th>

<th style="display: none;">Item code</th>
<th style="display: none;">Quantity</th>
<th style="display: none;">Amount</th>
<th style="display: none;">Avg. Sales Price</th>

<th>Total no. Products</th>
<th>Sum of Prd Qnty</th>
<th>Sum of Prd Amount</th>
<th>Avg. Sales Price</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
$total_prds=0;
$calc_sum=[];
foreach ($result_test as $key2=>$index2) 
{

  $xpl1 =explode(",",$index2[$key2][$key2][$key2][$key2]['prd_code']);

  
    $n_category1 = "";$n_category1_test="";
    foreach($xpl1 as $b1 => $a1){
      $prd_code[]=$a1;
      $n_category1 .= ($b1!=0) ? "<hr/>".$a1 : $a1 ;//amount
    }

    $xpl2 = explode(",",$index2[$key2][$key2][$key2][$key2]['prd_qnty']);
    $n_category2 = "";$n_category2_test="";
    foreach($xpl2 as $b2 => $a2){
      $prd_qnty[]=$a2;
    //$word_limited2= str_pad($a2,26);
     $n_category2 .= ($b2!=0) ? "<hr/>".$a2 : $a2 ; //type
    }

   $xpl3 = explode(",",$index2[$key2][$key2][$key2][$key2]['prd_sum']);
    $n_category3 = "";
    foreach($xpl3 as $b3 => $a3){
     $n_category3 .= ($b3!=0) ? "<hr/>".$a3 : $a3; //desc
    }

    $xpl4 = explode(",",$index2[$key2][$key2][$key2][$key2]['prd_avg_price']);
    $n_category4 = "";$n_category4_test="";
  foreach($xpl4 as $b4 => $a4)
  {
    $n_category4 .= ($b4!=0) ? "<hr/>".$a4 : $a4 ; //bank
  }

    $xpl5 = explode(",",$index2[$key2][$key2][$key2][$key2]['total_prd_qty']);
    $total_prd_qty=end($xpl5);

    $xpl6 = explode(",",$index2[$key2][$key2][$key2][$key2]['total_prd_sum']);
    $total_prd_sum=end($xpl6);

    $xpl7 = explode(",",$index2[$key2][$key2][$key2][$key2]['cat_avg_price']);
    $cat_avg_price=end($xpl7);

    $xpl8 = explode(",",$index2[$key2][$key2][$key2][$key2]['total_count_prd']);
    $total_count_prd=end($xpl8);

  ?>
<tr>
  <td><?php echo $i++;?></td>
  <td><?php echo $key2;?></td>

  <td style="display: none;"><?php echo $n_category1;?></td><!--code-->
  <td style="display: none;"><?php echo $n_category2;?></td><!--qnty-->
  <td style="display: none;"><?php echo $n_category3;?></td><!--sum-->
  <td style="display: none;"><?php echo $n_category4;?></td><!--avg price-->

  <td><?php echo number_format((float)$total_count_prd, 2, '.', '');?></td>
  <td><?php echo number_format((float)$total_prd_qty, 2, '.', '');?></td>
  <td><?php echo number_format((float)$total_prd_sum, 2, '.', '');?></td>
  <td><?php echo number_format((float)$cat_avg_price, 2, '.', '');?></td>
</tr>
<?php
}
?>
</tbody>
</table>


</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>


<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript">
</script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>




<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>




<script>
// Create the chart for category depending on country
Highcharts.chart('container4', {
chart: {
type: 'column'
},
title: {
text: 'Browser products selled in  each category for :  <?php if(!empty($start_date && $end_date && $choose_country))
{
 print_r($choose_country); echo "  :  ";  print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($choose_country); echo "  :  "; print_r($start_date);
}
elseif(!empty($end_date))
{
 print_r($choose_country); echo "  :  "; print_r($end_date);
}
elseif(!empty($selected_month))
{
 print_r($choose_country); echo "  :  ";   echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($current_year);
}
else
{
 print_r($choose_country); echo "  :  "; print_r($current_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total count of each category'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Categories",
    colorByPoint: true,


    data: [
    <?php 
    foreach ($all_category as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbp_ar_category.'",
            y: '.number_format((float)$val4->total_gross_amount, 2, '.', '').',
            drilldown: "'.$val4->sbp_ar_category.'"
        },';
    }
    ?>
    ]



}
],
drilldown: {
series: [
<?php
foreach ($cat_prd as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.number_format((float)$val6['sum'], 2, '.', '').'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>

<script>
// Create the chart
Highcharts.chart('container444', {
chart: {
type: 'column'
},
title: {
text: 'Browser products selled in each category for this country this year <?php if(!empty($start_date && $end_date && $choose_country))
{
  print_r($choose_country); echo "  :  "; print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($choose_country); echo "  :  ";   print_r($start_date);
}
elseif(!empty($end_date))
{
 print_r($choose_country); echo "  :  "; print_r($end_date);
}
elseif(!empty($selected_month))
{
  print_r($choose_country); echo "  :  ";  echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($previous_year);
}
else
{
print_r($previous_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total count of each category'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Categories",
    colorByPoint: true,


    data: [
    <?php 
    foreach ($all_category_last_year as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbp_ar_category.'",
            y: '.number_format((float)$val4->total_gross_amount, 2, '.', '').',
            drilldown: "'.$val4->sbp_ar_category.'"
        },';
    }
    ?>
    ]





}
],
drilldown: {
series: [
<?php
foreach ($cat_prd_last_year as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.number_format((float)$val6['sum'], 2, '.', '').'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>





<script>
// Create the chart for item  product on country
Highcharts.chart('containeritem', {
chart: {
type: 'column'
},
title: {
text: 'Browser Items selled  for :  <?php if(!empty($start_date && $end_date && $choose_country))
{
 print_r($choose_country); echo "  :  ";  print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($choose_country); echo "  :  "; print_r($start_date);
}
elseif(!empty($end_date))
{
 print_r($choose_country); echo "  :  "; print_r($end_date);
}
elseif(!empty($selected_month))
{
 print_r($choose_country); echo "  :  ";   echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($current_year);
}
else
{
 print_r($choose_country); echo "  :  "; print_r($current_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total Quantity of each Item'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Items:",
    colorByPoint: true,
    data: [
    <?php 
    foreach ($productitem as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbp_prd_code.'",
            y: '.$val4->total_qty.',
            drilldown: "'.$val4->sbp_prd_code.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($cat_prd as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.$val6['prd_qnty'].'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>

<script>
// Create the chart for item  product on country
Highcharts.chart('containeritemprev', {
chart: {
type: 'column'
},
title: {
text: 'Browser Items selled  for :  <?php if(!empty($start_date && $end_date && $choose_country))
{
 print_r($choose_country); echo "  :  ";  print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($choose_country); echo "  :  "; print_r($start_date);
}
elseif(!empty($end_date))
{
 print_r($choose_country); echo "  :  "; print_r($end_date);
}
elseif(!empty($selected_month))
{
 print_r($choose_country); echo "  :  ";   echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($current_year);
}
else
{
 print_r($choose_country); echo "  :  "; print_r($current_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total Quantity of each Item'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Items:",
    colorByPoint: true,
    data: [
    <?php 
    foreach ($productitemprev as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbp_prd_code.'",
            y: '.$val4->total_qty.',
            drilldown: "'.$val4->sbp_prd_code.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($cat_prd as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.$val6['prd_qnty'].'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>






<script>
// Create the chart for item  product on country
Highcharts.chart('containcustomer', {
chart: {
type: 'column'
},
title: {
text: 'Browser Top Customer  for :  <?php if(!empty($start_date && $end_date && $choose_country))
{
 print_r($choose_country); echo "  :  ";  print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($choose_country); echo "  :  "; print_r($start_date);
}
elseif(!empty($end_date))
{
 print_r($choose_country); echo "  :  "; print_r($end_date);
}
elseif(!empty($selected_month))
{
 print_r($choose_country); echo "  :  ";   echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($current_year);
}
else
{
 print_r($choose_country); echo "  :  "; print_r($current_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total qnty of each Item'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Top Customer:",
    colorByPoint: true,
    data: [
    <?php 
    foreach ($customerlist as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbr_customer.'",
           
              y: '.number_format((float)$val4->total_customercount, 2, '.', '').',
            drilldown: "'.$val4->sbr_customer.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($cat_prd as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.$val6['prd_qnty'].'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>



<script>
// Create the chart for item  product on country
Highcharts.chart('containcustomerlast', {
chart: {
type: 'column'
},
title: {
text: 'Browser Top Customer  for :  <?php if(!empty($start_date && $end_date && $choose_country))
{
 print_r($choose_country); echo "  :  ";  print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($choose_country); echo "  :  "; print_r($start_date);
}
elseif(!empty($end_date))
{
 print_r($choose_country); echo "  :  "; print_r($end_date);
}
elseif(!empty($selected_month))
{
 print_r($choose_country); echo "  :  ";   echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($current_year);
}
else
{
 print_r($choose_country); echo "  :  "; print_r($current_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total qnty of each Item'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Top Customer:",
    colorByPoint: true,
    data: [
    <?php 
    foreach ($customerlistprev as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbr_customer.'",
           
              y: '.number_format((float)$val4->total_customercount, 2, '.', '').',
            drilldown: "'.$val4->sbr_customer.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($cat_prd as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.$val6['prd_qnty'].'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>



























</html>