<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>


<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<style type="text/css">
.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Dashboard</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Dashboard</span></li>
<li><span>Sales Data</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-md-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Sort Table</h2>
</header>
<?php 
  echo form_open('submit_season_comparison');?>

<div class="panel-body">

<div class="row">
  <div class="col-sm-6">
  <div class="form-group">
  <label class="control-label" for="inputPlaceholder">Choose Season</label><br/>
    <select class="form-control mb-md bank month_name" name="season_selected" >
      <option value="">Choose</option>
      <option value="first_qurter" <?php if(!empty($season_selected)){if($season_selected=="first_qurter"){echo "selected";}};?>>First Quarter</option>
      <option value="sec_qurter" <?php if(!empty($season_selected)){if($season_selected=="sec_qurter"){echo "selected";}};?>>Second Quarter</option>
      <option value="third_qurter" <?php if(!empty($season_selected)){if($season_selected=="third_qurter"){echo "selected";}};?>>Third Quarter</option>
      <option value="fourth_qurter" <?php if(!empty($season_selected)){if($season_selected=="fourth_qurter"){echo "selected";}};?>>Fourth Quarter</option>
    </select>
  <div class="form_error">  </div>
  
  </div>
  </div>
  <div class="col-sm-6"> 
  <div class="form-group">
 
    
  </div>
  </div>
</div>


<!-- onclick="type_bank();" -->
</div>
<footer class="panel-footer">
<button class="btn btn-primary">Submit</button>
</footer>
<?php
echo form_close();?>
</section>
</div>
</div>



<div class="row">
<div class="col-lg-12">






<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Data Comparison</h2>
</header>
<div class="panel-body">
  <table class="table table-responsive table-bordered table-striped mb-none ">
   
  </table>

<table class="table table-responsive table-bordered table-striped mb-none " id="datatable-details">
  
     
<thead>
 

<tr>
 <th></th>
 
  <?php
  foreach($all_years as $c)
    {?>

 <th><?php echo $c;?></th>


<?php
}?>

</tr>
</thead>

<tbody>
   
      <tr><td><b>Fast Moving category</b></td> 
<?php
foreach($fast_moving as $index=>$fm)
{
  ?>
 <td><?php echo $fm[0]->sbp_ar_category;?></td>
  <?php
}
  ?>
      </tr>
      <tr><td><b>Total number of category selled</b></td> 
<?php
foreach($fast_moving as $index=>$fm)
{
  ?>
 <td><?php echo $fm[0]->total_cat;?></td>
  <?php
}
  ?>
      </tr>
     <!--  slow moving -->
  <tr><td><b>Slow Moving category</b></td> 
<?php
foreach($slow_moving as $index=>$sm)
{
  ?>
 <td><?php echo $sm[0]->sbp_ar_category;?></td>
  <?php
}
  ?>
      </tr>
      <tr><td><b>Total number of category selled</b></td> 
<?php
foreach($slow_moving as $index=>$sm)
{
  ?>
 <td><?php echo $sm[0]->total_cat;?></td>
  <?php
}
  ?>
      </tr>
   <!--   slow moving end -->
      <tr><td><b>Total amount achieved</b></td> 
<?php
foreach($all_data as $ad)
{
  ?>
 <td><?php echo number_format($ad->total_amount,2);?></td>
  <?php
}
  ?>
   </tr>
     <tr> <td><b>Percentage increase from previous year</b></td>
<?php
foreach($all_data as $index=>$ad)
{ 
  ?>
 <td><?php echo number_format($percentage_incerase[$index],2);?></td>
  <?php
}
  ?>
      </tr>

</tbody>
</table>


</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>


<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript">
</script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>



</html>