<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<style type="text/css">
.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Dashboard</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Dashboard</span></li>
<li><span>Sales Data</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>



<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Sales Data comparison</h2>
</header>
<div class="panel-body">

<div id="container1" style="min-width: 100%; height: 400px; margin: 0 auto"></div>



</div>
</section>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Product Sales per Category(for current year and previous year)</h2>
</header>
<div class="panel-body">

<div id="container2" style="min-width: 100%; height: 400px; margin: 0 auto"></div>

</div>
</section>

<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Drilldown data for classes and product code
  
  
  <span><a type="button" href="<?php echo base_url('submit_class_year_selected/2018');?>">2018</a></span> &nbsp;
  <span><a type="button" href="<?php echo base_url('submit_class_year_selected/2019');?>">2019</a></span> &nbsp;
  <span><a type="button" href="<?php echo base_url('submit_class_year_selected/2020');?>">2020</a></span> 
</header>
<div class="panel-body">

<div id="container3" style="min-width: 100%; height: 400px; margin: 0 auto"></div>


</div>
</section>



<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Grouped Data
  
  
  <span><a type="button" href="<?php echo base_url('submit_group_year_selected/2018');?>">2018</a></span> &nbsp;
  <span><a type="button" href="<?php echo base_url('submit_group_year_selected/2019');?>">2019</a></span> &nbsp;
  <span><a type="button" href="<?php echo base_url('submit_group_year_selected/2020');?>">2020</a></span> 
</header>
<div class="panel-body">

<div id="container4" style="min-width: 100%; height: 400px; margin: 0 auto"></div>


</div>
</section>


</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>


<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript">
</script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<script type="text/javascript">

$(document).ready(function()
    {
      $('#datatable-default3').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
         "pageLength": 25,
    responsive: true,
     "scrollX": true,
} );

      $month_selected=$('input[name="month_selected"]').val();
      $date_end=$('input[name="end_date_rng"]').val();
      $date_strt=$('input[name="start_date_rng"]').val();

      // if($month_selected=='' && $date_end=='' && $date_strt=='')
      // {
      //  window.location.href = 'sales-book-dashboard';
      // }

    } );
      
Highcharts.chart('container1', {
chart: {
type: 'column'
},
title: {
text: 'Last year and this year comparison'
},

xAxis: {
categories: [
    'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug',
    'Sep','Oct','Nov','Dec'
],
crosshair: true
},
yAxis: {
min: 0,
title: {
    text: 'Sales Income'
}
},
tooltip: {
headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    '<td style="padding:0"><b>{point.y:.1f} AED</b></td></tr>',
footerFormat: '</table>',
shared: true,
useHTML: true
},
plotOptions: {
column: {
    pointPadding: 0.2,
    borderWidth: 0
}
},
series: [
{
name: '<?php print_r($last_previous_year);?>',
data: [
<?php 
   foreach($months_last_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($previous_year);?>',
data: [
<?php 
   foreach($months_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

}, {
name: '<?php print_r($current_year);?>',
data: [
  <?php 
   foreach($months_curnt as $mc)
   {
    if(empty($mc))
      echo '0';
    else
      echo number_format((float)$mc, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>]//12 data,for all months

}]
});

Highcharts.chart('container2', {
chart: {
type: 'column'
},
title: {
text: 'Last year and this year comparison as per category'
},

xAxis: {
categories: [
<?php
foreach($all_category_comparison as $ac)
{
  if(!empty($ac))
  {
  //echo "'".$ac->sbp_ar_category."'";
  echo "'".$ac."'";
 }
  else{
     echo "'NUll'";
  }
echo ',';
}
  ?>  
],
crosshair: true
},
yAxis: {
min: 0,
title: {
    text: 'Category Sales Income'
}
},
tooltip: {
headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    '<td style="padding:0"><b>{point.y:.1f} AED</b></td></tr>',
footerFormat: '</table>',
shared: true,
useHTML: true
},
plotOptions: {
column: {
    pointPadding: 0.2,
    borderWidth: 0
}
},
series: [
{
name: '<?php print_r($last_previous_year);?>',
data: [

<?php 
   foreach($cat_amount_last_prev as $indx1=>$mp)
   {
      
    if(empty($mp[0]->total_amount))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($previous_year);?>',
data: [

<?php 
   foreach($cat_amount_prev as $indx1=>$mp)
   {
      
    if(empty($mp[0]->total_amount))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

}, {
name: '<?php print_r($current_year);?>',
data: [
  <?php 
   foreach($cat_amount_curnt as $indx2=>$mc)
   {
   $sum_cat2=array_sum($mc);
    foreach($all_category as $indx2=>$ac)
  {
    if($ac->pb_class==$indx2)
    {
    if(empty($mc))
      echo '0';
    else
      echo number_format((float)$sum_cat2, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
    }
   }
?>]//12 data,for all months

}]
});
</script>

<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>

<script>
// Create the chart
Highcharts.chart('container3', {
chart: {
type: 'column'
},
title: {
text: 'Browser purchase class drilldown by product code for <?php echo $year_selected;?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total count of each class'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Class",
    colorByPoint: true,
    data: [
    <?php 
   foreach($all_category_sales_purchase as $ac)
{
        echo '{
            name: "'.$ac[0]->pb_class.'",
            y: '.number_format((float)$ac[0]->total_amount, 2, '.', '').',
            drilldown: "'.$ac[0]->pb_class.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($prd_class_code as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
           if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.number_format((float)$val6['sum'], 2, '.', '').'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>

<script>
// Create the chart
Highcharts.chart('container4', {
chart: {
type: 'column'
},
title: {
text: 'Sales Vs purchase comparison for <?php echo $year_selected;?>'
},

xAxis: {
categories: [
<?php
foreach($all_category_comparison as $ac)
{
  if(!empty($ac))
  {
  //echo "'".$ac->sbp_ar_category."'";
  echo "'".$ac."'";
 }
  else{
     echo "'NUll'";
  }
echo ',';
}
  ?>  
],
crosshair: true
},
yAxis: {
min: 0,
title: {
    text: 'Category Sales Income'
}
},
tooltip: {
headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    '<td style="padding:0"><b>{point.y:.1f} AED</b></td></tr>',
footerFormat: '</table>',
shared: true,
useHTML: true
},
 plotOptions: {
    series: {
        borderWidth: 0,
        dataLabels: {
            enabled: true
        }
    },
    column: {
        dataLabels: {
            formatter: function()
            {   
                var firstColumnValue = this.y;
                var secondColumnValue = this.series.chart.series[1].yData[this.point.index];
                var yourCalculation = (firstColumnValue - secondColumnValue) / firstColumnValue * 100;
                return yourCalculation.toFixed(2) + '%';
            }
        }
    }
},
series: [
{
name: 'Sales',
data: [

<?php 
   foreach($total_sales_cat as $indx1=>$mp)
   {
      $total_amount=array_sum($mp);
    if(empty($total_amount))
      echo '0';
    else
      echo number_format((float)$total_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

},
{
name: 'Purchase',
data: [

<?php 
   foreach($all_category_sales_purchase as $indx1=>$mp)
   {
      
    if(empty($mp[0]->total_amount))
      echo '0';
    else
    echo number_format((float)$mp[0]->total_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

}]
});
</script>


</html>