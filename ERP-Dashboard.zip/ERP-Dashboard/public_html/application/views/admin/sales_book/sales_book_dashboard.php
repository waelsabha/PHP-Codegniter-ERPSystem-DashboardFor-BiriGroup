<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>
<?php
//$this->session->unset_userdata('prd_info');
//print_r($this->session->userdata['prd_info']);
if (!empty($this->session->userdata('prd_info'))) {
insert_prd_sales_vochuer();
}

?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>
<style type="text/css">
.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Dashboard</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Dashboard</span></li>
<li><span>Sales Data</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-md-12">
<section class="panel">
<header class="panel-heading">

<a href="https://mybusiness.googleapis.com/v4/accounts/{accountId}/locations/{locationId}/reviews"></a>

<h2 class="panel-title">Sort Table</h2>
</header>
<?php 
  echo form_open('submit_date_range_sales_book');?>

<div class="panel-body">

<div class="row">
  <div class="col-sm-6">
  <div class="form-group">
  <label class="control-label" for="inputPlaceholder">Choose Month</label><br/>
    <select class="form-control mb-md bank month_name" name="month_selected" >
      <option value="">Choose</option>
      <option value="01" >Jan</option>

      <option value="02" >Feb</option>

      <option value="03" >Mar</option>

      <option value="04" >Apr</option>

      <option value="05" >May</option>

      <option value="06" >Jun</option>

      <option value="07" >Jul</option>

      <option value="08" >Aug</option>

      <option value="09" >Sep</option>

      <option value="10" >Oct</option>

      <option value="11" >Nov</option>

      <option value="12" >Dec</option>
    </select>
  <div class="form_error">  </div>
  
  </div>
  </div>
  <div class="col-sm-6"> 
  <div class="form-group">
  <label class="control-label" for="inputPlaceholder"> OR Choose Date-range</label><br/>
   <div class="input-daterange input-group" data-plugin-datepicker="">
    <span class="input-group-addon">
    <i class="fa fa-calendar"></i>
    </span>
    <input type="text" class="form-control" name="start_date_rng">
    <span class="input-group-addon">to</span>
    <input type="text" class="form-control" name="end_date_rng">
</div>
    
  </div>
  </div>
</div>


<!-- onclick="type_bank();" -->
</div>
<footer class="panel-footer">
<button class="btn btn-primary">Submit</button>
</footer>
<?php
echo form_close();?>
</section>
</div>
</div>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Total Sales Data comparison</h2>
</header>
<div class="panel-body">
<div id="container0" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
</div>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Sales Data comparison</h2>
</header>
<div class="panel-body">
<div id="container1" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>

<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Product Sales per Category(for current year and previous year)</h2>
</header>
<div class="panel-body">
<div id="container6" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>

<div class="row">
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Sales Data per region 2021
  <a class="mb-xs mt-xs mr-xs btn btn-default pull-right" data-toggle="modal" data-target="#modalBootstrap21">View table</a>
</h2>
</header>

<div class="panel-body">
<div id="container222" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>

<div class="modal fade" id="modalBootstrap21" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
<h4 class="modal-title" id="myModalLabel">Table data</h4>
</div>
<div class="modal-body">
  <table class="table table-bordered">
    <thead>
      <th>Country</th>
       <th>Amount</th>
    </thead>
 <?php
    if(!empty($country_table_data_last_year))
    {

        foreach($country_table_data_last_year as $index=>$cn)
        {
         if(!empty($cn))
           {
          
         ?>
            <tr>
             <td><?php echo $index;?></td>
           <td><?php echo number_format((float)$cn, 2, '.', '');?></td>
        </tr>
            <?php
        }
      }
      

    }
    ;?>
   </table>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
</section>
</div>
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Sales Data per region
  <a class="mb-xs mt-xs mr-xs btn btn-default pull-right" data-toggle="modal" data-target="#modalBootstrap22">View table</a>
</h2>
</header>

<div class="panel-body">
<div id="container2" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>

<div class="modal fade" id="modalBootstrap22" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
<h4 class="modal-title" id="myModalLabel">Table data</h4>
</div>
<div class="modal-body">
  <table class="table table-bordered">
    <thead>
      <th>Country</th>
       <th>Amount</th>
    </thead>
 <?php
    if(!empty($country_table_data))
    {

        foreach($country_table_data as $index=>$cn)
        {
         if(!empty($cn))
           {
          
         ?>
            <tr>
             <td><?php echo $index;?></td>
           <td><?php echo number_format((float)$cn, 2, '.', '');?></td>
        </tr>
            <?php
        }
      }
      

    }
    ;?>
   </table>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
</section>
</div>
</div>

<div class="row">
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Report based on Branch wise Sales(for <?php echo $previous_year;?>) </h2>
</header>
<div class="panel-body">
<div id="container555" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Report based on Branch wise Sales(for <?php echo $current_year;?>) </h2>
</header>
<div class="panel-body">
<div id="container5" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
</div>

<div class="row">

<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Report based on Sales Type (for <?php echo $previous_year;?>)</h2>
</header>
<div class="panel-body">
<?php
$colors=array('bg-primary','bg-secondary','bg-tertiary','bg-quartenary');
foreach($type_sales_last_year as $ind=>$ts)
{
?>  
<div class="col-md-12 col-xl-12">
<section class="panel">
<div class="panel-body <?php echo $colors[$ind];?>">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $ts[0]->sbr_acc_to;?></h4>
<div class="info">
<strong class="amount" id="sales"><?php echo 
number_format((float)$ts[0]->total_amount, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<?php
}?> 
</div>
</section>
</div>
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Report based on Sales Type (for <?php echo $current_year;?>)</h2>
</header>
<div class="panel-body">
<?php
$colors=array('bg-primary','bg-secondary','bg-tertiary','bg-quartenary');
foreach($type_sales as $ind=>$ts)
{
?>  
<div class="col-md-12 col-xl-12">
<section class="panel">
<div class="panel-body <?php echo $colors[$ind];?>">
<div class="widget-summary widget-summary-sm">
<div class="widget-summary-col widget-summary-col-icon">
<div class="summary-icon">
<i class="fa  fa-money"></i>
</div>
</div>
<div class="widget-summary-col">
<div class="summary">
<h4 class="title"><?php echo $ts[0]->sbr_acc_to;?></h4>
<div class="info">
<strong class="amount" id="sales"><?php echo 
number_format((float)$ts[0]->total_amount, 2, '.', '');?></strong>
</div>
</div>

</div>
</div>
</div>
</section>
</div>
<?php
}?> 
</div>
</section>
</div>
</div>

<div class="row">
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Salesperson wise sales(for <?php echo $previous_year;?>) </h2>
</header>
<div class="panel-body">
<div id="container333" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>

<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Salesperson wise sales (for <?php echo $current_year;?>)</h2>
</header>
<div class="panel-body">
<div id="container3" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
</div>


<div class="row">
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Product Sales per Category(for <?php echo $previous_year;?>)</h2>
</header>
<div class="panel-body">
<div id="container444" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
<div class="col-md-6">
<section class="panel">
<header class="panel-heading">
<h2 class="panel-title">Product Sales per Category(for <?php echo $current_year;?>)</h2>
</header>
<div class="panel-body">
<div id="container4" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
</div>
</section>
</div>
</div>

<?php
$result_test=array();
$total_prds=0;
$calc_sum=[];
$k=0;
$gross_sum=[];
if(!empty($cat_prd))
{
foreach($cat_prd as $index=>$element)
{
  //sort($r['sum']);
   arsort($element);
$avg_prd_price=0;
  $total_cat_count=count($index);
  $total_prds=count($element);
$avg_cat_price=0;$total_prd_sum=0;$total_prd_qnty=0;

  foreach($element as $b1=>$r)
  {
if(empty($r['prd_code'])){$code_prd="NULL";}else{$code_prd=$r['prd_code'];}
    //$gross_sum[]=$r['sum'];
    //  $sort_array=arsort($element);
   $total_prd_sum=$total_prd_sum+$r['sum'];
   $total_prd_qnty=$total_prd_qnty+$r['prd_qnty'];

  $avg_prd_price=($r['sum']/$r['prd_qnty']);
$avg_cat_price=($total_prd_sum/$total_prd_qnty);
  
  
    if(!array_key_exists($index,$result_test)){
        // Add new data in array with ACCOUNT_NUMBER as an index
        $result_test[$index][$index][$index][$index][$index]['total_count_cat']= $total_cat_count;
        $result_test[$index][$index][$index][$index][$index]['total_count_prd']= $total_prds;
        $result_test[$index][$index][$index][$index][$index]['total_prd_qty']= $total_prd_qnty;
        $result_test[$index][$index][$index][$index][$index]['total_prd_sum']= $total_prd_sum;
        $result_test[$index][$index][$index][$index][$index]['cat_avg_price']= $avg_cat_price;

        $result_test[$index][$index][$index][$index][$index]['prd_code']= $code_prd;
        $result_test[$index][$index][$index][$index][$index]['prd_qnty']= $r['prd_qnty'];
        $result_test[$index][$index][$index][$index][$index]['prd_sum']= $r['sum'];
        $result_test[$index][$index][$index][$index][$index]['prd_avg_price']= number_format((float)$avg_prd_price, 2, '.', '');

    }else
    {
      $result_test[$index][$index][$index][$index][$index]['total_prd_qty'].=",". $total_prd_qnty;
      $result_test[$index][$index][$index][$index][$index]['total_prd_sum'].=",". $total_prd_sum;
      $result_test[$index][$index][$index][$index][$index]['cat_avg_price'].=",". $avg_cat_price;
        // Only alter category index
       $result_test[$index][$index][$index][$index][$index]['prd_code'] .=",".$code_prd; 
      $result_test[$index][$index][$index][$index][$index]['prd_qnty'].=",".$r['prd_qnty'];  
      $result_test[$index][$index][$index][$index][$index]['prd_sum'].=",".$r['sum'];
       $result_test[$index][$index][$index][$index][$index]['prd_avg_price'].=",".number_format((float)$avg_prd_price, 2, '.', '');
    }
  }
  $total_prd_qnty=0;
  $avg_prd_price=0;
  $total_prd_sum=0;
 $avg_cat_price=0;
}
}
?>

<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Data table view for category Vs Products</h2>
</header>
<div class="panel-body">
<table class="table table-responsive table-bordered table-striped mb-none " id="datatable-details2">
<thead>
<tr>
<th></th>
 <th>Category</th>

<th style="display: none;">Item code</th>
<th style="display: none;">Quantity</th>
<th style="display: none;">Amount</th>
<th style="display: none;">Avg. Sales Price</th>

<th>Total no. Products</th>
<th>Sum of Prd Qnty</th>
<th>Sum of Prd Amount</th>
<th>Avg. Sales Price</th>
</tr>
</thead>
<tbody>
<?php
$i=1;
$total_prds=0;
$calc_sum=[];
foreach ($result_test as $key2=>$index2) 
{

  $xpl1 =explode(",",$index2[$key2][$key2][$key2][$key2]['prd_code']);
    $n_category1 = "";$n_category1_test="";
    foreach($xpl1 as $b1 => $a1){
      $prd_code[]=$a1;
      $n_category1 .= ($b1!=0) ? "<hr/>".$a1 : $a1 ;//amount
    }

    $xpl2 = explode(",",$index2[$key2][$key2][$key2][$key2]['prd_qnty']);
    $n_category2 = "";$n_category2_test="";
    foreach($xpl2 as $b2 => $a2){
      $prd_qnty[]=$a2;
    //$word_limited2= str_pad($a2,26);
     $n_category2 .= ($b2!=0) ? "<hr/>".$a2 : $a2 ; //type
    }

   $xpl3 = explode(",",$index2[$key2][$key2][$key2][$key2]['prd_sum']);
    $n_category3 = "";
    foreach($xpl3 as $b3 => $a3){
     $n_category3 .= ($b3!=0) ? "<hr/>".$a3 : $a3; //desc
    }

    $xpl4 = explode(",",$index2[$key2][$key2][$key2][$key2]['prd_avg_price']);
    $n_category4 = "";$n_category4_test="";
  foreach($xpl4 as $b4 => $a4)
  {
    $n_category4 .= ($b4!=0) ? "<hr/>".$a4 : $a4 ; //bank
  }

    $xpl5 = explode(",",$index2[$key2][$key2][$key2][$key2]['total_prd_qty']);
    $total_prd_qty=end($xpl5);

    $xpl6 = explode(",",$index2[$key2][$key2][$key2][$key2]['total_prd_sum']);
    $total_prd_sum=end($xpl6);

    $xpl7 = explode(",",$index2[$key2][$key2][$key2][$key2]['cat_avg_price']);
    $cat_avg_price=end($xpl7);

    $xpl8 = explode(",",$index2[$key2][$key2][$key2][$key2]['total_count_prd']);
    $total_count_prd=end($xpl8);

  ?>
<tr>
  <td><?php echo $i++;?></td>
  <td><?php echo $key2;?></td>

  <td style="display: none;"><?php echo $n_category1;?></td><!--code-->
  <td style="display: none;"><?php echo $n_category2;?></td><!--qnty-->
  <td style="display: none;"><?php echo $n_category3;?></td><!--sum-->
  <td style="display: none;"><?php echo $n_category4;?></td><!--avg price-->

  <td><?php echo number_format((float)$total_count_prd, 2, '.', '');?></td>
  <td><?php echo number_format((float)$total_prd_qty, 2, '.', '');?></td>
  <td><?php echo number_format((float)$total_prd_sum, 2, '.', '');?></td>
  <td><?php echo number_format((float)$cat_avg_price, 2, '.', '');?></td>
</tr>
<?php
}
?>
</tbody>
</table>


</div>
</section>

</div>
</div>


</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>


<script src="<?php echo base_url('admin_assets/');?>javascripts/dashboard/examples.dashboard.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript">
</script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<script type="text/javascript">

$(document).ready(function()
    {
      $('#datatable-default3').DataTable( {
              rowReorder: {
            selector: 'td:nth-child(2)'
        },
         "pageLength": 25,
    responsive: true,
     "scrollX": true,
} );

      $month_selected=$('input[name="month_selected"]').val();
      $date_end=$('input[name="end_date_rng"]').val();
      $date_strt=$('input[name="start_date_rng"]').val();

      // if($month_selected=='' && $date_end=='' && $date_strt=='')
      // {
      //  window.location.href = 'sales-book-dashboard';
      // }

    } );
    Highcharts.chart('container0', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Total Sales Comparison'
    },
    
    xAxis: {
        type: 'category',
        labels: {
            rotation: -45,
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Sales Comparison(millions)'
        }
    },
    legend: {
        enabled: false
    },
    tooltip: {
        pointFormat: 'Total Sales : <b>{point.y:.1f} millions</b>'
    },
    series: [{
        name: 'Sales',
        colorByPoint: true,
        data: [
        <?php 
foreach($total_sales_all_years as $tsy)
{
?>
            ['<?php echo $tsy->sbr_voc_year;?>', <?php echo number_format((float)$tsy->total_amount, 2, '.', '');?>],
            <?php
            }?>
          
        ],
        dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y:.1f}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    }]
});
      
Highcharts.chart('container1', {
chart: {
type: 'column'
},
title: {
text: 'Last year and this year comparison'
},

xAxis: {
categories: [
    'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug',
    'Sep','Oct','Nov','Dec'
],
crosshair: true
},
yAxis: {
min: 0,
title: {
    text: 'Sales Income'
}
},
tooltip: {
headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    '<td style="padding:0"><b>{point.y:.1f} AED</b></td></tr>',
footerFormat: '</table>',
shared: true,
useHTML: true
},
plotOptions: {
column: {
    pointPadding: 0.2,
    borderWidth: 0
}
},
 series: [

{
name: '<?php print_r($last_last_last_prev_yr_fifth);?>',
data: [
<?php 
   foreach($months_last_last_last_prev_fifth as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

},

{
name: '<?php print_r($last_last_last_prev_yr);?>',
data: [
<?php 
   foreach($months_last_last_last_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

},

{
name: '<?php print_r($last_last_prev_yr);?>',
data: [
<?php 
   foreach($months_last_last_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($last_previous_year);?>',
data: [
<?php 
   foreach($months_last_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($previous_year);?>',
data: [
<?php 
   foreach($months_prev as $mp)
   {
    if(empty($mp))
      echo '0';
    else
      echo number_format((float)$mp, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>
]//12 data,for all months

}, {
name: '<?php print_r($current_year);?>',
data: [
  <?php 
   foreach($months_curnt as $mc)
   {
    if(empty($mc))
      echo '0';
    else
      echo number_format((float)$mc, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
?>]//12 data,for all months

}]
});

Highcharts.chart('container6', {
chart: {
type: 'column'
},
title: {
text: 'Last year and this year comparison as per category'
},

xAxis: {
categories: [
<?php
foreach($all_category_comparison as $ac)
{
  if(!empty($ac))
  {
  //echo "'".$ac->sbp_ar_category."'";
  echo "'".$ac."'";
  echo ',';
  }
}
  ?>  
],
crosshair: true
},
yAxis: {
min: 0,
title: {
    text: 'Category Sales Income'
}
},
tooltip: {
headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    '<td style="padding:0"><b>{point.y:.1f} AED</b></td></tr>',
footerFormat: '</table>',
shared: true,
useHTML: true
},
plotOptions: {
column: {
    pointPadding: 0.2,
    borderWidth: 0
}
},
series: [


{
name: '<?php print_r($last_last_last_prev_yr_fifth);?>',
data: [

<?php 
   foreach($cat_amount_last_last_last_fifth as $indx1=>$mp)
   {
      
    if(empty($mp[0]->sbp_ar_category))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_gross_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

},


{
name: '<?php print_r($last_last_prev_yr);?>',
data: [

<?php 
   foreach($cat_amount_last_last_prev as $indx1=>$mp)
   {
      
    if(empty($mp[0]->sbp_ar_category))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_gross_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($last_previous_year);?>',
data: [

<?php 
   foreach($cat_amount_last_prev as $indx1=>$mp)
   {
      
    if(empty($mp[0]->sbp_ar_category))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_gross_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

},
{
name: '<?php print_r($previous_year);?>',
data: [

<?php 
   foreach($cat_amount_prev as $indx1=>$mp)
   {
      
    if(empty($mp[0]->sbp_ar_category))
      echo '0';
    else
      echo number_format((float)$mp[0]->total_gross_amount, 2, '.', '');
    echo ',';
   // print_r($mp); 
   }
?>
]//12 data,for all months

}, {
name: '<?php print_r($current_year);?>',
data: [
  <?php 
   foreach($cat_amount_curnt as $indx2=>$mc)
   {
   $sum_cat2=array_sum($mc);
    foreach($all_category as $indx2=>$ac)
  {
    if($ac->sbp_ar_category==$indx2)
    {
    if(empty($mc))
      echo '0';
    else
      echo number_format((float)$sum_cat2, 2, '.', '');
    echo ',';
   // print_r($mp);
   }
    }
   }
?>]//12 data,for all months

}]
});
</script>


<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>

<script type="text/javascript">
Highcharts.chart('container2', {
chart: {
plotBackgroundColor: null,
plotBorderWidth: null,
plotShadow: false,
type: 'pie'
},
title: {
text: 'Country wise sales in <?php if(!empty($start_date && $end_date))
{
print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($start_date);
}
elseif(!empty($end_date))
{
print_r($end_date);
}
elseif(!empty($selected_month))
{
echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($current_year);
}
else
{
print_r($current_year);
}
?>'
},
tooltip: {
pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
},
plotOptions: {
pie: {
    allowPointSelect: true,
    cursor: 'pointer',
    dataLabels: {
        enabled: true,
        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
    }
}
},
exporting: {
    buttons: {
        contextButton: {
            enabled: false
        }
    }
},
series: [
{
    name: "Sales",
    colorByPoint: true,
    data: [
    <?php
    if(!empty($city_name))
    {
      foreach($city_name as $index=>$cn)
        {
           if(!empty($cn))
           {
            
        echo "{
            name: '".$cn."',
             y: ".number_format((float)$total[$index], 2, '.', '').",
              drilldown: '".$cn."'
           
        }";
        echo ",";   
        }
      }
    }
    ;?>
        
    ]
}
],
drilldown: {
series: [
    {
        name: "UAE",
        id: "UAE",
        data: 
        [
        <?php
        foreach($branch_name as $indx2=>$bn)
        {
            echo '[
                "'.$bn.'",
                '.number_format((float)$branch_total[$indx2], 2, '.', '').'
            ],';
            
        }?>   
        ]
      },
      {
        name: "KSA",
        id: "KSA",
        data: 
        [
        <?php
        foreach($ksa_branch_name as $indx2=>$bn)
        {
            echo '[
                "'.$bn.'",
                '.number_format((float)$ksa_branch_total[$indx2], 2, '.', '').'
            ],';
            
        }?>   
        ],

    },


        {
        name: "UK",
        id: "UK",
        data: 
        [
        <?php
        foreach($uk_branch_name as $indx2=>$bn)
        {
            echo '[
                "'.$bn.'",
                '.number_format((float)$uk_branch_total[$indx2], 2, '.', '').'
            ],';
            
        }?>   
        ],

    }
   
]
}
});

</script>

<script type="text/javascript">
Highcharts.chart('container222', {
chart: {
plotBackgroundColor: null,
plotBorderWidth: null,
plotShadow: false,
type: 'pie'
},
title: {
text: 'Country wise sales in <?php if(!empty($start_date && $end_date))
{
print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($start_date);
}
elseif(!empty($end_date))
{
print_r($end_date);
}
elseif(!empty($selected_month))
{
echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($previous_year);
}
else
{
print_r($previous_year);
}
?>'
},
tooltip: {
pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
},
plotOptions: {
pie: {
    allowPointSelect: true,
    cursor: 'pointer',
    dataLabels: {
        enabled: true,
        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
    }
}
},
exporting: {
    buttons: {
        contextButton: {
            enabled: false
        }
    }
},
series: [
{
    name: "Sales",
    colorByPoint: true,
    data: [
    <?php
    if(!empty($city_name_last_year))
    {
      foreach($city_name_last_year as $index=>$cn)
        {
           if(!empty($cn))
           {
            
        echo "{
            name: '".$cn."',
             y: ".number_format((float)$total_last_year[$index], 2, '.', '').",
              drilldown: '".$cn."'
           
        }";
        echo ",";   
        }
      }
    }
    ;?>
        
    ]
}
],
drilldown: {
series: [
    {
        name: "UAE",
        id: "UAE",
        data: 
        [
        <?php
        foreach($branch_name_last_year as $indx2=>$bn)
        {
            echo '[
                "'.$bn.'",
                '.number_format((float)$branch_total_last_year[$indx2], 2, '.', '').'
            ],';
            
        }?>   
        ]
      },
      {
        name: "KSA",
        id: "KSA",
        data: 
        [
        <?php
        foreach($ksa_branch_name_last_year as $indx2=>$bn)
        {
            echo '[
                "'.$bn.'",
                '.number_format((float)$ksa_branch_total_last_year[$indx2], 2, '.', '').'
            ],';
            
        }?>   
        ],

    },
     {
        name: "UK",
        id: "UK",
        data: 
        [
        <?php
        foreach($uk_branch_name_last_year as $indx2=>$bn)
        {
            echo '[
                "'.$bn.'",
                '.number_format((float)$uk_branch_total_last_year[$indx2], 2, '.', '').'
            ],';
            
        }?>   
        ],

    }
   
]
}
});

</script>

<script>
// Create the chart
Highcharts.chart('container4', {
chart: {
type: 'column'
},
title: {
text: 'Browser products selled in each category for the year <?php if(!empty($start_date && $end_date))
{
print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($start_date);
}
elseif(!empty($end_date))
{
print_r($end_date);
}
elseif(!empty($selected_month))
{
echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($current_year);
}
else
{
print_r($current_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total count of each category'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Categories",
    colorByPoint: true,
    data: [
    <?php 
    foreach ($all_category as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbp_ar_category.'",
            y: '.number_format((float)$val4->total_gross_amount, 2, '.', '').',
            drilldown: "'.$val4->sbp_ar_category.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($cat_prd as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.number_format((float)$val6['sum'], 2, '.', '').'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>

<script>
// Create the chart
Highcharts.chart('container444', {
chart: {
type: 'column'
},
title: {
text: 'Browser products selled in each category for the year <?php if(!empty($start_date && $end_date))
{
print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($start_date);
}
elseif(!empty($end_date))
{
print_r($end_date);
}
elseif(!empty($selected_month))
{
echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($previous_year);
}
else
{
print_r($previous_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total count of each category'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Categories",
    colorByPoint: true,
    data: [
    <?php 
    foreach ($all_category_last_year as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbp_ar_category.'",
            y: '.number_format((float)$val4->total_gross_amount, 2, '.', '').',
            drilldown: "'.$val4->sbp_ar_category.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($cat_prd_last_year as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.number_format((float)$val6['sum'], 2, '.', '').'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>

<script>
// Create the chart
Highcharts.chart('container3', {
chart: {
type: 'column'
},
title: {
text: 'Browser products selled by each salesperson for the year <?php if(!empty($start_date && $end_date))
{
print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($start_date);
}
elseif(!empty($end_date))
{
print_r($end_date);
}
elseif(!empty($selected_month))
{
echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($current_year);
}
else
{
print_r($current_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total sum of each prd'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Salesperson",
    colorByPoint: true,
    data: [
    <?php 
    foreach ($salesman as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbr_salesman.'",
            y: '.number_format((float)$val4->total_gross_amount, 2, '.', '').',
            drilldown: "'.$val4->sbr_salesman.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($sp_prd as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.number_format((float)$val6['sum'], 2, '.', '').'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>

<script>
// Create the chart
Highcharts.chart('container333', {
chart: {
type: 'column'
},
title: {
text: 'Browser products selled by each salesperson for the year <?php if(!empty($start_date && $end_date))
{
print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($start_date);
}
elseif(!empty($end_date))
{
print_r($end_date);
}
elseif(!empty($selected_month))
{
echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($previous_year);
}
else
{
print_r($previous_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total sum of each prd'
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Salesperson",
    colorByPoint: true,
    data: [
    <?php 
    foreach ($salesman_last_year as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbr_salesman.'",
            y: '.number_format((float)$val4->total_gross_amount, 2, '.', '').',
            drilldown: "'.$val4->sbr_salesman.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($sp_prd_last_year as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.number_format((float)$val6['sum'], 2, '.', '').'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>

<script>
// Create the chart
Highcharts.chart('container5', {
chart: {
type: 'column'
},
title: {
text: 'Browser products selled by each branch for the year <?php if(!empty($start_date && $end_date))
{
print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($start_date);
}
elseif(!empty($end_date))
{
print_r($end_date);
}
elseif(!empty($selected_month))
{
echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($current_year);
}
else
{
print_r($current_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total sum of each prd '
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Branch",
    colorByPoint: true,
    data: [
    <?php 
    foreach ($sort_branch as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbr_branch.'",
            y: '.number_format((float)$val4->total_gross_amount, 2, '.', '').',
            drilldown: "'.$val4->sbr_branch.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($brnch_prd as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.number_format((float)$val6['sum'], 2, '.', '').'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>

<script>
// Create the chart
Highcharts.chart('container555', {
chart: {
type: 'column'
},
title: {
text: 'Browser products selled by each branch for the year <?php if(!empty($start_date && $end_date))
{
print_r($start_date); echo " to "; print_r($end_date);
}
elseif(!empty($start_date))
{
print_r($start_date);
}
elseif(!empty($end_date))
{
print_r($end_date);
}
elseif(!empty($selected_month))
{
echo "for the month of ";print_r($selected_month); echo " for the year "; print_r($previous_year);
}
else
{
print_r($previous_year);
}
?>'
},
subtitle: {
text: 'Click the columns to view details.'
},
xAxis: {
type: 'category'
},
yAxis: {
title: {
    text: 'Total sum of each prd '
}

},
legend: {
enabled: false
},
plotOptions: {
series: {
    borderWidth: 0,
    dataLabels: {
        enabled: true,
        format: '{point.y:.1f}'
    }
}
},

tooltip: {
headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
},

series: [
{
    name: "Branch",
    colorByPoint: true,
    data: [
    <?php 
    foreach ($sort_branch_last_year as $indx4=>$val4) {
        echo '{
            name: "'.$val4->sbr_branch.'",
            y: '.number_format((float)$val4->total_gross_amount, 2, '.', '').',
            drilldown: "'.$val4->sbr_branch.'"
        },';
    }
    ?>
    ]
}
],
drilldown: {
series: [
<?php
foreach ($brnch_prd_last_year as $indx4=>$val_cat) 
{
    $sort_array=arsort($val_cat);
   echo '{
    name: "'.$indx4.'",
    id: "'.$indx4.'",
        data: [';
        
        foreach($val_cat as $indx6=>$val6)
        {
         if(empty($val6['prd_code'])){$code_prd='NULL';}else{$code_prd=$val6['prd_code'];}
        echo 
        '[
           "'.$code_prd.'",
            '.number_format((float)$val6['sum'], 2, '.', '').'
        ]';
        echo ",";
        }
       echo ']
    },';
   
}
   ?>

]
}
});
</script>
</html>