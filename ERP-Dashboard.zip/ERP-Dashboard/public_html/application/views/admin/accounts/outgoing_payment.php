<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" rel="stylesheet"  type='text/css'>


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
.countrypicker{
	max-height:100px;
}
.fa-whatsapp  {
  color:#fff;
  background:
  linear-gradient(#25d366,#25d366)10px 84%/15px 15px no-repeat,
  radial-gradient(#25d366 59%,transparent 0);
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">	

<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Outgoing payment</h2>
</header>
<div class="panel-body">
	<?php echo form_open_multipart('submit_outgoing_payment','class="form-horizontal form-bordered"');?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>
    <p class="required"> Fields marked as '::*::' are required fields</p>

   
<div class="row">
	<div class="col-md-12 table-rows-border">

<div class="col-md-12 col-sm-12"> 
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder"> Choose type<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type="radio" name="chose_type" value="1">Customer
  <input type="radio" name="chose_type" value="2">Accounts
  <input type="radio" name="chose_type" value="3">Supplier

  <div class="form_error">  <?php echo $this->session->flashdata('sup_name');?></div>
</div> 
</div>
</div>
</div>


<div class="col-md-12 table-rows-border">
<div class="col-md-6 col-sm-12">
  <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">  Select <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<select class="form-control customer_details" name="customer_details" style="display: none">
  <?php
  foreach($customer as $c)
  {
  ?>
    <option value="<?php echo $c->ac_id;?>"><?php echo $c->ac_name;?></option>
  <?php 
  }
  ?>
</select>
<select class="form-control supplier_details" name="supplier_details" style="display: none;">
  <?php
  foreach($suppliers as $s)
  {
  ?>
 <option value="<?php echo $s->as_id;?>"><?php echo $s->as_supplier_name;?></option>
  <?php 
  }
  ?>
</select>
<select class="form-control accounts_details" name="accounts_details" style="display: none;">
  <option value="0" >Root</option>  
<?php

if(!empty($accounts))
{
  foreach($accounts as $r)
  {
    $sql="SELECT * from account_tree_parent where par_root=".$r->root_id." ";
    $qry1=$this->db->query($sql);
    $qry1_result=$qry1->result();
    ?>
  <option class="root_val" value="<?php echo 'root_val:'.$r->root_id;?>"  ><b><?php echo $r->root_name.'('.$r->root_code.')';?></b></option>
  <?php
  if(!empty($qry1_result))
    {
  foreach($qry1_result as $q1)
  {
  ?>
  <option class="parent_val" value="<?php echo 'root_val:'.$r->root_id.'::'.'parent_val:'.$q1->par_id;?>" >&nbsp;-&nbsp;<?php echo $q1->par_name.'('.$q1->par_ac_code.')';?></option>
    <?php   
      
  $sql2="SELECT * from account_tree_child where ch_root='".$r->root_id."' AND ch_imd_parnt='".$q1->par_id."' AND ch_sts='1' ";
      $qry2=$this->db->query($sql2);
      $qry2_result=$qry2->result();
if(!empty($qry2_result))
  {
  foreach($qry2_result as $q2)
    {
      
      ?>
  <option class="child_val" value="<?php echo 'root_val:'.$q2->ch_root.'::'.'parent_val:'.$q2->ch_imd_parnt.'::'.'child_val:'.$q2->ch_id;?>" >&nbsp;&nbsp;-&nbsp;<?php echo $q2->ch_name.'('.$q2->ch_code.')';?></option>
    <?php
    $sql3="SELECT * from account_tree_sibling where sib_root='".$q2->ch_root."' AND sib_parnt='".$q2->ch_imd_parnt."' AND sib_child='".$q2->ch_id."' AND sib_sts='1' AND sib_1!='' ";
      $qry3=$this->db->query($sql3);
      $qry3_result=$qry3->result();

  if(!empty($qry3_result))
    {
    foreach($qry3_result as $q3)
    {
    
    ?>
  <option class="sibling_val1" value="<?php echo 'root_val:'.$q3->sib_root.'::'.'parent_val:'.$q3->sib_parnt.'::'.'child_val:'.$q3->sib_child.'::'.'sib_1_val:'.$q3->sib_id;?>" >
        &nbsp;&nbsp;&nbsp;-&nbsp;<?php echo $q3->sib_1.'('.$q3->sib_code.')';?></option><!--upto here correct-->
  <?php
    
  $sql4="SELECT * from account_tree_sibling2 where sib_root='".$q3->sib_root."' AND sib_parnt='".$q3->sib_parnt."' AND sib_child='".$q3->sib_child."' AND sib_sts='1' AND sib_1='".$q3->sib_id."' ";
    $qry4=$this->db->query($sql4);
    $qry4_result=$qry4->result();
  if(!empty($qry4_result))
  { 
  foreach($qry4_result as $q4)
  {
  
  ?>
  <option class="sibling_val2" value="<?php echo 'root_val:'.$q4->sib_root.'::'.'parent_val:'.$q4->sib_parnt.'::'.'child_val:'.$q4->sib_child.'::'.'sib_1_val:'.$q4->sib_1.'::'.'sib_2_val:'.$q4->sib_id;?>" >&nbsp;&nbsp;-&nbsp;<?php echo $q4->sib_2.'('.$q4->sib_code.')';?></option>
  <?php
  
  $sql5="SELECT * from account_tree_sibling3 where sib_root='".$q4->sib_root."' AND sib_parnt='".$q4->sib_parnt."' AND sib_child='".$q4->sib_child."' AND sib_sts='1' AND sib_1='".$q4->sib_1."' AND sib_2='".$q4->sib_id."' ";
    $qry5=$this->db->query($sql5);
    $qry5_result=$qry5->result();
  if(!empty($qry5_result))
  {
  foreach($qry5_result as $q5)
  { 
  
  ?>
  <option class="sibling_val3" value="<?php echo 'root_val:'.$q5->sib_root.'::'.'parent_val:'.$q5->sib_parnt.'::'.'child_val:'.$q5->sib_child.'::'.'sib_1_val:'.$q5->sib_1.'::'.'sib_2_val:'.$q5->sib_2.'::'.'sib_3_val:'.$q5->sib_id;?>" >&nbsp;&nbsp;-&nbsp;<?php echo $q5->sib_3.'('.$q5->sib_code.')';?></option>
  <?php
  
  $sql6="SELECT * from account_tree_sibling4 where sib_root='".$q5->sib_root."' AND sib_parnt='".$q5->sib_parnt."' AND sib_child='".$q5->sib_child."' AND sib_sts='1' AND sib_1='".$q5->sib_1."' AND sib_2='".$q5->sib_2."' AND sib_3='".$q5->sib_id."' ";
    $qry6=$this->db->query($sql6);
    $qry6_result=$qry6->result();
  if(!empty($qry6_result))
  { 
  foreach($qry6_result as $q6)
  { 
  ?>
  <option class="sibling_val4" value="<?php echo 'root_val:'.$q6->sib_root.'::'.'parent_val:'.$q6->sib_parnt.'::'.'child_val:'.$q6->sib_child.'::'.'sib_1_val:'.$q6->sib_1.'::'.'sib_2_val:'.$q6->sib_2.'::'.'sib_3_val:'.$q6->sib_3.'::'.'sib_4_val:'.$q6->sib_id;?>" >&nbsp;&nbsp;-&nbsp;<?php echo $q6->sib_4.'('.$q6->sib_code.')';?></option>
  <?php
  
  $sql7="SELECT * from account_tree_sibling5 where sib_root='".$q6->sib_root."' AND sib_parnt='".$q6->sib_parnt."' AND sib_child='".$q6->sib_child."' AND sib_sts='1' AND sib_1='".$q6->sib_1."' AND sib_2='".$q6->sib_2."' AND sib_3='".$q6->sib_id."' ";
    $qry7=$this->db->query($sql7);
    $qry7_result=$qry7->result();
  if(!empty($qry7_result))
  { 
  foreach($qry7_result as $q7)
  {
  ?>  
<option class="sibling_val5" value="<?php echo 'root_val:'.$q7->sib_root.'::'.'parent_val:'.$q7->sib_parnt.'::'.'child_val:'.$q7->sib_child.'::'.'sib_1_val:'.$q7->sib_1.'::'.'sib_2_val:'.$q7->sib_2.'::'.'sib_3_val:'.$q7->sib_3.'::'.'sib_4_val:'.$q7->sib_4.'::'.'sib_5_val:'.$q7->sib_id;?>" 
>&nbsp;&nbsp;-&nbsp;<?php echo $q7->sib_5.'('.$q7->sib_code.')';?></option>

<?php
}}
}}    
}}
}}
}}
}}
}}
}}
?>  
 
</select>
     <div class="dropdown_list"></div>
 
 <!-- here goes the dropdown list-->
</div>
</div>
</div>
	
<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">  Code <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <p class="code"></p>
 	<div class="form_error">  </div>
</div> 
</div>
</div>


</div>
</div>

<div class="row">
	<div class="col-md-12 table-rows-border">
<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Posting Date  <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

<input type="text" name="posting_date" class="form-control datetimepicker4" required="" />

 	<div class="form_error">  </div>
</div> 
</div>

</div>
		<div class="col-md-6 col-sm-12">
<div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Due Date<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
<input type="text" name="due_date" class="form-control datetimepicker4" required="" />
<div class="form_error">  </div>
</div>
</div>
	
</div>

</div>
</div>


<div class="row">
	<div class="col-md-12 table-rows-border">		
<div class="col-md-6 col-sm-12">

    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Transaction No. <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" name="trsctn_no" class="form-control" >
 	<div class="form_error">  <?php echo $this->session->flashdata('address');?></div>
</div> 
</div>
</div>

<div class="col-md-6 col-sm-12">
    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Amount <abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type="text" name="amount" class="form-control" >
 	<div class="form_error">  <?php echo $this->session->flashdata('notes');?></div>
</div> 
</div>
</div>
</div>
</div>

<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div>
</section>
</div>
</div>

</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script type="text/javascript">
$(document).ready(function()
{
$("input[name='chose_type']").change(function(){
 var input_choosen= $(this).val();
if(input_choosen=='1')   
  {
    $('select[name="customer_details"]').show();
    $('select[name="supplier_details"]').hide();
    $('select[name="accounts_details"]').hide();
  }
else if(input_choosen=='3')   
  {
    $('select[name="supplier_details"]').show();
    $('select[name="customer_details"]').hide();
    $('select[name="accounts_details"]').hide();
  } 
 else
 {
   $('select[name="accounts_details"]').show();
   $('select[name="customer_details"]').hide();
  $('select[name="supplier_details"]').hide();
 }  
// Do something interesting here
});


$("select[name='customer_details']").change(function(){
jQuery.ajax({
          url:"<?php echo base_url().'Payment/customer_code';?>",
          type:"post",
          data:{"cust_id":$(this).val()},
          success:function(result)
          {
           $('.code').html(result);
         // $('#country_code').html(returnedData.code);
          }
      });
  });
$("select[name='accounts_details']").change(function(){
  var selectedText = $("select[name='accounts_details'] option:selected").html();
  var output1 =selectedText.split('(');
   var output2 =output1[1].split(')');
$('.code').html(output2);
  });


$("select[name='supplier_details']").change(function(){
    jQuery.ajax({
          url:"<?php echo base_url().'Payment/supplier_code';?>",
          type:"post",
          data:{"sup_id":$(this).val()},
          success:function(result)
          {
          $('.code').html(result);
          }
      });
  });


});
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
    $(function () {
          $('.datetimepicker4').datepicker();
      });
</script>

</html>