<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css"/>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Account Entry Form</h2>
</header>
<div class="panel-body">
	<?php echo form_open('submit_ac_head',array('class'=>'form-horizontal form-bordered myform')
	);?>
	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

    <input type="hidden" name="root_val">
    <input type="hidden" name="parent_val">
    <input type="hidden" name="child_val">
    <input type="hidden" name="sib_1">
    <input type="hidden" name="sib_2">
    <input type="hidden" name="sib_3">
    <input type="hidden" name="sib_4">
    <input type="hidden" name="sib_5">
<p class="required"> Fields marked as '::*::' are required fields</p>
	

<input type="hidden" name="bank" >

<div class="row">
	<div class="col-md-12 table-rows-border">
<div class="col-md-6 col-sm-12">

<div class="form-group">
<label class="col-md-4 control-label" for="inputDefault">Under A/c<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select data-plugin-selectTwo class="form-control populate" name="under_ac" required="">
		<option value="0" >Root</option>	
<?php

if(!empty($result))
{
	foreach($result as $r)
	{
		$sql="SELECT * from account_tree_parent where par_root=".$r->root_id." ";
		$qry1=$this->db->query($sql);
		$qry1_result=$qry1->result();
		?>
	<option class="root_val" value="<?php echo 'root_val:'.$r->root_id;?>"><b><?php echo $r->root_name;?></b></option>
	<?php
	if(!empty($qry1_result))
		{
	foreach($qry1_result as $q1)
	{
	?>
	<option class="parent_val" value="<?php echo 'root_val:'.$r->root_id.'::'.'parent_val:'.$q1->par_id;?>">&nbsp;-&nbsp;<?php echo $q1->par_name;?></option>
		<?php
		
			
	$sql2="SELECT * from account_tree_child where ch_root='".$r->root_id."' AND ch_imd_parnt='".$q1->par_id."' AND ch_sts='1' ";
			$qry2=$this->db->query($sql2);
			$qry2_result=$qry2->result();
if(!empty($qry2_result))
	{
	foreach($qry2_result as $q2)
		{
			
			?>
	<option class="child_val" value="<?php echo 'root_val:'.$q2->ch_root.'::'.'parent_val:'.$q2->ch_imd_parnt.'::'.'child_val:'.$q2->ch_id;?>">&nbsp;&nbsp;-&nbsp;-&nbsp;<?php echo $q2->ch_name;?></option>
		<?php
		$sql3="SELECT * from account_tree_sibling where sib_root='".$q2->ch_root."' AND sib_parnt='".$q2->ch_imd_parnt."' AND sib_child='".$q2->ch_id."' AND sib_sts='1' AND sib_1!='' ";
			$qry3=$this->db->query($sql3);
			$qry3_result=$qry3->result();
	if(!empty($qry3_result))
		{		
	foreach($qry3_result as $q3)
		{			
		?>
	<option class="sibling_val1" value="<?php echo 'root_val:'.$q3->sib_root.'::'.'parent_val:'.$q3->sib_parnt.'::'.'child_val:'.$q3->sib_child.'::'.'sib_1_val:'.$q3->sib_1;?>">&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;-&nbsp;-&nbsp;<?php echo $q3->sib_1;?></option>

	<?php
	$sql4="SELECT * from account_tree_sibling where sib_root='".$q2->ch_root."' AND sib_parnt='".$q2->ch_imd_parnt."' AND sib_child='".$q2->ch_id."' AND sib_sts='1' AND sib_2!=''  ";
			$qry4=$this->db->query($sql4);
			$qry4_result=$qry4->result();
	if(!empty($qry4_result))
		{		
		foreach($qry4_result as $q4)
		{		
		?>
	<option class="sibling_val2" value="<?php echo 'root_val:'.$q3->sib_root.'::'.'parent_val:'.$q3->sib_parnt.'::'.'child_val:'.$q3->sib_child.'::'.'sib_1_val:'.$q3->sib_1.'::'.'sib_2_val:'.$q4->sib_2;?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;<?php echo $q4->sib_2;?></option>
	<?php
	
	$sql5="SELECT * from account_tree_sibling where sib_root='".$q2->ch_root."' AND sib_parnt='".$q2->ch_imd_parnt."' AND sib_child='".$q2->ch_id."' AND sib_sts='1' AND sib_3!=''  ";
			$qry5=$this->db->query($sql5);
			$qry5_result=$qry5->result();
	if(!empty($qry5_result))
		{		
		foreach($qry5_result as $q5)
		{		
	?>
	<option class="sibling_val3" value="<?php echo 'root_val:'.$q3->sib_root.'::'.'parent_val:'.$q3->sib_parnt.'::'.'child_val:'.$q3->sib_child.'::'.'sib_1_val:'.$q3->sib_1.'::'.'sib_2_val:'.$q4->sib_2.'::'.'sib_3_val:'.$q5->sib_3;?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;<?php echo $q5->sib_3;?></option>
	<?php
	
	$sql6="SELECT * from account_tree_sibling where sib_root='".$q2->ch_root."' AND sib_parnt='".$q2->ch_imd_parnt."' AND sib_child='".$q2->ch_id."' AND sib_sts='1' AND sib_4!=''  ";
			$qry6=$this->db->query($sql6);
			$qry6_result=$qry6->result();
		if(!empty($qry6_result))
		{	
		foreach($qry6_result as $q6)
		{	
			?>

	<option class="sibling_val4" value="<?php echo 'root_val:'.$q3->sib_root.'::'.'parent_val:'.$q3->sib_parnt.'::'.'child_val:'.$q3->sib_child.'::'.'sib_1_val:'.$q3->sib_1.'::'.'sib_2_val:'.$q4->sib_2.'::'.'sib_3_val:'.$q5->sib_3.'::'.'sib_4_val:'.$q6->sib_4;?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;<?php echo $q6->sib_4;?></option>
	<?php
	
	$sql7="SELECT * from account_tree_sibling where sib_root='".$q2->ch_root."' AND sib_parnt='".$q2->ch_imd_parnt."' AND sib_child='".$q2->ch_id."' AND sib_sts='1' AND sib_5!=''  ";
			$qry7=$this->db->query($sql7);
			$qry7_result=$qry7->result();
		if(!empty($qry7_result))
		{
		foreach($qry7_result as $q7)
		{
		?>
	<option class="sibling_val5" value="<?php echo 'root_val:'.$q3->sib_root.'::'.'parent_val:'.$q3->sib_parnt.'::'.'child_val:'.$q3->sib_child.'::'.'sib_1_val:'.$q3->sib_1.'::'.'sib_2_val:'.$q4->sib_2.'::'.'sib_3_val:'.$q5->sib_3.'::'.'sib_4_val:'.$q6->sib_4.'::'.'sib_5_val:'.$q7->sib_4;?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;<?php echo $q7->sib_5;?></option>
	<?php
		}
	}
	?>

		<?php
		}
		}
	}	
		?>
	<?php
		}		
	}
}}
}}
}}
}
	?>	

	
<?php
	}
}?>
	</select>

<div class="form_error">  <?php echo $this->session->flashdata('under_ac');?></div>
</div>
 </div>

</div>
<div class="col-md-6">

   <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Opening Balance<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type='text' name="opng_bal" class="form-control" value="" required />
<div class="form_error">  <?php echo $this->session->flashdata('opng_bal');?></div>
</div> 
</div>

</div>
</div>
</div>


<div class="row">
	<div class="col-md-12 table-rows-border">

<div class="col-md-6 col-sm-12">
    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">A/C Name<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type='text' name="ac_name" class="form-control" value="" required />
<div class="form_error">  <?php echo $this->session->flashdata('ac_name');?></div>
</div> 
</div>
</div>

<!-- <div class="col-md-6 col-sm-12">
    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">A/c Code<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type='text' name="ac_code" class="form-control" value="" required />
</div> 
</div>
</div>
 -->

 <div class="col-md-6 col-sm-12">
    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Memo<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<textarea class="form-control" name="memo"></textarea>
</div> 
<div class="form_error">  <?php echo $this->session->flashdata('memo');?></div>
</div>
</div>

</div>
</div>

<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary" type="submit">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div> 
</section>

</div>
</div>
</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript">
	</script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript">
	</script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript">
	</script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script type="text/javascript">
$("select").change(function(e) {
    var select = e.target;
    var option = select.options[select.selectedIndex];
    if ($(option).hasClass('parent_val')) {
     var selected_val=$(this).val();
     var split_val=selected_val.split('::');
     var val1=split_val[0];
     var val2=split_val[1];
   $('input[name="root_val"]').val(val1);
    $('input[name="parent_val"]').val(val2);
    } 
    else if($(option).hasClass('child_val'))
    {
    	var selected_val=$(this).val();
     var split_val=selected_val.split('::');
     var val1=split_val[0];
     var val2=split_val[1];
     var val3=split_val[2];
   		$('input[name="root_val"]').val(val1);
    	$('input[name="parent_val"]').val(val2);
    	$('input[name="child_val"]').val(val3);  	
    }
    else if($(option).hasClass('sibling_val1'))
    {
    	alert('in sib1');
    	var selected_val=$(this).val();
    	 var split_val=selected_val.split('::');
    	 var val1=split_val[0];///root
     	var val2=split_val[1];//parent
     	var val3=split_val[2];///child

     	var val4=split_val[3];//sib_1
     	var val5=split_val[4];//sib_2
    

    	$('input[name="root_val"]').val(val1);
    	$('input[name="parent_val"]').val(val2);
    	$('input[name="child_val"]').val(val3);

    	$('input[name="sib_1"]').val(val4);
    	$('input[name="sib_2"]').val(val5);
    }
     else if($(option).hasClass('sibling_val2'))
    {
    	alert('in sib2');
    	var selected_val=$(this).val();
    	 var split_val=selected_val.split('::');
    	 var val1=split_val[0];///root
     	var val2=split_val[1];//parent
     	var val3=split_val[2];///child

     	var val4=split_val[3];//sib_1
     	var val5=split_val[4];//sib_2
     	var val6=split_val[5];//sib_3

     	$('input[name="root_val"]').val(val1);
    	$('input[name="parent_val"]').val(val2);
    	$('input[name="child_val"]').val(val3);

    	$('input[name="sib_1"]').val(val4);
    	$('input[name="sib_2"]').val(val5);
    	$('input[name="sib_3"]').val(val6);

    	console.log(val4);
    	console.log(val5);

    }
    else if($(option).hasClass('sibling_val3'))
    {
    	var selected_val=$(this).val();
    	 var split_val=selected_val.split('::');
    	 var val1=split_val[0];///root
     	var val2=split_val[1];//parent
     	var val3=split_val[2];///child

     		var val4=split_val[3];//sib_1
     	var val5=split_val[4];//sib_2
     	var val6=split_val[5];//sib_3
     	var val7=split_val[6];//sib_4

   		$('input[name="root_val"]').val(val1);
    	$('input[name="parent_val"]').val(val2);
    	$('input[name="child_val"]').val(val3);

    	$('input[name="sib_1"]').val(val4);
    	$('input[name="sib_2"]').val(val5);
    	$('input[name="sib_3"]').val(val6);
    	$('input[name="sib_4"]').val(val7);
    }
    else if($(option).hasClass('sibling_val4'))
    {
    	var selected_val=$(this).val();
    	 var split_val=selected_val.split('::');
    	 var val1=split_val[0];///root
     	var val2=split_val[1];//parent
     	var val3=split_val[2];///child

     		var val4=split_val[3];//sib_1
     	var val5=split_val[4];//sib_2
     	var val6=split_val[5];//sib_3
     	var val7=split_val[6];//sib_4
     	var val8=split_val[7];//sib_5

     		 $('input[name="root_val"]').val(val1);
    	$('input[name="parent_val"]').val(val2);
    	$('input[name="child_val"]').val(val3);

    	$('input[name="sib_1"]').val(val4);
    	$('input[name="sib_2"]').val(val5);
    	$('input[name="sib_3"]').val(val6);
    	$('input[name="sib_4"]').val(val7);
    	$('input[name="sib_5"]').val(val8);
    }
    else {
       alert('in else');
    }
});
</script>
</html>