<!doctype html>
<html class="fixed">

<head>
<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>/vendor/select2/select2.css"/>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>


<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.table-rows-border{
	border-bottom: 1px solid #eff2f7;
    padding-bottom: 15px;
    margin-bottom: 15px;
}
.required{
	color: red;
}
</style>
</head>
<body>
<section class="body">

<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>
<section role="main" class="content-body">
<header class="page-header">
<h2>Entry Form</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>Entry Form</span></li>
<li><span>Add</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>

<div class="row">
<div class="col-lg-12">
    <a href="<?php echo base_url('list-account-head');?>" class="btn btn-primary">List Account Head</a>
<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Account Entry Form</h2>
</header>
<div class="panel-body">
	<?php echo form_open('submit_ac_head',array('class'=>'form-horizontal form-bordered myform')
	);?>



	  <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

    <input type="hidden" name="edit_id" value="<?php 
    if(!empty($edit_result[0]->root_id)){echo $edit_result[0]->root_id;}
    elseif(!empty($edit_result[0]->par_id)){echo $edit_result[0]->par_id;}
    elseif(!empty($edit_result[0]->ch_id)){echo $edit_result[0]->ch_id;}
    elseif(!empty($edit_result[0]->sib_id)){echo $edit_result[0]->sib_id;}
    else{}
      ;?>">

            <input type="hidden" name="edit_table" value="<?php if(!empty($edit_table)) {echo $edit_table;}?>">
  
    <input type="hidden" name="root_val">
    <input type="hidden" name="parent_val">
    <input type="hidden" name="child_val">
    <input type="hidden" name="sib_1">
    <input type="hidden" name="sib_2">
    <input type="hidden" name="sib_3">
    <input type="hidden" name="sib_4">
    <input type="hidden" name="sib_5">
<p class="required"> Fields marked as '::*::' are required fields</p>


<input type="hidden" name="bank" >

<div class="row">
	<div class="col-md-12 table-rows-border">

<div class="form-group">
<label class="col-md-4 control-label" for="inputDefault">Under A/c<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<select data-plugin-selectTwo class="form-control populate" name="under_ac" <?php if(!empty($edit_result[0])){echo "disabled";}else{echo "required";};?>>
		<option value="0" >Root</option>	
<?php

if(!empty($result))
{
	foreach($result as $r)
	{
		$sql="SELECT * from account_tree_parent where par_root=".$r->root_id." ";
		$qry1=$this->db->query($sql);
		$qry1_result=$qry1->result();
		?>
	<option class="root_val" value="<?php echo 'root_val:'.$r->root_id;?>" <?php if(!empty($edit_result[0]->par_root)){if($r->root_id==$edit_result[0]->par_root){echo "selected";}};?> ><b><?php echo $r->root_name.'('.$r->root_code.')';?></b></option>
	<?php
	if(!empty($qry1_result))
		{
	foreach($qry1_result as $q1)
	{
	?>
	<option class="parent_val" value="<?php echo 'root_val:'.$r->root_id.'::'.'parent_val:'.$q1->par_id;?>" <?php if(!empty($edit_result[0]->ch_imd_parnt)){if($q1->par_id==$edit_result[0]->ch_imd_parnt){echo "selected";}};?> >&nbsp;-&nbsp;<?php echo $q1->par_name.'('.$q1->par_ac_code.')';?></option>
		<?php		
			
	$sql2="SELECT * from account_tree_child where ch_root='".$r->root_id."' AND ch_imd_parnt='".$q1->par_id."' AND ch_sts='1' ";
			$qry2=$this->db->query($sql2);
			$qry2_result=$qry2->result();
if(!empty($qry2_result))
	{
	foreach($qry2_result as $q2)
		{
			
			?>
	<option class="child_val" value="<?php echo 'root_val:'.$q2->ch_root.'::'.'parent_val:'.$q2->ch_imd_parnt.'::'.'child_val:'.$q2->ch_id;?>" <?php if(!empty($edit_result[0]->sib_child)){if($q2->ch_id==$edit_result[0]->sib_child){echo "selected";}};?>  >&nbsp;&nbsp;-&nbsp;<?php echo $q2->ch_name.'('.$q2->ch_code.')';?></option>
		<?php
		$sql3="SELECT * from account_tree_sibling where sib_root='".$q2->ch_root."' AND sib_parnt='".$q2->ch_imd_parnt."' AND sib_child='".$q2->ch_id."' AND sib_sts='1' AND sib_1!='' ";
			$qry3=$this->db->query($sql3);
			$qry3_result=$qry3->result();

	if(!empty($qry3_result))
		{
		foreach($qry3_result as $q3)
		{
		
		?>
	<option class="sibling_val1" value="<?php echo 'root_val:'.$q3->sib_root.'::'.'parent_val:'.$q3->sib_parnt.'::'.'child_val:'.$q3->sib_child.'::'.'sib_1_val:'.$q3->sib_id;?>" <?php if(!empty($edit_result[0]->sib_1)){if($q3->sib_id==$edit_result[0]->sib_1){echo "selected";}};?>  >
        &nbsp;&nbsp;&nbsp;-&nbsp;<?php echo $q3->sib_1.'('.$q3->sib_code.')';?></option><!--upto here correct-->
	<?php
		
	$sql4="SELECT * from account_tree_sibling2 where sib_root='".$q3->sib_root."' AND sib_parnt='".$q3->sib_parnt."' AND sib_child='".$q3->sib_child."' AND sib_sts='1' AND sib_1='".$q3->sib_id."' ";
		$qry4=$this->db->query($sql4);
		$qry4_result=$qry4->result();
	if(!empty($qry4_result))
	{	
	foreach($qry4_result as $q4)
	{
	
	?>
	<option class="sibling_val2" value="<?php echo 'root_val:'.$q4->sib_root.'::'.'parent_val:'.$q4->sib_parnt.'::'.'child_val:'.$q4->sib_child.'::'.'sib_1_val:'.$q4->sib_1.'::'.'sib_2_val:'.$q4->sib_id;?>" <?php if(!empty($edit_result[0]->sib_2)){if($q4->sib_id==$edit_result[0]->sib_2){echo "selected";}};?> >&nbsp;&nbsp;-&nbsp;<?php echo $q4->sib_2.'('.$q4->sib_code.')';?></option>
	<?php
	
	$sql5="SELECT * from account_tree_sibling3 where sib_root='".$q4->sib_root."' AND sib_parnt='".$q4->sib_parnt."' AND sib_child='".$q4->sib_child."' AND sib_sts='1' AND sib_1='".$q4->sib_1."' AND sib_2='".$q4->sib_id."' ";
		$qry5=$this->db->query($sql5);
		$qry5_result=$qry5->result();
	if(!empty($qry5_result))
	{
	foreach($qry5_result as $q5)
	{	
	
	?>
	<option class="sibling_val3" value="<?php echo 'root_val:'.$q5->sib_root.'::'.'parent_val:'.$q5->sib_parnt.'::'.'child_val:'.$q5->sib_child.'::'.'sib_1_val:'.$q5->sib_1.'::'.'sib_2_val:'.$q5->sib_2.'::'.'sib_3_val:'.$q5->sib_id;?>"  <?php if(!empty($edit_result[0]->sib_3)){if($q5->sib_id==$edit_result[0]->sib_3){echo "selected";}};?> >&nbsp;&nbsp;-&nbsp;<?php echo $q5->sib_3.'('.$q5->sib_code.')';?></option>
	<?php
	
	$sql6="SELECT * from account_tree_sibling4 where sib_root='".$q5->sib_root."' AND sib_parnt='".$q5->sib_parnt."' AND sib_child='".$q5->sib_child."' AND sib_sts='1' AND sib_1='".$q5->sib_1."' AND sib_2='".$q5->sib_2."' AND sib_3='".$q5->sib_id."' ";
		$qry6=$this->db->query($sql6);
		$qry6_result=$qry6->result();
	if(!empty($qry6_result))
	{	
	foreach($qry6_result as $q6)
	{	
	?>
	<option class="sibling_val4" value="<?php echo 'root_val:'.$q6->sib_root.'::'.'parent_val:'.$q6->sib_parnt.'::'.'child_val:'.$q6->sib_child.'::'.'sib_1_val:'.$q6->sib_1.'::'.'sib_2_val:'.$q6->sib_2.'::'.'sib_3_val:'.$q6->sib_3.'::'.'sib_4_val:'.$q6->sib_id;?>"<?php if(!empty($edit_result[0]->sib_4)){if($q6->sib_id==$edit_result[0]->sib_4){echo "selected";}};?> >&nbsp;&nbsp;-&nbsp;<?php echo $q6->sib_4.'('.$q6->sib_code.')';?></option>
	<?php
	
	$sql7="SELECT * from account_tree_sibling5 where sib_root='".$q6->sib_root."' AND sib_parnt='".$q6->sib_parnt."' AND sib_child='".$q6->sib_child."' AND sib_sts='1' AND sib_1='".$q6->sib_1."' AND sib_2='".$q6->sib_2."' AND sib_3='".$q6->sib_id."' ";
		$qry7=$this->db->query($sql7);
		$qry7_result=$qry7->result();
	if(!empty($qry7_result))
	{	
	foreach($qry7_result as $q7)
	{
	?>	
<option class="sibling_val5" value="<?php echo 'root_val:'.$q7->sib_root.'::'.'parent_val:'.$q7->sib_parnt.'::'.'child_val:'.$q7->sib_child.'::'.'sib_1_val:'.$q7->sib_1.'::'.'sib_2_val:'.$q7->sib_2.'::'.'sib_3_val:'.$q7->sib_3.'::'.'sib_4_val:'.$q7->sib_4.'::'.'sib_5_val:'.$q7->sib_id;?>" <?php if(!empty($edit_result[0]->sib_5)){if($q7->sib_id==$edit_result[0]->sib_5){echo "selected";}};?>
>&nbsp;&nbsp;-&nbsp;<?php echo $q7->sib_5.'('.$q7->sib_code.')';?></option>

<?php
}}
}}		
}}
}}
}}
}}
}}
}}
?>	
</select>

<div class="form_error">  <?php echo $this->session->flashdata('under_ac');?></div>
</div>
 </div>

</div>
</div>


<div class="row">
	<div class="col-md-12 table-rows-border">

<div class="col-md-6 col-sm-12">
    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">A/C Name<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type='text' name="ac_name" class="form-control" value="<?php 
 if(!empty($edit_result[0]->root_name)){echo $edit_result[0]->root_name;
 }

elseif(!empty($edit_result[0]->par_name)){
echo $edit_result[0]->par_name;
}
elseif(!empty($edit_result[0]->ch_name)){
echo $edit_result[0]->ch_name;
}
elseif(!empty($edit_result[0]->sib_1) && !is_numeric($edit_result[0]->sib_1) ){
   echo $edit_result[0]->sib_1; 
}
elseif(!empty($edit_result[0]->sib_2) && !is_numeric($edit_result[0]->sib_2) ){
echo $edit_result[0]->sib_2;
}
elseif(!empty($edit_result[0]->sib_3) && !is_numeric($edit_result[0]->sib_3) ){
  echo $edit_result[0]->sib_3;  
}
elseif(!empty($edit_result[0]->sib_4) && !is_numeric($edit_result[0]->sib_4) ){
    echo $edit_result[0]->sib_4;  
}
elseif(!empty($edit_result[0]->sib_5) && !is_numeric($edit_result[0]->sib_5) ){
    echo $edit_result[0]->sib_5;  
}
else{}
 ?>" required />

<div class="form_error">  <?php echo $this->session->flashdata('ac_name');?></div>
</div> 
</div>
</div>

<div class="col-md-6">

   <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Opening Balance<abbr class="required">::*::</abbr></label>
<div class="col-md-8">

 <input type='text' name="opng_bal" class="form-control" value="<?php 
 if(!empty($edit_result[0]->root_bal))
 {
    echo $edit_result[0]->root_bal;
 }
elseif(!empty($edit_result[0]->par_opening_bal)){
echo $edit_result[0]->par_opening_bal;
}
elseif(!empty($edit_result[0]->ch_opening_bal)){
echo $edit_result[0]->ch_opening_bal;
}
elseif(!empty($edit_result[0]->sib_opening_bal)){
   echo $edit_result[0]->sib_opening_bal; 
}
else{}
 ?>" required />
<div class="form_error">  <?php echo $this->session->flashdata('opng_bal');?></div>
</div> 
</div>

</div>

<!-- <div class="col-md-6 col-sm-12">
    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">A/c Code<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
 <input type='text' name="ac_code" class="form-control" value="" required />
</div> 
</div>
</div>
 -->

</div>
</div>



<div class="row">
	<div class="col-md-12 table-rows-border">

<div class="col-md-6 col-sm-12">
    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Account Code<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
  <input type='text' name="acc_code" class="form-control" value="<?php 
  if(!empty($edit_result[0]->root_code))
  {
    echo $edit_result[0]->root_code;
  }
  elseif(!empty($edit_result[0]->par_ac_code)){
echo $edit_result[0]->par_ac_code;
}
elseif(!empty($edit_result[0]->ch_code)){
echo $edit_result[0]->ch_code;
}
elseif(!empty($edit_result[0]->sib_code)){
   echo $edit_result[0]->sib_code; 
}
else{}
  ?>" required />
</div> 
<div class="form_error">  <?php echo $this->session->flashdata('acc_code');?></div>
</div>
</div>       

<div class="col-md-6 col-sm-12">
    <div class="form-group">
<label class="col-md-4 control-label" for="inputPlaceholder">Memo<abbr class="required">::*::</abbr></label>
<div class="col-md-8">
	<textarea class="form-control" name="memo">
        <?php if(!empty($edit_result[0]->root_memo))
        {
            echo $edit_result[0]->root_memo;
        }
  elseif(!empty($edit_result[0]->par_memo)){
echo $edit_result[0]->par_memo;
}
elseif(!empty($edit_result[0]->ch_memo)){
echo $edit_result[0]->ch_memo;
}
elseif(!empty($edit_result[0]->sib_memo)){
   echo $edit_result[0]->sib_memo; 
}
else{}
        ?></textarea>
</div> 
<div class="form_error">  <?php echo $this->session->flashdata('memo');?></div>
</div>
</div>

</div>
</div>

<div class="col-sm-9 col-sm-offset-3">
<button class="btn btn-primary" type="submit">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>

<?php echo form_close();?>
</div> 
</section>

</div>
</div>
</section>
</div>
</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript">
	</script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript">
	</script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-multiselect/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-autosize/jquery.autosize.js" type="text/javascript">
	</script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-fileupload/bootstrap-fileupload.min.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script type="text/javascript">
$("select").change(function(e) {
    var select = e.target;
    var option = select.options[select.selectedIndex];
    if($(option).hasClass('root_val'))
    {
    //	console.log('in root val');
       var selected_val=$(this).val();
	    var val1=selected_val;
   		$('input[name="root_val"]').val(val1);
    }
    else if($(option).hasClass('parent_val')) {
    //	console.log('in parent val');
     var selected_val=$(this).val();
     var split_val=selected_val.split('::');
     var val1=split_val[0];
     var val2=split_val[1];
     $('input[name="root_val"]').val(val1);
     $('input[name="parent_val"]').val(val2);

    } 
    else if($(option).hasClass('child_val'))
    {
     var selected_val=$(this).val();
     var split_val=selected_val.split('::');
     var val1=split_val[0];
     var val2=split_val[1];
     var val3=split_val[2];
   		$('input[name="root_val"]').val(val1);
    	$('input[name="parent_val"]').val(val2);
    	$('input[name="child_val"]').val(val3);  	
    }
    else if($(option).hasClass('sibling_val1'))
    {
    	//alert('in sib1');
    	var selected_val=$(this).val();
    	 var split_val=selected_val.split('::');
    	 var val1=split_val[0];///root
     	var val2=split_val[1];//parent
     	var val3=split_val[2];///child

     	var val4=split_val[3];//sib_1
     	var val5=split_val[4];//sib_2
    

    	$('input[name="root_val"]').val(val1);
    	$('input[name="parent_val"]').val(val2);
    	$('input[name="child_val"]').val(val3);

    	$('input[name="sib_1"]').val(val4);
    	$('input[name="sib_2"]').val(val5);
    }
     else if($(option).hasClass('sibling_val2'))
    {
    	//alert('in sib2');
    	var selected_val=$(this).val();
    	 var split_val=selected_val.split('::');
    	 var val1=split_val[0];///root
     	var val2=split_val[1];//parent
     	var val3=split_val[2];///child

     	var val4=split_val[3];//sib_1
     	var val5=split_val[4];//sib_2
     	var val6=split_val[5];//sib_3

     	$('input[name="root_val"]').val(val1);
    	$('input[name="parent_val"]').val(val2);
    	$('input[name="child_val"]').val(val3);

    	$('input[name="sib_1"]').val(val4);
    	$('input[name="sib_2"]').val(val5);
    	$('input[name="sib_3"]').val(val6);

    	// console.log(val4);
    	// console.log(val5);

    }
    else if($(option).hasClass('sibling_val3'))
    {
    	var selected_val=$(this).val();
    	 var split_val=selected_val.split('::');
    	 var val1=split_val[0];///root
     	var val2=split_val[1];//parent
     	var val3=split_val[2];///child

     		var val4=split_val[3];//sib_1
     	var val5=split_val[4];//sib_2
     	var val6=split_val[5];//sib_3
     	var val7=split_val[6];//sib_4

   		$('input[name="root_val"]').val(val1);
    	$('input[name="parent_val"]').val(val2);
    	$('input[name="child_val"]').val(val3);

    	$('input[name="sib_1"]').val(val4);
    	$('input[name="sib_2"]').val(val5);
    	$('input[name="sib_3"]').val(val6);
    	$('input[name="sib_4"]').val(val7);
    }
    else if($(option).hasClass('sibling_val4'))
    {
    	var selected_val=$(this).val();
    	 var split_val=selected_val.split('::');
    	 var val1=split_val[0];///root
     	var val2=split_val[1];//parent
     	var val3=split_val[2];///child

     		var val4=split_val[3];//sib_1
     	var val5=split_val[4];//sib_2
     	var val6=split_val[5];//sib_3
     	var val7=split_val[6];//sib_4
     	var val8=split_val[7];//sib_5

     		 $('input[name="root_val"]').val(val1);
    	$('input[name="parent_val"]').val(val2);
    	$('input[name="child_val"]').val(val3);

    	$('input[name="sib_1"]').val(val4);
    	$('input[name="sib_2"]').val(val5);
    	$('input[name="sib_3"]').val(val6);
    	$('input[name="sib_4"]').val(val7);
    	$('input[name="sib_5"]').val(val8);
    }
    else {
       //alert('in else');
    }
});
</script>
</html>