<!doctype html>
<html class="fixed">

<head>

<?php $this->load->view('admin/head');?>

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/font-awesome/css/font-awesome.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/css/datepicker3.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/css/datatables.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/skins/default.css" />

<link rel="stylesheet" href="<?php echo base_url('admin_assets/');?>stylesheets/theme-custom.css">

<script src="<?php echo base_url('admin_assets/');?>vendor/modernizr/modernizr.js" type="text/javascript"></script>

<style type="text/css">
	.form_error 
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.form_error p .errors{
	color: red;
}
.errors
{font-size: 13px;font-family:Arial;color:red;font-style:italic}
.success
{font-size: 13px;font-family:Arial;color:green;font-style:italic}

.datepicker{z-index:18000 !important}
</style>

</head>
<body>
<section class="body">


<?php $this->load->view('admin/header');?>

<div class="inner-wrapper">

<?php $this->load->view('admin/aside');?>

<section role="main" class="content-body">
<header class="page-header">
<h2>List Sales Entries</h2>
<div class="right-wrapper pull-right">
<ol class="breadcrumbs">
<li>
<a href="#">
<i class="fa fa-home"></i>
</a>
</li>
<li><span>List</span></li>
<li><span>Sales Entries</span></li>
</ol>
<a class="sidebar-right-toggle"></a>
</div>
</header>


<section class="panel">
<header class="panel-heading">

<h2 class="panel-title">Table Data</h2>

</header>
<div class="panel-body">
	
	 <div class="form_error">
            <p class="errors">  <?php echo $this->session->flashdata('errors');?></p>
            <p class="success"><?php echo $this->session->flashdata('success');?></p>
    </div>

<table class="table table-bordered table-striped mb-none" id="datatable-default">
<thead>
<tr>
	<th style="width: 10%;"></th>

<th>Account Code</th>	
<th>Account Name</th>	
<th>Opening Balance</th>
<th>Created</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
	
<?php
$i=1;
if(!empty($result))
{
foreach($result as $t)
{
	echo "<tr class='gradeX'>";
	echo "<td>".$i++."</td>";
	
	echo "<td>".$t->root_code."</td>";
	echo "<td>".$t->root_name."</td>";
	echo "<td>".$t->root_bal."</td>";
	echo "<td>".date("Y-m-d", strtotime($t->root_dt_upd))."</td>";
		echo "<td>".
"<a href='".base_url()."edit_head/root/".$t->root_id."'><i class='fa fa-pencil'></i></a>".
// "<a href='delete_cust_details/root/'".$t->root_id."'' class='delete-row'><i class='fa fa-trash-o'></i></a>".
	"</td>";
	echo "</tr>";
$sql="SELECT * from account_tree_parent where par_root=".$t->root_id." ";
		$qry1=$this->db->query($sql);
		$qry1_result=$qry1->result();
if(!empty($qry1_result))
		{
	foreach($qry1_result as $q1)
	{
		echo "<tr class='gradeX'>";
	echo "<td>".$i++."</td>";
	
	echo "<td>".$q1->par_ac_code."</td>";
	echo "<td>".$q1->par_name."</td>";
	echo "<td>".$q1->par_opening_bal."</td>";
	echo "<td>".date("Y-m-d", strtotime($q1->par_dt_upd))."</td>";
		echo "<td>".
"<a href='".base_url()."edit_head/parent/".$q1->par_id."'><i class='fa fa-pencil'></i></a>".
	"</td>";
	echo "</tr>";

	$sql2="SELECT * from account_tree_child where ch_root='".$t->root_id."' AND ch_imd_parnt='".$q1->par_id."' AND ch_sts='1' ";
			$qry2=$this->db->query($sql2);
			$qry2_result=$qry2->result();
if(!empty($qry2_result))
	{
	foreach($qry2_result as $q2)
		{
echo "<tr class='gradeX'>";
	echo "<td>".$i++."</td>";
	
	echo "<td>".$q2->ch_code."</td>";
	echo "<td>".$q2->ch_name."</td>";
	echo "<td>".$q2->ch_opening_bal."</td>";
	echo "<td>".date("Y-m-d", strtotime($q2->ch_dt_upd))."</td>";
		echo "<td>".
"<a href='".base_url()."edit_head/child/".$q2->ch_id."'><i class='fa fa-pencil'></i></a>".
	"</td>";
	echo "</tr>";

$sql3="SELECT * from account_tree_sibling where sib_root='".$q2->ch_root."' AND sib_parnt='".$q2->ch_imd_parnt."' AND sib_child='".$q2->ch_id."' AND sib_sts='1' AND sib_1!='' ";
			$qry3=$this->db->query($sql3);
			$qry3_result=$qry3->result();

	if(!empty($qry3_result))
		{
		foreach($qry3_result as $q3)
		{
		
echo "<tr class='gradeX'>";
	echo "<td>".$i++."</td>";
	
	echo "<td>".$q3->sib_code."</td>";
	echo "<td>".$q3->sib_1."</td>";
	echo "<td>".$q3->sib_opening_bal."</td>";
	echo "<td>".date("Y-m-d", strtotime($q3->sib_dt_updt))."</td>";
		echo "<td>".
"<a href='".base_url()."edit_head/sib/".$q3->sib_id."'><i class='fa fa-pencil'></i></a>".
	"</td>";
	echo "</tr>";

	$sql4="SELECT * from account_tree_sibling2 where sib_root='".$q3->sib_root."' AND sib_parnt='".$q3->sib_parnt."' AND sib_child='".$q3->sib_child."' AND sib_sts='1' AND sib_1='".$q3->sib_id."' ";
		$qry4=$this->db->query($sql4);
		$qry4_result=$qry4->result();
	if(!empty($qry4_result))
	{	
	foreach($qry4_result as $q4)
	{
	echo "<tr class='gradeX'>";
	echo "<td>".$i++."</td>";
	
	echo "<td>".$q4->sib_code."</td>";
	echo "<td>".$q4->sib_2."</td>";
	echo "<td>".$q4->sib_opening_bal."</td>";
	echo "<td>".date("Y-m-d", strtotime($q4->sib_dt_updt))."</td>";
		echo "<td>".
"<a href='".base_url()."edit_head/sib2/".$q4->sib_id."'><i class='fa fa-pencil'></i></a>".
	"</td>";
	echo "</tr>";

	$sql5="SELECT * from account_tree_sibling3 where sib_root='".$q4->sib_root."' AND sib_parnt='".$q4->sib_parnt."' AND sib_child='".$q4->sib_child."' AND sib_sts='1' AND sib_1='".$q4->sib_1."' AND sib_2='".$q4->sib_id."' ";
		$qry5=$this->db->query($sql5);
		$qry5_result=$qry5->result();
	if(!empty($qry5_result))
	{
	foreach($qry5_result as $q5)
	{	

	echo "<tr class='gradeX'>";
	echo "<td>".$i++."</td>";
	
	echo "<td>".$q5->sib_code."</td>";
	echo "<td>".$q5->sib_3."</td>";
	echo "<td>".$q5->sib_opening_bal."</td>";
	echo "<td>".date("Y-m-d", strtotime($q5->sib_dt_updt))."</td>";
		echo "<td>".
"<a href='".base_url()."edit_head/sib3/'".$q5->sib_id."''><i class='fa fa-pencil'></i></a>".
	"</td>";
	echo "</tr>";

	$sql6="SELECT * from account_tree_sibling4 where sib_root='".$q5->sib_root."' AND sib_parnt='".$q5->sib_parnt."' AND sib_child='".$q5->sib_child."' AND sib_sts='1' AND sib_1='".$q5->sib_1."' AND sib_2='".$q5->sib_2."' AND sib_3='".$q5->sib_id."' ";
		$qry6=$this->db->query($sql6);
		$qry6_result=$qry6->result();
	if(!empty($qry6_result))
	{	
	foreach($qry6_result as $q6)
	{	

	echo "<tr class='gradeX'>";
	echo "<td>".$i++."</td>";
	
	echo "<td>".$q6->sib_code."</td>";
	echo "<td>".$q6->sib_4."</td>";
	echo "<td>".$q6->sib_opening_bal."</td>";
	echo "<td>".date("Y-m-d", strtotime($q6->sib_dt_updt))."</td>";
		echo "<td>".
"<a href='".base_url()."edit_head/sib4/'".$q6->sib_id."''><i class='fa fa-pencil'></i></a>".
	"</td>";
	echo "</tr>";

	$sql7="SELECT * from account_tree_sibling5 where sib_root='".$q6->sib_root."' AND sib_parnt='".$q6->sib_parnt."' AND sib_child='".$q6->sib_child."' AND sib_sts='1' AND sib_1='".$q6->sib_1."' AND sib_2='".$q6->sib_2."' AND sib_3='".$q6->sib_id."' ";
		$qry7=$this->db->query($sql7);
		$qry7_result=$qry7->result();
	if(!empty($qry7_result))
	{	
	foreach($qry7_result as $q7)
	{

	echo "<tr class='gradeX'>";
	echo "<td>".$i++."</td>";
	
	echo "<td>".$q7->sib_code."</td>";
	echo "<td>".$q7->sib_5."</td>";
	echo "<td>".$q7->sib_opening_bal."</td>";
	echo "<td>".date("Y-m-d", strtotime($q7->sib_dt_updt))."</td>";
	echo "<td>".
"<a href='".base_url()."edit_head/sib5/'".$q7->sib_id."''><i class='fa fa-pencil'></i></a>".
	"</td>";
	echo "</tr>";
?>

<?php
}} ////this is where the sibling 5 ends with if
?>
<?php
}} ////this is where the sibling 4 ends with if
?>
<?php		
}} ////this is where the sibling 3 ends with if
?>

<?php
}} ////this is where the sibling 2 ends with if
?>
<?php
}}////this is where the sibling 1 or sibling ends with if
?>
<?php
}} ////this is where the child ends with if
?>
<?php
}} ////this is where the parent ends with if
?>
<?php
}} ////this is where the root ends with if
?>	

</tr>

</tbody>
</table>

</div>
</section>

</section>
</div>

</section>

<script src="<?php echo base_url('admin_assets/');?>vendor/jquery/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-browser-mobile/jquery.browser.mobile.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/nanoscroller/nanoscroller.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/magnific-popup/magnific-popup.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-placeholder/jquery.placeholder.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/select2/select2.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/media/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>vendor/jquery-datatables-bs3/assets/js/datatables.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/theme.init.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.default.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.row.with.details.js" type="text/javascript"></script>
<script src="<?php echo base_url('admin_assets/');?>javascripts/tables/examples.datatables.tabletools.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>vendor/pnotify/pnotify.custom.js" type="text/javascript"></script>

<script src="<?php echo base_url('admin_assets/');?>javascripts/ui-elements/examples.modals.js" type="text/javascript"></script>

<script type="text/javascript">
	$(document).ready(function()
	{
		$('#country_id').val();

	});
</script>
</body>
</html>