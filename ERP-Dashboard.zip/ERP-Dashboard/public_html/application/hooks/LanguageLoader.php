<?php
class LanguageLoader
{
    function initialize() {
        $ci =& get_instance();

        $ci->load->helper('language');
       
        $siteLang = $ci->session->userdata('site_lang');
      
         if ($siteLang) {

          
             $ci->lang->load('header',$siteLang);
               $ci->lang->load('aside',$siteLang);
                 $ci->lang->load('content',$siteLang);
           




            //   print_r(($ci->lang->load('message','ar'););
          
         } else {
           
          
             $ci->lang->load('header','english');
               $ci->lang->load('aside',$siteLang);
                 $ci->lang->load('content',$siteLang);
         }
    }
}