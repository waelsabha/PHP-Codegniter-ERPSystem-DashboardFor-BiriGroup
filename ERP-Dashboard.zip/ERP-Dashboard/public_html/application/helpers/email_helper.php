<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 {
     
 	function setting()
    {
         $CI =& get_instance();
        $CI->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';
         $config['smtp_crypto'] = 'tls'; 
         $config['starttls'] = TRUE;
         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;
         return $config;


		    // $this->load->library('email');
            //     //  $config['protocol'] = "smtp";
            //     $config['mailpath']     = "/usr/bin/sendmail";
            //       $config['protocol'] = "smtp";
            //      $config['smtp_host'] = 'smtp.ionos.com';
            //      $config['smtp_port'] = '587';
            //      $config['smtp_user'] = 'noreply@birigroup.com';
            //      $config['smtp_pass'] = 'Noreply@000';
            //      $config['smtp_crypto'] = 'tls'; 
            //      $config['starttls'] = TRUE;
            //      $config['mailtype'] = 'html';
            //      $config['charset'] = 'utf-8';
            //      $config['newline'] = "\r\n";
            //      $config['crlf'] = "\r\n";
            //      $config['wordwrap'] = TRUE;
        
    }

    function hi_arya()
    {
         $CI =& get_instance();  
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
        $CI->email->to('support@birigroup.com');
        $CI->email->subject('cron working mail');
        $msg="Dear ARYA, testing the cron job working or not.";
       
        $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
            echo $CI->email->print_debugger();
         } 
    }

 	function send_user_mail($mail_data=null,$mail_sts=null)
	{	    
         $CI =& get_instance();
         $CI->load->model('Third_db_model','tm');

          $CI->email->initialize(setting());
	   	  $CI->email->from('noreply@birigroup.com','Biri Group');
	   	  
	   	  //$CI->email->to('support@birigroup.com');
		  $CI->email->to($mail_data['user_mail'],$mail_data['department']);
          $CI->email->cc('production@birigroup.com');
          if(empty($mail_sts))
		  $CI->email->subject('New Production Order');	
		else
		$CI->email->subject('New Production Order - Edited');

          $po_details=$CI->tm->get_po_details('prd_order',array('po_id'=>$mail_data['order_number']));
          
          if(!empty($po_details[0]->po_specl_customer_req))
    	$specl_customer_req=$po_details[0]->po_specl_customer_req;
	else
    	$specl_customer_req='';
        
        $prd_id=explode('|#|',$po_details[0]->po_prd_name);  
        foreach($prd_id as $pid)
            {
             $prd_data[]=$CI->tm->prd_var_data($pid);
            }
             
       // $prd_data[]=$CI->tm->prd_var($prd_id);///getting product details 
        $qnty=explode('|#|',$po_details[0]->po_qnty);
        $wgt=explode('|#|',$po_details[0]->po_wgt);
        $pck_type=explode('|#|',$po_details[0]->po_pck_type);
        $variations=explode('|#|',$po_details[0]->po_variations);
        $spcl_rq=explode('|#|',$po_details[0]->po_spcl_rq);
        $remarks=explode('|#|',$po_details[0]->po_rmks);

        $msg="Dear  " .$mail_data['username']." ,<br/> <br/>";
        $msg.="You got a new production order from ".$mail_data['order_from'].". <br/>";


        $msg.="<html>
        <head>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css'>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>
  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js'></script>
</head>
        <body>
        <p>Order Number: #".$po_details[0]->po_id."</p>
        <p>Delivery date: ".$po_details[0]->po_final_delivery_date."</p>
        <p>Delivery Location: ".$po_details[0]->po_delivery_loc."</p>
        <p>Sales Person: ".$po_details[0]->po_sales_person."</p>
          <p>Special customer request: ".$specl_customer_req."</p>
        <table class='table table-bordered' style='border: 1px solid black';><thead>
        <th>Product Name</th>
        <th>Product Code</th>
        <th>Quantity</th>
        <th>Weight</th>
        <th>Units</th>
        <th>Packaging type</th>
        <th>Variations</th>
        <th>Special request</th>
        <th>Remarks</th></thead>
        <tbody>
        ";
        foreach ($prd_data as $index=>$pdata) {
             $msg.="<tr>";
        foreach($pdata as $index2=>$q)
        {
            $pname=explode('|~~|',$q->pname);
           //  print_r($qnty[$index]);
            $msg.="<tr>";
            $msg.="<td>".$pname[0].'<br/>'.$pname[1]."</td>";
            $msg.="<td>".$q->pcode."</td>";
            $msg.="<td>".$qnty[$index]."</td>";
            $msg.="<td>".$wgt[$index]."</td>";
            $msg.="<td>".$q->uname."</td>";
            $msg.="<td>".$pck_type[$index]."</td>";
            $msg.="<td>".$variations[$index]."</td>";
            $msg.="<td>".$spcl_rq[$index]."</td>";
            $msg.="<td>".$remarks[$index]."</td>";
                $msg.="</tr>";
            }
             $msg.="</tr>";
        }
       
        $msg.="</tbody>";
        $msg.="</table></body></html>";
       
        if(!empty($po_details[0]->po_files))
        {  
            $msg.="Files attached :<br/><br/>";
            $prd_img=explode(',',$po_details[0]->po_files);
            foreach($prd_img as $images)
            {
                $msg.="<a href='".base_url('uploads/production/prod_files/').$images."'>".$images."</a><br/>";
            }         
        }
        
    
        $msg.="Check your dashboard to know more details about the order. Please take required action immediately after you receive this message.<br/>";

        $msg.="Thank you!<br/><br/>";


		$msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
        
		 $CI->email->message($msg);
		 if($CI->email->send())
			return true;
		 else
		 {
			 return false;
			//echo $CI->email->print_debugger();
		 }			
         //print_r($msg);	
	}



    function send_po_approved_mail($mail_data=null)
    {
    $CI =& get_instance();
    $CI->load->model('Third_db_model','tm');
       
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
        
         $po_details=$CI->tm->get_po_details('prd_order',array('po_id'=>$mail_data['po_id']));
         $sales_person=$po_details[0]->po_sales_person;
       
         $sales_info=$CI->tm->get_sales_email(array('log_uname'=>$sales_person));
         $sales_email=$sales_info[0]->log_email;
         $sales_dept=$sales_info[0]->log_dept;
	//$CI->email->to('support@birigroup.com');
        $CI->email->to($sales_email,$sales_dept);
        $CI->email->cc('production@birigroup.com');

        if(!empty($po_details[0]->po_edited_dept))
        {
           $CI->email->subject('Production Order Numbered #'.$po_details[0]->po_id.' Approved with edited details');

        }
        else
        {
             $CI->email->subject('Production Order Numbered #'.$po_details[0]->po_id.' Approved');
        }


         $msg="Dear ".$sales_info[0]->log_uname.",<br/>";
         $msg.="Your order numbered #".$po_details[0]->po_id." is approved successfully.";

        if(!empty($po_details[0]->po_edited_dept))
        {
            $msg.="Order Details edited by ".$po_details[0]->po_edited_dept." <br/>";
            $msg.="<b>New delivery date :".$po_details[0]->po_final_delivery_date."</b><br/>";
        }

        $msg.="Please check your list of product orders to find out more details<br/>";

         $msg.="Thank you!<br/><br/>";

         $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
       
        $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
         	return false;
            //echo $CI->email->print_debugger();
         }              
    }


function send_mail_po_delivery($po_id)
    {
         $CI =& get_instance();
    $CI->load->model('Third_db_model','tm');
       
        $CI->email->initialize(setting());
    $CI->email->from('noreply@birigroup.com','Biri Group');
        
         $po_details=$CI->tm->get_po_details('prd_order',array('po_id'=>$po_id));
         $sales_person=$po_details[0]->po_sales_person;
       
         $sales_info=$CI->tm->get_sales_email(array('log_uname'=>$sales_person));
         $sales_email=$sales_info[0]->log_email;
         $sales_dept=$sales_info[0]->log_dept;
 	//$CI->email->to('support@birigroup.com');
        $CI->email->to($sales_email,$sales_dept);
        $CI->email->cc('production@birigroup.com');
     
             $CI->email->subject('Production Order Numbered #'.$po_details[0]->po_id.' Delivered');
      
         $msg="Dear ".$sales_info[0]->log_uname.",<br/>";
         $msg.="Your order numbered #".$po_details[0]->po_id." is delivered successfully.";
    
         $msg.="Thank you!<br/><br/>";

         $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
       
        $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
         	return false;
           // echo $CI->email->print_debugger();
         }              
    }



 function send_mail_rejected($mail_data)
    {
        $CI =& get_instance();
        $CI->load->model('Admin_model','am');
       
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
    $candidate_details=$CI->am->get_data('jobs_applied',array('jid'=>$mail_data['job_id']));

        $CI->email->to($candidate_details[0]->j_email);
        $CI->email->subject('Application rejected for the position of '.$candidate_details[0]->j_applied);
        $msg="Dear ".$candidate_details[0]->j_candidate.",<br/><br/>";
        $msg.="Thank you so much for your interest in the ".$candidate_details[0]->j_applied." position with Biri Group. We appreciate you taking the time for applying for the job.<br/>";

        if(!empty($mail_data['reason_rej']))
             $msg.=$mail_data['reason_rej']."<br/><br/>";
        else
        $msg.="Unfortunately we have chosen to proceed with another candidate.<br/>";
    
        $msg.="Again, we appreciate your time, and we wish you the best of luck in your career endeavors.<br/><br/>";
         $msg.="Warm Regards, <br/>Biri Group.<br/><br/>";

         $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
       
        $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
        	 return false;
            //echo $CI->email->print_debugger();
         }  
    }
    
    
    function send_approve_mail($po_id)
    {
     $CI =& get_instance();
    $CI->load->model('Third_db_model','tm');
       
        $CI->email->initialize(setting());
    $CI->email->from('noreply@birigroup.com','Biri Group');
        
         $po_details=$CI->tm->get_po_details('prd_order',array('po_id'=>$po_id));
      $sales_info=$CI->tm->get_sales_email(array('log_sub_type'=>'ksa','log_designation'=>'Team-lead'));
      
      // $CI->email->to('support@birigroup.com');
        $CI->email->to($sales_info[0]->log_email);
        $CI->email->subject('Approve Production Order #'.$po_id);
       
        $msg="A new production order is created from staff in KSA. <br/> Approve to send for Production. <br/>";
        
         $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
         $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
         	 return false;
            //echo $CI->email->print_debugger();
         }  
    }
    
    function send_mail_store()
    {
       $CI =& get_instance();   
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
         $CI->email->to('berrystore@birigroup.com');
       //   $CI->email->cc('support@birigroup.com');
        $CI->email->subject('Pending Updation of Product Stock in Dashboard');
       $msg="It is noted that stock in dashboard is not updated for the last 3 days. <br/> Please do the needful to update the same ASAP. If the same is not updated within the next day, another mail will be send to the management. ";
        $msg.="<br/> Product Stock update can be find under , Transactions -> Sales -> Sales Quotation -> Update Product Stock. <br/> (If unable to find, please use the search bar on the top of the sidebar menu.) ";
        $msg.="<br/>This email will be send on every 3rd day from the last day of stock update. The same will be send to the management on the 4th day and henceforth. ";
        $msg.="<br/> Contact IT support for any futher assitance related to dashboard.<br/>";
         $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
         $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
             return false;
            //echo $CI->email->print_debugger();
         }  
    }

    function send_mail_store_mngmnt()
    {
         $CI =& get_instance();   
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
        $CI->email->to('berrystore@birigroup.com');
        $CI->email->cc(array('bayan@birigroup.com'));
        $CI->email->subject('Product Stock - Still Pending Update in Dashboard');
      $msg="Its noted that stock update in dashboard is still pending . It is requested to update the stock ASAP, as this has put in the notice of the management. ";
        $msg.="<br/>Please go through the instructions given in the early mail requesting for stock update. Follow the same steps mentioned. ";
        $msg.="<br/> Contact IT support for any futher assitance related to dashboard.<br/>";
        $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
         $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
             return false;
            //echo $CI->email->print_debugger();
         }  
    }

    function send_mail_stock_staff($mail_data)
    {
        if(!empty($mail_data))
        {
             $CI =& get_instance();   
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
        $sales_team=$CI->Admin_model->get_data('login_credentials',array('log_status'=>'1','log_sub_type'=>'gcc','log_dept'=>'Sales'));
        foreach($sales_team as $st)
        {
            $staff_emails[]="'".$st->log_email."'";
        }
     // print_r(implode(', ',array_filter($staff_emails)));
      $sales_team_email=array(implode(', ',array_filter($staff_emails)));
      $CI->email->to($sales_team_email[0]);
        $CI->email->cc('support@birigroup.com');
        $CI->email->subject('Stock Update- Current stock in warehouse');
         $html="Dear Team,<br/><br/> This is the current stock in our Dubai warehouse as per dashboard data. The quantity may vary as per the sales . 
         For more information or any issue with the stock please contact the warehouse team directly.<br/> ";
            $html.="<small>This is an auto-generated message, please do not reply to this email.</small>";
            $html.='<br/><br/><br/>';
            $html.='<table border="1" align="center"  width="100%">';
            $html.="<tbody><tr>";           
            $html.="<td><b>Code</b></td>";
            $html.="<td><b>Name</b></td>";
            $html.="<td><b>Quantity</b></td>";
            $html.="</tr>";
             
             foreach($mail_data['prd_details'] as $index=>$prd)
             {               
                    $pname=explode('|~~|',$prd[0]->pname);

                        if(!empty($pname[0]))
                        {
                            $prd_names=explode(',',$pname[0]);
                            $product_name=$prd_names[0];
                            //$product_name=$pname[0];
                        }
                        else
                        {
                            $pname=explode(',',$prd[0]->pname);
                            $product_name=$pname[0];
                        }
                       
                $html.="<tr>";
                $html.="<td>".$prd[0]->pcode."</td>";
                $html.="<td>".$product_name."</td>";
                $html.="<td>".$mail_data['result'][$index]->ps_dxb_qnty."</td>";
                $html.="</tr>";
             }
            $html.="</tbody></table>";

             $CI->email->message($html);
             if($CI->email->send())
                return true;
             else
             {
                 return false;
                //echo $CI->email->print_debugger();
             }  
        }
    }


     function mail_item_req_sts_ordred($mail_data)
    {
         $CI =& get_instance();   
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
        $CI->email->to(array('bayan@birigroup.com','procurement@ukrtrading.ae','bayan@ukrtrading.ae'));
        $CI->email->subject('Your Order Ready goods list !!');
        $msg="Good Morning Purchase Team, <br/>
Here is list of Goods you ordered and it should be ready. <br/> 
Please Check your dashboard and take action, Contact supplier check if goods are ready, <br/>
If Supplier goods ready book and arrange the collection and update status with ETA (expected time of arrival / ready to ship). <br/>
If Goods not ready please update sales team and amend ready date on dashboard with reason of delay. <br/>
Please Note that delaying tasks will effect your work performance and employee rating and might effect your bonus/rewarding system. <br/><br/>";
       foreach($mail_data as $m)
        {
        $msg.=$m;
        }
        $msg.="<br/> Contact IT support for any futher assitance related to dashboard.<br/>";
        $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
       
         $CI->email->message($msg);
         if($CI->email->send())
           return true;
         else
         {
             return false;
            //echo $CI->email->print_debugger();
         }  
    }

      function mail_item_req_sts_shipped($mail_data)
    {
         $CI =& get_instance();   
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
        $CI->email->to(array('bayan@birigroup.com','procurement@ukrtrading.ae','bayan@ukrtrading.ae'));
        $CI->email->subject('Your Arrived Goods list');
        $msg="Good Morning Purchase Team, <br/>
Here is list of Goods you Shipped and it should be on warehouse now,<br/>
Please Check your dashboard and take action, Contact Logistic / warehouse team to confirm goods already collected. <br/>
If they collect Make sure that MRN matches with the ordered goods and issue purchase voucher, <br/>
Update the status to completed on dashboard and send email to accounts department with full set of documents, <br/>
If Goods not arrived yet or late keep tracking it.<br/>
Please Note that delaying tasks will effect your work performance and employee rating and might effect your bonus/rewarding system.<br/><br/> ";
       foreach($mail_data as $m)
        {
        $msg.=$m;
        }
        $msg.="<br/> Contact IT support for any futher assitance related to dashboard.<br/>";
        $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
       
         $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
             return false;
            //echo $CI->email->print_debugger();
         }  
    }


    function mail_new_item_req_reminder($mail_data)
    {
        $CI =& get_instance();   
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
       // $CI->email->to(array('support@birigroup.com'));
       $CI->email->to(array('bayan@birigroup.com','procurement@ukrtrading.ae','bayan@ukrtrading.ae','support@birigroup.com'));
        $CI->email->subject('Your Late tasks of Item Request!! Urgent ');
        $msg="Good Morning Purchase Team, <br/>
Here is list of New item request which need your urgent attention!! <br/>
Please Check your dashboard and take action, Accept/Reject and prepare to place the order ASAP <br/>
If you have any issue or missing information contact the issuer or your direct manager .<br/><br/> 
Please Note that you need to Accept or reject any item request within 24 hours from issuing it and delaying tasks will effect your work performance and employee rating and might effect your bonus/rewarding system .<br/><br/> " ;
foreach($mail_data as $m)
   {
        $msg.=$m;
   }
        $msg.="<br/> Contact IT support for any futher assitance related to dashboard.<br/>";
        $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
      // echo $msg;
         $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
             return false;
            //echo $CI->email->print_debugger();
         }  
    }


     function mail_ready_pallet_reminder($mail_data)
    {
        $CI =& get_instance();   
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
       // $CI->email->to(array('support@birigroup.com'));
       $CI->email->to(array('bayan@birigroup.com','procurement@ukrtrading.ae','bayan@ukrtrading.ae','sales@ukrshipping.com','sales2@ukrshipping.com','support@birigroup.com'));
        $CI->email->subject('There is Ready Pallet To Check!! Urgent ');
        $msg="Good Morning Logistic Team, <br/>
Here is list of item request which need your urgent attention!! <br/>
Please Check your dashboard and take action,<br/>
If you have any issue or missing information contact the issuer or your direct manager .<br/><br/> 
Please Note that you need to take action within 24 hours from issuing it and delaying tasks will effect your work performance and employee rating and might effect your bonus/rewarding system .<br/><br/> " ;
foreach($mail_data as $m)
   {
        $msg.=$m;
   }
        $msg.="<br/> Contact IT support for any futher assitance related to dashboard.<br/>";
        $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
      // echo $msg;
         $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
             return false;
            //echo $CI->email->print_debugger();
         }  
    }

    function send_quot_approval_mail_mngt_stamp_sign($qid)
    {
        $CI =& get_instance();   
        $CI->email->initialize(setting());
        $quot_details=$CI->Admin_model->get_data('qoutattion_entry',array('q_id'=>$qid));
        $CI->email->from('noreply@birigroup.com','Biri Group');
        // $CI->email->to('support@birigroup.com');
        $CI->email->to('bayan@birigroup.com');
      //   $CI->email->cc('support@birigroup.com');
        $CI->email->subject('Request Approval for Showing Company Stamp and Signature # '. $quot_details[0]->q_ref_no);
      $msg="Requesting approval to show Stamp and Signature in quotation by ".$quot_details[0]->q_user_id." , for quotation numbered #".$quot_details[0]->q_ref_no." . Please take the next step for this request in dashboard, where you can find this request in `ACTIONS`-> `APPROVE REQUEST` inside List Quotations. <br/><br/> ";
       $msg.="<br/> Contact IT support for any futher assitance related to dashboard.<br/>";
        $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
       
         $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
             return false;
            //echo $CI->email->print_debugger();
         }  
    }

    function send_proforma_approval_mail_mngt_stamp_sign($qid)
    {
        $CI =& get_instance();   
        $CI->email->initialize(setting());
        $quot_details=$CI->Admin_model->get_data('qoutattion_entry',array('q_id'=>$qid));
        $CI->email->from('noreply@birigroup.com','Biri Group');
        // $CI->email->to('support@birigroup.com');
        $CI->email->to('bayan@birigroup.com');
      //  $CI->email->cc('support@birigroup.com');
        $CI->email->subject('Request Approval for Showing Company Stamp and Signature in Proforma # '. $quot_details[0]->q_ref_no);
      $msg="Requesting approval to show Stamp and Signature in Proforma by ".$quot_details[0]->q_user_id." , for Proforma numbered #".$quot_details[0]->q_ref_no." . Please take the next step for this request in dashboard, where you can find this request in `ACTIONS`-> `APPROVE REQUEST` inside List Proforma. <br/><br/> ";
       $msg.="<br/> Contact IT support for any futher assitance related to dashboard.<br/>";
        $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
       
         $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
             return false;
            //echo $CI->email->print_debugger();
         }  
    }

    function send_mail_req_accept($qid,$type)
    {
         $CI =& get_instance();   
        $CI->email->initialize(setting());
        $quot_details=$CI->Admin_model->get_data('qoutattion_entry',array('q_id'=>$qid));
        $sales_detail=$CI->Admin_model->get_data('login_credentials',array('log_uname'=>$quot_details[0]->q_user_id));
        $CI->email->from('noreply@birigroup.com','Biri Group');
         //$CI->email->to('support@birigroup.com');
        $CI->email->to(sales_detail[0]->log_email);
      //  $CI->email->cc('support@birigroup.com');
        if($type=="approve")
         {
        $CI->email->subject('Request Approved for Showing Company Stamp and Signature # '. $quot_details[0]->q_ref_no);
        $msg="Your request to print Stamp and Signature for quotation numbered #".$quot_details[0]->q_ref_no." is approved by management . Now generate PDF for the same, from List Quotations. <br/><br/> ";
        }
        else
        {
             $CI->email->subject('Request Declined for Showing Company Stamp and Signature # '. $quot_details[0]->q_ref_no);
        $msg="Your request to print Stamp and Signature for quotation numbered #".$quot_details[0]->q_ref_no." is declined by management.<br/><br/> ";
        }
       $msg.="<br/> Contact IT support for any futher assitance related to dashboard.<br/>";
        $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
       
         $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
             return false;
            //echo $CI->email->print_debugger();
         }  
    }

    function send_mail_req_accept_porforma($qid,$type)
    {
        $CI =& get_instance();   
        $CI->email->initialize(setting());
        $quot_details=$CI->Admin_model->get_data('qoutattion_entry',array('q_id'=>$qid));
        $sales_detail=$CI->Admin_model->get_data('login_credentials',array('log_uname'=>$quot_details[0]->q_user_id));
        $CI->email->from('noreply@birigroup.com','Biri Group');
        // $CI->email->to('support@birigroup.com');
        $CI->email->to(sales_detail[0]->log_email);
        // $CI->email->cc('support@birigroup.com');
        if($type=="approve")
         {
       $CI->email->subject('Request Approved for Showing Company Stamp and Signature # '. $quot_details[0]->q_ref_no);
        $msg="Your request to print Stamp and Signature for Proforma numbered #".$quot_details[0]->q_ref_no." is approved by management . Now generate PDF for the same, from List Proforma. <br/><br/> ";
        }
        else
        {
             $CI->email->subject('Request Declined for Showing Company Stamp and Signature # '. $quot_details[0]->q_ref_no);
        $msg="Your request to print Stamp and Signature for Proforma numbered #".$quot_details[0]->q_ref_no." is declined by management.<br/><br/> ";
        }
        
       $msg.="<br/> Contact IT support for any futher assitance related to dashboard.<br/>";
        $msg.="<small>This is an auto-generated message, please do not reply to this email.</small>";
       
         $CI->email->message($msg);
         if($CI->email->send())
            return true;
         else
         {
             return false;
            //echo $CI->email->print_debugger();
         }  
    }

 function mail_visitors($msg,$email)
    {
         $CI =& get_instance();   
        $CI->email->initialize(setting());
        $CI->email->from('noreply@birigroup.com','Biri Group');
         $CI->email->to($email);
         $CI->email->subject('Thank you for visiting us - Biri Group');
          $CI->email->message($msg);
                 if($CI->email->send())
                    return true;
                 else
                 {
                     return false;
                    //echo $CI->email->print_debugger();
                 }  
    }













}