<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
{

function pre_list($array_to_print)
{
$value=print_r("<pre>");
$value.=print_r($array_to_print);
$value.=print_r("</pre>");
return $value;
}


function prd_slug($job_title)
{
	 
	 $specialchar = array("9#39;","!", "-", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_","+", "=", "|", "/\/", "/", ".", '"', ",", "'", ":", ";", ",", "~", "`" ,"]", "[", "}", "{", "?");
		 $title = str_replace($specialchar, "", $job_title);
		 $title = str_replace(" ", "-", $title);
		 return $title;
}


function update_bal_amount($insert_id=null,$fun=null)
{


	$CI =& get_instance();
	
	$CI->load->model('Admin_model');

	$bal_amount=$CI->Admin_model->get_data('account_entry1',array('ae_id'=>$insert_id));
	$base_opening_amount=$bal_amount[0]->ae_bal_amount;
	$bank_name=$bal_amount[0]->ae_bank;
	$bank_date=$bal_amount[0]->ae_date;

	$order_by=('ae_date');
			$order_type="ASC";
	$all_bal_aftr_date=$CI->Admin_model->get_data('account_entry1',array('ae_date >'=>$bank_date,'ae_bank'=>$bank_name,'ae_desc !='=>'Opening Balances','ae_status'=>'1'),'','',$order_by,$order_type);

	$j=1;
	$new_bal_amount='';
	
	foreach($all_bal_aftr_date as $t)
	{
	
		if(!empty($base_opening_amount) && ($j==1))
					{
						if($t->ae_cash_type=="Spend")
							$new_bal_amount=$base_opening_amount-$t->ae_amount;
						else
							$new_bal_amount=$base_opening_amount+$t->ae_amount;
						
					}
				elseif(!empty($new_bal_amount) && ($j>1))
					{
					
						if($t->ae_cash_type=="Spend")
						$new_bal_amount=$new_bal_amount-$t->ae_amount;
							else
						$new_bal_amount=$new_bal_amount+$t->ae_amount;
					}
					else
					{
						$new_bal_amount='';
						$base_opening_amount='';
					}
					//echo $base_opening_amount;
					//echo "<br/>";
			//echo "<pre>";
			//print_r($new_bal_amount);
			//echo "</pre>";		
		// $data1=array('ae_bal_amount'=>$new_bal_amount);
  //       $cond1=array('ae_id'=>$t->ae_id,'ae_status'=>'1');
		// $CI->Admin_model->update_data('account_entry1',$data1,$cond1);
		 $j++;		 
	}
if(empty($fun))
return true;
elseif(!empty($new_bal_amount))
return $new_bal_amount;
else
return false;
}



function update_bank_bal()
{
	$CI =& get_instance();
		$CI->load->library('session');

$bank=$CI->session->userdata['bal_update']['bank_name_updated'];

$j=1;
	$cond_new=array('ae_bank'=>$bank,'ae_status'=>'1');
		$opening_bal_bbms=$CI->Admin_model->get_opening_bal($cond_new);
	$base_opening_amount=$opening_bal_bbms[0]->ae_amount;
	
			$order_by='ae_date';
			$order_type="ASC";
	$data_amount=$CI->Admin_model->get_data('account_entry1',array('ae_bank'=>$bank,'ae_desc !='=>'Opening Balances','ae_status'=>'1'),'','',$order_by,$order_type);

	foreach($data_amount as $t)
	{		
		if(!empty($base_opening_amount) && ($j==1))
				{
					if($t->ae_cash_type=="Spend")
						$new_bal_amount=$base_opening_amount-$t->ae_amount;
					else
						$new_bal_amount=$base_opening_amount+$t->ae_amount;

					
				}
			elseif(!empty($new_bal_amount) && ($j>1))
				{
					if($t->ae_cash_type=="Spend")
					$new_bal_amount=$new_bal_amount-$t->ae_amount;
						else
					$new_bal_amount=$new_bal_amount+$t->ae_amount;
				}
				else
				{
					$new_bal_amount='';
					$base_opening_amount='';
				}

				// echo "<pre>";
				// print_r($base_opening_amount.'-"'.$t->ae_bank.'"-``'.$t->ae_date.'``-!!'.$t->ae_amount.'!!'.$new_bal_amount);
				// echo "</pre>";
				$data1=array('ae_bal_amount'=>$new_bal_amount);
		        $cond1=array('ae_id'=>$t->ae_id,'ae_status'=>'1');
				$CI->Admin_model->update_data('account_entry1',$data1,$cond1);
				$j++;				
	}
	$session_data = 
	array(
			'bank_name_updated' => '',
		);
	$CI->session->unset_userdata('bal_update',$session_data);	
	return true;


}

function fund_tx_bal_update()
{
	$CI =& get_instance();
		$CI->load->library('session');

$bank1=$CI->session->userdata['bal_update2']['credit_bank'];
$bank2=$CI->session->userdata['bal_update2']['debit_bank'];
$j=1;
	$cond_new=array('ae_bank'=>$bank1,'ae_status'=>'1');
	$opening_bal_bbms=$CI->Admin_model->get_opening_bal($cond_new);
	$base_opening_amount=$opening_bal_bbms[0]->ae_amount;
	
			$order_by='ae_date';
			$order_type="ASC";
	$data_amount=$CI->Admin_model->get_data('account_entry1',array('ae_bank'=>$bank1,'ae_desc !='=>'Opening Balances','ae_status'=>'1'),'','',$order_by,$order_type);

	foreach($data_amount as $t)
	{		
		if(!empty($base_opening_amount) && ($j==1))
				{
					if($t->ae_cash_type=="Spend")
						$new_bal_amount=$base_opening_amount-$t->ae_amount;
					else
						$new_bal_amount=$base_opening_amount+$t->ae_amount;

					
				}
			elseif(!empty($new_bal_amount) && ($j>1))
				{
					if($t->ae_cash_type=="Spend")
					$new_bal_amount=$new_bal_amount-$t->ae_amount;
						else
					$new_bal_amount=$new_bal_amount+$t->ae_amount;
				}
				else
				{
					$new_bal_amount='';
					$base_opening_amount='';
				}

				// echo "<pre>";
				// print_r($base_opening_amount.'-"'.$t->ae_bank.'"-``'.$t->ae_date.'``-!!'.$t->ae_amount.'!!'.$new_bal_amount);
				// echo "</pre>";
				$data1=array('ae_bal_amount'=>$new_bal_amount);
		        $cond1=array('ae_id'=>$t->ae_id,'ae_status'=>'1');
				$CI->Admin_model->update_data('account_entry1',$data1,$cond1);
				$j++;				
	}


//////////////////here start the update for bank2/////////
	$k=1;
	$cond_new2=array('ae_bank'=>$bank2,'ae_status'=>'1');
	$opening_bal=$CI->Admin_model->get_opening_bal($cond_new2);
	$base_opening_amount2=$opening_bal[0]->ae_amount;

	$data_amount2=$CI->Admin_model->get_data('account_entry1',array('ae_bank'=>$bank2,'ae_desc !='=>'Opening Balances','ae_status'=>'1'),'','',$order_by,$order_type);

	foreach($data_amount2 as $t)
	{		
		if(!empty($base_opening_amount2) && ($k==1))
				{
					if($t->ae_cash_type=="Spend")
						$new_bal_amount2=$base_opening_amount2-$t->ae_amount;
					else
						$new_bal_amount2=$base_opening_amount2+$t->ae_amount;

					
				}
			elseif(!empty($new_bal_amount2) && ($k>1))
				{
					if($t->ae_cash_type=="Spend")
					$new_bal_amount2=$new_bal_amount2-$t->ae_amount;
						else
					$new_bal_amount2=$new_bal_amount2+$t->ae_amount;
				}
				else
				{
					$new_bal_amount2='';
					$base_opening_amount2='';
				}

				// echo "<pre>";
				// print_r($base_opening_amount.'-"'.$t->ae_bank.'"-``'.$t->ae_date.'``-!!'.$t->ae_amount.'!!'.$new_bal_amount);
				// echo "</pre>";
				$data2=array('ae_bal_amount'=>$new_bal_amount2);
		        $cond2=array('ae_id'=>$t->ae_id,'ae_status'=>'1');
				$CI->Admin_model->update_data('account_entry1',$data2,$cond2);
				$k++;				
	}

///////// ////////unset both the session here//////////////
		$session_data = 
	array(
			'credit_bank' => '',
			'debit_bank' => '',

		);
	$CI->session->unset_userdata('bal_update2',$session_data);
	return true;


}



function get_date_time()
{
	$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
return $dt->format('Y-m-d H:i:s');

}

function get_date()
{
	$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
return $dt->format('Y-m-d');

}


function get_time()
{
	$tz = 'Asia/Dubai'; // your required location time zone.
$timestamp = time();
$dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
$dt->setTimestamp($timestamp);
return $dt->format('H:i:s');

}











}