<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
{

function make_datatables($where = null, $where_in = null)
{
    $CI =& get_instance();
    $CI->load->model('datatables');
    $CI->datatables->make_query();

    if (!empty($where)) {
        $CI->db->where($where);
    }
    if (!empty($where_in)) {
        $CI->db->where_in($where_in[0], $where_in[1]);
    }
    if ($_POST["length"] != -1) {
        $CI->db->limit($_POST['length'], $_POST['start']);
    }
    $query = $CI->db->get();
    return $query->result();
}

function render_table($data, $where = null, $where_in = null)
{
    $CI =& get_instance();
    $CI->load->model('datatables');
    $output = array(
        "draw" => intval($_POST["draw"]),
        "recordsTotal" => $CI->datatables->get_all_data($where, $where_in),
        "recordsFiltered" => $CI->datatables->get_filtered_data($where, $where_in),
        "data" => $data
    );
      echo json_encode($output);
     exit();
}











































    
}?>