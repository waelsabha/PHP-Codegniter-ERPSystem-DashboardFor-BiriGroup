<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 {
 	function logged_in()
	{
		$CI =& get_instance();
		//$CI->load->library('session');
		
		if ($CI->session->userdata('user')) {
		
			// $CI->session->unset_userdata('center_log',null);
				// $CI->session->unset_userdata('student_log',null);
		return TRUE;
		}
		else{
			$session_data = array(
								'username' => '',
								'role'=> '',
								'main_dept'=>'',
								'user_email'=>'',
								'user_desig'=>'',
								'sub_dept'=>'',
								'user_position'=>'',
								
							);
			$CI->session->unset_userdata('user',$session_data);
			$CI->session->sess_destroy();	
		redirect('logout','refresh');
		}
	}
	
	
 }		