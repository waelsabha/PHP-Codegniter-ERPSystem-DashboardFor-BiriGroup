<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
{


function insert_prd_sales_vochuer()
{
	$CI =& get_instance();
	$CI->load->library('session');
	$CI->load->model('Admin_model');

$prd=$CI->session->userdata('prd_info');
	if(!empty($prd))
	{
		foreach ($prd as $p) {
		$data=array(
			'sbp_vochure_no'=>$p['vochuer_id'],
			'sbp_prd_name'=>$p['name_en'],
			'sbp_prd_code'=>$p['pcode'],
			'sbp_qty'=>$p['qty'],
			'sbp_rate'=>$p['rate'],
			'sbp_gross'=>$p['gross'],
			'sbp_grs_uae'=>$p['grs_uae'],
			'sbp_vat'=>$p['vat'],
			'sbp_ar_name'=>$p['name_ar'],
			'sbp_ar_category'=>$p['cat'],
			'sbp_ar_sts'=>'1',
			);
		$insert_id=$CI->Admin_model->insert_data("sales_book_product", $data);
		}
	}
	$session_data = array(
			'vochuer_id' => '',
			'name_en'=>'',
			'pcode'=>'',
			'qty'=>'',
			'rate'=>'',
			'gross'=>'',
			'grs_uae'=>'',
			'vat'=>'',
			'name_ar'=>'',
			'cat'=>'',
		);
	$CI->session->set_userdata('prd_info',$session_data);	
	$CI->session->unset_userdata('prd_info');
	return true;
}

















}

