<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 {    
 	function setting_survey()
    {
         $CI =& get_instance();
        $CI->load->library('email');
        //  $config['protocol'] = "smtp";
        $config['mailpath']     = "/usr/bin/sendmail";
          $config['protocol'] = "smtp";
         $config['smtp_host'] = 'smtp.ionos.com';
         $config['smtp_port'] = '587';
         $config['smtp_user'] = 'noreply@birigroup.com';
         $config['smtp_pass'] = 'Noreply@000';

         $config['mailtype'] = 'html';
         $config['charset'] = 'utf-8';
         $config['newline'] = "\r\n";
         $config['crlf'] = "\r\n";
         $config['wordwrap'] = TRUE;
         return $config;       
    }

function send_mail_survey($survey_id,$type)
{
	$CI =& get_instance();
    $CI->load->model('Third_db_model','tm');
    $CI->load->model('Admin_model','am');
          
    $CI->email->initialize(setting_survey());
    $CI->email->from('noreply@birigroup.com','Biri Group');
    $CI->email->to('projects@birigroup.com');
   // $CI->email->cc('bahjat@birigroup.com');
     //    $CI->email->to('support@birigroup.com');

$survey_details=$CI->Admin_model->get_data('survey_table',array('st_id'=>$survey_id));
$prd_set_details=$CI->Admin_model->get_data('product_set_data',array('psd_survey_id'=>$survey_id));

         if($type=="new")
    $CI->email->subject('New Survey Request #'.$survey_details[0]->st_survey_no);
else
	 $CI->email->subject('Survey Request Updated#'.$survey_details[0]->st_survey_no);

	 $html='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta name="x-apple-disable-message-reformatting">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="telephone=no" name="format-detection">
    <title></title>
    <!--[if (mso 16)]>
    <style type="text/css">
    a {text-decoration: none;}
    </style>
    <![endif]-->
    <!--[if gte mso 9]><style>sup { font-size: 100% !important; }</style><![endif]-->
    <!--[if gte mso 9]>
<xml>
    <o:OfficeDocumentSettings>
    <o:AllowPNG></o:AllowPNG>
    <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
</xml>
<![endif]-->
<style type="text/css">
    /* CONFIG STYLES Please do not delete and edit CSS styles below */
/* IMPORTANT THIS STYLES MUST BE ON FINAL EMAIL */
#outlook a {
    padding: 0;
}

.ExternalClass {
    width: 100%;
}

.ExternalClass,
.ExternalClass p,
.ExternalClass span,
.ExternalClass font,
.ExternalClass td,
.ExternalClass div {
    line-height: 100%;
}

.es-button {
    mso-style-priority: 100 !important;
    text-decoration: none !important;
}

a[x-apple-data-detectors] {
    color: inherit !important;
    text-decoration: none !important;
    font-size: inherit !important;
    font-family: inherit !important;
    font-weight: inherit !important;
    line-height: inherit !important;
}

.es-desk-hidden {
    display: none;
    float: left;
    overflow: hidden;
    width: 0;
    max-height: 0;
    line-height: 0;
    mso-hide: all;
}

td .es-button-border:hover a.es-button-1556804085234 {
    background: #7dbf44 !important;
    border-color: #7dbf44 !important;
}

td .es-button-border-1556804085253:hover {
    background: #7dbf44 !important;
}

.es-button-border:hover a.es-button {
    background: #7dbf44 !important;
    border-color: #7dbf44 !important;
}

.es-button-border:hover {
    background: #7dbf44 !important;
    border-color: #7dbf44 #7dbf44 #7dbf44 #7dbf44 !important;
}

td .es-button-border:hover a.es-button-1556806949166 {
    background: #7dbf44 !important;
    border-color: #7dbf44 !important;
}

td .es-button-border-1556806949166:hover {
    background: #7dbf44 !important;
}

/*
END OF IMPORTANT
*/
s {
    text-decoration: line-through;
}

html,
body {
    width: 100%;
    font-family: arial, "helvetica neue", helvetica, sans-serif;
    -webkit-text-size-adjust: 100%;
    -ms-text-size-adjust: 100%;
}

table {
    mso-table-lspace: 0pt;
    mso-table-rspace: 0pt;
    border-collapse: collapse;
    border-spacing: 0px;
}

table td,
html,
body,
.es-wrapper {
    padding: 0;
    Margin: 0;
}

.es-content,
.es-header,
.es-footer {
    table-layout: fixed !important;
    width: 100%;
}

img {
    display: block;
    border: 0;
    outline: none;
    text-decoration: none;
    -ms-interpolation-mode: bicubic;
}

table tr {
    border-collapse: collapse;
}

p,
hr {
    Margin: 0;
}

h1,
h2,
h3,
h4,
h5 {
    Margin: 0;
    line-height: 120%;
    mso-line-height-rule: exactly;
    font-family: arial, "helvetica neue", helvetica, sans-serif;
}

p,
ul li,
ol li,
a {
    -webkit-text-size-adjust: none;
    -ms-text-size-adjust: none;
    mso-line-height-rule: exactly;
}

.es-left {
    float: left;
}

.es-right {
    float: right;
}

.es-p5 {
    padding: 5px;
}

.es-p5t {
    padding-top: 5px;
}

.es-p5b {
    padding-bottom: 5px;
}

.es-p5l {
    padding-left: 5px;
}

.es-p5r {
    padding-right: 5px;
}

.es-p10 {
    padding: 10px;
}

.es-p10t {
    padding-top: 10px;
}

.es-p10b {
    padding-bottom: 10px;
}

.es-p10l {
    padding-left: 10px;
}

.es-p10r {
    padding-right: 10px;
}

.es-p15 {
    padding: 15px;
}

.es-p15t {
    padding-top: 15px;
}

.es-p15b {
    padding-bottom: 15px;
}

.es-p15l {
    padding-left: 15px;
}

.es-p15r {
    padding-right: 15px;
}

.es-p20 {
    padding: 20px;
}

.es-p20t {
    padding-top: 20px;
}

.es-p20b {
    padding-bottom: 20px;
}

.es-p20l {
    padding-left: 20px;
}

.es-p20r {
    padding-right: 20px;
}

.es-p25 {
    padding: 25px;
}

.es-p25t {
    padding-top: 25px;
}

.es-p25b {
    padding-bottom: 25px;
}

.es-p25l {
    padding-left: 25px;
}

.es-p25r {
    padding-right: 25px;
}

.es-p30 {
    padding: 30px;
}

.es-p30t {
    padding-top: 30px;
}

.es-p30b {
    padding-bottom: 30px;
}

.es-p30l {
    padding-left: 30px;
}

.es-p30r {
    padding-right: 30px;
}

.es-p35 {
    padding: 35px;
}

.es-p35t {
    padding-top: 35px;
}

.es-p35b {
    padding-bottom: 35px;
}

.es-p35l {
    padding-left: 35px;
}

.es-p35r {
    padding-right: 35px;
}

.es-p40 {
    padding: 40px;
}

.es-p40t {
    padding-top: 40px;
}

.es-p40b {
    padding-bottom: 40px;
}

.es-p40l {
    padding-left: 40px;
}

.es-p40r {
    padding-right: 40px;
}

.es-menu td {
    border: 0;
}

.es-menu td a img {
    display: inline-block !important;
}

/* END CONFIG STYLES */
a {
    font-family: arial, "helvetica neue", helvetica, sans-serif;
    font-size: 14px;
    text-decoration: none;
}

h1 {
    font-size: 30px;
    font-style: normal;
    font-weight: normal;
    color: #ffc246;
}

h1 a {
    font-size: 30px;
}

h2 {
    font-size: 26px;
    font-style: normal;
    font-weight: bold;
    color: #ffc246;
}

h2 a {
    font-size: 26px;
}

h3 {
    font-size: 22px;
    font-style: normal;
    font-weight: normal;
    color: #ffc246;
}

h3 a {
    font-size: 22px;
}

p,
ul li,
ol li {
    font-size: 14px;
    font-family: arial, "helvetica neue", helvetica, sans-serif;
    line-height: 150%;
}

ul li,
ol li {
    Margin-bottom: 15px;
}

.es-menu td a {
    text-decoration: none;
    display: block;
}

.es-wrapper {
    width: 100%;
    height: 100%;
    background-image: ;
    background-repeat: repeat;
    background-position: center top;
}

.es-wrapper-color {
    background-color: #f6f6f6;
}

.es-content-body {
    background-color: #ffffff;
}

.es-content-body p,
.es-content-body ul li,
.es-content-body ol li {
    color: #333333;
}

.es-content-body a {
    color: #ffc246;
}

.es-header {
    background-color: transparent;
    background-image: ;
    background-repeat: repeat;
    background-position: center top;
}

.es-header-body {
    background-color: #ffffff;
}

.es-header-body p,
.es-header-body ul li,
.es-header-body ol li {
    color: #ffc246;
    font-size: 16px;
}

.es-header-body a {
    color: #ffc246;
    font-size: 16px;
}

.es-footer {
    background-color: transparent;
    background-image: ;
    background-repeat: repeat;
    background-position: center top;
}

.es-footer-body {
    background-color: transparent;
}

.es-footer-body p,
.es-footer-body ul li,
.es-footer-body ol li {
    color: #ffffff;
    font-size: 14px;
}

.es-footer-body a {
    color: #ffffff;
    font-size: 14px;
}

.es-infoblock,
.es-infoblock p,
.es-infoblock ul li,
.es-infoblock ol li {
    line-height: 120%;
    font-size: 12px;
    color: #cccccc;
}

.es-infoblock a {
    font-size: 12px;
    color: #cccccc;
}

a.es-button {
    border-style: solid;
    border-color: #ffc246;
    border-width: 10px 20px 10px 20px;
    display: inline-block;
    background: #ffc246;
    border-radius: 0px;
    font-size: 18px;
    font-family: arial, "helvetica neue", helvetica, sans-serif;
    font-weight: normal;
    font-style: normal;
    line-height: 120%;
    color: #ffffff;
    text-decoration: none;
    width: auto;
    text-align: center;
}

.es-button-border {
    border-style: solid solid solid solid;
    border-color: #ffc246 #ffc246 #ffc246 #ffc246;
    background: #ffc246;
    border-width: 0px 0px 0px 0px;
    display: inline-block;
    border-radius: 0px;
    width: auto;
}

/* RESPONSIVE STYLES Please do not delete and edit CSS styles below. If you dont need responsive layout, please delete this section. */
@media only screen and (max-width: 600px) {

    p,
    ul li,
    ol li,
    a {
        font-size: 14px !important;
        line-height: 150% !important;
    }

    h1 {
        font-size: 30px !important;
        text-align: center;
        line-height: 120% !important;
    }

    h2 {
        font-size: 22px !important;
        text-align: center;
        line-height: 120% !important;
    }

    h3 {
        font-size: 20px !important;
        text-align: center;
        line-height: 120% !important;
    }

    h1 a {
        font-size: 30px !important;
    }

    h2 a {
        font-size: 22px !important;
    }

    h3 a {
        font-size: 20px !important;
    }

    .es-menu td a {
        font-size: 16px !important;
    }

    .es-header-body p,
    .es-header-body ul li,
    .es-header-body ol li,
    .es-header-body a {
        font-size: 16px !important;
    }

    .es-footer-body p,
    .es-footer-body ul li,
    .es-footer-body ol li,
    .es-footer-body a {
        font-size: 14px !important;
    }

    .es-infoblock p,
    .es-infoblock ul li,
    .es-infoblock ol li,
    .es-infoblock a {
        font-size: 12px !important;
    }

    *[class="gmail-fix"] {
        display: none !important;
    }

    .es-m-txt-c,
    .es-m-txt-c h1,
    .es-m-txt-c h2,
    .es-m-txt-c h3 {
        text-align: center !important;
    }

    .es-m-txt-r,
    .es-m-txt-r h1,
    .es-m-txt-r h2,
    .es-m-txt-r h3 {
        text-align: right !important;
    }

    .es-m-txt-l,
    .es-m-txt-l h1,
    .es-m-txt-l h2,
    .es-m-txt-l h3 {
        text-align: left !important;
    }

    .es-m-txt-r img,
    .es-m-txt-c img,
    .es-m-txt-l img {
        display: inline !important;
    }

    .es-button-border {
        display: block !important;
    }

    a.es-button {
        font-size: 20px !important;
        display: block !important;
        border-left-width: 0px !important;
        border-right-width: 0px !important;
    }

    .es-btn-fw {
        border-width: 10px 0px !important;
        text-align: center !important;
    }

    .es-adaptive table,
    .es-btn-fw,
    .es-btn-fw-brdr,
    .es-left,
    .es-right {
        width: 100% !important;
    }

    .es-content table,
    .es-header table,
    .es-footer table,
    .es-content,
    .es-footer,
    .es-header {
        width: 100% !important;
        max-width: 600px !important;
    }

    .es-adapt-td {
        display: block !important;
        width: 100% !important;
    }

    .adapt-img {
        width: 100% !important;
        height: auto !important;
    }

    .es-m-p0 {
        padding: 0px !important;
    }

    .es-m-p0r {
        padding-right: 0px !important;
    }

    .es-m-p0l {
        padding-left: 0px !important;
    }

    .es-m-p0t {
        padding-top: 0px !important;
    }

    .es-m-p0b {
        padding-bottom: 0 !important;
    }

    .es-m-p20b {
        padding-bottom: 20px !important;
    }

    .es-mobile-hidden,
    .es-hidden {
        display: none !important;
    }

    tr.es-desk-hidden,
    td.es-desk-hidden,
    table.es-desk-hidden {
        width: auto !important;
        overflow: visible !important;
        float: none !important;
        max-height: inherit !important;
        line-height: inherit !important;
    }

    tr.es-desk-hidden {
        display: table-row !important;
    }

    table.es-desk-hidden {
        display: table !important;
    }

    td.es-desk-menu-hidden {
        display: table-cell !important;
    }

    .es-menu td {
        width: 1% !important;
    }

    table.es-table-not-adapt,
    .esd-block-html table {
        width: auto !important;
    }

    table.es-social {
        display: inline-block !important;
    }

    table.es-social td {
        display: inline-block !important;
    }
}

/* END RESPONSIVE STYLES */
</style>
</head>

<body>
    <div class="es-wrapper-color">
        <!--[if gte mso 9]>
            <v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
                <v:fill type="tile" color="#f6f6f6"></v:fill>
            </v:background>
        <![endif]-->
        <table class="es-wrapper" width="100%" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td class="esd-email-paddings" valign="top">
                      
                        <table cellpadding="0" cellspacing="0" class="es-header" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" align="center" esd-custom-block-id="88656">
                                        <table class="es-header-body" width="600" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p20t es-p10b es-p20r es-p20l" style="background-position: center center;" align="left">
                                                        <!--[if mso]><table width="560" cellpadding="0" cellspacing="0"><tr><td width="270" valign="top"><![endif]-->
                                                        <table class="es-left" cellspacing="0" cellpadding="0" align="left">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="es-m-p20b esd-container-frame" width="270" align="left">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-image es-p5b" align="left" style="font-size:0"><a target="_blank" href="https://birigroup.com/"><img src="https://www.birigroup.com/temp_styles/assets/img/logo/Biri%20Group%20Logo-01.png" alt style="display: block;" class="adapt-img" width="125"></a></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td><td width="20"></td><td width="270" valign="top"><![endif]-->
                                                        <table class="es-right" cellspacing="0" cellpadding="0" align="right">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="270" align="left">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-menu">
                                                                                        <table class="es-menu" width="100%" cellspacing="0" cellpadding="0">
                                                                                            <tbody>
                                                                                                <tr class="links">
                                                                                                    <td class="es-p10t es-p10b es-p5r es-p5l" style="padding-bottom: 10px; padding-top: 10px; " width="33.33%" valign="top" bgcolor="transparent" align="center">
                                                                                                        Survey Details
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td></tr></table><![endif]-->
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table cellpadding="0" cellspacing="0" class="es-content" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" align="center">
                                        <table bgcolor="#ffffff" class="es-content-body" align="center" cellpadding="0" cellspacing="0" width="600">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure" align="left" style="background-position: center top;" esd-custom-block-id="44739">
                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="600" class="esd-container-frame" align="center" valign="top">
                                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                                            <tbody>
                                                                                <tr>
                                                                                   <td class="esd-block-image es-p25t es-p25b es-p35r es-p35l esd-frame esd-hover esdev-disable-select esd-draggable esd-block" align="center" style="font-size:0" esd-handler-name="imgBlockHandler">
                      
        
        
                <div class="esd-block-btn ">
                    <div class="esd-more"><a><span class="es-icon-dot-3"></span></a></div>
                    
                    
                    <div class="esd-move ui-draggable-handle" title="Move">
                        <a><span class="es-icon-move"></span></a>
                    </div>
                    <div class="esd-copy ui-draggable-handle" title="Copy">
                        <a><span class="es-icon-copy"></span></a>
                    </div>
                    <div class="esd-delete" title="Delete">
                        <a><span class="es-icon-delete"></span></a>
                    </div>
                </div>
                <img src="'.base_url('png_img/new_request.jpg').'" width="150" height="150"></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table cellpadding="0" cellspacing="0" class="es-content" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" align="center" esd-custom-block-id="44757">
                                        <table bgcolor="#ffffff" class="es-content-body" align="center" cellpadding="0" cellspacing="0" width="600">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p20t es-p20r es-p20l" align="left" style="background-position: center top;" esd-custom-block-id="44741">
                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="560" class="esd-container-frame" align="center" valign="top">
                                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center" class="esd-block-text">
                                                                                        <h2 style="color: #ffc246;">'.$order_sts.'</h2>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td align="center" class="esd-block-text es-p10t">
                                                                                        <p>'.$msg_to_use.'</p>
                                                                                    </td>
                                                                                </tr>
                                                                              
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="esd-structure es-p20t es-p10b es-p20r es-p20l" align="left" style="background-position: center top;" esd-custom-block-id="44742">
                                                        <!--[if mso]><table width="560" cellpadding="0" cellspacing="0"><tr><td width="280" valign="top"><![endif]-->
                                                        <table class="es-left" cellspacing="0" cellpadding="0" align="left">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="es-m-p20b esd-container-frame" width="280" align="left">
                                                                        <table style="border-left:1px solid transparent;border-top:1px solid transparent;border-bottom:1px solid transparent;background-color: #efefef; border-collapse: separate; background-position: center top;" width="100%" cellspacing="0" cellpadding="0" bgcolor="#efefef">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20t es-p10b es-p20r es-p20l" align="left">
                                                                                        <h4 style="color: #ffc246;">SUMMARY:</h4>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20b es-p20r es-p20l" align="left">
                                                                                        <table style="width: 100%;" class="cke_show_border" cellspacing="1" cellpadding="1" border="0" align="left">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td style="font-size: 14px; line-height: 150%;">Survey Number #:</td>
                                                                                                    <td><strong><span style="font-size: 14px; line-height: 150%;">'.$survey_details[0]->st_survey_no.'</span></strong></td>
                                                                                                </tr>
                                                                                               
                                                                                                <tr>
                                                                                                    <td style="font-size: 14px; line-height: 150%;"><b>Created by:</b></td>
                                                                                                    <td><strong><span style="font-size: 14px; line-height: 150%;">'.$survey_details[0]->st_user_created.'</span></strong></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td style="font-size: 14px; line-height: 150%;">Cordinates:</td>
                                                                                                    <td><strong><span style="font-size: 14px; line-height: 150%;">'.$survey_details[0]->st_start_cordinate.' , '.$survey_details[0]->st_end_cordinate.'</span></strong></td>
                                                                                                </tr>
                                                                                                 <tr>
                                                                                                    <td style="font-size: 14px; line-height: 150%;">Departments:</td>
                                                                                                    <td><strong><span style="font-size: 14px; line-height: 150%;">'.$survey_details[0]->st_dept_po.' <br/>';
                                                                                                   if(!empty($survey_details[0]->st_dept_installation))
                                                                                                   	$html.=$survey_details[0]->st_dept_installation;
                                                                                                    $html.='</span></strong></td>
                                                                                                </tr>
                                                                                                 <tr>
                                                                                                    <td style="font-size: 14px; line-height: 150%;">Dates:</td>
                                                                                                    <td><strong><span style="font-size: 14px; line-height: 150%;">'.$survey_details[0]->st_po_dept_date.' <br/>';
                                                                                              if(!empty($survey_details[0]->st_installation_dept_date))
                                                                                                $html.=$survey_details[0]->st_installation_dept_date;
                                                                                                   $html.=' </span></strong></td>
                                                                                                </tr>
                                                                                                
                                                                                                <tr>
                                                                                                    <td style="font-size: 14px; line-height: 150%;">Extra Details :</td>
                                                                                                    <td><strong><span style="font-size: 14px; line-height: 150%;">'.$survey_details[0]->st_additional_desc.'</span></strong></td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                        <p style="line-height: 150%;"><br></p>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td><td width="0"></td><td width="280" valign="top"><![endif]-->
                                                        <table class="es-right" cellspacing="0" cellpadding="0" align="right">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="280" align="left">
                                                                        <table style="border-left:1px solid transparent;border-right:1px solid transparent;border-top:1px solid transparent;border-bottom:1px solid transparent;background-color: #efefef; border-collapse: separate; background-position: center top;" width="100%" cellspacing="0" cellpadding="0" bgcolor="#efefef">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20t es-p10b es-p20r es-p20l" align="left">
                                                                                        <h4 style="color: #ffc246;">Customer Details:</h4>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20b es-p20r es-p20l" align="left">
                                                                                        <p>Customer Name: '.$survey_details[0]->st_new_cust_name.'  </p>
                                                                                        <p>Customer Company: '.$survey_details[0]->st_new_cust_comp.'  </p>
                                                                                         <p>Customer Email: '.$survey_details[0]->st_new_cust_email.'  </p>
                                                                                         <p>Customer Mobile: '.$survey_details[0]->st_new_cust_mobile.'  </p>
                                                                                          <p>Customer Landline: '.$survey_details[0]->st_new_cust_land.'  </p>';
                                                                                       
                                                                                    $html.='</td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td></tr></table><![endif]-->
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    
                        
                        <table cellpadding="0" cellspacing="0" class="es-footer" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" esd-custom-block-id="88654" align="center">
                                        <table class="es-footer-body" style="background-color: #333333;" width="600" cellspacing="0" cellpadding="0" bgcolor="#333333" align="center">
                                            <tbody>
                                               
                                                <tr>
                                                    <td class="esd-structure es-p20t es-p15b es-p20r es-p20l" style="background-position: center center; background-color: #ffc246;" bgcolor="#ffc246" align="left">
                                                       
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>';
// print_r($html);
         $CI->email->message($html);
         if($CI->email->send())
         return true;
          else
         {
          return false;
           //echo $CI->email->print_debugger();
         }              
}


function send_customer_installation_mail($survey_data,$installation_data)
{
      $html='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta name="x-apple-disable-message-reformatting">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="telephone=no" name="format-detection">
    <title></title>
    <!--[if (mso 16)]>
    <style type="text/css">
    a {text-decoration: none;}
    </style>
    <![endif]-->
    <!--[if gte mso 9]><style>sup { font-size: 100% !important; }</style><![endif]-->
    <!--[if gte mso 9]>
<xml>
    <o:OfficeDocumentSettings>
    <o:AllowPNG></o:AllowPNG>
    <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
</xml>
<![endif]-->
<style type="text/css">
    /* CONFIG STYLES Please do not delete and edit CSS styles below */
/* IMPORTANT THIS STYLES MUST BE ON FINAL EMAIL */
#outlook a {
    padding: 0;
}

.ExternalClass {
    width: 100%;
}

.ExternalClass,
.ExternalClass p,
.ExternalClass span,
.ExternalClass font,
.ExternalClass td,
.ExternalClass div {
    line-height: 100%;
}

.es-button {
    mso-style-priority: 100 !important;
    text-decoration: none !important;
}

a[x-apple-data-detectors] {
    color: inherit !important;
    text-decoration: none !important;
    font-size: inherit !important;
    font-family: inherit !important;
    font-weight: inherit !important;
    line-height: inherit !important;
}

.es-desk-hidden {
    display: none;
    float: left;
    overflow: hidden;
    width: 0;
    max-height: 0;
    line-height: 0;
    mso-hide: all;
}

td .es-button-border:hover a.es-button-1556804085234 {
    background: #7dbf44 !important;
    border-color: #7dbf44 !important;
}

td .es-button-border-1556804085253:hover {
    background: #7dbf44 !important;
}

.es-button-border:hover a.es-button {
    background: #7dbf44 !important;
    border-color: #7dbf44 !important;
}

.es-button-border:hover {
    background: #7dbf44 !important;
    border-color: #7dbf44 #7dbf44 #7dbf44 #7dbf44 !important;
}

td .es-button-border:hover a.es-button-1556806949166 {
    background: #7dbf44 !important;
    border-color: #7dbf44 !important;
}

td .es-button-border-1556806949166:hover {
    background: #7dbf44 !important;
}

/*
END OF IMPORTANT
*/
s {
    text-decoration: line-through;
}

html,
body {
    width: 100%;
    font-family: arial, "helvetica neue", helvetica, sans-serif;
    -webkit-text-size-adjust: 100%;
    -ms-text-size-adjust: 100%;
}

table {
    mso-table-lspace: 0pt;
    mso-table-rspace: 0pt;
    border-collapse: collapse;
    border-spacing: 0px;
}

table td,
html,
body,
.es-wrapper {
    padding: 0;
    Margin: 0;
}

.es-content,
.es-header,
.es-footer {
    table-layout: fixed !important;
    width: 100%;
}

img {
    display: block;
    border: 0;
    outline: none;
    text-decoration: none;
    -ms-interpolation-mode: bicubic;
}

table tr {
    border-collapse: collapse;
}

p,
hr {
    Margin: 0;
}

h1,
h2,
h3,
h4,
h5 {
    Margin: 0;
    line-height: 120%;
    mso-line-height-rule: exactly;
    font-family: arial, "helvetica neue", helvetica, sans-serif;
}

p,
ul li,
ol li,
a {
    -webkit-text-size-adjust: none;
    -ms-text-size-adjust: none;
    mso-line-height-rule: exactly;
}

.es-left {
    float: left;
}

.es-right {
    float: right;
}

.es-p5 {
    padding: 5px;
}

.es-p5t {
    padding-top: 5px;
}

.es-p5b {
    padding-bottom: 5px;
}

.es-p5l {
    padding-left: 5px;
}

.es-p5r {
    padding-right: 5px;
}

.es-p10 {
    padding: 10px;
}

.es-p10t {
    padding-top: 10px;
}

.es-p10b {
    padding-bottom: 10px;
}

.es-p10l {
    padding-left: 10px;
}

.es-p10r {
    padding-right: 10px;
}

.es-p15 {
    padding: 15px;
}

.es-p15t {
    padding-top: 15px;
}

.es-p15b {
    padding-bottom: 15px;
}

.es-p15l {
    padding-left: 15px;
}

.es-p15r {
    padding-right: 15px;
}

.es-p20 {
    padding: 20px;
}

.es-p20t {
    padding-top: 20px;
}

.es-p20b {
    padding-bottom: 20px;
}

.es-p20l {
    padding-left: 20px;
}

.es-p20r {
    padding-right: 20px;
}

.es-p25 {
    padding: 25px;
}

.es-p25t {
    padding-top: 25px;
}

.es-p25b {
    padding-bottom: 25px;
}

.es-p25l {
    padding-left: 25px;
}

.es-p25r {
    padding-right: 25px;
}

.es-p30 {
    padding: 30px;
}

.es-p30t {
    padding-top: 30px;
}

.es-p30b {
    padding-bottom: 30px;
}

.es-p30l {
    padding-left: 30px;
}

.es-p30r {
    padding-right: 30px;
}

.es-p35 {
    padding: 35px;
}

.es-p35t {
    padding-top: 35px;
}

.es-p35b {
    padding-bottom: 35px;
}

.es-p35l {
    padding-left: 35px;
}

.es-p35r {
    padding-right: 35px;
}

.es-p40 {
    padding: 40px;
}

.es-p40t {
    padding-top: 40px;
}

.es-p40b {
    padding-bottom: 40px;
}

.es-p40l {
    padding-left: 40px;
}

.es-p40r {
    padding-right: 40px;
}

.es-menu td {
    border: 0;
}

.es-menu td a img {
    display: inline-block !important;
}

/* END CONFIG STYLES */
a {
    font-family: arial, "helvetica neue", helvetica, sans-serif;
    font-size: 14px;
    text-decoration: none;
}

h1 {
    font-size: 30px;
    font-style: normal;
    font-weight: normal;
    color: #ffc246;
}

h1 a {
    font-size: 30px;
}

h2 {
    font-size: 26px;
    font-style: normal;
    font-weight: bold;
    color: #ffc246;
}

h2 a {
    font-size: 26px;
}

h3 {
    font-size: 22px;
    font-style: normal;
    font-weight: normal;
    color: #ffc246;
}

h3 a {
    font-size: 22px;
}

p,
ul li,
ol li {
    font-size: 14px;
    font-family: arial, "helvetica neue", helvetica, sans-serif;
    line-height: 150%;
}

ul li,
ol li {
    Margin-bottom: 15px;
}

.es-menu td a {
    text-decoration: none;
    display: block;
}

.es-wrapper {
    width: 100%;
    height: 100%;
    background-image: ;
    background-repeat: repeat;
    background-position: center top;
}

.es-wrapper-color {
    background-color: #f6f6f6;
}

.es-content-body {
    background-color: #ffffff;
}

.es-content-body p,
.es-content-body ul li,
.es-content-body ol li {
    color: #333333;
}

.es-content-body a {
    color: #ffc246;
}

.es-header {
    background-color: transparent;
    background-image: ;
    background-repeat: repeat;
    background-position: center top;
}

.es-header-body {
    background-color: #ffffff;
}

.es-header-body p,
.es-header-body ul li,
.es-header-body ol li {
    color: #ffc246;
    font-size: 16px;
}

.es-header-body a {
    color: #ffc246;
    font-size: 16px;
}

.es-footer {
    background-color: transparent;
    background-image: ;
    background-repeat: repeat;
    background-position: center top;
}

.es-footer-body {
    background-color: transparent;
}

.es-footer-body p,
.es-footer-body ul li,
.es-footer-body ol li {
    color: #ffffff;
    font-size: 14px;
}

.es-footer-body a {
    color: #ffffff;
    font-size: 14px;
}

.es-infoblock,
.es-infoblock p,
.es-infoblock ul li,
.es-infoblock ol li {
    line-height: 120%;
    font-size: 12px;
    color: #cccccc;
}

.es-infoblock a {
    font-size: 12px;
    color: #cccccc;
}

a.es-button {
    border-style: solid;
    border-color: #ffc246;
    border-width: 10px 20px 10px 20px;
    display: inline-block;
    background: #ffc246;
    border-radius: 0px;
    font-size: 18px;
    font-family: arial, "helvetica neue", helvetica, sans-serif;
    font-weight: normal;
    font-style: normal;
    line-height: 120%;
    color: #ffffff;
    text-decoration: none;
    width: auto;
    text-align: center;
}

.es-button-border {
    border-style: solid solid solid solid;
    border-color: #ffc246 #ffc246 #ffc246 #ffc246;
    background: #ffc246;
    border-width: 0px 0px 0px 0px;
    display: inline-block;
    border-radius: 0px;
    width: auto;
}

/* RESPONSIVE STYLES Please do not delete and edit CSS styles below. If you dont need responsive layout, please delete this section. */
@media only screen and (max-width: 600px) {

    p,
    ul li,
    ol li,
    a {
        font-size: 14px !important;
        line-height: 150% !important;
    }

    h1 {
        font-size: 30px !important;
        text-align: center;
        line-height: 120% !important;
    }

    h2 {
        font-size: 22px !important;
        text-align: center;
        line-height: 120% !important;
    }

    h3 {
        font-size: 20px !important;
        text-align: center;
        line-height: 120% !important;
    }

    h1 a {
        font-size: 30px !important;
    }

    h2 a {
        font-size: 22px !important;
    }

    h3 a {
        font-size: 20px !important;
    }

    .es-menu td a {
        font-size: 16px !important;
    }

    .es-header-body p,
    .es-header-body ul li,
    .es-header-body ol li,
    .es-header-body a {
        font-size: 16px !important;
    }

    .es-footer-body p,
    .es-footer-body ul li,
    .es-footer-body ol li,
    .es-footer-body a {
        font-size: 14px !important;
    }

    .es-infoblock p,
    .es-infoblock ul li,
    .es-infoblock ol li,
    .es-infoblock a {
        font-size: 12px !important;
    }

    *[class="gmail-fix"] {
        display: none !important;
    }

    .es-m-txt-c,
    .es-m-txt-c h1,
    .es-m-txt-c h2,
    .es-m-txt-c h3 {
        text-align: center !important;
    }

    .es-m-txt-r,
    .es-m-txt-r h1,
    .es-m-txt-r h2,
    .es-m-txt-r h3 {
        text-align: right !important;
    }

    .es-m-txt-l,
    .es-m-txt-l h1,
    .es-m-txt-l h2,
    .es-m-txt-l h3 {
        text-align: left !important;
    }

    .es-m-txt-r img,
    .es-m-txt-c img,
    .es-m-txt-l img {
        display: inline !important;
    }

    .es-button-border {
        display: block !important;
    }

    a.es-button {
        font-size: 20px !important;
        display: block !important;
        border-left-width: 0px !important;
        border-right-width: 0px !important;
    }

    .es-btn-fw {
        border-width: 10px 0px !important;
        text-align: center !important;
    }

    .es-adaptive table,
    .es-btn-fw,
    .es-btn-fw-brdr,
    .es-left,
    .es-right {
        width: 100% !important;
    }

    .es-content table,
    .es-header table,
    .es-footer table,
    .es-content,
    .es-footer,
    .es-header {
        width: 100% !important;
        max-width: 600px !important;
    }

    .es-adapt-td {
        display: block !important;
        width: 100% !important;
    }

    .adapt-img {
        width: 100% !important;
        height: auto !important;
    }

    .es-m-p0 {
        padding: 0px !important;
    }

    .es-m-p0r {
        padding-right: 0px !important;
    }

    .es-m-p0l {
        padding-left: 0px !important;
    }

    .es-m-p0t {
        padding-top: 0px !important;
    }

    .es-m-p0b {
        padding-bottom: 0 !important;
    }

    .es-m-p20b {
        padding-bottom: 20px !important;
    }

    .es-mobile-hidden,
    .es-hidden {
        display: none !important;
    }

    tr.es-desk-hidden,
    td.es-desk-hidden,
    table.es-desk-hidden {
        width: auto !important;
        overflow: visible !important;
        float: none !important;
        max-height: inherit !important;
        line-height: inherit !important;
    }

    tr.es-desk-hidden {
        display: table-row !important;
    }

    table.es-desk-hidden {
        display: table !important;
    }

    td.es-desk-menu-hidden {
        display: table-cell !important;
    }

    .es-menu td {
        width: 1% !important;
    }

    table.es-table-not-adapt,
    .esd-block-html table {
        width: auto !important;
    }

    table.es-social {
        display: inline-block !important;
    }

    table.es-social td {
        display: inline-block !important;
    }
}

/* END RESPONSIVE STYLES */
</style>
</head>

<body>
    <div class="es-wrapper-color">
        <!--[if gte mso 9]>
            <v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
                <v:fill type="tile" color="#f6f6f6"></v:fill>
            </v:background>
        <![endif]-->
        <table class="es-wrapper" width="100%" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td class="esd-email-paddings" valign="top">
                      
                        <table cellpadding="0" cellspacing="0" class="es-header" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" align="center" esd-custom-block-id="88656">
                                        <table class="es-header-body" width="600" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p20t es-p10b es-p20r es-p20l" style="background-position: center center;" align="left">
                                                        <!--[if mso]><table width="560" cellpadding="0" cellspacing="0"><tr><td width="270" valign="top"><![endif]-->
                                                        <table class="es-left" cellspacing="0" cellpadding="0" align="left">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="es-m-p20b esd-container-frame" width="270" align="left">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-image es-p5b" align="left" style="font-size:0"><a target="_blank" href="https://birigroup.com/"><img src="https://www.birigroup.com/temp_styles/assets/img/logo/Biri%20Group%20Logo-01.png" alt style="display: block;" class="adapt-img" width="125"></a></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td><td width="20"></td><td width="270" valign="top"><![endif]-->
                                                        <table class="es-right" cellspacing="0" cellpadding="0" align="right">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="270" align="left">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-menu">
                                                                                        <table class="es-menu" width="100%" cellspacing="0" cellpadding="0">
                                                                                            <tbody>
                                                                                                <tr class="links">
                                                                                                    <td class="es-p10t es-p10b es-p5r es-p5l" style="padding-bottom: 10px; padding-top: 10px; " width="33.33%" valign="top" bgcolor="transparent" align="center">
                                                                                                        Item Request Details
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td></tr></table><![endif]-->
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table cellpadding="0" cellspacing="0" class="es-content" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" align="center">
                                        <table bgcolor="#ffffff" class="es-content-body" align="center" cellpadding="0" cellspacing="0" width="600">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure" align="left" style="background-position: center top;" esd-custom-block-id="44739">
                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="600" class="esd-container-frame" align="center" valign="top">
                                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                                            <tbody>
                                                                                <tr>
                                                                                   <td class="esd-block-image es-p25t es-p25b es-p35r es-p35l esd-frame esd-hover esdev-disable-select esd-draggable esd-block" align="center" style="font-size:0" esd-handler-name="imgBlockHandler">
                      
        
        
                <div class="esd-block-btn ">
                    <div class="esd-more"><a><span class="es-icon-dot-3"></span></a></div>
                    
                    
                    <div class="esd-move ui-draggable-handle" title="Move">
                        <a><span class="es-icon-move"></span></a>
                    </div>
                    <div class="esd-copy ui-draggable-handle" title="Copy">
                        <a><span class="es-icon-copy"></span></a>
                    </div>
                    <div class="esd-delete" title="Delete">
                        <a><span class="es-icon-delete"></span></a>
                    </div>
                </div>
                <img src="'.base_url('png_img/'.$icon_use).'" width="150" height="150"></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table cellpadding="0" cellspacing="0" class="es-content" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" align="center" esd-custom-block-id="44757">
                                        <table bgcolor="#ffffff" class="es-content-body" align="center" cellpadding="0" cellspacing="0" width="600">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p20t es-p20r es-p20l" align="left" style="background-position: center top;" esd-custom-block-id="44741">
                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="560" class="esd-container-frame" align="center" valign="top">
                                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center" class="esd-block-text">
                                                                                        <h2 style="color: #ffc246;">'.$order_sts.'</h2>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td align="center" class="esd-block-text es-p10t">
                                                                                        <p>'.$msg_to_use.'</p>
                                                                                    </td>
                                                                                </tr>
                                                                              
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="esd-structure es-p20t es-p10b es-p20r es-p20l" align="left" style="background-position: center top;" esd-custom-block-id="44742">
                                                        <!--[if mso]><table width="560" cellpadding="0" cellspacing="0"><tr><td width="280" valign="top"><![endif]-->
                                                        <table class="es-left" cellspacing="0" cellpadding="0" align="left">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="es-m-p20b esd-container-frame" width="280" align="left">
                                                                        <table style="border-left:1px solid transparent;border-top:1px solid transparent;border-bottom:1px solid transparent;background-color: #efefef; border-collapse: separate; background-position: center top;" width="100%" cellspacing="0" cellpadding="0" bgcolor="#efefef">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20t es-p10b es-p20r es-p20l" align="left">
                                                                                        <h4 style="color: #ffc246;">SUMMARY:</h4>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20b es-p20r es-p20l" align="left">
                                                                                        <table style="width: 100%;" class="cke_show_border" cellspacing="1" cellpadding="1" border="0" align="left">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td style="font-size: 14px; line-height: 150%;">Request Number #:</td>
                                                                                                    <td><strong><span style="font-size: 14px; line-height: 150%;">'.$item_req_details[0]->ir_req_no .'</span></strong></td>
                                                                                                </tr>
                                                                                               
                                                                                                <tr>
                                                                                                    <td style="font-size: 14px; line-height: 150%;"><b>Order Created by:</b></td>
                                                                                                    <td><strong><span style="font-size: 14px; line-height: 150%;">'.$item_req_details[0]->ir_user_created.'</span></strong></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td style="font-size: 14px; line-height: 150%;">Order Created on:</td>
                                                                                                    <td><strong><span style="font-size: 14px; line-height: 150%;">'.$item_req_details[0]->ir_order_date.'</span></strong></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td style="font-size: 14px; line-height: 150%;">Extra Details :</td>
                                                                                                    <td><strong><span style="font-size: 14px; line-height: 150%;">'.$item_req_details[0]->ir_extra_details.'</span></strong></td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                        <p style="line-height: 150%;"><br></p>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td><td width="0"></td><td width="280" valign="top"><![endif]-->
                                                        <table class="es-right" cellspacing="0" cellpadding="0" align="right">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="280" align="left">
                                                                        <table style="border-left:1px solid transparent;border-right:1px solid transparent;border-top:1px solid transparent;border-bottom:1px solid transparent;background-color: #efefef; border-collapse: separate; background-position: center top;" width="100%" cellspacing="0" cellpadding="0" bgcolor="#efefef">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20t es-p10b es-p20r es-p20l" align="left">
                                                                                        <h4 style="color: #ffc246;">Order Details:</h4>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td class="esd-block-text es-p20b es-p20r es-p20l" align="left">
                                                                                        <p>Purchase Department  </p>
                                                                                        <p>'.$order_sts.'</p>';
                                                                                        
                                                                                      if($item_req_details[0]->ir_req_status=='1' || $item_req_details[0]->ir_req_status=='2')
                                            {
                                                                                        $html.='<p><b>Request Created on:</b>'.$item_req_details[0]->ir_order_date.'</p>';
                                                                                        }
                                            elseif(($item_req_details[0]->ir_req_status>'2') && ($item_req_details[0]->ir_req_status<'5'))
                                            {
                                            $html.='<p><b>Estimated Departure(ETD):</b>'.$item_req_details[0]->expected_shipment_date.'</p>';
                                                                                        }
                                            elseif(($item_req_details[0]->ir_req_status=='5') )
                                            {
                                            $html.='<p><b>Expected Time of Arrival(ETA):</b>'.$item_req_details[0]->ir_eta.'</p>';
                                            }
                                            else{
                                            $html.='<p><b>Reason for rejection:</b>'.$item_req_details[0]->rejection_reason.'</p>';
                                            }
                                                                                    $html.='</td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td></tr></table><![endif]-->
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table cellpadding="0" cellspacing="0" class="es-content" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" align="center">
                                        <table bgcolor="#ffffff" class="es-content-body" align="center" cellpadding="0" cellspacing="0" width="600">
                                            <tbody>';
                                             foreach($prd_table_data as $index=>$pd3)
                    {
                    if(empty($pd3[0]->p_prd_img))
                        {
                            $filename="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpeg";
                         if (file_exists($filename)) {
                            $img_path=$filename;
                            } else {
                            $img_path="https://birigroup.com/uploads/prd_images/".rawurlencode($pd3[0]->pcode).".jpg";
                            }
                        }
                        else
                        {
                            $first_img_prd=explode(',',$pd3[0]->p_prd_img);
                            if(!empty($first_img_prd[0]))
                            $img_path="https://birigroup.com/uploads/prd_images/".$first_img_prd[0]."";
                            
                            else
                            $img_path="https://birigroup.com/uploads/prd_images/".$pd3[0]->p_prd_img."";
                            
                        }
                        
                        //print_r($img_path);
                        $pname=explode('|~~|',$pd3[0]->pname);
                        if(!empty($pname[0]))
                        {
                            $prd_names=explode(',',$pname[0]);
                            $product_name=$prd_names[0];
                            //$product_name=$pname[0];
                        }
                        else
                        {
                            $pname=explode(',',$pd3[0]->pname);
                            $product_name=$pname[0];
                        }
                        
                                                $html.=' <tr>
                                             
                                                   <td class="esd-structure es-p10t es-p10b es-p20r es-p20l" align="left" style="background-position: center top;" esd-custom-block-id="44745">
                                                        <!--[if mso]><table width="560" cellpadding="0" cellspacing="0"><tr><td width="154" valign="top"><![endif]-->
                                                        <table cellpadding="0" cellspacing="0" class="es-left" align="left">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="154" class="es-m-p20b esd-container-frame" align="left">
                                                                        <table cellpadding="0" cellspacing="0" width="100%" style="background-position: left top;">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center" class="esd-block-image" style="font-size:0"><img class="adapt-img" src="'.$img_path.'" alt style="display: block;" width="154"></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td><td width="20"></td><td width="386" valign="top"><![endif]-->
                                                        <table cellpadding="0" cellspacing="0" class="es-right" align="right">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="386" align="left" class="esd-container-frame">
                                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="left" class="esd-block-text es-p10t es-m-txt-l">
                                                                                        <h3 style="color: #ffc246; font-size: 19px;"><strong>'.$product_name.'</strong><br/><strong>'.$pd3[0]->pcode.'</strong></h3>
                                                                                    </td>
                                                                                </tr>
                                                                             
                                                                                <tr>
                                                                                    <td align="left" class="esd-block-text es-p10t es-m-txt-l">
                                                                                        <h3 style="color: #ffc246; font-size: 19px;"><strong><span style="color:#000000;">Qty:</span>&nbsp;'.$quntys[$index].'</strong></h3>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td align="left" class="esd-block-text es-p10t es-m-txt-l">
                                                                                        <h3 style="color: #ffc246; font-size: 19px;"><strong><span style="color:#000000;">Remarks:</span>&nbsp;'.$rmks[$index].'</strong></h3>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso]></td></tr></table><![endif]-->
                                                    </td>
                                                </tr>';
                                                }
                                                
                                           $html.=' </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                        <table cellpadding="0" cellspacing="0" class="es-footer" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" esd-custom-block-id="88654" align="center">
                                        <table class="es-footer-body" style="background-color: #333333;" width="600" cellspacing="0" cellpadding="0" bgcolor="#333333" align="center">
                                            <tbody>
                                               
                                                <tr>
                                                    <td class="esd-structure es-p20t es-p15b es-p20r es-p20l" style="background-position: center center; background-color: #ffc246;" bgcolor="#ffc246" align="left">
                                                       
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>';
}















































}