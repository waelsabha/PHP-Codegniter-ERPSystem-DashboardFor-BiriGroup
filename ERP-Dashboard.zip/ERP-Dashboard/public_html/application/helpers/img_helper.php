<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 {


function img_upload($img_data)
{
	  $CI =& get_instance();
$CI->load->library('image_lib');
	$CI->load->library('upload');
  $image = array();

	$ImageCount = count($_FILES[$img_data['img_name']]['name']);

$prd_img_data=array();
        for($io = 0; $io < $ImageCount; $io++){
            $_FILES['file']['name']= $_FILES[$img_data['img_name']]['name'][$io];
            $_FILES['file']['type']= $_FILES[$img_data['img_name']]['type'][$io];
           $_FILES['file']['tmp_name']= $_FILES[$img_data['img_name']]['tmp_name'][$io];
            $_FILES['file']['error']= $_FILES[$img_data['img_name']]['error'][$io];
            $_FILES['file']['size']= $_FILES[$img_data['img_name']]['size'][$io];

            // File upload configuration
            $uploadPath = $img_data['upload_path'];
      $config['file_name'] = time() . $_FILES[$img_data['img_name']]["name"][$io];
            $config['upload_path'] = $uploadPath;
           /// $config['max_size'] = '1024000';////1mb
           $config['allowed_types'] = 'jpg|jpeg|PNG|JPEG|JPG|png|pdf|doc|docx|csv|xlsx|xlsm|xls|xlt|msword|';

            // Load and initialize upload library
            $CI->load->library('upload', $config, 'prd_image');
            $CI->prd_image->initialize($config);
 
            // Upload file to server
            if($CI->prd_image->do_upload('file')){
                // Uploaded file data
                $imageData[] = $CI->prd_image->data();
     
  // echo "<pre>";
  // print_r($prd_img_data);
  // echo "</pre>";
        }
        
    }
    // echo "<pre>";
    // print_r($imageData);
    // echo "</pre>";
    if(!empty($imageData))
    {
     $prd_img_data[]=$imageData;
     return $prd_img_data;
 	}
 	else
    {
    return FALSE; 
    }	
}



function single_img_upload($img_data)
{
   $CI =& get_instance();
$CI->load->library('image_lib');
  $CI->load->library('upload');
  $image = array();

if (isset($_FILES[$img_data['img_name']]['name']) && $_FILES[$img_data['img_name']]['name'] != "") 
{

      $config = array();
      $config['file_name'] = time() . $_FILES[$img_data['img_name']]["name"];
    $config['upload_path'] = $img_data['upload_path'];
      $config['allowed_types'] = 'jpg|jpeg|png|JPG|JPEG|PNG|pdf|PDF';
      $config['max_size'] = '1024000';////1mb
      $config['file_ext_tolower'] = TRUE;
      $config['overwrite'] = FALSE;
      $config['remove_spaces'] = TRUE;
      $CI->load->library('upload', $config);
      // Create custom object for cover upload
     
      $CI->upload ->initialize($config);
      

      if($CI->upload->do_upload($img_data['img_name']))
      {
        $data3 = $CI->upload->data();
        $uploadedfile3 = $data3['file_name'];
        return $uploadedfile3;
      }
      else
      {
         return  FALSE; 
      }   
}
}



function pdf_upload_only($img_data)
{
   $CI =& get_instance();
$CI->load->library('image_lib');
  $CI->load->library('upload');
  $image = array();

if (isset($_FILES[$img_data['img_name']]['name']) && $_FILES[$img_data['img_name']]['name'] != "") 
{

      $config = array();
      $config['file_name'] = time() . $_FILES[$img_data['img_name']]["name"];
    $config['upload_path'] = $img_data['upload_path'];
      $config['allowed_types'] = 'pdf|PDF';
      $config['max_size'] = '1024000';////1mb
      $config['file_ext_tolower'] = TRUE;
      $config['overwrite'] = FALSE;
      $config['remove_spaces'] = TRUE;
      $CI->load->library('upload', $config);
      // Create custom object for cover upload
     
      $CI->upload ->initialize($config);
      

      if($CI->upload->do_upload($img_data['img_name']))
      {
        $data3 = $CI->upload->data();
        $uploadedfile3 = $data3['file_name'];
        return $uploadedfile3;
      }
      else
      {
         return  FALSE; 
      }   
}
}








}